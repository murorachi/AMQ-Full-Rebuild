# Historical screenshot set superseded

The Batch285 Quiz screenshots were removed from the compact Batch286 project package because Batch286 replaces the Quiz layout and includes a direct comparison against the user-provided gameplay reference. Current evidence is in `../batch286-quiz-gameplay-layout/`.
