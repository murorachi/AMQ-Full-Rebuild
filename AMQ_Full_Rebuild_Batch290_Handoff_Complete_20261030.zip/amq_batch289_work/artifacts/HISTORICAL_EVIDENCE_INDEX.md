# Historical evidence index for compact deliveries

This delivery intentionally does not copy every prior screenshot and raw test log into each ZIP.

- Latest visual evidence: `artifacts/batch282-home-catalog/` (four Home screenshots, four Catalog layout-fixture screenshots, four opaque-origin error-fixture screenshots).
- Official osu! visual references: `artifacts/osu-reference/`.
- Historical blocker and grouped Node-suite summaries retained: `artifacts/historical-summary/`.
- Historical batches 233–281 and their full evidence remain represented by their individual version ZIPs; Batch281 was not overwritten. Their detailed status is summarized in `docs/WORK_STATUS.md`, `docs/MASTER_CHECKLIST.md`, and the corresponding handoff documents.
- The 28 MB `references/osu-master.zip` source archive is research-only and not needed for AMQ runtime/tests. Its SHA-256 and research traceability remain in `references/OSU_SOURCE_ARCHIVE_INFO.md`, `docs/OSU_SOURCE_RESEARCH_BATCH271.md`, and `docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`. It is omitted from this compact package, not deleted from the prior full Batch281 delivery.

## Batch283 最新視覺證據
- Catalog 與 osu! Stable Song Select 並排圖：`artifacts/batch283-catalog-stable/catalog-vs-osu-stable-1920x1080.jpg`。
- 最新四尺寸 Home/Catalog 截圖、Dock 展開圖位於 `artifacts/batch283-catalog-stable/`。Catalog 為明確標示的六筆 layout fixture，不代表正式曲庫或 live artwork。
- 差距表：`docs/OSU_CATALOG_VISUAL_GAP_BATCH283.md`；交付摘要：`docs/BATCH283_DELIVERY_SUMMARY.md`。
- Batch283 四尺寸 browser 145/145，focused Node 39/39，Architecture 1,358/0。人工 Stable gate仍未通過。

## Batch285 最新 Quiz／Route 證據
- Stable Intro 原圖對照：`artifacts/batch285-quiz-route-ui/quiz-vs-osu-stable.jpg`；目前 AMQ Quiz 截圖與四尺寸 Browser 截圖同目錄。
- 正式 route grid root cause 已修：body 不再把 app header/main auto-place 到不同 implicit columns；功能頁單欄全寬，status 移至 route bar；Quiz setup 預設收合。
- `tests/batch285-quiz-route-ui.browser.py` 71/71 PASS；Catalog regression 148/148 PASS。全量 Node runner 的 101 個逐檔 logs 在完整工作目錄 `artifacts/batch285-regression/`，但 orchestration 在 300 秒上限中斷、沒有 exit-code summary，故主要 ZIP 只保留狀態摘要，不將它標成全量通過。
- 視覺差距：`docs/OSU_QUIZ_VISUAL_GAP_BATCH285.md`。人工 Stable gate仍未通過；此版不是最終 osu! fidelity。

## Batch286 compact-package retention
- Batch264 Quiz screenshot binaries and Batch285 Quiz route screenshots are superseded by `batch286-quiz-gameplay-layout/` and are not duplicated in the compact Batch286 package; their historical test results remain in work logs.
- Batch284 Quiz screenshots are superseded by Batch286; Batch284 Multiplayer screenshots and its direct Stable comparison remain.
- Current Quiz reference, current 1920×1080 viewport, side-by-side comparison and four-size browser harness are retained.
