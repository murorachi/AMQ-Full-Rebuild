# Batch285 Node suite attempt summary

- Target: 101 files matching `tests/*.test.cjs`.
- A per-file parallel runner produced 101 log files in the full working directory `artifacts/batch285-regression/`.
- Log scan found no `not ok`, `FAIL`, timeout marker, or TAP `# fail > 0` marker.
- However, the outer execution reached the 300-second tool limit before it wrote the final TSV/exit-code aggregation. Therefore this is **inconclusive evidence**, not a full-suite PASS claim. Re-run in smaller, deterministic batches and save exit status per file before declaring completion.
- Two older visual contract tests failed on their first pass because their assertions were stale against the current CSS / route structure. Their assertions were updated to reflect the current production owners, then `batch265-visual-structure.contract.test.cjs` passed 6/6 and `batch280-home-chrome.contract.test.cjs` passed 6/6.
- `tests/app-shell.browser.test.py` also hit the tool timeout; not counted as PASS.
