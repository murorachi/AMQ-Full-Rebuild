# Batch287 VNDB character layout evidence

The screenshots in this folder use an isolated test API and a simple SVG fixture image. They verify that the character strip is positioned at the bottom of the Quiz gameplay viewport, Settings can add/remove VNDB IDs, saved IDs restore, and the strip hides when no image is available.

The fixture is not VNDB artwork and must not be used as product art or as evidence that live VNDB API/image requests succeeded. The official AMQ reference remains `artifacts/quiz-reference/amq-gameplay-layout-reference.jpg`.
