@echo off
setlocal
cd /d "%~dp0"
echo AMQ Learning Tool - local launcher
where node >nul 2>nul
if not errorlevel 1 (
  node -e "const [major,minor]=process.versions.node.split('.').map(Number);process.exit(major>22||(major===22&&minor>=5)?0:1)"
  if not errorlevel 1 (
    echo Node.js 22.5+ found. Starting private API and static server; the browser opens after the server is ready.
    node server/start.cjs
    goto :eof
  )
)
echo Node.js 22.5+ not found. Falling back to a static-only server; private account and server SRS features will be unavailable.
where py >nul 2>nul
if %errorlevel%==0 (
  echo Python launcher found. Opening static server at http://127.0.0.1:8000/src/
  start "" http://127.0.0.1:8000/src/
  py -m http.server 8000
  goto :eof
)
where python >nul 2>nul
if %errorlevel%==0 (
  echo Python found. Opening static server at http://127.0.0.1:8000/src/
  start "" http://127.0.0.1:8000/src
  python -m http.server 8000
  goto :eof
)
echo Python is not installed. Trying to open the page directly; browser APIs may be restricted.
start "" "%~dp0src\index.html"
pause
