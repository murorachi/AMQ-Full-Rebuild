(function (global) {
  "use strict";
  global.AMQPrototypeData = Object.freeze([
    { id: "a01", source: "AMQ", title: "廻廻奇譚", artist: "Eve", work: "咒術迴戰", year: 2020, type: "OP", familiarity: "familiar", score: 86, color: "purple", note: "第一季片頭曲", recent: "今天 08:42", correct: true, duration: "1:30" },
    { id: "a02", source: "AMQ", title: "紅蓮華", artist: "LiSA", work: "鬼滅之刃", year: 2019, type: "OP", familiarity: "familiar", score: 92, color: "rose", note: "竈門炭治郎 立志篇片頭曲", recent: "昨天 21:16", correct: true, duration: "1:29" },
    { id: "e01", source: "EMQ", title: "アイドル", artist: "YOASOBI", work: "【我推的孩子】", year: 2023, type: "OP", familiarity: "learning", score: 54, color: "mint", note: "第一季片頭曲", recent: "昨天 20:51", correct: false, duration: "1:29" },
    { id: "a03", source: "AMQ", title: "unravel", artist: "TK from 凛として時雨", work: "東京喰種", year: 2014, type: "OP", familiarity: "learning", score: 48, color: "blue", note: "第一季片頭曲", recent: "昨天 20:38", correct: true, duration: "1:30" },
    { id: "a04", source: "AMQ", title: "again", artist: "YUI", work: "鋼之鍊金術師 FULLMETAL ALCHEMIST", year: 2009, type: "OP", familiarity: "new", score: 0, color: "gold", note: "FA 第一首片頭曲", recent: "尚未練習", correct: false, duration: "1:30" },
    { id: "e02", source: "EMQ", title: "SPECIALZ", artist: "King Gnu", work: "咒術迴戰 懷玉・玉折／澀谷事變", year: 2023, type: "OP", familiarity: "learning", score: 61, color: "purple", note: "澀谷事變片頭曲", recent: "10 月 25 日", correct: true, duration: "1:30" },
    { id: "a05", source: "AMQ", title: "secret base ～君がくれたもの～", artist: "ZONE", work: "未聞花名", year: 2011, type: "ED", familiarity: "familiar", score: 95, color: "mint", note: "片尾曲", recent: "10 月 25 日", correct: true, duration: "1:30" },
    { id: "a06", source: "AMQ", title: "残酷な天使のテーゼ", artist: "高橋洋子", work: "新世紀福音戰士", year: 1995, type: "OP", familiarity: "familiar", score: 88, color: "rose", note: "電視動畫片頭曲", recent: "10 月 24 日", correct: true, duration: "1:30" },
    { id: "e03", source: "EMQ", title: "花の塔", artist: "さユり", work: "Lycoris Recoil 莉可麗絲", year: 2022, type: "ED", familiarity: "new", score: 0, color: "blue", note: "片尾曲", recent: "尚未練習", correct: false, duration: "1:30" },
    { id: "a07", source: "AMQ", title: "青のすみか", artist: "キタニタツヤ", work: "咒術迴戰 懷玉・玉折", year: 2023, type: "OP", familiarity: "learning", score: 39, color: "blue", note: "懷玉・玉折片頭曲", recent: "10 月 24 日", correct: false, duration: "1:30" },
    { id: "a08", source: "AMQ", title: "君の知らない物語", artist: "supercell", work: "化物語", year: 2009, type: "ED", familiarity: "familiar", score: 80, color: "gold", note: "動畫片尾曲", recent: "10 月 23 日", correct: true, duration: "1:30" },
    { id: "e04", source: "EMQ", title: "KICK BACK", artist: "米津玄師", work: "鏈鋸人", year: 2022, type: "OP", familiarity: "new", score: 0, color: "rose", note: "動畫片頭曲", recent: "尚未練習", correct: false, duration: "1:30" },
    { id: "a09", source: "AMQ", title: "打上花火", artist: "DAOKO × 米津玄師", work: "煙花", year: 2017, type: "插入曲", familiarity: "learning", score: 58, color: "purple", note: "電影主題曲", recent: "10 月 22 日", correct: true, duration: "1:30" },
    { id: "a10", source: "AMQ", title: "シュガーソングとビターステップ", artist: "UNISON SQUARE GARDEN", work: "血界戰線", year: 2015, type: "ED", familiarity: "new", score: 0, color: "mint", note: "片尾曲", recent: "尚未練習", correct: false, duration: "1:30" },
    { id: "e05", source: "EMQ", title: "炎", artist: "LiSA", work: "鬼滅之刃劇場版 無限列車篇", year: 2020, type: "插入曲", familiarity: "learning", score: 66, color: "gold", note: "劇場版主題曲", recent: "10 月 21 日", correct: true, duration: "1:30" }
  ]);
})(window);
