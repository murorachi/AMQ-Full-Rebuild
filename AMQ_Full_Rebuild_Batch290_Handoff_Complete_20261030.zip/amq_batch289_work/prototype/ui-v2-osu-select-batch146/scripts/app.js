(function (global) {
  "use strict";
  const songs = global.AMQPrototypeData.map(song => ({ ...song }));
  const STORAGE_KEY = "amq-ui-prototype-v1-state";
  let storageWarningShown = false;
  const state = {
    view: "home", catalogTab: "all", selectedSongId: songs[0].id,
    favorites: new Set(["a01", "a05", "a08"]), familiarityOverrides: new Map(), wrongSongIds: new Set(),
    lastSession: { mode: "AMQ", questionCount: 10, range: "all", clipLength: "15", showHints: false, autoNext: false },
    sourceFilters: new Set(["AMQ", "EMQ"]), familiarityFilters: new Set(), typeFilters: new Set(),
    query: "", sort: "recommended", mode: "AMQ", questionCount: 20, range: "all",
    clipLength: "15", showHints: false, autoNext: false,
    quizQueue: [], quizIndex: 0, quizResults: [], quizStatus: "idle", currentAnswer: "", isPlaying: false,
    playbackSeconds: 0, playbackInterval: null, toastTimer: null
  };
  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const escapeHtml = value => String(value ?? "").replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]);
  const currentSong = () => songs.find(song => song.id === state.selectedSongId) || songs[0];
  const songById = id => songs.find(song => song.id === id) || songs[0];
  const familiarityOf = song => state.familiarityOverrides.get(song.id) || song.familiarity;
  const familiarityLabel = value => ({ new: "尚未練習", learning: "學習中", familiar: "已熟悉" })[value] || "學習中";
  const cover = song => `<span class="cover-art ${escapeHtml(song.color)}"><img src="${escapeHtml(song.cover)}" alt="${escapeHtml(song.work)} 作品封面" loading="lazy" draggable="false"><span class="cover-art-sheen" aria-hidden="true"></span></span>`;
  const resultMark = correct => `<span class="result-mark ${correct ? "" : "wrong"}">${correct ? "✓" : "×"}</span>`;

  function restoreState() {
    try {
      const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!saved || typeof saved !== "object") return;
      if (Array.isArray(saved.favorites)) state.favorites = new Set(saved.favorites.filter(id => songs.some(song => song.id === id)));
      if (saved.mode && ["AMQ", "EMQ", "MIX"].includes(saved.mode)) state.mode = saved.mode;
      if (saved.questionCount !== undefined && [0, 10, 20, 50].includes(saved.questionCount)) state.questionCount = saved.questionCount;
      if (saved.range && ["all", "favorites", "unfamiliar"].includes(saved.range)) state.range = saved.range;
      if (Array.isArray(saved.familiarityOverrides)) state.familiarityOverrides = new Map(saved.familiarityOverrides.filter(entry => Array.isArray(entry) && songs.some(song => song.id === entry[0]) && ["new", "learning", "familiar"].includes(entry[1])));
      if (Array.isArray(saved.wrongSongIds)) state.wrongSongIds = new Set(saved.wrongSongIds.filter(id => songs.some(song => song.id === id)));
      if (saved.lastSession && typeof saved.lastSession === "object" && ["AMQ", "EMQ", "MIX"].includes(saved.lastSession.mode) && [0, 10, 20, 50].includes(saved.lastSession.questionCount) && ["all", "favorites", "unfamiliar"].includes(saved.lastSession.range)) state.lastSession = { ...state.lastSession, ...saved.lastSession };
    } catch (_) { /* Prototype storage is disposable; malformed state falls back to defaults. */ }
  }
  function persistState() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify({ favorites: [...state.favorites], mode: state.mode, questionCount: state.questionCount, range: state.range, familiarityOverrides: [...state.familiarityOverrides], wrongSongIds: [...state.wrongSongIds], lastSession: state.lastSession })); }
    catch (_) { if (!storageWarningShown) { storageWarningShown = true; toast("無法保存設定，本次仍可使用。", "error"); } }
  }
  function toast(message, kind = "") {
    const region = $("#toast-region");
    const node = document.createElement("div"); node.className = `toast ${kind}`; node.textContent = message; region.append(node);
    global.setTimeout(() => node.remove(), 2600);
  }
  function showView(view) {
    const previousView = state.view;
    const valid = ["home", "catalog", "settings", "quiz", "history", "song-info"];
    if (!valid.includes(view)) return;
    if (previousView === "quiz" && view !== "quiz") stopPlayerPlayback();
    state.view = view;
    $$(".view").forEach(section => { const active = section.id === `view-${view}`; section.hidden = !active; section.classList.toggle("active", active); });
    $$(".rail-item[data-nav]:not(.rail-settings), .mobile-nav-item[data-nav]").forEach(button => button.classList.toggle("active", button.dataset.nav === (view === "quiz" ? "settings" : view === "song-info" ? "catalog" : view)));
    const contexts = { home: ["AMQ", "首頁"], catalog: ["AMQ", "選曲"], settings: ["AMQ", "練習設定"], quiz: ["AMQ", "答題中"], history: ["AMQ", "學習紀錄"], "song-info": ["AMQ", "歌曲資訊"] };
    $("#top-context").textContent = contexts[view][0]; $("#top-subcontext").textContent = contexts[view][1];
    $("#main-stage").focus({ preventScroll: true });
    if (view === "home") renderHome();
    if (view === "catalog") renderCatalog();
    if (view === "settings") renderSettings();
    if (view === "history") renderHistory();
    if (view === "song-info") renderFullSongInfo();
    if (view === "quiz") renderQuiz();
  }
  function visibleSongs() {
    let list = songs.filter(song => {
      if (!state.sourceFilters.has(song.source)) return false;
      if (state.familiarityFilters.size && !state.familiarityFilters.has(familiarityOf(song))) return false;
      if (state.typeFilters.size && !state.typeFilters.has(song.type)) return false;
      if (state.catalogTab === "favorites" && !state.favorites.has(song.id)) return false;
      if (state.catalogTab === "recent" && song.recent === "尚未練習") return false;
      if (state.catalogTab === "unfamiliar" && familiarityOf(song) === "familiar") return false;
      if (state.query) {
        const q = state.query.toLocaleLowerCase();
        const fields = [song.title, song.artist, song.work, song.source, song.type, String(song.year)].join(" ").toLocaleLowerCase();
        if (!fields.includes(q)) return false;
      }
      return true;
    });
    if (state.sort === "title") list.sort((a, b) => a.title.localeCompare(b.title, "ja"));
    else if (state.sort === "work") list.sort((a, b) => a.work.localeCompare(b.work, "zh-Hant"));
    else if (state.sort === "recent") list.sort((a, b) => (a.recent === "尚未練習" ? "" : a.recent).localeCompare(b.recent === "尚未練習" ? "" : b.recent));
    else if (state.sort === "familiarity") list.sort((a, b) => a.score - b.score);
    return list;
  }
  function renderCounts() {
    const favoriteCount = songs.filter(song => state.favorites.has(song.id)).length;
    const recentCount = songs.filter(song => song.recent !== "尚未練習").length;
    const unfamiliarCount = songs.filter(song => familiarityOf(song) !== "familiar").length;
    [["#count-all", songs.length], ["#tab-count-all", songs.length], ["#count-favorites", favoriteCount], ["#tab-count-favorites", favoriteCount], ["#count-recent", recentCount], ["#count-unfamiliar", unfamiliarCount], ["#setup-favorite-count", `${favoriteCount} 首`], ["#setup-unfamiliar-count", `${unfamiliarCount} 首`]].forEach(([selector, value]) => { const node = $(selector); if (node) node.textContent = value; });
  }
  function renderCatalog() {
    renderCounts();
    $$("[data-catalog-tab]").forEach(button => { const active = button.dataset.catalogTab === state.catalogTab; button.classList.toggle("selected", active && button.classList.contains("filter-option")); button.classList.toggle("active", active && button.classList.contains("catalog-tab")); if (button.getAttribute("role") === "tab") button.setAttribute("aria-selected", String(active)); });
    const list = visibleSongs();
    $("#result-summary").textContent = `顯示 ${list.length} 首歌曲`;
    $("#song-list").innerHTML = list.map(song => {
      const familiarity = familiarityOf(song); const score = state.familiarityOverrides.has(song.id) ? (familiarity === "new" ? 0 : familiarity === "learning" ? 52 : 85) : song.score;
      return `<div class="song-row ${song.id === state.selectedSongId ? "selected" : ""}" data-song-id="${escapeHtml(song.id)}" role="option" aria-selected="${song.id === state.selectedSongId}" tabindex="0"><div class="song-primary">${cover(song)}<span class="row-copy"><strong>${escapeHtml(song.title)}</strong><small>${escapeHtml(song.work)} · ${escapeHtml(song.artist)}</small></span></div><span class="song-source"><i class="source-dot ${song.source === "EMQ" ? "emq" : ""}"></i>${song.source}</span><span class="familiarity-cell"><span class="familiarity-label ${familiarity}">${familiarityLabel(familiarity)}</span><span class="familiarity-track"><span class="${familiarity}" style="width:${score}%"></span></span></span><span class="song-actions"><button class="row-action ${state.favorites.has(song.id) ? "favorited" : ""}" data-favorite-id="${escapeHtml(song.id)}" aria-label="${state.favorites.has(song.id) ? "取消收藏" : "收藏"}" title="收藏">${state.favorites.has(song.id) ? "♥" : "♡"}</button><button class="row-action" data-play-song="${escapeHtml(song.id)}" aria-label="選擇歌曲" title="選擇歌曲">›</button></span></div>`;
    }).join("");
    $("#catalog-empty").hidden = list.length > 0;
    $("#song-list").hidden = list.length === 0;
    if (list.length && !list.some(song => song.id === state.selectedSongId)) state.selectedSongId = list[0].id;
    renderSongDetail(); renderPlayer();
  }
  function selectSong(id, openInfo = false) {
    if (!songs.some(song => song.id === id)) return;
    state.selectedSongId = id; renderCatalog(); renderPlayer();
    if (openInfo) { showView("song-info"); return; }
    if (state.view === "catalog") { const row = $(`.song-row[data-song-id="${CSS.escape(id)}"]`); if (row) row.scrollIntoView({ block: "nearest" }); }
  }
  function toggleFavorite(id) {
    if (state.favorites.has(id)) { state.favorites.delete(id); toast("已從收藏移除。"); }
    else { state.favorites.add(id); toast("已加入收藏。", ""); }
    persistState(); renderCounts();
    if (state.view === "catalog") renderCatalog();
    if (state.view === "home") renderHome();
    if (state.view === "song-info") renderFullSongInfo();
    if (state.view === "quiz") renderQuizFavorite();
    renderPlayer();
  }
  function renderSongDetail() {
    const song = currentSong(); const familiarity = familiarityOf(song); const score = state.familiarityOverrides.has(song.id) ? (familiarity === "new" ? 0 : familiarity === "learning" ? 52 : 85) : song.score;
    $("#song-detail").innerHTML = `<div class="detail-cover ${song.color}"><img src="${escapeHtml(song.cover)}" alt="${escapeHtml(song.work)} 作品視覺"><span class="detail-cover-label">作品視覺</span></div><div class="detail-title-row"><h2>${escapeHtml(song.title)}</h2><button class="row-action ${state.favorites.has(song.id) ? "favorited" : ""}" data-favorite-id="${escapeHtml(song.id)}" aria-label="${state.favorites.has(song.id) ? "取消收藏" : "收藏歌曲"}">${state.favorites.has(song.id) ? "♥" : "♡"}</button></div><p class="detail-work-title">${escapeHtml(song.work)}<br>${escapeHtml(song.artist)}</p><div class="detail-meta"><span class="meta-pill">${song.source}</span><span class="meta-pill">${escapeHtml(song.type)}</span><span class="meta-pill">${song.year}</span></div><div class="detail-primary-actions"><button class="button button-primary" id="detail-practice">練習這首歌 ↗</button><button class="button button-ghost" id="detail-full-info" aria-label="完整歌曲資訊">ⓘ</button></div><div class="detail-section"><div class="detail-section-head"><span>學習熟悉度</span><small>本機示範資料</small></div><div class="detail-familiarity"><div class="familiarity-ring" style="--progress:${score}%"><span>${score}%</span></div><div><strong>${familiarityLabel(familiarity)}</strong><p>${familiarity === "new" ? "尚無答題紀錄" : familiarity === "learning" ? "持續練習中" : "已熟悉"}</p></div></div></div><div class="detail-section"><div class="detail-section-head"><span>最近練習</span><small>${song.recent}</small></div><div class="detail-history-row">${cover(song)}<span class="row-copy"><strong>${song.recent === "尚未練習" ? "尚無練習紀錄" : "最近一次練習"}</strong><small>${song.recent === "尚未練習" ? "尚無紀錄" : `${song.source} · ${song.type}`}</small></span>${song.recent === "尚未練習" ? "" : resultMark(song.correct)}</div><button class="detail-expand" id="detail-open-history">查看完整學習紀錄 →</button></div>`;
  }
  function renderPlayer() {
    const song = currentSong();
    $("#player-cover").className = `player-cover ${song.color}`; $("#player-cover").innerHTML = `<img src="${escapeHtml(song.cover)}" alt="">`;
    $("#player-song-title").textContent = song.title; $("#player-work-title").textContent = `${song.work} · ${song.artist}`;
    $("#player-source").textContent = `${song.source} · DEMO`; $("#player-favorite").textContent = state.favorites.has(song.id) ? "♥" : "♡"; $("#player-favorite").classList.toggle("favorited", state.favorites.has(song.id));
  }
  function renderHome() {
    renderCounts();
    const recent = songs.filter(song => song.recent !== "尚未練習").slice(0, 4);
    $("#home-recent-list").innerHTML = recent.map(song => `<div class="recent-row" data-song-open="${song.id}" tabindex="0">${cover(song)}<span class="row-copy"><strong>${escapeHtml(song.title)}</strong><small>${escapeHtml(song.work)}</small></span>${resultMark(song.correct)}</div>`).join("");
    const favoriteSongs = songs.filter(song => state.favorites.has(song.id)).slice(0, 3);
    $("#favorite-preview").innerHTML = favoriteSongs.length ? favoriteSongs.map(song => `<div class="favorite-tile" data-song-open="${song.id}" tabindex="0">${cover(song)}<strong>${escapeHtml(song.title)}</strong><small>${escapeHtml(song.work)}</small></div>`).join("") : `<p class="muted">尚無收藏</p>`;
  }
  function renderSettings() {
    renderCounts();
    $$("[data-mode]").forEach(button => { const selected = button.dataset.mode === state.mode; button.classList.toggle("selected", selected); button.setAttribute("aria-checked", String(selected)); });
    $$("[data-question-count]").forEach(button => button.classList.toggle("selected", Number(button.dataset.questionCount) === state.questionCount));
    $$('input[name="range"]').forEach(input => { input.checked = input.value === state.range; input.closest(".range-option").classList.toggle("selected", input.checked); });
    $("#clip-length").value = state.clipLength; $("#show-hints").checked = state.showHints; $("#auto-next").checked = state.autoNext;
    $("#summary-mode").textContent = state.mode; $("#summary-count").textContent = state.questionCount ? `${state.questionCount} 題` : "不限題數";
    $("#summary-range").textContent = ({ all: "全部可用歌曲", favorites: "只練習我的收藏", unfamiliar: "只練習不熟悉的歌曲" })[state.range];
    $("#summary-advanced").textContent = state.typeFilters.size || state.clipLength !== "15" || state.showHints || state.autoNext ? "已自訂" : "預設";
  }
  function makeQuizPool() {
    let pool = songs.filter(song => state.mode === "MIX" || song.source === state.mode);
    if (state.range === "favorites") pool = pool.filter(song => state.favorites.has(song.id));
    if (state.range === "unfamiliar") pool = pool.filter(song => familiarityOf(song) !== "familiar");
    if (state.typeFilters.size) pool = pool.filter(song => state.typeFilters.has(song.type));
    if (!pool.length) return [];
    // A predictable rotation is easier to inspect in a prototype than random mock behavior.
    const offset = Math.max(0, pool.findIndex(song => song.id === state.selectedSongId));
    pool = pool.slice(offset).concat(pool.slice(0, offset));
    const count = state.questionCount || pool.length;
    return pool.slice(0, Math.min(count, pool.length));
  }
  function startPractice() {
    const queue = makeQuizPool();
    if (!queue.length) { toast("目前範圍沒有歌曲。請切換模式或收藏範圍。", "error"); return; }
    state.lastSession = { mode: state.mode, questionCount: state.questionCount, range: state.range, clipLength: state.clipLength, showHints: state.showHints, autoNext: state.autoNext };
    state.quizQueue = queue; state.quizIndex = 0; state.quizResults = []; state.quizStatus = "answering"; state.currentAnswer = "";
    setPlayerSong(queue[0]); showView("quiz"); renderQuiz();
    toast(`開始 ${state.mode} 練習，共 ${queue.length} 題。${state.questionCount > queue.length ? "示範曲庫歌曲不足，已縮短題數。" : ""}`);
  }
  function stopPlayerPlayback() { if (state.playbackInterval) global.clearInterval(state.playbackInterval); state.playbackInterval = null; state.isPlaying = false; state.playbackSeconds = 0; updatePlayerProgress(); const stage = $("#audio-stage"); if (stage) stage.classList.remove("playing"); if (state.view === "quiz") $("#audio-state").textContent = "已暫停"; }
  function setPlayerSong(song) { stopPlayerPlayback(); state.selectedSongId = song.id; renderPlayer(); updatePlayerProgress(); }
  function quizSong() { return state.quizQueue[state.quizIndex] || currentSong(); }
  function renderQuiz() {
    if (!state.quizQueue.length) return;
    const song = quizSong();
    const finished = state.quizIndex >= state.quizQueue.length;
    $("#quiz-mode-label").textContent = `${state.mode} 練習`;
    $("#quiz-progress-label").textContent = finished ? `已完成 ${state.quizQueue.length} 題` : `第 ${Math.min(state.quizIndex + 1, state.quizQueue.length)} 題，共 ${state.quizQueue.length} 題`;
    const progressPercent = finished ? 100 : Math.round(state.quizResults.length / state.quizQueue.length * 100);
    $("#quiz-progress-percent").textContent = `${String(progressPercent).padStart(2, "0")}%`;
    $("#quiz-progress-bar").style.width = `${progressPercent}%`;
    $("#quiz-title").textContent = finished ? "練習完成" : state.quizStatus === "result" ? (state.quizResults.at(-1)?.correct ? "答對" : "答錯") : "猜歌名";
    $("#quiz-prompt").textContent = finished ? "本輪結果" : state.showHints ? `${song.work} · ${song.year}` : "輸入歌曲名稱";
    $("#quiz-eyebrow").textContent = finished ? "完成" : state.quizStatus === "result" ? "結果" : "答題";
    $("#audio-state").textContent = state.isPlaying ? "示範播放中" : "示範音訊";
    $("#audio-stage").classList.toggle("playing", state.isPlaying);
    $("#answer-input").disabled = finished || state.quizStatus === "result";
    $("#answer-input").value = state.quizStatus === "answering" ? state.currentAnswer : "";
    $("#submit-answer").disabled = finished;
    $("#submit-answer").innerHTML = state.quizStatus === "result" ? "下一題 <span>→</span>" : finished ? "已完成" : "確認答案 <span>↗</span>";
    $("#reveal-answer").disabled = finished || state.quizStatus === "result";
    $("#reveal-answer").textContent = state.quizStatus === "result" ? "答案已揭曉" : "我不確定";
    $("#answer-feedback").hidden = state.quizStatus !== "result";
    if (state.quizStatus === "result" && state.quizResults.length) {
      const result = state.quizResults.at(-1); $("#answer-feedback").classList.toggle("wrong", !result.correct);
      $("#answer-feedback").textContent = result.correct ? `回答正確。${result.song.title} · ${result.song.work}` : `正確答案：${result.song.title} · ${result.song.work}。這首歌已列入本次錯題紀錄。`;
    }
    $("#quiz-correct-count").textContent = state.quizResults.filter(result => result.correct).length;
    $("#quiz-wrong-count").textContent = state.quizResults.filter(result => !result.correct).length;
    $("#quiz-remaining-count").textContent = Math.max(0, state.quizQueue.length - state.quizResults.length);
    $("#quiz-history-list").innerHTML = state.quizResults.slice(-4).reverse().map(result => `<div class="quiz-history-item">${cover(result.song)}<span class="row-copy"><strong>${escapeHtml(result.song.title)}</strong><small>${escapeHtml(result.song.work)}</small></span>${resultMark(result.correct)}</div>`).join("") || `<p class="muted empty-history">完成第一題後，結果會出現在這裡。</p>`;
    $("#mark-unfamiliar").textContent = familiarityOf(song) === "new" ? "✓ 已標記不熟悉" : "◌ 標記為不熟悉";
    renderQuizFavorite(); setPlayerSong(song); $("#player-song-title").textContent = finished ? "本輪練習已完成" : song.title; $("#player-work-title").textContent = finished ? `${state.quizResults.filter(result => result.correct).length} 題答對 · ${state.quizResults.filter(result => !result.correct).length} 題答錯` : `${song.work} · ${song.artist}`;
    $("#player-source").textContent = "DEMO AUDIO";
    if (state.quizStatus === "answering" && !finished) { const input = $("#answer-input"); if (state.view === "quiz") input.focus({ preventScroll: true }); }
  }
  function renderQuizFavorite() { const song = quizSong(); $("#quiz-favorite").textContent = state.favorites.has(song.id) ? "♥ 已收藏" : "♡ 加入收藏"; }
  function submitAnswer(answer) {
    if (state.quizStatus === "result") { nextQuestion(); return; }
    if (state.quizIndex >= state.quizQueue.length) return;
    const song = quizSong(); const normalized = value => String(value || "").normalize("NFKC").trim().toLocaleLowerCase();
    const correct = normalized(answer) === normalized(song.title);
    state.quizResults.push({ song, answer, correct, time: new Date().toLocaleTimeString("zh-TW", { hour: "2-digit", minute: "2-digit" }) });
    state.quizStatus = "result"; state.currentAnswer = answer;
    song.recent = "剛剛"; song.correct = correct;
    const previous = familiarityOf(song);
    state.familiarityOverrides.set(song.id, correct ? (previous === "new" ? "learning" : previous === "learning" ? "familiar" : "familiar") : "new");
    if (!correct) state.wrongSongIds.add(song.id);
    persistState(); renderQuiz(); renderCounts();
    if (!correct) toast("已加入錯題複習。");
  }
  function nextQuestion() {
    if (state.quizIndex + 1 >= state.quizQueue.length) { state.quizIndex = state.quizQueue.length; state.quizStatus = "complete"; renderQuiz(); toast("這輪練習完成。", ""); return; }
    state.quizIndex += 1; state.quizStatus = "answering"; state.currentAnswer = ""; setPlayerSong(quizSong()); renderQuiz();
  }
  function revealAnswer() { submitAnswer(""); }
  function markUnfamiliar() { const song = quizSong(); state.familiarityOverrides.set(song.id, "new"); persistState(); renderQuiz(); toast("已標記為不熟悉。"); }
  function renderHistory() {
    const results = state.quizResults.length ? state.quizResults.slice().reverse() : songs.filter(song => song.recent !== "尚未練習").slice(0, 8).map(song => ({ song, correct: song.correct, time: song.recent }));
    $("#history-total").innerHTML = `${126 + state.quizResults.length} <small>題</small>`;
    $("#history-review-count").innerHTML = `${String(songs.filter(song => familiarityOf(song) !== "familiar").length).padStart(2, "0")} <small>首</small>`;
    const filter = $("#history-filter").value;
    const filtered = results.filter(result => filter === "all" || (filter === "correct" ? result.correct : !result.correct));
    $("#history-list").innerHTML = filtered.map(result => `<div class="history-table-row"><div class="history-song">${cover(result.song)}<span class="row-copy"><strong>${escapeHtml(result.song.title)}</strong><small>${escapeHtml(result.song.work)}</small></span></div><span class="history-date">${escapeHtml(result.time || result.song.recent)}</span><span class="history-result ${result.correct ? "" : "wrong"}">${result.correct ? "✓ 答對" : "× 答錯"}</span><span class="history-familiarity">${familiarityLabel(familiarityOf(result.song))}</span><button class="history-row-open" data-song-open="${result.song.id}" aria-label="查看歌曲">↗</button></div>`).join("") || `<p class="muted">目前沒有符合條件的紀錄。</p>`;
  }
  function renderFullSongInfo() {
    const song = currentSong(); const familiarity = familiarityOf(song); const score = state.familiarityOverrides.has(song.id) ? (familiarity === "new" ? 0 : familiarity === "learning" ? 52 : 85) : song.score;
    $("#full-song-info").innerHTML = `<div class="full-info-cover ${song.color}"><img src="${escapeHtml(song.cover)}" alt="${escapeHtml(song.work)} 作品視覺"></div><div class="full-info-content"><p class="eyebrow">${song.source} · ${song.type} · ${song.year}</p><h2>${escapeHtml(song.title)}</h2><p class="work-name">${escapeHtml(song.work)} · ${escapeHtml(song.artist)}</p><div class="info-grid"><div class="info-cell"><span>熟悉度</span><strong>${familiarityLabel(familiarity)} · ${score}%</strong></div><div class="info-cell"><span>最近練習</span><strong>${escapeHtml(song.recent)}</strong></div><div class="info-cell"><span>歌曲類型</span><strong>${escapeHtml(song.type)}</strong></div><div class="info-cell"><span>收藏狀態</span><strong>${state.favorites.has(song.id) ? "已收藏" : "未收藏"}</strong></div></div><div class="full-info-actions"><button class="button button-primary" id="full-info-practice">練習這首歌 ↗</button><button class="button button-ghost" data-favorite-id="${song.id}">${state.favorites.has(song.id) ? "♥ 取消收藏" : "♡ 加入收藏"}</button><button class="button button-ghost" id="full-info-unfamiliar">標記不熟悉</button></div><div class="full-info-history"><h3>最近學習紀錄</h3><p>${song.recent === "尚未練習" ? "尚無練習紀錄。" : `${escapeHtml(song.recent)} · 最近一次${song.correct ? "答對" : "答錯"}。`}</p></div></div>`;
  }
  function updatePlayerProgress() { $("#player-current-time").textContent = `0:${String(state.playbackSeconds).padStart(2, "0")}`; $("#player-progress-fill").style.width = `${Math.min(100, state.playbackSeconds / 90 * 100)}%`; $("#player-play").textContent = state.isPlaying ? "Ⅱ" : "▶"; }
  function togglePlayer() {
    state.isPlaying = !state.isPlaying;
    if (state.playbackInterval) global.clearInterval(state.playbackInterval);
    state.playbackInterval = null;
    if (state.isPlaying) {
      toast("示範播放器尚未連接音訊。", "");
      state.playbackInterval = global.setInterval(() => { state.playbackSeconds = (state.playbackSeconds + 1) % 91; updatePlayerProgress(); if (state.playbackSeconds === 90) { state.isPlaying = false; global.clearInterval(state.playbackInterval); state.playbackInterval = null; updatePlayerProgress(); } }, 1000);
    }
    updatePlayerProgress();
    if (state.view === "quiz") { $("#audio-state").textContent = state.isPlaying ? "示範播放中" : "已暫停"; $("#audio-stage").classList.toggle("playing", state.isPlaying); }
  }
  function openShortcuts() {
    $("#modal-content").innerHTML = `<p class="eyebrow">KEYBOARD SHORTCUTS</p><h2 id="modal-title">快捷鍵</h2><p>這些快捷鍵只在此示範原型內生效。</p><div class="shortcut-list"><span>搜尋歌曲</span><kbd>Ctrl / ⌘ + K</kbd><span>選曲列表上下移動</span><kbd>↑ / ↓</kbd><span>查看選取歌曲</span><kbd>Enter</kbd><span>收藏 / 取消收藏</span><kbd>F</kbd><span>關閉彈窗 / 結束練習</span><kbd>Esc</kbd><span>提交答案 / 下一題</span><kbd>Enter</kbd></div>`;
    $("#modal-backdrop").hidden = false; $("#modal-close").focus();
  }
  function closeModal() { $("#modal-backdrop").hidden = true; }
  function navigateFromButton(button) {
    if (button.dataset.catalogTab) state.catalogTab = button.dataset.catalogTab;
    const nav = button.dataset.nav;
    if (nav) showView(nav);
  }
  function handleClick(event) {
    const target = event.target.closest("button, [data-song-open], .song-row, .favorite-tile, .recent-row"); if (!target) return;
    if (target.dataset.nav) { navigateFromButton(target); return; }
    if (target.dataset.catalogTab) { state.catalogTab = target.dataset.catalogTab; if (state.view !== "catalog") showView("catalog"); else renderCatalog(); return; }
    if (target.dataset.songOpen) { selectSong(target.dataset.songOpen, true); return; }
    if (target.dataset.favoriteId) { event.stopPropagation(); toggleFavorite(target.dataset.favoriteId); return; }
    if (target.dataset.playSong) { event.stopPropagation(); selectSong(target.dataset.playSong); return; }
    if (target.classList.contains("song-row")) { selectSong(target.dataset.songId); return; }
    if (target.id === "continue-practice") { continuePractice(); return; }
    if (target.id === "review-button") { startReviewPractice(); return; }
    if (target.id === "catalog-start") { showView("settings"); return; }
    if (target.id === "detail-practice" || target.id === "full-info-practice") { state.range = "all"; startPracticeWithSong(currentSong()); return; }
    if (target.id === "detail-full-info") { showView("song-info"); return; }
    if (target.id === "detail-open-history") { showView("history"); return; }
    if (target.id === "start-practice") { startPractice(); return; }
    if (target.id === "advanced-toggle") { const expanded = target.getAttribute("aria-expanded") === "true"; target.setAttribute("aria-expanded", String(!expanded)); $("#advanced-options").hidden = expanded; return; }
    if (target.id === "submit-answer") { return; }
    if (target.id === "reveal-answer") { revealAnswer(); return; }
    if (target.id === "skip-question") { submitAnswer(""); return; }
    if (target.id === "mark-unfamiliar") { markUnfamiliar(); return; }
    if (target.id === "full-info-unfamiliar") { state.familiarityOverrides.set(currentSong().id, "new"); persistState(); renderFullSongInfo(); toast("已標記為不熟悉。"); return; }
    if (target.id === "quiz-favorite" || target.id === "player-favorite") { toggleFavorite(state.view === "quiz" ? quizSong().id : currentSong().id); return; }
    if (target.id === "quit-practice") { state.isPlaying = false; showView("history"); return; }
    if (target.id === "quiz-settings-button") { showView("settings"); return; }
    if (target.id === "player-play") { togglePlayer(); return; }
    if (target.id === "player-prev" || target.id === "player-next") { const index = songs.findIndex(song => song.id === currentSong().id); selectSong(songs[(index + (target.id === "player-next" ? 1 : songs.length - 1)) % songs.length].id); return; }
    if (target.id === "volume-button" || target.id === "player-queue") { toast("此控制項為視覺原型，尚未連接真實音訊佇列或音量。"); return; }
    if (target.id === "global-search-button") { showView("catalog"); if (global.innerWidth <= 700) $("#filter-sidebar").classList.add("mobile-open"); $("#catalog-search").focus(); return; }
    if (target.id === "shortcuts-button") { openShortcuts(); return; }
    if (target.id === "modal-close" || target.id === "modal-backdrop") { closeModal(); return; }
    if (target.id === "clear-filters") { state.query = ""; state.sourceFilters = new Set(["AMQ", "EMQ"]); state.familiarityFilters.clear(); state.typeFilters.clear(); state.catalogTab = "all"; $("#catalog-search").value = ""; $$('[data-source-filter]').forEach(input => { input.checked = true; }); $$('[data-familiarity-filter]').forEach(input => { input.checked = false; }); $$('[data-type-filter]').forEach(input => { input.checked = false; }); renderCatalog(); return; }
    if (target.id === "open-filters") { $("#filter-sidebar").classList.add("mobile-open"); return; }
    if (target.id === "close-filters") { $("#filter-sidebar").classList.remove("mobile-open"); return; }
    if (target.dataset.resetFilter === "source") { state.sourceFilters = new Set(["AMQ", "EMQ"]); $$('[data-source-filter]').forEach(input => { input.checked = true; }); renderCatalog(); return; }
    if (target.dataset.resetFilter === "familiarity") { state.familiarityFilters.clear(); $$('[data-familiarity-filter]').forEach(input => { input.checked = false; }); renderCatalog(); return; }
  }
  function continuePractice() {
    if (state.quizQueue.length && state.quizIndex < state.quizQueue.length && state.quizStatus !== "complete") {
      state.selectedSongId = quizSong().id;
      showView("quiz"); renderQuiz(); toast("已接續上次尚未完成的練習。"); return;
    }
    state.mode = state.lastSession.mode; state.questionCount = state.lastSession.questionCount; state.range = state.lastSession.range;
    state.clipLength = state.lastSession.clipLength; state.showHints = state.lastSession.showHints; state.autoNext = state.lastSession.autoNext;
    renderSettings(); startPractice();
  }
  function startReviewPractice() {
    const wrongSongs = songs.filter(song => state.wrongSongIds.has(song.id));
    if (!wrongSongs.length) { state.range = "unfamiliar"; showView("settings"); renderSettings(); toast("沒有錯題，已切換至不熟悉歌曲。"); return; }
    const sources = new Set(wrongSongs.map(song => song.source));
    state.mode = sources.size > 1 ? "MIX" : wrongSongs[0].source;
    state.range = "all"; state.quizQueue = wrongSongs; state.quizIndex = 0; state.quizResults = []; state.quizStatus = "answering"; state.currentAnswer = "";
    state.lastSession = { mode: state.mode, questionCount: wrongSongs.length, range: "all", clipLength: state.clipLength, showHints: state.showHints, autoNext: state.autoNext };
    setPlayerSong(wrongSongs[0]); showView("quiz"); renderQuiz(); toast(`開始錯題複習，共 ${wrongSongs.length} 首。`);
  }
  function startPracticeWithSong(song) {
    state.selectedSongId = song.id; state.range = "all";
    state.quizQueue = [song]; state.quizIndex = 0; state.quizResults = []; state.quizStatus = "answering"; state.currentAnswer = "";
    setPlayerSong(song); showView("quiz"); renderQuiz();
  }
  function handleChange(event) {
    const target = event.target;
    if (target.matches("[data-source-filter]")) { target.checked ? state.sourceFilters.add(target.value) : state.sourceFilters.delete(target.value); renderCatalog(); return; }
    if (target.matches("[data-familiarity-filter]")) { target.checked ? state.familiarityFilters.add(target.value) : state.familiarityFilters.delete(target.value); renderCatalog(); return; }
    if (target.matches("[data-type-filter]")) { target.checked ? state.typeFilters.add(target.value) : state.typeFilters.delete(target.value); renderSettings(); return; }
    if (target.id === "catalog-sort") { state.sort = target.value; renderCatalog(); return; }
    if (target.name === "range") { state.range = target.value; renderSettings(); return; }
    if (target.id === "history-filter") { renderHistory(); return; }
    if (target.id === "clip-length") { state.clipLength = target.value; renderSettings(); return; }
    if (target.id === "show-hints") { state.showHints = target.checked; renderSettings(); return; }
    if (target.id === "auto-next") { state.autoNext = target.checked; renderSettings(); return; }
  }
  function handleInput(event) {
    if (event.target.id === "catalog-search") { state.query = event.target.value.trim(); renderCatalog(); const input = $("#catalog-search"); input.focus({ preventScroll: true }); input.setSelectionRange(input.value.length, input.value.length); }
    if (event.target.id === "answer-input") state.currentAnswer = event.target.value;
  }
  function handleSubmit(event) {
    if (event.target.id !== "answer-form") return;
    event.preventDefault(); if (state.quizStatus === "result") { nextQuestion(); return; }
    submitAnswer($("#answer-input").value);
  }
  function handleKeydown(event) {
    const typing = ["INPUT", "TEXTAREA", "SELECT"].includes(document.activeElement?.tagName);
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); showView("catalog"); $("#catalog-search").focus(); return; }
    if (event.key === "Escape") { if (!$("#modal-backdrop").hidden) { closeModal(); return; } if (state.view === "quiz") { state.isPlaying = false; showView("history"); return; } $("#filter-sidebar").classList.remove("mobile-open"); return; }
    if (state.view === "quiz" && event.key === "Enter" && !typing) { event.preventDefault(); if (state.quizStatus === "result") nextQuestion(); else $("#answer-input").focus(); return; }
    if (state.view === "catalog" && ["ArrowDown", "ArrowUp", "Enter", "f", "F"].includes(event.key) && !typing) {
      const list = visibleSongs(); if (!list.length) return; let index = list.findIndex(song => song.id === state.selectedSongId);
      if (event.key === "ArrowDown" || event.key === "ArrowUp") { event.preventDefault(); index = (index + (event.key === "ArrowDown" ? 1 : list.length - 1)) % list.length; selectSong(list[index].id); const row = $(`.song-row[data-song-id="${CSS.escape(list[index].id)}"]`); if (row) row.scrollIntoView({ block: "nearest" }); }
      else if (event.key === "Enter") { event.preventDefault(); showView("song-info"); }
      else if (event.key.toLowerCase() === "f") { event.preventDefault(); toggleFavorite(state.selectedSongId); }
    }
  }
  function boot() {
    restoreState();
    document.addEventListener("click", handleClick); document.addEventListener("change", handleChange); document.addEventListener("input", handleInput); document.addEventListener("submit", handleSubmit); document.addEventListener("keydown", handleKeydown);
    $$("[data-mode]").forEach(button => button.addEventListener("click", () => { state.mode = button.dataset.mode; renderSettings(); }));
    $$("[data-question-count]").forEach(button => button.addEventListener("click", () => { state.questionCount = Number(button.dataset.questionCount); renderSettings(); }));
    $("#modal-backdrop").addEventListener("click", event => { if (event.target.id === "modal-backdrop") closeModal(); });
    renderHome(); renderCounts(); renderPlayer(); renderSettings();
    const params = new URLSearchParams(location.search);
    if (params.has("view") && ["home", "catalog", "settings", "quiz", "history", "song-info"].includes(params.get("view"))) showView(params.get("view"));
    if (params.has("selftest")) runSelfTest();
    global.AMQPrototype = Object.freeze({ state, songs, showView, visibleSongs, startPractice, continuePractice, startReviewPractice, toggleFavorite, selectSong, submitAnswer, nextQuestion, renderCatalog, renderSettings, renderHistory, renderFullSongInfo, runSelfTest });
  }
  function runSelfTest() {
    const report = [];
    const check = (name, condition) => report.push({ name, passed: Boolean(condition) });
    try {
      showView("catalog"); $("#catalog-search").value = "廻廻奇譚"; state.query = "廻廻奇譚"; renderCatalog(); check("search finds song title", visibleSongs().length === 1 && visibleSongs()[0].id === "a01");
      state.query = ""; $("#catalog-search").value = ""; state.catalogTab = "all"; renderCatalog();
      const before = state.favorites.has("a02"); toggleFavorite("a02"); check("favorite toggle changes state", state.favorites.has("a02") !== before); toggleFavorite("a02");
      state.mode = "EMQ"; renderSettings(); check("mode switching updates selection", $("[data-mode=EMQ]").getAttribute("aria-checked") === "true"); state.mode = "AMQ";
      $("#advanced-toggle").click(); check("advanced settings expand", !$("#advanced-options").hidden); $("#advanced-toggle").click(); check("advanced settings collapse", $("#advanced-options").hidden);
      state.range = "all"; state.questionCount = 10; renderSettings(); startPractice(); check("practice starts with question queue", state.view === "quiz" && state.quizQueue.length === 10);
      submitAnswer(quizSong().title); check("answer submission shows correct result", state.quizStatus === "result" && state.quizResults[0].correct);
      nextQuestion(); check("next question advances queue", state.quizIndex === 1 && state.quizStatus === "answering");
      state.quizQueue = []; state.quizIndex = 0; state.quizResults = []; state.quizStatus = "idle"; state.query = ""; state.catalogTab = "all"; showView("home");
    } catch (error) { report.push({ name: `unexpected error: ${error.message}`, passed: false }); }
    const passed = report.filter(item => item.passed).length;
    document.body.insertAdjacentHTML("beforeend", `<pre id="selftest-report" style="position:fixed;z-index:999;right:8px;bottom:76px;max-width:500px;max-height:50vh;overflow:auto;padding:12px;background:#0c0d11;color:#fff;border:1px solid #56d8c7;font:12px/1.6 monospace">UI SELFTEST ${passed}/${report.length} PASS\n${report.map(item => `${item.passed ? "PASS" : "FAIL"} ${escapeHtml(item.name)}`).join("\n")}</pre>`);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot, { once: true }); else boot();
})(window);
