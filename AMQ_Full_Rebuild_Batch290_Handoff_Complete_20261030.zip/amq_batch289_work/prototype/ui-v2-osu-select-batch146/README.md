# AMQ Song Select Prototype v2 · Batch146

## 目標

這是獨立的 UI 視覺方向候選版，根據使用者確認的方向，將 osu!stable Song Select 作為主要參考：高密度曲目列表、清楚的選取狀態、左側分類與搜尋、右側目前歌曲資訊、底部播放列、快速鍵與少量粉色強調。它不是 osu! 的像素複製，也不是正式產品 UI。

## 開啟

以瀏覽器開啟 `index.html`。若瀏覽器限制本機資源，從此資料夾啟動靜態伺服器：

```bash
python -m http.server 8000
```

然後開啟本機伺服器的根路徑。原型只使用 HTML/CSS/JavaScript 與 mock data，不需要 npm install。

## 目錄

- `index.html`：六個視圖與可操作 UI。
- `styles/tokens.css`：基礎 token。
- `styles/layout.css`：原型布局。
- `styles/components.css`：原型元件。
- `styles/osu-select.css`：本批視覺方向調整，壓低卡片、漸層與圓角，選曲頁改為密集列表和固定資訊面板。
- `scripts/mock-data.js`：15 首示範歌曲，不是正式曲庫；每首有獨立 `cover` 路徑。
- `assets/covers/`：15 張本專案原創 SVG 動畫風示意封面，具備場景、角色剪影、光源與作品識別文字；不是對應作品的官方封面，也不是從 Skin 中抽取的素材。正式接入前應替換為有合法使用依據的作品封面或動畫。
- `scripts/app.js`：搜尋、收藏、篩選、排序、模式、設定、答題、錯題複習與歷史互動。
- `tests/browser-smoke.py`：Playwright／Chromium smoke tests。
- `artifacts/`：本批執行測試後產生的截圖。

## 設計決策

- 選曲是主畫面：左側篩選、中央曲目列表、右側選取歌曲資料，底部播放控制。
- 桌面保持資訊密度與直接操作；1024px 以下隱藏右側詳情，900px 以下改成單欄與篩選抽屜。
- 不使用大面積漸層、玻璃效果、裝飾性數據卡與大量圓角。
- 保留原型已有互動與測試選擇器，減少視覺改版造成的行為回歸。
- 非選曲畫面目前只做扁平化與減少裝飾，尚未逐頁重新設計，應先驗收選曲主方向再延伸。

## 驗證

執行：

```bash
python tests/browser-smoke.py
```

Batch147 執行結果：45/45 PASS，無未捕捉的瀏覽器例外；額外驗證前五首歌曲列表封面與選中歌曲資訊封面均成功載入；覆蓋 1440×900、1024×768、390×844 無頁面層級溢位。截圖是 Chromium 渲染證據，非像素比對驗收。

## 尚未完成

- 1920×1080 選曲截圖已更新；仍需人工確認畫面是否符合使用者的 osu!stable 參考預期。
- Batch147 修正測試方式：在受限環境中以 data URI 內嵌本地 SVG，避免原本的 `set_content()` 導致相對路徑封面破圖。15 張原創 SVG 示意封面已在選取／懸停時提供輕量動效。它們不是對應動畫的官方封面，也不代表已接入真實曲庫圖片。
- 原型沒有接正式 `src/`、Catalog、AudioService、QuizSession、SRS、persistence 或多人服務。
- 本機直接開啟 `file://` 的實機驗收仍受先前測試環境限制；需在一般使用者瀏覽器確認相對資源載入。
