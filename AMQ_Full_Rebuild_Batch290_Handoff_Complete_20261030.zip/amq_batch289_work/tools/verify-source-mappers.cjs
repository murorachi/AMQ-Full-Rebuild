#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const zlib = require('node:zlib');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const [amqPath, emqPath] = process.argv.slice(2);
if (!amqPath || !emqPath) {
  console.error('Usage: node tools/verify-source-mappers.cjs <data.js> <emq-data.js>');
  process.exit(2);
}
function parseAMQ(file) {
  const context = { window: {} };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(file, 'utf8'), context, { timeout: 10000, filename: path.basename(file) });
  const db = context.window.DB;
  if (!db || !Array.isArray(db.anime) || !Array.isArray(db.songs)) throw new Error('AMQ DB schema invalid');
  return db;
}
function parseEMQ(file) {
  const text = fs.readFileSync(file, 'utf8');
  const match = text.match(/window\.__EMQ_PACKED_B64\s*=\s*"([^"]+)"/);
  if (!match) throw new Error('EMQ packed payload missing');
  const payload = JSON.parse(zlib.gunzipSync(Buffer.from(match[1], 'base64')).toString('utf8'));
  if (!Array.isArray(payload.works) || !Array.isArray(payload.songs)) throw new Error('EMQ payload schema invalid');
  return payload;
}
function loadModule(file, context) { vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file }); }
const context = { window: {} };
vm.createContext(context);
loadModule('src/data/identity.js', context);
loadModule('src/data/audio-candidates.js', context);
loadModule('src/data/source-mappers.js', context);
loadModule('src/data/validate.js', context);
loadModule('src/data/query-index.js', context);
const mappers = context.window.AMQData.sourceMappers;
const validator = context.window.AMQData.validateRecords;
try {
  const amq = parseAMQ(amqPath);
  const mapAMQ = mappers.createAMQSongMapper(amq.anime);
  const amqRecords = amq.songs.map(mapAMQ);
  const amqValidation = validator(amqRecords);
  if (amqValidation.status !== 'loaded' || amqValidation.validCount !== amq.songs.length) throw new Error(`AMQ canonical validation: ${amqValidation.status}, valid=${amqValidation.validCount}, rejected=${amqValidation.rejectedCount}`);
  const emq = parseEMQ(emqPath);
  const mapEMQ = mappers.createEMQSongMapper(emq.works);
  const emqRecords = emq.songs.map(mapEMQ);
  const emqValidation = validator(emqRecords);
  if (emqValidation.status !== 'loaded' || emqValidation.validCount !== emq.songs.length) throw new Error(`EMQ canonical validation: ${emqValidation.status}, valid=${emqValidation.validCount}, rejected=${emqValidation.rejectedCount}`);
  const catalog = context.window.AMQData.queryIndex.createCatalog([...amqValidation.records, ...emqValidation.records]);
  const amqProbe = catalog.search({ source: 'AMQ', query: amqValidation.records[0].title, limit: 1 });
  const emqProbe = catalog.search({ source: 'EMQ', query: emqValidation.records[0].title, limit: 1 });
  if (amqProbe.total < 1 || emqProbe.total < 1 || amqProbe.records[0].source !== 'AMQ' || emqProbe.records[0].source !== 'EMQ') throw new Error('catalog real-data search probe failed');
  const sourceGroups = catalog.groupBy('source');
  const typeGroups = catalog.groupBy('type');
  const kindGroups = catalog.groupBy('workKind');
  const sourceCounts = Object.fromEntries(sourceGroups.groups.map(group => [group.value, group.count]));
  if (sourceGroups.total !== catalog.size || sourceGroups.groups.reduce((sum, group) => sum + group.count, 0) !== catalog.size) throw new Error('catalog source group counts do not reconcile');
  if (sourceCounts.AMQ !== amqValidation.validCount || sourceCounts.EMQ !== emqValidation.validCount) throw new Error(`catalog source group counts mismatch: ${JSON.stringify(sourceCounts)}`);
  for (const [field, groups] of [['type', typeGroups], ['workKind', kindGroups]]) {
    if (groups.groups.reduce((sum, group) => sum + group.count, 0) > groups.total) throw new Error(`catalog ${field} group count exceeds matching total`);
  }
  const sortedPage = catalog.search({ source: 'AMQ', sortBy: 'title', sortDirection: 'asc', offset: 10, limit: 20 });
  if (sortedPage.total !== amqValidation.validCount || sortedPage.records.length !== 20) throw new Error('catalog real-data sort/pagination probe failed');
  const pageTitles = sortedPage.records.map(record => context.window.AMQData.queryIndex.normalizeText(record.title));
  if (pageTitles.some((title, i) => i > 0 && title < pageTitles[i - 1])) throw new Error('catalog real-data title sorting probe failed');
  const audioStats = records => ({
    songsWithCandidates: records.filter(record => record.audioCandidates.length > 0).length,
    totalCandidates: records.reduce((sum, record) => sum + record.audioCandidates.length, 0),
    songsWithoutCandidates: records.filter(record => record.audioCandidates.length === 0).length
  });
  console.log(JSON.stringify({ status:'PASS', scope:'supplied Library files / Stage I evidenced mapping, rebuilt catalog search, grouping, sorting and candidate construction only; not Candidate302 compatibility or audio playability', amq:{works:amq.anime.length,songs:amq.songs.length,mapped:amqRecords.length,validation:amqValidation.status,queryProbe:amqProbe.total,audioCandidates:audioStats(amqValidation.records)}, emq:{works:emq.works.length,songs:emq.songs.length,mapped:emqRecords.length,validation:emqValidation.status,queryProbe:emqProbe.total,version:emq.version,createdAt:emq.createdAt||null,audioCandidates:audioStats(emqValidation.records)}, catalog:{size:catalog.size,records:amqValidation.records.length+emqValidation.records.length,sourceCounts,typeGroups:typeGroups.groups,workKindGroups:kindGroups.groups,sortedPage:{total:sortedPage.total,offset:sortedPage.offset,limit:sortedPage.limit}} }, null, 2));
} catch (error) {
  console.error(`SOURCE MAPPER VERIFICATION FAIL: ${error.stack || error.message}`);
  process.exit(1);
}
