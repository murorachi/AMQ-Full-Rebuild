'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const { inspectDatabase } = require('../server/database-integrity.cjs');

function main(argv) {
  if (argv.length !== 1 || !argv[0]) throw new Error('Usage: node tools/verify-private-server-backup.cjs <backup.sqlite>');
  const filename = path.resolve(argv[0]);
  if (!fs.existsSync(filename) || !fs.statSync(filename).isFile()) throw new Error('Backup file does not exist.');
  const db = new DatabaseSync(filename, { readOnly: true });
  let inspection;
  try { inspection = inspectDatabase(db); }
  finally { db.close(); }
  console.log(JSON.stringify({ status: 'PASS', file: filename, bytes: fs.statSync(filename).size,
    sha256: crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex'), integrity: inspection.integrity, foreignKeyErrors: inspection.foreignKeyErrors, tables: inspection.tables, missingOptionalTables: inspection.missingOptionalTables, tableCounts: inspection.tableCounts }, null, 2));
}

try { main(process.argv.slice(2)); }
catch (error) { console.error(`Backup verification failed: ${error && error.message ? error.message : 'unknown error'}`); process.exitCode = 1; }
