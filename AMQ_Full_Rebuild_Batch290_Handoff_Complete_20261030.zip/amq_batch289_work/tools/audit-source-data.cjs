#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const path = require('node:path');

function fail(message) {
  console.error(`SOURCE AUDIT FAIL: ${message}`);
  process.exit(1);
}
function sha256(buffer) { return crypto.createHash('sha256').update(buffer).digest('hex'); }
function readFile(file) {
  try { return fs.readFileSync(path.resolve(file)); }
  catch (error) { fail(`cannot read ${file}: ${error.message}`); }
}
function parseAssignedJson(source, marker, label) {
  const start = source.indexOf(marker);
  if (start < 0) fail(`${label}: assignment marker not found`);
  let cursor = start + marker.length;
  while (/\s/.test(source[cursor] || '')) cursor += 1;
  if (source[cursor] !== '{') fail(`${label}: expected JSON object after assignment`);
  const objectStart = cursor;
  let depth = 0;
  let inString = false;
  let escaped = false;
  for (; cursor < source.length; cursor += 1) {
    const ch = source[cursor];
    if (inString) {
      if (escaped) escaped = false;
      else if (ch === '\\') escaped = true;
      else if (ch === '"') inString = false;
      continue;
    }
    if (ch === '"') inString = true;
    else if (ch === '{' || ch === '[') depth += 1;
    else if (ch === '}' || ch === ']') {
      depth -= 1;
      if (depth === 0) {
        try { return JSON.parse(source.slice(objectStart, cursor + 1)); }
        catch (error) { fail(`${label}: JSON parse failed: ${error.message}`); }
      }
    }
  }
  fail(`${label}: unterminated JSON value`);
}
function uniquePositiveIntegerIds(rows, getId, label) {
  const ids = new Set();
  let duplicates = 0;
  let invalid = 0;
  for (const row of rows) {
    const id = getId(row);
    if (!Number.isSafeInteger(id) || id <= 0) { invalid += 1; continue; }
    if (ids.has(id)) duplicates += 1;
    ids.add(id);
  }
  if (invalid || duplicates) fail(`${label}: ${invalid} invalid IDs, ${duplicates} duplicate IDs`);
  return ids;
}
function assertArrayRows(rows, length, label) {
  if (!Array.isArray(rows)) fail(`${label}: expected array`);
  const wrong = rows.reduce((count, row) => count + (Array.isArray(row) && row.length === length ? 0 : 1), 0);
  if (wrong) fail(`${label}: ${wrong} rows do not have expected length ${length}`);
}

const [amqPath, emqPath] = process.argv.slice(2);
if (!amqPath || !emqPath) {
  console.error('Usage: node tools/audit-source-data.cjs <data.js> <emq-data.js>');
  process.exit(2);
}
const amqBuffer = readFile(amqPath);
const emqBuffer = readFile(emqPath);
const amqSource = amqBuffer.toString('utf8');
const emqSource = emqBuffer.toString('utf8');
const amq = parseAssignedJson(amqSource, 'window.DB=', 'AMQ data.js');
if (!Array.isArray(amq.anime) || !Array.isArray(amq.songs)) fail('AMQ DB must contain anime and songs arrays');
assertArrayRows(amq.anime, 7, 'AMQ anime');
assertArrayRows(amq.songs, 12, 'AMQ songs');
const amqWorkIds = uniquePositiveIntegerIds(amq.anime, row => row[0], 'AMQ work IDs');
const amqSongIds = uniquePositiveIntegerIds(amq.songs, row => row[1], 'AMQ song IDs');
const amqDanglingWorks = amq.songs.filter(row => !amqWorkIds.has(row[0])).length;
if (amqDanglingWorks) fail(`AMQ songs contain ${amqDanglingWorks} dangling work references`);

const packedMatch = emqSource.match(/window\.__EMQ_PACKED_B64\s*=\s*"([^"]+)"/);
if (!packedMatch) fail('EMQ packed gzip base64 assignment not found');
let emq;
try { emq = JSON.parse(zlib.gunzipSync(Buffer.from(packedMatch[1], 'base64')).toString('utf8')); }
catch (error) { fail(`EMQ gzip/JSON decode failed: ${error.message}`); }
if (emq.version !== 1 || !Array.isArray(emq.songs) || !Array.isArray(emq.works)) fail('EMQ payload must have version 1, songs array, and works array');
const emqWorkIds = uniquePositiveIntegerIds(emq.works, row => row && row.i, 'EMQ work IDs');
const emqSongIds = uniquePositiveIntegerIds(emq.songs, row => row && row.i, 'EMQ song IDs');
const emqDanglingWorks = emq.songs.filter(row => !emqWorkIds.has(row && row.w)).length;
if (emqDanglingWorks) fail(`EMQ songs contain ${emqDanglingWorks} dangling work references`);
const crossWorkCollisions = [...amqWorkIds].filter(id => emqWorkIds.has(id));
const crossSongCollisions = [...amqSongIds].filter(id => emqSongIds.has(id));
if (crossWorkCollisions.length || crossSongCollisions.length) fail(`cross-source ID collisions: ${crossWorkCollisions.length} work, ${crossSongCollisions.length} song`);

const amqAudioNonEmpty = [9, 10, 11].map(index => ({
  column: index,
  nonEmpty: amq.songs.filter(row => typeof row[index] === 'string' && row[index].trim() !== '').length
}));
const emqAudioCandidateCount = emq.songs.filter(row => Array.isArray(row.v) && row.v.length > 0 && row.v.every(url => typeof url === 'string' && /^https:\/\//i.test(url))).length;
const emqTitleArtistCount = emq.songs.filter(row => typeof row.t === 'string' && row.t.trim() && typeof row.a === 'string' && row.a.trim()).length;
const result = {
  generatedAt: new Date().toISOString(),
  warning: 'This report audits the supplied source files only; it does not prove they are the exact selected reference companion assets or that audio URLs are playable.',
  amq: {
    file: path.basename(amqPath), bytes: amqBuffer.length, sha256: sha256(amqBuffer),
    topLevelKeys: Object.keys(amq), animeCount: amq.anime.length, songCount: amq.songs.length,
    animeRowLength: 7, songRowLength: 12,
    duplicateAnimeIds: 0, duplicateSongIds: 0, danglingSongWorkReferences: amqDanglingWorks,
    audioNonEmptyByColumn: amqAudioNonEmpty
  },
  emq: {
    file: path.basename(emqPath), bytes: emqBuffer.length, sha256: sha256(emqBuffer),
    payloadBytes: zlib.gunzipSync(Buffer.from(packedMatch[1], 'base64')).length,
    version: emq.version, createdAt: emq.createdAt || null, sourceLabel: emq.source || null,
    topLevelKeys: Object.keys(emq), workCount: emq.works.length, songCount: emq.songs.length,
    workFields: [...new Set(emq.works.flatMap(row => Object.keys(row)))].sort(),
    songFields: [...new Set(emq.songs.flatMap(row => Object.keys(row)))].sort(),
    duplicateWorkIds: 0, duplicateSongIds: 0, danglingSongWorkReferences: emqDanglingWorks,
    songsWithHttpsAudioCandidates: emqAudioCandidateCount, songsWithNonEmptyTitleAndArtist: emqTitleArtistCount
  },
  crossSource: { workIdCollisions: crossWorkCollisions.length, songIdCollisions: crossSongCollisions.length }
};
console.log(JSON.stringify(result, null, 2));
