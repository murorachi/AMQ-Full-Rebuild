#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const vm = require('node:vm');
const zlib = require('node:zlib');
const path = require('node:path');
const { performance } = require('node:perf_hooks');
const root = path.resolve(__dirname, '..');
const [amqPath, emqPath, rawIterations] = process.argv.slice(2);
if (!amqPath || !emqPath) {
  console.error('Usage: node tools/benchmark-catalog.cjs <data.js> <emq-data.js> [iterations=30]');
  process.exit(2);
}
const iterations = rawIterations === undefined ? 30 : Number(rawIterations);
if (!Number.isSafeInteger(iterations) || iterations < 5 || iterations > 500) {
  console.error('iterations must be an integer between 5 and 500');
  process.exit(2);
}
function parseAMQ(file) {
  const context = { window: {} };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(file, 'utf8'), context, { timeout: 10000, filename: path.basename(file) });
  const db = context.window.DB;
  if (!db || !Array.isArray(db.anime) || !Array.isArray(db.songs)) throw new Error('AMQ DB schema invalid');
  return db;
}
function parseEMQ(file) {
  const text = fs.readFileSync(file, 'utf8');
  const match = text.match(/window\.__EMQ_PACKED_B64\s*=\s*"([^"]+)"/);
  if (!match) throw new Error('EMQ packed payload missing');
  const payload = JSON.parse(zlib.gunzipSync(Buffer.from(match[1], 'base64')).toString('utf8'));
  if (!Array.isArray(payload.works) || !Array.isArray(payload.songs)) throw new Error('EMQ payload schema invalid');
  return payload;
}
function loadModule(file, context) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), context, { filename: file });
}
function percentile(sorted, p) {
  return sorted[Math.min(sorted.length - 1, Math.ceil(p * sorted.length) - 1)];
}
function summarize(samples) {
  const sorted = samples.slice().sort((a, b) => a - b);
  return {
    samples: samples.length,
    minMs: Number(sorted[0].toFixed(3)),
    p50Ms: Number(percentile(sorted, 0.50).toFixed(3)),
    p95Ms: Number(percentile(sorted, 0.95).toFixed(3)),
    maxMs: Number(sorted[sorted.length - 1].toFixed(3)),
    meanMs: Number((samples.reduce((sum, value) => sum + value, 0) / samples.length).toFixed(3))
  };
}
function groupCounts(records, field) {
  const counts = {};
  for (const record of records) {
    const key = record[field] == null || record[field] === '' ? '(empty)' : String(record[field]);
    counts[key] = (counts[key] || 0) + 1;
  }
  return Object.fromEntries(Object.entries(counts).sort((a, b) => a[0].localeCompare(b[0], 'en')));
}
function firstText(records, field) {
  const found = records.find(record => typeof record[field] === 'string' && record[field].trim());
  return found ? found[field].trim().slice(0, 24) : null;
}
try {
  const context = { window: {} };
  vm.createContext(context);
  loadModule('src/data/identity.js', context);
loadModule('src/data/audio-candidates.js', context);
loadModule('src/data/source-mappers.js', context);
  loadModule('src/data/validate.js', context);
  loadModule('src/data/query-index.js', context);
  const { sourceMappers, validateRecords, queryIndex } = context.window.AMQData;
  const amq = parseAMQ(amqPath);
  const emq = parseEMQ(emqPath);
  const amqMapped = amq.songs.map(sourceMappers.createAMQSongMapper(amq.anime));
  const emqMapped = emq.songs.map(sourceMappers.createEMQSongMapper(emq.works));
  const amqValidated = validateRecords(amqMapped);
  const emqValidated = validateRecords(emqMapped);
  if (amqValidated.status !== 'loaded' || emqValidated.status !== 'loaded') throw new Error('source validation failed; benchmark aborted');
  const records = [...amqValidated.records, ...emqValidated.records];
  const buildStart = performance.now();
  const catalog = queryIndex.createCatalog(records);
  const buildMs = performance.now() - buildStart;
  const amqRecord = amqValidated.records[0];
  const emqRecord = emqValidated.records[0];
  const cases = [
    { name: 'title_substring', criteria: { query: amqRecord.title.slice(0, Math.min(8, amqRecord.title.length)), limit: 100 } },
    { name: 'artist_substring', criteria: { query: firstText(records, 'artist') || 'a', limit: 100 } },
    { name: 'work_title_substring', criteria: { query: firstText(records, 'animeTitle') || 'a', limit: 100 } },
    { name: 'source_type_filter', criteria: { source: 'AMQ', type: amqRecord.type, limit: 100 } },
    { name: 'combined_filter', criteria: { source: 'EMQ', workKind: emqRecord.workKind, animeId: emqRecord.animeId, limit: 100 } },
    { name: 'empty_query_first_page', criteria: { limit: 100 } }
  ];
  const benchmarkResults = cases.map(testCase => {
    const warmup = catalog.search(testCase.criteria);
    if (warmup.total < 1 && !testCase.name.includes('empty_query')) throw new Error(`benchmark probe returned no results: ${testCase.name}`);
    const samples = [];
    let total = warmup.total;
    for (let i = 0; i < iterations; i++) {
      const start = performance.now();
      const result = catalog.search(testCase.criteria);
      samples.push(performance.now() - start);
      total = result.total;
    }
    return { name: testCase.name, criteria: testCase.criteria, matchedTotal: total, timing: summarize(samples) };
  });
  const groupCases = [
    { name: 'group_by_source', field: 'source', criteria: {} },
    { name: 'group_by_type_with_source_filter', field: 'type', criteria: { source: 'AMQ' } }
  ];
  const groupingResults = groupCases.map(testCase => {
    const warmup = catalog.groupBy(testCase.field, testCase.criteria);
    const samples = [];
    let groups = warmup.groups;
    for (let i = 0; i < iterations; i++) {
      const start = performance.now();
      const result = catalog.groupBy(testCase.field, testCase.criteria);
      samples.push(performance.now() - start);
      groups = result.groups;
    }
    return { name: testCase.name, field: testCase.field, criteria: testCase.criteria, matchedTotal: warmup.total, groupCount: groups.length, timing: summarize(samples) };
  });
  const report = {
    status: 'PASS',
    generatedAt: new Date().toISOString(),
    scope: 'Local Node process, current supplied Library files, current Stage I-evidenced mappers and in-memory catalog; not browser latency, not Candidate302 compatibility, not audio playback.',
    runtime: { node: process.version, platform: process.platform, arch: process.arch },
    sources: {
      AMQ: { works: amq.anime.length, songs: amq.songs.length, mapped: amqValidated.validCount, status: amqValidated.status },
      EMQ: { works: emq.works.length, songs: emq.songs.length, mapped: emqValidated.validCount, status: emqValidated.status, version: emq.version, createdAt: emq.createdAt || null }
    },
    catalog: {
      records: catalog.size,
      buildMs: Number(buildMs.toFixed(3)),
      bySource: groupCounts(records, 'source'),
      bySongType: groupCounts(records, 'type'),
      byWorkKind: groupCounts(records, 'workKind')
    },
    benchmark: { iterations, warmupRunsPerCase: 1, cases: benchmarkResults, groupingCases: groupingResults },
    caveats: [
      'Timing is an observational baseline for this runtime and machine, not a performance guarantee or pass threshold.',
      'Each search and grouping call currently scans the in-memory snapshot; no inverted index or fuzzy search is implemented.',
      'Catalog build timing excludes source file read, decompression, mapping, and validation.',
      'Source compatibility and browser behavior remain unverified.'
    ]
  };
  process.stdout.write(JSON.stringify(report, null, 2) + '\n');
} catch (error) {
  console.error(`CATALOG BENCHMARK FAIL: ${error.stack || error.message}`);
  process.exit(1);
}
