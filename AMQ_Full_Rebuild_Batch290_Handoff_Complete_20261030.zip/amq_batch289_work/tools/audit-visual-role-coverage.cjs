#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const outputArg = process.argv.findIndex(arg => arg === '--output-dir');
const outputDir = outputArg >= 0 && process.argv[outputArg + 1]
  ? path.resolve(process.argv[outputArg + 1])
  : path.join(root, 'artifacts/batch245-regression');
const read = p => fs.readFileSync(path.join(root, p), 'utf8');
const rolesDoc = JSON.parse(read('docs/skin-contract/amq-skin-role-manifest.v1.json'));
const needsDoc = JSON.parse(read('docs/skin-contract/amq-visual-needs.v1.json'));
const adapter = read('src/skins/theme-adapter.js');
const css = fs.readdirSync(path.join(root, 'src/styles'), { recursive: true }).filter(name => String(name).endsWith('.css')).map(name => fs.readFileSync(path.join(root, 'src/styles', name), 'utf8')).join('\n') + '\n' + read('src/styles.css');
const html = read('src/index.html');
const tests = fs.readdirSync(path.join(root, 'tests')).filter(name => /(?:skin|visual|osk|mapping|catalog|home).*\.(?:test\.cjs|browser\.test\.py)$/.test(name));
const testText = tests.map(name => read(`tests/${name}`)).join('\n');
const runtime = new Map();
for (const m of adapter.matchAll(/^\s*"([^"]+)": \{ selector: ("(?:\\.|[^"])*"|'(?:\\.|[^'])*'), token: "([^"]+)" \}/gm)) { const selector = m[2].startsWith("\"") ? JSON.parse(m[2]) : m[2].slice(1, -1); runtime.set(m[1], { selector, token: m[3] }); }
const needsByRole = new Map();
for (const need of needsDoc.needs) for (const id of need.roleIds) {
  if (!needsByRole.has(id)) needsByRole.set(id, []);
  needsByRole.get(id).push(need);
}
function selectorEvidence(selector) {
  if (!selector) return { declared: false, htmlLiteral: false, cssLiteral: false };
  const id = selector.match(/#([\w-]+)/)?.[1];
  const cls = selector.match(/\.([\w-]+)/)?.[1];
  const htmlLiteral = Boolean((id && new RegExp(`id=["']${id}["']`).test(html)) || (cls && new RegExp(`class=["'][^"']*\\b${cls}\\b`).test(html)));
  const cssLiteral = css.includes(selector) || Boolean((id && css.includes(`#${id}`)) || (cls && css.includes(`.${cls}`)));
  return { declared: true, htmlLiteral, cssLiteral };
}
const rows = rolesDoc.roles.map(role => {
  const r = runtime.get(role.id);
  const needs = needsByRole.get(role.id) || [];
  const ev = selectorEvidence(r?.selector);
  const tokenConsumer = Boolean(r && css.includes(r.token));
  const hasFallback = typeof role.fallback === 'string' && role.fallback.trim().length > 0;
  const hasResetMechanism = /function reset\s*\(/.test(adapter) && /restoreInlineOverrides\(\)/.test(adapter) && /revokeActive\(\)/.test(adapter);
  const evidence = tests.filter(name => testText.includes(role.id) || (r && testText.includes(r.token)));
  const gaps = [];
  if (!r) gaps.push('runtime selector 未接線');
  else {
    if (!ev.htmlLiteral) gaps.push('selector 未在 HTML 靜態標記中找到（可能由 JS 動態建立，需 browser evidence）');
    if (!tokenConsumer) gaps.push('CSS token consumer 未找到');
  }
  if (!hasFallback) gaps.push('缺少明確 fallback');
  if (!hasResetMechanism) gaps.push('adapter reset/restore/revoke 機制未找到');
  if (!evidence.length) gaps.push('未找到直接引用此 role/token 的測試證據');
  const supported = Boolean(r && tokenConsumer && hasFallback && hasResetMechanism && evidence.length);
  return { id: role.id, page: role.page, label: role.label, required: role.required, visualNeeds: needs.map(n => n.id), selector: r?.selector || null, token: r?.token || null, selectorEvidence: ev, tokenConsumer, fallback: role.fallback, resetMechanism: hasResetMechanism, testEvidence: evidence, status: supported ? 'runtime-wired-needs-browser-confirmation' : (r ? 'partial-or-unverified' : 'unsupported'), gaps };
});
const summary = { schemaVersion: 1, generatedAt: new Date().toISOString(), roles: rows.length, wired: rows.filter(r => r.selector).length, unsupported: rows.filter(r => !r.selector).length, withCssConsumer: rows.filter(r => r.tokenConsumer).length, withTestEvidence: rows.filter(r => r.testEvidence.length).length, rolesWithGaps: rows.filter(r => r.gaps.length).length, rows };
const outJson = path.join(outputDir, 'visual-role-audit.json');
const outMd = path.join(outputDir, 'visual-role-audit.md');
fs.mkdirSync(path.dirname(outJson), { recursive: true });
fs.writeFileSync(outJson, JSON.stringify(summary, null, 2) + '\n');
const lines = ['# Batch245 Visual-role 自動稽核', '', `- Roles: ${summary.roles}`, `- Runtime selector wired: ${summary.wired}`, `- Unsupported: ${summary.unsupported}`, `- CSS token consumer found: ${summary.withCssConsumer}`, `- Direct test evidence found: ${summary.withTestEvidence}`, `- Roles with one or more gaps: ${summary.rolesWithGaps}`, '', '> Static audit is a triage aid, not proof of browser behavior. HTML literal absence can mean a dynamic target and requires browser evidence.', '', '| Role | Status | Selector | CSS consumer | Test evidence | Gaps |', '|---|---|---|---|---|---|'];
for (const r of rows) lines.push(`| ${r.id} | ${r.status} | ${r.selector || '—'} | ${r.tokenConsumer ? 'yes' : 'no'} | ${r.testEvidence.join(', ') || '—'} | ${r.gaps.join('; ').replace(/\|/g, '\\|') || '—'} |`);
fs.writeFileSync(outMd, lines.join('\n') + '\n');
console.log(JSON.stringify({ ...summary, rows: undefined, json: path.relative(root, outJson), markdown: path.relative(root, outMd) }, null, 2));
if (rows.some(r => !r.fallback)) process.exitCode = 1;
