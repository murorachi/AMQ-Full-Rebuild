'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');
const { inspectDatabase } = require('../server/database-integrity.cjs');

function fail(message) { throw new Error(message); }
function quoteSqlString(value) { return `'${String(value).replace(/'/g, "''")}'`; }
function inspectDatabaseFile(filename) {
  const db = new DatabaseSync(filename, { readOnly: true });
  try { return inspectDatabase(db); }
  finally { db.close(); }
}

function main(argv) {
  const [sourceArg, outputArg, ...rest] = argv;
  if (!sourceArg || !outputArg || rest.length) fail('Usage: node tools/backup-private-server.cjs <source.sqlite> <new-backup.sqlite>');
  const source = path.resolve(sourceArg);
  const output = path.resolve(outputArg);
  if (source === output) fail('Backup output must not be the source database path.');
  if (!fs.existsSync(source) || !fs.statSync(source).isFile()) fail('Source database file does not exist.');
  if (fs.existsSync(output)) fail('Backup output already exists; refusing to overwrite it.');
  fs.mkdirSync(path.dirname(output), { recursive: true, mode: 0o700 });
  const temp = path.join(path.dirname(output), `.${path.basename(output)}.${process.pid}.${crypto.randomBytes(8).toString('hex')}.tmp`);
  let sourceDb;
  try {
    sourceDb = new DatabaseSync(source);
    sourceDb.exec('PRAGMA busy_timeout = 5000; PRAGMA foreign_keys = ON;');
    // A SQLite-native snapshot includes committed WAL content and avoids copying a live DB file blindly.
    sourceDb.exec(`VACUUM INTO ${quoteSqlString(temp)}`);
    sourceDb.close(); sourceDb = null;
    const inspection = inspectDatabaseFile(temp);
    if (process.platform !== 'win32') fs.chmodSync(temp, 0o600);
    // link() is atomic and refuses to replace an existing destination, including a race after preflight.
    try { fs.linkSync(temp, output); }
    catch (error) {
      if (error && error.code === 'EEXIST') fail('Backup output already exists; refusing to overwrite it.');
      // Filesystems that do not support hard links can still use exclusive creation.
      if (!error || !['EPERM', 'ENOTSUP', 'EOPNOTSUPP'].includes(error.code)) throw error;
      try { fs.copyFileSync(temp, output, fs.constants.COPYFILE_EXCL); }
      catch (copyError) { try { fs.unlinkSync(output); } catch (_) {} throw copyError; }
      if (process.platform !== 'win32') fs.chmodSync(output, 0o600);
    }
    fs.unlinkSync(temp);
    const bytes = fs.statSync(output).size;
    const hash = crypto.createHash('sha256').update(fs.readFileSync(output)).digest('hex');
    console.log(JSON.stringify({ status: 'PASS', source, output, bytes, sha256: hash, integrity: inspection.integrity, foreignKeyErrors: inspection.foreignKeyErrors, tables: inspection.tables, missingOptionalTables: inspection.missingOptionalTables, tableCounts: inspection.tableCounts }, null, 2));
  } finally {
    if (sourceDb) { try { sourceDb.close(); } catch (_) {} }
    try { if (fs.existsSync(temp)) fs.unlinkSync(temp); } catch (_) {}
  }
}

try { main(process.argv.slice(2)); }
catch (error) { console.error(`Backup failed: ${error && error.message ? error.message : 'unknown error'}`); process.exitCode = 1; }
