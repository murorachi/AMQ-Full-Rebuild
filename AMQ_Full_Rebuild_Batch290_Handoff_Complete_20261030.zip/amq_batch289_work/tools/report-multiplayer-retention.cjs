'use strict';

const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { DatabaseSync } = require('node:sqlite');

function tableExists(db, name) {
  return Boolean(db.prepare("SELECT 1 AS present FROM sqlite_master WHERE type = 'table' AND name = ?").get(name));
}
function number(value) { return value === null || value === undefined ? null : Number(value); }
function main(argv) {
  if (argv.length !== 1 || !argv[0]) throw new Error('Usage: node tools/report-multiplayer-retention.cjs <existing-amq.sqlite>');
  const filename = path.resolve(argv[0]);
  if (!fs.existsSync(filename) || !fs.statSync(filename).isFile()) throw new Error('Database file does not exist.');
  const db = new DatabaseSync(filename, { readOnly: true });
  let report;
  try {
    const roomsPresent = tableExists(db, 'multiplayer_rooms');
    const commandsPresent = tableExists(db, 'multiplayer_commands');
    const eventsPresent = tableExists(db, 'srs_assessment_events');
    let rooms = { tablePresent: roomsPresent, total: 0, active: 0, closed: 0, unknownPhase: 0, oldestUpdatedAt: null, newestUpdatedAt: null };
    let commands = { tablePresent: commandsPresent, total: 0, roomsWithCommands: 0, maxCommandsPerRoom: 0, oldestCreatedAt: null, newestCreatedAt: null };
    let srsAssessmentEvents = { tablePresent: eventsPresent, total: 0, oldestCreatedAt: null, newestCreatedAt: null };

    if (roomsPresent) {
      const phaseCounts = db.prepare(`
        SELECT COUNT(*) AS total,
          SUM(CASE WHEN json_valid(state_json) = 1 AND json_extract(state_json, '$.phase') IN ('lobby', 'round') THEN 1 ELSE 0 END) AS active,
          SUM(CASE WHEN json_valid(state_json) = 1 AND json_extract(state_json, '$.phase') = 'closed' THEN 1 ELSE 0 END) AS closed,
          SUM(CASE WHEN json_valid(state_json) = 0 OR json_extract(state_json, '$.phase') IS NULL OR json_extract(state_json, '$.phase') NOT IN ('lobby', 'round', 'closed') THEN 1 ELSE 0 END) AS unknownPhase,
          MIN(updated_at) AS oldestUpdatedAt, MAX(updated_at) AS newestUpdatedAt
        FROM multiplayer_rooms`).get();
      rooms = { tablePresent: true, total: number(phaseCounts.total) || 0, active: number(phaseCounts.active) || 0, closed: number(phaseCounts.closed) || 0,
        unknownPhase: number(phaseCounts.unknownPhase) || 0, oldestUpdatedAt: number(phaseCounts.oldestUpdatedAt), newestUpdatedAt: number(phaseCounts.newestUpdatedAt) };
    }
    if (commandsPresent) {
      const summary = db.prepare(`SELECT COUNT(*) AS total, COUNT(DISTINCT room_id) AS roomsWithCommands,
        MIN(created_at) AS oldestCreatedAt, MAX(created_at) AS newestCreatedAt FROM multiplayer_commands`).get();
      const maximum = db.prepare('SELECT MAX(command_count) AS maximum FROM (SELECT COUNT(*) AS command_count FROM multiplayer_commands GROUP BY room_id)').get();
      commands = { tablePresent: true, total: number(summary.total) || 0, roomsWithCommands: number(summary.roomsWithCommands) || 0,
        maxCommandsPerRoom: number(maximum.maximum) || 0, oldestCreatedAt: number(summary.oldestCreatedAt), newestCreatedAt: number(summary.newestCreatedAt) };
    }
    if (eventsPresent) {
      const summary = db.prepare('SELECT COUNT(*) AS total, MIN(created_at) AS oldestCreatedAt, MAX(created_at) AS newestCreatedAt FROM srs_assessment_events').get();
      srsAssessmentEvents = { tablePresent: true, total: number(summary.total) || 0, oldestCreatedAt: number(summary.oldestCreatedAt), newestCreatedAt: number(summary.newestCreatedAt) };
    }
    report = { rooms, commands, srsAssessmentEvents };
  } finally { db.close(); }
  console.log(JSON.stringify({ status: 'PASS', file: filename, bytes: fs.statSync(filename).size,
    sha256: crypto.createHash('sha256').update(fs.readFileSync(filename)).digest('hex'), mode: 'read-only; no data writes', ...report }, null, 2));
}

try { main(process.argv.slice(2)); }
catch (error) { console.error(`Multiplayer retention report failed: ${error && error.message ? error.message : 'unknown error'}`); process.exitCode = 1; }
