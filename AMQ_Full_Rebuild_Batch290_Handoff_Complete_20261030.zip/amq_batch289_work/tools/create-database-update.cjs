#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const zlib = require('node:zlib');
const { createHash } = require('node:crypto');

function readAssignedJson(file, variable) {
  const source = fs.readFileSync(file, 'utf8').trim();
  const escaped = variable.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const match = source.match(new RegExp(`^window\\.${escaped}\\s*=\\s*([\\s\\S]+?)\\s*;?$`));
  if (!match) throw new Error(`${file} must contain a single window.${variable} = JSON assignment`);
  try { return JSON.parse(match[1]); }
  catch (_) { throw new Error(`${file} assignment is not valid JSON`); }
}
function readPackedBase64(file) {
  const source = fs.readFileSync(file, 'utf8').trim();
  const match = source.match(/^window\.__EMQ_PACKED_B64\s*=\s*("(?:[^"\\]|\\.)*")\s*;?$/);
  if (!match) throw new Error(`${file} must contain a single JSON-string window.__EMQ_PACKED_B64 assignment`);
  return JSON.parse(match[1]);
}
function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

function main() {
  const [amqPath, emqPath, outputPath] = process.argv.slice(2);
  if (!amqPath || !emqPath || !outputPath) {
    process.stderr.write('Usage: node tools/create-database-update.cjs <data.js> <emq-data.js> <output.json>\n');
    process.exitCode = 2;
    return;
  }
  const amq = readAssignedJson(path.resolve(amqPath), 'DB');
  const packed = readPackedBase64(path.resolve(emqPath));
  if (!Array.isArray(amq.anime) || !Array.isArray(amq.songs) || typeof packed !== 'string') throw new Error('source scripts do not match the expected bundled schemas');
  const emq = JSON.parse(zlib.gunzipSync(Buffer.from(packed, 'base64')).toString('utf8'));
  if (!emq || emq.version !== 1 || !Array.isArray(emq.works) || !Array.isArray(emq.songs)) throw new Error('EMQ decompressed payload must contain version 1, works, and songs');
  const payload = {
    schemaVersion: 1,
    sources: {
      AMQ: { schema: 'candidate382-stageI-library-data-v1', anime: amq.anime, songs: amq.songs },
      EMQ: { schema: 'candidate382-stageI-library-emq-v1', version: 1, works: emq.works, songs: emq.songs }
    }
  };
  const checksum = createHash('sha256').update(stableStringify(payload), 'utf8').digest('hex');
  const envelope = { format: 'amq-learning-database-update', formatVersion: 1, createdAt: new Date().toISOString(), payload, checksum };
  const output = path.resolve(outputPath);
  fs.writeFileSync(output, `${JSON.stringify(envelope)}\n`, { flag: 'wx' });
  process.stdout.write(`Created ${output}\nAMQ: ${amq.anime.length} works / ${amq.songs.length} songs\nEMQ: ${emq.works.length} works / ${emq.songs.length} songs\nSHA-256: ${checksum}\n`);
}

try { main(); }
catch (error) { process.stderr.write(`Failed to create database update package: ${error.message}\n`); process.exitCode = 1; }
