#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createHash, generateKeyPairSync } = require('node:crypto');

const target = process.argv[2];
if (!target) {
  process.stderr.write('Usage: node tools/create-database-update-signing-key.cjs <private-key-output.pem>\n');
  process.exit(2);
} else {
  const privatePath = path.resolve(target);
  fs.mkdirSync(path.dirname(privatePath), { recursive: true });
  if (fs.existsSync(privatePath)) throw new Error('private key output already exists; refusing to overwrite');
  const pair = generateKeyPairSync('ed25519');
  const privatePem = pair.privateKey.export({ type: 'pkcs8', format: 'pem' });
  const publicDer = pair.publicKey.export({ type: 'spki', format: 'der' });
  const keyId = createHash('sha256').update(publicDer).digest('hex').slice(0, 16);
  const fd = fs.openSync(privatePath, 'wx', 0o600);
  try { fs.writeFileSync(fd, privatePem); } finally { fs.closeSync(fd); }
  try { fs.chmodSync(privatePath, 0o600); } catch (_) {}
  process.stdout.write(`Created Ed25519 signing key.\nPrivate key: ${privatePath}\nPublic key (SPKI DER Base64): ${publicDer.toString('base64')}\nKey ID: ${keyId}\nKeep the private key offline; never publish or add it to a source ZIP.\n`);
}
