#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { createHash, createPublicKey, verify } = require('node:crypto');

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}
function digest(bytes) { return createHash('sha256').update(bytes).digest('hex'); }
function fail(message) { process.stderr.write(`Release verification failed: ${message}\n`); process.exitCode = 1; }

const [releaseDirectoryArg, publicKeyPathArg] = process.argv.slice(2);
if (!releaseDirectoryArg || !publicKeyPathArg) {
  fail('Usage: node tools/verify-database-update-release.cjs <release-directory> <public-key.pem>');
  process.exitCode = 2;
} else {
  try {
    const directory = path.resolve(releaseDirectoryArg);
    const manifestPath = path.join(directory, 'latest.json');
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
    const publicKey = createPublicKey(fs.readFileSync(path.resolve(publicKeyPathArg), 'utf8'));
    if (publicKey.asymmetricKeyType !== 'ed25519') throw new Error('verification key must be Ed25519');
    const publicDer = publicKey.export({ type: 'spki', format: 'der' });
    const expectedKeyId = digest(publicDer).slice(0, 16);
    if (!manifest || manifest.format !== 'amq-learning-database-release' || manifest.manifestVersion !== 1) throw new Error('unsupported manifest format');
    if (!manifest.signature || manifest.signature.algorithm !== 'Ed25519' || manifest.signature.keyId !== expectedKeyId || typeof manifest.signature.value !== 'string') throw new Error('signature metadata or key ID mismatch');
    const unsigned = { ...manifest }; delete unsigned.signature;
    if (!verify(null, Buffer.from(stableStringify(unsigned), 'utf8'), publicKey, Buffer.from(manifest.signature.value, 'base64'))) throw new Error('manifest signature is invalid');
    if (!manifest.bundle || typeof manifest.bundle.url !== 'string' || path.basename(manifest.bundle.url) !== manifest.bundle.url || manifest.bundle.url.includes('..')) throw new Error('bundle URL must be a local basename');
    const bundlePath = path.join(directory, manifest.bundle.url);
    const bytes = fs.readFileSync(bundlePath);
    if (bytes.length !== manifest.bundle.byteLength) throw new Error('bundle byte length mismatch');
    if (digest(bytes) !== manifest.bundle.sha256) throw new Error('bundle SHA-256 mismatch');
    const envelope = JSON.parse(bytes.toString('utf8'));
    if (!envelope || envelope.format !== manifest.bundle.format || envelope.formatVersion !== manifest.bundle.formatVersion) throw new Error('bundle format mismatch');
    if (envelope.checksum !== manifest.bundle.payloadChecksum) throw new Error('payload checksum mismatch');
    process.stdout.write(JSON.stringify({ status: 'PASS', releaseVersion: manifest.releaseVersion, keyId: expectedKeyId, bundle: manifest.bundle.url, byteLength: bytes.length, sha256: digest(bytes), payloadChecksum: envelope.checksum, counts: manifest.bundle.counts }, null, 2) + '\n');
  } catch (error) { fail(error.message); }
}
