#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');

const root = path.resolve(__dirname, '..');
const failures = [];
const notes = [];
const read = (relative) => fs.readFileSync(path.join(root, relative), 'utf8');
const exists = (relative) => fs.existsSync(path.join(root, relative));

function check(condition, label, detail = '') {
  const line = `${condition ? 'PASS' : 'FAIL'} ${label}${detail ? `: ${detail}` : ''}`;
  (condition ? notes : failures).push(line);
}

function inspectHtml(relative, requiredOrder) {
  const html = read(relative);
  const ids = [...html.matchAll(/\bid\s*=\s*(["'])(.*?)\1/g)].map(match => match[2]);
  const duplicateIds = [...new Set(ids.filter((id, index) => ids.indexOf(id) !== index))];
  check(duplicateIds.length === 0, `${relative} duplicate IDs`, duplicateIds.join(', '));

  const refs = [...html.matchAll(/<(?:script|link)\b[^>]*?(?:src|href)\s*=\s*(["'])(.*?)\1[^>]*>/gi)]
    .map(match => match[2])
    .filter(ref => !/^(?:[a-z]+:|\/\/|#|data:)/i.test(ref));
  const missing = refs.filter(ref => !exists(path.posix.normalize(path.posix.join(path.posix.dirname(relative), ref))));
  check(missing.length === 0, `${relative} local references`, `${refs.length} checked${missing.length ? `; missing: ${missing.join(', ')}` : ''}`);

  const scripts = [...html.matchAll(/<script\b[^>]*?src\s*=\s*(["'])(.*?)\1[^>]*>/gi)].map(match => match[2].replace(/^\.\.\/src\//, ''));
  const positions = requiredOrder.map(script => scripts.indexOf(script));
  check(positions.every(position => position >= 0) && positions.every((position, index) => index === 0 || positions[index - 1] < position), `${relative} module load order`, requiredOrder.join(' < '));

  const inlineScripts = [...html.matchAll(/<script\b(?![^>]*\bsrc\s*=)[^>]*>([\s\S]*?)<\/script>/gi)].map(match => match[1]);
  for (let index = 0; index < inlineScripts.length; index += 1) {
    const directory = fs.mkdtempSync(path.join(root, '.amq-inline-check-'));
    const temp = path.join(directory, `script-${index}.cjs`);
    try {
      fs.writeFileSync(temp, inlineScripts[index]);
      const { spawnSync } = require('node:child_process');
      const result = spawnSync(process.execPath, ['--check', temp], { encoding: 'utf8' });
      check(result.status === 0, `${relative} inline script ${index + 1} syntax`, result.stderr.trim());
    } finally {
      fs.rmSync(directory, { recursive: true, force: true });
    }
  }
}

const runtimeOrder = [
  'core/state.js', 'core/event-bus.js', 'core/lifecycle.js', 'core/errors.js',
  'data/identity.js', 'data/validate.js', 'data/source-adapter.js', 'data/source-registry.js', 'data/audio-candidates.js', 'data/source-mappers.js', 'data/database-update.js', 'data/chinese-title-provider.js', 'data/query-index.js', 'data/load-state.js', 'data/repository.js', 'data/runtime-bootstrap.js', 'data/source-runtime.js', 'engine/answer-evaluator.js', 'engine/quiz-engine.js', 'engine/quiz-pool.js', 'engine/quiz-clock.js', 'engine/quiz-mods.js', 'engine/quiz-session.js', 'learning/fsrs-scheduler.js', 'learning/statistics-dashboard.js', 'audio/audio-service.js', 'audio/playback-coordinator.js', 'persistence/familiarity-store.js', 'persistence/quiz-history-store.js', 'persistence/playback-history-store.js', 'persistence/app-settings-store.js', 'persistence/workspace-preferences-store.js', 'persistence/skin-theme-store.js', 'persistence/blacklist-store.js', 'persistence/srs-store.js', 'persistence/personal-library-store.js', 'persistence/backup-restore.js', 'app-runtime.js', 'ui/catalog-browser.js', 'ui/answer-suggestions.js', 'ui/quiz-panel.js', 'ui/backup-restore-panel.js', 'ui/database-update-panel.js', 'ui/free-player-dock.js', 'ui/statistics-dashboard-panel.js', 'skins/osk-importer.js', 'skins/theme-adapter.js', 'skins/theme-transfer.js', 'ui/skin-import-panel.js', 'integrations/external-service-adapter.js', 'integrations/artwork-adapter.js', 'integrations/ann-artwork-adapter.js', 'integrations/artwork-provider-factory.js', 'multiplayer/protocol.js', 'multiplayer/room-state-machine.js', 'multiplayer/http-client.js', 'multiplayer/room-session.js', 'ui/multiplayer-panel.js', 'ui/workspace-preferences-panel.js', 'app.js'
];
inspectHtml('src/index.html', [...runtimeOrder.slice(0, 4), 'data/assets/data.js', 'data/assets/emq-data.js', ...runtimeOrder.slice(4)]);
inspectHtml('tests/tests.html', runtimeOrder.filter(script => script !== 'app.js' && script !== 'multiplayer/http-client.js' && script !== 'multiplayer/room-session.js' && script !== 'ui/multiplayer-panel.js'));

const jsFiles = [];
function walk(directory) {
  for (const entry of fs.readdirSync(path.join(root, directory), { withFileTypes: true })) {
    const relative = path.posix.join(directory, entry.name);
    if (entry.isDirectory()) walk(relative);
    else if (entry.isFile() && /\.(?:js|cjs)$/.test(relative) && !relative.includes('.tmp.')) jsFiles.push(relative);
  }
}
walk('src');
walk('tests');
walk('tools');
for (const relative of jsFiles) {
  const { spawnSync } = require('node:child_process');
  const result = spawnSync(process.execPath, ['--check', path.join(root, relative)], { encoding: 'utf8' });
  check(result.status === 0, `${relative} syntax`, result.stderr.trim());

  const source = read(relative);
  if (!relative.startsWith('src/') && !relative.startsWith('tests/')) continue;
  const deprecatedPatterns = [
    ['String.prototype.substr', /\.substr\s*\(/],
    ['escape()', /\bescape\s*\(/],
    ['unescape()', /\bunescape\s*\(/],
    ['document.all', /\bdocument\s*\.\s*all\b/],
    ['arguments.callee', /\barguments\s*\.\s*callee\b/]
  ];
  for (const [label, pattern] of deprecatedPatterns) {
    check(!pattern.test(source), `${relative} deprecated API`, label);
  }
}

const moduleSources = Object.fromEntries(jsFiles.map(file => [file, read(file)]));
for (const relative of jsFiles.filter(file => file.startsWith('src/core/'))) {
  check(!/\bAMQData\b|\bAMQApp\b|\bdocument\s*\./.test(moduleSources[relative]), `${relative} dependency direction`, 'core must not depend on data, app, or DOM');
}
for (const relative of jsFiles.filter(file => file.startsWith('src/data/'))) {
  check(!/\bAMQApp\b|\bdocument\s*\./.test(moduleSources[relative]), `${relative} dependency direction`, 'data modules must not depend on app or DOM');
}
for (const relative of jsFiles.filter(file => file.startsWith('src/engine/'))) {
  check(!/\bdocument\s*\.|\bAMQApp\b|\bAMQCatalogBrowser\b/.test(moduleSources[relative]), `${relative} dependency direction`, 'engine modules must not depend on DOM or UI');
}
for (const relative of jsFiles.filter(file => file.startsWith('src/audio/'))) {
  check(!/\bAMQApp\b|\bAMQCatalogBrowser\b/.test(moduleSources[relative]), `${relative} dependency direction`, 'audio services must not depend on UI');
}
for (const relative of jsFiles.filter(file => file.startsWith('src/persistence/'))) {
  check(!/\bAMQApp\b|\bAMQEngine\b|\bAMQQuizPanel\b|\bAMQCatalogBrowser\b|\bAMQAudio\b/.test(moduleSources[relative]), `${relative} dependency direction`, 'persistence must not depend on engine, audio, app, or UI');
}
for (const relative of jsFiles.filter(file => file.startsWith('src/learning/'))) {
  check(!/\bdocument\s*\.|\blocalStorage\b|\bAMQApp\b|\bAMQQuizPanel\b|\bAMQCatalogBrowser\b/.test(moduleSources[relative]), `${relative} dependency direction`, 'learning algorithms must not depend on DOM, persistence storage, app, or UI');
}
check(!/\bAMQData\b/.test(moduleSources['src/app.js'] || ''), 'app dependency direction', 'app must not directly own data source access');
check(/themeAdapter\.apply/.test(moduleSources['src/ui/skin-import-panel.js'] || ''), 'skin panel delegates rendering', 'role rendering belongs to the Skin Theme Adapter');
check(/theme-target-unavailable/.test(moduleSources['src/skins/theme-adapter.js'] || '') && !/\) \|\| root;/.test(moduleSources['src/skins/theme-adapter.js'] || ''), 'skin adapter fails closed without catalog target', 'skin visuals must not fall back to the global document root');
check(/AbortController/.test(moduleSources['src/integrations/artwork-adapter.js'] || '') && /ARTWORK_URL_UNSAFE/.test(moduleSources['src/integrations/artwork-adapter.js'] || ''), 'artwork adapter cancellation and URL safety', 'provider calls are cancellable and artwork URLs must be HTTPS');
check(/record\.artworkRef/.test(moduleSources['src/integrations/artwork-adapter.js'] || '') && /work reference/.test(moduleSources['src/integrations/artwork-adapter.js'] || ''), 'artwork cache keys use explicit work references', 'song IDs must never be treated as anime/game work IDs');
check(/artworkAdapter\.getArtwork/.test(moduleSources['src/ui/catalog-browser.js'] || '') && /ARTWORK_URL_UNSAFE/.test(moduleSources['src/integrations/artwork-adapter.js'] || ''), 'catalog artwork rendering uses validated adapter results', 'only normalized adapter results may reach img.src');
check(/skins\/theme-adapter\.js/.test(read('src/index.html')) && /skins\/theme-adapter\.js/.test(read('tests/tests.html')), 'skin theme adapter load wiring', 'production and browser test pages load adapter');

for (const relative of jsFiles) {
  const names = [...read(relative).matchAll(/^\s*function\s+([A-Za-z_$][\w$]*)\s*\(/gm)].map(match => match[1]);
  const duplicates = [...new Set(names.filter((name, index) => names.indexOf(name) !== index))];
  check(duplicates.length === 0, `${relative} duplicate function declarations`, duplicates.join(', '));
}

for (const line of notes) console.log(line);
for (const line of failures) console.error(line);
console.log(`\nArchitecture check: ${notes.length} passed, ${failures.length} failed.`);
process.exitCode = failures.length ? 1 : 0;

check(/artworkProviderFactory/.test(moduleSources["src/integrations/artwork-provider-factory.js"] || "") && /annId/.test(moduleSources["src/integrations/artwork-provider-factory.js"] || "") && /vndbId/.test(moduleSources["src/integrations/artwork-provider-factory.js"] || "") && !/searchVisualNovels\(/.test(moduleSources["src/integrations/artwork-provider-factory.js"] || ""), "artwork providers prefer ANNID and require explicit IDs for fallbacks", "ANNID is the primary anime cover identity; no title guessing");
