#!/usr/bin/env node
'use strict';

const fs = require('node:fs');
const path = require('node:path');
const { createHash, createPrivateKey, createPublicKey, sign } = require('node:crypto');
const { spawnSync } = require('node:child_process');

function fail(message, code = 1) {
  process.stderr.write(`${message}\n`);
  process.exitCode = code;
}

function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}

function main() {
  const [amqPath, emqPath, outputDirectory, releaseVersion, privateKeyPath] = process.argv.slice(2);
  if (!amqPath || !emqPath || !outputDirectory || !releaseVersion || !privateKeyPath) {
    fail('Usage: node tools/create-database-update-release.cjs <data.js> <emq-data.js> <output-directory> <release-version> <ed25519-private-key.pem>', 2);
    return;
  }
  if (!/^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$/.test(releaseVersion)) throw new Error('release-version must be a semver-like version such as 1.0.0');
  const privateKey = createPrivateKey(fs.readFileSync(path.resolve(privateKeyPath), 'utf8'));
  if (privateKey.asymmetricKeyType !== 'ed25519') throw new Error('signing key must be an Ed25519 private key');
  const publicKey = createPublicKey(privateKey);
  const publicDer = publicKey.export({ type: 'spki', format: 'der' });
  const keyId = createHash('sha256').update(publicDer).digest('hex').slice(0, 16);
  const outputDir = path.resolve(outputDirectory);
  fs.mkdirSync(outputDir, { recursive: true });
  const bundleName = `amq-database-update-${releaseVersion}.json`;
  const bundlePath = path.join(outputDir, bundleName);
  const manifestPath = path.join(outputDir, 'latest.json');
  if (fs.existsSync(bundlePath) || fs.existsSync(manifestPath)) throw new Error('release output already exists; refusing to overwrite a published bundle or latest.json');
  const generator = path.join(__dirname, 'create-database-update.cjs');
  const generated = spawnSync(process.execPath, [generator, path.resolve(amqPath), path.resolve(emqPath), bundlePath], { encoding: 'utf8', maxBuffer: 4 * 1024 * 1024 });
  if (generated.status !== 0) throw new Error((generated.stderr || generated.stdout || 'database bundle generation failed').trim());
  const bytes = fs.readFileSync(bundlePath);
  const envelope = JSON.parse(bytes.toString('utf8'));
  const sha256 = createHash('sha256').update(bytes).digest('hex');
  const manifest = {
    format: 'amq-learning-database-release',
    manifestVersion: 1,
    releaseVersion,
    createdAt: new Date().toISOString(),
    minimumAppUpdateFormatVersion: 1,
    maximumAppUpdateFormatVersion: 1,
    bundle: {
      url: bundleName,
      format: envelope.format,
      formatVersion: envelope.formatVersion,
      byteLength: bytes.length,
      sha256,
      payloadChecksum: envelope.checksum,
      counts: {
        AMQ: { works: envelope.payload.sources.AMQ.anime.length, songs: envelope.payload.sources.AMQ.songs.length },
        EMQ: { works: envelope.payload.sources.EMQ.works.length, songs: envelope.payload.sources.EMQ.songs.length }
      }
    }
  };
  manifest.signature = { algorithm: 'Ed25519', keyId, value: sign(null, Buffer.from(stableStringify(manifest), 'utf8'), privateKey).toString('base64') };
  try { fs.writeFileSync(manifestPath, `${JSON.stringify(manifest, null, 2)}\n`, { flag: 'wx' }); }
  catch (error) { fs.rmSync(bundlePath, { force: true }); throw error; }
  process.stdout.write(`Created signed release ${releaseVersion}\nBundle: ${bundlePath}\nManifest: ${manifestPath}\nSigning key ID: ${keyId}\nBundle bytes: ${bytes.length}\nBundle SHA-256: ${sha256}\nPayload SHA-256: ${envelope.checksum}\n`);
}

try { main(); }
catch (error) { fail(`Failed to create database update release: ${error.message}`); }
