#!/usr/bin/env node
'use strict';
const fs = require('node:fs');
const crypto = require('node:crypto');
const zlib = require('node:zlib');
const path = require('node:path');
function sha256(data) { return crypto.createHash('sha256').update(data).digest('hex'); }
function assignedJson(source, marker) {
  const start = source.indexOf(marker);
  if (start < 0) throw new Error(`assignment marker missing: ${marker}`);
  let i = start + marker.length;
  while (/\s/.test(source[i] || '')) i++;
  if (source[i] !== '{') throw new Error('expected JSON object');
  const begin = i; let depth = 0, quoted = false, escape = false;
  for (; i < source.length; i++) {
    const c = source[i];
    if (quoted) { if (escape) escape = false; else if (c === '\\') escape = true; else if (c === '"') quoted = false; continue; }
    if (c === '"') quoted = true;
    else if (c === '{' || c === '[') depth++;
    else if (c === '}' || c === ']') { if (--depth === 0) return JSON.parse(source.slice(begin, i + 1)); }
  }
  throw new Error('unterminated JSON');
}
function summarize(total, mapped, missing) { return { total, mapped, missing, coveragePercent: total ? Number((mapped / total * 100).toFixed(2)) : 0 }; }
function audit(amqPath, emqPath) {
  const amqBytes = fs.readFileSync(amqPath); const emqBytes = fs.readFileSync(emqPath);
  const amq = assignedJson(amqBytes.toString('utf8'), 'window.DB=');
  const emqSource = emqBytes.toString('utf8');
  const packed = emqSource.match(/window\.__EMQ_PACKED_B64\s*=\s*"([^"]+)"/);
  if (!packed) throw new Error('EMQ packed payload missing');
  const emq = JSON.parse(zlib.gunzipSync(Buffer.from(packed[1], 'base64')).toString('utf8'));
  if (!Array.isArray(amq.anime) || !Array.isArray(amq.songs) || !Array.isArray(emq.works) || !Array.isArray(emq.songs)) throw new Error('source data schema mismatch');
  const amqMapped = new Set(amq.anime.filter(row => Array.isArray(row) && Number.isSafeInteger(row[6]) && row[6] > 0).map(row => row[0]));
  const emqMapped = new Set(emq.works.filter(row => row && typeof row.vndbId === 'string' && /^v\d+$/i.test(row.vndbId.trim())).map(row => row.i));
  const amqSongWorks = new Set(amq.songs.filter(row => Array.isArray(row) && amqMapped.has(row[0])).map(row => row[0]));
  const emqSongWorks = new Set(emq.songs.filter(row => row && emqMapped.has(row.w)).map(row => row.w));
  return {
    generatedAt: new Date().toISOString(),
    caveat: 'This is identifier coverage only. It does not prove provider availability, image URL existence, browser CORS, image decoding, attribution display, or license acceptance.',
    sources: {
      amq: { sha256: sha256(amqBytes), bytes: amqBytes.length, works: summarize(amq.anime.length, amqMapped.size, amq.anime.length - amqMapped.size), songs: summarize(amq.songs.length, amq.songs.filter(row => amqMapped.has(row[0])).length, amq.songs.filter(row => !amqMapped.has(row[0])).length), uniqueWorksWithSongs: amqSongWorks.size },
      emq: { sha256: sha256(emqBytes), bytes: emqBytes.length, works: summarize(emq.works.length, emqMapped.size, emq.works.length - emqMapped.size), songs: summarize(emq.songs.length, emq.songs.filter(row => emqMapped.has(row.w)).length, emq.songs.filter(row => !emqMapped.has(row.w)).length), uniqueWorksWithSongs: emqSongWorks.size }
    }
  };
}
const [amqPath, emqPath] = process.argv.slice(2);
if (!amqPath || !emqPath) { console.error('Usage: node tools/audit-artwork-coverage.cjs <data.js> <emq-data.js>'); process.exit(2); }
try { console.log(JSON.stringify(audit(path.resolve(amqPath), path.resolve(emqPath)), null, 2)); }
catch (error) { console.error(`ARTWORK COVERAGE AUDIT FAIL: ${error.message}`); process.exit(1); }
