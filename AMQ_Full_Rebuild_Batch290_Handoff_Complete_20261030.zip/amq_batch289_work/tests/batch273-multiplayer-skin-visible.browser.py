#!/usr/bin/env python3
"""Route-aware Skin apply/fallback/reset checks for Batch272 multiplayer roles."""
from pathlib import Path
import json, re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'src'; OUT=ROOT/'artifacts'/'batch273-multiplayer-skin'; OUT.mkdir(parents=True,exist_ok=True)
html=(SRC/'index.html').read_text(encoding='utf-8')
def inline_css(m): return '<style>\n'+(SRC/m.group(1)).read_text(encoding='utf-8')+'\n</style>'
def inline_js(m): return '<script>\n'+(SRC/m.group(1)).read_text(encoding='utf-8')+'\n</script>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',inline_css,html)
html=re.sub(r'<script src="([^"]+)" defer></script>',inline_js,html)
html=re.sub(r'<script src="([^"]+)"></script>',inline_js,html)
roles=[
 {'id':'multiplayer.lobby.tab','selector':'[data-skin-component="multiplayer.lobby.source-tabs"]','token':'--amq-skin-role-multiplayer-lobby-tab'},
 {'id':'multiplayer.lobby.room-list','selector':'[data-skin-component="multiplayer.lobby.room-list"]','token':'--amq-skin-role-multiplayer-lobby-room-list'},
 {'id':'multiplayer.lobby.create-room','selector':'[data-skin-component="multiplayer.lobby.create-room"]','token':'--amq-skin-role-multiplayer-lobby-create-room'},
 {'id':'multiplayer.member.item','selector':'[data-skin-component="multiplayer.member-list"]','token':'--amq-skin-role-multiplayer-member-item'},
 {'id':'multiplayer.ready-state','selector':'[data-skin-component="multiplayer.member-list"]','token':'--amq-skin-role-multiplayer-ready-state'},
]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1920,'height':1080}); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(html,wait_until='domcontentloaded',timeout=60000); page.wait_for_timeout(500)
 page.locator('#app-shell-nav [data-nav-page="quiz"]').click(); page.wait_for_timeout(100)
 # Explicitly labelled DOM fixture only, to exercise player-row roles while the real lobby is empty.
 page.evaluate('''() => { const list=document.querySelector('#multiplayer-players'); const row=document.createElement('li'); row.className='multiplayer-player-item'; row.dataset.skinComponent='multiplayer.member-item'; const ready=document.createElement('span'); ready.className='multiplayer-player-ready-state'; ready.dataset.skinComponent='multiplayer.ready-state'; ready.textContent='Fixture: ready state'; row.append(ready); list.append(row); document.querySelector('#multiplayer-room-details').hidden=false; }''')
 result=page.evaluate('''async roles => { const adapter=window.AMQSkins.themeAdapter.createThemeAdapter({validateImage:()=>true}); const rows=[]; const png=Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z/D/PwAG/gL/DHWJ3gAAAABJRU5ErkJggg=='),c=>c.charCodeAt(0)); const blob=new Blob([png],{type:'image/png'}); for(const r of roles){const nodes=[...document.querySelectorAll(r.selector)];const visible=nodes.filter(n=>n.getClientRects().length&&!n.closest('[hidden]'));const asset={path:'batch273.png',extension:'png',blob};const a=await adapter.apply({enabled:true,roleMappings:{[r.id]:asset.path},assets:[asset]});const stylesAfterApply=nodes.map(n=>n.style.getPropertyValue(r.token));const apply=nodes.length>0&&visible.length>0&&a.roles.includes(r.id)&&nodes.every(n=>n.style.getPropertyValue(r.token).includes('blob:'));const outside=[...document.querySelectorAll('*')].filter(n=>!nodes.includes(n)&&n.style&&n.style.getPropertyValue(r.token));const scope=outside.length===0;const m=await adapter.apply({enabled:true,roleMappings:{[r.id]:'missing.png'},assets:[]});const fallback=!m.roles.includes(r.id)&&m.warnings.some(w=>w.startsWith(r.id+':mapped-asset-missing'))&&nodes.every(n=>!n.style.getPropertyValue(r.token));await adapter.apply({enabled:true,roleMappings:{[r.id]:asset.path},assets:[asset]});adapter.reset();const reset=nodes.every(n=>!n.style.getPropertyValue(r.token)&&!n.dataset.amqSkinRoleActive);rows.push({id:r.id,targetCount:nodes.length,visibleCount:visible.length,apply,fallback,reset,scope,appliedRoles:a.roles,warnings:a.warnings,stylesAfterApply});}return rows;}''',roles)
 page.locator('#multiplayer-panel').screenshot(path=str(OUT/'multiplayer-skin-panel-fixture.png'))
 browser.close()
 summary={'roleCount':len(result),'applyPass':sum(x['apply'] for x in result),'fallbackPass':sum(x['fallback'] for x in result),'resetPass':sum(x['reset'] for x in result),'scopePass':sum(x['scope'] for x in result),'pageErrors':errors,'fixture':'one explicitly labelled player row; not live multiplayer data','rows':result}
 (OUT/'role-matrix.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 for r in result: print(('PASS' if r['apply'] and r['fallback'] and r['reset'] and r['scope'] else 'FAIL'),r['id'],r)
 print('SUMMARY',json.dumps({k:v for k,v in summary.items() if k not in ['rows','fixture']},ensure_ascii=False))
 if errors or any(not(r['apply'] and r['fallback'] and r['reset'] and r['scope']) for r in result): raise SystemExit('multiplayer role matrix failed')
