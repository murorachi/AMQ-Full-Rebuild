'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const html = fs.readFileSync(path.join(root, 'src/index.html'), 'utf8');
const panel = fs.readFileSync(path.join(root, 'src/ui/quiz-panel.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'src/styles/ui-shell.css'), 'utf8');

test('quiz audio status has a live semantic state and distinct visual states', () => {
  assert.match(html, /id="quiz-audio-status"[^>]*role="status"[^>]*aria-live="polite"[^>]*data-audio-state="idle"/);
  assert.match(panel, /elements\.audioStatus\.setAttribute\("data-audio-state", audioState\)/);
  for (const state of ['loading', 'ready', 'playing', 'paused', 'blocked', 'failed']) {
    assert.match(css, new RegExp(`#quiz-audio-status\\[data-audio-state="${state}"\\]`), `${state} has a state-specific visual rule`);
  }
});

test('quiz error banner is hidden when empty and becomes a typed visible alert on failure', () => {
  assert.match(html, /id="quiz-error"[^>]*role="alert"/);
  assert.match(panel, /elements\.error\.hidden = !errorText/);
  assert.match(panel, /elements\.error\.setAttribute\("data-error-state"/);
  assert.match(panel, /elements\.error\.setAttribute\("data-error-code"/);
  assert.match(css, /#quiz-error\[hidden\]\s*\{\s*display:none\s*\}/);
  assert.match(css, /#quiz-error:not\(\[hidden\]\)[\s\S]*?overflow-wrap:anywhere/);
});

test('quiz controls and answer suggestions meet touch targets with responsive layout', () => {
  assert.match(css, /\.quiz-actions button\{min-height:44px/);
  assert.match(css, /\.quiz-suggestion-option\{min-height:44px/);
  assert.match(css, /@media\(max-width:520px\)[\s\S]*?\.quiz-actions button\{min-width:0;min-height:46px/);
  assert.match(css, /\.quiz-actions button:hover:not\(:disabled\)/);
  assert.match(css, /\.quiz-actions #quiz-start:hover:not\(:disabled\)/);
});


test('legacy global quiz question-card styling is removed and multiplayer cards are owned by the shell', () => {
  const baseCss = fs.readFileSync(path.join(root, 'src/styles.css'), 'utf8');
  assert.doesNotMatch(baseCss, /^\.quiz-question-card\s*\{/m, 'legacy global light question-card rule must not remain as a hidden override');
  assert.doesNotMatch(baseCss, /^\.quiz-question-card \.notice\s*\{/m);
  assert.match(css, /\.app-page--quiz #multiplayer-panel \.quiz-question-card\{[^}]*padding:1rem[^}]*border:1px solid[^}]*background:linear-gradient/);
  assert.match(css, /\.app-page--quiz \.quiz-question-card,\.app-page--quiz \.quiz-history,\.app-page--quiz \.quiz-srs,\.app-page--learning \.statistics-grid>div\{background:linear-gradient/);
  assert.doesNotMatch(css, /\.app-page--quiz \.quiz-question-card,\.app-page--quiz \.quiz-history,\.app-page--quiz \.quiz-srs,\.app-page--learning \.statistics-grid>div\{[^}]*!important/);
});


test('form-control palette is shell-scoped and quiz answer fields do not rely on important overrides', () => {
  assert.doesNotMatch(css, /(?:^|})input,select\{background:#111219!important;border-color:#393c49!important;color:#f3f4f8!important;border-radius:3px!important/);
  assert.match(css, /\.app-page :is\(input:not\(\[type="checkbox"\]\):not\(\[type="radio"\]\):not\(\[type="range"\]\):not\(\[type="file"\]\),select\),#free-player-dock :is\(/);
  assert.match(css, /\.app-page :is\(input,select\):disabled,#free-player-dock :is\(input,select\):disabled\{cursor:not-allowed;opacity:\.52\}/);
  assert.doesNotMatch(css, /\.app-page--quiz \.quiz-answer-form input,\.app-page--quiz \.quiz-all-answer-fields input\{[^}]*!important/);
  assert.match(css, /\.app-page--quiz #quiz-panel \.quiz-answer-form input\{[^}]*border:1px solid #4a4050;border-radius:4px;background:#111219;color:#f3f4f8/);
  assert.doesNotMatch(css, /\.app-page--quiz #quiz-panel \.quiz-answer-form input\{[^}]*!important/);
});
