'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const zlib = require('node:zlib');
const { generateKeyPairSync } = require('node:crypto');
const { spawn, spawnSync } = require('node:child_process');

const root = path.resolve(__dirname, '..');
const architectureScript = path.join(root, 'tools/check-architecture.cjs');
const auditScript = path.join(root, 'tools/audit-source-data.cjs');

function writeFixture(directory, { crossCollision = false, duplicateAmqSong = false, danglingEmqWork = false } = {}) {
  const animeId = 11;
  const songId = 22;
  const emqWorkId = crossCollision ? animeId : 1500000001;
  const emqSongId = crossCollision ? songId : 2000000001;
  const amq = {
    anime: [[animeId, 'Work', 'Work Alt', 'Spring 2020', 'TV', 2020, 100]],
    songs: [[animeId, songId, 1, 1, 'Song', 'Artist', 3, 90.5, 7, 'audio.mp3', 'video.webm', '']]
  };
  if (duplicateAmqSong) amq.songs.push([...amq.songs[0]]);
  const emq = {
    version: 1,
    createdAt: '2026-10-16',
    source: 'test fixture',
    works: [{ i: emqWorkId, t: 'VN', n: 'VN alt', y: 2020, st: 1, r: 1, vndbId: 'v1' }],
    songs: [{ i: emqSongId, o: 1, w: danglingEmqWork ? 987654321 : emqWorkId, r: 1, t: 'EMQ Song', a: 'EMQ Artist', aa: ['EMQ Artist'], n: '', ta: ['EMQ Song'], v: ['https://example.invalid/audio.mp3'], d: 90, k: 1, y: 2020, wt: 'VN', wn: 'VN alt', wa: ['VN alt'], st: 1, links: 1 }]
  };
  const amqPath = path.join(directory, 'data.js');
  const emqPath = path.join(directory, 'emq-data.js');
  fs.writeFileSync(amqPath, `window.DB=${JSON.stringify(amq)};`);
  fs.writeFileSync(emqPath, `window.__EMQ_PACKED_B64 = "${zlib.gzipSync(Buffer.from(JSON.stringify(emq))).toString('base64')}";`);
  return { amqPath, emqPath };
}

function runAudit(options) {
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'amq-source-audit-'));
  try {
    const files = writeFixture(directory, options);
    return spawnSync(process.execPath, [auditScript, files.amqPath, files.emqPath], { encoding: 'utf8' });
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
}

test('architecture checker passes the current module boundaries and HTML wiring', () => {
  const result = spawnSync(process.execPath, [architectureScript], { encoding: 'utf8' });
  assert.equal(result.status, 0, result.stdout + result.stderr);
  assert.match(result.stdout, /Architecture check: \d+ passed, 0 failed\./);
});
test('architecture checker can run concurrently without sharing inline-script temp files', async () => {
  const run = () => new Promise((resolve, reject) => {
    const child = spawn(process.execPath, [architectureScript]);
    let stdout = '';
    let stderr = '';
    child.stdout.on('data', chunk => { stdout += chunk; });
    child.stderr.on('data', chunk => { stderr += chunk; });
    child.on('error', reject);
    child.on('close', code => resolve({ code, stdout, stderr }));
  });
  const [first, second] = await Promise.all([run(), run()]);
  assert.equal(first.code, 0, first.stderr);
  assert.equal(second.code, 0, second.stderr);
  assert.match(first.stdout, /Architecture check: \d+ passed, 0 failed\./);
  assert.match(second.stdout, /Architecture check: \d+ passed, 0 failed\./);
});

test('source data audit accepts structurally valid AMQ and packed EMQ fixtures', () => {
  const result = runAudit();
  assert.equal(result.status, 0, result.stdout + result.stderr);
  const report = JSON.parse(result.stdout);
  assert.equal(report.amq.animeCount, 1);
  assert.equal(report.emq.workCount, 1);
  assert.equal(report.crossSource.songIdCollisions, 0);
});

test('source data audit rejects duplicate AMQ song IDs', () => {
  const result = runAudit({ duplicateAmqSong: true });
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /duplicate IDs/);
});

test('source data audit rejects cross-source ID collisions', () => {
  const result = runAudit({ crossCollision: true });
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /cross-source ID collisions/);
});

test('source data audit rejects EMQ songs whose work ID is missing', () => {
  const result = runAudit({ danglingEmqWork: true });
  assert.notEqual(result.status, 0);
  assert.match(result.stderr, /dangling work references/);
});

test('catalog benchmark reports repeatable timing samples for valid AMQ/EMQ fixtures', () => {
  const benchmarkScript = path.join(root, 'tools/benchmark-catalog.cjs');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'amq-catalog-benchmark-'));
  try {
    const files = writeFixture(directory);
    const result = spawnSync(process.execPath, [benchmarkScript, files.amqPath, files.emqPath, '5'], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stdout + result.stderr);
    const report = JSON.parse(result.stdout);
    assert.equal(report.status, 'PASS');
    assert.equal(report.catalog.records, 2);
    assert.equal(report.benchmark.iterations, 5);
    assert.equal(report.benchmark.cases.length, 6);
    assert.equal(report.benchmark.groupingCases.length, 2);
    assert.deepEqual(report.benchmark.groupingCases.map(entry => entry.name), ['group_by_source', 'group_by_type_with_source_filter']);
    assert.ok(report.benchmark.groupingCases.every(entry => entry.timing.samples === 5));
    for (const entry of report.benchmark.cases) {
      assert.equal(entry.timing.samples, 5);
      assert.ok(entry.timing.p95Ms >= entry.timing.minMs);
    }
  } finally {
    fs.rmSync(directory, { recursive: true, force: true });
  }
});

test('catalog benchmark rejects invalid iteration counts', () => {
  const benchmarkScript = path.join(root, 'tools/benchmark-catalog.cjs');
  const result = spawnSync(process.execPath, [benchmarkScript, 'missing-amq.js', 'missing-emq.js', '2'], { encoding: 'utf8' });
  assert.equal(result.status, 2);
  assert.match(result.stderr, /between 5 and 500/);
});

test('database update package generator emits versioned non-executable JSON with a verifiable SHA-256', () => {
  const generator = path.join(root, 'tools/create-database-update.cjs');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'amq-database-update-'));
  try {
    const files = writeFixture(directory);
    const output = path.join(directory, 'update.json');
    const result = spawnSync(process.execPath, [generator, files.amqPath, files.emqPath, output], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stdout + result.stderr);
    const envelope = JSON.parse(fs.readFileSync(output, 'utf8'));
    assert.equal(envelope.format, 'amq-learning-database-update');
    assert.equal(envelope.formatVersion, 1);
    assert.equal(envelope.payload.sources.AMQ.songs.length, 1);
    assert.equal(envelope.payload.sources.EMQ.songs.length, 1);
    const stable = value => value === null || typeof value !== 'object' ? JSON.stringify(value)
      : Array.isArray(value) ? `[${value.map(stable).join(',')}]`
        : `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stable(value[key])}`).join(',')}}`;
    const digest = require('node:crypto').createHash('sha256').update(stable(envelope.payload), 'utf8').digest('hex');
    assert.equal(envelope.checksum, digest);
    assert.match(result.stdout, /SHA-256:/);
  } finally { fs.rmSync(directory, { recursive: true, force: true }); }
});


test('database update release generator creates a version manifest and refuses overwrite', () => {
  const generator = path.join(root, 'tools/create-database-update-release.cjs');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'amq-database-release-'));
  try {
    const files = writeFixture(directory);
    const outputDirectory = path.join(directory, 'release');
    const keyPair = generateKeyPairSync('ed25519');
    const privateKeyPath = path.join(directory, 'test-signing-key.pem');
    fs.writeFileSync(privateKeyPath, keyPair.privateKey.export({ type: 'pkcs8', format: 'pem' }));
    const result = spawnSync(process.execPath, [generator, files.amqPath, files.emqPath, outputDirectory, '1.2.3', privateKeyPath], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stdout + result.stderr);
    const manifest = JSON.parse(fs.readFileSync(path.join(outputDirectory, 'latest.json'), 'utf8'));
    const bundlePath = path.join(outputDirectory, manifest.bundle.url);
    const bundleBytes = fs.readFileSync(bundlePath);
    assert.equal(manifest.format, 'amq-learning-database-release');
    assert.equal(manifest.releaseVersion, '1.2.3');
    assert.equal(manifest.bundle.byteLength, bundleBytes.length);
    assert.equal(manifest.bundle.sha256, require('node:crypto').createHash('sha256').update(bundleBytes).digest('hex'));
    assert.equal(manifest.bundle.payloadChecksum, JSON.parse(bundleBytes.toString('utf8')).checksum);
    assert.equal(manifest.signature.algorithm, 'Ed25519');
    const unsigned = { ...manifest }; delete unsigned.signature;
    const stable = value => value === null || typeof value !== 'object' ? JSON.stringify(value)
      : Array.isArray(value) ? `[${value.map(stable).join(',')}]`
        : `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stable(value[key])}`).join(',')}}`;
    assert.equal(require('node:crypto').verify(null, Buffer.from(stable(unsigned)), keyPair.publicKey, Buffer.from(manifest.signature.value, 'base64')), true);
    const publicKeyPath = path.join(directory, 'test-signing-public.pem');
    fs.writeFileSync(publicKeyPath, keyPair.publicKey.export({ type: 'spki', format: 'pem' }));
    const verifier = path.join(root, 'tools/verify-database-update-release.cjs');
    const verifyResult = spawnSync(process.execPath, [verifier, outputDirectory, publicKeyPath], { encoding: 'utf8' });
    assert.equal(verifyResult.status, 0, verifyResult.stdout + verifyResult.stderr);
    assert.equal(JSON.parse(verifyResult.stdout).status, 'PASS');
    const repeat = spawnSync(process.execPath, [generator, files.amqPath, files.emqPath, outputDirectory, '1.2.3', privateKeyPath], { encoding: 'utf8' });
    assert.notEqual(repeat.status, 0);
    assert.match(repeat.stderr, /refusing to overwrite/);
  } finally { fs.rmSync(directory, { recursive: true, force: true }); }
});

test('database update release generator rejects a non-Ed25519 signing key before creating output artifacts', () => {
  const generator = path.join(root, 'tools/create-database-update-release.cjs');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'amq-database-release-invalid-key-'));
  try {
    const files = writeFixture(directory);
    const key = require('node:crypto').generateKeyPairSync('rsa', { modulusLength: 2048 });
    const privateKeyPath = path.join(directory, 'wrong-key.pem');
    fs.writeFileSync(privateKeyPath, key.privateKey.export({ type: 'pkcs8', format: 'pem' }));
    const outputDirectory = path.join(directory, 'release');
    const result = spawnSync(process.execPath, [generator, files.amqPath, files.emqPath, outputDirectory, '1.2.3', privateKeyPath], { encoding: 'utf8' });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /must be an Ed25519 private key/);
    assert.equal(fs.existsSync(outputDirectory), false);
  } finally { fs.rmSync(directory, { recursive: true, force: true }); }
});


test('signing-key generator creates a private Ed25519 key without overwriting existing keys', () => {
  const generator = path.join(root, 'tools/create-database-update-signing-key.cjs');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'amq-signing-key-'));
  try {
    const privatePath = path.join(directory, 'keys', 'release-private.pem');
    const result = spawnSync(process.execPath, [generator, privatePath], { encoding: 'utf8' });
    assert.equal(result.status, 0, result.stdout + result.stderr);
    assert.match(result.stdout, /Public key \(SPKI DER Base64\):/);
    assert.match(result.stdout, /Key ID: [a-f0-9]{16}/);
    assert.match(fs.readFileSync(privatePath, 'utf8'), /BEGIN PRIVATE KEY/);
    assert.equal(fs.statSync(privatePath).mode & 0o777, 0o600);
    const repeat = spawnSync(process.execPath, [generator, privatePath], { encoding: 'utf8' });
    assert.notEqual(repeat.status, 0);
    assert.match(repeat.stderr, /refusing to overwrite/);
  } finally { fs.rmSync(directory, { recursive: true, force: true }); }
});

test('release verifier rejects a modified bundle even when the signed manifest remains unchanged', () => {
  const generator = path.join(root, 'tools/create-database-update-release.cjs');
  const verifier = path.join(root, 'tools/verify-database-update-release.cjs');
  const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'amq-release-verify-tamper-'));
  try {
    const files = writeFixture(directory);
    const pair = require('node:crypto').generateKeyPairSync('ed25519');
    const privatePath = path.join(directory, 'private.pem');
    const publicPath = path.join(directory, 'public.pem');
    fs.writeFileSync(privatePath, pair.privateKey.export({ type: 'pkcs8', format: 'pem' }));
    fs.writeFileSync(publicPath, pair.publicKey.export({ type: 'spki', format: 'pem' }));
    const output = path.join(directory, 'release');
    const created = spawnSync(process.execPath, [generator, files.amqPath, files.emqPath, output, '1.0.0', privatePath], { encoding: 'utf8' });
    assert.equal(created.status, 0, created.stdout + created.stderr);
    const manifest = JSON.parse(fs.readFileSync(path.join(output, 'latest.json'), 'utf8'));
    fs.appendFileSync(path.join(output, manifest.bundle.url), ' ');
    const result = spawnSync(process.execPath, [verifier, output, publicPath], { encoding: 'utf8' });
    assert.notEqual(result.status, 0);
    assert.match(result.stderr, /byte length mismatch|SHA-256 mismatch/);
  } finally { fs.rmSync(directory, { recursive: true, force: true }); }
});
