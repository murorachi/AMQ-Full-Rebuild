'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sandbox = { window: {} }; vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/learning/assessment-engine.js'), 'utf8'), sandbox);
const assess = sandbox.window.AMQLearning.assessmentEngine.assess;
const result = (correct, elapsedSeconds, extra = {}) => ({ kind: 'answered', target: 'anime', correct, elapsedSeconds, ...extra });
for (const [seconds, grade] of [[0,4],[5,4],[10,4],[10.01,3],[11,3],[15,3],[15.01,2],[30,2]]) {
  const got = assess(result(true, seconds), 'anime');
  assert.equal(got.grade, grade, `${seconds}s should map to grade ${grade}`);
}
assert.equal(assess(result(false, 1), 'anime').grade, 1);
assert.equal(assess(result(true, 1), 'title').grade, null, 'song-title answers must not affect work-title SRS');
assert.equal(assess(result(true, 1), 'artist').grade, null, 'artist answers must not affect work-title SRS');
assert.equal(assess(result(false, 4, { correctByTarget: { anime: true, artist: false, title: false } }), 'all').grade, 4,
  'all-target rating is based only on the work title');
assert.equal(assess(result(true, 4, { correctByTarget: { anime: false, artist: true, title: true } }), 'all').grade, 1,
  'correct artist/song cannot compensate for a wrong work title');
assert.equal(assess(result(true, null), 'anime').grade, null);
assert.equal(assess({ kind: 'revealed', elapsedSeconds: 8, correct: null }, 'anime').grade, null);
assert.equal(assess({ kind: 'unplayed-skip', elapsedSeconds: null }, 'anime').grade, null);
console.log('assessment-engine: 15 assertions passed');
