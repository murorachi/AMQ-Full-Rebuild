const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const test = require('node:test');

const root = path.resolve(__dirname, '..');
const assetPath = path.join(root, 'docs/skin-contract/stable-asset-manifest.v1.json');
const rolePath = path.join(root, 'docs/skin-contract/amq-skin-role-manifest.v1.json');
const assets = JSON.parse(fs.readFileSync(assetPath, 'utf8'));
const roles = JSON.parse(fs.readFileSync(rolePath, 'utf8'));

test('skin manifests declare supported schema versions and non-empty inventories', () => {
  assert.equal(assets.schemaVersion, 1);
  assert.equal(roles.schemaVersion, 1);
  assert.ok(assets.assets.length > 0);
  assert.ok(roles.roles.length > 0);
  assert.equal(assets.status, 'initial-reviewed-subset-not-complete');
  assert.match(roles.status, /^runtime-mapping-studio-wired; 48 roles have runtime selectors;/);
});

test('stable asset IDs and AMQ role IDs are unique and well-formed', () => {
  const assetIds = assets.assets.map(asset => asset.id);
  const roleIds = roles.roles.map(role => role.id);
  assert.equal(new Set(assetIds).size, assetIds.length);
  assert.equal(new Set(roleIds).size, roleIds.length);
  for (const asset of assets.assets) {
    assert.match(asset.id, /^stable\.[a-z0-9.-]+$/);
    assert.ok(Array.isArray(asset.filenames) && asset.filenames.length > 0, asset.id);
    assert.ok(asset.category && asset.purpose && asset.fallback, asset.id);
    assert.ok(['exact', 'exact-optional', 'exact-when-present', 'derived-stateful', 'exact-state-pair', 'exact-stretch-rule', 'exact-only-if-semantic-match', 'optional-effect'].includes(asset.mappingPolicy), asset.id);
  }
  for (const role of roles.roles) {
    assert.match(role.id, /^[a-z][a-z0-9.-]+$/);
    assert.ok(role.page && role.label && role.fallback, role.id);
    assert.equal(typeof role.required, 'boolean', role.id);
  }
});

test('every role stable asset reference resolves to a declared asset', () => {
  const ids = new Set(assets.assets.map(asset => asset.id));
  for (const role of roles.roles) {
    for (const assetId of role.stableAssets) assert.ok(ids.has(assetId), `${role.id} references missing ${assetId}`);
  }
});

test('each stable asset role reference resolves to a declared AMQ role', () => {
  const ids = new Set(roles.roles.map(role => role.id));
  for (const asset of assets.assets) {
    for (const roleId of asset.amqRoles) assert.ok(ids.has(roleId), `${asset.id} references missing ${roleId}`);
  }
});

test('required roles have explicit fallback and song artwork is not inferred from OSK character art', () => {
  for (const role of roles.roles.filter(item => item.required)) assert.ok(role.fallback.trim().length > 0, role.id);
  const artwork = roles.roles.find(role => role.id === 'catalog.song-artwork');
  assert.ok(artwork);
  assert.match(artwork.fallback, /never infer from random OSK character art/i);
});

test('runtime skin contract matches the documented role and asset manifests', () => {
  const runtime = fs.readFileSync(path.join(root, 'src/skins/skin-contract.js'), 'utf8');
  const runtimeAssets = runtime.match(/const stableAssets = (\[.*?\]);\n const roles = /s);
  const runtimeRoles = runtime.match(/const roles = (\[.*?\]);\n const pages = /s);
  assert.ok(runtimeAssets, 'runtime stable asset manifest is embedded');
  assert.ok(runtimeRoles, 'runtime AMQ role manifest is embedded');
  assert.deepEqual(JSON.parse(runtimeAssets[1]), assets.assets);
  assert.deepEqual(JSON.parse(runtimeRoles[1]), roles.roles);
});

test('each page role has stable UI identity and explicit extension semantics', () => {
  const pageIds = new Set(['home','catalog','quiz','multiplayer','results','learning','settings','shared-player','shared']);
  for (const role of roles.roles) {
    assert.ok(pageIds.has(role.page), `${role.id} has a supported page`);
    assert.ok(role.fallback.trim().length > 0, `${role.id} has a deliberate fallback or extension policy`); assert.doesNotMatch(role.fallback, /TODO|TBD|unknown/i, `${role.id} does not defer its fallback decision`);
  }
});

test('unsupported OSK roles remain explicitly unsupported until semantic DOM and CSS consumers exist', () => {
  const adapter = fs.readFileSync(path.join(root, 'src/skins/theme-adapter.js'), 'utf8');
  const runtimeIds = new Set(Array.from(adapter.matchAll(/^    "([^"]+)": \{ selector:/gm), match => match[1]));
  const unsupported = roles.roles.filter(role => !runtimeIds.has(role.id)).map(role => role.id).sort();
  assert.equal(runtimeIds.size, 48, 'the runtime selector inventory stays aligned with the reviewed implementation');
  assert.deepEqual(unsupported, [
    'app.home.ambient-effect', 'app.navigation.options', 'catalog.action.random', 'catalog.difficulty-marker',
    'catalog.song-artwork', 'feedback.success',
    'quiz.result.correct', 'quiz.result.incorrect', 'results.grade',
    'settings.dialog', 'settings.entry', 'settings.slider'
  ]);
  for (const role of roles.roles.filter(item => !runtimeIds.has(item.id))) {
    assert.ok(role.fallback.trim(), `${role.id} must retain a deliberate fallback`);
    assert.doesNotMatch(adapter, new RegExp(role.id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '\\"\\s*:'), `${role.id} must not be claimed by runtime before its real target is reviewed`);
  }
  assert.deepEqual(roles.roles.find(role => role.id === 'catalog.song-artwork').stableAssets, [], 'random OSK character art must not be repurposed as a song cover');
  assert.deepEqual(roles.roles.find(role => role.id === 'quiz.result.correct').stableAssets, ['stable.ranking.grade.a'], 'a documented grade asset remains semantically distinct from AMQ answer correctness');
  assert.ok(runtimeIds.has('results.panel'), 'the real round-result panel has a semantically matching results-panel runtime role');
  assert.ok(runtimeIds.has('results.primary-action'), 'the real results CTA has a dedicated runtime selector and CSS consumer');
  assert.ok(runtimeIds.has('learning.history.item') && runtimeIds.has('learning.review.item'), 'learning history and review roles only become supported with real list containers');
});

test('official stable asset semantics do not leak into unrelated AMQ panels', () => {
  const byAsset = Object.fromEntries(assets.assets.map(asset => [asset.id, asset]));
  const byRole = Object.fromEntries(roles.roles.map(role => [role.id, role]));
  assert.deepEqual(byAsset['stable.menu.button.background'].amqRoles, ['catalog.item.background', 'catalog.item.selected']);
  assert.deepEqual(byAsset['stable.songselect.bottom'].amqRoles, ['catalog.frame.bottom']);
  for (const id of ['catalog.song-detail.panel', 'player.dock.background', 'multiplayer.room.panel', 'learning.progress.panel', 'settings.panel']) {
    assert.deepEqual(byRole[id].stableAssets, [], `${id} must remain an AMQ extension role without a verified stable asset equivalent`);
  }
  assert.match(byRole['catalog.song-artwork'].fallback, /never infer from random OSK character art/i);
});

test('Batch240 traceability separates AMQ runtime wiring from native stable renderer support', () => {
  const matrix = fs.readFileSync(path.join(__dirname, '../docs/AMQ_VISUAL_NEEDS_TRACEABILITY_BATCH240.md'), 'utf8');
  assert.match(matrix, /Runtime selector/);
  assert.match(matrix, /CSS token consumer/);
  assert.match(matrix, /catalog\.frame\.top[\s\S]*unsupported: native edge-repeat not implemented/);
  assert.match(matrix, /catalog\.song-artwork[\s\S]*unsupported/);
  assert.match(matrix, /app\.navigation\.options/);
  assert.match(matrix, /theme schema v4/);
});

test('Batch241 pixel contracts are loaded before the shared renderer and do not claim native fidelity', () => {
  const html = fs.readFileSync(path.join(root, 'src/index.html'), 'utf8');
  const blendAt = html.indexOf('skins/skin-blend.js');
  const edgeAt = html.indexOf('skins/skin-edge-repeat.js');
  const rendererAt = html.indexOf('skins/skin-renderer.js');
  assert.ok(blendAt >= 0 && edgeAt >= 0 && rendererAt >= 0);
  assert.ok(blendAt < rendererAt && edgeAt < rendererAt, 'pixel helpers must load before renderer binds their API');
  const renderer = fs.readFileSync(path.join(root, 'src/skins/skin-renderer.js'), 'utf8');
  assert.match(renderer, /nativeStableFidelity:\s*Object\.freeze\(\{\s*multiplicativeTint:\s*false,\s*songselectTopEdgeRepeat:\s*false/s);
  assert.match(renderer, /multiply-rgba-contract-v1/);
  assert.match(renderer, /explicit-right-edge-repeat-rgba-v1/);
});


test('Batch242 Canvas renderer loads before shared renderer and keeps native fidelity unsupported', () => {
  const html = fs.readFileSync(path.join(root, 'src/index.html'), 'utf8');
  const canvasAt = html.indexOf('skins/skin-canvas-renderer.js');
  const rendererAt = html.indexOf('skins/skin-renderer.js');
  assert.ok(canvasAt >= 0 && canvasAt < rendererAt, 'Canvas integration must load before shared renderer');
  const canvas = fs.readFileSync(path.join(root, 'src/skins/skin-canvas-renderer.js'), 'utf8');
  assert.match(canvas, /decodeImageBlob/);
  assert.match(canvas, /renderBlobToCanvas/);
  assert.match(canvas, /nativeStableFidelity:\s*false/);
  assert.match(canvas, /SKIN_IMAGE_PIXEL_LIMIT_EXCEEDED/);
});
