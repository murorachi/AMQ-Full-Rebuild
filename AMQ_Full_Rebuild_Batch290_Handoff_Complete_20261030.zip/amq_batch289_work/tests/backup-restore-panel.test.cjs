'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');

class Element {
  constructor(id = '') { this.id = id; this.listeners = new Map(); this.children = []; this.dataset = {}; this.attributes = {}; this.hidden = false; this.disabled = false; this.textContent = ''; this.files = []; this.value = ''; this.clicked = 0; }
  addEventListener(name, handler) { if (!this.listeners.has(name)) this.listeners.set(name, new Set()); this.listeners.get(name).add(handler); }
  removeEventListener(name, handler) { this.listeners.get(name)?.delete(handler); }
  async dispatch(name) { for (const handler of this.listeners.get(name) || []) await handler({ target: this }); }
  setAttribute(name, value) { this.attributes[name] = value; }
  replaceChildren(...children) { this.children = [...children]; }
  append(...children) { this.children.push(...children); }
  appendChild(child) { this.children.push(child); return child; }
  click() { this.clicked += 1; }
  remove() { this.removed = true; }
}
function createHarness({ service, confirm = () => true } = {}) {
  const ids = ['backup-export', 'backup-file', 'backup-preflight', 'backup-restore', 'backup-status', 'backup-preview', 'backup-file-name'];
  const elements = Object.fromEntries(ids.map(id => [id, new Element(id)]));
  const body = new Element('body');
  const document = { getElementById: id => elements[id] || null, createElement: tag => new Element(tag), body };
  const window = { document, AMQPersistence: { backupRestore: { createBackupRestore: () => service } }, confirm, crypto: {}, URL: { createObjectURL: () => 'blob:test', revokeObjectURL() {} }, setTimeout(fn) { fn(); return 1; }, Blob: class Blob { constructor(parts, options) { this.parts = parts; this.options = options; } } };
  const sandbox = { window, document, console, setTimeout, clearTimeout };
  vm.createContext(sandbox);
  vm.runInContext(fs.readFileSync(path.join(root, 'src/ui/backup-restore-panel.js'), 'utf8'), sandbox);
  const controller = window.AMQUI.backupRestorePanel.createBackupRestorePanel({ document, api: window.AMQPersistence.backupRestore, storage: {}, confirm, makeBlob: (parts, options) => ({ parts, options }), createObjectURL: () => 'blob:test', revokeObjectURL() {} });
  return { elements, controller, window, body };
}
(async () => {
  {
    const service = { exportBackup: async () => ({ ok: false, reason: 'invalid-stored-data' }), preflight: async () => ({ ok: false }), restoreBackup: async () => ({ ok: false }) };
    const h = createHarness({ service });
    assert.equal(h.controller.ok, true);
    assert.equal(h.window.AMQUI.backupRestorePanel.keyLabels.amqSongTagsV1, '歌曲標籤與歌曲關聯', 'song tags are visible by a human-readable name in preflight preview');
    await h.elements['backup-export'].dispatch('click');
    assert.match(h.elements['backup-status'].textContent, /備份匯出失敗/);
    assert.equal(h.elements['backup-status'].dataset.state, 'error');
    h.controller.dispose();
    console.log('PASS backup panel initializes, exposes accessible status, and surfaces export errors');
  }
  {
    let writes = 0;
    const service = {
      exportBackup: async () => ({ ok: true, backup: { createdAt: '2026-10-27T00:00:00.000Z' } }),
      preflight: async () => ({ ok: true, formatVersion: 1, keys: ['aniBlacklistedSongs_v1'], backup: { format: 'amq-learning-tool-backup' } }),
      restoreBackup: async () => { writes += 1; return { ok: true, restoredKeys: ['aniBlacklistedSongs_v1'] }; }
    };
    const h = createHarness({ service, confirm: () => false });
    const file = { name: 'backup.json', size: 12, text: async () => '{"backup":true}' };
    h.elements['backup-file'].files = [file];
    await h.elements['backup-file'].dispatch('change');
    await h.elements['backup-preflight'].dispatch('click');
    assert.equal(h.elements['backup-restore'].disabled, false);
    assert.match(JSON.stringify(h.elements['backup-preview'].children.map(x => ({ text: x.textContent, children: x.children.map(c => c.textContent) }))), /歌曲黑名單/);
    await h.elements['backup-restore'].dispatch('click');
    assert.equal(writes, 0, 'cancelled restore must not write');
    assert.match(h.elements['backup-status'].textContent, /已取消還原/);
    h.controller.dispose();
    console.log('PASS restore requires a successful preflight and explicit confirmation; cancellation performs no writes');
  }
  {
    const service = {
      exportBackup: async () => ({ ok: true, backup: { createdAt: '2026-10-27T00:00:00.000Z' } }),
      preflight: async () => ({ ok: true, formatVersion: 1, keys: ['aniBlacklistedSongs_v1', 'aniAnimeWatch_v1'], backup: { format: 'amq-learning-tool-backup' } }),
      restoreBackup: async () => ({ ok: false, phase: 'commit', reason: 'quota exceeded', rolledBack: false, rollbackErrors: [{ key: 'aniAnimeWatch_v1' }] })
    };
    const h = createHarness({ service, confirm: () => true });
    h.elements['backup-file'].files = [{ name: 'backup.json', size: 12, text: async () => '{}' }];
    await h.elements['backup-file'].dispatch('change');
    await h.elements['backup-preflight'].dispatch('click');
    await h.elements['backup-restore'].dispatch('click');
    assert.match(h.elements['backup-status'].textContent, /無法確認完整回滾/);
    assert.match(h.elements['backup-status'].textContent, /aniAnimeWatch_v1/);
    assert.equal(h.elements['backup-status'].dataset.state, 'error');
    h.controller.dispose();
    console.log('PASS persistent rollback failure is shown as a severe data-integrity warning');
  }
  {
    let downloaded = null;
    const service = { exportBackup: async () => ({ ok: true, backup: { createdAt: '2026-10-27T00:00:00.000Z', format: 'amq-learning-tool-backup' } }), preflight: async () => ({ ok: false }), restoreBackup: async () => ({ ok: false }) };
    const h = createHarness({ service });
    h.controller.dispose();
    const ids = ['backup-export', 'backup-file', 'backup-preflight', 'backup-restore', 'backup-status', 'backup-preview', 'backup-file-name'];
    const elements = Object.fromEntries(ids.map(id => [id, new Element(id)]));
    const body = new Element('body');
    let downloadAnchor = null;
    const document = { getElementById: id => elements[id] || null, createElement: tag => { const node = new Element(tag); if (tag === 'a') downloadAnchor = node; return node; }, body };
    const api = { createBackupRestore: () => service };
    const panel = h.window.AMQUI.backupRestorePanel.createBackupRestorePanel({ document, api, storage: {}, confirm: () => true,
      makeBlob: (parts, options) => { downloaded = { parts, options }; return { parts, options }; },
      createObjectURL: () => 'blob:download', revokeObjectURL() {} });
    await elements['backup-export'].dispatch('click');
    assert.ok(downloaded);
    assert.equal(downloaded.options.type, 'application/json;charset=utf-8');
    assert.ok(downloadAnchor && downloadAnchor.clicked === 1, 'export must click a download anchor');
    assert.match(downloadAnchor.download, /\.json$/);
    assert.match(elements['backup-status'].textContent, /開始下載/);
    panel.dispose();
    console.log('PASS successful export builds a JSON download and reports completion');
  }
  {
    let restored = false;
    const service = {
      exportBackup: async () => ({ ok: false }),
      preflight: async () => ({ ok: true, formatVersion: 1, keys: ['aniAnimeWatch_v1'], backup: { format: 'amq-learning-tool-backup' } }),
      restoreBackup: async () => { restored = true; return { ok: true, restoredKeys: ['aniAnimeWatch_v1'] }; }
    };
    const h = createHarness({ service, confirm: () => true });
    h.elements['backup-file'].files = [{ name: 'restore.json', size: 8, text: async () => '{"valid":true}' }];
    await h.elements['backup-file'].dispatch('change');
    await h.elements['backup-preflight'].dispatch('click');
    await h.elements['backup-restore'].dispatch('click');
    assert.equal(restored, true);
    assert.equal(h.elements['backup-restore'].disabled, true);
    assert.match(h.elements['backup-status'].textContent, /請重新載入頁面/);
    h.controller.dispose();
    console.log('PASS successful restore reports restored item count and reload requirement');
  }
  {
    const service = { exportBackup: async () => ({ ok: true, backup: { createdAt: '2026-10-27T00:00:00.000Z' } }), preflight: async () => ({ ok: false, reason: 'checksum-mismatch' }), restoreBackup: async () => ({ ok: false }) };
    const h = createHarness({ service });
    h.elements['backup-file'].files = [{ name: 'tampered.json', size: 12, text: async () => '{}' }];
    await h.elements['backup-file'].dispatch('change');
    await h.elements['backup-preflight'].dispatch('click');
    assert.equal(h.elements['backup-restore'].disabled, true);
    assert.match(h.elements['backup-status'].textContent, /未修改任何資料/);
    h.controller.dispose();
    console.log('PASS failed preflight keeps restore disabled and explicitly reports no data mutation');
  }
  {
    let resolveOldPreflight;
    const oldPreflight = new Promise(resolve => { resolveOldPreflight = resolve; });
    const service = {
      exportBackup: async () => ({ ok: false }),
      preflight: input => input === 'backup-A' ? oldPreflight : Promise.resolve({ ok: true, formatVersion: 1, keys: ['aniAnimeWatch_v1'], backup: { format: 'amq-learning-tool-backup', marker: 'B' } }),
      restoreBackup: async backup => ({ ok: true, restoredKeys: [backup.marker] })
    };
    const h = createHarness({ service });
    h.elements['backup-file'].files = [{ name: 'backup-A.json', size: 10, text: async () => 'backup-A' }];
    await h.elements['backup-file'].dispatch('change');
    const pendingOldPreflight = h.elements['backup-preflight'].dispatch('click');
    h.elements['backup-file'].files = [{ name: 'backup-B.json', size: 10, text: async () => 'backup-B' }];
    await h.elements['backup-file'].dispatch('change');
    resolveOldPreflight({ ok: true, formatVersion: 1, keys: ['aniBlacklistedSongs_v1'], backup: { format: 'amq-learning-tool-backup', marker: 'A' } });
    await pendingOldPreflight;
    assert.equal(h.elements['backup-restore'].disabled, true, 'stale preflight from backup A must not enable restore after selecting backup B');
    assert.equal(h.elements['backup-preflight'].disabled, false, 'selecting backup B must re-enable preflight after the old request becomes stale');
    assert.match(h.elements['backup-status'].textContent, /請執行預檢/);
    assert.equal(h.elements['backup-file-name'].textContent, 'backup-B.json');
    h.controller.dispose();
    console.log('PASS stale asynchronous preflight cannot overwrite state after a newer backup file is selected');
  }
  {
    let resolveRestore;
    let restoreCalls = 0;
    const firstRestore = new Promise(resolve => { resolveRestore = resolve; });
    const service = {
      exportBackup: async () => ({ ok: false }),
      preflight: async input => ({ ok: true, formatVersion: 1, keys: ['aniAnimeWatch_v1'], backup: { format: 'amq-learning-tool-backup', marker: input } }),
      restoreBackup: async backup => { restoreCalls += 1; return backup.marker === 'backup-A' ? firstRestore : { ok: true, restoredKeys: ['backup-B'] }; }
    };
    const h = createHarness({ service });
    h.elements['backup-file'].files = [{ name: 'backup-A.json', size: 10, text: async () => 'backup-A' }];
    await h.elements['backup-file'].dispatch('change');
    await h.elements['backup-preflight'].dispatch('click');
    const pendingRestore = h.elements['backup-restore'].dispatch('click');
    assert.equal(restoreCalls, 1);
    assert.equal(h.elements['backup-file'].disabled, true, 'file selection must be locked during a restore commit');
    h.elements['backup-file'].files = [{ name: 'backup-B.json', size: 10, text: async () => 'backup-B' }];
    await h.elements['backup-file'].dispatch('change');
    await h.elements['backup-preflight'].dispatch('click');
    assert.equal(h.elements['backup-restore'].disabled, true, 'preflight must not re-enable restore while another restore is in progress');
    await h.elements['backup-restore'].dispatch('click');
    assert.equal(restoreCalls, 1, 'a second restore must not start concurrently');
    resolveRestore({ ok: true, restoredKeys: ['backup-A'] });
    await pendingRestore;
    assert.equal(h.elements['backup-file'].disabled, false);
    assert.equal(h.elements['backup-restore'].disabled, true, 'successful restore clears the preflight result');
    assert.match(h.elements['backup-status'].textContent, /請重新載入頁面/);
    h.controller.dispose();
    console.log('PASS restore operation locks file selection and prevents concurrent restore/preflight races');
  }
  console.log('Backup/restore panel tests: 8/8 passed');
})().catch(error => { console.error(error); process.exitCode = 1; });
