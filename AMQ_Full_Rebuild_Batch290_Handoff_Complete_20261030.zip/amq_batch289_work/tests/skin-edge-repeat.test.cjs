'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const window = {};
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/skins/skin-edge-repeat.js'), 'utf8'), { window, Object, Number, Uint8ClampedArray });
const edge = window.AMQSkins.skinEdgeRepeat;
test('right edge extension repeats only the explicitly selected trailing columns', () => {
  const source = [10,0,0,255, 20,0,0,255, 30,0,0,255];
  const result = edge.extendRightEdgeRgba(source, 3, 1, 7, 1);
  assert.deepEqual(Array.from(result).filter((_, i) => i % 4 === 0), [10,20,30,30,30,30,30]);
});
test('multi-column edge segment repeats in source order for each row', () => {
  const source = [1,0,0,255, 2,0,0,255, 3,0,0,255, 4,0,0,255, 5,0,0,255, 6,0,0,255];
  const result = edge.extendRightEdgeRgba(source, 3, 2, 5, 2);
  assert.deepEqual(Array.from(result).filter((_, i) => i % 4 === 0), [1,2,3,2,3,4,5,6,5,6]);
});
test('narrow targets crop without changing source pixel order', () => {
  const source = [1,0,0,255, 2,0,0,255, 3,0,0,255];
  assert.deepEqual(Array.from(edge.extendRightEdgeRgba(source, 3, 1, 2, 1)).filter((_, i) => i % 4 === 0), [1,2]);
});
test('invalid dimensions and edge widths fail closed', () => {
  assert.equal(edge.extendRightEdgeRgba([1,2,3,4], 1, 1, 2, 2), null);
  assert.equal(edge.extendRightEdgeRgba([1,2,3], 1, 1, 2, 1), null);
});
test('edge extension refuses output allocations above the configured pixel budget', () => {
  const source = [1,2,3,4, 5,6,7,8];
  assert.equal(edge.extendRightEdgeRgba(source, 2, 1, 10, 1, 4), null);
});
test('edge extension rejects unsafe integers, 32-bit byte lengths and multiplication overflow before allocation', () => {
  const source = new Uint8Array([1,2,3,4]);
  for (const dims of [
    [Number.MAX_SAFE_INTEGER + 1, 1, 1, 1],
    [1, Number.MAX_SAFE_INTEGER + 1, 1, 1],
    [0x40000000, 1, 0x40000000, 1],
    [1, 0x40000000, 1, 1],
    [-1, 1, 1, 1], [1, 0, 1, 1], [1.5, 1, 1, 1]
  ]) assert.equal(edge.extendRightEdgeRgba(source, ...dims), null, `reject ${dims.join('x')}`);
});
test('edge extension rejects mismatched typed-array views without coercing allocation', () => {
  assert.equal(edge.extendRightEdgeRgba(new Uint8Array(3), 1, 1, 1, 1), null);
  assert.equal(edge.extendRightEdgeRgba(new Uint8Array(4), 1, 1, 1, 1, 0.5), null);
});
