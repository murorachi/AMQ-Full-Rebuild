'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const window = {};
const sandbox = { window, Date };
vm.createContext(sandbox);
for (const file of ['src/engine/answer-evaluator.js', 'src/learning/assessment-engine.js', 'src/multiplayer/server-answer-assessment.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), sandbox, { filename: file });
}
const factory = window.AMQMultiplayer.serverAnswerAssessment.createServerAnswerAssessor;
const workA = { source: 'AMQ', title: 'Song A', artist: 'Artist A', animeTitle: 'Work A', animeAlternateTitle: 'Alt Work A', workAliases: ['Work Alias'] };
const assessor = factory({ questions: [
  { questionId: 'q-anime', target: 'anime', record: workA },
  { questionId: 'q-all', target: 'all', record: workA },
  { questionId: 'q-title', target: 'title', record: workA },
  { questionId: 'q-artist', target: 'artist', record: workA },
  { questionId: 'q-other', target: 'anime', record: { source: 'EMQ', title: 'Song B', artist: 'Artist B', animeTitle: 'Work B' } }
] });
assert.equal(assessor.ruleVersion, 'work-title-latency-v1');
function assess(submission, context = {}) { return assessor.assessSubmission(submission, context); }
for (const [seconds, grade] of [[0,4],[10,4],[10.01,3],[15,3],[15.01,2]]) {
  const got = assess({ questionId: 'q-anime', answer: 'Work Alias', target: 'title', outcome: 'timeout', correct: false, grade: 1, elapsedSeconds: 999, acceptPartial: true },
    { outcome: 'answered', startedAt: 1000, receivedAt: 1000 + seconds * 1000 });
  assert.equal(got.assessment.grade, grade, `server-derived ${seconds}s title answer should grade ${grade}`);
  assert.equal(got.isWorkTitleCorrect, true);
  assert.equal(got.target, 'anime', 'target comes from trusted server question configuration, not submission');
}
assert.equal(assess({ questionId: 'q-all', answers: { anime: 'Work A', title: 'wrong song', artist: 'wrong artist' } },
  { outcome: 'answered', startedAt: 1000, receivedAt: 5000 }).assessment.grade, 4,
  'all target assesses only the work title');
assert.equal(assess({ questionId: 'q-all', answers: { anime: 'wrong', title: 'Song A', artist: 'Artist A' } },
  { outcome: 'answered', startedAt: 1000, receivedAt: 2000 }).assessment.grade, 1,
  'correct song title and artist cannot compensate for wrong work title');
assert.equal(assess({ questionId: 'q-anime', answer: 'Work A', outcome: 'answered', correct: true, grade: 4 },
  { outcome: 'timeout', startedAt: 1000, receivedAt: 15000 }).assessment.grade, 1,
  'client claims cannot override a server timeout');
assert.equal(assess({ questionId: 'q-anime', answer: 'Work A' }, { outcome: 'revealed', startedAt: 1000, receivedAt: 2000 }).assessment.grade, null);
assert.equal(assess({ questionId: 'q-anime', answer: 'Work A' }, { outcome: 'unplayed-skip' }).assessment.grade, null);
assert.equal(assess({ questionId: 'q-anime', answer: 'Work A' }, { outcome: 'cancelled' }).assessment.grade, null);
assert.equal(assess({ questionId: 'q-title', answer: 'Song A' }, { outcome: 'answered', startedAt: 1000, receivedAt: 2000 }).assessment.grade, null,
  'song title target must not receive work-title SRS rating');
assert.equal(assess({ questionId: 'q-artist', answer: 'Artist A' }, { outcome: 'answered', startedAt: 1000, receivedAt: 2000 }).assessment.grade, null,
  'artist target must not receive work-title SRS rating');
assert.equal(assess({ questionId: 'q-anime', answer: 'Work A' }, { outcome: 'answered' }).assessment.grade, null,
  'correct answer without trusted latency cannot be graded');
assert.throws(() => assess({ questionId: 'client-invented', answer: 'Work A' }, { outcome: 'answered' }), error => error.code === 'ASSESSMENT_QUESTION_UNKNOWN');
assert.throws(() => assess({ questionId: 'q-anime', answer: 'Work A' }, { outcome: 'answered', startedAt: 2000, receivedAt: 1000 }), error => error.code === 'ASSESSMENT_TIME_INVALID');
assert.throws(() => assess({ questionId: 'q-anime', answer: 'Work A' }), error => error.code === 'ASSESSMENT_OUTCOME_INVALID');
assert.throws(() => factory({ questions: [{ questionId: 'same', target: 'anime', record: {} }, { questionId: 'same', target: 'anime', record: {} }] }), error => error.code === 'ASSESSMENT_QUESTION_DUPLICATE');
assert.throws(() => factory({ questions: [{ questionId: 'no-target', record: {} }] }), error => error.code === 'ASSESSMENT_TARGET_INVALID');
console.log('multiplayer-server-answer-assessment: PASS (server-derived title-only grading, trusted context, spoof resistance, no-grade outcomes)');
