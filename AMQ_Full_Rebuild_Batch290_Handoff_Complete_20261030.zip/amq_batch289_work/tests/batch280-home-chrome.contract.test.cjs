const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const shell = fs.readFileSync(path.join(root, 'src/ui/app-shell.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'src/styles/ui-design-landing.css'), 'utf8');

test('Home route removes global header and route rail while feature routes restore navigation', () => {
  assert.match(shell, /nav\.hidden\s*=\s*pageId\s*===\s*"home"/);
  assert.match(shell, /shellHeader\.hidden\s*=\s*true/);
  assert.match(shell, /nav\.appendChild\(routeStatus\)/);
  assert.match(shell, /document\.body\.dataset\.currentPage\s*=\s*pageId/);
  assert.match(css, /\.app-header\[hidden\],\s*#app-shell-nav\[hidden\]\s*\{\s*display:none\s*!important/);
});

test('Home uses full viewport with no top rail, side rail, or bottom history panel', () => {
  assert.match(css, /main\s*\{\s*grid-column:1;\s*grid-row:2;[^}]*padding:0/s);
  assert.match(css, /#page-home\s*\.home-recent\s*\{\s*display:none/);
  assert.match(css, /#page-home\s*\.home-dashboard\s*\{[^}]*grid-template-rows:minmax\(0,1fr\)/s);
});

test('Catalog fixed player dock no longer reserves the removed side navigation rail', () => {
  assert.match(css, /#page-catalog\s+#free-player-dock\s*\{\s*left:12px;\s*right:12px;/);
});

test('Recent history safely handles nullish metadata and exposes stable skin component targets', () => {
  assert.match(shell, /function displayText\(value\)/);
  assert.match(shell, /\^\(\?:null\|undefined\|nan\)\$/i);
  assert.match(shell, /home\.recent\.item/);
  assert.match(shell, /home\.recent\.artwork/);
  assert.match(shell, /home\.recent\.title/);
});

test('Home recent entries remain semantic keyboard-operable buttons with visible focus treatment', () => {
  assert.match(shell, /item\.type\s*=\s*"button"/);
  assert.match(css, /#page-home \.home-recent-item:focus-visible\s*\{[^}]*outline:2px solid/s);
  assert.match(css, /#page-home \.home-recent-copy strong\s*\{[^}]*-webkit-line-clamp:2/s);
});

test('Home brand uses an original note-question icon instead of the AMQ wordmark', () => {
  assert.match(shell, /class="home-brand-mark"[^>]*role="img" aria-label="AMQ 音樂問號標誌"/);
  assert.doesNotMatch(shell, /class="home-brand-mark"[^>]*>AMQ</);
  assert.match(shell, /class="app-brand-icon" data-skin-component="home.logo"/);
  assert.match(css, /background-image:\s*var\(--amq-skin-role-app-home-logo, url\("\.\.\/assets\/amq-note-question\.png"\)\)/);
  assert.ok(fs.existsSync(path.join(root, 'src/assets/amq-note-question.png')));
});
