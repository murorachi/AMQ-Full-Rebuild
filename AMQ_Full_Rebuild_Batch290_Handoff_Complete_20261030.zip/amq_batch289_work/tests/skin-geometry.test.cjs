'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const window = {};
vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/skins/skin-geometry.js'), 'utf8'), { window, Object, String, RegExp });
const geometry = window.AMQSkins.skinGeometry;
test('native background uses center cover and documents crop behavior', () => {
  const rule = geometry.describe('app.home.background', 'menu-background.jpg');
  assert.equal(rule.mode, 'cover');
  assert.equal(rule.anchor, 'center center');
  assert.match(rule.note, /保留比例、裁切超出部分/);
});
test('top and bottom song-select frames keep different geometry contracts', () => {
  assert.equal(geometry.describe('catalog.frame.top', 'songselect-top.png').mode, 'repeat-x');
  assert.equal(geometry.describe('catalog.frame.bottom', 'songselect-bottom.png').mode, 'stretch-x');
});
test('stateful button and semantic extension roles are not treated as generic images', () => {
  assert.equal(geometry.describe('catalog.item.background', 'menu-button-background.png').mode, 'stateful-panel');
  assert.equal(geometry.describe('catalog.song-artwork', 'character-front.png').mode, 'semantic-block');
  assert.equal(geometry.describe('player.dock.background', 'songselect-bottom.png').mode, 'semantic-block');
});
test('high-density and hover state filenames surface additional requirements', () => {
  assert.match(geometry.describe('catalog.item.selected', 'selection-bar@2x.png').versionNote, /高密度/);
  assert.match(geometry.describe('settings.entry', 'selection-options-over.png').versionNote, /hover/);
});
test('all documented geometry rules have explicit fit and anchor semantics', () => {
  for (const [id, rule] of Object.entries(geometry.rules)) {
    assert.ok(rule.mode, `${id} mode`);
    assert.ok(rule.anchor, `${id} anchor`);
    assert.ok(rule.label, `${id} label`);
    assert.ok(rule.note, `${id} note`);
  }
});
