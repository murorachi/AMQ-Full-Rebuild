#!/usr/bin/env python3
"""Route-aware production DOM Skin role apply/fallback/reset and visible-state matrix."""
from pathlib import Path
import json, re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
OUT = ROOT / 'artifacts' / 'batch257-regression'
OUT.mkdir(parents=True, exist_ok=True)
html = (SRC / 'index.html').read_text(encoding='utf-8')
def inline_css(m): return '<style>\n' + (SRC / m.group(1)).read_text(encoding='utf-8') + '\n</style>'
def inline_js(m): return '<script>\n' + (SRC / m.group(1)).read_text(encoding='utf-8') + '\n</script>'
html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', inline_css, html)
html = re.sub(r'<script src="([^"]+)" defer></script>', inline_js, html)
html = re.sub(r'<script src="([^"]+)"></script>', inline_js, html)
adapter = (SRC / 'skins/theme-adapter.js').read_text(encoding='utf-8')
block = adapter[adapter.index('  const ROLE_RUNTIME = Object.freeze({'):]
block = block[:block.index('\n  });')]
roles = []
for line in block.splitlines():
    m = re.match(r'\s*"([^"]+)": \{ selector: (.*), token: "([^"]+)" \},?', line)
    if m:
        rid, literal, token = m.groups()
        selector = json.loads(literal) if literal.startswith('"') else literal[1:-1]
        roles.append({'id': rid, 'selector': selector, 'token': token})

checks, failures = 0, []
def check(ok, label):
    global checks
    checks += 1
    print(('PASS ' if ok else 'FAIL ') + label)
    if not ok: failures.append(label)

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox', '--disable-dev-shm-usage'])
    page = browser.new_page(viewport={'width': 1440, 'height': 900}, reduced_motion='reduce')
    errors = []
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.set_content(html, wait_until='domcontentloaded', timeout=60000)
    page.wait_for_timeout(900)
    page.evaluate('''() => { const m=document.createElement('meta');m.name='batch257';document.head.append(m); }''')
    routes = ['home', 'catalog', 'quiz', 'results']
    visible_by_route = {}
    detailed = []
    for route in routes:
        if route == 'catalog' and page.locator('#page-home').is_visible():
            if page.locator('#home-pie-core').get_attribute('aria-expanded') != 'true': page.locator('#home-pie-core').click()
            page.locator('.home-pie-action--catalog').click()
        elif route != 'home':
            page.locator(f'#app-shell-nav [data-nav-page="{route}"]').click()
        page.wait_for_timeout(70)
        route_state = page.evaluate('''route => ({
          route: document.querySelector('main').dataset.currentPage,
          visible: !!document.querySelector('#page-'+route) && getComputedStyle(document.querySelector('#page-'+route)).display !== 'none',
          currentNav: document.querySelector('#app-shell-nav [data-nav-page="'+route+'"]')?.getAttribute('aria-current'),
          focusedId: document.activeElement?.id || '',
          width: innerWidth, scrollWidth: document.documentElement.scrollWidth,
          reducedMotion: matchMedia('(prefers-reduced-motion: reduce)').matches
        })''', route)
        check(route_state['route'] == route and route_state['visible'], f'{route}: actual app route is visible')
        check(route == 'home' or route_state['currentNav'] == 'page', f'{route}: aria-current is synchronized')
        if route != 'home':
            focus_inside = page.evaluate("route => document.querySelector('#page-' + route)?.contains(document.activeElement)", route)
            check(focus_inside, f'{route}: keyboard focus lands inside destination page ({route_state["focusedId"]})')
        check(route_state['width'] == route_state['scrollWidth'] or route_state['scrollWidth'] <= route_state['width'] + 1, f'{route}: no desktop horizontal overflow')
        check(route_state['reducedMotion'], f'{route}: reduced-motion preference reaches runtime')
        role_rows = page.evaluate('''roles => roles.map(r => {
          const nodes=[...document.querySelectorAll(r.selector)];
          const visible=nodes.filter(n=>n.getClientRects().length && getComputedStyle(n).visibility!=='hidden' && !n.closest('[hidden]'));
          return {id:r.id,selector:r.selector,token:r.token,targetCount:nodes.length,visibleCount:visible.length,
            targetTags:visible.slice(0,4).map(n=>({id:n.id||'',tag:n.tagName,page:n.closest('[id^="page-"]')?.id||''}))};
        })''', roles)
        visible_roles = [r for r in role_rows if r['visibleCount']]
        visible_by_route[route] = [r['id'] for r in visible_roles]
        check(len(visible_roles) > 0, f'{route}: at least one Skin role has a visible production target')
        for role in visible_roles:
            result = page.evaluate('''async r => {
              const api=window.AMQSkins.themeAdapter, adapter=api.createThemeAdapter();
              const nodes=[...document.querySelectorAll(r.selector)].filter(n=>n.getClientRects().length && getComputedStyle(n).visibility!=='hidden' && !n.closest('[hidden]'));
              const allNodes=[...document.querySelectorAll(r.selector)];
              const png=Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4z8DwHwAFAAH/iZk9HQAAAABJRU5ErkJggg=='),c=>c.charCodeAt(0));
              const blob=new Blob([png],{type:'image/png'});
              const asset={path:'batch257.png',extension:'png',blob};
              const applied=await adapter.apply({enabled:true,roleMappings:{[r.id]:asset.path},assets:[asset]});
              const appliedOk=applied.roles.includes(r.id)&&nodes.length>0&&nodes.every(n=>n.style.getPropertyValue(r.token).includes('blob:'));
              const mapped=await adapter.apply({enabled:true,roleMappings:{[r.id]:'missing.png'},assets:[]});
              const missingOk=!mapped.roles.includes(r.id)&&mapped.warnings.some(w=>w.startsWith(r.id+':mapped-asset-missing'))&&allNodes.every(n=>!n.style.getPropertyValue(r.token));
              const appliedAgain=await adapter.apply({enabled:true,roleMappings:{[r.id]:asset.path},assets:[asset]});
              const active=nodes.some(n=>n.style.getPropertyValue(r.token)); adapter.reset();
              const resetOk=active&&allNodes.every(n=>!n.style.getPropertyValue(r.token)&&!n.dataset.amqSkinRoleActive);
              const outside=[...document.querySelectorAll('*')].filter(n=>!allNodes.includes(n)&&n.style&&n.style.getPropertyValue(r.token));
              return {id:r.id,appliedOk,missingOk,resetOk,scopeOk:outside.length===0,warnings:applied.warnings.concat(mapped.warnings),targetCount:allNodes.length,visibleCount:nodes.length};
            }''', role)
            ok = result['appliedOk'] and result['missingOk'] and result['resetOk'] and result['scopeOk']
            check(ok, f'{route}: {role["id"]} apply/missing-fallback/reset/scope')
            detailed.append({'route':route,**result})
        page.screenshot(path=str(OUT / f'{route}-visible-state.png'), full_page=False)
    page.set_viewport_size({'width':390,'height':844})
    mobile = {}
    for route in routes:
        if route == 'home':
            page.keyboard.press('Alt+ArrowLeft')
        elif route == 'catalog' and page.locator('#page-home').is_visible():
            if page.locator('#home-pie-core').get_attribute('aria-expanded') != 'true': page.locator('#home-pie-core').click()
            page.locator('.home-pie-action--catalog').click()
        else:
            page.locator(f'#app-shell-nav [data-nav-page="{route}"]').click()
        page.wait_for_timeout(40)
        data = page.evaluate('''route=>({route:document.querySelector('main').dataset.currentPage,width:innerWidth,scrollWidth:document.documentElement.scrollWidth,focusId:document.activeElement?.id||'',navCurrent:document.querySelector('#app-shell-nav [data-nav-page="'+route+'"]')?.getAttribute('aria-current')})''',route)
        mobile[route]=data
        check(data['route']==route and data['scrollWidth']<=data['width']+1, f'{route}: 390px route has no horizontal overflow')
        check(route == 'home' or data['navCurrent']=='page', f'{route}: 390px aria-current remains synchronized')
    check(not errors, f'no uncaught Chromium page errors ({len(errors)})')
    summary={'assertions':checks,'failures':failures,'roleCount':len(roles),'routes':routes,'visibleRolesByRoute':visible_by_route,'roleChecks':len(detailed),'rolePasses':sum(all(r[k] for k in ('appliedOk','missingOk','resetOk','scopeOk')) for r in detailed),'mobile':mobile,'pageErrors':errors,'results':detailed}
    (OUT/'route-skin-visible-state.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    browser.close()
print(f'Batch257 route-aware Skin assertions: {checks-len(failures)}/{checks} PASS; visible role checks={len(detailed)}')
if failures: raise SystemExit('; '.join(failures))
