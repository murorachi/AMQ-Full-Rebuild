#!/usr/bin/env python3
"""Batch273 osu! Stable-style Home menu geometry and Catalog regression checks."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'src'; OUT=ROOT/'artifacts'/'batch283-catalog-stable'; OUT.mkdir(parents=True,exist_ok=True)
html=(SRC/'index.html').read_text(encoding='utf-8')
def css(m):
    import base64
    content=(SRC/m.group(1)).read_text(encoding='utf-8')
    asset=base64.b64encode((SRC/'assets'/'amq-note-question.png').read_bytes()).decode('ascii')
    content=content.replace('url("../assets/amq-note-question.png")', f'url("data:image/png;base64,{asset}")')
    return '<style>'+content+'</style>'
def js(m): return '<script>'+ (SRC/m.group(1)).read_text(encoding='utf-8')+'</script>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',css,html)
html=re.sub(r'<script src="([^"]+)"></script>', '', html)
# Keep the real app-shell owner while omitting the heavyweight data/runtime bundles;
# this is a DOM/CSS layout fixture, not a live data acceptance test.
html=html.replace('</body>', '<script>'+ (SRC/'ui'/'app-shell.js').read_text(encoding='utf-8') + '</script></body>')
checks=0; failures=[]
def check(ok,label):
 global checks
 checks+=1
 if ok: print('PASS',label)
 else: failures.append(label); print('FAIL',label)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h,name in [(1920,1080,'1920x1080'),(1440,900,'1440x900'),(1024,768,'1024x768'),(390,844,'390x844')]:
  page=browser.new_page(viewport={'width':w,'height':h}); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=60000); page.wait_for_timeout(100)
  page.screenshot(path=str(OUT/f'home-{name}.jpg'),full_page=True,type='jpeg',quality=83)
  home_metrics=page.evaluate('''() => ({hero:Math.round(document.querySelector("#page-home .home-feature").getBoundingClientRect().height),actions:[...document.querySelectorAll("#page-home .home-main-action")].map(x=>({h:Math.round(x.getBoundingClientRect().height),x:Math.round(x.getBoundingClientRect().x),y:Math.round(x.getBoundingClientRect().y)})),recent:Math.round(document.querySelector("#page-home .home-recent").getBoundingClientRect().height),artMark:Math.round(document.querySelector("#home-feature-art").getBoundingClientRect().width),brand:document.querySelector("#home-feature-art > span").getAttribute('aria-label'),brandBg:getComputedStyle(document.querySelector("#home-feature-art > .home-brand-mark")).backgroundImage,artSkinId:document.querySelector("#home-feature-art").dataset.skinComponent,menuSkinIds:[...document.querySelectorAll("#page-home .home-main-action")].map(x=>x.dataset.skinComponent),historyState:document.querySelector("#page-home").dataset.historyState,cta:(()=>{const r=document.querySelector("#page-home .home-feature-action").getBoundingClientRect();return {x:r.x,y:r.y,right:r.right,bottom:r.bottom}})(),grid:getComputedStyle(document.querySelector("#page-home .home-dashboard")).gridTemplateColumns,actionClip:getComputedStyle(document.querySelector("#page-home .home-main-action")).clipPath,iconOrder:getComputedStyle(document.querySelector("#page-home .home-action-icon")).order})''')
  check(len(home_metrics['actions'])==6 and max(a['h'] for a in home_metrics['actions'])<=120,f'home destinations use compact controls at {name}: {home_metrics["actions"]}')
  check('polygon' in home_metrics['actionClip'] and home_metrics['iconOrder']=='2',f'Home menu uses slanted game-client button silhouette and trailing icons at {name}: {home_metrics["actionClip"]}, order={home_metrics["iconOrder"]}')
  check((180 <= home_metrics['artMark'] <= 640 if w > 900 else 170 <= home_metrics['artMark'] <= 280) and home_metrics['brand']=='AMQ 音樂問號標誌' and 'data:image/png;base64,' in home_metrics['brandBg'],f'empty Home uses a deliberate circular note-question brand surface, not a fake work cover, at {name}: art={home_metrics["artMark"]}, label={home_metrics["brand"]}, bg={home_metrics["brandBg"][:80]}')
  check(home_metrics['artSkinId']=='home.feature.artwork' and len(set(home_metrics['menuSkinIds']))==6,f'Home artwork and all six menu targets expose stable Skin component IDs at {name}')
  check(home_metrics['historyState']=='empty',f'Home records empty history honestly without invented recommendations at {name}')
  if w > 900: check(home_metrics['cta']['right'] <= min(a['x'] for a in home_metrics['actions']) or home_metrics['cta']['bottom'] <= min(a['y'] for a in home_metrics['actions']) or home_metrics['cta']['y'] >= max(a['y'] + a['h'] for a in home_metrics['actions']),f'Home feature CTA does not overlap the right-side destination menu at {name}: CTA={home_metrics["cta"]}, menu={home_metrics["actions"]}')
  if w > 1180: check(home_metrics['recent'] <= 190 and home_metrics['hero'] > home_metrics['recent'] * 2.5,f'Home empty-history status stays compact while the osu-style stage gets visual priority at {name}: hero={home_metrics["hero"]}, recent={home_metrics["recent"]}')
  desktop_menu=(w>900 and len({a['x'] for a in home_metrics['actions']})==1 and len({a['y'] for a in home_metrics['actions']})==6)
  mobile_menu=(w<=900 and len({a['y'] for a in home_metrics['actions']})>=2)
  check(desktop_menu or mobile_menu,f'Home destinations use game-client menu placement at {name}: {home_metrics["actions"]}')
  check(page.locator('#page-home').is_visible(),f'Home route visible at {name}')
  check(page.locator('.app-header').is_hidden() and page.locator('#app-shell-nav').is_hidden(),f'Home has no global top header or sidebar navigation at {name}')
  check(page.locator('#page-home .home-main-action').count()==6,f'six main destinations are directly visible at {name}')
  check(page.locator('#page-home .home-recent').is_hidden(),f'Home has no bottom history panel crowding the main menu at {name}')
  check(page.locator('#home-pie, #home-pie-core, .home-footer-note').count()==0,f'old pie menu and explanatory note removed at {name}')
  check(page.locator('#page-home .eyebrow').count()==0,f'editorial eyebrow labels absent on Home at {name}')
  check(page.locator('#home-feature-mark, #home-pie, #home-pie-core').count()==0,f'abstract brand mark and old pie components absent at {name}')
  check(page.locator('#home-feature-art').count()==1 and page.locator('#home-recent-list').count()==1,f'artwork and playback-history owners mounted at {name}')
  m=page.evaluate('({width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,iw:innerWidth,ih:innerHeight})')
  check(m['width']<=w,f'no horizontal overflow at {name}')
  if w>=1024: check(m['height']<=h,f'no whole-page vertical overflow at {name}')
  page.locator('#page-home .home-main-action[data-go-page="catalog"]').click(); page.wait_for_timeout(20)
  check(page.locator('#app-shell-nav').is_hidden() is False and page.locator('.app-header').is_hidden() and page.locator('#app-shell-nav #app-status').is_visible(),f'feature route uses one compact navigation/status row at {name}')
  nav_geometry=page.evaluate('''() => { const nav=document.querySelector('#app-shell-nav').getBoundingClientRect(); const page=document.querySelector('#page-catalog').getBoundingClientRect(); return {navTop:Math.round(nav.top),navBottom:Math.round(nav.bottom),pageTop:Math.round(page.top),navHeight:Math.round(nav.height)} }''')
  check(nav_geometry['navBottom'] <= nav_geometry['pageTop'] + 2,f'feature route navigation is placed above the page rather than auto-flowing below it at {name}: {nav_geometry}')
  # A separately named, deterministic data fixture for layout review only. This does not
  # claim the production catalog/IndexedDB successfully loaded in this opaque origin.
  page.evaluate("""() => {
    const root = document.querySelector('#catalog-browser');
    if (root && !root.querySelector('.catalog-workspace')) {
      const heading = root.querySelector('.catalog-title-row');
      const scene = document.createElement('div'); scene.className = 'catalog-scene-background'; scene.dataset.artworkStatus = 'missing'; scene.dataset.skinComponent = 'catalog.selected-artwork-background'; scene.setAttribute('aria-hidden','true'); const sceneImg = document.createElement('img'); sceneImg.alt=''; scene.append(sceneImg); root.prepend(scene);
      const workspace = document.createElement('div'); workspace.className = 'catalog-workspace';
      workspace.dataset.catalogLayout = 'osu-stable-inspired';
      const sidebar = document.createElement('aside'); sidebar.className = 'catalog-sidebar'; sidebar.setAttribute('aria-label','曲庫搜尋、篩選與管理');
      const center = document.createElement('section'); center.className = 'catalog-main-list'; center.setAttribute('aria-label','歌曲列表');
      const detail = document.createElement('aside'); detail.className = 'catalog-detail-column'; detail.dataset.skinComponent = 'catalog.selected-work-stage'; detail.setAttribute('aria-label','目前選取歌曲資訊');
      if (heading) heading.after(workspace); else root.append(workspace);
      workspace.append(sidebar,center,detail);
      const move=(selector,parent)=>{const node=root.querySelector(selector);if(node)parent.append(node);return node;};
      const disclosure=(selectors,title)=>{const nodes=selectors.map(q=>root.querySelector(q)).filter(Boolean);if(!nodes.length)return;const d=document.createElement('details');d.className='catalog-management-group';const summary=document.createElement('summary');summary.textContent=title;d.append(summary);nodes.forEach(n=>d.append(n));sidebar.append(d);};
      move('.catalog-primary-controls',sidebar); move('#catalog-advanced-filters',sidebar);
      disclosure(['.catalog-presets-controls','#catalog-filter-preset-status'],'篩選預設');
      disclosure(['.catalog-tags-controls','#catalog-tag-status'],'歌曲標籤');
      disclosure(['.catalog-batch-controls','#catalog-batch-status'],'批次操作');
      disclosure(['.personal-library'],'個人作品清單');
      move('.catalog-summary-row',center); move('#catalog-error',center);
      const oldLayout=root.querySelector('.catalog-select-layout');
      if(oldLayout){const list=oldLayout.querySelector('.catalog-list-wrap');if(list)center.append(list);}
      const details=root.querySelector('#catalog-selection-details');if(details)detail.append(details);
      move('.pagination',center); if(oldLayout)oldLayout.remove();
      const mode=document.querySelector('#catalog-mode-selector');if(mode){const strip=document.createElement('div');strip.id='catalog-mode-selector';strip.className='catalog-mode-strip';strip.dataset.skinRole='catalog.mode-selector';strip.dataset.skinComponent='catalog.mode-selector';strip.setAttribute('role','group');strip.setAttribute('aria-label','AMQ／EMQ／MIX 曲庫來源');const row=mode.querySelector('.mode-row');if(row)strip.append(row);if(heading)heading.insertBefore(strip,heading.querySelector('.catalog-actions'));const state=mode.querySelector('.state-grid');const message=mode.querySelector('#app-message');if(state||message){const d=document.createElement('details');d.className='catalog-mode-status';const sm=document.createElement('summary');sm.textContent='曲庫／練習狀態';d.append(sm);if(state)d.append(state);if(message)d.append(message);sidebar.append(d)}mode.remove();}
    }
  }""")
  page.evaluate("""() => {
    const root = document.querySelector('#catalog-browser');
    const rows = document.querySelector('#catalog-rows');
    const empty = document.querySelector('#catalog-empty');
    const detail = document.querySelector('#catalog-selection-content');
    if (!root || !rows || !empty) return false;
    const fixture = [
      ['青い栞','Galileo Galilei','あの日見た花の名前を僕達はまだ知らない。','OP','AMQ'],
      ['君の知らない物語','supercell','化物語','ED','AMQ'],
      ['紅蓮の弓矢','Linked Horizon','進撃の巨人','OP','AMQ'],
      ['残酷な天使のテーゼ','高橋洋子','新世紀エヴァンゲリオン','OP','AMQ'],
      ['鳥の詩','Lia','AIR','OP','AMQ'],
      ['千の刃濤、桃花染の皇姫','AUGUST','千の刃濤、桃花染の皇姫','GAME','EMQ']
    ];
    const svg = (i) => 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="96" height="128"><defs><linearGradient id="g" x2="1" y2="1"><stop stop-color="${['#8b4d78','#416a91','#b64c55','#6a6396','#407e75','#9b7547'][i]}"/><stop offset="1" stop-color="#171820"/></linearGradient></defs><rect width="96" height="128" fill="url(#g)"/><circle cx="48" cy="42" r="24" fill="#ffffff" fill-opacity=".18"/><path d="M0 100L96 42V128H0Z" fill="#ffffff" fill-opacity=".12"/></svg>`);
    rows.replaceChildren();
    fixture.forEach((record, i) => {
      const tr = document.createElement('tr'); tr.tabIndex = 0; tr.setAttribute('aria-selected', String(i === 0));
      record.forEach((value, col) => {
        const td = document.createElement('td');
        if (col === 0) {
          td.className = 'catalog-title-cell catalog-title-cell--artwork';
          const art = document.createElement('span'); art.className = 'catalog-artwork'; art.dataset.artworkStatus = 'available';
          const img = document.createElement('img'); img.className = 'catalog-artwork-image'; img.alt = ''; img.src = svg(i); art.append(img);
          const title = document.createElement('span'); title.className = 'catalog-song-title'; title.textContent = value;
          td.append(art, title);
        } else td.textContent = value;
        tr.append(td);
      });
      rows.append(tr);
    });
    empty.hidden = true; root.dataset.catalogState = 'ready';
    const error = document.querySelector('#catalog-error'); if (error) { error.hidden = true; error.textContent = ''; }
    const summary = document.querySelector('#catalog-summary'); if (summary) summary.textContent = '6 首歌曲';
    const appStatus = document.querySelector('#app-status'); if (appStatus) appStatus.textContent = '曲庫已載入';
    const dataState = document.querySelector('#data-state'); if (dataState) dataState.textContent = '已載入';
    const modeStatus = document.querySelector('#catalog-status'); if (modeStatus) { modeStatus.textContent = '曲庫已載入'; modeStatus.dataset.status = 'ready'; }
    document.querySelectorAll('#catalog-browser [role=alert], #catalog-browser [data-error-code]').forEach(el => { el.hidden = true; el.style.display = 'none'; });
    document.querySelectorAll('#catalog-browser .catalog-sidebar .notice').forEach(el => { if (/DATA_SOURCE_READ_FAILED|無法讀取曲庫來源/.test(el.textContent)) { el.hidden = true; el.style.display = 'none'; } });
    if (detail) { detail.hidden = false; detail.replaceChildren(); const h = document.createElement('h3'); h.textContent = '青い栞'; const img = document.createElement('img'); img.src = svg(0); img.alt = ''; img.style.cssText = 'width:100%;max-height:220px;object-fit:cover;margin:.5rem 0'; const p = document.createElement('p'); p.textContent = 'あの日見た花の名前を僕達はまだ知らない。'; detail.append(h,img,p); }
    const selectionEmpty = document.querySelector('#catalog-selection-empty'); if (selectionEmpty) selectionEmpty.hidden = true;
    return true;
  }""")
  page.wait_for_timeout(20)
  # Match the production dock owner's default startCollapsed=true state.
  page.evaluate("""() => { const dock=document.querySelector('#free-player-dock'); const body=document.querySelector('#free-player-body'); const toggle=document.querySelector('#free-player-collapse'); dock.dataset.collapsed='true'; body.hidden=true; toggle.setAttribute('aria-expanded','false'); }""")
  page.screenshot(path=str(OUT/f'catalog-data-fixture-{name}.jpg'),full_page=True,type='jpeg',quality=83)
  catalog_metrics=page.evaluate('''() => ({row:Math.round(document.querySelector("#catalog-rows tr").getBoundingClientRect().height),art:(()=>{const r=document.querySelector("#catalog-rows .catalog-artwork").getBoundingClientRect();return {w:Math.round(r.width),h:Math.round(r.height)}})(),columns:getComputedStyle(document.querySelector(".catalog-workspace")).gridTemplateColumns})''')
  check(50<=catalog_metrics['row']<=78,f'catalog rows use dense client-style rhythm at {name}: {catalog_metrics["row"]}')
  check(catalog_metrics['art']['w']>=34 and catalog_metrics['art']['h']>=46,f'catalog rows retain visible artwork thumbnails at {name}: {catalog_metrics["art"]}')
  list_height=page.locator('.catalog-list-wrap').evaluate('(el)=>Math.round(el.getBoundingClientRect().height)')
  if w>=1181: check(list_height>=400,f'desktop song-select list fills the available play area at {name}: {list_height}px')
  check(catalog_metrics['art']['w']<=50 and catalog_metrics['art']['h']<=64,f'catalog cover thumbnails remain compact at {name}: {catalog_metrics["art"]}')
  dock_metrics=page.evaluate('''() => { const dock=document.querySelector("#free-player-dock").getBoundingClientRect(); const pagination=document.querySelector("#page-catalog .pagination").getBoundingClientRect(); const list=document.querySelector("#page-catalog .catalog-list-wrap").getBoundingClientRect(); return {dock:{top:Math.round(dock.top),bottom:Math.round(dock.bottom),height:Math.round(dock.height),position:getComputedStyle(document.querySelector("#free-player-dock")).position},pagination:{top:Math.round(pagination.top),bottom:Math.round(pagination.bottom),height:Math.round(pagination.height)},list:{top:Math.round(list.top),bottom:Math.round(list.bottom),height:Math.round(list.height)},reserved:getComputedStyle(document.documentElement).getPropertyValue("--amq-player-dock-height").trim()} }''')
  check(dock_metrics['dock']['height'] <= 60 if w>760 else dock_metrics['dock']['position']=='static',f'player dock starts in the compact production state at {name}: {dock_metrics}')
  check(dock_metrics['list']['height']>=240 if w<=760 else dock_metrics['list']['height']>=280,f'catalog list retains a usable scroll area at {name}: {dock_metrics}')
  if w>760:
   check(dock_metrics['pagination']['bottom'] <= dock_metrics['dock']['top'] + 2,f'pagination remains above the compact player dock at {name}: {dock_metrics}')
   page.evaluate("""() => { const dock=document.querySelector('#free-player-dock'); dock.dataset.collapsed='false'; document.querySelector('#free-player-body').hidden=false; document.querySelector('#free-player-collapse').setAttribute('aria-expanded','true'); document.documentElement.style.setProperty('--amq-player-dock-height', `${Math.round(dock.getBoundingClientRect().height)}px`); }""")
   page.wait_for_timeout(30)
   expanded=page.evaluate('''() => {const d=document.querySelector('#free-player-dock').getBoundingClientRect(),p=document.querySelector('#page-catalog .pagination').getBoundingClientRect();return {dock:{top:Math.round(d.top),height:Math.round(d.height)},pagination:{bottom:Math.round(p.bottom)},reserved:getComputedStyle(document.documentElement).getPropertyValue('--amq-player-dock-height').trim(),nowPlayingBackground:getComputedStyle(document.querySelector('#free-player-now-playing')).backgroundColor}}''')
   check(expanded['pagination']['bottom'] <= expanded['dock']['top'] + 2,f'pagination remains visible when player dock expands at {name}: {expanded}')
   check(expanded['nowPlayingBackground'] != 'rgb(248, 250, 252)',f'expanded player uses the dark game-client now-playing surface at {name}: {expanded}')
   if w==1920: page.screenshot(path=str(OUT/'catalog-dock-expanded-1920x1080.jpg'),full_page=True,type='jpeg',quality=83)
  else: check(dock_metrics['dock']['position']=='static',f'mobile player dock participates in document flow at {name}: {dock_metrics}')
  check(dock_metrics['reserved'].endswith('px'),f'player dock publishes measured layout height at {name}: {dock_metrics["reserved"]}')
  check(page.locator('.catalog-workspace > .catalog-sidebar #catalog-query').count()==1,f'catalog filters retain their single left-side DOM owner at {name}')
  check(page.locator('.catalog-workspace > .catalog-main-list #catalog-rows').count()==1,f'catalog rows retain their single list DOM owner at {name}')
  check(page.locator('.catalog-workspace > .catalog-detail-column #catalog-selection-details').count()==1,f'selected song details retain their single DOM owner at {name}')
  visual_areas=page.evaluate('''() => { const ws=document.querySelector('.catalog-workspace'); const rect=s=>{const r=document.querySelector(s).getBoundingClientRect();return {x:Math.round(r.x),y:Math.round(r.y),right:Math.round(r.right),width:Math.round(r.width)}};return {areas:getComputedStyle(ws).gridTemplateAreas,filters:rect('.catalog-sidebar'),songs:rect('.catalog-main-list'),stage:rect('.catalog-detail-column'),scene:!!document.querySelector('.catalog-scene-background')} }''')
  if w > 760:
   check(visual_areas['songs']['x'] > visual_areas['stage']['x'] and visual_areas['filters']['x'] < visual_areas['stage']['x'] and visual_areas['stage']['width'] >= 180,f'Catalog visual order follows Stable reference: filters left, selected-work stage center, song queue right at {name}: {visual_areas}')
  else:
   check(visual_areas['filters']['y'] < visual_areas['stage']['y'] < visual_areas['songs']['y'],f'Catalog mobile layout stacks filters, selected work, and song queue in reading order at {name}: {visual_areas}')
  check(visual_areas['scene'],f'Catalog selected-artwork background layer exists without substituting fake cover art at {name}')
  check(page.locator('#catalog-mode-selector[data-skin-component="catalog.mode-selector"] .mode-row button').count()==3,f'AMQ/EMQ/MIX controls stay in one compact top mode strip at {name}')
  check(page.locator('.catalog-sidebar #catalog-mode-selector').count()==0,f'old tall mode dashboard is removed from the filter rail at {name}')
  check(page.locator('.catalog-detail-column[data-skin-component="catalog.selected-work-stage"]').count()==1,f'selected-work stage exposes a stable Skin component ID at {name}')
  check(not errors,f'no browser exceptions at {name}: {errors}')
  page.close()
 browser.close()
print(f'Batch283 Home/Catalog visual checks: {checks-len(failures)}/{checks} PASS')
if failures: raise SystemExit(1)
