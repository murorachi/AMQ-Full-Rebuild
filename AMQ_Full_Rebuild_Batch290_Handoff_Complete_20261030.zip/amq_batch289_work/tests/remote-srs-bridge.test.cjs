'use strict';

const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const test = require('node:test');

const root = path.resolve(__dirname, '..');
const scripts = ['src/learning/fsrs-scheduler.js', 'src/persistence/srs-store.js', 'src/persistence/remote-srs-bridge.js'];
function createFakeIndexedDB() {
  const databases = new Map();
  const copy = value => value == null ? value : JSON.parse(JSON.stringify(value));
  return {
    records: databases,
    open(name) {
      const request = {};
      setImmediate(() => {
        let database = databases.get(name);
        const needsUpgrade = !database;
        if (!database) { database = { stores: new Map() }; databases.set(name, database); }
        const db = {
          objectStoreNames: { contains: storeName => database.stores.has(storeName) },
          createObjectStore(storeName) { if (!database.stores.has(storeName)) database.stores.set(storeName, new Map()); },
          transaction(storeName) {
            const values = database.stores.get(storeName);
            const transaction = { objectStore() { return {
              get(key) { const req = {}; setImmediate(() => { req.result = copy(values.get(key) || null); if (req.onsuccess) req.onsuccess(); if (transaction.oncomplete) transaction.oncomplete(); }); return req; },
              put(value) { const req = {}; setImmediate(() => { values.set(value.key, copy(value)); req.result = value.key; if (req.onsuccess) req.onsuccess(); if (transaction.oncomplete) transaction.oncomplete(); }); return req; },
              delete(key) { const req = {}; setImmediate(() => { values.delete(key); if (req.onsuccess) req.onsuccess(); if (transaction.oncomplete) transaction.oncomplete(); }); return req; }
            }; }, abort() { if (transaction.onabort) transaction.onabort(); } };
            return transaction;
          },
          close() {}
        };
        request.result = db;
        if (needsUpgrade && request.onupgradeneeded) request.onupgradeneeded();
        if (request.onsuccess) request.onsuccess();
      });
      return request;
    }
  };
}

function createHarness({ conflictFirstPut = false, networkFailureFirstPut = false, networkFailureAfterCommitFirstPut = false, holdFirstPut = false, useIndexedDb = false } = {}) {
  const window = { localStorage: { getItem() { throw new Error('remote bridge must not use browser localStorage'); }, setItem() { throw new Error('remote bridge must not use browser localStorage'); } } };
  if (useIndexedDb) window.indexedDB = createFakeIndexedDB();
  const requests = [];
  const pendingRecords = new Map();
  let failPendingDelete = false;
  const pendingStore = {
    async get(userId, source) { const record = pendingRecords.get(`${Number(userId)}:${source}`); return record ? JSON.parse(JSON.stringify(record)) : null; },
    async put(userId, source, record) { pendingRecords.set(`${Number(userId)}:${source}`, JSON.parse(JSON.stringify(record))); return true; },
    async delete(userId, source) { if (failPendingDelete) throw Object.assign(new Error('simulated pending store delete failure'), { code: 'REMOTE_SRS_PENDING_STORE_DELETE_FAILED' }); pendingRecords.delete(`${Number(userId)}:${source}`); return true; }
  };
  const schedulerSandbox = { window, Date, Math, Number, Object, Array, Set, String, JSON, Map, Promise, Error, TypeError };
  vm.createContext(schedulerSandbox);
  for (const relative of scripts) vm.runInContext(fs.readFileSync(path.join(root, relative), 'utf8'), schedulerSandbox, { filename: relative });
  const scheduler = window.AMQLearning.fsrsScheduler;
  const schedules = {
    AMQ: scheduler.emptySchedule(Date.now()),
    EMQ: { ...scheduler.emptySchedule(Date.now()), source: 'EMQ' }
  };
  const revisions = { AMQ: 0, EMQ: 0 };
  let puts = 0;
  let releaseHeldPut = null;
  let firstPutStartedResolve;
  const firstPutStarted = new Promise(resolve => { firstPutStartedResolve = resolve; });
  window.fetch = async (url, options = {}) => {
    requests.push({ url, method: options.method || 'GET', body: options.body ? JSON.parse(options.body) : null });
    const match = String(url).match(/^\/api\/srs\/(AMQ|EMQ)$/);
    if (!match) throw new Error(`unexpected request ${url}`);
    const source = match[1];
    if (!options.method || options.method === 'GET') return { ok: true, status: 200, json: async () => ({ source, revision: revisions[source], schedule: JSON.parse(JSON.stringify(schedules[source])), updatedAt: null }) };
    puts++;
    if (networkFailureFirstPut && puts === 1) throw new Error('simulated network disconnect');
    if (networkFailureAfterCommitFirstPut && puts === 1) {
      const body = JSON.parse(options.body);
      if (body.expectedRevision !== revisions[source]) return { ok: false, status: 409, json: async () => ({ error: { code: 'SRS_REVISION_CONFLICT', message: 'stale' } }) };
      schedules[source] = JSON.parse(JSON.stringify(body.schedule));
      revisions[source]++;
      throw new Error('simulated response lost after server commit');
    }
    if (conflictFirstPut && puts === 1) return { ok: false, status: 409, json: async () => ({ error: { code: 'SRS_REVISION_CONFLICT', message: 'stale' } }) };
    const body = JSON.parse(options.body);
    if (body.expectedRevision !== revisions[source]) return { ok: false, status: 409, json: async () => ({ error: { code: 'SRS_REVISION_CONFLICT', message: 'stale' } }) };
    schedules[source] = JSON.parse(JSON.stringify(body.schedule));
    revisions[source]++;
    if (holdFirstPut && puts === 1) {
      firstPutStartedResolve();
      await new Promise(resolve => { releaseHeldPut = resolve; });
    }
    return { ok: true, status: 200, json: async () => ({ source, revision: revisions[source], schedule: schedules[source], updatedAt: Date.now() }) };
  };
  return { window, scheduler, requests, schedules, revisions, pendingRecords, pendingStore, firstPutStarted, releaseFirstPut: () => { if (releaseHeldPut) releaseHeldPut(); }, setFailPendingDelete(value) { failPendingDelete = Boolean(value); }, createBridge: options => window.AMQPersistence.remoteSrsBridge.createRemoteSrsBridge(options), createStore: (source, storage) => window.AMQPersistence.srsStore.createSrsStore({ source, storage, songExists: () => true }) };
}

test('remote SRS bridge loads per-user schedules and serializes revisions without touching localStorage', async () => {
  const h = createHarness();
  const bridge = h.createBridge();
  const connected = await bridge.connect();
  assert.equal(connected.state, 'synced');
  assert.equal(h.requests.filter(item => item.method === 'GET').length, 2);
  const amq = h.createStore('AMQ', bridge.storageFor('AMQ'));
  const emq = h.createStore('EMQ', bridge.storageFor('EMQ'));
  assert.equal(amq.enroll('amq-1').ok, true);
  assert.equal(amq.rate('amq-1', 3).ok, true);
  assert.equal(emq.enroll('emq-1').ok, true);
  const status = await bridge.flush();
  assert.equal(status.state, 'synced');
  assert.equal(status.sources.AMQ.revision, 1, 'coalesced AMQ writes commit the latest full schedule once');
  assert.equal(status.sources.EMQ.revision, 1);
  const puts = h.requests.filter(item => item.method === 'PUT');
  assert.deepEqual(puts.filter(item => item.url.endsWith('/AMQ')).map(item => item.body.expectedRevision), [0]);
  assert.deepEqual(puts.filter(item => item.url.endsWith('/EMQ')).map(item => item.body.expectedRevision), [0]);
  assert.equal(h.schedules.AMQ.cards['amq-1'].reps, 1);
  assert.equal(h.schedules.EMQ.cards['emq-1'].source, 'EMQ');
  amq.dispose(); emq.dispose(); await bridge.flush(); bridge.close();
});

test('remote SRS bridge fails closed on revision conflict and blocks later writes', async () => {
  const h = createHarness({ conflictFirstPut: true });
  const bridge = h.createBridge();
  await bridge.connect();
  const store = h.createStore('AMQ', bridge.storageFor('AMQ'));
  assert.equal(store.enroll('song-a').ok, true, 'local store accepts the first change while network save is pending');
  const status = await bridge.flush();
  assert.equal(status.state, 'conflict');
  assert.equal(status.sources.AMQ.error.code, 'SRS_REVISION_CONFLICT');
  assert.equal(store.enroll('song-b').ok, false, 'writes are blocked after conflict');
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 1, 'no blind retry overwrites a newer server schedule');
  store.dispose(); await bridge.flush(); bridge.close();
});



test('remote SRS bridge retries a failed latest schedule only when server revision is unchanged', async () => {
  const h = createHarness({ networkFailureFirstPut: true });
  const bridge = h.createBridge();
  await bridge.connect();
  const store = h.createStore('AMQ', bridge.storageFor('AMQ'));
  assert.equal(store.enroll('song-retry').ok, true);
  assert.equal((await bridge.flush()).state, 'error');
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 1);
  const retried = await bridge.retryPending('AMQ');
  assert.equal(retried.state, 'synced');
  assert.equal(retried.sources.AMQ.revision, 1);
  assert.ok(h.schedules.AMQ.cards['song-retry'], 'latest pending schedule reaches the server after safe retry');
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 2);
  store.dispose(); await bridge.flush(); bridge.close();
});

test('remote SRS retry recognizes a committed PUT whose response was lost without sending a duplicate PUT', async () => {
  const h = createHarness({ networkFailureAfterCommitFirstPut: true });
  const bridge = h.createBridge();
  await bridge.connect();
  const store = h.createStore('AMQ', bridge.storageFor('AMQ'));
  assert.equal(store.enroll('song-committed-response-lost').ok, true);
  assert.equal((await bridge.flush()).state, 'error');
  assert.equal(h.revisions.AMQ, 1, 'the simulated server committed before the response was lost');
  assert.ok(h.schedules.AMQ.cards['song-committed-response-lost']);
  const retried = await bridge.retryPending('AMQ');
  assert.equal(retried.state, 'synced');
  assert.equal(retried.sources.AMQ.revision, 1);
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 1, 'matching server payload is reconciled without a second PUT');
  assert.equal(store.enroll('after-reconcile').ok, true, 'writes resume after safe reconciliation');
  await bridge.flush();
  assert.equal(h.revisions.AMQ, 2);
  store.dispose(); await bridge.flush(); bridge.close();
});

test('remote SRS retry detects a newer server revision and never overwrites it', async () => {
  const h = createHarness({ networkFailureFirstPut: true });
  const bridge = h.createBridge();
  await bridge.connect();
  const store = h.createStore('AMQ', bridge.storageFor('AMQ'));
  assert.equal(store.enroll('local-pending-song').ok, true);
  assert.equal((await bridge.flush()).state, 'error');
  h.revisions.AMQ = 1;
  h.schedules.AMQ = { ...h.schedules.AMQ, remoteDeviceChange: true };
  const retried = await bridge.retryPending('AMQ');
  assert.equal(retried.state, 'conflict');
  assert.equal(retried.sources.AMQ.error.code, 'SRS_REVISION_CONFLICT');
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 1, 'retry must not write after a revision mismatch');
  assert.equal(store.enroll('later-song').ok, false, 'conflict keeps writes fail-closed');
  store.dispose(); await bridge.flush(); bridge.close();
});

test('remote SRS durable pending schedule survives bridge recreation and retries under the same user identity', async () => {
  const h = createHarness({ networkFailureFirstPut: true });
  const userId = 701;
  const firstBridge = h.createBridge({ userId, pendingStore: h.pendingStore });
  await firstBridge.connect();
  const firstStore = h.createStore('AMQ', firstBridge.storageFor('AMQ'));
  assert.equal(firstStore.enroll('durable-pending-song').ok, true);
  assert.equal((await firstBridge.flush()).state, 'error');
  assert.ok(h.pendingRecords.has(`${userId}:AMQ`), 'pending schedule is persisted before network delivery');
  firstStore.dispose(); firstBridge.close();

  const restoredBridge = h.createBridge({ userId, pendingStore: h.pendingStore });
  const restored = await restoredBridge.connect();
  assert.equal(restored.durable, true);
  assert.equal(restored.sources.AMQ.state, 'error', 'recovered pending writes require explicit retry');
  const raw = restoredBridge.storageFor('AMQ').getItem(h.window.AMQPersistence.srsStore.storageKeys.AMQ);
  assert.ok(JSON.parse(raw).cards['durable-pending-song'], 'restored storage exposes the pending schedule, not the stale server snapshot');
  const retried = await restoredBridge.retryPending('AMQ');
  assert.equal(retried.sources.AMQ.state, 'synced');
  assert.ok(h.schedules.AMQ.cards['durable-pending-song']);
  assert.equal(h.pendingRecords.has(`${userId}:AMQ`), false, 'successful retry clears the durable record');
  restoredBridge.close();
});

test('remote SRS uses the built-in IndexedDB adapter when a user identity is available', async () => {
  const h = createHarness({ networkFailureFirstPut: true, useIndexedDb: true });
  const userId = 706;
  const firstBridge = h.createBridge({ userId });
  await firstBridge.connect();
  const store = h.createStore('AMQ', firstBridge.storageFor('AMQ'));
  assert.equal(store.enroll('indexed-db-pending-song').ok, true);
  assert.equal((await firstBridge.flush()).state, 'error');
  store.dispose(); firstBridge.close();

  const restoredBridge = h.createBridge({ userId });
  const status = await restoredBridge.connect();
  assert.equal(status.durable, true);
  assert.equal(status.sources.AMQ.state, 'error');
  const retried = await restoredBridge.retryPending('AMQ');
  assert.equal(retried.sources.AMQ.state, 'synced');
  assert.ok(h.schedules.AMQ.cards['indexed-db-pending-song']);
  restoredBridge.close();
});

test('remote SRS durable queue preserves write order when a newer schedule arrives during an in-flight PUT', async () => {
  const h = createHarness({ holdFirstPut: true });
  const bridge = h.createBridge({ userId: 704, pendingStore: h.pendingStore });
  await bridge.connect();
  const store = h.createStore('AMQ', bridge.storageFor('AMQ'));
  assert.equal(store.enroll('ordered-song').ok, true);
  await h.firstPutStarted;
  assert.equal(store.rate('ordered-song', 3).ok, true, 'a newer full schedule can queue while the first PUT is in flight');
  h.releaseFirstPut();
  const status = await bridge.flush();
  assert.equal(status.sources.AMQ.state, 'synced');
  assert.equal(h.revisions.AMQ, 2);
  assert.deepEqual(h.requests.filter(item => item.method === 'PUT' && item.url.endsWith('/AMQ')).map(item => item.body.expectedRevision), [0, 1]);
  assert.equal(h.schedules.AMQ.cards['ordered-song'].lastRating, 3, 'the newest queued schedule wins without skipping the base revision');
  assert.equal(h.pendingRecords.has('704:AMQ'), false);
  store.dispose(); bridge.close();
});

test('remote SRS durable queue reconciles a committed write after reload without duplicate PUT', async () => {
  const h = createHarness({ networkFailureAfterCommitFirstPut: true });
  const userId = 702;
  const firstBridge = h.createBridge({ userId, pendingStore: h.pendingStore });
  await firstBridge.connect();
  const store = h.createStore('AMQ', firstBridge.storageFor('AMQ'));
  assert.equal(store.enroll('committed-before-reload').ok, true);
  assert.equal((await firstBridge.flush()).state, 'error');
  assert.equal(h.revisions.AMQ, 1);
  store.dispose(); firstBridge.close();

  const restoredBridge = h.createBridge({ userId, pendingStore: h.pendingStore });
  const restored = await restoredBridge.connect();
  assert.equal(restored.sources.AMQ.state, 'synced', 'server payload equality resolves the lost response');
  assert.equal(restored.sources.AMQ.revision, 1);
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 1);
  assert.equal(h.pendingRecords.has(`${userId}:AMQ`), false);
  restoredBridge.close();
});

test('remote SRS durable queue is user-isolated and conflicting pending data requires explicit discard', async () => {
  const h = createHarness({ networkFailureFirstPut: true });
  const ownerId = 703;
  const firstBridge = h.createBridge({ userId: ownerId, pendingStore: h.pendingStore });
  await firstBridge.connect();
  const store = h.createStore('AMQ', firstBridge.storageFor('AMQ'));
  assert.equal(store.enroll('private-pending-song').ok, true);
  assert.equal((await firstBridge.flush()).state, 'error');
  store.dispose(); firstBridge.close();

  const otherUserBridge = h.createBridge({ userId: ownerId + 1, pendingStore: h.pendingStore });
  const otherUserStatus = await otherUserBridge.connect();
  assert.equal(otherUserStatus.sources.AMQ.state, 'synced');
  assert.equal(JSON.parse(otherUserBridge.storageFor('AMQ').getItem(h.window.AMQPersistence.srsStore.storageKeys.AMQ)).cards['private-pending-song'], undefined,
    'another account never receives the first user pending schedule');
  otherUserBridge.close();

  h.revisions.AMQ = 1;
  h.schedules.AMQ = { ...h.schedules.AMQ, remoteDeviceChange: true };
  const conflictBridge = h.createBridge({ userId: ownerId, pendingStore: h.pendingStore });
  const conflict = await conflictBridge.connect();
  assert.equal(conflict.sources.AMQ.state, 'conflict');
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 1, 'conflicting pending data is never blindly written');
  const discarded = await conflictBridge.discardPending('AMQ');
  assert.equal(discarded.sources.AMQ.state, 'synced');
  assert.equal(h.pendingRecords.has(`${ownerId}:AMQ`), false, 'explicit discard clears only the selected user/source queue');
  conflictBridge.close();
});

test('remote SRS explicit discard fails closed if durable queue deletion fails', async () => {
  const h = createHarness({ networkFailureFirstPut: true });
  const userId = 705;
  const bridge = h.createBridge({ userId, pendingStore: h.pendingStore });
  await bridge.connect();
  const store = h.createStore('AMQ', bridge.storageFor('AMQ'));
  assert.equal(store.enroll('cannot-drop-pending').ok, true);
  assert.equal((await bridge.flush()).state, 'error');
  h.setFailPendingDelete(true);
  await assert.rejects(() => bridge.discardPending('AMQ'), /無法持久化未同步的 SRS 變更/);
  assert.equal(bridge.getStatus().sources.AMQ.state, 'error');
  assert.ok(h.pendingRecords.has(`${userId}:AMQ`), 'failed delete keeps the durable queue record');
  h.setFailPendingDelete(false);
  await bridge.discardPending('AMQ');
  assert.equal(h.pendingRecords.has(`${userId}:AMQ`), false);
  store.dispose(); bridge.close();
});

test('remote SRS bridge reports network failure instead of falsely reporting synced', async () => {
  const h = createHarness({ networkFailureFirstPut: true });
  const bridge = h.createBridge();
  await bridge.connect();
  const store = h.createStore('AMQ', bridge.storageFor('AMQ'));
  assert.equal(store.enroll('song-network').ok, true);
  const status = await bridge.flush();
  assert.equal(status.state, 'error');
  assert.equal(status.sources.AMQ.state, 'error');
  assert.equal(status.sources.AMQ.error.code, 'REMOTE_SRS_REQUEST_FAILED');
  assert.equal(store.enroll('song-after-error').ok, false, 'network failure blocks later writes until explicit reload');
  assert.equal(h.requests.filter(item => item.method === 'PUT').length, 1);
  store.dispose(); await bridge.flush(); bridge.close();
});
