'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
class Element { constructor(tagName = 'div') { this.tagName = tagName.toUpperCase(); this.textContent = ''; this.listeners = new Map(); this.children = []; this.hidden = false; this.dataset = {}; this.attributes = {}; this.className = ''; this.style = {}; } addEventListener(name, fn) { if (!this.listeners.has(name)) this.listeners.set(name, new Set()); this.listeners.get(name).add(fn); } removeEventListener(name, fn) { this.listeners.get(name)?.delete(fn); } dispatch(name) { for (const fn of [...(this.listeners.get(name) || [])]) fn({}); } appendChild(child) { if (child.parentElement && child.parentElement !== this) child.parentElement.children = child.parentElement.children.filter(item => item !== child); this.children.push(child); child.parentElement = this; return child; } append(...children) { children.forEach(child => this.appendChild(child)); } replaceChildren(...children) { for (const child of this.children) if (child.parentElement === this) child.parentElement = null; this.children = []; this.textContent = ''; children.forEach(child => this.appendChild(child)); } remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter(item => item !== this); this.parentElement = null; } setAttribute(name, value) { this.attributes[name] = String(value); } }
class Events { constructor() { this.listeners = new Map(); } addEventListener(name, fn) { if (!this.listeners.has(name)) this.listeners.set(name, new Set()); this.listeners.get(name).add(fn); } removeEventListener(name, fn) { this.listeners.get(name)?.delete(fn); } }
const document = new Events(), globalEvents = new Events(); document.createElement = tagName => new Element(tagName);
const window = { document, addEventListener: globalEvents.addEventListener.bind(globalEvents), removeEventListener: globalEvents.removeEventListener.bind(globalEvents) };
const sandbox = { window, document, console, Object, Array, Number, String, Set, Map };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/ui/statistics-dashboard-panel.js'), 'utf8'), sandbox);
const elements = Object.fromEntries(['status','error','summary','bySource','byTarget','workProgress','familiarity','srs','playback','daily','refresh','historyList','historyEmpty','historyCount','reviewList','reviewEmpty','reviewCount'].map(key => [key, new Element()]));
let badRead = false, projectionCalls = 0, srsPersistenceError = false, srsRecoveryAvailable = false;
const history = { getHistory: () => [{ id: 'history-1', source: 'AMQ', songId: 'history-song', target: 'anime', correct: true, result: '答對', songName: '未命名歌曲', workTitle: '未知作品', elapsed: 3, at: '2026-10-27T10:00:00Z' }], getPersistenceStatus: () => ({ detailWriteBlocked: badRead, summaryWriteBlocked: false }), dispose() {} };
const familiarity = { getSnapshot: source => ({ one: source === 'AMQ' ? 2 : 1 }), getPersistenceStatus: () => ({ AMQ: { readBlocked: false }, EMQ: { readBlocked: false } }), dispose() {} };
const makeSrs = source => ({ counts: () => ({ total: source === 'AMQ' ? 2 : 0, active: source === 'AMQ' ? 2 : 0, due: source === 'AMQ' ? 1 : 0, new: source === 'AMQ' ? 1 : 0, learning: 0, review: source === 'AMQ' ? 1 : 0, suspended: 0 }), snapshot: () => ({ cards: source === 'AMQ' ? { 'due-song': { songId: 'due-song', state: 'review', dueAt: Date.parse('2026-10-27T09:00:00Z') }, 'new-song': { songId: 'new-song', state: 'new', dueAt: Date.parse('2026-10-30T09:00:00Z') } } : {} }), chooseSession: () => source === 'AMQ' ? { ids: ['due-song', 'new-song'], dueCount: 1 } : { ids: [], dueCount: 0 }, getPersistenceStatus: () => ({ blocked: false, error: srsPersistenceError ? 'quota exceeded' : null, recoveryAvailable: srsRecoveryAvailable, persisted: !srsPersistenceError && !srsRecoveryAvailable }), dispose() {} });
const playback = { getEntries: () => [{ source: 'EMQ', title: 'Free song', workTitle: 'Game' }], getPersistenceStatus: () => ({ ok: true, readBlocked: false }), dispose() {} };
const persistence = {
  quizHistoryStore: { keys: { UPDATE_EVENT: 'quiz-update' } }, familiarityStore: { keys: { AMQ_EVENT: 'fam-amq', EMQ_EVENT: 'fam-emq' } },
  srsStore: { updateEvent: 'srs-update' }, playbackHistoryStore: { updateEvent: 'playback-update' }
};
const learning = { statisticsDashboard: { buildDashboard(input) { projectionCalls++; assert.equal(input.quizHistory.length, 1); return {
  quiz: { total: 1, correct: 1, wrong: 0, accuracy: 1, averageElapsedSeconds: 3, bySource: { AMQ: { total: 1, accuracy: 1 }, EMQ: { total: 0, accuracy: null } }, byTarget: { anime: { total: 1, accuracy: 1 }, title: { total: 0, accuracy: null }, artist: { total: 0, accuracy: null } }, recentDays: [] },
  workProgress: { totalWorks: 1, totalAnswers: 1, works: [{ source: 'AMQ', title: 'Example Anime', total: 1, uniqueSongs: 1, accuracy: 1, lastAt: '2026-10-27T10:00:00Z' }] },
  familiarity: { AMQ: { unknown: 0, level0: 0, level1: 0, level2: 1, level3: 0 }, EMQ: { unknown: 0, level0: 0, level1: 1, level2: 0, level3: 0 } },
  srs: { AMQ: { total: 1, due: 0, new: 1, learning: 0, review: 0, suspended: 0 }, EMQ: { total: 1, due: 0, new: 1, learning: 0, review: 0, suspended: 0 } },
  playback: { total: 1, bySource: { AMQ: 0, EMQ: 1 }, latest: { source: 'EMQ', title: 'Free song', workTitle: 'Game' } }
}; } } };
let unexpectedStoreCreations = 0;
const unavailableLearningPersistence = {
  quizHistoryStore: { keys: {} , createQuizHistoryStore() { unexpectedStoreCreations++; throw new Error('should not create'); } },
  familiarityStore: { keys: {}, createFamiliarityStore() { unexpectedStoreCreations++; throw new Error('should not create'); } },
  srsStore: { createSrsStore() { unexpectedStoreCreations++; throw new Error('should not create'); } },
  playbackHistoryStore: { createPlaybackHistoryStore() { unexpectedStoreCreations++; throw new Error('should not create'); } }
};
assert.throws(() => window.AMQUI.statisticsDashboardPanel.createStatisticsDashboardPanel({ persistence: unavailableLearningPersistence, learning: null }), /projection is unavailable/);
assert.equal(unexpectedStoreCreations, 0, 'missing required projection is rejected before creating persistence stores');
const catalogRecords = [
  { source: 'AMQ', id: 'history-song', title: 'Resolved Opening', animeTitle: 'Resolved Anime', artworkRef: { source: 'AMQ', id: 'work-1', kind: 'anime' } },
  { source: 'AMQ', id: 'due-song', title: 'Due Review Song', animeTitle: 'Due Review Work', artworkRef: { source: 'AMQ', id: 'work-2', kind: 'anime' } },
  { source: 'EMQ', id: 'history-song', title: 'Wrong Source Duplicate', animeTitle: 'Wrong Source Work', artworkRef: { source: 'EMQ', id: 'v123', kind: 'visual_novel_game' } }
];
const catalog = { size: catalogRecords.length, search({ offset, limit }) { return { records: catalogRecords.slice(offset, offset + limit), total: catalogRecords.length }; } };
const runtime = { catalogSnapshot: () => catalog };
const panel = window.AMQUI.statisticsDashboardPanel.createStatisticsDashboardPanel({ elements, persistence, learning, runtime, quizHistoryStore: history, familiarityStore: familiarity, srsAMQ: makeSrs('AMQ'), srsEMQ: makeSrs('EMQ'), playbackHistoryStore: playback });
assert.equal(elements.status.textContent, '統計已更新'); assert.match(elements.summary.textContent, /答題 1 題/); assert.match(elements.playback.textContent, /Free song/); assert.match(elements.workProgress.textContent, /Example Anime/); assert.equal(projectionCalls, 1);
assert.equal(elements.historyList.children.length, 1, 'real recent answer rows render from quiz history'); assert.match(elements.historyList.children[0].children[1].children[0].textContent, /Resolved Opening/); assert.match(elements.historyList.children[0].children[1].children[1].textContent, /Resolved Anime/); assert.match(elements.historyList.children[0].children[2].children[1].textContent, /答對/); assert.equal(panel.getSnapshot().recentHistory[0].catalogRecord, catalogRecords[0], 'history record resolution uses exact source-scoped song identity even when another source reuses the same song ID');
assert.equal(elements.reviewList.children.length, 1, 'only due SRS cards render; new cards are not mislabeled as due'); assert.match(elements.reviewList.children[0].children[1].children[0].textContent, /Due Review Song/); assert.match(elements.reviewList.children[0].children[1].children[1].textContent, /Due Review Work/); assert.match(elements.reviewCount.textContent, /到期 1 張/);
assert.equal(panel.getSnapshot().available, true, 'shared snapshot exposes the same real statistics projection');
const snapshots = []; const unsubscribe = panel.subscribe(snapshot => snapshots.push(snapshot));
assert.equal(snapshots[0].report.quiz.total, 1, 'subscribers receive the current shared report without creating another store');
badRead = true; panel.render(); assert.equal(elements.status.textContent, '讀取失敗'); assert.match(elements.error.textContent, /答題歷史/); assert.equal(projectionCalls, 1, 'read failure must not be projected as zero counts'); assert.equal(elements.historyList.children.length, 0); assert.match(elements.historyEmpty.textContent, /讀取失敗/); assert.equal(elements.reviewList.children.length, 0); assert.match(elements.reviewEmpty.textContent, /讀取失敗/);
assert.equal(snapshots.at(-1).available, false, 'read failure propagates to the profile view');
badRead = false; srsPersistenceError = true; panel.render();
assert.equal(elements.status.textContent, '讀取失敗', 'SRS persistence errors must not be presented as updated statistics');
assert.match(elements.error.textContent, /AMQ SRS/);
assert.equal(projectionCalls, 1, 'failed SRS persistence prevents the dashboard from projecting a possibly non-durable snapshot');
srsPersistenceError = false; srsRecoveryAvailable = true; panel.render();
assert.equal(elements.status.textContent, '讀取失敗', 'SRS recovery state must remain visible until the source is healthy');
assert.match(elements.error.textContent, /AMQ SRS/);
srsRecoveryAvailable = false; panel.render();
const notified = snapshots.length; unsubscribe(); panel.render(); assert.equal(snapshots.length, notified, 'unsubscribed profile listeners are not retained');
assert.equal(panel.dispose(), true); assert.equal(panel.dispose(), false);

(async () => {
  badRead = false;
  const artworkElements = Object.fromEntries(['status','error','summary','bySource','byTarget','workProgress','familiarity','srs','playback','daily','refresh','historyList','historyEmpty','historyCount','reviewList','reviewEmpty','reviewCount'].map(key => [key, new Element()]));
  const artworkResolvers = []; const artworkRequests = [];
  const artworkAdapter = { getArtwork(record) { artworkRequests.push(record); return new Promise(resolve => { artworkResolvers.push(resolve); }); } };
  const artworkPanel = window.AMQUI.statisticsDashboardPanel.createStatisticsDashboardPanel({ elements: artworkElements, persistence, learning, runtime, artworkAdapter, quizHistoryStore: history, familiarityStore: familiarity, srsAMQ: makeSrs('AMQ'), srsEMQ: makeSrs('EMQ'), playbackHistoryStore: playback });
  await new Promise(resolve => setImmediate(resolve));
  assert.ok(artworkRequests.length >= 2, 'history and due review rows reuse the injected artwork adapter for exact catalog records');
  artworkPanel.render();
  await new Promise(resolve => setImmediate(resolve));
  artworkResolvers.forEach(resolve => resolve({ url: 'https://art.example.test/work-cover.jpg', provider: 'fixture' }));
  await new Promise(resolve => setImmediate(resolve));
  await new Promise(resolve => setImmediate(resolve));
  const historySlot = artworkElements.historyList.children[0].children[0];
  assert.equal(historySlot.children.filter(child => child.tagName === 'IMG').length, 1, 'resolved artwork is attached to the matching current history row');
  const reviewSlot = artworkElements.reviewList.children[0].children[0];
  assert.equal(reviewSlot.children.filter(child => child.tagName === 'IMG').length, 1, 'resolved artwork is attached to the matching current review row');
  artworkPanel.dispose();

  const staleElements = Object.fromEntries(['status','error','summary','bySource','byTarget','workProgress','familiarity','srs','playback','daily','refresh','historyList','historyEmpty','historyCount','reviewList','reviewEmpty','reviewCount'].map(key => [key, new Element()]));
  const staleResolvers = [];
  const staleAdapter = { getArtwork() { return new Promise(resolve => staleResolvers.push(resolve)); } };
  const stalePanel = window.AMQUI.statisticsDashboardPanel.createStatisticsDashboardPanel({ elements: staleElements, persistence, learning, runtime, artworkAdapter: staleAdapter, quizHistoryStore: history, familiarityStore: familiarity, srsAMQ: makeSrs('AMQ'), srsEMQ: makeSrs('EMQ'), playbackHistoryStore: playback });
  await new Promise(resolve => setImmediate(resolve));
  stalePanel.dispose();
  staleResolvers.forEach(resolve => resolve({ url: 'https://art.example.test/late-cover.jpg' }));
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(staleElements.historyList.children[0].children[0].children.filter(child => child.tagName === 'IMG').length, 0, 'late artwork completion after dispose cannot mutate detached learning rows');
  console.log('Statistics dashboard panel tests: PASS');
})().catch(error => { console.error(error); process.exitCode = 1; });
