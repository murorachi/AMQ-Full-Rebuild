'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sandbox = { window: { setTimeout, clearTimeout } };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/persistence/app-settings-store.js'), 'utf8'), sandbox, { filename: 'src/persistence/app-settings-store.js' });
const api = sandbox.window.AMQPersistence.appSettingsStore;
class Storage {
  constructor(values = {}) { this.values = new Map(Object.entries(values)); this.failReads = false; this.failWrites = false; }
  getItem(key) { if (this.failReads) throw new Error('read denied'); return this.values.has(key) ? this.values.get(key) : null; }
  setItem(key, value) { if (this.failWrites) throw new Error('quota exceeded'); this.values.set(key, String(value)); }
}
class Events {
  constructor() { this.listeners = new Map(); }
  addEventListener(type, fn) { if (!this.listeners.has(type)) this.listeners.set(type, new Set()); this.listeners.get(type).add(fn); }
  removeEventListener(type, fn) { this.listeners.get(type)?.delete(fn); }
  fire(type, event) { for (const fn of [...(this.listeners.get(type) || [])]) fn(event); }
}
const KEY = 'amqLearningAppSettingsV1';
{
  const storage = new Storage(); const store = api.createAppSettingsStore({ storage });
  assert.deepEqual(JSON.parse(JSON.stringify(store.getSettings())), { schemaVersion: 1, catalogFilterPresets: [], target: 'anime', questionCount: 25, clipSeconds: 20, acceptPartial: false, autoPlay: true, customListId: '', srsEnabled: true, yearFrom: null, yearTo: null, includeUnknownYear: true, animeType: '', difficultyMin: null, difficultyMax: null, songType: '', watchStatus: '', randomSample: false, clipStartSeconds: 0, autoNextDelaySeconds: 0, chineseTitlesEnabled: false });
  const saved = store.set({ target: 'all', questionCount: 0, clipSeconds: 45, acceptPartial: true, autoPlay: false });
  assert.equal(saved.ok, true); assert.equal(saved.persisted, true);
  assert.equal(store.set({ customListId: 'cpl-1' }).ok, true);
  assert.equal(store.set({ srsEnabled: true, yearFrom: 2000, yearTo: 2025, includeUnknownYear: false, animeType: 'TV', difficultyMin: 2, difficultyMax: 8, songType: 'OP', watchStatus: 'completed' }).ok, true);
  assert.equal(store.getSettings().yearFrom, 2000);
  assert.equal(store.getSettings().includeUnknownYear, false);
  assert.equal(store.getSettings().animeType, 'TV');
  assert.equal(store.getSettings().difficultyMax, 8);
  assert.equal(store.getSettings().songType, 'OP');
  assert.equal(store.getSettings().watchStatus, 'completed');
  assert.equal(store.set({ yearFrom: 2025, yearTo: 2000 }).reason, 'invalid-settings', 'reversed year ranges are rejected');
  assert.equal(store.set({ difficultyMin: 9, difficultyMax: 2 }).reason, 'invalid-settings', 'reversed difficulty ranges are rejected');
  assert.equal(store.set({ watchStatus: 'invented' }).reason, 'invalid-settings', 'unknown watch statuses are rejected');
  assert.equal(store.set({ clipStartSeconds: 601 }).reason, 'invalid-settings', 'clip start is bounded');
  assert.equal(store.set({ autoNextDelaySeconds: 31 }).reason, 'invalid-settings', 'auto-next delay is bounded');
  assert.equal(store.set({ randomSample: 'yes' }).reason, 'invalid-settings', 'random sample switch requires a boolean');
  assert.equal(store.set({ chineseTitlesEnabled: 'yes' }).reason, 'invalid-settings', 'Chinese title switch requires a boolean');
  assert.equal(store.set({ chineseTitlesEnabled: true }).ok, true);
  assert.equal(store.getSettings().chineseTitlesEnabled, true);
  assert.equal(store.set({ randomSample: true, clipStartSeconds: 12, autoNextDelaySeconds: 4 }).ok, true);
  assert.equal(store.getSettings().randomSample, true);
  assert.equal(store.getSettings().clipStartSeconds, 12);
  assert.equal(store.getSettings().autoNextDelaySeconds, 4);
  assert.equal(store.set({ includeUnknownYear: 'yes' }).reason, 'invalid-settings', 'unknown-year switch requires a boolean');
  assert.equal(store.getSettings().srsEnabled, true);
  assert.equal(store.getSettings().customListId, 'cpl-1');
  assert.equal(store.set({ customListId: 42 }).reason, 'invalid-settings');
  const restored = api.createAppSettingsStore({ storage });
  assert.deepEqual(JSON.parse(JSON.stringify(restored.getSettings())), JSON.parse(storage.getItem(KEY)));
  store.dispose(); restored.dispose();
  console.log('PASS versioned settings persist and restore known schema fields');
}
{
  const raw = '{broken settings'; const storage = new Storage({ [KEY]: raw });
  const store = api.createAppSettingsStore({ storage });
  assert.equal(storage.getItem('amqLearningAppSettingsRecoveryV1'), raw);
  assert.deepEqual(JSON.parse(JSON.stringify(store.getSettings())), JSON.parse(JSON.stringify(api.defaults)));
  assert.equal(store.getStatus().recoveryAvailable, true);
  store.dispose();
  console.log('PASS malformed settings are quarantined before defaults replace the active state');
}
{
  const raw = '{preserve me'; const storage = new Storage({ [KEY]: raw }); storage.failWrites = true;
  const store = api.createAppSettingsStore({ storage });
  assert.equal(store.getStatus().blocked, true);
  assert.equal(store.set({ autoPlay: false }).persisted, false);
  assert.equal(storage.getItem(KEY), raw);
  store.dispose();
  console.log('PASS failed recovery blocks writes and preserves corrupt source bytes');
}
{
  const raw = JSON.stringify({ schemaVersion: 1, target: 'anime', questionCount: 25, clipSeconds: 20, acceptPartial: false, autoPlay: true });
  const storage = new Storage({ [KEY]: raw }); storage.failReads = true;
  const eventTarget = new Events();
  const store = api.createAppSettingsStore({ storage, eventTarget });
  assert.equal(store.getStatus().blocked, true);
  assert.equal(store.set({ autoPlay: false }).reason, 'persistence-blocked');
  assert.equal(storage.values.get(KEY), raw);
  storage.failReads = false;
  eventTarget.fire('storage', { key: KEY });
  assert.equal(store.getStatus().blocked, false);
  assert.equal(store.set({ autoPlay: false }).persisted, true);
  store.dispose();
  console.log('PASS read failure blocks mutation and the same store recovers after a successful storage event');
}
{
  const storage = new Storage(); const store = api.createAppSettingsStore({ storage });
  assert.equal(store.set({ questionCount: 501 }).reason, 'invalid-settings');
  assert.equal(store.set({ invented: true }).reason, 'invalid-settings');
  assert.equal(storage.getItem(KEY), null);
  let failedWriteNotified = false;
  store.subscribe((status, settings, source) => {
    if (source === 'write-failed' && status.error === 'quota exceeded') failedWriteNotified = true;
  });
  storage.failWrites = true;
  assert.equal(store.set({ autoPlay: false }).persisted, false);
  assert.equal(store.getSettings().autoPlay, true, 'failed writes do not commit state');
  assert.equal(failedWriteNotified, true, 'failed writes notify subscribers so UI status can update');
  store.dispose();
  console.log('PASS invalid settings and failed writes do not mutate state and write failure notifies subscribers');
}
{
  const storage = new Storage(); const eventTarget = new Events();
  const store = api.createAppSettingsStore({ storage, eventTarget });
  const notifications = [];
  store.subscribe((status, settings, source) => notifications.push({ status, settings, source }));
  assert.equal(store.set({ target: 'artist', questionCount: 8 }).ok, true);
  storage.values.clear();
  eventTarget.fire('storage', { key: null });
  assert.equal(store.getSettings().target, api.defaults.target);
  assert.equal(store.getSettings().questionCount, api.defaults.questionCount);
  assert.equal(notifications.at(-1).source, 'external');
  store.dispose();
  const count = notifications.length;
  eventTarget.fire('storage', { key: null });
  assert.equal(notifications.length, count, 'dispose removes storage listener');
  console.log('PASS storage.clear external event resets defaults and dispose releases listener');
}
{
  const legacy = { schemaVersion: 1, target: 'anime', questionCount: 25, clipSeconds: 20, acceptPartial: false, autoPlay: true };
  const storage = new Storage({ [KEY]: JSON.stringify(legacy) });
  const store = api.createAppSettingsStore({ storage });
  assert.equal(store.getSettings().srsEnabled, true, 'legacy settings preserve the enabled default without invalidating the stored schema');
  assert.equal(store.getSettings().randomSample, false, 'legacy settings default to non-random playback');
  assert.equal(store.getSettings().clipStartSeconds, 0, 'legacy settings default to the beginning of the track');
  assert.equal(store.getSettings().autoNextDelaySeconds, 0, 'legacy settings preserve manual next-question behavior');
  assert.equal(store.getSettings().chineseTitlesEnabled, false, 'legacy settings do not enable external title downloads automatically');
  assert.equal(store.set({ srsEnabled: true }).persisted, true);
  const reloaded = api.createAppSettingsStore({ storage });
  assert.equal(reloaded.getSettings().srsEnabled, true, 'global SRS toggle survives reload');
  store.dispose(); reloaded.dispose();
  console.log('PASS legacy settings remain compatible and global SRS toggle persists across reload');
}

{
  const storage = new Storage(); const store = api.createAppSettingsStore({ storage });
  const preset = { id: 'preset-a', name: '已看完 OP', filters: {
    query: '', source: 'AMQ', type: 'OP', workKind: '', animeYearFrom: '2010', animeYearTo: '2020',
    includeUnknownYear: 'false', animeType: 'TV', animeDecade: '', watchStatus: 'completed', familiarityLevel: '4', tagId: ''
  }, sortBy: 'animeYear', sortDirection: 'desc', pageSize: 50 };
  assert.equal(store.set({ catalogFilterPresets: [preset] }).persisted, true);
  const exposed = store.getSettings();
  exposed.catalogFilterPresets[0].filters.source = 'EMQ';
  assert.equal(store.getSettings().catalogFilterPresets[0].filters.source, 'AMQ', 'returned preset snapshots cannot mutate the store');
  const reloaded = api.createAppSettingsStore({ storage });
  assert.equal(reloaded.getSettings().catalogFilterPresets[0].name, '已看完 OP');
  assert.equal(reloaded.getSettings().catalogFilterPresets[0].filters.source, 'AMQ');
  assert.equal(reloaded.getSettings().catalogFilterPresets[0].pageSize, 50);
  assert.equal(reloaded.set({ catalogFilterPresets: [{ ...preset, filters: { ...preset.filters, familiarityLevel: '9' } }] }).reason, 'invalid-settings');
  assert.equal(reloaded.set({ catalogFilterPresets: [{ ...preset, filters: { ...preset.filters, inventedFilter: 'yes' } }] }).reason, 'invalid-settings', 'unknown preset filter fields are rejected');
  assert.equal(reloaded.set({ catalogFilterPresets: [preset, { ...preset, id: 'preset-b', name: '已看完 OP' }] }).reason, 'invalid-settings', 'case-insensitive duplicate preset names are rejected');
  assert.equal(reloaded.set({ catalogFilterPresets: Array.from({ length: 31 }, (_, i) => ({ ...preset, id: `p-${i}`, name: `preset ${i}` })) }).reason, 'invalid-settings', 'preset count is bounded');
  store.dispose(); reloaded.dispose();
  console.log('PASS named catalog filter presets validate, persist, reload and isolate returned snapshots');
}
console.log(`App settings store tests: 8/8 passed`);
