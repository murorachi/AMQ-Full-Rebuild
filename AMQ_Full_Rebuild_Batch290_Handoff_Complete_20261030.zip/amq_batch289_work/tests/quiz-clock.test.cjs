'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sandbox = { window: { setInterval, clearInterval }, setInterval, clearInterval };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/engine/quiz-clock.js'), 'utf8'), sandbox, { filename: 'src/engine/quiz-clock.js' });
const createQuizClock = sandbox.window.AMQEngine.quizClock.createQuizClock;
function fakeScheduler() {
  let now = 0; let nextId = 1; const timers = new Map();
  return {
    now: () => now,
    setInterval(fn, ms) { const id = nextId++; timers.set(id, { fn, ms, next: now + ms }); return id; },
    clearInterval(id) { timers.delete(id); },
    advance(ms) {
      const end = now + ms; let loops = 0;
      while (true) {
        let due = null;
        for (const [id, timer] of timers) if (timer.next <= end && (!due || timer.next < due.timer.next)) due = { id, timer };
        if (!due) break;
        if (++loops > 10000) throw new Error('fake timer loop runaway');
        now = due.timer.next;
        if (!timers.has(due.id)) continue;
        due.timer.next += due.timer.ms;
        due.timer.fn();
      }
      now = end;
    },
    activeCount: () => timers.size
  };
}
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('clock counts down only after start and fires timeout once', () => {
  const scheduler = fakeScheduler(); let timeouts = 0; const ticks = [];
  const clock = createQuizClock({ now: scheduler.now, setInterval: scheduler.setInterval, clearInterval: scheduler.clearInterval, tickMs: 100, onTick: seconds => ticks.push(seconds), onTimeout: () => timeouts++ });
  assert.equal(clock.getRemainingSeconds(), 0);
  clock.start(2);
  scheduler.advance(1900);
  assert.equal(clock.getRemainingSeconds(), 1);
  assert.equal(timeouts, 0);
  scheduler.advance(100);
  assert.equal(clock.getRemainingSeconds(), 0);
  assert.equal(timeouts, 1);
  scheduler.advance(1000);
  assert.equal(timeouts, 1);
  assert.ok(ticks.length > 2);
});
test('pause excludes paused time and resume preserves the remaining duration', () => {
  const scheduler = fakeScheduler(); let timeouts = 0;
  const clock = createQuizClock({ now: scheduler.now, setInterval: scheduler.setInterval, clearInterval: scheduler.clearInterval, tickMs: 100, onTimeout: () => timeouts++ });
  clock.start(3); scheduler.advance(1200);
  assert.equal(clock.pause(), true);
  const remaining = clock.getState().remainingMs;
  scheduler.advance(5000);
  assert.equal(clock.getState().remainingMs, remaining);
  assert.equal(timeouts, 0);
  assert.equal(clock.resume(), true);
  scheduler.advance(remaining - 1);
  assert.equal(timeouts, 0);
  scheduler.advance(1);
  assert.equal(timeouts, 1);
});
test('stop and dispose clear scheduled callbacks and prevent restart', () => {
  const scheduler = fakeScheduler();
  const clock = createQuizClock({ now: scheduler.now, setInterval: scheduler.setInterval, clearInterval: scheduler.clearInterval, tickMs: 100 });
  clock.start(5); assert.equal(scheduler.activeCount(), 1);
  clock.stop(); assert.equal(scheduler.activeCount(), 0);
  assert.equal(clock.getRemainingSeconds(), 0);
  clock.start(2); clock.dispose();
  assert.equal(scheduler.activeCount(), 0);
  assert.equal(clock.start(1), false);
});
test('clock validates duration and interval bounds', () => {
  const scheduler = fakeScheduler();
  const clock = createQuizClock({ now: scheduler.now, setInterval: scheduler.setInterval, clearInterval: scheduler.clearInterval, tickMs: 100 });
  assert.throws(() => clock.start(0), /seconds/);
  assert.throws(() => createQuizClock({ tickMs: 1 }), /tickMs/);
  clock.dispose();
});

let passed = 0;
for (const item of tests) {
  try { item.fn(); passed++; console.log(`PASS ${item.name}`); }
  catch (error) { console.error(`FAIL ${item.name}\n${error.stack}`); process.exitCode = 1; }
}
console.log(`\nQuiz clock tests: ${passed}/${tests.length} passed`);
if (passed !== tests.length) process.exitCode = 1;
