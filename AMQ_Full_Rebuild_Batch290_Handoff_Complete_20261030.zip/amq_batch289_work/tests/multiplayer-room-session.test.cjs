'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '../src/multiplayer/room-session.js'), 'utf8');
function load(client, extra = {}) {
  const context = { Date, Math, AbortController, ...extra };
  context.globalThis = context;
  vm.runInNewContext(source, context);
  return context.AMQMultiplayer.roomSession.createRoomSession({ client, pollIntervalMs: 100, maxRetryMs: 800, createRequestId: () => 'stable-id', ...extra });
}
function deferred() { let resolve; let reject; const promise = new Promise((a, b) => { resolve = a; reject = b; }); return { promise, resolve, reject }; }
function snapshot(revision, extra = {}) { return { snapshot: { revision, unchanged: false, state: { phase: 'waiting', ...extra } }, timeoutAssessment: null }; }
function fakeTimers() {
  let nextId = 1; const pending = new Map();
  return { pending, setTimeout(fn, delay) { const id = nextId++; pending.set(id, { fn, delay }); return id; }, clearTimeout(id) { pending.delete(id); }, setInterval() { throw new Error('interval should not be used'); }, clearInterval() {}, runNext() { const entry = pending.entries().next().value; if (!entry) return false; pending.delete(entry[0]); entry[1].fn(); return true; } };
}

test('room session keeps one poll in flight and applies only monotonically newer snapshots', async () => {
  const timers = fakeTimers(); const first = deferred(); let calls = 0;
  const client = { getSnapshot() { calls++; return calls === 1 ? first.promise : Promise.resolve(snapshot(2)); }, command: async () => ({}) };
  const session = load(client, { timers }); session.attach('abcdef123456'); session.start(); session.start();
  await Promise.resolve(); await Promise.resolve(); assert.equal(calls, 1);
  first.resolve(snapshot(1)); await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().revision, 1); assert.equal(timers.pending.size, 1);
  timers.runNext(); await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().revision, 2); assert.equal(calls, 2);
  session.dispose(); assert.equal(timers.pending.size, 0);
});

test('stop aborts in-flight polling and late responses cannot mutate state or reschedule', async () => {
  const timers = fakeTimers(); const pending = deferred(); let signal;
  const client = { getSnapshot(_id, options) { signal = options.signal; return pending.promise; }, command: async () => ({}) };
  const session = load(client, { timers }); session.attach('abcdef123456'); session.start();
  await Promise.resolve(); await Promise.resolve(); session.stop();
  assert.equal(signal.aborted, true);
  pending.resolve(snapshot(7)); await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().revision, null); assert.equal(timers.pending.size, 0); assert.equal(session.isRunning, false);
  session.dispose();
});

test('late completion from a stopped generation cannot detach the new poll abort controller', async () => {
  const timers = fakeTimers(); const oldRequest = deferred(); const newRequest = deferred(); let calls = 0; let signals = [];
  const client = { getSnapshot(_id, options) { signals.push(options.signal); calls++; return calls === 1 ? oldRequest.promise : newRequest.promise; }, command: async () => ({}) };
  const session = load(client, { timers }); session.attach('abcdef123456'); session.start();
  await Promise.resolve(); await Promise.resolve(); session.stop(); session.start();
  await Promise.resolve(); await Promise.resolve(); assert.equal(calls, 2);
  oldRequest.resolve(snapshot(1)); await new Promise(resolve => setImmediate(resolve));
  session.stop(); assert.equal(signals[1].aborted, true);
  newRequest.resolve(snapshot(2)); await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().revision, null); session.dispose();
});

test('unchanged revision preserves current snapshot and network recovery polls again with backoff', async () => {
  const timers = fakeTimers(); let calls = 0;
  const client = { async getSnapshot(_id, options) { calls++; if (calls === 1) return snapshot(3); if (calls === 2) throw Object.assign(new Error('offline'), { code: 'MULTIPLAYER_NETWORK_ERROR' }); return { snapshot: { revision: 3, unchanged: true }, timeoutAssessment: null }; }, command: async () => ({}) };
  const session = load(client, { timers }); session.attach('abcdef123456'); session.start();
  await new Promise(resolve => setImmediate(resolve)); assert.equal(session.getState().revision, 3);
  timers.runNext(); await new Promise(resolve => setImmediate(resolve)); assert.equal(session.getState().status, 'offline');
  assert.equal([...timers.pending.values()][0].delay, 200);
  timers.runNext(); await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().revision, 3); assert.equal(session.getState().status, 'connected');
  session.dispose();
});

test('command network retry reuses requestId and expected revision; revision conflict is not retained', async () => {
  const timers = fakeTimers(); const calls = [];
  const client = { getSnapshot: async () => snapshot(4), async command(_id, type, fields) { calls.push({ type, fields }); if (calls.length === 1) throw Object.assign(new Error('offline'), { code: 'MULTIPLAYER_NETWORK_ERROR' }); if (calls.length === 2) return { snapshot: { revision: 5, unchanged: false, state: { phase: 'waiting' } } }; throw Object.assign(new Error('stale'), { code: 'ROOM_REVISION_CONFLICT', status: 409 }); } };
  const session = load(client, { timers }); session.attach('abcdef123456', { revision: 4, unchanged: false, state: { phase: 'waiting' } });
  await assert.rejects(session.setReady(true), error => error.code === 'MULTIPLAYER_NETWORK_ERROR');
  await session.setReady(true);
  assert.equal(calls[0].fields.requestId, calls[1].fields.requestId); assert.equal(calls[0].fields.expectedRevision, 4);
  await assert.rejects(session.dispatch('player.ready', { ready: false }), error => error.code === 'ROOM_REVISION_CONFLICT');
  session.dispose();
});

test('network retry keeps the original command revision even if polling observes a newer snapshot', async () => {
  const timers = fakeTimers(); const calls = []; let polls = 0;
  const client = { async getSnapshot() { polls++; return snapshot(polls === 1 ? 4 : 9); }, async command(_id, type, fields) { calls.push({ type, fields: { ...fields } }); if (calls.length === 1) throw Object.assign(new Error('offline'), { code: 'MULTIPLAYER_NETWORK_ERROR' }); return { snapshot: { revision: 10, unchanged: false, state: { phase: 'waiting' } } }; } };
  const session = load(client, { timers }); session.attach('abcdef123456'); session.start();
  await new Promise(resolve => setImmediate(resolve)); assert.equal(session.getState().revision, 4);
  await assert.rejects(session.setReady(true), error => error.code === 'MULTIPLAYER_NETWORK_ERROR');
  timers.runNext(); await new Promise(resolve => setImmediate(resolve)); assert.equal(session.getState().revision, 9);
  await session.setReady(true);
  assert.equal(calls[0].fields.requestId, calls[1].fields.requestId);
  assert.equal(calls[0].fields.expectedRevision, 4); assert.equal(calls[1].fields.expectedRevision, 4);
  session.dispose();
});

test('invalid room, invalid snapshot and use after dispose fail explicitly', async () => {
  const timers = fakeTimers();
  const session = load({ getSnapshot: async () => ({}), command: async () => ({}) }, { timers });
  assert.throws(() => session.attach('bad'), error => error.code === 'ROOM_ID_INVALID');
  session.attach('abcdef123456'); session.start();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().status, 'offline');
  session.dispose(); assert.throws(() => session.start(), error => error.code === 'ROOM_SESSION_DISPOSED');
});


test('late lower-revision poll response cannot overwrite a newer command snapshot', async () => {
  const timers = fakeTimers(); const stalePoll = deferred(); let polls = 0; let listeners = [];
  const client = {
    getSnapshot() { polls++; return polls === 1 ? Promise.resolve(snapshot(5)) : stalePoll.promise; },
    async command() { return { snapshot: { revision: 7, unchanged: false, state: { phase: 'active', marker: 'command-result' } } }; }
  };
  const session = load(client, { timers }); session.attach('abcdef123456');
  session.subscribe(value => listeners.push(value.revision)); session.start();
  await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().revision, 5);
  timers.runNext(); await Promise.resolve(); await Promise.resolve();
  assert.equal(polls, 2, 'second poll should be in flight');
  await session.dispatch('player.ready', { ready: true });
  assert.equal(session.getState().revision, 7);
  stalePoll.resolve(snapshot(6)); await new Promise(resolve => setImmediate(resolve));
  assert.equal(session.getState().revision, 7, 'stale response must not roll back the command snapshot');
  assert.equal(listeners.includes(6), false, 'stale revision must not be emitted');
  session.dispose();
});
