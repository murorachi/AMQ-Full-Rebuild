'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sandbox = { window: {} };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/data/audio-candidates.js'), 'utf8'), sandbox, { filename: 'src/data/audio-candidates.js' });
const api = sandbox.window.AMQData.audioCandidates;
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('AMQ candidate resolver preserves the three reference mirror hosts in their verified order', () => {
  const candidates = api.createAMQAudioCandidates('folder/Opening Theme.mp3');
  assert.deepEqual(JSON.parse(JSON.stringify(candidates.map(candidate => candidate.url))), [
    'https://nawdist.animemusicquiz.com/Opening%20Theme.mp3',
    'https://naedist.animemusicquiz.com/Opening%20Theme.mp3',
    'https://eudist.animemusicquiz.com/Opening%20Theme.mp3'
  ]);
  assert.ok(candidates.every(candidate => candidate.kind === 'audio'));
  assert.equal(Object.isFrozen(candidates), true);
  assert.equal(Object.isFrozen(candidates[0]), true);
});
test('AMQ candidate resolver returns an empty list for missing audio filenames', () => {
  assert.deepEqual(JSON.parse(JSON.stringify(api.createAMQAudioCandidates(''))), []);
  assert.deepEqual(JSON.parse(JSON.stringify(api.createAMQAudioCandidates(null))), []);
});
test('EMQ resolver inserts the observed Catbox mirror before the original URL and deduplicates candidates', () => {
  const original = 'https://erogemusicquiz.com/selfhoststorage/catbox/abc123.mp3';
  const candidates = api.createEMQAudioCandidates([original, original, ' https://cdn.example/song.mp3 ']);
  assert.deepEqual(JSON.parse(JSON.stringify(candidates.map(candidate => candidate.url))), [
    'https://files.catbox.moe/abc123.mp3', original, 'https://cdn.example/song.mp3'
  ]);
  assert.equal(candidates[0].source, 'files.catbox.moe');
  assert.equal(candidates[1].source, 'erogemusicquiz.com');
});
test('EMQ resolver rejects a non-array source field and ignores blank entries', () => {
  assert.throws(() => api.createEMQAudioCandidates('https://example.invalid/audio.mp3'), /array/);
  assert.deepEqual(JSON.parse(JSON.stringify(api.createEMQAudioCandidates(['', '  ']))), []);
});
test('EMQ userup WebA candidates follow legacy Asia CDN then original then WebM sibling fallback', () => {
  const url = 'https://erogemusicquiz.com/selfhoststorage/userup/weba/abc-123.weba?token=keep';
  const candidates = api.createEMQAudioCandidates([url]);
  assert.deepEqual(JSON.parse(JSON.stringify(candidates.map(candidate => candidate.url))), [
    'https://asiadist.erogemusicquiz.com/selfhoststorage/userup/weba/abc-123.weba?token=keep',
    url,
    'https://asiadist.erogemusicquiz.com/selfhoststorage/userup/abc-123.webm?token=keep',
    'https://erogemusicquiz.com/selfhoststorage/userup/abc-123.webm?token=keep'
  ]);
  assert.deepEqual(JSON.parse(JSON.stringify(candidates.map(candidate => candidate.source))), [
    'asiadist.erogemusicquiz.com', 'erogemusicquiz.com', 'asiadist.erogemusicquiz.com', 'erogemusicquiz.com'
  ]);
});
test('reported EMQ song 2000042847 WebA record expands into the four known candidates', () => {
  const url = 'https://erogemusicquiz.com/selfhoststorage/userup/weba/58495f58-0048-4177-9b9e-0f1d55b11e32.weba';
  const candidates = api.createEMQAudioCandidates([url]);
  assert.equal(candidates.length, 4);
  assert.deepEqual(JSON.parse(JSON.stringify(candidates.map(candidate => new URL(candidate.url).pathname.split('.').pop()))), ['weba', 'weba', 'webm', 'webm']);
  assert.equal(candidates[0].source, 'asiadist.erogemusicquiz.com');
  assert.equal(candidates[1].source, 'erogemusicquiz.com');
});
test('EMQ userup MP3 tries the Asia CDN before the original server URL', () => {
  const original = 'https://erogemusicquiz.com/selfhoststorage/userup/fb3423e0-0f09-4749-bca2-ed6ee38347b5.mp3';
  const candidates = api.createEMQAudioCandidates([original]);
  assert.deepEqual(JSON.parse(JSON.stringify(candidates.map(candidate => candidate.url))), [
    'https://asiadist.erogemusicquiz.com/selfhoststorage/userup/fb3423e0-0f09-4749-bca2-ed6ee38347b5.mp3',
    original
  ]);
});
test('EMQ Catbox fallback is deduplicated and unrelated WebA URLs are not rewritten', () => {
  const catbox = 'https://erogemusicquiz.com/selfhoststorage/catbox/file-1.mp3';
  assert.deepEqual(JSON.parse(JSON.stringify(api.createEMQAudioCandidates([catbox, catbox]).map(candidate => candidate.url))), [
    'https://files.catbox.moe/file-1.mp3', catbox
  ]);
  assert.deepEqual(JSON.parse(JSON.stringify(api.createEMQAudioCandidates(['https://cdn.example/audio.weba']).map(candidate => candidate.url))), [
    'https://cdn.example/audio.weba'
  ]);
});
test('audio candidate validator rejects malformed entries and duplicate URLs', () => {
  const context = { window: {} }; vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(root, 'src/data/identity.js'), 'utf8'), context, { filename: 'src/data/identity.js' });
  vm.runInContext(fs.readFileSync(path.join(root, 'src/data/validate.js'), 'utf8'), context, { filename: 'src/data/validate.js' });
  const validate = context.window.AMQData.validateRecord;
  const base = { id: 1, title: 'Song', source: 'AMQ' };
  assert.equal(validate({ ...base, audioCandidates: [{ url: '', source: 'mirror', kind: 'audio' }] })[0].code, 'INVALID_AUDIO_CANDIDATE');
  assert.equal(validate({ ...base, audioCandidates: [{ url: 'u', source: 'mirror', kind: 'video' }] })[0].code, 'INVALID_AUDIO_CANDIDATE');
  assert.equal(validate({ ...base, audioCandidates: [{ url: 'u', source: 'mirror', kind: 'audio' }, { url: 'u', source: 'mirror', kind: 'audio' }] })[0].code, 'DUPLICATE_AUDIO_CANDIDATE');
});

let passed = 0;
for (const item of tests) {
  try { item.fn(); passed++; console.log(`PASS ${item.name}`); }
  catch (error) { console.error(`FAIL ${item.name}\n${error.stack}`); process.exitCode = 1; }
}
console.log(`\nAudio candidate tests: ${passed}/${tests.length} passed`);
if (passed !== tests.length) process.exitCode = 1;
