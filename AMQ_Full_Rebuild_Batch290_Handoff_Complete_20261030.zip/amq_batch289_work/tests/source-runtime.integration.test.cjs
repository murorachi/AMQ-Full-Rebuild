'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');

async function main() {
  const window = {
    AbortController, Blob, Response, DecompressionStream, Uint8Array, atob,
    setTimeout, clearTimeout
  };
  const sandbox = { window, AbortController, setTimeout, clearTimeout, Uint8Array, Blob, Response, DecompressionStream, atob };
  vm.createContext(sandbox);
  const files = [
    'src/data/assets/data.js', 'src/data/assets/emq-data.js',
    'src/core/state.js', 'src/core/errors.js', 'src/data/identity.js', 'src/data/validate.js',
    'src/data/source-adapter.js', 'src/data/source-registry.js',
    'src/data/audio-candidates.js', 'src/data/source-mappers.js', 'src/data/database-update.js', 'src/data/query-index.js',
    'src/data/load-state.js', 'src/data/repository.js',
    'src/data/runtime-bootstrap.js', 'src/data/source-runtime.js', 'src/engine/quiz-pool.js', 'src/app-runtime.js'
  ];
  for (const file of files) {
    vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), sandbox, { filename: file, timeout: 15000 });
  }

  const data = window.AMQData;
  const state = window.AMQCore.state;
  const updateStore = { async getActive() { return null; }, async replaceAtomic() { throw new Error('not used'); }, async clearAtomic() { return true; } };
  const bundle = window.AMQAppRuntime.createRuntime({ stateStore: state, databaseUpdateStore: updateStore });
  assert.ok(bundle, 'app composition should configure the browser runtime when source assets are present');
  try {
    assert.equal(bundle.sourceInfo.AMQ.songs, 38821);
    const amq = await bundle.runtime.loadCurrentMode();
    assert.equal(amq.accepted, true, 'AMQ load should be accepted');
    assert.equal(amq.state.dataStatus, 'loaded');
    assert.equal(amq.state.dataValidCount, 38821);
    const amqCatalog = bundle.runtime.catalogSnapshot();
    assert.equal(amqCatalog.size, 38821);
    const amqWorkRecord = await bundle.resolveArtworkRecord('AMQ', 1);
    assert.equal(amqWorkRecord.animeId, 1, 'explicit AMQ workId resolves through formal anime data index');
    assert.equal(amqWorkRecord.artworkRef.annId, 1226, 'AMQ artwork mapping uses the stored ANNID, not a guessed title lookup');
    assert.equal(amqWorkRecord.artworkRef.kind, 'anime');
    const amqPage = amqCatalog.search({ source: 'AMQ', limit: 25 });
    assert.equal(amqPage.total, 38821);
    assert.equal(amqPage.records.length, 25);
    const amqProbe = amqCatalog.search({ source: 'AMQ', query: amqPage.records[0].title, limit: 5 });
    assert.ok(amqProbe.total >= 1, 'real AMQ title search should find its source record');
    const amqGroups = amqCatalog.groupBy('source');
    assert.equal(amqGroups.groups.find(group => group.value === 'AMQ').count, 38821);

    state.update({ mode: 'EMQ' });
    const emq = await bundle.runtime.loadCurrentMode();
    assert.equal(emq.accepted, true, 'EMQ load should be accepted');
    assert.equal(emq.state.dataStatus, 'loaded');
    assert.equal(emq.state.dataValidCount, 16839);
    assert.equal(bundle.runtime.catalogSnapshot().size, 16839);
    const emqCatalog = bundle.runtime.catalogSnapshot();
    const emqPage = emqCatalog.search({ source: 'EMQ', limit: 25 });
    const emqWorkId = emqPage.records[0].animeId;
    const emqWorkRecord = await bundle.resolveArtworkRecord('EMQ', emqWorkId);
    assert.equal(emqWorkRecord.animeId, emqWorkId, 'explicit EMQ workId resolves through formal work data');
    assert.equal(emqWorkRecord.artworkRef.kind, 'visual_novel_game');
    assert.equal(emqWorkRecord.artworkRef.source, 'EMQ');
    assert.equal(emqPage.total, 16839);
    assert.equal(emqPage.records.length, 25);
    const emqProbe = emqCatalog.search({ source: 'EMQ', query: emqPage.records[0].title, limit: 5 });
    assert.ok(emqProbe.total >= 1, 'real EMQ title search should find its source record');
    assert.ok(Array.isArray(emqProbe.records[0].audioCandidates));
    assert.equal(emqProbe.records[0].audioCandidates[0].url, 'https://files.catbox.moe/0c6rav.mp3');
    assert.equal(emqProbe.records[0].audioCandidates[1].url, 'https://erogemusicquiz.com/selfhoststorage/catbox/0c6rav.mp3');
    const amqAudioRecords = [];
    for (let offset = 0; offset < 38821; offset += 10000) {
      amqAudioRecords.push(...amqCatalog.search({ source: 'AMQ', offset, limit: 10000 }).records.filter(record => record.audioCandidates.length > 0));
    }
    assert.equal(amqAudioRecords.length, 37939);
    const allAmqRecords = [];
    for (let offset = 0; offset < 38821; offset += 10000) allAmqRecords.push(...amqCatalog.search({ source: 'AMQ', offset, limit: 10000 }).records);
    const amqQuizPool = window.AMQEngine.quizPool.createQuizPool(allAmqRecords, 'AMQ');
    assert.ok(amqQuizPool.length > 30000 && amqQuizPool.length <= 37939);
    assert.deepEqual(JSON.parse(JSON.stringify(amqAudioRecords[0].audioCandidates.map(candidate => candidate.source))), ['nawdist.animemusicquiz.com', 'naedist.animemusicquiz.com', 'eudist.animemusicquiz.com']);
    assert.equal(emqCatalog.groupBy('source').groups.find(group => group.value === 'EMQ').count, 16839);
    const allEmqRecords = [];
    for (let offset = 0; offset < 16839; offset += 10000) allEmqRecords.push(...emqCatalog.search({ source: 'EMQ', offset, limit: 10000 }).records);
    const emqQuizPool = window.AMQEngine.quizPool.createQuizPool(allEmqRecords, 'EMQ');
    assert.ok(emqQuizPool.length > 15000 && emqQuizPool.length <= 16839);
    console.log(`PASS real quiz pools: AMQ ${amqQuizPool.length} playable records, EMQ ${emqQuizPool.length} playable records`);

    state.update({ mode: 'MIX' });
    const mix = await bundle.runtime.loadCurrentMode();
    assert.equal(mix.accepted, true, 'MIX loads both verified source adapters');
    assert.equal(mix.state.dataStatus, 'loaded');
    assert.equal(mix.state.dataValidCount, 55660);
    const mixCatalog = bundle.runtime.catalogSnapshot();
    assert.equal(mixCatalog.size, 55660);
    const mixGroups = mixCatalog.groupBy('source').groups;
    assert.equal(mixGroups.find(group => group.value === 'AMQ').count, 38821);
    assert.equal(mixGroups.find(group => group.value === 'EMQ').count, 16839);
    const allMixedRecords = [];
    for (let offset = 0; offset < 55660; offset += 10000) allMixedRecords.push(...mixCatalog.search({ source: ['AMQ', 'EMQ'], offset, limit: 10000 }).records);
    const mixedQuizPool = window.AMQEngine.quizPool.createQuizPool(allMixedRecords, 'MIX');
    assert.equal(mixedQuizPool.length, 54778, 'MIX candidate pool combines both playable source pools without uniform source weighting');
    assert.equal(mixedQuizPool.filter(record => record.source === 'AMQ').length, 37939);
    assert.equal(mixedQuizPool.filter(record => record.source === 'EMQ').length, 16839);
    console.log(`PASS source runtime: AMQ ${amqCatalog.size}, EMQ ${emqCatalog.size}, MIX ${mixCatalog.size} normalized records; playable MIX pool ${mixedQuizPool.length}`);
  } finally {
    bundle.dispose();
  }
}

main().catch(error => {
  console.error(`FAIL source runtime integration\n${error.stack || error.message}`);
  process.exitCode = 1;
});
