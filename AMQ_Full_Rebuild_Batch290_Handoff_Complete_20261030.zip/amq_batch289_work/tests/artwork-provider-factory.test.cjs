'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
function load(data) { const window = { AMQData: data || {} }; vm.runInNewContext(fs.readFileSync(require.resolve('../src/integrations/artwork-provider-factory.js'), 'utf8'), { window, Object, String, Error }); return window.AMQIntegrations.artworkProviderFactory; }
test('provider factory only resolves exact explicit external IDs and preserves attribution', async () => {
  const api = load(); let calls = [];
  const factory = api.createArtworkProviders({ vndbAdapter: { async getVisualNovel(id, options) { calls.push({ id, signal: options.signal }); return { id, imageUrl: 'https://images.example/v17.jpg' }; } } });
  const signal = new AbortController().signal;
  const provider = factory.providers.EMQ;
  const result = await provider({ record: { source: 'EMQ', id: 700, animeId: 99, artworkRef: { source: 'EMQ', id: 99, kind: 'visual_novel_game', vndbId: 'V17' } }, signal });
  assert.equal(result.url, 'https://images.example/v17.jpg');
  assert.equal(result.provider, 'VNDB');
  assert.equal(result.sourceUrl, 'https://vndb.org/v17');
  assert.equal(calls.length, 1); assert.equal(calls[0].id, 'v17'); assert.equal(calls[0].signal, signal);
});

test('provider factory creates one shared crosswalk provider for AniList fallback and disposes it with the provider bundle', async () => {
  let created = 0, disposed = 0, lookedUp = 0;
  const api = load({ chineseTitleProvider: { createChineseTitleProvider() { created++; return { getAniListId(record) { return record.animeAnnId === 9876 ? '456' : ''; }, dispose() { disposed++; } }; } } });
  const factory = api.createArtworkProviders({
    annArtworkAdapter: { async getArtwork() { return { imageUrl: null }; } },
    anilistAdapter: { async getMediaById(id) { lookedUp = id; return { coverUrl: 'https://img.example/456.jpg', siteUrl: 'https://anilist.co/anime/456' }; } }
  });
  assert.equal(created, 1);
  assert.ok(factory.chineseTitleProvider, 'the app can share the factory-owned crosswalk provider with Catalog');
  const result = await factory.providers.AMQ({ record: { source: 'AMQ', id: 1, animeAnnId: 9876, artworkRef: { source: 'AMQ', id: 20, kind: 'anime', annId: 9876 } }, signal: new AbortController().signal });
  assert.equal(lookedUp, 456);
  assert.equal(result.provider, 'AniList');
  assert.equal(factory.dispose(), true);
  assert.equal(disposed, 1, 'factory disposes its shared crosswalk provider exactly once');
});

test('provider factory refuses source-local IDs and never title-searches ambiguous works', async () => {
  const api = load(); let calls = 0;
  const factory = api.createArtworkProviders({ vndbAdapter: { async getVisualNovel() { calls++; return { imageUrl: 'https://images.example/wrong.jpg' }; }, async searchVisualNovels() { calls++; } } });
  const result = await factory.providers.EMQ({ record: { source: 'EMQ', id: 5, animeId: 6, animeTitle: 'Same title', artworkRef: { source: 'EMQ', id: 6, kind: 'visual_novel_game' } }, signal: new AbortController().signal });
  assert.equal(result, null); assert.equal(calls, 0);
  const amq = await factory.providers.AMQ({ record: { source: 'AMQ', id: 1, animeId: 6, animeTitle: 'Anime', artworkRef: { source: 'AMQ', id: 6, kind: 'anime' } }, signal: new AbortController().signal });
  assert.equal(amq, null); assert.equal(calls, 0);
});
test('provider factory honors cancellation and disposal', async () => {
  const api = load(); let calls = 0;
  const factory = api.createArtworkProviders({ vndbAdapter: { async getVisualNovel(id, options) { calls++; if (options.signal.aborted) throw Object.assign(new Error('cancelled'), { name: 'AbortError' }); return { id, imageUrl: null }; } } });
  const controller = new AbortController(); controller.abort();
  await assert.rejects(factory.providers.EMQ({ record: { artworkRef: { source: 'EMQ', id: 1, kind: 'visual_novel_game', vndbId: 'v1' } }, signal: controller.signal }), { code: 'ARTWORK_REQUEST_CANCELLED' });
  assert.equal(calls, 0); assert.equal(factory.dispose(), true); assert.equal(factory.dispose(), false);
  await assert.rejects(factory.providers.EMQ({ record: {}, signal: new AbortController().signal }), { code: 'ARTWORK_PROVIDER_DISPOSED' });
});
test('AMQ artwork provider prefers direct ANN cover from the stored ANNID', async () => {
  const api = load(); const calls = [];
  const factory = api.createArtworkProviders({ annArtworkAdapter: { async getArtwork(id, options) { calls.push({ id, signal: options.signal }); return { imageUrl: 'https://cdn.animenewsnetwork.com/thumbnails/fit200x200/encyc/A123-1.jpg', sourceUrl: `https://www.animenewsnetwork.com/encyclopedia/anime.php?id=${id}`, attribution: 'ANN' }; } }, anilistAdapter: { async getMediaById() { throw new Error('AniList must not be called when ANN has artwork'); } } });
  const signal = new AbortController().signal;
  const result = await factory.providers.AMQ({ record: { source: 'AMQ', animeAnnId: 123, artworkRef: { source: 'AMQ', id: 77, kind: 'anime', annId: 123 } }, signal });
  assert.equal(calls[0].id, 123); assert.equal(calls[0].signal, signal);
  assert.equal(result.url, 'https://cdn.animenewsnetwork.com/thumbnails/fit200x200/encyc/A123-1.jpg');
  assert.equal(result.provider, 'ANN'); assert.equal(result.sourceUrl, 'https://www.animenewsnetwork.com/encyclopedia/anime.php?id=123');
});
test('AMQ falls back to AniList only when ANN has no image and an explicit crosswalk exists', async () => {
  const api = load(); const calls = [];
  const factory = api.createArtworkProviders({ annArtworkAdapter: { async getArtwork(id) { calls.push(`ann:${id}`); return { imageUrl: null }; } }, anilistAdapter: { async getMediaById(id) { calls.push(`ani:${id}`); return { coverUrl: 'https://img.example/ani.jpg', siteUrl: `https://anilist.co/anime/${id}` }; } }, chineseTitleProvider: { getAniListId() { return '456'; } } });
  const result = await factory.providers.AMQ({ record: { source: 'AMQ', animeAnnId: 123, artworkRef: { source: 'AMQ', id: 77, kind: 'anime', annId: 123 } }, signal: new AbortController().signal });
  assert.deepEqual(calls, ['ann:123', 'ani:456']); assert.equal(result.provider, 'AniList');
});
test('AMQ uses explicit AniList crosswalk after ANN transport failure but preserves cancellation', async () => {
  const api = load(); let aniCalls = 0;
  const factory = api.createArtworkProviders({ annArtworkAdapter: { async getArtwork() { throw Object.assign(new Error('offline'), { code: 'ANN_NETWORK_ERROR' }); } }, anilistAdapter: { async getMediaById(id) { aniCalls++; return { coverUrl: `https://img.example/${id}.jpg`, siteUrl: `https://anilist.co/anime/${id}` }; } }, chineseTitleProvider: { getAniListId() { return '456'; } } });
  const result = await factory.providers.AMQ({ record: { source: 'AMQ', animeAnnId: 123, artworkRef: { source: 'AMQ', id: 77, kind: 'anime', annId: 123 } }, signal: new AbortController().signal });
  assert.equal(result.provider, 'AniList'); assert.equal(aniCalls, 1);
  const cancelled = api.createArtworkProviders({ annArtworkAdapter: { async getArtwork() { throw Object.assign(new Error('cancelled'), { name: 'AbortError', code: 'ANN_REQUEST_CANCELLED' }); } }, anilistAdapter: { async getMediaById() { aniCalls++; } }, chineseTitleProvider: { getAniListId() { return '456'; } } });
  await assert.rejects(cancelled.providers.AMQ({ record: { source: 'AMQ', animeAnnId: 123, artworkRef: { source: 'AMQ', id: 77, kind: 'anime', annId: 123 } }, signal: new AbortController().signal }), { code: 'ANN_REQUEST_CANCELLED' });
  assert.equal(aniCalls, 1, 'cancellation is never swallowed into fallback');
});

test('AMQ provider falls back to explicit AniList crosswalk for ANN rate-limit, HTTP, and timeout errors', async () => {
  const api = load();
  for (const code of ['ANN_RATE_LIMITED', 'ANN_HTTP_ERROR', 'ANN_TIMEOUT']) {
    let fallbackCalls = 0;
    const factory = api.createArtworkProviders({
      annArtworkAdapter: { async getArtwork() { throw Object.assign(new Error(code), { code }); } },
      anilistAdapter: { async getMediaById(id) { fallbackCalls++; return { coverUrl: `https://img.example/${id}.jpg`, siteUrl: `https://anilist.co/anime/${id}` }; } },
      chineseTitleProvider: { getAniListId() { return '456'; } }
    });
    const result = await factory.providers.AMQ({ record: { source: 'AMQ', animeAnnId: 123, artworkRef: { source: 'AMQ', id: 77, kind: 'anime', annId: 123 } }, signal: new AbortController().signal });
    assert.equal(result.provider, 'AniList', `${code} should permit explicit crosswalk fallback`);
    assert.equal(fallbackCalls, 1);
    factory.dispose();
  }
});

test('provider factory exposes bounded, privacy-safe provider diagnostics for missing IDs and failures', async () => {
  const api = load();
  let tick = 100;
  const factory = api.createArtworkProviders({
    now: () => tick++, maxDiagnostics: 3,
    annArtworkAdapter: { async getArtwork() { throw Object.assign(new Error('private URL should not be exposed'), { code: 'ANN_RATE_LIMITED' }); } },
    anilistAdapter: { async getMediaById() { throw Object.assign(new Error('request detail should not be exposed'), { code: 'EXTERNAL_NETWORK_ERROR' }); } }
  });
  const record = { source: 'AMQ', animeTitle: 'Private title', animeAnnId: 123, artworkRef: { source: 'AMQ', id: 999, kind: 'anime', annId: 123, anilistId: '456' } };
  await assert.rejects(factory.providers.AMQ({ record, signal: new AbortController().signal }), { code: 'EXTERNAL_NETWORK_ERROR' });
  assert.deepEqual(JSON.parse(JSON.stringify(factory.getDiagnostics().map(item => [item.provider, item.outcome, item.code]))), [
    ['ANN', 'error', 'ANN_RATE_LIMITED'], ['AniList', 'error', 'EXTERNAL_NETWORK_ERROR']
  ]);
  const safeJson = JSON.stringify(factory.getDiagnostics());
  assert.equal(safeJson.includes('Private title'), false);
  assert.equal(safeJson.includes('999'), false);
  assert.equal(safeJson.includes('private URL'), false);
  await factory.providers.EMQ({ record: { artworkRef: { source: 'EMQ', id: 4, kind: 'visual_novel_game' } }, signal: new AbortController().signal });
  await factory.providers.AMQ({ record: { artworkRef: { source: 'AMQ', id: 5, kind: 'anime' } }, signal: new AbortController().signal });
  assert.equal(factory.getDiagnostics().length, 3, 'diagnostics are bounded');
  assert.equal(factory.clearDiagnostics(), true);
  assert.deepEqual(JSON.parse(JSON.stringify(factory.getDiagnostics())), []);
  factory.dispose();
});

test('provider factory records successful ANN and skipped AniList crosswalk without changing provider selection', async () => {
  const api = load();
  const factory = api.createArtworkProviders({ annArtworkAdapter: { async getArtwork(id) { return { imageUrl: `https://img.example/${id}.jpg` }; } } });
  const result = await factory.providers.AMQ({ record: { source: 'AMQ', artworkRef: { source: 'AMQ', id: 10, kind: 'anime', annId: 44 } }, signal: new AbortController().signal });
  assert.equal(result.provider, 'ANN');
  assert.deepEqual(JSON.parse(JSON.stringify(factory.getDiagnostics().map(item => [item.provider, item.outcome]))), [['ANN', 'available']]);
  factory.dispose();
});
