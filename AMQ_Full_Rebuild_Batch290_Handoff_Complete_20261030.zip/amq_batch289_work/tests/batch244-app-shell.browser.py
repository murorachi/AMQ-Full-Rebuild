#!/usr/bin/env python3
"""Real-index browser smoke test. Inline local assets because sandbox navigation is blocked."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
ARTIFACTS = ROOT / "artifacts" / "batch244-regression"
ARTIFACTS.mkdir(parents=True, exist_ok=True)
html = (SRC / "index.html").read_text(encoding="utf-8")

def inline_css(match):
    path = (SRC / match.group(1)).resolve()
    return "<style>\n" + path.read_text(encoding="utf-8") + "\n</style>"

def inline_js(match):
    path = (SRC / match.group(1)).resolve()
    return "<script>\n" + path.read_text(encoding="utf-8") + "\n</script>"

html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', inline_css, html)
html = re.sub(r'<script src="([^"]+)"></script>', inline_js, html)
failures = []
checks = 0

def check(condition, label):
    global checks
    checks += 1
    if not condition:
        failures.append(label)
        print(f"FAIL {label}")
    else:
        print(f"PASS {label}")

with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path="/usr/bin/chromium", args=["--no-sandbox", "--disable-dev-shm-usage"])
    page = browser.new_page(viewport={"width": 1440, "height": 900})
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.set_content(html, wait_until="domcontentloaded", timeout=60000)
    page.wait_for_timeout(900)
    check(page.locator("#page-home").is_visible(), "real app starts on the home page")
    check(page.locator("#home-pie-core").count() == 1, "home pie core is present")
    check("AMQ ADAPTATION" in page.locator("#page-home .home-copy .eyebrow").inner_text(), "home identifies the pie menu as an AMQ adaptation, not a native osu!stable element")
    check("不是 osu!stable 原生元件" in page.locator("#page-home .home-footer-note").inner_text(), "home explains the custom navigation semantics")
    check(page.locator("#home-pie-actions").is_hidden(), "home actions begin collapsed")
    page.screenshot(path=str(ARTIFACTS / "home-desktop.png"), full_page=True)
    page.locator("#home-pie-core").click()
    check(page.locator("#home-pie-actions").is_visible() and page.locator(".home-pie-action").count() == 5, "pie click reveals five primary destinations including the local profile")
    page.keyboard.press("Escape")
    check(page.locator("#home-pie-actions").is_hidden() and page.locator("#home-pie-core").get_attribute("aria-expanded") == "false", "Escape collapses the home menu and synchronizes aria-expanded")
    check(page.evaluate("document.activeElement.id") == "home-pie-core", "Escape returns keyboard focus to the home menu trigger")
    page.locator("#home-pie-core").click()
    home_action_overlaps = page.evaluate("""() => {
      const rects = [...document.querySelectorAll('.home-pie-action')].map(node => { const r = node.getBoundingClientRect(); return { left:r.left, top:r.top, right:r.right, bottom:r.bottom }; });
      let overlaps = 0;
      for (let i=0;i<rects.length;i++) for (let j=i+1;j<rects.length;j++) if (rects[i].left < rects[j].right && rects[i].right > rects[j].left && rects[i].top < rects[j].bottom && rects[i].bottom > rects[j].top) overlaps++;
      return overlaps;
    }""")
    check(home_action_overlaps == 0, "five home destinations do not overlap on desktop")
    page.locator(".home-pie-action--catalog").click()
    check(page.locator("#page-catalog").is_visible(), "catalog route opens")
    check(page.locator("#home-pie-actions").is_hidden() and page.locator("#home-pie-core").get_attribute("aria-expanded") == "false", "leaving home collapses transient menu state instead of preserving a stale open menu")
    check(page.locator("#app-shell-nav [data-nav-page=catalog]").get_attribute("aria-current") == "page", "active navigation exposes aria-current page")
    nav_touch_targets = page.locator("#app-shell-nav button").evaluate_all("nodes => nodes.map(e => getComputedStyle(e).minHeight)")
    check(len(nav_touch_targets) > 1 and all(float(value.replace('px','')) >= 44 for value in nav_touch_targets), "desktop page navigation and back-to-home controls meet the 44px minimum target")
    check(page.locator("#catalog-browser").count() == 1 and page.locator("#free-player-dock").count() == 1, "real catalog and player modules remain mounted")
    check(page.locator("#catalog-browser .catalog-workspace[data-catalog-layout='osu-stable-inspired']").count() == 1, "catalog mounts a real filter/list/detail workspace")
    catalog_input_palette = page.locator("#catalog-query").evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,border:s.borderTopColor,radius:s.borderRadius,focus:!!e.matches(':focus-visible')}; }")
    check(catalog_input_palette["background"] == "rgb(17, 18, 25)" and catalog_input_palette["color"] == "rgb(243, 244, 248)" and catalog_input_palette["radius"] == "3px", "Catalog search input uses shell-owned dark palette without global important rule")
    player_input_palette = page.locator("#free-player-search").evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,radius:s.borderRadius}; }")
    check(player_input_palette["background"] == "rgb(17, 18, 25)" and player_input_palette["color"] == "rgb(243, 244, 248)" and player_input_palette["radius"] == "3px", "Free Player Dock retains dark input styling after global palette is scoped")
    check(page.locator(".catalog-workspace > .catalog-sidebar #catalog-query").count() == 1 and page.locator(".catalog-workspace > .catalog-main-list #catalog-rows").count() == 1 and page.locator(".catalog-workspace > .catalog-detail-column #catalog-selection-details").count() == 1, "existing query, song list and detail DOM are reparented into assigned regions")
    check(page.locator(".catalog-workspace > .catalog-sidebar #catalog-mode-selector").count() == 1, "AMQ/EMQ/MIX mode selector is part of the song-select workspace, not a separate full-width panel")
    check(page.locator(".catalog-management-group").count() == 4, "secondary presets, tags, batch tools and personal library are grouped into disclosures")
    artwork_fallback_styles = page.evaluate("""() => {
      const host = document.createElement('span'); host.className = 'catalog-artwork'; host.dataset.artworkStatus = 'missing'; host.dataset.artworkSource = 'AMQ'; host.dataset.artworkSourceLabel = 'ANIME';
      const fallback = document.createElement('span'); fallback.className = 'catalog-artwork-fallback'; fallback.dataset.artworkSourceLabel = 'ANIME';
      const mark = document.createElement('span'); mark.className = 'catalog-artwork-mark'; mark.textContent = 'W';
      const label = document.createElement('span'); label.className = 'catalog-artwork-title-label'; label.textContent = 'Work Z'; fallback.append(mark,label); host.append(fallback); document.querySelector('#catalog-rows').append(host);
      const result = {source:getComputedStyle(host).getPropertyValue('--unused'), badge:getComputedStyle(fallback,'::before').content, markColor:getComputedStyle(mark).color, layout:getComputedStyle(fallback).flexDirection, width:host.getBoundingClientRect().width, height:host.getBoundingClientRect().height}; host.remove(); return result;
    }""")
    check(artwork_fallback_styles["badge"] == '"ANIME"' and artwork_fallback_styles["markColor"] == "rgb(244, 166, 196)", "Catalog missing-cover fallback shows source identity and title-derived artwork mark")
    check(artwork_fallback_styles["layout"] == "column", "Catalog cover fallback separates title mark and work label in the artwork slot")
    catalog_state_styles = page.evaluate("""() => {
      const root = document.querySelector('#catalog-browser');
      const status = document.querySelector('#catalog-status');
      const empty = document.querySelector('#catalog-empty');
      const original = root.getAttribute('data-catalog-state');
      const originalTransition = status.style.transition; status.style.transition = 'none';
      root.setAttribute('data-catalog-state', 'loading'); const loading = getComputedStyle(status).backgroundColor;
      root.setAttribute('data-catalog-state', 'failed'); const failed = getComputedStyle(status).backgroundColor;
      root.setAttribute('data-catalog-state', 'empty'); const emptyState = getComputedStyle(empty).backgroundColor;
      root.setAttribute('data-catalog-state', 'filtered-empty'); const filteredEmpty = getComputedStyle(empty).backgroundColor;
      root.setAttribute('data-catalog-state', 'loaded'); const loaded = getComputedStyle(status).color;
      if (original === null) root.removeAttribute('data-catalog-state'); else root.setAttribute('data-catalog-state', original);
      status.style.transition = originalTransition;
      return { loading, failed, emptyState, filteredEmpty, loaded };
    }""")
    check(catalog_state_styles["loading"] != catalog_state_styles["failed"] and catalog_state_styles["failed"] != catalog_state_styles["loaded"], "catalog loading, failed and loaded status pills have distinct visual treatments")
    check(catalog_state_styles["emptyState"] != catalog_state_styles["filteredEmpty"], "source-empty and filter-empty states have distinct visual treatments")
    catalog_error_styles = page.evaluate("""() => {
      const root = document.querySelector('#catalog-browser');
      const error = document.querySelector('#catalog-error');
      const reload = document.querySelector('#catalog-reload');
      const originalState = root.getAttribute('data-catalog-state');
      const originalHidden = error.hidden;
      const originalText = error.textContent;
      root.setAttribute('data-catalog-state', 'failed'); error.hidden = false; error.textContent = 'DATA_SOURCE_TIMEOUT：曲庫來源逾時；原因：來源回應超時。此錯誤可重試。';
      const result = { display: getComputedStyle(error).display, backgroundImage: getComputedStyle(error).backgroundImage, color: getComputedStyle(error).color, wrap: getComputedStyle(error).overflowWrap, buttonHeight: reload.getBoundingClientRect().height };
      root.setAttribute('data-catalog-state', originalState); error.hidden = originalHidden; error.textContent = originalText;
      return result;
    }""")
    check(catalog_error_styles["display"] == "block" and catalog_error_styles["wrap"] == "anywhere", "Catalog error details are visible and wrap safely instead of overflowing")
    check("linear-gradient" in catalog_error_styles["backgroundImage"] and catalog_error_styles["buttonHeight"] >= 40, "Catalog failure banner and retry control have clear visual/touch affordances")
    check(len(page.locator(".catalog-workspace").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean)")) == 3, "desktop song select uses three actual layout columns")
    catalog_touch_height = page.evaluate("""() => {
      const body = document.querySelector('#catalog-rows');
      const row = document.createElement('tr');
      for (let i = 0; i < 5; i++) { const cell = document.createElement('td'); cell.textContent = i === 0 ? 'Touch target fixture' : 'Test'; row.appendChild(cell); }
      body.appendChild(row); const height = row.getBoundingClientRect().height; row.remove(); return height;
    }""")
    check(catalog_touch_height >= 44, "Catalog song rows meet the 44px touch target while allowing taller wrapped rows")
    catalog_checkbox_style = page.evaluate("""() => { const row=document.createElement('tr'), cell=document.createElement('td'), input=document.createElement('input'); input.type='checkbox'; input.className='catalog-row-select'; cell.append(input); row.append(cell); document.querySelector('#catalog-rows').append(row); const s=getComputedStyle(input); const result={width:s.width,minHeight:s.minHeight,padding:s.padding,accent:s.accentColor}; row.remove(); return result; }""")
    check(catalog_checkbox_style["width"] == "15px" and catalog_checkbox_style["minHeight"] == "15px" and catalog_checkbox_style["padding"] == "0px", "Catalog row checkbox keeps its compact size without important overrides")
    page.screenshot(path=str(ARTIFACTS / "catalog-desktop-full.png"), full_page=True)
    page.screenshot(path=str(ARTIFACTS / "catalog-desktop.png"), full_page=False)
    page.screenshot(path=str(ARTIFACTS / "catalog-viewport.png"), full_page=False)
    check(page.locator("#page-catalog #catalog-browser").evaluate("e => e.nextElementSibling && e.nextElementSibling.id") == "free-player-dock", "catalog content precedes the optional player panel")
    check(page.locator("#free-player-body").is_hidden() and page.locator("#free-player-collapse").get_attribute("aria-expanded") == "false", "sticky player starts as a compact dock instead of covering song selection")
    player_progress_style = page.locator("#free-player-progress").evaluate("e => { const s=getComputedStyle(e); return {radius:s.borderRadius,background:s.backgroundColor,accent:s.accentColor}; }")
    check(player_progress_style["radius"] == "2px" and player_progress_style["background"] == "rgb(40, 42, 54)", "Free Player range track retains its explicit dark surface without important radius")
    check(page.locator("#free-player-dock").evaluate("e => e.getBoundingClientRect().height") < 100, "collapsed desktop player is a compact bottom bar")
    page.locator("#free-player-collapse").click()
    check(page.locator("#free-player-body").is_visible(), "player controls remain available when the dock is expanded")
    page.locator("#free-player-collapse").click()
    page.locator('[data-go-page="quiz"]').first.click()
    check(page.locator("#page-quiz").is_visible() and page.locator("#quiz-panel").count() == 1 and page.locator("#multiplayer-panel").count() == 1, "single and multiplayer features share the quiz area")
    check(page.locator("#app-shell-nav [data-nav-page=catalog]").get_attribute("aria-current") is None, "inactive navigation removes aria-current instead of exposing false as a page value")
    check(page.locator("#page-quiz > .app-page-intro").count() == 1 and page.locator("#page-quiz > #quiz-panel").count() == 1 and page.locator("#quiz-panel").evaluate("e => e.compareDocumentPosition(document.querySelector('#multiplayer-panel')) & Node.DOCUMENT_POSITION_FOLLOWING") != 0, "quiz page has a real page heading and puts single-player before multiplayer")
    check(page.locator("#multiplayer-panel").evaluate("e => getComputedStyle(e).backgroundImage.includes('linear-gradient')"), "multiplayer panel keeps a readable overlay above optional skin art")
    multiplayer_card_style = page.locator("#multiplayer-room-details").evaluate("e => ({padding:getComputedStyle(e).padding,borderWidth:getComputedStyle(e).borderTopWidth,radius:getComputedStyle(e).borderRadius,background:getComputedStyle(e).backgroundImage})")
    check(multiplayer_card_style["padding"] == "16px" and multiplayer_card_style["borderWidth"] == "1px" and multiplayer_card_style["radius"] == "4px", "multiplayer room card has explicit shell-owned layout after removing the legacy global card rule")
    check("linear-gradient" in multiplayer_card_style["background"], "multiplayer room card keeps the intended dark shell surface without !important override")
    check(page.locator("#multiplayer-panel button").evaluate_all("nodes => nodes.filter(node => node.disabled).every(node => getComputedStyle(node).opacity < 1)"), "disabled multiplayer controls have explicit visual feedback")
    multiplayer_input_palette = page.locator("#multiplayer-capacity").evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,border:s.borderTopColor,radius:s.borderRadius}; }")
    multiplayer_answer_palette = page.locator("#multiplayer-answer").evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,border:s.borderTopColor,radius:s.borderRadius}; }")
    check(multiplayer_input_palette["background"] == "rgb(17, 18, 25)" and multiplayer_input_palette["color"] == "rgb(243, 244, 248)" and multiplayer_input_palette["radius"] == "3px", "Multiplayer numeric input uses shell-owned dark palette")
    check(multiplayer_answer_palette["background"] == "rgb(17, 18, 25)" and multiplayer_answer_palette["color"] == "rgb(243, 244, 248)" and multiplayer_answer_palette["radius"] == "3px", "Multiplayer answer input uses the shell-owned dark control palette")
    page.screenshot(path=str(ARTIFACTS / "quiz-desktop.png"), full_page=True)
    check(page.locator("#quiz-panel > .quiz-setup-section #quiz-setup-heading").inner_text() == "回合設定", "quiz configuration has a dedicated semantic setup section")
    check(page.locator("#quiz-panel > .quiz-round-section #quiz-round-heading").inner_text() == "本輪狀態", "live round controls and status are grouped in their own section")
    check(page.locator("#quiz-panel > .quiz-setup-section #quiz-count").count() == 1 and page.locator("#quiz-panel > .quiz-setup-section .quiz-filter-panel").count() == 1, "existing quiz setting IDs and filter panel remain mounted without duplicating state owners")
    check(page.locator("#quiz-panel .quiz-filter-panel > summary strong").inner_text() == "出題篩選", "question-pool filters have a clear expandable summary")
    check(page.locator("#quiz-panel .quiz-history #quiz-history-heading").inner_text() == "答題紀錄", "history remains explicitly labeled as real local answer history")
    quiz_legacy_surface_styles = page.evaluate("""() => Object.fromEntries(['#quiz-panel .quiz-history','#quiz-panel .quiz-srs','#statistics-dashboard .statistics-grid > div'].map(selector => { const node=document.querySelector(selector); const style=getComputedStyle(node); return [selector,{background:style.backgroundColor,image:style.backgroundImage,radius:style.borderRadius}]; }))""")
    check(quiz_legacy_surface_styles["#quiz-panel .quiz-history"]["background"] != "rgb(255, 255, 255)" and quiz_legacy_surface_styles["#quiz-panel .quiz-history"]["radius"] == "6px", "quiz history has shell-owned dark styling without important override")
    check(quiz_legacy_surface_styles["#quiz-panel .quiz-srs"]["background"] != "rgb(255, 255, 255)" and quiz_legacy_surface_styles["#quiz-panel .quiz-srs"]["radius"] == "6px", "quiz SRS has shell-owned dark styling without important override")
    check("linear-gradient" in quiz_legacy_surface_styles["#statistics-dashboard .statistics-grid > div"]["image"], "learning metrics keep their dark shell surface after removing the old important override")
    check(page.locator("#page-quiz #quiz-round-results").count() == 0 and page.locator("#quiz-round-results").is_hidden(), "round results are moved out of the live quiz panel into a dedicated results route")
    check(page.locator("#quiz-round-results #quiz-round-results-list").count() == 1 and "已保存的計分目標" in page.locator("#quiz-round-results-note").inner_text(), "round results explicitly limit details to persisted scored targets")
    page.locator('[data-nav-page="results"]').first.click()
    check(page.locator("#page-results").is_visible() and page.locator("#results-workspace").count() == 1, "results has an independent navigable page and workspace")
    check(page.locator("#results-empty").is_visible() and page.locator("#quiz-round-results").is_hidden(), "results page has a real empty state before a completed round")
    page.screenshot(path=str(ARTIFACTS / "results-desktop.png"), full_page=True)
    long_result_layout = page.evaluate("""() => {
      const section = document.querySelector('#quiz-round-results'), empty = document.querySelector('#results-empty'), list = document.querySelector('#quiz-round-results-list');
      const oldHidden = section.hidden, oldEmptyHidden = empty.hidden, oldChildren = [...list.childNodes];
      const item = document.createElement('li'); item.className = 'quiz-round-result-item is-wrong'; const title = document.createElement('strong'); title.textContent = '超長作品標題 '.repeat(28); const meta = document.createElement('span'); meta.textContent = 'AMQ · 作品 · 答錯 · 尚未保存 · '.repeat(10); item.append(title,meta); list.replaceChildren(item); section.hidden = false; empty.hidden = true;
      const result = { pageWidth:document.documentElement.scrollWidth, viewport:window.innerWidth, itemWidth:item.getBoundingClientRect().width, titleHeight:title.getBoundingClientRect().height, metaHeight:meta.getBoundingClientRect().height, listScrollWidth:list.scrollWidth, listClientWidth:list.clientWidth };
      list.replaceChildren(...oldChildren); section.hidden = oldHidden; empty.hidden = oldEmptyHidden; return result;
    }""")
    check(long_result_layout["titleHeight"] > 0 and long_result_layout["metaHeight"] > 0, "long result titles and unsaved metadata wrap instead of disappearing")
    check(long_result_layout["pageWidth"] <= long_result_layout["viewport"] + 1 and long_result_layout["listScrollWidth"] <= long_result_layout["listClientWidth"] + 1, "long result metadata does not overflow its result list")
    check(page.locator("#results-return-to-quiz").is_visible() and page.locator("#results-return-to-quiz").get_attribute("data-go-page") == "quiz", "results empty state offers a direct, honest next action into quiz setup")
    check(page.locator("#results-continue-quiz").count() == 1 and page.locator("#results-continue-quiz").get_attribute("data-go-page") == "quiz", "completed result state has a matching route back to quiz setup")
    results_action_height = page.locator("#results-return-to-quiz").evaluate("e => getComputedStyle(e).minHeight")
    check(float(results_action_height.replace("px", "")) >= 44, "results primary action meets touch target minimum")
    result_disabled_style = page.locator("#results-workspace button").evaluate_all("nodes => nodes.map(node => ({disabled:node.disabled, opacity:getComputedStyle(node).opacity}))")
    check(all((not node["disabled"]) or float(node["opacity"]) < 1 for node in result_disabled_style), "disabled result actions, when present, have explicit unavailable styling")
    check(page.locator("#results-workspace .results-empty").evaluate("e => getComputedStyle(e).display === 'grid' && parseFloat(getComputedStyle(e).minHeight) >= 220"), "results empty state remains visually distinct and keyboard-safe")
    page.locator("#results-return-to-quiz").click()
    check(page.locator("#page-quiz").is_visible(), "results primary action navigates to quiz setup")
    check(page.evaluate("document.activeElement && document.activeElement.id") == "quiz-setup-heading", "results action transfers keyboard focus into the actual quiz setup section")
    check(page.locator("#quiz-error").is_hidden() or page.locator("#quiz-error").inner_text().strip() != "", "quiz error UI hides empty alerts and never renders a blank error banner")
    check(page.locator("#quiz-audio-status").get_attribute("role") == "status" and page.locator("#quiz-audio-status").get_attribute("aria-live") == "polite", "quiz audio status is announced as a live status")
    quiz_audio_state_styles = page.evaluate("""() => {
      const node = document.querySelector('#quiz-audio-status'); const old = node.getAttribute('data-audio-state');
      const states = {}; for (const state of ['idle','loading','ready','playing','paused','blocked','failed']) { node.setAttribute('data-audio-state', state); states[state] = {color:getComputedStyle(node).color, background:getComputedStyle(node).backgroundColor, border:getComputedStyle(node).borderColor}; }
      node.setAttribute('data-audio-state', old); return states;
    }""")
    check(quiz_audio_state_styles["playing"]["color"] != quiz_audio_state_styles["failed"]["color"] and quiz_audio_state_styles["blocked"]["border"] != quiz_audio_state_styles["failed"]["border"], "quiz audio ready/playing, blocked and failed states have distinct visual feedback")
    multiplayer_action_height = page.locator("#multiplayer-panel .quiz-actions button").first.evaluate("e => getComputedStyle(e).minHeight")
    check(float(multiplayer_action_height.replace("px", "")) >= 44, "multiplayer room actions meet touch target minimum")
    multiplayer_state_styles = page.evaluate("""() => {
      const round = document.querySelector('#multiplayer-round-status'), audio = document.querySelector('#multiplayer-audio-status');
      const oldRound = round.getAttribute('data-round-state'), oldAudio = audio.getAttribute('data-audio-state'); const out = {};
      for (const state of ['active','submitted','expired']) { round.setAttribute('data-round-state',state); out['round-'+state] = {color:getComputedStyle(round).color,border:getComputedStyle(round).borderLeftColor}; }
      for (const state of ['waiting','loading','playing','failed']) { audio.setAttribute('data-audio-state',state); out['audio-'+state] = {color:getComputedStyle(audio).color,border:getComputedStyle(audio).borderLeftColor}; }
      round.setAttribute('data-round-state',oldRound); audio.setAttribute('data-audio-state',oldAudio); return out;
    }""")
    check(multiplayer_state_styles["round-active"]["color"] != multiplayer_state_styles["round-expired"]["color"] and multiplayer_state_styles["round-submitted"]["border"] != multiplayer_state_styles["round-active"]["border"], "multiplayer active/submitted/expired states have distinct visual feedback")
    check(multiplayer_state_styles["audio-playing"]["color"] != multiplayer_state_styles["audio-failed"]["color"] and multiplayer_state_styles["audio-waiting"]["border"] != multiplayer_state_styles["audio-failed"]["border"], "multiplayer waiting/playing/failed audio states have distinct visual feedback")
    check(page.locator("#quiz-panel .quiz-setup-section > .quiz-settings").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 3, "quiz setup controls use three balanced desktop columns")
    check(page.locator("#quiz-panel .quiz-question-card").evaluate("e => parseFloat(getComputedStyle(e).minHeight) >= 210"), "quiz prompt is rendered as a dedicated answer-stage surface")
    check(len(page.locator("#quiz-panel .quiz-summary-row > span").all()) == 4, "quiz round status uses four distinct information tiles")
    check(page.locator("#quiz-panel .quiz-answer-form").evaluate("e => getComputedStyle(e).display") == "grid", "answer form uses a responsive input-and-submit layout")
    quiz_answer_palette = page.locator("#quiz-answer").evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,border:s.borderTopColor,radius:s.borderRadius,height:s.getPropertyValue('min-height')}; }")
    check(quiz_answer_palette["background"] == "rgb(17, 18, 25)" and quiz_answer_palette["color"] == "rgb(243, 244, 248)" and quiz_answer_palette["radius"] == "4px", "Quiz answer input keeps its dedicated shell surface without important overrides")
    check(page.locator("#quiz-all-answer-fields input").evaluate_all("nodes => nodes.every(e => { const s=getComputedStyle(e); return s.backgroundColor === 'rgb(17, 18, 25)' && s.color === 'rgb(243, 244, 248)'; })"), "all three answer fields retain the shell palette when the all-answer mode is used")
    page.locator('[data-go-page="learning"]').first.click()
    check(page.locator("#page-learning").is_visible() and page.locator("#statistics-dashboard").count() == 1, "learning center owns the existing statistics panel")
    check(page.locator("#page-learning > .app-page-intro").count() == 1, "learning center has a dedicated visual heading")
    page.screenshot(path=str(ARTIFACTS / "learning-desktop.png"), full_page=True)
    check(len(page.locator("#statistics-dashboard .statistics-grid > div").all()) == 7, "learning center keeps seven real metrics without synthesizing values")
    check(page.locator("#statistics-dashboard .statistics-grid").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 4, "learning metrics form a four-column desktop summary grid")
    page.locator('[data-go-page="profile"]').first.click()
    check(page.locator("#page-profile").is_visible() and page.locator("#profile-panel").count() == 1, "local profile has a dedicated navigation page and panel")
    check(page.locator("#page-profile > .app-page-intro").count() == 1 and page.locator("#profile-panel .profile-metrics > div").count() == 6, "profile page has a heading and six real-data metric slots")
    check("不會把本機答題紀錄假裝成全球排名" in page.locator("#profile-panel .profile-rank-note").inner_text(), "profile explicitly refuses to fabricate global ranking or PP")
    page.screenshot(path=str(ARTIFACTS / "profile-desktop.png"), full_page=True)
    page.locator('[data-go-page="settings"]').first.click()
    check(page.locator("#page-settings").is_visible(), "settings route opens")
    check(page.locator("#page-settings > .app-page-intro").count() == 1, "settings has a dedicated visual heading")
    page.screenshot(path=str(ARTIFACTS / "settings-desktop.png"), full_page=True)
    check(page.locator("#page-settings .workspace-preferences-grid").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 2, "settings workspace controls use two balanced desktop columns")
    settings_checkbox = page.locator("#page-settings .workspace-visibility-grid input[type=checkbox]").first.evaluate("e => { const s=getComputedStyle(e); return {width:s.width,height:s.height,minHeight:s.minHeight,border:s.borderTopWidth,background:s.backgroundColor,appearance:s.appearance}; }")
    check(settings_checkbox["width"] == "17px" and settings_checkbox["height"] == "17px" and settings_checkbox["minHeight"] == "17px" and settings_checkbox["border"] == "1px" and settings_checkbox["appearance"] == "none", "Settings OSK toggles retain the intended custom checkbox geometry without important declarations")
    settings_file_palette = page.locator("#backup-file").evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,maxWidth:s.maxWidth}; }")
    check(settings_file_palette["background"] == "rgb(23, 25, 32)" and settings_file_palette["color"] == "rgb(185, 189, 203)", "Settings file input remains dark after dropping the old important background")
    settings_dropdown_image = page.locator("#page-settings select").first.evaluate("e => getComputedStyle(e).backgroundImage")
    check("linear-gradient" in settings_dropdown_image, "Settings dropdown preserves its skin-aware image without important specificity hacks")
    workspace_status = page.evaluate("""() => { const n=document.querySelector('#workspace-preferences-status'); const old=n.getAttribute('data-state'); n.setAttribute('data-state','error'); const s=getComputedStyle(n); const result={background:s.backgroundImage,color:s.color,border:s.borderLeftColor}; if(old===null)n.removeAttribute('data-state');else n.setAttribute('data-state',old); return result; }""")
    check("linear-gradient" in workspace_status["background"] and workspace_status["color"] == "rgb(229, 217, 182)" and workspace_status["border"] == "rgb(197, 138, 42)", "Settings error state retains warning/error palette through a scoped selector")
    settings_select_palette = page.locator("#page-settings select").first.evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,border:s.borderTopColor,radius:s.borderRadius}; }")
    settings_text_palette = page.locator("#page-settings input:not([type=checkbox]):not([type=file])").first.evaluate("e => { const s=getComputedStyle(e); return {background:s.backgroundColor,color:s.color,border:s.borderTopColor,radius:s.borderRadius}; }")
    check(settings_select_palette["color"] == "rgb(243, 244, 248)" and settings_select_palette["radius"] == "3px", "Settings dropdown keeps explicit dark shell styling and radius")
    check(settings_text_palette["background"] == "rgb(17, 18, 25)" and settings_text_palette["color"] == "rgb(243, 244, 248)", "Settings text/file-adjacent controls retain dark palette after legacy global removal")
    check(page.locator("#page-settings .settings-quick-nav [data-settings-jump]").count() == 5, "settings page offers five direct links to real settings sections")
    page.locator("#page-settings [data-settings-jump='skin-import-panel']").click()
    check(page.evaluate("document.activeElement.id") == "skin-import-heading", "settings quick navigation moves keyboard focus to the chosen section heading")
    check(page.locator("#page-settings .skin-import-controls").count() == 1, "skin import and mapping actions remain in the settings work area")
    check(page.locator("#skin-import-status").evaluate("e => getComputedStyle(e).backgroundColor") != "rgb(255, 255, 255)", "skin status no longer inherits a legacy white notice surface")
    check(page.locator("#skin-import-panel").count() == 1 and page.locator("#backup-restore-panel").count() == 1 and page.locator("#database-update-panel").count() == 1, "OSK, backup, and database update stay accessible under settings")
    check(page.locator("#page-settings").evaluate("e => getComputedStyle(e).color") != "rgb(32, 43, 61)", "dark shell overrides legacy light palette")
    check("return { schemaVersion: 4, enabled: enabled === true" in (SRC / "ui/skin-import-panel.js").read_text(encoding="utf-8"), "portable theme transfer keeps backward-compatible bundle schema 1 while IndexedDB records use schema 4")
    skin_result = page.evaluate("""async () => {
      const adapter = window.AMQSkins.themeAdapter.createThemeAdapter();
      const bytes = Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR4nGP4kD37PwAHOwL2lXHKcAAAAABJRU5ErkJggg=='), c => c.charCodeAt(0));
      const blob = new Blob([bytes], { type: 'image/png' });
      const result = await adapter.apply({ enabled: true, mappings: { background: null, selectionFrame: null, characterOverlay: null }, roleMappings: { 'app.home.background': 'skin.png', 'catalog.item.selected': 'skin.png', 'results.panel': 'skin.png', 'catalog.song-artwork': 'skin.png' }, assets: [{ path: 'skin.png', extension: 'png', blob }], accentColors: [] });
      const homeToken = document.querySelector('#page-home').style.getPropertyValue('--amq-skin-role-app-home-background');
      const catalogToken = document.querySelector('#catalog-browser').style.getPropertyValue('--amq-skin-role-catalog-item-selected');
      const resultsToken = document.querySelector('#quiz-round-results').style.getPropertyValue('--amq-skin-role-results-panel');
      adapter.reset(); adapter.dispose();
      return { roles: result.roles, warnings: result.warnings, homeToken, catalogToken, resultsToken };
    }""")
    check("app.home.background" in skin_result["roles"] and "catalog.item.selected" in skin_result["roles"] and "results.panel" in skin_result["roles"] and skin_result["resultsToken"], "real UI accepts home, selected-row and round-results panel skin assets")
    check("catalog.song-artwork:unsupported-role" in skin_result["warnings"], "unsupported skin role is reported instead of silently applied")
    role_support = page.evaluate("window.AMQSkins.themeAdapter.getRoleSupport()")
    check(role_support["catalog.song-detail.panel"]["supported"] and role_support["player.control.play"]["supported"] and role_support["results.panel"]["supported"], "catalog detail, player control and round-results roles expose real runtime targets")
    check(role_support["multiplayer.ready-state"]["supported"] and role_support["multiplayer.ready-state"]["selector"] == "#multiplayer-players", "multiplayer readiness role uses a stable room-member owner while its CSS token is consumed only by readiness badges")
    ready_badge_styles = page.evaluate("""() => {
      const list = document.querySelector('#multiplayer-players');
      const row = document.createElement('li'); row.className = 'multiplayer-player-item';
      const badge = document.createElement('span'); badge.className = 'multiplayer-player-ready-state';
      badge.dataset.ready = 'true'; badge.textContent = '已準備'; row.appendChild(badge); list.appendChild(row);
      const ready = { display: getComputedStyle(badge).display, color: getComputedStyle(badge).color };
      badge.dataset.ready = 'false';
      const notReady = { color: getComputedStyle(badge).color };
      row.remove(); return { ready, notReady };
    }""")
    check(ready_badge_styles["ready"]["display"] in ("flex", "inline-flex") and ready_badge_styles["ready"]["color"] != ready_badge_styles["notReady"]["color"], "multiplayer ready and not-ready badges have distinct, readable visual states")
    runtime_roles = page.evaluate("window.AMQSkins.themeAdapter.runtimeRoles")
    check(len(runtime_roles) == 35 and all(role_support[role]["supported"] for role in runtime_roles), "all 35 declared runtime roles resolve to concrete DOM targets")
    role_css = (SRC / "styles/ui-shell.css").read_text(encoding="utf-8")
    role_tokens = page.evaluate("""() => {
      const source = document.querySelector('style')?.textContent || '';
      return window.AMQSkins.themeAdapter.runtimeRoles.map(role => role);
    }""")
    adapter_source = (SRC / "skins/theme-adapter.js").read_text(encoding="utf-8")
    declared_tokens = re.findall(r'"([^"]+)": \{ selector: .*?, token: "([^"]+)" \}', adapter_source)
    check(len(declared_tokens) == 35 and all(f"var({token}" in role_css for _, token in declared_tokens), "all 35 runtime skin roles have a concrete CSS token consumer")
    check(role_support["learning.history.item"]["supported"] and role_support["learning.history.item"]["selector"] == "#learning-history-list", "learning history skin role targets the real history list container")
    check(role_support["learning.review.item"]["supported"] and role_support["learning.review.item"]["selector"] == "#learning-review-list", "learning review skin role targets the real due-review list container")
    page.locator("[data-go-page='catalog']").first.click()
    page.set_viewport_size({"width": 390, "height": 844})
    page.wait_for_timeout(100)
    mobile_nav_targets = page.locator("#app-shell-nav button").evaluate_all("nodes => nodes.filter(e => e.getBoundingClientRect().width > 0).map(e => getComputedStyle(e).minHeight)")
    check(len(mobile_nav_targets) > 1 and all(float(value.replace('px','')) >= 44 for value in mobile_nav_targets), "mobile page navigation and back-to-home controls meet the 44px minimum target")
    mobile_columns = page.locator(".catalog-workspace").evaluate("e => getComputedStyle(e).gridTemplateColumns")
    check(len(mobile_columns.split()) == 1 and mobile_columns.strip().endswith("px"), "catalog collapses to a single column on mobile")
    check(page.locator("#free-player-dock").evaluate("e => e.getBoundingClientRect().height") < 100, "collapsed mobile player remains compact")
    check(page.locator("#free-player-dock").evaluate("e => getComputedStyle(e).position") == "static", "mobile player stays in document flow and does not cover filters")
    check(page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), "catalog has no page-level horizontal overflow at 390px")
    mobile_artwork_fallback = page.evaluate("""() => {
      const host = document.createElement('span'); host.className = 'catalog-artwork'; host.dataset.artworkStatus = 'loading'; host.dataset.artworkSource = 'EMQ'; host.dataset.artworkSourceLabel = 'GAME';
      const fallback = document.createElement('span'); fallback.className = 'catalog-artwork-fallback'; fallback.dataset.artworkSourceLabel = 'GAME';
      const mark = document.createElement('span'); mark.className = 'catalog-artwork-mark'; mark.textContent = 'G'; const label = document.createElement('span'); label.className = 'catalog-artwork-title-label'; label.textContent = 'Game B'; fallback.append(mark,label); host.append(fallback); document.querySelector('#catalog-rows').append(host);
      const result = {width:host.getBoundingClientRect().width,height:host.getBoundingClientRect().height,animation:getComputedStyle(mark).animationName,badge:getComputedStyle(fallback,'::before').content}; host.remove(); return result;
    }""")
    check(mobile_artwork_fallback["width"] > 0 and mobile_artwork_fallback["height"] > 0 and mobile_artwork_fallback["badge"] == '"GAME"', "mobile EMQ artwork fallback keeps a visible game-specific visual slot")
    page.emulate_media(reduced_motion="reduce")
    reduced_motion_animation = page.evaluate("""() => { const host=document.createElement('span'); host.className='catalog-artwork'; host.dataset.artworkStatus='loading'; const mark=document.createElement('span'); mark.className='catalog-artwork-mark'; host.append(mark); document.body.append(host); const name=getComputedStyle(mark).animationName; host.remove(); return name; }""")
    check(reduced_motion_animation == "none", "reduced-motion preference disables artwork fallback animation")
    page.emulate_media(reduced_motion="no-preference")
    mobile_error_state = page.evaluate("""() => {
      const root = document.querySelector('#catalog-browser'), error = document.querySelector('#catalog-error'), reload = document.querySelector('#catalog-reload');
      const oldState = root.getAttribute('data-catalog-state'), oldHidden = error.hidden, oldText = error.textContent;
      root.setAttribute('data-catalog-state', 'failed'); error.hidden = false; error.textContent = 'DATA_SOURCE_TIMEOUT：曲庫來源逾時；原因：來源回應超時。此錯誤可重試。';
      const result = { pageWidth: document.documentElement.scrollWidth, viewport: window.innerWidth, errorWidth: error.getBoundingClientRect().width, reloadWidth: reload.getBoundingClientRect().width };
      root.setAttribute('data-catalog-state', oldState); error.hidden = oldHidden; error.textContent = oldText; return result;
    }""")
    check(mobile_error_state["pageWidth"] <= mobile_error_state["viewport"] + 1, "mobile Catalog error detail does not introduce horizontal page overflow")
    check(mobile_error_state["errorWidth"] > 0 and mobile_error_state["reloadWidth"] > 0, "mobile Catalog error detail and retry action remain visible")
    page.screenshot(path=str(ARTIFACTS / "catalog-mobile.png"), full_page=False)
    page.evaluate("window.scrollTo(0, 520)")
    check(page.evaluate("window.scrollY > 0"), "mobile route transition fixture begins from a scrolled Catalog position")
    page.locator("[data-go-page='quiz']").first.click()
    route_scroll = page.evaluate("({y:window.scrollY, headingTop:document.querySelector('#page-quiz .app-page-intro').getBoundingClientRect().top})")
    check(route_scroll["y"] == 0 and route_scroll["headingTop"] >= 0, "cross-page navigation resets scroll so the destination heading is visible")
    check(page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), "quiz has no page-level horizontal overflow at 390px")
    check(page.locator("#quiz-panel > .quiz-setup-section > .quiz-settings").evaluate("e => getComputedStyle(e).gridTemplateColumns.split().filter(Boolean).length") == 1, "quiz setup fields reflow to a single column on narrow mobile screens")
    mobile_quiz_action_height = page.locator("#quiz-panel .quiz-actions button").first.evaluate("e => getComputedStyle(e).minHeight")
    mobile_suggestion_height = page.locator("#quiz-panel .quiz-suggestion-option").evaluate("e => getComputedStyle(e).minHeight") if page.locator("#quiz-panel .quiz-suggestion-option").count() else "44px"
    check(float(mobile_quiz_action_height.replace("px", "")) >= 46 and float(mobile_suggestion_height.replace("px", "")) >= 44, "mobile quiz actions and answer suggestions meet touch target minimums")
    page.screenshot(path=str(ARTIFACTS / "quiz-mobile.png"), full_page=False)
    page.locator("[data-go-page='learning']").first.click()
    check(page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), "learning center has no page-level horizontal overflow at 390px")
    check(page.locator("#statistics-dashboard .statistics-grid").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 1, "learning metrics reflow to one column on mobile")
    check(page.locator("#learning-history-list").count() == 1 and page.locator("#learning-review-list").count() == 1, "learning center includes real recent-history and due-review list containers")
    check(page.locator("#learning-history-empty").is_visible() and "讀取失敗" in page.locator("#learning-history-empty").inner_text(), "opaque-origin history failure is shown honestly rather than as an empty-success state")
    check(page.locator("#learning-review-empty").is_visible() and "讀取失敗" in page.locator("#learning-review-empty").inner_text(), "opaque-origin SRS failure is shown honestly rather than as zero due cards")
    check(page.locator("#statistics-dashboard .learning-detail-grid").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 1, "learning history and review sections stack on mobile")
    learning_artwork_columns = page.evaluate("""() => {
      const list = document.querySelector('#learning-history-list');
      const row = document.createElement('li'); row.className = 'learning-history-item';
      const art = document.createElement('span'); art.className = 'learning-item-artwork'; row.appendChild(art);
      const main = document.createElement('div'); main.className = 'learning-list-item-main'; row.appendChild(main);
      list.appendChild(row); const columns = getComputedStyle(row).gridTemplateColumns; row.remove(); return columns;
    }""")
    check(len(learning_artwork_columns.split()) == 2, "learning rows reserve an artwork slot and content column on mobile")
    page.screenshot(path=str(ARTIFACTS / "learning-mobile.png"), full_page=False)
    page.locator("[data-go-page='settings']").first.click()
    check(page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), "settings has no page-level horizontal overflow at 390px")
    check(page.locator("#page-settings .workspace-preferences-grid").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 1, "settings preference groups reflow to one column on mobile")
    check(page.locator("#page-settings .settings-quick-nav").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 2, "settings quick navigation becomes a two-column touch grid on mobile")
    check(page.locator("#page-settings .workspace-shortcut-grid").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 1, "keyboard shortcut controls stack for mobile touch targets")
    page.evaluate("window.scrollTo(0, 0)")
    page.locator("[data-settings-jump='account-panel']").click()
    settings_jump = page.evaluate("({y:window.scrollY, targetTop:document.querySelector('#account-panel').getBoundingClientRect().top, focus:document.activeElement.textContent.trim()})")
    check(settings_jump["y"] > 0 and settings_jump["targetTop"] >= -1, "Settings quick navigation still scrolls to its section instead of resetting to the page top")
    check("私人伺服器帳號" in settings_jump["focus"], "Settings quick navigation focuses the destination section heading")
    page.screenshot(path=str(ARTIFACTS / "settings-mobile.png"), full_page=False)
    page.locator("[data-go-page='profile']").first.click()
    check(page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), "profile has no page-level horizontal overflow at 390px")
    check(page.locator("#profile-panel .profile-metrics").evaluate("e => getComputedStyle(e).gridTemplateColumns.split(' ').filter(Boolean).length") == 1, "profile metrics reflow to one column on mobile")
    page.screenshot(path=str(ARTIFACTS / "profile-mobile.png"), full_page=False)
    page.locator("[data-go-page='results']").first.click()
    check(page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), "results page has no page-level horizontal overflow at 390px")
    check(page.locator("#results-empty").is_visible() and page.locator("#results-return-to-quiz").is_visible(), "results empty state exposes its truthful no-results message and primary CTA")
    page.locator("#results-return-to-quiz").click()
    check(page.locator("#page-quiz").is_visible() and page.evaluate("window.scrollY === 0"), "results primary CTA routes to Quiz and resets the viewport")
    check(page.evaluate("document.activeElement.id") == "quiz-setup-heading", "results CTA moves keyboard focus to the destination quiz setup heading")
    page.keyboard.press("Alt+ArrowLeft")
    check(page.locator("#page-home").is_visible() and page.evaluate("window.scrollY === 0"), "Alt+Left returns to Home with consistent route and scroll semantics")
    page.locator("#home-pie-core").click()
    page.locator(".home-pie-action--quiz").click()
    page.locator("[data-go-page='results']").first.click()
    mobile_results_action = page.locator("#results-return-to-quiz").evaluate("e => ({height:getComputedStyle(e).minHeight,width:e.getBoundingClientRect().width,scrollWidth:document.documentElement.scrollWidth,viewport:window.innerWidth})")
    check(float(mobile_results_action["height"].replace("px", "")) >= 46, "mobile results primary action meets 46px touch target minimum")
    mobile_result_metadata = page.evaluate("""() => { const list=document.querySelector('#quiz-round-results-list'), section=document.querySelector('#quiz-round-results'), empty=document.querySelector('#results-empty'); const old=[...list.childNodes], oldSection=section.hidden, oldEmpty=empty.hidden; const item=document.createElement('li'); item.className='quiz-round-result-item is-wrong'; const title=document.createElement('strong'); title.textContent='超長作品標題 '.repeat(25); const meta=document.createElement('span'); meta.textContent='AMQ · 作品 · 答錯 · 尚未保存 · '.repeat(8); item.append(title,meta); list.replaceChildren(item); section.hidden=false; empty.hidden=true; const result={page:document.documentElement.scrollWidth,viewport:innerWidth,list:list.scrollWidth,client:list.clientWidth,title:title.getBoundingClientRect().height,meta:meta.getBoundingClientRect().height}; list.replaceChildren(...old); section.hidden=oldSection; empty.hidden=oldEmpty; return result; }""")
    check(mobile_result_metadata["page"] <= mobile_result_metadata["viewport"] + 1 and mobile_result_metadata["list"] <= mobile_result_metadata["client"] + 1, "mobile long result titles and unsaved metadata do not overflow")
    check(mobile_result_metadata["title"] > 0 and mobile_result_metadata["meta"] > 0, "mobile result title and status metadata remain readable")
    check(mobile_results_action["scrollWidth"] <= mobile_results_action["viewport"] + 1 and mobile_results_action["width"] > 0, "mobile results action remains visible without horizontal overflow")
    page.screenshot(path=str(ARTIFACTS / "results-mobile.png"), full_page=False)
    page.locator("[data-go-page='home']").first.click()
    check(page.locator("#page-home").is_visible(), "home remains reachable at mobile viewport")
    page.locator("#home-pie-core").click()
    mobile_home_action_overlaps = page.evaluate("""() => {
      const rects = [...document.querySelectorAll('.home-pie-action')].map(node => { const r = node.getBoundingClientRect(); return { left:r.left, top:r.top, right:r.right, bottom:r.bottom }; });
      let overlaps = 0;
      for (let i=0;i<rects.length;i++) for (let j=i+1;j<rects.length;j++) if (rects[i].left < rects[j].right && rects[i].right > rects[j].left && rects[i].top < rects[j].bottom && rects[i].bottom > rects[j].top) overlaps++;
      return overlaps;
    }""")
    check(mobile_home_action_overlaps == 0, "five home destinations do not overlap on mobile")
    check(page.evaluate("document.documentElement.scrollWidth <= window.innerWidth + 1"), "home has no horizontal overflow at 390px")
    page.screenshot(path=str(ARTIFACTS / "home-mobile.png"), full_page=False)
    check(not errors, f"no uncaught browser exceptions: {errors}")
    browser.close()

print(f"\nReal app-shell browser checks: {checks - len(failures)}/{checks} passed")
if failures:
    raise SystemExit(1)
