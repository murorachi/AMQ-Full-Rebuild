const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const css = fs.readFileSync(path.join(root, 'src/styles/ui-design-landing.css'), 'utf8');
const shellCss = fs.readFileSync(path.join(root, 'src/styles/ui-shell.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'src/index.html'), 'utf8');

test('Results workspace has a compact production-owned visual hierarchy', () => {
  assert.match(css, /#results-workspace\s*\{[^}]*display:flex/s);
  assert.match(css, /#results-workspace \.results-empty h3/);
  assert.match(css, /#results-workspace \.results-primary-action/);
  assert.match(html, /id="results-workspace"/);
});
test('empty Results remains honest and routes to Quiz without inventing scores', () => {
  assert.match(html, /還沒有可顯示的本輪結果/);
  assert.match(html, /id="results-return-to-quiz"[^>]*data-go-page="quiz"/);
  assert.doesNotMatch(html, /id="results-workspace"[^]*?全球排名：\s*\d+/);
});
test('multiplayer has a visually distinct section without a second state owner', () => {
  assert.match(css, /#multiplayer-panel\s*\{[^}]*border-top:2px solid #b94d72/s);
  assert.match(html, /id="multiplayer-panel"/);
  assert.equal((html.match(/id="multiplayer-status"/g) || []).length, 1);
  assert.equal((html.match(/id="multiplayer-source"/g) || []).length, 1);
});
test('Quiz configuration is compacted while existing advanced filter remains disclosure-based', () => {
  assert.match(css, /Batch265: make configuration subordinate to play/);
  assert.match(css, /\.quiz-filter-panel\[open\]/);
  assert.match(html, /<details class="quiz-filter-panel"/);
});
test('mobile Results stacks the existing action and avoids horizontal layout pressure', () => {
  assert.match(shellCss, /#results-workspace \.results-empty\{min-height:220px;padding:1rem/);
  assert.match(shellCss, /#results-workspace \.results-primary-action\{width:100%;white-space:normal\}/);
});

test('Multiplayer surface keeps readable overlay above optional Skin artwork', () => {
  assert.match(css, /--amq-skin-role-multiplayer-room-panel,none/);
  assert.match(css, /#multiplayer-panel\s*\{[^}]*background-image:linear-gradient/s);
});
