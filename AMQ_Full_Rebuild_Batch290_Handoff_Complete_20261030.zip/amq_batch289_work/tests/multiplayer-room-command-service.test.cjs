'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const root = path.resolve(__dirname, '..');
const window = {};
const sandbox = { window, Date };
vm.createContext(sandbox);
for (const file of ['src/engine/answer-evaluator.js', 'src/learning/assessment-engine.js', 'src/multiplayer/protocol.js', 'src/multiplayer/room-state-machine.js', 'src/multiplayer/server-answer-assessment.js', 'src/multiplayer/room-command-service.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), sandbox, { filename: file });
}
const machine = window.AMQMultiplayer.roomStateMachine;
const assessmentFactory = window.AMQMultiplayer.serverAnswerAssessment.createServerAnswerAssessor;
const serviceFactory = window.AMQMultiplayer.roomCommandService.createRoomCommandService;
let clock = 1000;
let roundCounter = 0;
let selectCalls = 0;
const record = { source: 'AMQ', title: 'Song A', artist: 'Artist A', animeTitle: 'Work A', workAliases: ['Alias A'] };
const assessor = assessmentFactory({ questions: [{ questionId: 'trusted-q1', target: 'anime', record }] });
const initialState = machine.createRoom({ roomId: 'room-service', hostId: 'host', now: () => clock, maxPlayers: 4 });
const service = serviceFactory({
  initialState, roomStateMachine: machine, assessor,
  selectQuestion: () => { selectCalls += 1; return { questionId: 'trusted-q1' }; },
  createRoundId: () => `server-round-${++roundCounter}`,
  roundDurationMs: 5000, now: () => clock
});
const auth = playerId => ({ authenticated: true, playerId });
const code = expected => error => error.code === expected;
const mutableInitial = JSON.parse(JSON.stringify(machine.createRoom({ roomId: 'detached-initial', hostId: 'detached-host', now: () => clock })));
const detachedService = serviceFactory({
  initialState: mutableInitial, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'detached-round', now: () => clock
});
mutableInitial.hostId = 'forged-host';
mutableInitial.players.push({ id: 'forged-host', displayName: 'Forged', role: 'host', ready: false, joinedAt: clock });
assert.equal(detachedService.getSnapshot(auth('detached-host')).state.hostId, 'detached-host', 'service detaches and freezes initial state at construction');
assert.throws(() => serviceFactory({
  initialState: { schemaVersion: machine.version, revision: 0 }, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'invalid-state'
}), code('ROOM_STATE_INVALID'));
const dispatch = (playerId, command) => service.dispatch(auth(playerId), command);
assert.throws(() => service.dispatch({ playerId: 'host' }, { type: 'room.close' }), code('ROOM_AUTH_REQUIRED'));
assert.throws(() => service.dispatch(auth('outsider'), { type: 'room.snapshot' }), code('ROOM_COMMAND_NOT_ALLOWED'));
clock = 1050;
dispatch('p1', { type: 'player.join', actorId: 'host', displayName: 'P1' });
dispatch('p2', { type: 'player.join', actorId: 'host', displayName: 'P2' });
const p1Ready = dispatch('p1', { type: 'player.ready', ready: false, requestId: 'shared-request-id' });
const p1ReadyReplay = dispatch('p1', { requestId: 'shared-request-id', ready: false, type: 'player.ready' });
assert.equal(p1ReadyReplay.replayed, true, 'same actor/request ID/payload replays the original result');
assert.equal(p1ReadyReplay.event, p1Ready.event, 'replay returns the original event without another transition');
assert.throws(() => dispatch('p1', { type: 'player.ready', ready: true, requestId: 'shared-request-id' }), code('ROOM_REQUEST_ID_REUSED'));
const sparsePayload = [];
sparsePayload.length = 1;
assert.throws(() => dispatch('p1', { type: 'player.ready', ready: false, requestId: 'sparse-payload', metadata: sparsePayload }), code('ROOM_COMMAND_INVALID'), 'sparse arrays cannot collapse to an ambiguous idempotency fingerprint');
assert.throws(() => dispatch('p1', { type: 'player.ready', ready: false, requestId: 'non-finite-payload', metadata: NaN }), code('ROOM_COMMAND_INVALID'), 'non-finite numbers are not valid JSON command metadata');
let commandGetterCalls = 0;
const getterPayload = { type: 'player.ready', requestId: 'getter-payload' };
Object.defineProperty(getterPayload, 'metadata', { enumerable: true, get() { commandGetterCalls += 1; return 'unsafe'; } });
assert.throws(() => dispatch('p1', getterPayload), code('ROOM_COMMAND_INVALID'), 'accessors are rejected without running them');
assert.equal(commandGetterCalls, 0, 'canonicalization must not execute command getters');
let requestIdGetterCalls = 0;
const requestIdGetterPayload = { type: 'player.ready', ready: false };
Object.defineProperty(requestIdGetterPayload, 'requestId', { enumerable: true, get() { requestIdGetterCalls += 1; return 'unsafe-id'; } });
assert.throws(() => dispatch('p1', requestIdGetterPayload), code('ROOM_COMMAND_INVALID'), 'requestId accessors must be rejected before request ID inspection');
assert.equal(requestIdGetterCalls, 0, 'requestId getter must not execute');
let noRequestIdGetterCalls = 0;
const noRequestIdGetterPayload = { type: 'player.ready', ready: false };
Object.defineProperty(noRequestIdGetterPayload, 'metadata', { enumerable: true, get() { noRequestIdGetterCalls += 1; return true; } });
assert.throws(() => dispatch('p1', noRequestIdGetterPayload), code('ROOM_COMMAND_INVALID'), 'commands without requestId must still be canonicalized safely');
assert.equal(noRequestIdGetterCalls, 0, 'getter must not execute on commands without requestId');
const normalizedIdFirst = dispatch('p1', { type: 'player.ready', ready: false, requestId: ' padded-id ' });
const normalizedIdReplay = dispatch('p1', { type: 'player.ready', ready: false, requestId: 'padded-id' });
assert.equal(normalizedIdFirst.replayed, false);
assert.equal(normalizedIdReplay.replayed, true, 'request IDs are normalized before fingerprint comparison');
const p2Ready = dispatch('p2', { type: 'player.ready', ready: false, requestId: 'shared-request-id' });
assert.equal(p2Ready.replayed, false, 'request IDs are isolated by authenticated player');
dispatch('p1', { type: 'player.ready', ready: true });
dispatch('p2', { type: 'player.ready', ready: true });
assert.throws(() => dispatch('p1', { type: 'round.start' }), code('ROOM_HOST_REQUIRED'));
assert.equal(selectCalls, 0, 'unauthorized start must not call the trusted question selector');
const stale = service.revision - 1;
assert.throws(() => dispatch('host', { type: 'round.start', expectedRevision: stale }), code('ROOM_REVISION_CONFLICT'));
assert.equal(selectCalls, 0, 'stale command must not consume a question selection');
clock = 1200;
const started = dispatch('host', { type: 'round.start', questionId: 'attacker-question', roundId: 'attacker-round', durationMs: 999999 });
assert.equal(started.snapshot.state.currentRound.questionId, 'trusted-q1');
assert.equal(started.snapshot.state.currentRound.id, 'server-round-1');
assert.equal(started.snapshot.state.currentRound.deadlineAt, 6200, 'duration comes from server configuration');
const exportedState = service.exportState();
assert.equal(exportedState.revision, service.revision, 'server persistence hook exports the authoritative state revision');
assert.equal(exportedState.currentRound.id, 'server-round-1');
assert.equal(Object.isFrozen(exportedState), true, 'exported persistence state remains detached and immutable');
assert.throws(() => dispatch('p1', { type: 'round.timeout' }), code('ROOM_COMMAND_NOT_ALLOWED'));
clock = 2200;
const answerCommand = { type: 'answer.submit', requestId: 'answer-once-1', actorId: 'host', roundId: 'server-round-1', answer: 'Alias A', target: 'title', outcome: 'timeout', correct: false, grade: 1, receivedAt: 999999 };
const answered = dispatch('p1', answerCommand);
const revisionAfterAnswer = service.revision;
const answerReplay = dispatch('p1', { ...answerCommand });
assert.equal(answerReplay.replayed, true, 'retry of a committed answer returns the original result');
assert.equal(answerReplay.assessment.assessment.grade, answered.assessment.assessment.grade);
assert.equal(service.revision, revisionAfterAnswer, 'idempotent replay must not commit a second state transition');
assert.throws(() => dispatch('p1', { ...answerCommand, answer: 'different answer' }), code('ROOM_REQUEST_ID_REUSED'));
assert.equal(answered.event.playerId, 'p1', 'actor identity comes from authenticated connection, not command payload');
assert.equal(answered.assessment.assessment.grade, 4, 'trusted server elapsed time and title evaluator override client claims');
assert.equal(answered.assessment.isWorkTitleCorrect, true);
assert.equal(answered.snapshot.state.currentRound.answers[0].answer, 'Alias A');
assert.throws(() => dispatch('p1', { type: 'answer.submit', roundId: 'server-round-1', answer: 'second answer' }), code('ROOM_ANSWER_DUPLICATE'));
assert.throws(() => service.getSnapshot(auth('outsider')), code('ROOM_PLAYER_NOT_MEMBER'));
clock = 3000;
assert.throws(() => service.expireRound(), code('ROOM_ANSWER_DEADLINE_NOT_REACHED'));
clock = 6300;
const expired = service.expireRound();
assert.equal(expired.event.type, 'round.timeout');
assert.equal(expired.snapshot.state.phase, 'lobby');
const delayedAnswerReplay = dispatch('p1', { ...answerCommand });
assert.equal(delayedAnswerReplay.replayed, true, 'delayed answer retry still replays the original command');
assert.equal(delayedAnswerReplay.event, answered.event, 'delayed replay preserves the original event');
assert.equal(delayedAnswerReplay.assessment, answered.assessment, 'delayed replay preserves the original assessment');
assert.equal(delayedAnswerReplay.snapshot.state.revision, service.revision, 'current room members receive a fresh snapshot with the current revision on replay');
assert.equal(delayedAnswerReplay.snapshot.state.currentRound.status, 'closed', 'fresh replay snapshot reflects the closed round instead of restoring stale active-round state');
assert.equal(expired.timeoutAssessments.length, 2, 'host and unanswered player receive timeout assessment; answered player is not assessed twice');
assert.ok(expired.timeoutAssessments.every(item => item.assessment.grade === 1));
assert.equal(expired.timeoutAssessments.map(item => item.playerId).sort().join(','), 'host,p2');
assert.throws(() => service.expireRound(), code('ROOM_NO_ACTIVE_ROUND'));
const boundedState = machine.createRoom({ roomId: 'bounded-idempotency', hostId: 'host-bounded', now: () => clock });
const boundedService = serviceFactory({
  initialState: boundedState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }),
  createRoundId: () => 'bounded-round', roundDurationMs: 5000, now: () => clock,
  maxIdempotencyEntries: 1
});
const boundedAuth = auth('host-bounded');
const firstBounded = boundedService.dispatch(boundedAuth, { type: 'player.ready', ready: false, requestId: 'first' });
boundedService.dispatch(boundedAuth, { type: 'player.ready', ready: true, requestId: 'second' });
const afterEviction = boundedService.dispatch(boundedAuth, { type: 'player.ready', ready: false, requestId: 'first' });
assert.equal(afterEviction.replayed, false, 'old idempotency entries are evicted at the configured capacity');
assert.equal(firstBounded.event.type, 'noop');
assert.equal(boundedService.revision, 2, 'bounded cache eviction does not corrupt room revision');
const fifoState = machine.createRoom({ roomId: 'fifo-replay-order', hostId: 'fifo-host', now: () => clock });
const fifoService = serviceFactory({
  initialState: fifoState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'fifo-round',
  now: () => clock, maxIdempotencyEntries: 2
});
const fifoAuth = auth('fifo-host');
fifoService.dispatch(fifoAuth, { type: 'player.ready', ready: false, requestId: 'fifo-a' });
fifoService.dispatch(fifoAuth, { type: 'player.ready', ready: true, requestId: 'fifo-b' });
assert.equal(fifoService.dispatch(fifoAuth, { type: 'player.ready', ready: false, requestId: 'fifo-a' }).replayed, true, 'replay hit does not execute the cached command again');
fifoService.dispatch(fifoAuth, { type: 'player.ready', ready: false, requestId: 'fifo-c' });
const fifoAAfterEviction = fifoService.dispatch(fifoAuth, { type: 'player.ready', ready: false, requestId: 'fifo-a' });
assert.equal(fifoAAfterEviction.replayed, false, 'cache replay does not refresh insertion order; the oldest entry is evicted FIFO');
assert.equal(fifoService.revision, 2, 'replayed FIFO entry can be re-executed after eviction without corrupting revision');
assert.throws(() => serviceFactory({
  initialState: boundedState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'x',
  maxIdempotencyEntries: -1
}), code('ROOM_IDEMPOTENCY_CAPACITY_INVALID'));
const limitedState = machine.createRoom({ roomId: 'limited-room', hostId: 'limited-host', now: () => clock });
const limitedService = serviceFactory({
  initialState: limitedState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'limited-round',
  now: () => clock, maxCommandsPerWindow: 2, commandWindowMs: 1000
});
const limitedAuth = auth('limited-host');
const limitedFirst = limitedService.dispatch(limitedAuth, { type: 'player.ready', ready: false, requestId: 'rate-1' });
limitedService.dispatch(limitedAuth, { type: 'player.ready', ready: true, requestId: 'rate-2' });
assert.throws(() => limitedService.dispatch(limitedAuth, { type: 'player.ready', ready: false, requestId: 'rate-3' }), error => error.code === 'ROOM_RATE_LIMITED' && error.details.retryAfterMs > 0);
assert.throws(() => limitedService.dispatch(limitedAuth, { type: 'player.ready', ready: true, requestId: 'rate-1' }), code('ROOM_RATE_LIMITED'), 'request ID mismatch attempts count against the rate limit');
assert.equal(limitedService.dispatch(limitedAuth, { type: 'player.ready', ready: false, requestId: 'rate-1' }).replayed, true, 'idempotent replay bypasses command rate limit');
clock += 1000;
assert.equal(limitedService.dispatch(limitedAuth, { type: 'player.ready', ready: false, requestId: 'rate-3' }).replayed, false, 'new commands are accepted after the sliding window expires');
assert.equal(limitedFirst.event.type, 'noop');

// A new command reads server time once and uses that exact instant for both rate limit and transition.
let tickingClock = 20000;
let tickingClockCalls = 0;
const tickingState = machine.createRoom({ roomId: 'single-clock-read-room', hostId: 'single-clock-host', now: () => tickingClock });
const tickingService = serviceFactory({
  initialState: tickingState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'single-clock-round',
  now: () => { tickingClockCalls += 1; return tickingClock + tickingClockCalls - 1; },
  maxCommandsPerWindow: 2, commandWindowMs: 1000
});
const tickingResult = tickingService.dispatch(auth('single-clock-host'), { type: 'player.ready', ready: false, requestId: 'single-clock-request' });
assert.equal(tickingClockCalls, 1, 'new command reads the injected server clock once');
assert.equal(tickingResult.event.at, 20000, 'state transition uses the same timestamp used for rate-limit accounting');
const tickingReplay = tickingService.dispatch(auth('single-clock-host'), { type: 'player.ready', ready: false, requestId: 'single-clock-request' });
assert.equal(tickingReplay.replayed, true);
assert.equal(tickingClockCalls, 1, 'successful idempotent replay does not need a new server timestamp');

// Sliding-window cutoff is exclusive: a command exactly one full window later may proceed.
let boundaryClock = 30000;
const boundaryState = machine.createRoom({ roomId: 'rate-boundary-room', hostId: 'rate-boundary-host', now: () => boundaryClock });
const boundaryService = serviceFactory({
  initialState: boundaryState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'rate-boundary-round',
  now: () => boundaryClock, maxCommandsPerWindow: 1, commandWindowMs: 1000
});
const boundaryAuth = auth('rate-boundary-host');
boundaryService.dispatch(boundaryAuth, { type: 'player.ready', ready: false, requestId: 'boundary-first' });
assert.throws(() => boundaryService.dispatch(boundaryAuth, { type: 'player.ready', ready: true, requestId: 'boundary-blocked' }), error => error.code === 'ROOM_RATE_LIMITED' && error.details.retryAfterMs === 1000);
boundaryClock += 1000;
assert.equal(boundaryService.dispatch(boundaryAuth, { type: 'player.ready', ready: true, requestId: 'boundary-exact-cutoff' }).replayed, false, 'timestamp exactly at cutoff expires from sliding window');
assert.throws(() => serviceFactory({
  initialState: limitedState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'x',
  maxCommandsPerWindow: 0
}), code('ROOM_RATE_LIMIT_CONFIG_INVALID'));
// A backwards wall-clock adjustment must not corrupt sliding-window assumptions.
let rollbackClock = 5000;
const rollbackState = machine.createRoom({ roomId: 'clock-rollback-room', hostId: 'clock-host', now: () => rollbackClock });
const rollbackService = serviceFactory({
  initialState: rollbackState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'clock-round',
  now: () => rollbackClock, maxCommandsPerWindow: 4, commandWindowMs: 1000
});
const rollbackAuth = auth('clock-host');
rollbackService.dispatch(rollbackAuth, { type: 'player.ready', ready: false, requestId: 'clock-baseline' });
const rollbackRevision = rollbackService.revision;
rollbackClock = 4999;
assert.throws(() => rollbackService.dispatch(rollbackAuth, { type: 'player.ready', ready: true, requestId: 'clock-backwards' }), code('ROOM_SERVER_TIME_REGRESSION'));
assert.equal(rollbackService.revision, rollbackRevision, 'clock rollback is rejected before room state can change');
rollbackClock = 5000;
assert.equal(rollbackService.dispatch(rollbackAuth, { type: 'player.ready', ready: false, requestId: 'clock-baseline' }).replayed, true, 'service resumes when clock reaches the last observed timestamp');

// Assessment failure after a tentative state-machine transition must not commit state or cache the request.
let failAssessment = true;
const guardedAssessor = {
  hasQuestion: id => assessor.hasQuestion(id),
  assessSubmission(...args) {
    if (failAssessment) throw new Error('synthetic assessor failure');
    return assessor.assessSubmission(...args);
  }
};
let atomicClock = 8000;
const atomicState = machine.createRoom({ roomId: 'atomic-room', hostId: 'atomic-host', now: () => atomicClock });
const atomicService = serviceFactory({
  initialState: atomicState, roomStateMachine: machine, assessor: guardedAssessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'atomic-round',
  now: () => atomicClock, roundDurationMs: 5000
});
const atomicHost = auth('atomic-host');
const atomicGuest = auth('atomic-guest');
atomicService.dispatch(atomicGuest, { type: 'player.join', displayName: 'Guest' });
atomicService.dispatch(atomicGuest, { type: 'player.ready', ready: true });
atomicService.dispatch(atomicHost, { type: 'round.start' });
atomicClock += 100;
const beforeFailedAssessment = atomicService.getSnapshot(atomicGuest).state;
const failingAnswer = { type: 'answer.submit', roundId: 'atomic-round', answer: 'Alias A', requestId: 'atomic-answer' };
assert.throws(() => atomicService.dispatch(atomicGuest, failingAnswer), /synthetic assessor failure/);
assert.equal(atomicService.revision, beforeFailedAssessment.revision, 'failed assessment does not commit the tentative answer transition');
assert.equal(atomicService.getSnapshot(atomicGuest).state.currentRound.answers.length, 0, 'failed assessment leaves no partial answer in room state');
failAssessment = false;
const retriedAnswer = atomicService.dispatch(atomicGuest, failingAnswer);
assert.equal(retriedAnswer.replayed, false, 'failed command is not written to the idempotency cache');
assert.equal(retriedAnswer.snapshot.state.currentRound.answers.length, 1, 'retry commits exactly one answer after assessment succeeds');
assert.equal(atomicService.revision, beforeFailedAssessment.revision + 1, 'successful retry advances revision exactly once');

// Predictable round-start rejections must not consume injected selector/factory resources.
let rejectedStartSelectorCalls = 0;
let rejectedStartIdCalls = 0;
const noPlayersState = machine.createRoom({ roomId: 'start-preflight-empty', hostId: 'preflight-host', now: () => clock });
const noPlayersService = serviceFactory({
  initialState: noPlayersState, roomStateMachine: machine, assessor,
  selectQuestion: () => { rejectedStartSelectorCalls += 1; return { questionId: 'trusted-q1' }; },
  createRoundId: () => { rejectedStartIdCalls += 1; return 'unused-round'; }, now: () => clock
});
assert.throws(() => noPlayersService.dispatch(auth('preflight-host'), { type: 'round.start' }), code('ROOM_NEEDS_PLAYERS'));
assert.equal(rejectedStartSelectorCalls, 0, 'no-player rejection must happen before consuming a question selection');
assert.equal(rejectedStartIdCalls, 0, 'no-player rejection must happen before consuming a round ID');
const unreadyState = machine.createRoom({ roomId: 'start-preflight-unready', hostId: 'preflight-host-2', now: () => clock });
const unreadyService = serviceFactory({
  initialState: unreadyState, roomStateMachine: machine, assessor,
  selectQuestion: () => { rejectedStartSelectorCalls += 1; return { questionId: 'trusted-q1' }; },
  createRoundId: () => { rejectedStartIdCalls += 1; return 'unused-round-2'; }, now: () => clock
});
unreadyService.dispatch(auth('preflight-guest'), { type: 'player.join' });
assert.throws(() => unreadyService.dispatch(auth('preflight-host-2'), { type: 'round.start' }), code('ROOM_PLAYERS_NOT_READY'));
assert.equal(rejectedStartSelectorCalls, 0, 'unready-player rejection must happen before consuming a question selection');
assert.equal(rejectedStartIdCalls, 0, 'unready-player rejection must happen before consuming a round ID');

// A timeout assessment failure partway through a room must not close the round.
let timeoutClock = 12000;
let timeoutAssessmentCalls = 0;
let failSecondTimeoutAssessment = true;
const timeoutAtomicAssessor = {
  hasQuestion: id => assessor.hasQuestion(id),
  assessSubmission(...args) {
    if (args[1] && args[1].outcome === 'timeout') {
      timeoutAssessmentCalls += 1;
      if (failSecondTimeoutAssessment && timeoutAssessmentCalls === 2) throw new Error('synthetic second timeout assessment failure');
    }
    return assessor.assessSubmission(...args);
  }
};
const timeoutAtomicState = machine.createRoom({ roomId: 'timeout-atomic-room', hostId: 'timeout-host', now: () => timeoutClock });
const timeoutAtomicService = serviceFactory({
  initialState: timeoutAtomicState, roomStateMachine: machine, assessor: timeoutAtomicAssessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'timeout-atomic-round',
  now: () => timeoutClock, roundDurationMs: 1000
});
const timeoutHost = auth('timeout-host');
const timeoutGuestA = auth('timeout-guest-a');
const timeoutGuestB = auth('timeout-guest-b');
timeoutAtomicService.dispatch(timeoutGuestA, { type: 'player.join', displayName: 'Guest A' });
timeoutAtomicService.dispatch(timeoutGuestB, { type: 'player.join', displayName: 'Guest B' });
timeoutAtomicService.dispatch(timeoutGuestA, { type: 'player.ready', ready: true });
timeoutAtomicService.dispatch(timeoutGuestB, { type: 'player.ready', ready: true });
timeoutAtomicService.dispatch(timeoutHost, { type: 'round.start' });
timeoutClock += 1000;
const beforeTimeoutFailure = timeoutAtomicService.getSnapshot(timeoutHost).state;
assert.throws(() => timeoutAtomicService.expireRound(), /synthetic second timeout assessment failure/);
assert.equal(timeoutAtomicService.revision, beforeTimeoutFailure.revision, 'partial timeout assessment failure does not commit room revision');
assert.equal(timeoutAtomicService.getSnapshot(timeoutHost).state.phase, 'round', 'partial timeout assessment failure leaves the round active for retry');
assert.equal(timeoutAtomicService.getSnapshot(timeoutHost).state.currentRound.status, 'active');
failSecondTimeoutAssessment = false;
timeoutAssessmentCalls = 0;
const recoveredTimeout = timeoutAtomicService.expireRound();
assert.equal(recoveredTimeout.timeoutAssessments.length, 3, 'retry recomputes and returns timeout assessment for every unanswered player');
assert.equal(timeoutAtomicService.getSnapshot(timeoutHost).state.phase, 'lobby');
assert.equal(timeoutAtomicService.revision, beforeTimeoutFailure.revision + 1, 'successful retry commits exactly one round transition');


// Close-command retries must replay successful results, while failed commands must not poison idempotency.
let closeClock = 40000;
let closeRoundCounter = 0;
const closeState = machine.createRoom({ roomId: 'close-retry-room', hostId: 'close-host', now: () => closeClock });
const closeService = serviceFactory({
  initialState: closeState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }),
  createRoundId: () => `close-retry-round-${++closeRoundCounter}`,
  now: () => closeClock, roundDurationMs: 1000
});
const closeHost = auth('close-host');
const closeGuest = auth('close-guest');
closeService.dispatch(closeGuest, { type: 'player.join', displayName: 'Close Guest' });
closeService.dispatch(closeGuest, { type: 'player.ready', ready: true });
closeService.dispatch(closeHost, { type: 'round.start', requestId: 'close-round-start' });
const activeCloseRevision = closeService.revision;
const closedRound = closeService.dispatch(closeHost, { type: 'round.close', requestId: 'close-round-once' });
assert.equal(closeService.revision, activeCloseRevision + 1, 'round.close commits one revision');
const closedRoundReplay = closeService.dispatch(closeHost, { type: 'round.close', requestId: 'close-round-once' });
assert.equal(closedRoundReplay.replayed, true, 'successful round.close retry replays the original result');
assert.equal(closedRoundReplay.event.at, closedRound.event.at, 'round.close replay preserves the original event timestamp');
assert.equal(closeService.revision, activeCloseRevision + 1, 'round.close replay does not increment revision');

closeService.dispatch(closeGuest, { type: 'player.ready', ready: true });
closeService.dispatch(closeHost, { type: 'round.start', requestId: 'close-room-round-start' });
const activeRoomCloseRevision = closeService.revision;
assert.throws(() => closeService.dispatch(closeHost, { type: 'room.close', requestId: 'room-close-after-round' }), code('ROOM_ROUND_ACTIVE'));
assert.equal(closeService.revision, activeRoomCloseRevision, 'failed room.close does not commit a revision');
const closedRoundBeforeRoom = closeService.dispatch(closeHost, { type: 'round.close', requestId: 'close-round-before-room-close' });
assert.equal(closedRoundBeforeRoom.event.type, 'round.close');
const closedRoom = closeService.dispatch(closeHost, { type: 'room.close', requestId: 'room-close-after-round' });
assert.equal(closedRoom.event.type, 'room.close', 'same requestId can be retried after its previous failed attempt');
const closedRoomRevision = closeService.revision;
const closedRoomReplay = closeService.dispatch(closeHost, { type: 'room.close', requestId: 'room-close-after-round' });
assert.equal(closedRoomReplay.replayed, true, 'successful room.close retry replays the original result');
assert.equal(closedRoomReplay.event.at, closedRoom.event.at, 'room.close replay preserves original event');
assert.equal(closeService.revision, closedRoomRevision, 'room.close replay does not increment revision');

// Host leave is idempotent across host transfer; tie-breaks must not depend on runtime locale.
let leaveClock = 50000;
let leaveRoundCounter = 0;
const leaveState = machine.createRoom({ roomId: 'host-transfer-retry-room', hostId: 'former-host', now: () => leaveClock });
const leaveService = serviceFactory({
  initialState: leaveState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }),
  createRoundId: () => `host-transfer-round-${++leaveRoundCounter}`,
  now: () => leaveClock, roundDurationMs: 1000
});
const formerHost = auth('former-host');
const lowerCaseGuest = auth('a-guest');
const upperCaseGuest = auth('A-guest');
const firstGuestJoin = leaveService.dispatch(lowerCaseGuest, { type: 'player.join', displayName: 'Lowercase guest', requestId: 'lowercase-guest-join' });
const firstGuestJoinRevision = leaveService.revision;
const firstGuestJoinReplay = leaveService.dispatch(lowerCaseGuest, { type: 'player.join', displayName: 'Lowercase guest', requestId: 'lowercase-guest-join' });
assert.equal(firstGuestJoinReplay.replayed, true, 'successful player.join retry replays without duplicating membership');
assert.equal(firstGuestJoinReplay.event, firstGuestJoin.event, 'player.join retry preserves the original event');
assert.equal(leaveService.revision, firstGuestJoinRevision, 'player.join replay does not increment revision');
leaveService.dispatch(upperCaseGuest, { type: 'player.join', displayName: 'Uppercase guest' });
const beforeHostLeave = leaveService.revision;
const hostLeave = leaveService.dispatch(formerHost, { type: 'player.leave', requestId: 'former-host-leave-once' });
assert.equal(hostLeave.event.hostChanged, true, 'host leave event records that ownership transferred');
assert.equal(hostLeave.event.hostId, 'A-guest', 'equal join timestamps use deterministic code-unit ID ordering, independent of locale');
assert.equal(hostLeave.snapshot.state.hostId, 'A-guest');
assert.equal(leaveService.revision, beforeHostLeave + 1, 'host leave commits exactly one revision');
const hostLeaveReplay = leaveService.dispatch(formerHost, { type: 'player.leave', requestId: 'former-host-leave-once' });
assert.equal(hostLeaveReplay.replayed, true, 'former host can safely retry its exact successful leave after losing membership');
assert.equal(hostLeaveReplay.event.at, hostLeave.event.at, 'leave replay preserves the original event timestamp');
assert.equal(hostLeaveReplay.event.hostId, 'A-guest', 'leave replay preserves the original host-transfer result');
assert.equal(leaveService.revision, beforeHostLeave + 1, 'leave replay does not transfer host or increment revision twice');
assert.throws(() => leaveService.dispatch(formerHost, { type: 'room.close', requestId: 'former-host-close-attempt' }), code('ROOM_PLAYER_NOT_MEMBER'), 'former host cannot use host privileges after leaving');
assert.throws(() => leaveService.dispatch(formerHost, { type: 'player.leave', requestId: 'former-host-leave-once', expectedRevision: leaveService.revision }), code('ROOM_REQUEST_ID_REUSED'), 'reusing a successful leave request ID for a different payload is rejected');
assert.equal(leaveService.revision, beforeHostLeave + 1, 'rejected stale-host commands do not mutate room state');
leaveService.dispatch(lowerCaseGuest, { type: 'player.ready', ready: true });
const newHostStart = leaveService.dispatch(upperCaseGuest, { type: 'round.start', requestId: 'new-host-starts-round' });
assert.equal(newHostStart.event.type, 'round.start', 'the deterministically elected host receives host authority');
assert.equal(leaveService.getSnapshot(upperCaseGuest).state.hostId, 'A-guest');
const formerHostDelayedReplay = leaveService.dispatch(formerHost, { type: 'player.leave', requestId: 'former-host-leave-once' });
assert.equal(formerHostDelayedReplay.replayed, true, 'former host can retry its original leave command');
assert.equal(formerHostDelayedReplay.snapshot.state.revision, hostLeave.snapshot.state.revision, 'former member does not receive a fresh room snapshot after leaving');
assert.ok(formerHostDelayedReplay.snapshot.state.revision < leaveService.revision, 'the former member replay snapshot remains the original leave response');

const finalLeaveState = machine.createRoom({ roomId: 'last-host-leave-room', hostId: 'last-host', now: () => leaveClock });
const finalLeaveService = serviceFactory({
  initialState: finalLeaveState, roomStateMachine: machine, assessor,
  selectQuestion: () => ({ questionId: 'trusted-q1' }), createRoundId: () => 'unused-final-leave-round',
  now: () => leaveClock
});
const lastHostLeave = finalLeaveService.dispatch(auth('last-host'), { type: 'player.leave', requestId: 'last-host-leaves' });
assert.equal(lastHostLeave.event.type, 'player.leave', 'last host can leave successfully without a viewer-specific snapshot failure');
assert.equal(lastHostLeave.snapshot.state.phase, 'closed', 'leaving the final player closes the room');
assert.equal(finalLeaveService.revision, 1);

console.log('multiplayer-room-command-service: PASS (auth-derived identity, trusted round selection/time, command allowlist, request idempotency, bounded cache, rate-limit boundaries, close retry atomicity, assessment orchestration, host-transfer retry and deterministic tie-break)');
