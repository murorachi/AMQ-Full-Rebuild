#!/usr/bin/env python3
"""Chromium desktop/mobile regression for the real Quiz Arena and Results pages."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
OUT = ROOT / 'artifacts' / 'batch244-regression'
OUT.mkdir(parents=True, exist_ok=True)
html = (SRC / 'index.html').read_text(encoding='utf-8')
def inline_css(m): return '<style>\n' + (SRC / m.group(1)).read_text(encoding='utf-8') + '\n</style>'
def inline_js(m): return '<script>\n' + (SRC / m.group(1)).read_text(encoding='utf-8') + '\n</script>'
html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', inline_css, html)
html = re.sub(r'<script src="([^"]+)"></script>', inline_js, html)
checks = 0
failures = []
def check(ok, label):
    global checks
    checks += 1
    print(('PASS ' if ok else 'FAIL ') + label)
    if not ok: failures.append(label)
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
    page = browser.new_page(viewport={'width':1440,'height':900})
    errors=[]
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.set_content(html, wait_until='domcontentloaded', timeout=60000)
    page.wait_for_timeout(900)
    page.locator('#home-pie-core').click()
    page.locator('#home-pie-actions [data-go-page="quiz"]').click()
    page.wait_for_timeout(150)
    check(page.locator('#page-quiz').is_visible(), 'quiz route opens through real navigation')
    check(page.locator('#quiz-setup-heading').evaluate('(e)=>document.activeElement===e'), 'quiz navigation restores focus to setup heading')
    check(page.locator('#quiz-panel .quiz-question-card').count()==1, 'single-player quiz keeps one authoritative question stage')
    controls=['#quiz-start','#quiz-play','#quiz-pause','#quiz-reveal','#quiz-skip','#quiz-next','#quiz-end','#quiz-submit']
    check(all(page.locator(s).count()==1 for s in controls), 'all primary quiz controls remain present exactly once')
    check(page.locator('#quiz-answer').is_visible(), 'answer input remains visible in setup/idle state')
    desktop=page.evaluate("""() => {const q=s=>document.querySelector(s).getBoundingClientRect(); const cs=s=>getComputedStyle(document.querySelector(s));return {width:document.documentElement.scrollWidth,inner:innerWidth,stage:q('#quiz-panel .quiz-question-card').height,columns:cs('#quiz-panel .quiz-summary-row').gridTemplateColumns,answer:cs('#quiz-panel .quiz-answer-form').gridTemplateColumns};}""")
    check(desktop['width']<=desktop['inner']+1, '1440px quiz has no horizontal overflow')
    check(desktop['stage']>=200, 'quiz question stage has a substantial minimum height')
    check(len(desktop['columns'].split(' '))==3 and page.locator('#quiz-pool-size').is_visible(), 'desktop HUD keeps progress/timer compact and pool count in the left session rail')
    page.screenshot(path=str(OUT/'quiz-desktop.png'), full_page=True)
    page.locator('[data-go-page="results"]').first.click()
    check(page.locator('#page-results').is_visible(), 'results route opens through real navigation')
    check(page.locator('#results-empty').is_visible() and not page.locator('#quiz-round-results').is_visible(), 'empty results state is shown without fabricated score rows')
    check(page.locator('#quiz-round-results-list li').count()==0, 'empty result list contains no synthetic rows')
    page.locator('#results-return-to-quiz').click()
    check(page.locator('#page-quiz').is_visible(), 'empty-state CTA returns to Quiz Arena')
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(150)
    mobile=page.evaluate("""() => ({width:document.documentElement.scrollWidth,inner:innerWidth,metrics:getComputedStyle(document.querySelector('#quiz-panel .quiz-summary-row')).gridTemplateColumns,answer:getComputedStyle(document.querySelector('#quiz-panel .quiz-answer-form')).gridTemplateColumns,actions:getComputedStyle(document.querySelector('#quiz-panel .quiz-actions')).gridTemplateColumns})""")
    check(mobile['width']<=mobile['inner']+1, '390px quiz has no horizontal overflow')
    check(len(mobile['metrics'].split(' '))==2, 'mobile HUD collapses to two columns while progress stays centered')
    check(len(mobile['answer'].split(' '))==2, 'mobile answer form keeps input and submit together in a compact game bar')
    check(len(mobile['actions'].split(' '))==2, 'mobile quiz controls use two columns')
    page.screenshot(path=str(OUT/'quiz-mobile.png'), full_page=True)
    page.locator('[data-go-page="results"]').first.click()
    mobile_results=page.evaluate("document.documentElement.scrollWidth <= innerWidth + 1")
    check(mobile_results, '390px results empty state has no horizontal overflow')
    page.screenshot(path=str(OUT/'results-mobile.png'), full_page=True)
    # A temporary DOM-only long-title fixture verifies wrapping; it is never persisted or treated as product data.
    page.evaluate("""() => {const section=document.querySelector('#quiz-round-results');section.hidden=false;document.querySelector('#results-empty').hidden=true;const li=document.createElement('li');li.className='quiz-round-result-item is-wrong';const title=document.createElement('strong');title.textContent='超長作品標題'.repeat(24);const meta=document.createElement('span');meta.textContent='AMQ · 作品 · 答錯 · 尚未保存 · metadata '.repeat(8);li.append(title,meta);document.querySelector('#quiz-round-results-list').replaceChildren(li);}""")
    page.wait_for_timeout(100)
    long=page.evaluate("""() => ({width:document.documentElement.scrollWidth,inner:innerWidth,li:document.querySelector('#quiz-round-results-list li').getBoundingClientRect().width,scroll:document.querySelector('#quiz-round-results-list li').scrollWidth})""")
    check(long['width']<=long['inner']+1 and long['scroll']<=long['li']+2, 'long result title and metadata wrap without horizontal overflow')
    check(not errors, f'no uncaught browser exceptions ({len(errors)})')
    browser.close()
print(f'Batch244 Quiz/Results Chromium assertions: {checks-len(failures)}/{checks} PASS')
if failures: raise SystemExit('; '.join(failures))
