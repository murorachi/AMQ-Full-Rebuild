'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sandbox = { window: {} };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/persistence/familiarity-store.js'), 'utf8'), sandbox, { filename: 'src/persistence/familiarity-store.js' });
const api = sandbox.window.AMQPersistence.familiarityStore;
class FakeStorage {
  constructor(values = {}) { this.values = new Map(Object.entries(values)); this.failWrites = false; this.failReads = false; }
  getItem(key) { if (this.failReads) throw new Error("storage read denied"); return this.values.has(key) ? this.values.get(key) : null; }
  setItem(key, value) { if (this.failWrites) throw new Error('quota exceeded'); this.values.set(key, String(value)); }
}
class FakeEventTarget {
  constructor() { this.listeners = new Map(); }
  addEventListener(type, fn) { if (!this.listeners.has(type)) this.listeners.set(type, new Set()); this.listeners.get(type).add(fn); }
  removeEventListener(type, fn) { this.listeners.get(type)?.delete(fn); }
  fire(type, event) { for (const fn of [...(this.listeners.get(type) || [])]) fn(event); }
}
const amq = id => ({ id, source: 'AMQ' });
const emq = id => ({ id, source: 'EMQ' });
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }

test('reads the observed AMQ status key and normalizes valid 0–4 familiarity levels', () => {
  const storage = new FakeStorage({ aniCollection_v2: JSON.stringify({ '1': 3, '2': '2', '3': 0, '4': null, '5': 'bad', '6': 5, '7': 4 }) });
  const store = api.createFamiliarityStore({ storage });
  assert.equal(store.getLevel(amq(1)), 3);
  assert.equal(store.getLevel(amq(2)), 2);
  assert.equal(store.getLevel(amq(3)), 0);
  assert.equal(store.getLevel(amq(4)), null);
  assert.equal(store.getLevel(amq(5)), null);
  assert.equal(store.getLevel(amq(6)), null);
  assert.equal(store.getLevel(amq(7)), 4);
  assert.equal(store.getLevel(amq(8)), 0);
  store.dispose();
});
test('uses the legacy fallback only when the primary value is falsy and writes to the primary key', () => {
  const storage = new FakeStorage({ anisongFieldGuide_v1: JSON.stringify({ '1': 2 }) });
  const events = [];
  const store = api.createFamiliarityStore({ storage, dispatchEvent: name => events.push(name) });
  assert.equal(store.getLevel(amq(1)), 2);
  assert.equal(store.setLevel(amq(2), 4).persisted, true);
  assert.deepEqual(JSON.parse(storage.getItem('aniCollection_v2')), { '1': 2, '2': 4 });
  assert.deepEqual(events, ['ani-familiarity-updated-v51']);
  store.setLevel(amq(2), 0);
  assert.deepEqual(JSON.parse(storage.getItem('aniCollection_v2')), { '1': 2 });
  store.dispose();
});
test('keeps EMQ familiarity separate from legacy AMQ IDs that collide numerically', () => {
  const storage = new FakeStorage({ aniCollection_v2: JSON.stringify({ '1': 3 }) });
  const events = [];
  const store = api.createFamiliarityStore({ storage, dispatchEvent: name => events.push(name) });
  assert.equal(store.getLevel(amq(1)), 3);
  assert.equal(store.getLevel(emq(1)), 0);
  assert.equal(store.setLevel(emq(1), 2).persisted, true);
  assert.equal(store.getLevel(amq(1)), 3);
  assert.equal(store.getLevel(emq(1)), 2);
  assert.deepEqual(JSON.parse(storage.getItem('amqLearningFamiliarityV1')), { '1': 2 });
  assert.deepEqual(events, ['amq-learning-familiarity-updated-v1']);
  store.dispose();
});
test('invalid records and levels are rejected without changing storage', () => {
  const storage = new FakeStorage(); const store = api.createFamiliarityStore({ storage });
  assert.equal(store.setLevel({ id: 1, source: 'MIX' }, 2).reason, 'invalid-record');
  assert.equal(store.setLevel(amq(1), 5).reason, 'invalid-level');
  assert.equal(store.setLevel(amq(''), 2).reason, 'invalid-record');
  assert.equal(storage.getItem('aniCollection_v2'), null);
  store.dispose();
});
test('storage failures roll back the in-memory value and report non-persistence', () => {
  const storage = new FakeStorage({ aniCollection_v2: JSON.stringify({ '1': 1 }) });
  const store = api.createFamiliarityStore({ storage });
  storage.failWrites = true;
  const result = store.setLevel(amq(1), 3);
  assert.equal(result.ok, false);
  assert.equal(result.persisted, false);
  assert.equal(store.getLevel(amq(1)), 1);
  assert.match(result.reason, /quota/);
  store.dispose();
});
test('read failures block writes instead of treating inaccessible existing data as empty', () => {
  const original = JSON.stringify({ '1': 3 });
  const storage = new FakeStorage({ aniCollection_v2: original });
  storage.failReads = true;
  const target = new FakeEventTarget();
  const store = api.createFamiliarityStore({ storage, eventTarget: target });
  assert.equal(store.getPersistenceStatus().AMQ.readBlocked, true);
  const rejected = store.setLevel(amq(2), 1);
  assert.equal(rejected.persisted, false);
  assert.match(rejected.reason, /read denied/);
  assert.equal(storage.values.get('aniCollection_v2'), original);
  storage.failReads = false;
  target.fire('storage', { key: 'aniCollection_v2' });
  assert.equal(store.getPersistenceStatus().AMQ.readBlocked, false);
  assert.equal(store.getLevel(amq(1)), 3);
  assert.equal(store.setLevel(amq(2), 1).persisted, true);
  assert.deepEqual(JSON.parse(storage.getItem('aniCollection_v2')), { '1': 3, '2': 1 });
  store.dispose();
});
test('external read failure is not announced as successful persistence', () => {
  const storage = new FakeStorage({ aniCollection_v2: JSON.stringify({ '1': 3 }) });
  const target = new FakeEventTarget(); const store = api.createFamiliarityStore({ storage, eventTarget: target });
  const updates = []; store.subscribe(event => updates.push(event));
  storage.failReads = true; target.fire('storage', { key: 'aniCollection_v2' });
  assert.equal(store.getLevel(amq(1)), 3, 'last known snapshot is retained');
  assert.equal(store.getPersistenceStatus().AMQ.readBlocked, true);
  assert.equal(updates.at(-1).persisted, false);
  assert.equal(store.getLastWrite().ok, false);
  storage.failReads = false; target.fire('storage', { key: 'aniCollection_v2' });
  assert.equal(updates.at(-1).persisted, true);
  store.dispose();
});

test('storage clear reloads empty AMQ and EMQ maps', () => {
  const storage = new FakeStorage({ aniCollection_v2: JSON.stringify({ '1': 3 }), amqLearningFamiliarityV1: JSON.stringify({ '2': 2 }) });
  const target = new FakeEventTarget(); const store = api.createFamiliarityStore({ storage, eventTarget: target });
  storage.values.clear(); target.fire('storage', { key: null });
  assert.equal(store.getLevel(amq(1)), 0);
  assert.equal(store.getLevel(emq(2)), 0);
  assert.equal(store.getPersistenceStatus().AMQ.readBlocked, false);
  assert.equal(store.getPersistenceStatus().EMQ.readBlocked, false);
  store.dispose();
});

test('storage events refresh cross-tab values and dispose removes the listener', () => {
  const storage = new FakeStorage({ aniCollection_v2: JSON.stringify({ '1': 1 }) });
  const target = new FakeEventTarget(); const store = api.createFamiliarityStore({ storage, eventTarget: target });
  let updates = 0; store.subscribe(() => updates++);
  storage.setItem('aniCollection_v2', JSON.stringify({ '1': 3 }));
  target.fire('storage', { key: 'aniCollection_v2' });
  assert.equal(store.getLevel(amq(1)), 3);
  assert.equal(updates, 1);
  assert.equal(store.dispose(), true);
  target.fire('storage', { key: 'aniCollection_v2' });
  assert.equal(updates, 1);
});

let passed = 0;
for (const item of tests) {
  try { item.fn(); passed++; console.log(`PASS ${item.name}`); }
  catch (error) { console.error(`FAIL ${item.name}\n${error.stack}`); process.exitCode = 1; }
}
console.log(`\nFamiliarity store tests: ${passed}/${tests.length} passed`);
if (passed !== tests.length) process.exitCode = 1;
