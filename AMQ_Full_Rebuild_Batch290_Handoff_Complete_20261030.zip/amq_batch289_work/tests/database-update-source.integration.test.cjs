'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const zlib = require('node:zlib');
const { webcrypto } = require('node:crypto');
const { TextEncoder } = require('node:util');
const root = path.resolve(__dirname, '..');
const window = { crypto: webcrypto, TextEncoder };
const sandbox = { window, TextEncoder, Uint8Array, AbortController, setTimeout, clearTimeout };
vm.createContext(sandbox);
for (const file of ['src/data/assets/data.js', 'src/data/assets/emq-data.js', 'src/data/identity.js', 'src/data/validate.js', 'src/data/audio-candidates.js', 'src/data/source-mappers.js', 'src/data/database-update.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), sandbox, { filename: file, timeout: 30000 });
}
function stableStringify(value) {
  if (value === null || typeof value !== 'object') return JSON.stringify(value);
  if (Array.isArray(value)) return `[${value.map(stableStringify).join(',')}]`;
  return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(',')}}`;
}
(async () => {
  const amq = JSON.parse(JSON.stringify(window.DB));
  const emq = JSON.parse(zlib.gunzipSync(Buffer.from(window.__EMQ_PACKED_B64, 'base64')).toString('utf8'));
  const payload = { schemaVersion: 1, sources: {
    AMQ: { schema: window.AMQData.databaseUpdate.sourceSchemas.AMQ, anime: amq.anime, songs: amq.songs },
    EMQ: { schema: window.AMQData.databaseUpdate.sourceSchemas.EMQ, version: 1, works: emq.works, songs: emq.songs }
  } };
  const checksum = [...new Uint8Array(await webcrypto.subtle.digest('SHA-256', new TextEncoder().encode(stableStringify(payload))))].map(byte => byte.toString(16).padStart(2, '0')).join('');
  const envelope = { format: window.AMQData.databaseUpdate.format, formatVersion: 1, createdAt: new Date().toISOString(), payload, checksum };
  const store = { async getActive() { return null; }, async replaceAtomic() {}, async clearAtomic() {} };
  const manager = window.AMQData.databaseUpdate.createManager({ store, crypto: webcrypto, sourceMappers: window.AMQData.sourceMappers, validator: window.AMQData.validateRecords });
  const result = await manager.preflight(envelope, { compare: false });
  assert.equal(result.ok, true, result.reason);
  assert.deepEqual(JSON.parse(JSON.stringify(result.sourceCounts)), { AMQ: { songs: 38821, works: 9516 }, EMQ: { songs: 16839, works: 6645 } });
  assert.equal(result.normalized.AMQ.length, 38821);
  assert.equal(result.normalized.EMQ.length, 16839);
  console.log('PASS real source package preflight: AMQ 38,821 songs / 9,516 works; EMQ 16,839 songs / 6,645 works');
})().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
