'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const window = {};
const sandbox = { window, console, Date, Math, Object, Array, String, Number, Set, Map, Promise, TypeError, setInterval, clearInterval };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/ui/free-player-dock.js'), 'utf8'), sandbox);
class Element {
  constructor(tag = 'div') { this.tagName = tag.toUpperCase(); this.value = ''; this.textContent = ''; this.disabled = false; this.children = []; this.listeners = new Map(); this.ownerDocument = { createElement: name => new Element(name) }; }
  get firstChild() { return this.children[0] || null; }
  appendChild(child) { this.children.push(child); return child; }
  removeChild(child) { this.children.splice(this.children.indexOf(child), 1); return child; }
  setAttribute(name, value) { this.attributes = this.attributes || {}; this.attributes[name] = String(value); }
  addEventListener(name, fn) { if (!this.listeners.has(name)) this.listeners.set(name, new Set()); this.listeners.get(name).add(fn); }
  removeEventListener(name, fn) { this.listeners.get(name)?.delete(fn); }
  dispatch(name) { for (const fn of [...(this.listeners.get(name) || [])]) fn({ target: this }); }
}
const records = [
  { id: 1, source: 'AMQ', title: 'Song One', artist: 'Singer', animeTitle: 'Work', animeId: 9, audioCandidates: [{ url: 'one', source: 'cdn' }] },
  { id: 2, source: 'EMQ', title: 'Song Two', artist: 'Singer B', animeTitle: 'Game', animeId: 9, audioCandidates: [{ url: 'two', source: 'cdn' }] },
  { id: 3, source: 'AMQ', title: 'No Audio', artist: '', animeTitle: 'Work', audioCandidates: [] }
];
const elementIds = ['dock','search','results','play','pause','stop','random','status','nowPlaying','queue','enqueue','queuePlay','removeQueue','clearQueue','next','previous','mode','volume','mute','collapse','body','progress','time'];
const elements = Object.fromEntries(elementIds.map(key => [key, new Element(['results','queue','mode'].includes(key) ? 'select' : ['volume','progress'].includes(key) ? 'input' : ['play','pause','stop','random','enqueue','removeQueue','clearQueue','next','previous','mute','collapse'].includes(key) ? 'button' : 'div')]));
const stateListeners = new Set();
const stateStore = { getState: () => ({ dataStatus: 'loaded' }), subscribe(fn) { stateListeners.add(fn); return () => stateListeners.delete(fn); } };
const catalog = { size: records.length, search({ offset = 0, limit = 100 } = {}) { return { records: records.slice(offset, offset + limit), total: records.length }; } };
const runtime = { catalogSnapshot: () => catalog };
const audioListeners = new Set();
let audioState = { status: 'idle', sequence: 0 }; let nextSequence = 6; let audioVolume = 1, audioMuted = false, audioCurrentTime = 8;
let now = 0, timerId = 0; const timers = new Map();
const audio = {
  subscribe(fn) { audioListeners.add(fn); return () => audioListeners.delete(fn); },
  getState: () => audioState,
  getPlaybackMetrics: () => ({ available: audioState.status === 'playing' || audioState.status === 'paused', duration: 90, currentTime: audioCurrentTime }),
  setVolume(value) { audioVolume = value; return true; }, setMuted(value) { audioMuted = value; return true; }, seek(value) { audioCurrentTime = value; return true; },
  async play() { audioState = { status: 'playing', sequence: ++nextSequence }; for (const fn of [...audioListeners]) fn(audioState); return { status: 'playing' }; },
  end() { audioState = { status: 'ended', sequence: audioState.sequence }; for (const fn of [...audioListeners]) fn(audioState); },
  fail() { audioState = { status: 'failed', sequence: audioState.sequence, error: 'decode-error' }; for (const fn of [...audioListeners]) fn(audioState); },
  pause() { audioState = { status: 'paused', sequence: 7 }; for (const fn of [...audioListeners]) fn(audioState); return true; },
  stop() { audioState = { status: 'stopped', sequence: 7 }; for (const fn of [...audioListeners]) fn(audioState); return true; },
  dispose() {}
};
const recorded = []; const historyAttempts = []; let failNextHistory = false;
const history = { subscribe() { return () => {}; }, getPersistenceStatus: () => ({ ok: true }), recordPlayback(entry) { historyAttempts.push(entry.id); if (failNextHistory) { failNextHistory = false; return { persisted: false, reason: 'quota exceeded' }; } recorded.push(entry); return { persisted: true }; }, dispose() {} };
let rolledBackAudio = 0;
assert.throws(() => window.AMQUI.freePlayerDock.createFreePlayerDock({ runtime, stateStore,
  audioApi: { createAudioService() { return { dispose() { rolledBackAudio++; } }; } },
  historyApi: { createPlaybackHistoryStore() { throw new Error('history unavailable'); } }
}), /history unavailable/);
assert.equal(rolledBackAudio, 1, 'newly acquired AudioService is disposed if playback history acquisition fails');
const dock = window.AMQUI.freePlayerDock.createFreePlayerDock({ elements, runtime, stateStore, audioService: audio, playbackHistoryStore: history,
  now: () => now, setInterval(fn) { const id = ++timerId; timers.set(id, fn); return id; }, clearInterval(id) { timers.delete(id); } });
(async () => {
  assert.equal(dock.getState().recordCount, 2, 'only songs with audio candidates enter the free player');
  elements.search.value = 'two'; elements.search.dispatch('input');
  assert.equal(elements.results.children.length, 1); assert.match(elements.results.children[0].textContent, /Song Two/);
  await dock.playRecord(records[0]);
  const timer = [...timers.values()][0]; assert.equal(typeof timer, 'function');
  for (let i = 0; i < 19; i++) { now += 250; timer(); }
  assert.equal(recorded.length, 0, 'under five seconds is not recorded');
  now += 250; timer();
  assert.equal(recorded.length, 1, 'actual playing state reaching five seconds records one entry');
  assert.equal(recorded[0].source, 'AMQ'); assert.equal(recorded[0].songId, 1); assert.equal(recorded[0].durationSeconds, 90);
  timer(); assert.equal(recorded.length, 1, 'one audio sequence cannot be counted twice');
  await dock.playRecord(records[1]);
  assert.equal(dock.getState().currentRecord.id, 2, 'replacing playback keeps the selected track and playback identity aligned');
  assert.equal(recorded.length, 1, 'restarting another track does not duplicate the prior history entry');
  assert.match(elements.nowPlaying.textContent, /Song Two/);
  assert.equal(elements.dock.attributes['data-playback-state'], 'playing', 'dock exposes the AudioService playback state for visual styling');
  assert.equal(elements.status.attributes['data-playback-state'], 'playing', 'status pill reflects the active playback state');
  assert.equal(elements.nowPlaying.attributes['data-playback-state'], 'playing', 'current track card reflects the active playback state');
  assert.equal(elements.progress.attributes['aria-valuetext'], '00:08 / 01:30', 'seek progress exposes readable time to assistive technology');
  audioState = { status: 'paused', sequence: audioState.sequence }; for (const fn of [...audioListeners]) fn(audioState);
  assert.equal(elements.dock.attributes['data-playback-state'], 'paused', 'paused state is projected to the dock without duplicate playback state');
  audio.fail(); assert.equal(elements.dock.attributes['data-playback-state'], 'failed', 'failure state is visually distinguishable');
  await dock.playRecord(records[1]); assert.equal(elements.dock.attributes['data-playback-state'], 'playing', 'a later successful playback clears the visual failure state');
  assert.equal(dock.getState().queueCount, 2, 'direct playback places tracks in the queue without duplicating identities');
  assert.equal(dock.enqueueRecord(records[1]).added, false, 'enqueue is idempotent for the same source-aware track');
  assert.equal(dock.setPlayMode('loop'), true); assert.equal(dock.getState().playMode, 'loop');
  assert.equal(dock.playNext(), true); assert.equal(dock.getState().currentRecord.id, 1, 'loop mode wraps from the final queue item');
  assert.equal(dock.playPrevious(), true); assert.equal(dock.getState().currentRecord.id, 2, 'previous follows actual queue play history');
  audio.end(); await Promise.resolve(); await Promise.resolve();
  assert.equal(dock.getState().currentRecord.id, 1, 'natural end automatically advances according to the selected play mode');
  assert.equal(dock.setPlayMode('shuffle'), true); assert.equal(dock.playNext(), true); assert.equal(dock.getState().currentRecord.id, 2, 'shuffle mode selects a different queue item when possible');
  assert.equal(dock.setPlayMode('sequential'), true);
  assert.equal(dock.playNext(), false, 'sequential mode does not wrap at the end of the queue');
  assert.equal(dock.setPlayMode('loop'), true); assert.equal(dock.playNext(), true); assert.equal(dock.getState().currentRecord.id, 1, 'loop mode wraps to the first item');
  elements.volume.value = '0.4'; elements.volume.dispatch('input'); assert.equal(dock.getState().volume, 0.4); assert.equal(audioVolume, 0.4);
  elements.mute.dispatch('click'); assert.equal(dock.getState().muted, true); assert.equal(audioMuted, true);
  elements.progress.value = '500'; elements.progress.dispatch('change'); assert.equal(audioCurrentTime, 45, 'progress slider seeks through the AudioService owner');
  elements.collapse.dispatch('click'); assert.equal(dock.getState().collapsed, true); assert.equal(elements.body.hidden, true);
  assert.equal(dock.removeQueueItem(0), true); assert.equal(dock.getState().queueCount, 1);
  dock.clearQueue(); assert.equal(dock.getState().queueCount, 0); assert.equal(dock.getState().currentRecord, null);
  const firstHistoryId = recorded[0].id;
  assert.equal(dock.dispose(), true); assert.equal(dock.dispose(), false); assert.equal(timers.size, 0);
  const dock2 = window.AMQUI.freePlayerDock.createFreePlayerDock({ elements, runtime, stateStore, audioService: audio, playbackHistoryStore: history,
    now: () => now, setInterval(fn) { const id = ++timerId; timers.set(id, fn); return id; }, clearInterval(id) { timers.delete(id); } });
  await dock2.playRecord(records[0]);
  const timer2 = [...timers.values()][0]; failNextHistory = true;
  for (let i = 0; i < 21; i++) { now += 250; timer2(); }
  assert.equal(recorded.length, 2, 'a new dock lifetime can record the same track again after a transient storage failure');
  assert.notEqual(recorded[1].id, firstHistoryId, 'history IDs remain unique across dock remounts');
  assert.equal(historyAttempts[historyAttempts.length - 1], historyAttempts[historyAttempts.length - 2], 'history retry reuses the same id for one audio sequence');
  dock2.dispose(); assert.equal(timers.size, 0);
  console.log('Free player dock tests: queue, playback controls and history identity PASS');
})().catch(error => { console.error(error); process.exitCode = 1; });
