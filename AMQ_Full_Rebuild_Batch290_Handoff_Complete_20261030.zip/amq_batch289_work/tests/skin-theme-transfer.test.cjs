'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
function setup() {
  const window = { Blob, btoa, atob, Date, Object, Array, Set, String, Number, RegExp, Error, Math, JSON, Uint8Array };
  window.AMQSkins = {};
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/skins/skin-resolver.js'), 'utf8'), { window, Object, Array, Set, Number, String, RegExp, TypeError, RangeError });
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, '../src/skins/theme-transfer.js'), 'utf8'), { window, Blob, btoa, atob, Date, Object, Array, Set, String, Number, RegExp, Error, Math, JSON, Uint8Array });
  return window.AMQSkins.themeTransfer;
}
function sample(overrides = {}) {
  return { schemaVersion: 1, enabled: true, metadata: { name: 'Skin Test', author: 'Local', version: '1' },
    mappings: { background: 'menu/menu-background.png', selectionFrame: 'selection-bar.png', characterOverlay: null }, roleMappings: { 'app.home.background': 'menu/menu-background.png', 'catalog.item.selected': 'selection-bar.png' }, skinIniText: '[General]\nName: Skin Test', accentColors: ['#123456'], motionPreference: 'reduce', overrides: { regions: { home: { padding: 22, opacity: 0.8 } }, components: { 'catalog.item.selected': { borderRadius: 7 } } },
    assets: [{ path: 'menu/menu-background.png', name: 'menu-background.png', extension: 'png', mime: 'image/png', blob: new Blob([new Uint8Array([0, 1, 2, 255])], { type: 'image/png' }) },
      { path: 'selection-bar.png', name: 'selection-bar.png', extension: 'png', mime: 'image/png', blob: new Blob([new Uint8Array([3, 4, 5])], { type: 'image/png' }) },
      { path: 'hitnormal.wav', name: 'hitnormal.wav', extension: 'wav', mime: 'audio/wav', blob: new Blob([new Uint8Array([6, 7])], { type: 'audio/wav' }) }], ...overrides };
}
test('portable theme export/import round-trips metadata, mappings, and binary assets', async () => {
  const api = setup();
  const exported = await api.exportTheme(sample());
  const bundle = JSON.parse(exported);
  assert.equal(bundle.format, 'amq-skin-theme');
  assert.match(bundle.notice, /著作權|授權/);
  const restored = await api.importTheme(exported);
  assert.equal(restored.metadata.name, 'Skin Test');
  assert.equal(restored.mappings.background, 'menu/menu-background.png');
  assert.equal(restored.motionPreference, 'reduce');
  assert.equal(restored.roleMappings['catalog.item.selected'], 'selection-bar.png');
  assert.equal(restored.skinIniText, '[General]\nName: Skin Test');
  assert.equal(restored.overrides.regions.home.padding, 22);
  assert.equal(restored.overrides.components['catalog.item.selected'].borderRadius, 7);
  assert.equal(restored.assets.some(asset => asset.path === 'hitnormal.wav' && asset.extension === 'wav'), true);
  assert.deepEqual(Array.from(new Uint8Array(await restored.assets[0].blob.arrayBuffer())), [0, 1, 2, 255]);
});
test('import rejects unknown format/version, path traversal, and dangling mappings', async () => {
  const api = setup();
  await assert.rejects(api.importTheme('{"format":"other","formatVersion":1}'), { code: 'THEME_TRANSFER_UNSUPPORTED_VERSION' });
  const badPath = JSON.parse(await api.exportTheme(sample())); badPath.theme.assets[0].path = '../escape.png';
  await assert.rejects(api.importTheme(JSON.stringify(badPath)), { code: 'THEME_TRANSFER_INVALID_PATH' });
  const badMapping = JSON.parse(await api.exportTheme(sample())); badMapping.theme.mappings.background = 'missing.png';
  await assert.rejects(api.importTheme(JSON.stringify(badMapping)), { code: 'THEME_TRANSFER_INVALID_MAPPING' });
});
test('import rejects invalid base64 and excessive asset counts', async () => {
  const api = setup();
  const invalid = JSON.parse(await api.exportTheme(sample())); invalid.theme.assets[0].dataBase64 = 'not base64!';
  await assert.rejects(api.importTheme(JSON.stringify(invalid)), { code: 'THEME_TRANSFER_ASSET_INVALID' });
  assert.throws(() => api.validateTheme({ schemaVersion: 1, assets: Array.from({ length: 5001 }, (_, i) => ({ path: `${i}.png`, extension: 'png', blob: new Blob(['x']) })) }, true), { code: 'THEME_TRANSFER_INVALID_SCHEMA' });
});
test('import rejects unsupported asset extensions and malformed schema', async () => {
  const api = setup();
  const unsupported = JSON.parse(await api.exportTheme(sample())); unsupported.theme.assets[0].extension = 'exe';
  await assert.rejects(api.importTheme(JSON.stringify(unsupported)), { code: 'THEME_TRANSFER_UNSUPPORTED_ASSET' });
  await assert.rejects(api.importTheme('{broken'), { code: 'THEME_TRANSFER_INVALID_JSON' });
});

test('portable transfer rejects malformed override schema and strips unsafe properties', async () => {
  const api = setup();
  const payload = JSON.parse(await api.exportTheme(sample()));
  payload.theme.overrides = { regions: { home: { backgroundImage: 'url(javascript:alert(1))', padding: 18 } }, components: {} };
  const restored = await api.importTheme(JSON.stringify(payload));
  assert.equal(restored.overrides.regions.home.padding, 18);
  assert.equal(restored.overrides.regions.home.backgroundImage, undefined);
  payload.theme.overrides = 'not-an-object';
  await assert.rejects(api.importTheme(JSON.stringify(payload)), { code: 'THEME_TRANSFER_INVALID_OVERRIDES' });
});

test('portable transfer round-trips explicit normal/hover pairs and validates both assets', async () => {
  const api = setup();
  const source = sample();
  source.roleStateMappings = { 'app.navigation.back': { normal: 'menu/menu-background.png', hover: 'selection-bar.png', fit: 'contain', position: 'top left' } };
  const restored = await api.importTheme(await api.exportTheme(source));
  assert.deepEqual(JSON.parse(JSON.stringify(restored.roleStateMappings)), { 'app.navigation.back': { normal: 'menu/menu-background.png', hover: 'selection-bar.png', fit: 'contain', position: 'top left' } });
  const malformed = JSON.parse(await api.exportTheme(source));
  malformed.theme.roleStateMappings['app.navigation.back'].hover = 'missing.png';
  await assert.rejects(api.importTheme(JSON.stringify(malformed)), { code: 'THEME_TRANSFER_INVALID_MAPPING' });
});

test('portable transfer rejects mapping counts above limits instead of silently truncating imported choices', () => {
  const api = setup();
  const roleMappings = Object.fromEntries(Array.from({ length: 501 }, (_, index) => [`role-${index}`, null]));
  const roleStateMappings = Object.fromEntries(Array.from({ length: 101 }, (_, index) => [`role-${index}`, { normal: null, hover: null }]));
  const base = { schemaVersion: 1, assets: [], mappings: {} };
  assert.throws(() => api.validateTheme({ ...base, roleMappings }, false), { code: 'THEME_TRANSFER_INVALID_SCHEMA' });
  assert.throws(() => api.validateTheme({ ...base, roleStateMappings }, false), { code: 'THEME_TRANSFER_INVALID_SCHEMA' });
});
