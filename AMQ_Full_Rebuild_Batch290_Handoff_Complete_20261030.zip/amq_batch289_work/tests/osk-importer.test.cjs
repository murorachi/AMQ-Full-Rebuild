const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const zlib = require('node:zlib');
const root = path.resolve(__dirname, '..');
const sandbox = { window: {}, ArrayBuffer, DataView, Uint8Array, TextDecoder, Blob, Response, DecompressionStream, escape, decodeURIComponent };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/skins/osk-importer.js'), 'utf8'), sandbox, { filename: 'src/skins/osk-importer.js' });
const importer = sandbox.window.AMQSkins.oskImporter;
function zip(files, method = 8) {
  const local = [], central = [];
  let offset = 0;
  for (const [name, text] of Object.entries(files)) {
    const nameBytes = Buffer.from(name);
    const plain = Buffer.isBuffer(text) ? text : Buffer.from(text);
    const packed = method === 8 ? zlib.deflateRawSync(plain) : plain;
    const localHeader = Buffer.alloc(30);
    localHeader.writeUInt32LE(0x04034b50, 0); localHeader.writeUInt16LE(20, 4); localHeader.writeUInt16LE(0, 6);
    localHeader.writeUInt16LE(method, 8); localHeader.writeUInt32LE(0, 14); localHeader.writeUInt32LE(packed.length, 18); localHeader.writeUInt32LE(plain.length, 22);
    localHeader.writeUInt16LE(nameBytes.length, 26); localHeader.writeUInt16LE(0, 28);
    local.push(localHeader, nameBytes, packed);
    const centralHeader = Buffer.alloc(46);
    centralHeader.writeUInt32LE(0x02014b50, 0); centralHeader.writeUInt16LE(20, 4); centralHeader.writeUInt16LE(20, 6);
    centralHeader.writeUInt16LE(0, 8); centralHeader.writeUInt16LE(method, 10); centralHeader.writeUInt32LE(0, 16);
    centralHeader.writeUInt32LE(packed.length, 20); centralHeader.writeUInt32LE(plain.length, 24); centralHeader.writeUInt16LE(nameBytes.length, 28);
    centralHeader.writeUInt32LE(offset, 42);
    central.push(centralHeader, nameBytes);
    offset += localHeader.length + nameBytes.length + packed.length;
  }
  const centralBytes = Buffer.concat(central);
  const localBytes = Buffer.concat(local);
  const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(Object.keys(files).length, 8); end.writeUInt16LE(Object.keys(files).length, 10);
  end.writeUInt32LE(centralBytes.length, 12); end.writeUInt32LE(localBytes.length, 16);
  return Buffer.concat([localBytes, centralBytes, end]);
}
async function read(buffer) { return importer.read(buffer, { inflateRaw: bytes => zlib.inflateRawSync(Buffer.from(bytes)) }); }
(async () => {
  let passed = 0;
  async function test(name, fn) { try { await fn(); passed++; console.log(`PASS ${name}`); } catch (error) { console.error(`FAIL ${name}\n${error.stack}`); process.exitCode = 1; } }
  await test('reads deflated .osk entries and parses skin.ini metadata', async () => {
    const parsed = await read(zip({ 'skin.ini': '[General]\nName: Night Theme\nAuthor: Example\nVersion: 2.5\n[Colours]\nCombo1: 12, 34, 56', 'menu-background.jpg': 'imagebytes', 'selection-bar.png': 'framebytes', 'hitnormal.wav': 'soundbytes', 'folder/readme.txt': 'ignore' }));
    assert.equal(parsed.metadata.name, 'Night Theme'); assert.equal(parsed.metadata.author, 'Example'); assert.equal(parsed.metadata.version, '2.5');
    assert.equal(parsed.metadata.colors.combo1, 'rgb(12, 34, 56)'); assert.equal(parsed.imageCount, 2); assert.equal(parsed.soundCount, 1); assert.equal(parsed.entries.some(entry => entry.name === 'hitnormal.wav'), true); assert.match(parsed.skinIniText, /Name: Night Theme/); assert.equal(parsed.metadata.sections.general.Name, 'Night Theme');
    assert.equal(parsed.mappings.background.path, 'menu-background.jpg'); assert.equal(parsed.mappings.selectionBar.path, 'selection-bar.png');
    assert.equal(parsed.entries.some(entry => entry.name === 'readme.txt'), false);
  });
  await test('reads stored ZIP entries without compression', async () => {
    const parsed = await read(zip({ 'skin.ini': '[General]\nName: Stored', 'songselect-top.png': 'top' }, 0));
    assert.equal(parsed.metadata.name, 'Stored'); assert.equal(parsed.mappings.songSelectTop.name, 'songselect-top.png');
  });
  await test('ignores path traversal and absolute archive paths', async () => {
    const parsed = await read(zip({ '../evil.png': 'bad', '/root.png': 'bad', 'skin.ini': '[General]\nName: Safe', 'good.png': 'ok' }, 0));
    assert.equal(Array.from(parsed.entries, entry => entry.path).join(','), 'skin.ini,good.png');
  });
  await test('rejects non-ZIP and missing supported assets', async () => {
    await assert.rejects(() => importer.read(new Uint8Array([1,2,3])), error => error.code === 'OSK_INVALID_ZIP');
    await assert.rejects(() => read(zip({ 'readme.txt': 'nothing supported' }, 0)), error => error.code === 'OSK_NO_SUPPORTED_ASSETS');
  });
  await test('rejects entry count inconsistent with ZIP central directory', async () => {
    const broken = zip({ 'skin.ini': '[General]\nName: Broken' }); const eocd = broken.lastIndexOf(Buffer.from([0x50,0x4b,0x05,0x06])); broken[eocd + 8] = 2;
    await assert.rejects(() => read(broken), error => ['OSK_INVALID_CENTRAL_DIRECTORY','OSK_ENTRY_LIMIT','OSK_ZIP64_OR_MULTIDISK'].includes(error.code));
  });
  await test('decodes skin.ini with UTF-16LE BOM', async () => {
    const ini = Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from('[General]\nName: UTF16 Skin', 'utf16le')]);
    const parsed = await read(zip({ 'skin.ini': ini }, 0));
    assert.equal(parsed.metadata.name, 'UTF16 Skin');
  });
  await test('decodes skin.ini with UTF-16BE BOM', async () => {
    const ini = Buffer.concat([Buffer.from([0xfe, 0xff]), Buffer.from('[General]\nName: UTF16BE Skin', 'utf16le').swap16()]);
    const parsed = await read(zip({ 'skin.ini': ini }, 0));
    assert.equal(parsed.metadata.name, 'UTF16BE Skin');
  });
  await test('falls back to Windows-1252 when UTF-8 has replacement characters', async () => {
    const ini = Buffer.concat([Buffer.from('[General]\nName: Caf'), Buffer.from([0xe9]), Buffer.from(' Skin')]);
    const parsed = await read(zip({ 'skin.ini': ini }, 0));
    assert.equal(parsed.metadata.name, 'Café Skin');
  });
  await test('central role catalog selects frame and character candidates consistently', async () => {
    const parsed = await read(zip({ 'skin.ini': '[General]\nName: Catalog', 'selection-bar.png': 'frame', 'songselect-top.png': 'top', 'character-front.png': 'character', 'other.png': 'other' }, 0));
    assert.deepEqual(Array.from(importer.candidatesForRole(parsed.entries, 'selectionFrame'), entry => entry.name).sort(), ['selection-bar.png', 'songselect-top.png']);
    assert.deepEqual(Array.from(importer.candidatesForRole(parsed.entries, 'characterOverlay'), entry => entry.name), ['character-front.png']);
  });
  await test('preserves repeated Mania sections and audits missing references without rejecting partial skins', async () => {
    const parsed = await read(zip({ 'skin.ini': '[General]\nName: Partial\nVersion: latest\n[Mania]\nKeys: 4\nNoteImage0: mania/arrows/left@2x\nKeyImage0: _blank\n[Mania]\nKeys: 7\nNoteImage0: mania/arrows/left\nNoteImage1: mania/arrows/right@2x', 'mania/arrows/left.png': 'left' }, 0));
    assert.equal(parsed.metadata.sectionBlocks.filter(block => block.name === 'mania').length, 2);
    assert.equal(parsed.referenceAudit.checked, 3);
    assert.equal(parsed.referenceAudit.resolved, 1);
    assert.equal(parsed.referenceAudit.missing.length, 2);
    assert.equal(parsed.referenceAudit.missing.some(item => item.status === 'missing-hd-reference'), true);
  });
  await test('maps current selection-mode filename and legacy osu suffix', async () => {
    const current = await read(zip({ 'skin.ini': '[General]\nName: Current', 'selection-mode.png': 'mode' }, 0));
    assert.equal(current.mappings.selectionMode.name, 'selection-mode.png');
    const legacy = await read(zip({ 'skin.ini': '[General]\nName: Legacy', 'selection-mode-osu.png': 'mode' }, 0));
    assert.equal(legacy.mappings.selectionMode.name, 'selection-mode-osu.png');
  });
  await test('rejects decompressor output larger than declared entry size', async () => {
    const archive = zip({ 'skin.ini': '[General]\nName: Size Guard' });
    await assert.rejects(() => importer.read(archive, { inflateRaw: () => Buffer.alloc(999) }), error => error.code === 'OSK_DECOMPRESSED_SIZE_LIMIT');
  });
  console.log(`\nOSK importer tests: ${passed}/12 passed.`);
  if (passed !== 12) process.exitCode = 1;
})();

