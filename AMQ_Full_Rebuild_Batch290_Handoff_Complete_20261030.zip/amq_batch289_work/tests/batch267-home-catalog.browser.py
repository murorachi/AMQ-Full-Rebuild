#!/usr/bin/env python3
"""Batch267 Home/Catalog density and responsive visual acceptance checks."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'src'; OUT=ROOT/'artifacts'/'batch267-home-catalog'; OUT.mkdir(parents=True,exist_ok=True)
html=(SRC/'index.html').read_text(encoding='utf-8')
def css(m): return '<style>'+ (SRC/m.group(1)).read_text(encoding='utf-8')+'</style>'
def js(m): return '<script>'+ (SRC/m.group(1)).read_text(encoding='utf-8')+'</script>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)">',css,html)
html=re.sub(r'<script src="([^"]+)"></script>', '', html)
# Keep the real app-shell owner while omitting the heavyweight data/runtime bundles;
# this is a DOM/CSS layout fixture, not a live data acceptance test.
html=html.replace('</body>', '<script>'+ (SRC/'ui'/'app-shell.js').read_text(encoding='utf-8') + '</script></body>')
checks=0; failures=[]
def check(ok,label):
 global checks
 checks+=1
 if ok: print('PASS',label)
 else: failures.append(label); print('FAIL',label)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h,name in [(1920,1080,'1920x1080'),(1440,900,'1440x900'),(1024,768,'1024x768'),(390,844,'390x844')]:
  page=browser.new_page(viewport={'width':w,'height':h}); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=60000); page.wait_for_timeout(100)
  page.screenshot(path=str(OUT/f'home-{name}.png'),full_page=True)
  home_metrics=page.evaluate('''() => ({hero:Math.round(document.querySelector("#page-home .home-feature").getBoundingClientRect().height),actions:[...document.querySelectorAll("#page-home .home-main-action")].map(x=>Math.round(x.getBoundingClientRect().height)),recent:Math.round(document.querySelector("#page-home .home-recent").getBoundingClientRect().height),artMark:Math.round(document.querySelector("#home-feature-art > span").getBoundingClientRect().width)})''')
  check(len(home_metrics['actions'])==6 and max(home_metrics['actions'])<=100,f'home destinations use compact controls at {name}: {home_metrics["actions"]}')
  check(home_metrics['artMark']<=100,f'empty Home artwork fallback is restrained rather than oversized at {name}: {home_metrics["artMark"]}')
  check(page.locator('#page-home').is_visible(),f'Home route visible at {name}')
  check(page.locator('#page-home .home-main-action').count()==6,f'six main destinations are directly visible at {name}')
  check(page.locator('#home-pie, #home-pie-core, .home-footer-note').count()==0,f'old pie menu and explanatory note removed at {name}')
  check(page.locator('#page-home .eyebrow').count()==0,f'editorial eyebrow labels absent on Home at {name}')
  check(page.locator('#home-feature-mark, #home-pie, #home-pie-core').count()==0,f'abstract brand mark and old pie components absent at {name}')
  check(page.locator('#home-feature-art').count()==1 and page.locator('#home-recent-list').count()==1,f'artwork and playback-history owners mounted at {name}')
  m=page.evaluate('({width:document.documentElement.scrollWidth,height:document.documentElement.scrollHeight,iw:innerWidth,ih:innerHeight})')
  check(m['width']<=w,f'no horizontal overflow at {name}')
  if w>=1024: check(m['height']<=h,f'no whole-page vertical overflow at {name}')
  page.locator('[data-nav-page="catalog"]').click(); page.wait_for_timeout(20)
  page.screenshot(path=str(OUT/f'catalog-opaque-origin-error-{name}.png'),full_page=True)
  # A separately named, deterministic data fixture for layout review only. This does not
  # claim the production catalog/IndexedDB successfully loaded in this opaque origin.
  page.evaluate("""() => {
    const root = document.querySelector('#catalog-browser');
    if (root && !root.querySelector('.catalog-workspace')) {
      const heading = root.querySelector('.catalog-title-row');
      const workspace = document.createElement('div'); workspace.className = 'catalog-workspace';
      workspace.dataset.catalogLayout = 'osu-stable-inspired';
      const sidebar = document.createElement('aside'); sidebar.className = 'catalog-sidebar'; sidebar.setAttribute('aria-label','曲庫搜尋、篩選與管理');
      const center = document.createElement('section'); center.className = 'catalog-main-list'; center.setAttribute('aria-label','歌曲列表');
      const detail = document.createElement('aside'); detail.className = 'catalog-detail-column'; detail.setAttribute('aria-label','目前選取歌曲資訊');
      if (heading) heading.after(workspace); else root.append(workspace);
      workspace.append(sidebar,center,detail);
      const move=(selector,parent)=>{const node=root.querySelector(selector);if(node)parent.append(node);return node;};
      const disclosure=(selectors,title)=>{const nodes=selectors.map(q=>root.querySelector(q)).filter(Boolean);if(!nodes.length)return;const d=document.createElement('details');d.className='catalog-management-group';const summary=document.createElement('summary');summary.textContent=title;d.append(summary);nodes.forEach(n=>d.append(n));sidebar.append(d);};
      move('.catalog-primary-controls',sidebar); move('#catalog-advanced-filters',sidebar);
      disclosure(['.catalog-presets-controls','#catalog-filter-preset-status'],'篩選預設');
      disclosure(['.catalog-tags-controls','#catalog-tag-status'],'歌曲標籤');
      disclosure(['.catalog-batch-controls','#catalog-batch-status'],'批次操作');
      disclosure(['.personal-library'],'個人作品清單');
      move('.catalog-summary-row',center); move('#catalog-error',center);
      const oldLayout=root.querySelector('.catalog-select-layout');
      if(oldLayout){const list=oldLayout.querySelector('.catalog-list-wrap');if(list)center.append(list);}
      const details=root.querySelector('#catalog-selection-details');if(details)detail.append(details);
      move('.pagination',center); if(oldLayout)oldLayout.remove();
      const mode=document.querySelector('#catalog-mode-selector');if(mode)sidebar.prepend(mode);
    }
  }""")
  page.evaluate("""() => {
    const root = document.querySelector('#catalog-browser');
    const rows = document.querySelector('#catalog-rows');
    const empty = document.querySelector('#catalog-empty');
    const detail = document.querySelector('#catalog-selection-content');
    if (!root || !rows || !empty) return false;
    const fixture = [
      ['青い栞','Galileo Galilei','あの日見た花の名前を僕達はまだ知らない。','OP','AMQ'],
      ['君の知らない物語','supercell','化物語','ED','AMQ'],
      ['紅蓮の弓矢','Linked Horizon','進撃の巨人','OP','AMQ'],
      ['残酷な天使のテーゼ','高橋洋子','新世紀エヴァンゲリオン','OP','AMQ'],
      ['鳥の詩','Lia','AIR','OP','AMQ'],
      ['千の刃濤、桃花染の皇姫','AUGUST','千の刃濤、桃花染の皇姫','GAME','EMQ']
    ];
    const svg = (i) => 'data:image/svg+xml,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="96" height="128"><defs><linearGradient id="g" x2="1" y2="1"><stop stop-color="${['#8b4d78','#416a91','#b64c55','#6a6396','#407e75','#9b7547'][i]}"/><stop offset="1" stop-color="#171820"/></linearGradient></defs><rect width="96" height="128" fill="url(#g)"/><circle cx="48" cy="42" r="24" fill="#ffffff" fill-opacity=".18"/><path d="M0 100L96 42V128H0Z" fill="#ffffff" fill-opacity=".12"/></svg>`);
    rows.replaceChildren();
    fixture.forEach((record, i) => {
      const tr = document.createElement('tr'); tr.tabIndex = 0; tr.setAttribute('aria-selected', String(i === 0));
      record.forEach((value, col) => {
        const td = document.createElement('td');
        if (col === 0) {
          td.className = 'catalog-title-cell catalog-title-cell--artwork';
          const art = document.createElement('span'); art.className = 'catalog-artwork'; art.dataset.artworkStatus = 'available';
          const img = document.createElement('img'); img.className = 'catalog-artwork-image'; img.alt = ''; img.src = svg(i); art.append(img);
          const title = document.createElement('span'); title.className = 'catalog-song-title'; title.textContent = value;
          td.append(art, title);
        } else td.textContent = value;
        tr.append(td);
      });
      rows.append(tr);
    });
    empty.hidden = true; root.dataset.catalogState = 'ready';
    const error = document.querySelector('#catalog-error'); if (error) { error.hidden = true; error.textContent = ''; }
    const summary = document.querySelector('#catalog-summary'); if (summary) summary.textContent = '6 首歌曲';
    const appStatus = document.querySelector('#app-status'); if (appStatus) appStatus.textContent = '曲庫已載入';
    const dataState = document.querySelector('#data-state'); if (dataState) dataState.textContent = '已載入';
    const modeStatus = document.querySelector('#catalog-status'); if (modeStatus) { modeStatus.textContent = '曲庫已載入'; modeStatus.dataset.status = 'ready'; }
    document.querySelectorAll('#catalog-browser [role=alert], #catalog-browser [data-error-code]').forEach(el => { el.hidden = true; el.style.display = 'none'; });
    document.querySelectorAll('#catalog-browser .catalog-sidebar .notice').forEach(el => { if (/DATA_SOURCE_READ_FAILED|無法讀取曲庫來源/.test(el.textContent)) { el.hidden = true; el.style.display = 'none'; } });
    if (detail) { detail.hidden = false; detail.replaceChildren(); const h = document.createElement('h3'); h.textContent = '青い栞'; const img = document.createElement('img'); img.src = svg(0); img.alt = ''; img.style.cssText = 'width:100%;max-height:220px;object-fit:cover;margin:.5rem 0'; const p = document.createElement('p'); p.textContent = 'あの日見た花の名前を僕達はまだ知らない。'; detail.append(h,img,p); }
    const selectionEmpty = document.querySelector('#catalog-selection-empty'); if (selectionEmpty) selectionEmpty.hidden = true;
    return true;
  }""")
  page.wait_for_timeout(20)
  page.screenshot(path=str(OUT/f'catalog-data-fixture-{name}.png'),full_page=True)
  catalog_metrics=page.evaluate('''() => ({row:Math.round(document.querySelector("#catalog-rows tr").getBoundingClientRect().height),art:(()=>{const r=document.querySelector("#catalog-rows .catalog-artwork").getBoundingClientRect();return {w:Math.round(r.width),h:Math.round(r.height)}})(),columns:getComputedStyle(document.querySelector(".catalog-workspace")).gridTemplateColumns})''')
  check(50<=catalog_metrics['row']<=78,f'catalog rows use dense client-style rhythm at {name}: {catalog_metrics["row"]}')
  check(catalog_metrics['art']['w']<=44 and catalog_metrics['art']['h']<=56,f'catalog cover thumbnails do not dominate rows at {name}: {catalog_metrics["art"]}')
  check(page.locator('.catalog-workspace > .catalog-sidebar #catalog-query').count()==1,f'catalog filter is in left sidebar at {name}')
  check(page.locator('.catalog-workspace > .catalog-main-list #catalog-rows').count()==1,f'catalog rows remain in center list at {name}')
  check(page.locator('.catalog-workspace > .catalog-detail-column #catalog-selection-details').count()==1,f'selected song details remain in right panel at {name}')
  check(not errors,f'no browser exceptions at {name}: {errors}')
  page.close()
 browser.close()
print(f'Batch267 Home/Catalog visual checks: {checks-len(failures)}/{checks} PASS')
if failures: raise SystemExit(1)
