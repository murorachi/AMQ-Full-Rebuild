#!/usr/bin/env python3
"""Batch285 route-grid and Quiz UI regression, grounded in osu! Stable reference review.
Uses production DOM/CSS and app-shell route owner; no fake rooms, users, scores or questions."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]; SRC=ROOT/'src'; OUT=ROOT/'artifacts'/'batch285-quiz-route-ui'; OUT.mkdir(parents=True,exist_ok=True)
html=(SRC/'index.html').read_text(encoding='utf-8')
def css(m):
    content=(SRC/m.group(1)).read_text(encoding='utf-8')
    return '<style>\n'+content+'\n</style>'
html=re.sub(r'<link rel="stylesheet" href="([^"]+)"\s*/?>',css,html)
html=re.sub(r'<script src="[^"]+"></script>', '', html)
html=html.replace('</body>', '<script>\n'+(SRC/'ui'/'app-shell.js').read_text(encoding='utf-8')+'\n</script></body>')
checks=0; failures=[]
def check(ok,label):
 global checks
 checks+=1
 print(('PASS ' if ok else 'FAIL ')+label)
 if not ok: failures.append(label)
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for w,h,name in [(1920,1080,'1920x1080'),(1440,900,'1440x900'),(1024,768,'1024x768'),(390,844,'390x844')]:
  page=browser.new_page(viewport={'width':w,'height':h}); errors=[]; page.on('pageerror',lambda e:errors.append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=60000); page.wait_for_timeout(80)
  page.locator('.home-main-action[data-go-page="quiz"]').click(); page.wait_for_timeout(30)
  check(page.locator('#quiz-panel').is_visible(),f'{name}: Quiz route visible')
  shell=page.evaluate('''() => ({bodyColumns:getComputedStyle(document.body).gridTemplateColumns.split(' ').length,mainX:Math.round(document.querySelector('main').getBoundingClientRect().x),mainWidth:Math.round(document.querySelector('main').getBoundingClientRect().width),viewport:innerWidth,pageWidth:Math.round(document.querySelector('#page-quiz').getBoundingClientRect().width)})''')
  check(shell['bodyColumns']==1 and shell['mainX']==0 and shell['mainWidth']==w,f'{name}: feature route occupies the full viewport rather than a split body grid')
  check(shell['pageWidth']>=w-2,f'{name}: Quiz workspace uses available width')
  check(page.locator('.app-header').is_hidden() and page.locator('#app-shell-nav #app-status').is_visible(),f'{name}: redundant global header is removed and app status stays in route bar')
  page.locator('#quiz-answer').focus()
  shortcut=page.evaluate('''() => {const input=document.querySelector('#quiz-answer'),event=new KeyboardEvent('keydown',{key:'ArrowLeft',altKey:true,bubbles:true,cancelable:true});input.dispatchEvent(event);return {page:document.body.dataset.currentPage,prevented:event.defaultPrevented}}''')
  check(shortcut['page']=='quiz' and not shortcut['prevented'],f'{name}: browser-back shortcut does not hijack answer editing')
  setup=page.locator('#quiz-panel > .quiz-setup-section')
  check(not setup.evaluate('(e)=>e.open'),f'{name}: Quiz settings are collapsed by default to protect the game stage')
  page.locator('#quiz-panel > .quiz-setup-section > summary').click()
  check(setup.evaluate('(e)=>e.open') and page.locator('#quiz-target').is_visible(),f'{name}: setup disclosure opens the real settings controls')
  page.locator('#quiz-panel > .quiz-setup-section > summary').click()
  check(not setup.evaluate('(e)=>e.open'),f'{name}: setup disclosure closes without replacing the settings owner')
  check(page.locator('#quiz-question-title').is_visible() and page.locator('#quiz-answer').is_visible(),f'{name}: quiz prompt and answer owner visible')
  q=page.evaluate('''() => {const root=document.querySelector('#quiz-panel'),stage=root.querySelector('.quiz-question-card'),answer=root.querySelector('.quiz-answer-form');return {scrollWidth:document.documentElement.scrollWidth,innerWidth,stageHeight:Math.round(stage.getBoundingClientRect().height),answerHeight:Math.round(answer.getBoundingClientRect().height),focus:getComputedStyle(root.querySelector('#quiz-question-title')).fontSize,setup:root.querySelector('.quiz-setup-section').getBoundingClientRect().top,round:root.querySelector('.quiz-round-section').getBoundingClientRect().top}}''')
  check(q['scrollWidth']<=w+1,f'{name}: Quiz no horizontal overflow')
  check(q['round']<q['setup'],f'{name}: live round stays ahead of setup')
  if w>=1024: check(q['stageHeight']>=220,f'{name}: quiz stage retains visual priority')
  page.locator('#quiz-panel').screenshot(path=str(OUT/f'quiz-panel-{name}.jpg'),type='jpeg',quality=82)
  page.screenshot(path=str(OUT/f'quiz-{name}.jpg'),full_page=True,type='jpeg',quality=82)
  page.locator('[data-nav-page="catalog"]').click(); page.wait_for_timeout(20)
  page.locator('[data-nav-page="quiz"]').click(force=True); page.wait_for_timeout(20)
  check(page.locator('#multiplayer-panel').is_visible(),f'{name}: multiplayer panel visible on Quiz route')
  check(page.locator('#multiplayer-mode-tabs [data-room-source]').count()==4,f'{name}: source filters retained')
  check(page.locator('#multiplayer-room-search').is_visible() and page.locator('#multiplayer-create').is_visible(),f'{name}: room search and create controls retained')
  room=page.evaluate('''() => {const p=document.querySelector('#multiplayer-panel'),s=document.querySelector('#multiplayer-rooms');return {doc:document.documentElement.scrollWidth,innerWidth,roomHeight:Math.round(s.getBoundingClientRect().height),optionCount:s.options.length,panelWidth:Math.round(p.getBoundingClientRect().width),panelScroll:p.scrollWidth,panelClient:p.clientWidth}}''')
  check(room['doc']<=w+1 and room['panelScroll']<=room['panelClient']+3,f'{name}: lobby has no horizontal overflow')
  if room['optionCount']==1: check(room['roomHeight']<=120,f'{name}: no-room state is compact rather than a blank giant list ({room["roomHeight"]}px)')
  page.locator('#multiplayer-panel').screenshot(path=str(OUT/f'multiplayer-panel-{name}.jpg'),type='jpeg',quality=82)
  page.screenshot(path=str(OUT/f'multiplayer-{name}.jpg'),full_page=True,type='jpeg',quality=82)
  check(not errors,f'{name}: no uncaught browser exceptions ({len(errors)})')
  page.close()
 browser.close()
print(f'Batch285 Quiz route UI browser: {checks-len(failures)}/{checks} PASS; empty-room state is not live server evidence.')
if failures: raise SystemExit(1)
