'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sandbox = { AbortController, setTimeout, clearTimeout, window: { AbortController, setTimeout, clearTimeout, fetch: null } };
vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/data/chinese-title-provider.js'), 'utf8'), sandbox, { filename: 'src/data/chinese-title-provider.js' });
const api = sandbox.window.AMQData.chineseTitleProvider;
const anilist = { '100': 'AniList 中文名' };
const bangumi = [{ title: 'Example Work', titleTranslate: { 'zh-Hant': ['範例作品'], 'zh-Hans': ['示例作品'] }, sites: [
  { site: 'myanimelist', id: '12' }, { site: 'anilist', id: '100' }, { site: 'vndb', id: 'v123' }, { site: 'anime-news-network', id: '9876' }
]}];
function response(value) { return { ok: true, status: 200, json: async () => value }; }

function fakeIndexedDB() {
  const values = new Map();
  const stores = new Set();
  const database = {
    objectStoreNames: { contains: name => stores.has(name) },
    createObjectStore(name) { stores.add(name); },
    transaction(name, mode) {
      const tx = { error: null, objectStore() { return {
        get(key) { const request = {}; setTimeout(() => { request.result = values.get(key); if (request.onsuccess) request.onsuccess(); }, 0); return request; },
        put(value, key) { setTimeout(() => { values.set(key, value); if (tx.oncomplete) tx.oncomplete(); }, 0); return {}; }
      }; } };
      return tx;
    },
    close() {}
  };
  return { open() { const request = { result: null, error: null }; setTimeout(() => { request.result = database; if (!stores.has('maps') && request.onupgradeneeded) request.onupgradeneeded(); if (request.onsuccess) request.onsuccess(); }, 0); return request; } };
}
(async () => {
  {
    const cache = { value: null, async get() { return this.value; }, async set(value) { this.value = value; } };
    const calls = [];
    const provider = api.createChineseTitleProvider({ indexedDB: null, cache, AbortController, convertToTraditional: value => value.replace('示例', '範例'), fetch: async url => {
      calls.push(url); return response(url.includes('anilist-chinese') ? anilist : bangumi);
    } });
    const result = await provider.load();
    assert.equal(result.ok, true);
    assert.equal(result.status, 'ready');
    assert.equal(calls.length, 2);
    assert.equal(provider.getTitle({ source: 'AMQ', animeAnnId: 9876 }), '範例作品');
    assert.deepEqual(JSON.parse(JSON.stringify(provider.getAliases({ source: 'AMQ', animeAnnId: 9876 }))), ['範例作品', 'AniList 中文名']);
    assert.equal(provider.getTitle({ source: 'EMQ', animeVndbId: 'V123' }), '範例作品');
    assert.equal(provider.getTitle({ source: 'EMQ', animeVndbId: 'unknown' }), '');
    assert.equal(provider.getAniListId({ source: 'AMQ', animeAnnId: 9876 }), '100');
    assert.equal(provider.getAniListId({ source: 'AMQ', animeId: 12 }), '');
    assert.ok(cache.value && cache.value.maps && cache.value.savedAt);
    const cachedProvider = api.createChineseTitleProvider({ indexedDB: null, cache, fetch: async () => { throw new Error('network should not be used for fresh cache'); } });
    const cached = await cachedProvider.load();
    assert.equal(cached.cached, true);
    assert.equal(cachedProvider.getTitle({ source: 'AMQ', animeAnnId: 9876 }), '範例作品');
    provider.dispose(); cachedProvider.dispose();
    console.log('PASS Chinese title provider maps MAL/VNDB IDs, preserves aliases, converts titles and uses persistent cache');
  }
  {
    const cache = { value: null, async get() { return this.value; }, async set(value) { this.value = value; } };
    let now = 1000;
    const first = api.createChineseTitleProvider({ indexedDB: null, cache, AbortController, now: () => now, convertToTraditional: x => x, fetch: async url => response(url.includes('anilist-chinese') ? anilist : bangumi) });
    await first.load();
    now += 8 * 24 * 60 * 60 * 1000;
    const stale = api.createChineseTitleProvider({ indexedDB: null, cache, AbortController, now: () => now, fetch: async () => { throw new Error('offline'); } });
    const result = await stale.load();
    assert.equal(result.stale, true);
    assert.equal(stale.getTitle({ source: 'AMQ', animeAnnId: 9876 }), '範例作品');
    first.dispose(); stale.dispose();
    console.log('PASS expired cache remains usable when remote sources fail');
  }
  {
    const provider = api.createChineseTitleProvider({ indexedDB: null, AbortController, fetch: async url => {
      if (url.includes('anilist-chinese')) throw new Error('AniList source offline');
      return response(bangumi);
    } });
    const result = await provider.load();
    assert.equal(result.partial, true);
    assert.equal(provider.getTitle({ source: 'AMQ', animeAnnId: 9876 }), '範例作品');
    assert.equal(provider.getStatus().status, 'ready-partial');
    provider.dispose();
    console.log('PASS Bangumi-only data still provides Chinese titles when the optional AniList source is unavailable');
  }
  {
    const indexedDB = fakeIndexedDB();
    let networkCalls = 0;
    const first = api.createChineseTitleProvider({ indexedDB, AbortController, convertToTraditional: x => x, fetch: async url => { networkCalls++; return response(url.includes('anilist-chinese') ? anilist : bangumi); } });
    await first.load();
    assert.equal(networkCalls, 2);
    const second = api.createChineseTitleProvider({ indexedDB, AbortController, fetch: async () => { throw new Error('fresh IndexedDB cache should avoid network'); } });
    const result = await second.load();
    assert.equal(result.cached, true);
    assert.equal(second.getTitle({ source: 'EMQ', animeVndbId: 'v123' }), '範例作品');
    first.dispose(); second.dispose();
    console.log('PASS IndexedDB cache is persisted and reused without another remote fetch');
  }
  {
    const controller = new AbortController();
    const provider = api.createChineseTitleProvider({ indexedDB: null, AbortController, fetch: (url, options) => new Promise((resolve, reject) => {
      options.signal.addEventListener('abort', () => { const error = new Error('aborted'); error.name = 'AbortError'; reject(error); }, { once: true });
    }) });
    const pending = provider.load({ signal: controller.signal });
    controller.abort();
    await assert.rejects(pending, error => error && error.name === 'AbortError');
    assert.equal(provider.getStatus().ready, false);
    provider.dispose();
    console.log('PASS title lookup honors cancellation and does not publish partial state');
  }
  {
    assert.throws(() => api.parseAniListMap([]), /must be an object/);
    assert.throws(() => api.parseBangumi({}), /must be an array/);
    assert.throws(() => api.parseBangumi([{ title: 'No ID', titleTranslate: { 'zh-Hans': ['中文'] }, sites: [] }]), /no usable/);
    console.log('PASS provider rejects malformed datasets and does not guess work identity');
  }
  console.log('Chinese title provider tests: 6/6 passed');
})().catch(error => { console.error(error.stack || error); process.exitCode = 1; });
