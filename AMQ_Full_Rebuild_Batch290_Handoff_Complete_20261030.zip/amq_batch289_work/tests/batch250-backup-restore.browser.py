#!/usr/bin/env python3
"""Real Chromium checks for Settings backup/restore touch targets and mobile layout."""
from pathlib import Path
import re
from playwright.sync_api import sync_playwright
ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / 'src'
OUT = ROOT / 'artifacts' / 'batch250-regression'
OUT.mkdir(parents=True, exist_ok=True)
html = (SRC / 'index.html').read_text(encoding='utf-8')
def inline_css(match): return '<style>\n' + (SRC / match.group(1)).read_text(encoding='utf-8') + '\n</style>'
def inline_js(match): return '<script>\n' + (SRC / match.group(1)).read_text(encoding='utf-8') + '\n</script>'
html = re.sub(r'<link rel="stylesheet" href="([^"]+)">', inline_css, html)
html = re.sub(r'<script src="([^"]+)"></script>', inline_js, html)
checks, failures = 0, []
def check(ok, label):
    global checks
    checks += 1
    print(('PASS ' if ok else 'FAIL ') + label)
    if not ok: failures.append(label)
with sync_playwright() as p:
    browser = p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox','--disable-dev-shm-usage'])
    page = browser.new_page(viewport={'width':1440,'height':900})
    errors=[]
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.set_content(html, wait_until='domcontentloaded', timeout=60000)
    page.wait_for_timeout(400)
    page.locator('#home-pie-core').click()
    page.locator('#home-pie-actions [data-go-page="settings"]').click()
    page.wait_for_timeout(100)
    check(page.locator('#page-settings').is_visible(), 'Settings route opens through the real navigation')
    controls = ['#backup-export', '#backup-preflight', '#backup-restore']
    metrics = page.evaluate("""selectors => selectors.map(selector => {const element=document.querySelector(selector); return {selector, exists:!!element, minHeight:element?parseFloat(getComputedStyle(element).minHeight):0, rectHeight:element?element.getBoundingClientRect().height:0};})""", controls)
    for item in metrics:
        check(item['exists'] and item['minHeight'] >= 44 and item['rectHeight'] >= 44, f"{item['selector']} computed touch target >=44px ({item['minHeight']}px min / {item['rectHeight']}px actual)")
    desktop = page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
    check(desktop, 'Settings has no horizontal overflow at desktop width')
    page.screenshot(path=str(OUT/'settings-backup-desktop.png'), full_page=True)
    page.set_viewport_size({'width':390,'height':844})
    page.wait_for_timeout(100)
    mobile = page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1')
    check(mobile, 'Settings backup/restore has no horizontal overflow at 390px')
    mobile_metrics = page.evaluate("""selectors => selectors.map(selector => {const element=document.querySelector(selector); return {selector, height:element?element.getBoundingClientRect().height:0, width:element?element.getBoundingClientRect().width:0};})""", controls)
    check(all(item['height'] >= 44 and item['width'] > 0 for item in mobile_metrics), 'backup/restore touch targets remain usable at 390px')
    check(not errors, f'no uncaught browser exceptions ({len(errors)})')
    page.screenshot(path=str(OUT/'settings-backup-mobile.png'), full_page=True)
    browser.close()
print(f'Batch250 Backup/Restore Chromium assertions: {checks-len(failures)}/{checks} PASS')
if failures: raise SystemExit('; '.join(failures))
