'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const sandbox = { window: {} }; vm.createContext(sandbox);
vm.runInContext(fs.readFileSync(path.join(root, 'src/learning/statistics-dashboard.js'), 'utf8'), sandbox);
const build = sandbox.window.AMQLearning.statisticsDashboard.buildDashboard;
const report = build({
  quizHistory: [
    { source: 'AMQ', target: 'anime', correct: true, elapsed: 2, at: '2026-10-26T10:00:00.000Z', animeId: 'work-1', workTitle: 'Example Anime', songId: 'song-1' },
    { source: 'AMQ', target: 'title', correct: false, elapsed: 4, at: '2026-10-26T10:01:00.000Z', animeId: 'work-1', workTitle: 'Example Anime', songId: 'song-2' },
    { source: 'EMQ', target: 'artist', correct: true, elapsed: 1, at: '2026-10-27T10:00:00.000Z', animeId: 'work-1', workTitle: 'Example Game', songId: 'song-1' },
    { source: 'UNKNOWN', target: 'anime', correct: true, elapsed: 1, at: '2026-10-27T10:00:00.000Z' },
    { source: 'EMQ', target: 'title', correct: 'yes', elapsed: 1 }
  ],
  familiarityAMQ: { '1': 0, '2': 2, '3': 3, '4': 4, 'bad': 'x' }, familiarityEMQ: { '10': 1 },
  srsAMQ: { total: 10, active: 8, due: 3, new: 2, learning: 1, review: 5, suspended: 2 },
  srsEMQ: { total: 2, active: 2, due: 1 },
  playbackHistory: [{ source: 'EMQ', songId: 'same' }, { source: 'AMQ', songId: 'same' }]
});
assert.equal(report.quiz.total, 3, 'invalid/unknown-source answer records are not silently counted');
assert.equal(report.quiz.correct, 2); assert.equal(report.quiz.wrong, 1); assert.equal(report.quiz.accuracy, 2 / 3);
assert.equal(report.quiz.averageElapsedSeconds, 7 / 3);
assert.equal(report.quiz.bySource.AMQ.total, 2); assert.equal(report.quiz.bySource.EMQ.total, 1);
assert.equal(report.quiz.byTarget.title.accuracy, 0); assert.equal(report.quiz.recentDays.length, 2);
assert.equal(report.familiarity.AMQ.level0, 1); assert.equal(report.familiarity.AMQ.level2, 1); assert.equal(report.familiarity.AMQ.level3, 1); assert.equal(report.familiarity.AMQ.level4, 1); assert.equal(report.familiarity.AMQ.unknown, 1);
assert.equal(report.srs.AMQ.due, 3); assert.equal(report.srs.EMQ.total, 2);
assert.equal(report.workProgress.totalWorks, 2, 'same numeric work IDs across AMQ and EMQ must remain source-isolated');
assert.equal(report.workProgress.totalAnswers, 3);
assert.equal(report.workProgress.works.find(work => work.title === 'Example Anime').uniqueSongs, 2);
assert.equal(report.workProgress.works.find(work => work.title === 'Example Anime').accuracy, 0.5);
assert.equal(report.playback.total, 2); assert.equal(report.playback.bySource.AMQ, 1); assert.equal(report.playback.bySource.EMQ, 1);
assert.equal(build({}).quiz.accuracy, null, 'empty history produces an explicit empty accuracy rather than NaN');
console.log('Statistics dashboard tests: PASS');
