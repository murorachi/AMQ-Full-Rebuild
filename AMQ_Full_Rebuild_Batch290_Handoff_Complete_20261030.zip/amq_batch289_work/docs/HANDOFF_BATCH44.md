# Batch 44 交接：必要功能跨模組驗收矩陣

## 已完成
- 新增 `tests/audio-session.integration.test.cjs`，直接組合 AudioService、QuizSession、QuizClock、QuizEngine 與 QuizPool；使用 mock media 驗證 `canplay` 不等於實際播放、`playing` 才啟動計時、pause 凍結剩餘時間、resume 延續剩餘 deadline、end／dispose 清理 timer。
- 更新 `docs/FUNCTION_INVENTORY.md`，修正已取得資料來源／已有 query、SRS、quiz engine 模組的過時描述，新增跨模組驗收矩陣與限制。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`。

## 驗證邊界
- Node mock-media integration PASS，不代表真實音源可播放或瀏覽器端 E2E 通過。
- AMQ／EMQ／MIX load/cancel、query index、catalog browser、QuizSession persistence 與 quiz panel source switching 均已有既有整合測試，但舊版完整相容、真實瀏覽器及真實音訊仍未驗收。
- 全量 Node scripts 23/23 exit 0；tooling 8/8；architecture 437/0。
- Source audit、mapper verification（Catalog 55,660）、5 次 benchmark、所有 JS/CJS syntax 均 PASS；來源 asset SHA-256 unchanged。
- 完整日誌與封包驗證位於 `/mnt/data/amq_batch44_logs/`。

## 下一批 Batch 45
1. 核對 catalog browser 與 query index、共享 load state 的 loading／empty／failed／filter／sort／pagination 狀態投影。
2. 只修正有證據的功能性 UI 缺陷，補測；不做 CSS 大重構。
3. 全量回歸與完整 ZIP 交付，維持真實瀏覽器 E2E 阻塞紀錄。
