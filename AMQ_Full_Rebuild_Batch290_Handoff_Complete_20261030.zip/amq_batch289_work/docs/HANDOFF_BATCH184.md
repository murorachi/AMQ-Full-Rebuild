# Batch184 交接：可自訂快捷鍵與工作區偏好

## 本批完成
- 新增 `src/persistence/workspace-preferences-store.js`，獨立 key `amqWorkspacePreferencesV1`，保存 shortcuts、visibility、defaultSection、statisticsOrder；具備 schema validation、壞資料隔離、跨分頁 storage event refresh、dispose 與失敗寫入不提交。
- 新增 `src/ui/workspace-preferences-panel.js`，提供 12 個快捷鍵操作：聚焦答案、開始回合、播放／暫停、揭曉、跳過、下一題、前往曲庫搜尋、前往自由播放搜尋、前往設定、隨機播放、前往統計。
- 快捷鍵需要 Ctrl／Alt／Meta 修飾鍵，限制字母／數字／F1–F12，拒絕重複組合；忽略 input／textarea／select／contenteditable／textbox、IME composition、AltGraph 與 repeat。錄製時 Escape 取消。目標不存在、隱藏或 disabled 時不執行。
- 工作區可切換 10 個區塊顯示、設定預設入口、上移／下移統計六項資訊。預設入口預設為「保留首頁位置」，不改變原有首次載入位置。隱藏不會 dispose 功能模組或清除資料。
- `src/app.js` 用既有 lifecycle scope 擁有 store 與 panel。新增 store tests、panel contract tests，更新 app lifecycle integration。
- 修正 `src/index.html` 原有重複 footer 尾碼。

## 測試證據
- 73 個 Node `*.test.cjs`：73/73 檔案 exit 0；`artifacts/batch184-workspace-shortcuts/node-tests.tsv` 與 `node-tests/`。
- Workspace preferences store：6 組測試 PASS。
- Workspace preferences panel contract：32 assertions PASS。
- App lifecycle integration：dispose/remount、mount failure rollback PASS。
- Architecture checker：1,080 PASS／0 FAIL。
- OSK harness：12/12 assertions PASS。
- JS/CJS `node --check`：168/168 PASS。
- AMQ／EMQ 資產 hash 與 Batch183 一致，未修改曲庫。

## 尚未驗收／限制
- Chromium headless 18 秒 timeout，DOM output 0 bytes；stderr 有 DBus／zygote 啟動錯誤。真實瀏覽器快捷鍵、焦點、響應式版面與隱藏區塊操作仍未驗收。見 `artifacts/batch184-workspace-shortcuts/browser-attempt.txt`。
- 尚未實作具名的多組曲庫篩選預設管理；既有猜歌篩選仍沿用 App Settings Store，沒有複製第二份狀態。
- Candidate302 正式基準與 Candidate382 Stage 0 原始檔不在工作副本，無法 hash／相容性驗收。工作副本無 `.git`，未初始化。

## 修改檔案
- `src/persistence/workspace-preferences-store.js`（新增）
- `src/ui/workspace-preferences-panel.js`（新增）
- `src/app.js`
- `src/index.html`
- `src/styles.css`
- `tests/tests.html`
- `tests/app-lifecycle.integration.test.cjs`
- `tests/workspace-preferences-store.test.cjs`（新增）
- `tests/workspace-preferences-panel.contract.test.cjs`（新增）
- `tools/check-architecture.cjs`
- `AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/ARCHITECTURE.md`、`docs/FUNCTION_INVENTORY.md`、`docs/NEXT_SESSION_PROMPT.md`、本 handoff 與本批 artifacts。

## Batch185 下一步
1. 稽核 QuizSession engine listener／persistence adapter 同步重入與可能重複持久化。
2. 檢查 `playbackEpoch`／`playAttemptId` 在 explicit restart 前後對 stale audio event 的隔離。
3. 先建 controlled regression，只修可重現 P0/P1；保留四級熟悉度、`all` 只看作品標題、單一 playback owner。
