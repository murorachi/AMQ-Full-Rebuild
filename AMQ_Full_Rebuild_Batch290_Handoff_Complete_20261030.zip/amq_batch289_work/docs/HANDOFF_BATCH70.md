# Batch 70 交接：舊版與新版功能差異盤點

日期：2026-10-27

## 本批結果
- 完成 50 項功能差異矩陣：`docs/FUNCTION_PARITY_AUDIT_BATCH70.md`。
- 更新唯一主清單、`WORK_STATUS.md`、`FUNCTION_INVENTORY.md`、`AI_START_HERE.md` 與 `NEXT_SESSION_PROMPT.md`。
- 本批沒有修改 `src/` 程式碼、來源資料、舊版 HTML 或正式基準。

## 證據與限制
- 舊版參考 `AMQ382(2).html` SHA-256：`65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`，內容標示 Candidate381／V82.x。只用靜態線索；不代表 Candidate302／Candidate382 Stage 0 相容，也不證明每項舊功能目前可正常操作。
- 新版來自 Batch 69 ZIP；其 SHA-256：`619698d4f6fac51f76b9e8a8d58433573c271a18ef933b19f6e5c9c2691d1094`。ZIP integrity test 通過。
- 舊版約 705 個 id、268 button、149 input、47 select；新版 `src/index.html` 約 90 個 id、27 button、12 input、9 select。僅作介面表面差異線索，不計算為功能數量／相容率。

## 關鍵缺口
- 核心待驗收：真實瀏覽器下答案建議／鍵盤／IME、真實音訊、AMQ／EMQ／MIX 模式與篩選差異、乾淨啟動。
- 必要性待定或部分缺失：舊版完整猜歌篩選、Random Sample／片段位置、自動下一題延遲、中文標題 provider、探索新歌、弱點補強、統計儀表板、作品圖鑑。
- 明確缺失／阻塞：收藏 UI 與 `aniFavorites_v1` 身份、歌曲標籤、批次操作、獨立播放器／佇列／播放歷史、完整備份還原、資料庫更新、主題／背景、AniList／MAL／VNDB、多人服務端等。
- 詳細 P0/P1/P2 分類與各項驗收條件見 parity audit。

## 自動化驗證
- `tests/*.test.cjs`：27/27 腳本 exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：480 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，重複 ID／懸空關聯／跨來源 ID 衝突為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，AMQ 38,821、EMQ 16,839、Catalog 55,660。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，Catalog build 約 1,065.636 ms（本機 Node 記憶體內觀察，不代表瀏覽器效能）。
- 本批為文件／清單盤點，沒有修改 `src/` 程式碼或 AMQ／EMQ 資料資產；以上測試證明現有工作副本仍通過，不證明舊版相容或瀏覽器／音訊通過。

## 結論
- Batch 70 差異盤點可結案。
- 新版必要功能完整性及整體產品重建不可結案；真實瀏覽器／音訊尚未驗收，且仍有 P1 功能缺口待決策。
- 不要自動復刻所有舊功能；優先必要學習流程與資料安全。UI／CSS 大重構排最後。
- 下一批直接依 parity audit P0/P1 排序，並更新唯一主清單與交接資料。
