# Batch216 交接：學習清單作品識別／封面與跨頁 UI 狀態

日期：2026-10-29
工作副本：`/mnt/data/amq_batch216_work/project`
來源交付包：`/mnt/data/AMQ_Full_Rebuild_Batch215_Learning_Review_Settings_UI_20261029.zip`
來源 ZIP SHA-256：`cddd9b59332340140dcb3f594c21225a9ba4e199f671913fffebdb3828b2999b`
本批交付：`AMQ_Full_Rebuild_Batch216_SourceAware_Learning_UI_20261029.zip`（交付 ZIP SHA-256 以外部 `.zip.sha256` sidecar 為準；最終 manifest 項目 3,692）。

## 本批實作

- `src/ui/statistics-dashboard-panel.js`：注入既有 runtime `catalogSnapshot()`，以 source + song ID 精確建立當前已載入 Catalog 的唯讀索引。只有 source-aware identity 完全相符才補作品名稱／標題／封面 record；跨來源重複 ID 不會互相命中。Catalog 不在當前 snapshot 或無法可靠對應時，保留歷史內已保存名稱或顯示明確歌曲 ID，不以標題猜測。
- 學習歷史與 SRS 複習列共用 app 已建立的 `artworkAdapter`，沒有新增 provider、外部請求或快取 owner。只有 record 存在明確 `artworkRef` 才請求封面；provider missing/error 與圖片載入失敗顯示可辨識 fallback。
- 封面非同步更新使用 render generation 與 dispose guard；清單重繪後舊 Promise 不得寫入新列，dispose 後 late completion 不得再修改 UI。既有 artwork adapter 的 pending/cache 去重策略維持唯一來源。
- `src/app.js` 將既有 runtime、artwork adapter、state store 注入 statistics dashboard。狀態 owner 仍為原有 stores/runtime。
- `src/styles/ui-shell.css`：學習列表加入來源可辨識的封面 slot、桌面三欄／手機兩欄結構、hover／focus-visible、封面未提供與錯誤 fallback；結果頁、Catalog、多人控制加入明確 focus-visible／disabled／error 視覺回饋。
- `tests/statistics-dashboard-panel.test.cjs`：加入 source-scoped record identity（含跨來源相同 song ID）、名稱補全、共用 adapter 封面更新與 dispose 後 late completion 回歸。
- `tests/app-shell.browser.test.py`：更新到 `artifacts/batch216-regression/`；正式 shell 現有檢查 91/91 PASS，包含結果空狀態、多人 disabled 樣式、學習列表手機封面欄與無 uncaught exceptions。

## 驗證

- 全部 77 個 `tests/*.test.cjs`：逐檔 exit 0；`artifacts/batch216-regression/node-tests/summary.tsv` 與各檔 log。`quiz-pool.test.cjs` 因執行成本單獨重跑，10/10 PASS。
- `tests/statistics-dashboard-panel.test.cjs`：PASS（含 source-aware mapping、artwork Promise、dispose late completion）。
- `tests/app-shell.browser.test.py`：91/91 PASS；桌面與 390px 手機、無水平溢位、無 uncaught browser exceptions。
- `node tools/check-architecture.cjs`：1,137 PASS／0 FAIL。
- 172 個 JS/CJS `node --check`、三個 Python browser tests `py_compile`：需以 `artifacts/batch216-regression/` 最終證據為準。
- Batch215 來源 ZIP CRC PASS；對 ZIP 內 3,583 個 manifest 項目直接驗 hash，零 mismatch、零 missing。ZIP 中額外目錄項是正常 ZIP directory entries，不是額外檔案。
- AMQ／EMQ 靜態資料資產保持唯讀；hash 證據見 `artifacts/batch216-regression/asset-hashes.txt`。

## 阻塞與限制

- HTTP-origin 測試未重跑：前批同環境 Chromium loopback navigation 回報 `ERR_BLOCKED_BY_ADMINISTRATOR`，本批環境與 origin 條件未變。真實 localStorage／reload／IndexedDB 仍未驗收。
- 外部封面 provider／真實曲庫／真實音訊／真實 `.osk` 未做 live API 或實機驗收；本批只證明接線與非同步生命週期契約。
- Catalog runtime snapshot 只代表當前已載入模式；其他來源的 SRS／歷史若不在 snapshot，保留既有名稱或明確 ID。沒有跨模式全曲庫 resolver 時不自行載入第二份曲庫。
- Candidate302 正式維護基準與 Candidate382 Stage 0 CSS 比較基準原始檔缺席；不宣稱相容。工作副本沒有 `.git`，未初始化。
- 全球排行榜仍無可信 backend owner，不造 PP／排名／PB。UI 主線未結案。

## 下一批優先

1. 繼續完成 Catalog 鍵盤選取／觸控操作與錯誤、loading、filtered-empty 狀態的端到端互動回歸。
2. 結果頁補真實已保存 round 的顯示與操作回歸；不使用跨回合假資料。
3. 多人頁繼續檢查 focus order、命令忙碌／離線／錯誤提示及 server snapshot 變更，不改 server-authoritative state owner。
4. OSK 剩餘 13 roles 只在建立真實語義 target／CSS consumer 後才接線；真實 `.osk` 仍待驗收。
5. 繼續更新唯一主清單／工作狀態／traceability／handoff／manifest／ZIP。HTTP-origin test 僅在環境改變時重跑。
