# Handoff Batch 87 · 2026-10-27

## Implemented
- `src/data/query-index.js`: year range / unknown year policy / anime subtype / decade / source-aware watch status / familiarity filters; numeric anime-year sorting; dynamic facets for anime subtype and decade. Filters execute before sorting and pagination.
- `src/ui/catalog-browser.js`: year from/to, include unknown year, subtype, decade, watch status and familiarity controls. It builds a copied index with `animeDecade`, source-aware `watchStatus`, and `familiarityLevel` from the existing stores; original runtime catalog records are not mutated.
- `src/app.js`: owns one Familiarity Store and shares it with Catalog Browser and QuizPanel.
- Chinese-title index rebuild only occurs when `chineseTitlesEnabled` toggles, not on every unrelated settings update.
- `tests/query-index.test.cjs`, `tests/catalog-browser.test.cjs`, `tests/catalog-browser.integration.test.cjs`, and `tests/quiz-panel.test.cjs` now cover browse filters and cross-source eligibility.

## Verification
- Query index tests PASS, including year/unknown year, anime type, decade, watch status, familiarity, facets and numeric year sorting.
- Catalog browser unit and integration tests PASS; new UI filter controls produce expected result counts and reset correctly.
- QuizPanel integration PASS, including MIX unknown-year include/exclude, missing EMQ metadata handling, difficulty boundaries and AMQ/EMQ/MIX filter matrix.
- Batch 86 Dock, dashboard, AudioService metrics and app lifecycle tests were re-run and PASS.
- All 39 `tests/*.test.cjs` scripts passed when run individually. The first group of 20 and second group of 18 passed; `tests/tooling.test.cjs` was run separately and passed 9/9 after its aggregate runner hit the tool execution limit. The timed-out aggregate command is not counted as passing.
- `node tools/check-architecture.cjs`: 642 passed / 0 failed.
- Source audit PASS; mapper verification PASS, Catalog 55,660; 5-iteration benchmark PASS.
- JavaScript/CJS syntax: 89/89 PASS.
- Source asset hashes remain `data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3` and `emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`.

## Remaining
- True browser validation for facets, cross-tab watch/familiarity changes, storage failure and large-catalog rebuild performance is unavailable; do not retry known Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` route.
- Full Candidate302 filter semantic compatibility remains unverified; Candidate302 must not be searched or modified.
- External service and multiplayer contracts remain unimplemented.
