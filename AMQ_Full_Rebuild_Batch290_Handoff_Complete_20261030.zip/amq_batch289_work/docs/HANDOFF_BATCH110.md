# Batch110 交接：曲庫發布簽章與更新供應鏈驗證

日期：2026-10-28

## 本批目標

依 Batch109 的下一步，在不等待使用者最後集中實機驗收的前提下，先完成所有不依賴公開 hosting 的曲庫發布簽章功能，並將固定公鑰、發布工具、測試及交接文件接好。

## 修改

- `tools/create-database-update-signing-key.cjs`：新增自架 Ed25519 keygen 工具，私鑰以 owner-only 權限建立且拒絕覆蓋既有檔案。
- `tools/verify-database-update-release.cjs`：新增發布前離線驗證工具，檢查 manifest signature、key ID、bundle byte length／SHA-256、payload checksum 與格式。
- `tools/create-database-update-release.cjs`：現在必須提供 `<ed25519-private-key.pem>`。發布前先讀取並驗證 key type 為 Ed25519，然後產生 bundle／manifest；manifest 以穩定 canonical JSON（排除 signature 欄位）簽署，含 `algorithm: Ed25519`、公鑰 DER SHA-256 前 16 位 hex 作為 `keyId` 及 Base64 signature。已有輸出仍拒絕覆蓋。
- `src/data/database-update-config.js`：固定官方 Ed25519 SPKI DER Base64 公鑰與 key ID；manifest URL 仍預設空白。
- `src/ui/database-update-panel.js`：下載 manifest 後立即驗證簽章與 key ID；公鑰缺失、signature 缺失／錯誤、key ID 不符或 WebCrypto 不支援 Ed25519 都 fail closed，且不會下載 bundle。通過後才進行原有 HTTPS／同來源／byte length／SHA-256／payload checksum／schema／mapping／完整資料驗證及差異預覽。
- `tests/tooling.test.cjs`：使用臨時 Ed25519 key pair 產生簽章並以公鑰驗證；仍驗證拒絕覆蓋。
- `tests/database-update-panel.test.cjs`：mock-fetch 使用測試 key；驗證有效簽章流程、bundle hash mismatch 與修改已簽署 manifest 後的 signature rejection。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/ARCHITECTURE.md`、`docs/ACCEPTANCE.md`、`README_FIRST.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md` 及發布契約。

## 金鑰保管

- 公鑰可公開，位於 `src/data/database-update-config.js`。
- 私鑰不在專案目錄與 ZIP 內；本次生成的私鑰位於 ZIP 外 `/mnt/data/AMQ_DATABASE_UPDATE_SIGNING_PRIVATE.pem`，權限設為 owner-only。交付時需單獨提供，使用者必須安全保存且不可公開上傳。
- 自架者應產生自己的 Ed25519 key pair，並將公鑰與 key ID 更新到 `src/data/database-update-config.js`，用對應私鑰簽署自己的發布包。
- 官方固定 HTTPS hosting／manifest URL 尚未指定，沒有部署／推送任何產物。

## 驗證

- `node --check tools/create-database-update-release.cjs`：PASS。
- `node --check src/ui/database-update-panel.js`：PASS。
- `node --test tests/tooling.test.cjs tests/database-update-panel.test.cjs`：11/11 PASS。
- 完整測試、架構、資料稽核、mapper、benchmark、語法與最終 ZIP／Manifest 結果以本批最終工作狀態紀錄為準。
- 真實瀏覽器、HTTPS hosting、CORS、IndexedDB transaction／quota／reload 仍待使用者最後集中實機驗收；mock tests 不代表已驗收。

## 下一步

1. 先完成全量自動化回歸與包完整性驗證。
2. 公開更新 hosting 由使用者／維護者選擇可信任位置後再配置；不假造 URL、不自行發布。
3. 最後由使用者集中驗收 Google login、註冊、SRS、曲庫更新與主要答題流程。

## 最終自動化回歸與交付包

- 非-tooling 測試腳本：49/49 exit 0（逐檔執行）。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：783 passed／0 failed。
- `node --check` 全部 `src/`、`tests/`、`tools/`、`server/` JS／CJS：117/117 PASS。
- Source audit：PASS；AMQ 9,516 works／38,821 songs；EMQ 6,645 works／16,839 songs；跨來源 ID collision 0。
- Mapper verification：PASS，Catalog 55,660 records。
- Catalog benchmark 5 runs：PASS。
- 正式來源 signed release preview：13,279,913 bytes；Ed25519 signature 以 pinned public key 驗證成功，key ID `55f06a8b96214b9b`；preview 只在 `/mnt/data/amq_batch110_signed_release_preview/`，不在 ZIP。
- 來源檔雜湊與 Batch100 既有紀錄一致；未修改正式基準／唯讀來源。
- ZIP／manifest 最終驗證結果由交付回報提供，並保留 `/mnt/data/amq_batch110_validation_logs/` 的各項日誌。
- 最終 ZIP：`AMQ_Full_Rebuild_Batch110_Handoff_20261028.zip`，271 entries（含目錄）、256 個檔案（含 `MANIFEST.sha256`），Manifest 255 個受管檔案；CRC PASS、缺檔 0、額外檔 0、hash mismatch 0。官方私鑰及本機 signed preview 均不在 ZIP 內。
