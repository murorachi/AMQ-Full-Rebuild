# AMQ 新版重建交接：Batch115

日期：2026-10-28  
工作副本：`/mnt/data/amq_batch114_work`（最終以本交接包內檔案為準）  
Git：無 `.git` metadata；未初始化 Git、未 commit、未 push。

## 本批目標

從磁碟上實際存在的 Batch114 工作副本接續，完成可自動驗證的多人房間 HTTP transport 與 durable room lifecycle，不重做 Batch111–114。

## 實作成果

1. `server/multiplayer-runtime.cjs` 在隔離 VM 載入 bundled AMQ／EMQ 唯讀曲庫與既有 mapper、answer evaluator、assessment engine、room state machine，建立 server-owned playable question pool 與評級器。
2. `server/multiplayer-host.cjs` 管理 room create/list/join/dispatch/snapshot，使用每房 Promise queue 序列化命令，將房間狀態、已用 question IDs、timeout assessments 與 requestId/fingerprint/result 持久化至 SQLite。每房保留最近 5,000 筆命令結果。
3. `server/database.cjs` 使用 `multiplayer_rooms` 與 `multiplayer_commands` 表保存 room state 及 durable idempotency records。
4. `server/http-server.cjs` 接入需登入的 REST endpoints：
   - `GET /api/multiplayer/rooms`
   - `POST /api/multiplayer/rooms`
   - `POST /api/multiplayer/rooms/:id/join`
   - `GET /api/multiplayer/rooms/:id?sinceRevision=N`
   - `POST /api/multiplayer/rooms/:id/commands`
5. 修正新玩家加入的 membership guard 順序：`player.join` 必須先允許非成員進入命令服務，不能在狀態機驗證前就要求其已是成員；其他命令仍要求目前成員身份。加入命令同樣受 requestId 冪等保護。
6. `src/multiplayer/room-command-service.js` 新增 `exportState()`，回傳 detached／frozen authoritative state，供 server 持久化使用。
7. `round.start` 的 question ID、round ID、duration 全由 server 決定。Client 的 `actorId`、correctness、grade、latency 不可信；答案只透過 server-owned work-title evaluator 判定。Active-round snapshot 隱藏其他玩家答案；server timer 到期後關閉回合並保存 timeout assessment，只向對應玩家回傳其評級。
8. 新增 `tests/multiplayer-http.integration.test.cjs` 與 `tests/multiplayer-host.integration.test.cjs`，使用本機 HTTP、真實 bundled read-only data 與暫存 SQLite 驗證完整流程。

## 驗證結果

- 54/54 `tests/*.test.cjs` scripts 逐檔 exit 0（其中 53 個非-tooling scripts 加上 tooling 檔直接執行）。
- `tests/tooling.test.cjs` 直接執行 exit 0；`node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：836 passed／0 failed。
- JavaScript/CJS syntax：128/128 PASS。
- Source audit：PASS。
- Mapper：PASS；AMQ 38,821 songs／9,516 works，EMQ 16,839 songs／6,645 works，Catalog 55,660 records。
- 5-run catalog benchmark：PASS。這是目前 Node 環境的記憶體內基準，不是瀏覽器效能保證。
- `node --test tests/multiplayer-http.integration.test.cjs`：1/1 PASS；timeout 測試使用注入時鐘直接推進 deadline，避免在負載較高時因 wall-clock 執行延遲而出現假失敗。
- `node --test tests/multiplayer-host.integration.test.cjs`：1/1 PASS。
- `node --test tests/server-auth-srs.integration.test.cjs tests/database-google-migration.test.cjs`：9/9 PASS。
- `node tests/account-panel.integration.test.cjs`：PASS。
- `node tests/external-service-feature-adapters.test.cjs`：PASS。
- 唯讀資料 SHA-256 未變：
  - AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`
  - EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`
- Node v22.16 的 `node:sqlite` 仍會顯示 ExperimentalWarning。
- 完整日誌放在交付包外的 `/mnt/data/amq_batch115_validation_logs/final/`；不把臨時測試資料庫或敏感私鑰放入 ZIP。

## 尚未完成／明確阻塞

- 多人 API 目前是 authenticated HTTP polling，不是 WebSocket；沒有多人前端 UI，不能宣稱完整多人遊玩已完成。
- 尚未整合既有 AudioService／QuizSession 的音訊同步，也未將多人評級自動寫入個人 SRS。
- 沒有多節點共享 queue、分散式鎖或分散式限流；目前 durable state 的保證範圍是單一 SQLite 資料庫與單一伺服器程序生命週期。
- Google OAuth 真實憑證／回呼、AniList／MAL 真實 API、公開 HTTPS 更新 hosting 仍需要使用者自己的憑證或正式端點。
- 真實瀏覽器、音訊可聽性、multi-client E2E 與 Windows 操作驗收，依使用者要求留到其他程式端功能完成後集中處理。已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 路徑不重試。
- Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 均未覆寫；沒有 `.git` metadata，不得宣稱有 branch／commit。

## 本批主要變更檔案

- `server/database.cjs`
- `server/http-server.cjs`
- `server/multiplayer-runtime.cjs`
- `server/multiplayer-host.cjs`
- `src/multiplayer/room-command-service.js`
- `tests/multiplayer-room-command-service.test.cjs`
- `tests/multiplayer-http.integration.test.cjs`
- `tests/multiplayer-host.integration.test.cjs`
- `docs/PRIVATE_SERVER.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `README_FIRST.md`

## 下一批建議順序

1. 檢查多人 UI／AudioService 接線可否重用既有 AudioService、QuizSession、Clock，不得建立第二套音訊或計時狀態來源。
2. 追查遠端 SRS offline queue／多裝置衝突處理；沿用 `expectedRevision` 與 fail-closed，不能靜默覆蓋。
3. 研究 AniList／MAL OAuth credential lifecycle、token refresh 與 provider list mapping；不得把 client secret 放入前端，也不得未經確認覆寫本機 personal library/watch status。
4. 每批更新同一份主清單、狀態、交接文件、下一個 AI 提示、架構／驗收文件及 manifest；真實瀏覽器／音訊驗收最後集中執行。
