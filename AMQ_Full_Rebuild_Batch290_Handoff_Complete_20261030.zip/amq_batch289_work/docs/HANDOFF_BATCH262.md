# Batch262 交接：Home 正式作品映射與封面接線

## 基準保護
- 從 Batch261 工作副本建立 Batch262；Batch261 ZIP／資料檔不覆寫。
- 本副本沒有 `.git`，未初始化 Git。
- `src/data/assets/data.js` 與 `src/data/assets/emq-data.js` 未修改；交付前需再次比對其 SHA-256。

## 本批完成
- `src/data/source-runtime.js` 新增 `resolveArtworkRecord(source, workId)`：AMQ 使用正式 `anime` row 與明確 ANNID；EMQ 使用正式 `works` row 與明確 VNDB ID；不匹配或無效 ID 回傳 `null`。
- `src/app.js` 將既有 artwork adapter 接到 Home shell。`src/ui/app-shell.js` 讓播放歷史 `workId` 經 resolver 取得 artworkRef，再走既有 provider adapter；圖片失敗回到來源 fallback，不猜測 URL。
- Home 主視覺與最近六筆播放紀錄可呈現 provider 圖片；測試 fixture 有明確測試 adapter 標記，不冒充 live artwork。
- Home history 重繪改用列表事件委派，避免每次重繪都保留舊列 listener。
- 清除 `ui-shell.css` 中已無 DOM owner 的 Home pie／舊 Home copy CSS；CSS contract 改為保護新 Home 與防止舊 selector 回流。
- Home 空紀錄最近學習區改為內容高度，降低無紀錄時的巨大空白。

## 驗證證據
- `python tests/batch262-home-catalog.browser.py`：47/47，1920×1080、1440×900、1024×768、390×844。
- `python tests/batch262-home-artwork.browser.py`：10/10，fixture 驗證 adapter 注入、主視覺圖片、兩筆最近紀錄圖片與 provider traceability。
- `python tests/app-shell.browser.test.py`：144/144。
- `node tests/source-runtime.integration.test.cjs`：PASS；AMQ 38,821、EMQ 16,839、MIX 55,660，含明確 workId mapping。
- `node tests/app-shell-navigation.contract.test.cjs`：2/2；`node tests/skin-theme-adapter.test.cjs`：20/20；`node tests/catalog-browser.test.cjs`：6/6；Catalog integration PASS；`node tests/ui-shell-css.contract.test.cjs`：8/8。
- `node tools/check-architecture.cjs`：1,293 PASS／0 FAIL；JS/CJS syntax 186/186；Python AST 24/24。

## 尚未驗收／阻塞
- 全量 92 檔 Node suite 的執行遭工具時間窗口中斷，沒有完整 aggregate summary；不得宣稱全量通過。
- 外部 ANN／VNDB live network、實際封面成功載入、HTTP-origin IndexedDB、Windows／實機未驗收。
- `artifacts/batch262-home-catalog/catalog-1920x1080.png` 仍是 opaque-origin IndexedDB error state，不能作正常 Catalog 載入畫面證據。
- Home 仍有大面積主視覺留白，osu! 視覺驗收未通過。

## 下一批建議
1. 在可用 HTTP-origin 測試環境驗證正式 Catalog 資料載入與 ANN/VNDB 圖片請求；若 loopback 仍被政策阻擋，記錄阻塞後繼續。
2. 建立獨立的正常 Catalog data fixture 截圖，與 opaque-origin error 截圖分開命名。
3. 以同尺寸 osu! Client Interface 參考逐項收斂 Home／Catalog 的構圖、作品視覺與密度；不要用 fixture 通過視覺驗收。
4. 繼續 Quiz／Settings／Results 的正式頁面視覺切片，保留 `docs/UI_COPY_POLICY.md`。
