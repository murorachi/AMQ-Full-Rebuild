# Batch272 Handoff：Multiplayer Lobby 視覺切片與 Skin 映射

## 本批已實作
- 以 `artifacts/osu-reference/osu-multiplayer-lobby.jpg` 作視覺依據，將正式 `#multiplayer-panel` 從單純表單重整為遊戲客戶端式 Lobby 結構：標題／狀態、來源分頁、搜尋與進行中篩選、房間清單、加入房間、建立房間。
- 保留 `src/ui/multiplayer-panel.js` 唯一 server/client/session owner，房間清單只取自 `client.listRooms()`，沒有塞入假房間。
- 新增來源篩選 All/AMQ/EMQ/MIX、房間搜尋、只看進行中的房間。狀態由 server response `source`、`phase`、`playerCount`、`maxPlayers`、`revision` 驅動；進行中判定依目前 state machine 的 `phase === "round"`。
- 保留既有建立、更新大廳、代碼加入、房間準備／開始／關閉／離開、回合／答題操作 ID 和 handlers；沒有複製 room state。
- `docs/skin-contract/amq-skin-role-manifest.v1.json`、`src/skins/skin-contract.js`、`src/skins/theme-adapter.js` 新增 `multiplayer.lobby.tab`、`multiplayer.lobby.room-list`、`multiplayer.lobby.create-room` 三個穩定元件角色及 token consumer。
- 以 `src/styles/ui-design-landing.css` 原有 Multiplayer 區塊替換為集中式 Lobby 視覺規則，沒有再疊加另一段 override。保留 `src/styles/ui-shell.css` 中的音訊／錯誤／準備狀態語義樣式。
- 新增 `tests/batch272-multiplayer-lobby-visual.contract.test.cjs`、`tests/batch272-multiplayer-lobby.browser.py` 與 `artifacts/batch272-multiplayer-lobby/` 四尺寸截圖及差距表。

## 驗證證據
- Focused Node tests：Multiplayer、Skin、CSS、房間 session/state 相關 tests 共 67/67 PASS（含 `multiplayer-panel.integration.test.cjs`、`skin-theme-adapter.test.cjs`）。
- Chromium browser geometry：`python tests/batch272-multiplayer-lobby.browser.py`：32/32 PASS，涵蓋 1920×1080、1440×900、1024×768、390×844；四尺寸均無水平 document/panel overflow，無 page errors。
- 截圖為正式 DOM/CSS 的空房間清單狀態，沒有 fake server rows；不是 live server/auth E2E 證據。並排對照圖：`artifacts/batch272-multiplayer-lobby/comparison-1920x1080.jpg`。
- Architecture checker：`node tools/check-architecture.cjs` 輸出 1,328 PASS／0 FAIL。JavaScript/CJS `node --check` 200/200 PASS；Python AST 30/30 PASS。
- 全量 `node --test tests/*.test.cjs` 超過本次執行時間窗口被中止；輸出未取得完整 aggregate summary，因此全量 Node suite 狀態為未驗證。中途曾發現舊 Batch265 CSS contract 仍期待舊青綠邊框，已更新為新 Lobby 粉紅邊框並納入最終 focused 67/67。
- 參考圖視覺差距表：`artifacts/batch272-multiplayer-lobby/visual-gap-table.md`。
- Mod owner audit：目前未找到 canonical Mod registry/state/multiplier/audio transformation owner，因此沒有造出假 Mod overlay 或倍率。
- 依 `docs/ARTIFACT_ARCHIVE_INDEX.md` 精簡交付包歷史產物：保留目前 tests 直接讀取的 Batch245/252 fixtures、最新 Batch270/272 截圖及 Stable 參考圖；其他舊批次 raw logs／重複截圖不再全部複製。

## 未完成／阻塞
- osu!stable 參考圖包含玩家頭像槽位、房間內地圖／歌曲縮圖、聊天區與底部 Back/New Game/Quick Join；目前 server room summary/API 不提供足夠欄位，且沒有 chat owner。本批只完成由真實 API 欄位支援的切片，這些差距仍開啟。
- 未執行登入狀態下的 live multiplayer HTTP E2E；未驗證多人音源投影／完整多人聽歌流程。
- 沒有 AMQ Mod owner，Reverse、Beat Shuffle、Fade Out、Vocal Only、Background Only 仍需先定義唯一規則、互斥與 audio owner。
- Home/Catalog 真實 artwork、正式曲庫、HTTP-origin IndexedDB、全量 Node suite、Windows／實機與人工 osu! 視覺 gate仍未驗收。不要宣稱整個產品已達 Stable fidelity。

## 下一批建議
1. 先補多人 UI 與 server response 的 traceability，決定是否要正式擴充 room summary API 以提供可驗證的玩家槽位／房間狀態欄位；不需要時保持現況。
2. 優先完成 Home/Catalog 尚未關閉的 P0 真實 artwork／正式資料視覺差距，並取得可用環境的正式資料證據。
3. 若要開發 AMQ Mods，先獨立設計並測試 canonical Mod registry/state/multiplier/audio owner，再實作 overlay；不可把它當純 UI 工作。
4. 逐角色驗證新三個 Skin roles 的 apply/fallback/reset，補齊 OSK Mapping Studio 視覺證據。

## 封裝規則
- 交付 ZIP：`AMQ_Full_Rebuild_Batch272_Multiplayer_Lobby_UI_20261030.zip`。
- `MANIFEST.sha256` 635 個檔案逐檔驗證通過；ZIP integrity check 無錯誤。
- 本工作目錄沒有 Git repository；未初始化 Git，未覆寫 Batch271 ZIP。
- 原始 `references/osu-master.zip` 保留不變，SHA-256 仍為 `973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`。
