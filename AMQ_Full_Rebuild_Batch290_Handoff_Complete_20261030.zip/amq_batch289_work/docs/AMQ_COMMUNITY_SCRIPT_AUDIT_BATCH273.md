# AMQ 社群腳本參考稽核（Batch273）

日期：2026-10-30  
來源：使用者提供的 `AMQ-Scripts-master(1).zip`，封存副本 `references/AMQ-Scripts-master.zip`  
SHA-256：`76fc073a51da180d087ba4c6636b22531053ed5b1affeb5a8330e7de7c4aad04`  
ZIP：97 entries；CRC integrity check：PASS。

## 定向檢視

| 檔案 | 觀察到的實際做法 | 對新版 AMQ 的用途 | 不直接移植的原因 |
|---|---|---|---|
| `gameplay/amqAnswerTimesUtility.user.js` | 監聽 `player answered`，讀取 `answerTime` 並轉成毫秒保存 | 參考多人作答時間的事件來源與單位轉換 | 事件名稱／payload 由舊官方 runtime 定義；新版必須使用自己的 protocol contract |
| `gameplay/amqPlayerAnswerTimeDisplay.user.js` | 監聽 `player answered` 與 `player answers`，從 `quiz.players` 取得玩家資訊，並呼叫答案輸入與 timer UI 的內部方法 | 明確指出玩家答案、作答時間、回合進度可能分屬不同事件 | 直接依賴 `quiz.players`、`quiz.answerInput`、`quiz.videoTimerBar` 等內部物件，耦合度高；不可複製成新版 API |
| `gameplay/amqAutocomplete.user.js` | 監聽鍵盤事件，修改 `AmqAwesomeplete`／答案輸入 prototype，處理提交與候選項目 | 參考答案輸入、候選項目及快捷鍵衝突的測試情境 | prototype patch 與全域 keydown 可能和新版輸入狀態、快捷鍵管理器衝突；新版優先使用既有 `src/ui/answer-suggestions.js` 與 Quiz owner |
| `gameplay/amqNoDropdown.user.js` | 覆寫 `AutoCompleteController.prototype.newList` 並新增鍵盤處理 | 提醒 dropdown 顯示與鍵盤導覽需作為同一互動契約驗收 | 直接覆寫官方 prototype 不適合作為新版架構 |
| `design/amqBackground.user.js` | 以大量 selector 與 prototype hook 建立自訂背景，覆蓋多頁面及聊天區 | 提供背景映射需求清單，支持按頁面／區域分配 Skin role | 全域 CSS／DOM hook 範圍廣，容易蓋掉 UI；新版應經 Skin Registry、resolver 和穩定 component ID |
| `design/amqSimpleBackground.css` | 透過 CSS variables 控制多頁面背景與聊天背景 | 參考背景分區與可配置變數的簡單模式 | 不直接沿用外部 URL 或全域覆寫；須保留資產驗證、fallback 與來源政策 |

## 實作決策

1. 不將社群腳本直接注入正式 runtime；只保留原始 ZIP 作可追溯研究來源。
2. Quiz 作答時間／玩家答案顯示應先核對 `src/multiplayer/protocol.js`、`src/multiplayer/room-session.js` 與 `src/ui/multiplayer-panel.js`，只使用新版明確提供的資料欄位。
3. 自動完成與下拉選單要驗證輸入焦點、方向鍵、Enter、Escape、錯誤後清空與快捷鍵衝突；避免 prototype patch。
4. 背景映射必須落在 Skin Registry 的穩定 component ID，並經同一套 asset apply/fallback/reset；不可讓社群腳本式全域 CSS 成為第二套 Skin 系統。

## 限制

本次是對指定六個檔案的定向檢視，不是 97 個項目的完整安全審計，也沒有把這些腳本執行於官方 AMQ 網站。沒有驗證其目前仍相容於官方 runtime。這些腳本不是官方完整原始碼。
