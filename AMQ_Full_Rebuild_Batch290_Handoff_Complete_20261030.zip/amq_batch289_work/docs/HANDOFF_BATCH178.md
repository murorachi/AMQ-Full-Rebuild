# Batch178 交接：Backup/restore 與 SRS 相容性

## 完成內容
- `tests/backup-restore.test.cjs`：新增重複匯入相同 backup 的 idempotency 測試，並驗證 custom-list extension metadata 原樣保留。11/11 scenarios PASS。
- `tests/srs-store.test.cjs`：新增未知頂層／card extension 欄位在其他設定變更後仍保留的測試。20/20 PASS。
- 未找到可重現 P0/P1 production defect，因此未修改 `src/`。
- 71 個 Node tests、backup panel 8/8、Remote SRS Bridge 12/12、History Store 21/21、AudioService 22、QuizSession 25/25、architecture 1,051/0、OSK 12/12、160 syntax checks 均通過。
- 證據在 `artifacts/batch178-regression/`。

## 限制
Candidate302／Candidate382 Stage 0 原始檔缺席；真實瀏覽器音訊、ANN API／CORS／封面、真實 OSK、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。

## 後續
Batch179 已接續處理 database update active-read stale snapshot race，詳見 `docs/HANDOFF_BATCH179.md`。
