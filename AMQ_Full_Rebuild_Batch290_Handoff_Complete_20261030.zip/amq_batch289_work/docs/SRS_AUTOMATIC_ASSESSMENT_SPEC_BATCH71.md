# 全域 SRS 自動評估與選題設計契約（Batch 71）

本文件是 `docs/PRODUCT_SCOPE_DECISIONS_BATCH71.md` 的 SRS 技術補充。它定義模組責任與資料流，不假定現有 API 名稱；實作前須核對 `src/` 的真實介面。

## 模組責任

1. `AssessmentEngine`（新增或擴充既有純函式模組）：將單題行為事件轉成版本化評級建議與原因碼。不得讀寫 DOM、Storage 或直接修改 scheduler。
2. `SrsPolicy`（純函式）：判斷全域 SRS 是否啟用，決定 SRS 對選題與統計的影響。關閉時保持非 SRS 行為。
3. `QuizSelector`／現有 QuizPool：先套用 eligibility，再用 SRS metadata 排序／抽樣；不得複製 Catalog 或另建歌曲身份系統。
4. 現有 FSRS scheduler：只負責根據 rating 與既有排程計算下一次複習；不負責判斷答案好壞。
5. 現有 SRS store：唯一持久化來源，保存 schedule、rating provenance、規則版本與必要依據。
6. Statistics projection：由 SRS store 與 history 的可用紀錄計算顯示數字，不維護獨立真相計數器。
7. UI：呈現全域開關、自動建議／原因、手動評級與統計；不自行實作評級門檻或選題算法。

## 建議資料契約（實作前與現有 schema 對齊）

`assessment` 至少包含：
- `sourceKey`：source-aware song identity。
- `rating`：scheduler 支援的評級枚舉。
- `origin`：`automatic` 或 `manual`。
- `ruleVersion`：自動評估規則版本；手動評級可記錄採用的 UI/schema 版本。
- `reasonCodes`：有限白名單，例如 `incorrect_answer`、`skipped`、`correct_slow`、`correct_fast`、`multiple_attempts`、`used_hint`、`replayed_audio`、`manual_override`。
- `signals`：只保存確實有紀錄且必要的有限訊號；不要保存整段原始互動事件或無界歷史。
- `createdAt`、`questionId`（若現有資料模型有穩定 ID）、`mode`、`source`。

不得在缺少證據時把 `used_hint` 或 `replayed_audio` 設為 false；應用 `unknown`／欄位缺席區分「沒有發生」與「沒有記錄」。

## 自動評估初版規則要求

規則應是 deterministic、版本化、可測試的決策表，而不是隱藏在 if-else UI handler。先定義事件優先序：

- 跳過／放棄，或答案錯誤且回合結束：強烈的低熟練訊號，通常建議 Again。
- 答對但有多次錯誤嘗試、提示或多次重播：降低 rating 建議，不得視為無提示快速答對。
- 答對但延遲高於慢速門檻：建議 Hard 或 Good，依現有 scheduler 的 rating 語義決定。
- 答對、低延遲、無已知提示／額外嘗試：可建議 Easy；若提示／重播訊號未知，不可假定完全無提示。
- 中途取消、音訊未成功播放、資料／計時器錯誤：不自動評級，避免把環境故障當成不熟悉。
- 若無可靠的 latency 或 interaction telemetry：使用可用訊號降級評估，並記錄 `insufficient_signals`，不編造時間或操作事件。

具體時間門檻、rating 對應及權重在核對現有 scheduler 語義後定義並寫成 fixtures；不得只憑主觀猜測直接寫入正式排程。

## 選題排序要求

- 硬性 eligibility 一律先於 SRS 排序。
- 在符合條件的歌曲內，考慮到期狀態、逾期程度、近期評估與新題比例。
- 新題比例、隨機種子／抽樣策略、同回合去重與來源公平性都必須可測試。
- SRS disabled 時不得因任何 schedule metadata 改變一般抽樣結果的 eligibility；不要刪除 schedule。
- fallback 必須有界，不得對空候選池重複抽取或阻塞模式切換。

## 測試矩陣最低要求

- 自動評估：錯答、跳過、快速答對、慢速答對、多次嘗試、未知提示狀態、重播、音訊失敗、取消、缺失 latency、時間邊界、規則版本。
- 手動評級：覆寫自動建議、保存來源、保存失敗、重新開題後狀態、後續自動建議可恢復。
- Toggle：開啟／關閉／重開、reload 持久化、關閉不刪資料、關閉不更新統計、一般 quiz 繼續工作。
- Selector：各 source、MIX 權重、黑名單、個人清單、年份／季別／難度／看番 filters、到期池不足、新題補充、同回合去重。
- Identity：AMQ ID 與 EMQ ID 數值相同但來源不同；MIX 不產生第三份 schedule。
- Storage：讀取失敗、寫入失敗、損壞資料、跨分頁更新及備份還原。

## 禁止事項

- 不建立第二個 FSRS scheduler。
- 不將「熟悉度分類」和「FSRS rating」混成同一欄位，除非先有明確、經測試的 mapping contract。
- 不把每次答題都強迫寫入 SRS；toggle-off 時必須完全不更新 SRS schedule。
- 不用假設的提示／重播資料評估使用者。
- 不因手動覆寫永久關閉自動評估。
- 不讓 UI 元件持有另一份排程或統計真相。


## Batch 72：四級自動評估定案（使用者確認）

自動評估只看「作品標題」（猜歌目標 `anime`）。猜歌曲名稱（`title`）或歌手（`artist`）不產生 SRS 評級。若目標為 `all`，只看 `correctByTarget.anime`，歌名與歌手正誤完全不影響評級。

| 條件 | FSRS 評級 | 原因碼 |
|---|---:|---|
| 作品標題答錯／超時 | 1 | `work_title_incorrect` |
| 作品標題答對，0–10 秒（含 10 秒） | 4 | `work_title_correct_fast` |
| 作品標題答對，超過 10 至 15 秒（含 15 秒） | 3 | `work_title_correct_medium` |
| 作品標題答對，超過 15 秒 | 2 | `work_title_correct_slow` |
| 沒有可靠計時、未作答揭曉、未播放跳過／取消 | 不評級 | 對應 `insufficient_latency`／`no_work_title_answer` |

規則版本為 `work-title-latency-v1`。保持現有 FSRS-6 原生四級與公式不變。自動評級在既有 SRS 複習回合內執行；使用者仍可在同一題手動覆寫，自動結果會被替換而不是重複計算一次複習。評級來源、規則版本與原因碼寫入既有 SRS 卡片，不建立第二份排程或 store。

注意：這是 Batch 72 的評估切片，**不代表全域 SRS 開關及一般 AMQ／EMQ／MIX 出題整合已完成**；其餘項目仍留在主清單。
