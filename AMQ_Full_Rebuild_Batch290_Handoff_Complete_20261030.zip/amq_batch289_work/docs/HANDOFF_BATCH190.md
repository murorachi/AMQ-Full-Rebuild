# Batch190 交接：備份／還原與作品學習進度

日期：2026-10-28
工作副本：`/mnt/data/amq_batch189/amq_batch153_work`（由 Batch189 ZIP 解壓；無 `.git`，未初始化）

## 本批完成

- 檢查既有 `src/persistence/backup-restore.js` 與 `src/ui/backup-restore-panel.js`。既有流程已涵蓋匯出 JSON 下載、檔案讀取、50 MB 限制、預檢、確認／取消、提交失敗回滾狀態、stale preflight、還原互斥與 preflight no-write；未另造第二套備份／還原寫入流程。
- `src/ui/backup-restore-panel.js` 新增 `amqSongTagsV1` 的使用者可讀標籤「歌曲標籤與歌曲關聯」。`src/index.html` 備份說明同步列出歌曲標籤與看番狀態。
- `src/learning/statistics-dashboard.js` 新增作品層級衍生進度，依 source + workKind + animeId 分組，沒有 animeId 的舊紀錄才退回以來源 + 正規化作品標題分組。提供作答次數、答對／答錯、正確率、不同歌曲數與最近作答時間。資料不另行持久化。
- `src/ui/statistics-dashboard-panel.js` 與 `src/index.html` 新增「作品學習進度」區塊，顯示練習作品總數、作答總量與前 8 個作品。明確區分作品答題進度與歌曲熟悉度。
- AMQ／EMQ 相同數字作品 ID 仍按來源分開，沒有新增資料 key 或改動曲庫。

## 修改檔案

- `src/ui/backup-restore-panel.js`
- `src/index.html`
- `src/learning/statistics-dashboard.js`
- `src/ui/statistics-dashboard-panel.js`
- `tests/backup-restore-panel.test.cjs`
- `tests/statistics-dashboard.test.cjs`
- `tests/statistics-dashboard-panel.test.cjs`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- 新增本檔及 `artifacts/batch190-regression/`

## 驗證證據

- 74/74 個 `tests/*.test.cjs` 檔案 exit 0；逐檔記錄在 `artifacts/batch190-regression/node-tests.tsv`、`node-tests.json` 及 `node-tests/`、`status/`。總控執行觸及外層時限後，剩餘未記錄測試分批執行，最終 74 個 status 全部為 0。修改後的三個相關測試再次獨立執行：Backup panel 8/8、Statistics projection PASS、Statistics panel PASS。
- Architecture Checker：1,095 PASS／0 FAIL，`artifacts/batch190-regression/architecture.log`。
- OSK import panel harness：12/12，`artifacts/batch190-regression/osk-harness.log`。
- 170 個 JS/CJS `node --check` PASS，`artifacts/batch190-regression/syntax-checks.json`。
- AMQ 資產 SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`。
- EMQ 資產 SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 未驗收／限制

- 真實瀏覽器的下載／選檔／預覽與作品進度版面未實機驗收；先前 Chromium headless 啟動失敗的限制仍存在。
- HTTP-origin IndexedDB、真實音訊、ANN API／CORS／封面、真實 `.osk`、viewport／鍵盤與正式 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- Candidate302 正式維護基準、Candidate382 Stage 0 CSS 比較基準原始檔不在交付副本；沒有 hash 或相容性聲稱。
- 無 `.git`，未初始化。原始基準未覆蓋，AMQ／EMQ 資產唯讀。

## 下一批

Batch191 優先做播放器視覺化：檢查既有 Free Player Dock 與 AudioService，將播放狀態、目前歌曲、進度、時間、播放模式、ended／pause／error 轉成清楚的視覺回饋。沿用既有單一 AudioService owner，不新增平行播放狀態或直接操作 HTMLAudioElement。同步測試與更新工作清單。
