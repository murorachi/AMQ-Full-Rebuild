# Batch276 Handoff：Artwork provider wiring + Catalog load lifecycle

## 本批實作
- Catalog row/detail artwork 不再把「收到 URL」誤當成「圖片已載入」。圖片 `load` 前保持 `loading` 並保留可讀 fallback；成功 `load` 後才設 `available`、隱藏 fallback、顯示 source attribution link。圖片 `error` 會移除 image 與 stale source link，恢復 title-derived fallback。
- 新增 `createArtworkSourceLink()`，只接受 HTTPS source URL；attribution 只在圖片確實 load 成功後顯示。
- `src/app.js` 先前沒有建立 AniList client/feature，雖然 factory 有 AniList fallback 分支，但 production composition 沒有提供 adapter。現在 app 在 `anilistAdapter` 存在時建立 `externalServiceAdapter` AniList client 與 feature adapter，傳給 artwork provider factory。ANN 仍優先，AniList 只在無 ANN 圖且有明確 crosswalk 時 fallback。
- Crosswalk/chinese-title provider 改由 `artwork-provider-factory` 建立並持有，透過 provider bundle 提供給 Catalog 共用；provider bundle dispose 時負責釋放。`src/app.js` 不再直接讀 `AMQData`，Architecture checker 保持通過。AniList adapter 是 optional，缺失時不會關閉 ANN/VNDB artwork pipeline。

## 驗證
- Node 98 個 `*.test.cjs` 分 20 組，20/20 groups exit 0、306/306 subtests PASS。分組 log `artifacts/batch276-regression/node-groups/group-01.log` 至 `group-20.log`；摘要 `artifacts/batch276-regression/node-suite-summary.json`。
- Focused Node（Catalog artwork lifecycle、provider factory、app artwork lifecycle、ANN/artwork adapters、Skin/CSS contracts）52/52 PASS，`artifacts/batch276-regression/focused-node.log`。
- Home/Catalog browser 85/85；Home artwork fixture 14/14；Multiplayer Skin roles apply/fallback/reset/scope 5/5，0 page errors。
- Architecture 1,335 PASS／0 FAIL；JS/CJS syntax 192/192；Python AST 36/36。

## 尚未解決
1. Live ANN/VNDB/AniList network response、CORS/rate-limit 與實際作品封面仍未在正式 app browser 驗收。Factory fixtures 不能冒充 live provider success。
2. IndexedDB app-origin save/reload：HTTP 與 HTTPS localhost app navigation 都遭 `ERR_BLOCKED_BY_ADMINISTRATOR`，阻擋發生於 document load 前。不得重試相同 probe 或繞過政策。需要批准的 browser/CI runner。
3. 人工 osu! Stable visual gate、外部 AMQ/EMQ 可聽音訊、Windows／實機鍵盤／觸控仍未驗收。

## 下一批 Batch277
- 若有批准 browser/CI runner，優先完成正式 app-origin persistence 與 live artwork provider acceptance。
- 若 browser origin 仍不可用，完成 provider-specific diagnostics、真實 Catalog data binding contract、錯誤碼與 source attribution 報告，不以 fixture 取代 live evidence。
- 先讀 `docs/NEXT_SESSION_PROMPT.md`，不要重做 Batch275/276 已驗收功能。
