# AMQ Batch112 交接：私人伺服器 SQLite 一致性備份

日期：2026-10-28

## 本批成果

- `tools/backup-private-server.cjs <source.sqlite> <new-backup.sqlite>` 使用 SQLite `VACUUM INTO` 建立一致性 snapshot，不直接複製可能仍在寫入的 live DB 檔案。
- 備份拒絕 source/output 同路徑、拒絕覆蓋已存在的目的檔；以 hard link 或 exclusive copy 建立最終目標，避免靜默覆蓋。
- 備份後驗證 `PRAGMA integrity_check`、`PRAGMA foreign_key_check` 與 `users`、`sessions`、`srs_schedules` 必要表。
- 輸出 SHA-256、bytes 與必要表筆數；POSIX 備份檔設為 0600。
- `tools/verify-private-server-backup.cjs <backup.sqlite>` 可離線重新驗證，不會自動還原或覆寫線上 DB。
- `tests/private-server-backup.test.cjs` 覆蓋真實 SQLite snapshot、資料筆數、離線 verifier、拒絕覆蓋、同路徑及損壞來源。

## 使用方式

```sh
node tools/backup-private-server.cjs runtime-data/amq.sqlite backups/amq-2026-10-28.sqlite
node tools/verify-private-server-backup.cjs backups/amq-2026-10-28.sqlite
```

備份包含帳號、個人 SRS 與 session token hash，必須保密。Windows 部署另需限制 NTFS ACL。這不代表 restore procedure、加密、異地複寫或災難復原已完成。

## Targeted tests

```sh
node --test tests/private-server-backup.test.cjs
```

結果：2/2 PASS。Node 22.16 仍顯示 `node:sqlite` ExperimentalWarning。

## 下一步

1. 全量執行非-tooling tests、tooling tests、architecture check、JS/CJS syntax、source audit、mapper、5-run benchmark。
2. 確認 AMQ／EMQ 唯讀來源 hash 不變。
3. 重新產生 Manifest／ZIP，驗證 CRC、檔案集合、SHA-256 且不含 `.pem`。
4. 繼續多人 server transport／room lifecycle、Google account link/unlink（不得 email 自動合併）、遠端 SRS offline/conflict handling 與外部 service feature adapters。真實瀏覽器／音訊驗收留到使用者最後集中執行。


## 最終全量驗證

- 50/50 非-tooling test scripts PASS；tooling 13/13 PASS。
- Architecture 794 passed／0 failed；JS/CJS syntax 120/120 PASS。
- Source audit／mapper／5-run benchmark PASS。
- Batch111 server integration 5/5 PASS；Batch112 backup tests 2/2 PASS。
- AMQ／EMQ 唯讀來源 hash 與 Batch110／111 一致，見 `docs/WORK_STATUS.md`。
- Validation logs：`/mnt/data/amq_batch112_validation_logs/`。
