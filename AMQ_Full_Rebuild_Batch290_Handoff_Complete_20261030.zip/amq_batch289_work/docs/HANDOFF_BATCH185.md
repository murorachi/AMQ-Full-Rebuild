# Batch185 交接：QuizSession 同步重入與舊回合遲到回呼

## 本批完成
- `src/engine/quiz-session.js` 新增 `mutateEngine()`：QuizSession 自己發起的 engine state mutation 不會在 `engine.publish()` 期間同步向外部 Session subscribers 發出中間通知；呼叫者完成後仍由既有通知點發布完整狀態。
- `persistProgress()` 使用同步 `persistenceInProgress` guard 包住 familiarity／history adapters。adapter callback 期間重入 Session mutation 回傳 `persistence-in-progress`，不會跳過另一個 store，也不會重複提交。
- `tests/quiz-session.test.cjs` 新增三個 controlled regression：
  1. listener 在 answered snapshot 通知後 reset，兩個 store 已各寫入一次，reset 最終狀態不被外層答題操作覆蓋。
  2. familiarity adapter callback 內重入 reset 被拒絕，history store 仍正常寫入。
  3. 舊回合音訊 Promise 在 explicit restart 同一歌曲後完成，不能覆寫新回合 message／phase。
- 沒有改 `playbackEpoch`／`playAttemptId` 實作，因現有 epoch 與 question identity guard 已通過跨 explicit restart 的 stale completion 測試。

## 測試證據
- QuizSession：34/34 PASS，`artifacts/batch185-regression/quiz-session.test.cjs.log`。
- 73 個 `tests/*.test.cjs`：73/73 exit 0、0 fail。逐檔狀態 `artifacts/batch185-regression/node-tests.tsv`；逐檔日誌在 `node-tests/`。`quiz-pool.test.cjs` 首輪執行碰到外層限制，獨立以 90 秒 timeout 重跑，10/10 PASS。
- Architecture Checker：1,080 PASS／0 FAIL，`architecture.log`。
- OSK harness：12/12，`osk-panel.log`。
- `src/`、`tests/`、`tools/`、`server/`、`prototype/` 共 168 個 JS/CJS `node --check` PASS，`syntax-summary.txt`。
- 曲庫 hash 與 Batch184 ZIP 相同，`asset-sha256.txt`。

## 修改檔案
- `src/engine/quiz-session.js`
- `tests/quiz-session.test.cjs`
- `AI_START_HERE.md`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `docs/HANDOFF_BATCH185.md`
- `artifacts/batch185-regression/*`

## 尚未驗收／限制
- 真實瀏覽器音訊／UI、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤及正式 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- 無 `.git`，未初始化；正式基準原始檔缺席。
- 尚需測試 `skip()` 的 stop event 與 `nextQuestion()` 中止音訊期間的 listener reentry；詳見 Batch186 prompt。

## Batch186
1. controlled test 覆蓋 skip／nextQuestion／reset／endRound 的 AudioService callback reentry。
2. 只修可重現 P0/P1，保留單一 playback owner、熟悉度規則與 `playAttemptId`／`playbackEpoch`。
3. 評估具名多組曲庫篩選預設的最小安全接法，沿用既有 App Settings state。
4. 全量回歸、更新工作清單並交付 ZIP／SHA-256。
