# Batch227 交接：移除 Quiz question-card 全域舊樣式島

日期：2026-10-29
工作副本：`/mnt/data/amq_batch227_work/project`
來源交付：`AMQ_Full_Rebuild_Batch226_Multiplayer_Round_Results_Mobile_UI_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch227_Quiz_Card_CSS_Replacement_20261029.zip`

## 開工檢查與基準

- 已讀 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、Batch226 handoff／next prompt、架構、Wiki traceability、OSK role audit 與 leaderboard trust contract。
- 工作目錄沒有 `.git`，未初始化。Candidate302 正式維護基準與 Candidate382 Stage 0 CSS 比較基準原始檔缺席，不宣稱相容、不覆蓋舊基準。
- AMQ／EMQ 靜態資料資產唯讀，SHA-256 維持原值。

## 本批實作：真正替換舊 CSS，而非只疊一層

- `src/styles.css`
  - 移除全域 `.quiz-question-card` 的白底／12px 圓角／通用邊框舊規則。
  - 移除 `.quiz-question-card .notice` 的舊 margin 規則；現有 quiz notice 由正式 shell 的 `#quiz-message` 規則管理。
- `src/styles/ui-shell.css`
  - 移除 quiz question card／history／SRS／learning metrics 的 legacy override group 中不必要的 `!important`。
  - 為 `#multiplayer-panel .quiz-question-card` 加入明確 padding、border、radius、dark surface 與 shadow；原本依賴 global `.quiz-question-card` 的 multiplayer room detail／round card 現在由正式 UI shell 擁有完整樣式。
  - 保留 `#quiz-panel .quiz-question-card` 專屬答題舞台視覺層級與皮膚 background layering。
- `tests/quiz-ui-state.contract.test.cjs`
  - 驗證全域舊 `.quiz-question-card` 規則確實移除，multiplayer card 由 shell 明確接管，且 override group 不再使用 `!important`。
- `tests/app-shell.browser.test.py`
  - 驗證多人卡片 padding／border／radius／dark gradient；驗證 quiz history、SRS 與 learning metrics 在移除舊 `!important` 後仍保持正式暗色 UI。
  - 輸出位於 `artifacts/batch227-regression/`。

## 驗證結果

- Node test files：81/81 PASS，逐檔日誌位於 `artifacts/batch227-regression/node-tests/`。
- Chromium formal shell：119/119 PASS；無 uncaught browser exceptions；桌面／390px 手機結果、猜歌、多人與學習中心 UI 沒有水平溢位。
- Architecture Checker：1,165 PASS／0 FAIL。
- 167 個 `src/`、`tests/`、`tools/` JS/CJS `node --check`：PASS。
- 3 個 Python browser test `py_compile`：PASS。
- AMQ／EMQ 靜態資料 SHA-256 未變，見 `artifacts/batch227-regression/asset-hashes.txt`。
- ZIP CRC、manifest hash、缺漏／額外檔案及 ZIP SHA-256 在交付前另行驗證。

## 尚未驗收／阻塞

- HTTP-origin IndexedDB persistence/reload：Chromium loopback `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變，本批不重試；真實 save/reload assertions 未執行。
- 真實 `.osk`、live 曲庫／封面 API／音訊、Candidate302／Candidate382 Stage 0 相容性、完整實機視覺與互動驗收仍未完成。
- 全球排行榜仍無可信 backend owner，不產生虛構 PP／排名／PB。
- UI 主線仍未結案；本批只完成 question-card 舊 CSS 島的實際替換，不代表全產品 UI 完工。

## 下一批

依 `docs/NEXT_SESSION_PROMPT.md`：繼續移除另一組已確認可替換的舊 CSS island，優先盤點 quiz answer form input 的 global `!important` palette 依賴，先證明每個 input 都由正式 shell 覆蓋後再移除 legacy rule；不要大範圍刪除共用樣式或影響 Settings／Catalog。
