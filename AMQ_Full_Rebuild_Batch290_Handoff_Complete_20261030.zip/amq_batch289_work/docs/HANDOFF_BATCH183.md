# Batch183 交接：QuizSession 撤銷重入與播放權重新取得政策

## 本批完成
- 依 `docs/NEXT_SESSION_PROMPT.md` 檢查 playback revoke callback 中同步 listener 重入 `dispose()`、`reset()`、`endRound()` 的狀態矩陣。現有 `revokingPlayback` guard 會拒絕 reset/endRound/startRound 等 mutation；dispose reentry 可清理 session，且不會清除新 owner 的 lease。
- 強化 `tests/quiz-session.test.cjs` 的 stale auto-next regression：撤銷後手動觸發已排隊的舊 timer，不會重新取得播放權；被撤銷 session 的被動 `nextQuestion()` 與 `resumeAudio()` 也不能搶回 lease。只有明確 `startRound()` 操作會經 coordinator 正式重新取得播放權，並撤銷現有 owner。
- 本批沒有找到可重現的新 P0/P1 production defect，因此未修改 `src/`。這是由回歸測試支撐的結論，不代表真實瀏覽器音訊已驗收。

## 驗證證據
- QuizSession：31/31 PASS。
- Playback Coordinator：7/7 PASS。
- 全部 71 個 `tests/*.test.cjs`：71/71 exit 0。第一輪順序執行在 61 個 PASS 後碰到外層時間限制，剩餘 10 個測試分開執行；`artifacts/batch183-regression/node-tests.tsv` 有 71 筆 PASS，0 筆 FAIL。
- Architecture checker：1,051 PASS／0 FAIL。
- OSK import panel harness：12/12 assertions PASS。
- 專案內 164 個 `.js`／`.cjs` 檔案 `node --check` PASS。
- `src/data/assets/data.js` SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`src/data/assets/emq-data.js` SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。兩者與 Batch182 ZIP 內檔案一致。
- 詳細日誌與 summary：`artifacts/batch183-regression/`。

## 變更檔案
- `tests/quiz-session.test.cjs`：強化 revoke 後 passive action 與 explicit restart 的 lease policy assertion。
- `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`、本 handoff 與 `artifacts/batch183-regression/`：更新工作狀態與證據。
- 未修改熟悉度四級規則、`playAttemptId`／`playbackEpoch` contract、曲庫資產或正式基準。

## 尚未驗收／阻塞
- 真實瀏覽器音訊、多分頁 lease／IndexedDB、ANN API/CORS/封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。
- Candidate302 正式維護基準與 Candidate382 Stage 0 CSS 基準原始檔不在工作副本，無法做原始 hash／相容性比對。
- 工作副本無 `.git`，未初始化。

## Batch184 下一步
1. 稽核 `QuizSession` 在 `startRound()`／`reset()`／`endRound()` 中 engine listener 同步重入與 persistence adapter 重入的完整性；只處理能重現且有資料安全／核心狀態影響的問題。
2. 檢查 `playbackEpoch`、`playAttemptId` 以及 late audio event 在 explicit restart 前後是否能分辨舊播放請求。
3. 若沒有 P0/P1 缺陷，補上測試防護即可，不要為了產生 production diff 而硬改。
4. 執行全量 71 Node tests、architecture、OSK harness、164 個 syntax checks；更新同一份主清單並交付 ZIP／SHA-256。
