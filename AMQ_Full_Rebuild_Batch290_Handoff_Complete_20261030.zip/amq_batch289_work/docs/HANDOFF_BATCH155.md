# AMQ Batch155 交接文件

日期：2026-10-28  
工作副本：`/mnt/data/amq_batch153_work`  
前一批：Batch154  
本批目標：修正 Skin Adapter lifecycle 邊界，建立獨立且可取消的 artwork provider/cache 邊界。

## 開工確認
- 已閱讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH154.md` 與 `docs/NEXT_SESSION_PROMPT.md`。
- `git status --short --branch` 回報目前工作目錄不是 Git repository；沒有初始化 Git。
- Candidate302、Candidate382 Stage 0 與 `src/data/assets/data.js`／`emq-data.js` 保持唯讀。
- 可用 Node.js、Python、Chromium。HTTP-origin IndexedDB 及真實 `.osk` 仍受既有環境阻礙，未重複宣稱通過。

## 實作
1. `src/skins/theme-adapter.js`
   - 缺少 `#catalog-browser` 時 fail closed，不再將新 Skin 視覺套到 `documentElement`。
   - `dispose()` 改為冪等並永久拒絕後續 `apply()`。
   - 保留 generation guard，確保圖片 decode 尚未完成時 reset/dispose 不會讓舊請求重新套用樣式。
   - reset 仍清理歷史 root-level token，避免舊版樣式殘留，但新套用只作用於 Catalog target。
2. 新增 `src/integrations/artwork-adapter.js`
   - provider 必須由呼叫端明確注入；模組不自行發網路請求。
   - 接受現有 AniList `coverUrl`、MAL／VNDB `imageUrl` 或通用 `url` 形狀。
   - 僅允許 HTTPS 圖片 URL，拒絕 credentials 與不安全 scheme；source URL 只保留 HTTPS。
   - 以 `source + id` 做 key，支援同鍵 in-flight dedupe、bounded LRU cache、invalidate、AbortController cancellation、dispose 與 stale result guard。
   - 無 provider 或無圖片時回傳明確 `missing` 狀態，不製造假封面。
3. 更新 `src/index.html`、`tests/tests.html` script load order 與 `tools/check-architecture.cjs`。
4. 新增 `tests/artwork-adapter.test.cjs`；擴充 `tests/skin-theme-adapter.test.cjs`。

## 驗證結果
- `node --test tests/skin-theme-adapter.test.cjs tests/artwork-adapter.test.cjs`：15/15 PASS。
- 受影響回歸：Catalog、external service、skin store/transfer、OSK importer、app lifecycle 共 14 top-level groups PASS，0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- `node tools/check-architecture.cjs`：1007 PASS／0 FAIL。
- `tests/` 內 67 個 `*.test.cjs` 分成 12 個 Node 測試批次，12/12 批次均 exit 0。第一個 orchestrator 在整體 120 秒上限時停在第 9 組，之後從第 10 組續跑並核對所有 12 組日誌；摘要與各組輸出位於 `artifacts/batch155-regression/`。未將單一全包命令說成通過。
- ZIP 完整性將於交付打包時再次驗證。

## 尚未完成／阻塞
- Artwork adapter 是 provider/cache boundary，不代表封面已渲染進 Catalog。尚未有 ANN provider；現有 AniList、MAL、VNDB feature adapters 的 normalize 結果提供不同圖片欄位，已記錄並由 adapter 統一承接。後續需要明確的作品 ID/linking strategy，再接 Catalog UI。
- 尚未取得真實 `.osk`，人工 ZIP fixture 不等同真實相容性驗收。
- IndexedDB save/reload/clear 仍待允許 localhost HTTP navigation 的瀏覽器環境；先前回報 `net::ERR_BLOCKED_BY_ADMINISTRATOR`，本批沒有再重試已知被擋路線。
- 完整 osu!stable Song Select layout 與封面主導 UI 尚未完成正式整合及視覺驗收。

## 下一步
1. 為 Catalog 加上獨立 artwork view model／縮圖渲染接線，但只在存在已驗證的 artwork provider 或 record artwork URL 時顯示；無圖維持可替換的視覺 fallback，不引入空白彩色方塊。
2. 明確建立 AMQ/EMQ song -> anime/game work 的 linking contract，避免用歌曲 ID 猜作品 ID；優先利用已有 `animeId`／來源 ID。
3. 保留搜尋、篩選、排序、分頁、鍵盤操作、個人清單與學習狀態；先補測試再分層替換表格。
4. 真實 `.osk` 與 IndexedDB browser acceptance 環境可用時再完成阻塞驗收。

## 交付判定
- 已實作：Skin lifecycle fail-closed/idempotent disposal；獨立 artwork adapter boundary。
- 已測試：受影響測試、Chromium panel、architecture、67/67 Node test files 分批回歸。
- 尚未驗收：真實 `.osk`、正式 origin IndexedDB、Catalog 封面 UI 整合與完整 Song Select 視覺。
