# Batch259 Roadmap Override：UI 視覺落地 P0

本批開始，UI 視覺落地優先於新增狀態矩陣。下一批先完成正式 Home + Catalog 的實際構圖整合，並以 `docs/DESIGN_LANDING_FLOW.md` 的 Gate 5 視覺閘門驗收。只有在 Home/Catalog 的 P0 差距關閉後，才把視覺工作標記完成。

### Batch258｜Settings／Learning／Multiplayer 可見狀態矩陣（完成本地範圍）
- Route-aware Chromium matrix 96/96（首次）後增補實際 DOM 契約檢查，最終 99/99 PASS；48 visible role-route pairs apply/fallback/reset/token-scope 全部通過。
- 覆蓋 Home、Catalog、Quiz、Results、Learning、Settings；Quiz 內 Multiplayer panel owner 額外驗證。六個 route 390px 無水平溢位、ARIA current 同步、reduced-motion 可見、0 page errors。
- Architecture 1,293/0；JS/CJS 195/195；Python AST 18/18；四個 focused Node tests exit 0。全量 Node 嘗試超出命令時間窗口，未宣稱通過。
- 下一批：補 Multiplayer 可觸發 error/recovery、Learning empty/error interactions，並以分組方式完成全量 Node 測試。

# AMQ 新版重建：逐批完成路線圖（持續更新，正式交付基準已推進至 Batch258）

> 用途：把剩餘工作切成有可驗收出口的批次，供主清單與每次交接共用。這是基於 Batch243 已知缺口的工程估算，不是預先宣稱所有工作都必然在該批完成。每批開始仍需重新核對實際程式碼、測試證據與阻塞；若有新 P0/P1，先處理新證據，不為守批次編號犧牲正確性。

## 完成狀態定義
- **已驗收**：程式、測試與要求均有證據，且回歸已執行。
- **已實作未驗收**：程式存在，但必要環境／實機驗收未完成。
- **待處理**：尚未完成實作或證據不足。
- **阻塞**：有具體外部限制與證據；不得算完成，也不得阻止無依賴的工作。
- **延後**：低優先級或明確不在本輪必要範圍。

## 每批固定出口條件
1. 讀取 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、最近 handoff／next prompt 及相關契約。
2. 核對唯讀基準 ZIP SHA-256、MANIFEST、資料資產 hash、工作副本與 Git 狀態；不初始化 `.git`，不覆蓋基準，不修改 AMQ／EMQ 原始資料。
3. 先寫回歸測試，再修正；每項新 UI 角色須具備語義 target、CSS consumer、state／geometry、fallback、reset，且測試 apply／fallback／reset。
4. 執行本批 focused tests、相關 Chromium tests、全量 Node test files、Architecture Checker、JS/CJS syntax、Python compile（如有），記錄真實結果與未跑項目。
5. 更新同一份主清單、狀態、traceability、handoff、next prompt、README／AI start、證據、MANIFEST 與完整 ZIP；最後驗證 manifest 完整性、ZIP CRC 與 raw-data hash。

## 批次路線

### Batch244｜像素幾何邊界與 renderer 資源生命週期
**優先級：P1。目標：** 關閉 Canvas／edge-repeat 邊界輸入與例外清理缺口，不宣稱 native osu! fidelity。
- 安全整數、32-bit 上限、TypedArray 長度、乘法溢位及負／零／非整數幾何的 table-driven tests。
- decode reject／空 Blob／損毀 Blob、Canvas factory throw、getContext/readback/writeback throw 的錯誤碼與 ImageBitmap cleanup。
- 確認每種失敗都 fail closed，不建立超預算 output canvas，不遺漏資源 close。
- 驗收：focused renderer tests、合成 PNG Chromium tests、全量 Node／Architecture／syntax、Manifest／ZIP。
- 不做：重試已知遭 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋的相同 HTTP-origin probe。

### Batch245｜視覺角色完整盤點與 UI 覆蓋缺口分級
**狀態：已完成自動稽核工具與基礎回歸；逐角色 browser apply/fallback/reset 仍未完成。**
**優先級：P1。目標：** 把需求清單變成可追蹤、可驗收的實際 UI 清單，而非只列 Skin 檔名。
- 對每個 visual need 記錄頁面、語義 DOM selector、CSS consumer、狀態、幾何、fallback、reset、browser test 與支持狀態。
- 用程式／測試檢查 selector 缺失、沒有 CSS consumer、只存在 mapping metadata、或 fallback/reset 缺漏。
- 分成可安全接線、需要新 UI 元件、需真實 artwork/provider、受基準缺失阻塞。
- 驗收：traceability 與 runtime inventory 一致；每個未支持角色都有原因與解除條件；不亂接角色圖。

### Batch246｜Mapping Studio 真實操作閉環
**狀態：已完成本批可執行的資料完整性、套用生命週期、觸控尺寸與代表性 Chromium 閉環；全角色驗收仍進行中。**
**優先級：P1。目標：** 逐條驗證選取、預覽、套用、匯入／匯出、缺件與重設流程。
- 檢查 state-pair、@2x logical size、fit／position、失效路徑與錯誤提示。
- 檢查鍵盤焦點、busy/error/empty 狀態、觸控尺寸與窄螢幕重排。
- 只有有完整語義 consumer 的角色才加入 runtime adapter；對 apply、fallback、reset 加測試。
- 驗收：Mapping Studio Chromium regression、store/transfer/adapter tests、沒有丟失 legacy records。

### Batch247｜首頁與 Catalog UI 收尾
**狀態：已完成可在本地驗證的狀態／互動缺口；真實來源驗收仍受外部環境限制。**
**優先級：P1。目標：** 完成首頁及選歌頁可見的互動狀態與資料語義。
- 核對 loading／empty／error／retry、搜尋／篩選／排序、鍵盤選取、disabled、hover/focus/active。
- 核對作品封面真實來源、載入失敗與 fallback；不使用隨機 OSK 圖或假封面。
- 核對桌面與 390px layout、水平溢位、reduced-motion、可見焦點和觸控目標。
- 已完成：未接受 load result 的失敗狀態優先順序、query-preserving retry／single-listener regression、44px retry target 與 reduced-motion／390px Chromium 驗收；Home/Catalog 22/22、formal shell 150/150、全量 Node 90/90 files exit 0。
- 未完成：live data adapter／真實 HTTP-origin、外部 artwork provider 與真實裝置驗收仍為外部 gate。

### Batch248｜Quiz Arena 與 Results UI 收尾
**狀態：已完成本批可驗證範圍；優先級：P1。** 修正新回合開始時清除上一輪 completed-result pointer 失敗卻未回報的問題。Store 回傳 pointer-clear outcome；QuizSession 保留新回合並顯示 warning；Results note 明示 reload 後恢復的舊結果不代表本輪成績。QuizHistoryStore 27/27、QuizSession 41/41、Results contract 9/9、Quiz/Results Chromium 19/19、formal shell 150/150、Node 90/90 files exit 0、Architecture 1,279/0。
- **仍未完成：** setup／playing／answered／timeout／audio error／empty pool／cancelled／unsaved result 的完整逐狀態 browser matrix；真實音訊另列實機 gate。

### Batch249｜Settings、Learning Center、Multiplayer 與共用狀態
**狀態：已完成本批可證明的 Learning Center／SRS 修正；其他穩定契約已檢視但仍保留外部驗收。** Dashboard 現在對 AMQ／EMQ SRS 的 blocked／error／recoveryAvailable／persisted false 與 playback-history persisted false fail closed；SRS 有效替代排程成功持久化後清除記憶體 recovery warning，但保留 storage quarantine bytes。修正前兩個 regression 都能重現失敗；修正後 SRS 20/20、statistics panel PASS。全量 Node 90/90 files exit 0、Architecture 1,279/0、JS/CJS 193/193、Python 12/12、formal shell 150/150。
- Settings／Multiplayer：檢視既有 store save/error 與 command busy/rejected/focus lifecycle；未找到足夠證據支持大幅修改，避免無故重寫。
- **仍未完成：** Settings backup/restore browser E2E、Learning Center 所有 store failure combinations、Multiplayer 真實多 client E2E。

### Batch250｜持久化真實環境 gate 與備份／還原
**狀態：已完成可執行範圍；HTTP-origin gate 仍阻塞。** 確認 Chromium／origin／policy 沒有變化，因此沒有重試同類 `ERR_BLOCKED_BY_ADMINISTRATOR` probe。Backup/restore preflight、checksum、schema allowlist、rollback、rollback failure warning、stale preflight 與 busy lock 已由既有 Node regressions 證明。修正 Settings backup/restore、database update、Skin import controls 的 min-height 40px 為 44px；新 Chromium 桌面／390px 8/8，focused Node 12/12。全量 Node 90/90 files exit 0、Architecture 1,279/0、JS/CJS 193/193、Python 13/13。
- **仍未完成：** 真實 HTTP-origin IndexedDB save/reload；需環境條件實際改變。Storage fixture 回滾測試不等同真實瀏覽器持久化驗收。

### Batch251｜跨頁端到端、鍵盤焦點與觸控尺寸
**狀態：本地可執行範圍已完成。** 修正 `navigate()` 對一般目的頁 heading 呼叫 `focus()` 卻未加 `tabindex` 的缺口；補上 Settings quick-nav、統計排序、快捷鍵、reset 與 Mapping reset 的 44px target。跨頁 Chromium 45/45、formal shell 150/150、Home/Catalog 22/22、Quiz/Results 19/19、Backup/Restore 8/8；Node 91/91 files、Architecture 1,286/0、JS/CJS 194/194、Python 14/14。
- 390px Home／Catalog／Quiz／Results／Learning／Settings 無頁面水平溢位；Catalog query 跨頁保留；Settings quick-nav 保留頁內跳轉語義。
- **仍未完成：** 35 wired roles 逐角色 browser apply/fallback/reset、13 unsupported roles、HTTP-origin IndexedDB、live provider/audio、Windows／實機與 Candidate baselines。

### Batch252｜Skin fidelity 與真實 `.osk` 相容界線
**優先級：P1/P2，依實際素材與規格可得性決定。目標：** 明確完成可實作的相容範圍，避免誇大原生相容。
- 審核 skin.ini version、@2x、動畫家族、state pair、tint/blend、songselect-top edge repeat 與各 role geometry 的證據來源。
- 對可確定的 AMQ pixel contract 加 synthetic tests；原生演算法不明時維持 unsupported 並寫出證據缺口。
- 若有合法且可讀取的真實 `.osk`，建立只含 metadata／必要測試資料的稽核；不無故複製第三方資產。
- 驗收：每項 nativeStableFidelity flag 皆與實際測試一致；沒有將 Canvas integration 宣稱成原生 compositor。

### Batch253｜最終缺口盤點、交付候選與結案判定
**優先級：P1。目標：** 將必要功能與外部驗收 gate 分離，判斷能否結案。
- 逐項核對主清單：必要項目需有實作與驗收證據；已實作未驗收、阻塞、延後不得算完成。
- 檢查 UI traceability 沒有無主角色、重複狀態來源、無 consumer token 或隱藏舊 UI 冒充替換。
- 確認所有未解問題都有影響、解除條件、負責批次與是否阻擋結案。
- 重建最終 manifest／ZIP，記錄 SHA-256，確認 baseline 與原始資料未變。
- 若仍有外部環境 gate，交付「工程範圍完成、產品最終驗收未完成」而非宣稱全面結案。

## 估算與調整規則
- 已知工程工作：Batch244–250 已完成各自可執行範圍；Batch251 完成本地跨頁／可存取性回歸；Batch252 檢查 Skin 相容界線；Batch253 做最終缺口盤點與交付候選判定。
- 預估約 8–10 批才能形成完整驗收候選；若 Batch245 發現大量 UI 角色缺少真正 consumer，或需要真實 `.osk`／live provider，可能增加批次。
- 不為湊滿批次而重構穩定模組；某批若已符合驗收條件，可合併或提早結案。每次調整必須記錄理由與證據。
- HTTP-origin IndexedDB、真實音訊、live artwork/catalog、Windows／實機是外部驗收 gate，需與可在本地完成的工程項目分開統計。

## 主清單待辦（每批都需更新）
- [ ] 路線圖中的每一項都由主清單對應任務編號追蹤。
- [ ] 每批交付後重新估算剩餘批次，列出已驗收／未驗收／阻塞數量。
- [ ] 不以測試數量或批次編號替代產品完成度。


## Batch246 執行結果（2026-10-29）
- 已完成 Mapping Studio state-pair 的實際套用與 reset browser regression，新增 44px 控制項最小高度、apply busy/error/focus recovery，以及 store／transfer 超限映射數量 fail-closed。
- 全量 Node 90/90 files、275 cases；Architecture 1,279/0；JS/CJS 197/197；Python 13/13；formal shell 150/150、Home/Catalog 19/19、Quiz/Results 19/19、Canvas 15/15、Mapping Studio browser harness 成功。
- 剩餘重點：Home/Catalog 真實狀態閉環、逐角色視覺驗收、HTTP-origin IndexedDB 外部 gate、真實音訊／live artwork／Windows 與 Candidate baselines。
- 批次估算維持約 7–9 批到驗收候選，取決於 UI 缺口及外部 gate；不將阻塞項目算作已完成。


## Batch247 執行結果（2026-10-29）
- 修正 Catalog 未接受且無錯誤的 load result 被 stale shared loading 狀態掩蓋；新增 `DATA_LOAD_NOT_ACCEPTED`，並以 request-local error 正確顯示 failed／empty／retry。
- retry 保留 query，確認 reload click listener 單一；retry button computed min-height 44px，含較高 specificity 規則修正。
- Home/Catalog Chromium 22/22；formal shell 150/150；Quiz/Results 19/19；Canvas 15/15；OSK／Mapping Studio harness PASS；全量 Node 90/90 files exit 0；Architecture 1,279/0；JS/CJS 193/193；Python compile 12/12。
- 外部 gate 不變：HTTP-origin IndexedDB、live catalog/artwork/audio、Windows／實機、native fidelity 未驗收。

### Batch252 實際結果補記（2026-10-29）
- 已解析真實 `aristia hima.osk`：119 images、0 sounds、10,071,206 expanded bytes，skin.ini version `latest`；98 Mania refs 全未解析，已將樣本標記為該功能不完整。
- 新增 `tests/skin-compatibility-audit.contract.test.cjs` 與 metadata/count-only audit report；focused Skin suite 36/36 PASS；全量 Node 92/92 files、Architecture 1,293/0、JS/CJS 186、Python 14/14；Chromium shell 150/150、cross-page 45/45、Home/Catalog 22/22、Backup/Restore 8/8、Canvas 9/9。
- 不宣稱原生 compositor、版本語義、動畫或 tint 相容；Batch253 仍須核對全量測試與交付證據。


### Batch253 執行結果（2026-10-29）
- 發現並修正 Batch252 handoff 的 ZIP SHA-256 與實際交付封包不一致；正確 hash 為 `514f7dd94063105617609fc89d5ad048ee4531c62900dfe2dfa7517c7ea9be3b`。
- `tools/audit-visual-role-coverage.cjs` 現可透過 `--output-dir` 輸出到批次專屬目錄；新增測試防止新稽核覆寫歷史報告。
- 全量 Node 92/92 files、Architecture 1,293/0、JS/CJS 186/186、Python 14/14；Chromium app-shell 150/150、cross-page 45/45、Home/Catalog 22/22、Backup/Restore 8/8、Skin Canvas 9/9。
- 交付候選可供工程接續，但產品仍未結案：35 wired roles 尚未逐一 browser apply/fallback/reset、13 unsupported、HTTP-origin IndexedDB、live providers/audio、Windows／實機、native fidelity 保留為未驗收。


### Batch254｜正式 DOM 逐角色 Skin apply／fallback／reset
**狀態：本地 runtime role matrix 已驗收；產品整體仍未結案。**
- 正式 `src/index.html` inline browser harness 驗證 35/35 runtime roles 存在於掛載 DOM；逐角色 apply 35/35、missing-asset fallback 35/35、reset／URL revoke 35/35；0 uncaught page errors。
- Fixture matrix 保留作為隔離診斷，不取代正式 DOM 測試。初始 Home route 只有 4 個 target 可見，因此 route-aware 可見狀態仍需另測。
- Node 92/92 files、Architecture 1,293/0、JS/CJS 186、Python 17、正式 app-shell Chromium PASS。
- 下一批 Batch255：13 unsupported roles 語義審查與可接線項目；再做多頁可見狀態／互動驗收。外部環境 gate 繼續保留，但不包含舊版基準搜尋。


### Batch255｜Unsupported Skin 角色語義審查
- **完成：** 13 roles 逐項語義分級；focused Node 4 檔案通過；Chromium cross-page 45/45；raw data hashes 保持不變。
- **方向決策：** 新版 AMQ 獨立開發，Candidate302／Candidate382 不再是必要參考或阻塞。
- **未完成：** 3 個候選角色需精確 target／CSS consumer；35 wired roles route-aware visible-state matrix 未全覆蓋；HTTP-origin IndexedDB、live providers/audio、Windows／實機仍待外部條件驗收。
- **Batch256：** 先接線 Catalog filter panel 與 random action 的可證明元件邊界，然後增加 Settings range input role 的專屬測試。


### Batch256｜Catalog filter Skin role 精確接線（2026-10-29）
**狀態：本地可執行範圍已驗證。** 將 `catalog.filter.background` 接到 `.catalog-sidebar > .catalog-primary-controls`，新增專屬 token／CSS consumer，避免整個 Catalog 被背景覆蓋。Adapter apply/fallback/reset、target unavailable 與 manifest/audit regressions 通過。全量 Node 92/92 files exit 0、Architecture 1,293/0、JS/CJS 186/186、Python 16/16；Home/Catalog Chromium 22/22；正式 DOM role matrix 36 roles apply/fallback/reset 各 36/36、0 page errors。角色統計更新為 48 total／36 wired／12 unsupported。
- `catalog.action.random` 目前沒有 Catalog 專屬控制項／事件 owner；不錯接播放器的 random action。
- `settings.slider` 目前 Settings 頁沒有 range input；播放器音量／進度不屬於 Settings。
- **Batch257：** route-aware visible-state browser matrix，先 Home、Catalog、Quiz、Results。


### Batch257｜Home／Catalog／Quiz／Results route-aware Skin 可見狀態（2026-10-29）
**狀態：本地可執行範圍已驗收；整體產品與外部來源仍未結案。** 新增正式 DOM Chromium matrix，透過應用程式自己的導航進入每個 route；64/64 assertions PASS，32 可見 role-route pairs 的 apply／missing fallback／reset／token scope 全部 PASS。Home 4、Catalog 15、Quiz 9、Results 4 個可見角色；桌面與 390px 無水平溢位，ARIA／焦點／reduced-motion 檢查通過，0 page errors。
- 交叉回歸：cross-page 45/45、Home/Catalog 22/22、production role matrix 36/36 apply／fallback／reset；Node 92/92 files exit 0、Architecture 1,293/0、JS/CJS 186/186、Python 17/17。
- **限制：** Results 使用真實空狀態，隱藏結果面板不計入可見 coverage。此 matrix 不等於完整人工視覺驗收或 live provider／durable storage acceptance。
- **Batch258：** 擴充 Settings、Learning Center、Multiplayer route-aware 可見狀態與 error／empty／recovery flow。
