# AMQ Batch 61 交接：Runtime dispose 同步失效化

日期：2026-10-27

## 發現與影響

檢查 lifecycle／runtime 跨模組邊界時，發現 `src/data/runtime-bootstrap.js` 的 `dispose()` 只呼叫 `repository.cancel()`。這只能取消活動請求；若 Catalog 已成功載入，dispose 後共享 state 仍會保持 `dataStatus: loaded`，但重新掛載會建立新的 Repository／load-state controller，該新 controller 沒有舊 Catalog。若正在載入，狀態也會等 Promise catch 的微任務才重設。這會產生 UI 顯示與 runtime Catalog 不一致的短暫或持續狀態。

## 實作

- `src/data/runtime-bootstrap.js`：dispose 標記終止、解除 mode subscription 後，優先呼叫 `repository.invalidate()`；只有相容注入 Repository 沒有 `invalidate()` 時才退回 `cancel()`。失效化會同步取消活動請求、遞增 generation、清空 Catalog 與共享 loaded/loading 狀態。
- `tests/data-pipeline.integration.test.cjs`：新增兩個整合測試。
  - 已載入 Catalog 後 dispose，`dataStatus` 同步回到 `not-loaded`，Catalog 為 `null`，重複 dispose 回傳 false。
  - 載入中 dispose，在 Promise settle 前同步清除 loading；忽略 abort 的來源遲到 resolve 後也不得重新發布。
- `docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`：補充 dispose 的 Catalog 所有權與同步重設契約。

## 回歸證據

- 修改前：新增兩測試使 data-pipeline integration 為 18/20，分別證明 loaded／loading 狀態殘留。
- 修改後：`node tests/data-pipeline.integration.test.cjs` 20/20 PASS。
- 全部 `tests/*.test.cjs`：25/25 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：459 passed，0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839，duplicate IDs／dangling refs／cross-source collisions 皆為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，Catalog 55,660 筆。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，僅為 Node 記憶體內量測。
- `node --check`：63 個 JS/CJS 檔案 PASS。
- 日誌位於 `/mnt/data/amq_batch61_logs/`。

## 資料與基準保護

- `data.js` SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`。
- `emq-data.js` SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 工作副本沒有 `.git` metadata；未初始化 Git、未 commit／push。未修改正式基準、來源資料或 CSS/UI。

## 尚未驗收／阻塞

- 真實瀏覽器 UI、mount-dispose-remount、響應式、鍵盤與跨分頁 storage。
- 真實音訊可聽性與乾淨 Windows 啟動。
- Candidate302／Candidate382 Stage 0 正式相容性。Candidate381 僅靜態參考；遵照指示不搜尋 Candidate302。
- `aniFavorites_v1` 身份及 legacy source-less IDs 來源未知，不做猜測式遷移。

## 下一批 Batch 62

1. 檢查 app mount／dispose／remount 的狀態與資源清理順序，找具體、可測的跨模組缺口。
2. 不重試已知失敗的 Chromium CLI 導覽方式；只有新環境或新證據才重新評估。
3. 不猜測收藏身份、source-less IDs 或 P2 行為；UI／CSS 大重構仍排最後。
4. 全量測試、更新同一份 checklist／WORK_STATUS／handoff，重建並驗證 Manifest／ZIP。
