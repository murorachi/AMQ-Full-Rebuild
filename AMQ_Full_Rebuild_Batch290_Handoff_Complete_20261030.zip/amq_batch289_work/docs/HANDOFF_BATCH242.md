# Batch242 Handoff：Canvas Pixel Pipeline Integration

## 基準與安全
- 唯讀來源：`/mnt/data/AMQ_Full_Rebuild_Batch241_Skin_Pixel_Contracts_20261029.zip`
- Batch241 ZIP SHA-256：`83c791783d6865d84e1e3dd1a9c2cc8953d1cbd7cf41629271c1517196bf1c21`
- 獨立工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch242`
- 工作目錄沒有 Git repository；未初始化 `.git`，未覆蓋 Batch241 ZIP。
- AMQ／EMQ 原始資產 hash 應維持：`data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 本批實作
- 新增 `src/skins/skin-canvas-renderer.js`：`decodeImageBlob`、`readImageRgba`、`renderToCanvas`、`renderBlobToCanvas`。有 16 MiB Blob／16 MP 預設上限、穩定錯誤碼、ImageBitmap cleanup 與 Canvas API 缺失處理。
- `src/index.html` 在 `skin-renderer.js` 前載入 Canvas module；`skin-renderer.js` 暴露 Canvas integration seam 與 `canvas-decode-read-transform-write-v1` capability。
- 新增 `tests/skin-canvas-renderer.test.cjs` 與 `tests/batch242-skin-canvas.browser.py`，測試使用生成 PNG／合成 RGBA，不包含第三方素材。
- 重新審查未支援 roles，沒有在缺少完整 selector + CSS consumer + semantic fallback 時提升狀態。

## 驗證
- 全部 Node：89/89 test files 成功，259 cases pass，0 failures；逐檔 logs 在 `artifacts/batch242-regression/node-tests/`，摘要 `node-suite-summary.txt`。
- Focused Skin／renderer／manifest：30/30。
- Canvas Chromium：9/9。Mapping Studio：30/30；Home/Catalog：19/19；Quiz/Results：19/19；formal app-shell：150/150。
- Architecture Checker：1,270 pass／0 fail。
- HTTP-origin harness：阻塞，Chromium `ERR_BLOCKED_BY_ADMINISTRATOR`；真實 origin save/reload assertions 未執行。

## 未解與下一批
- Native stable tint/blend、songselect-top edge-repeat、動畫與完整 compositor 仍 unsupported。
- 13 個視覺 roles 仍 unsupported；真實 artwork provider 與 fallback 語義必須保護。
- Batch243：在可用 HTTP origin 驗收 IndexedDB；補 Canvas transparent-alpha／multi-row edge geometry 測試；只接線通過語義驗收的角色。
