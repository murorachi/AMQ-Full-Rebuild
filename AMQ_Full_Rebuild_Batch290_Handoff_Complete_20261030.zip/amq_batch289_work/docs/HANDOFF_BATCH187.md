# Batch187 交接：具名曲庫篩選預設與進階篩選盤點

日期：2026-10-28
工作副本：`/mnt/data/amq_batch153_work`

## 本批實作

### 具名曲庫篩選預設
- `src/persistence/app-settings-store.js` 在現有 `amqLearningAppSettingsV1` schemaVersion 1 新增可選 `catalogFilterPresets`。舊資料缺少此欄位時自動正規化為空陣列，不需破壞性 schema migration，也不增加第二個 storage key。
- 每個 preset 保存 `id`、`name`、完整 Catalog filter snapshot、`sortBy`、`sortDirection`、`pageSize`。
- 最多 30 組；名稱 trim 後 1–40 字且不分大小寫唯一；ID 唯一；只接受已知 filter keys；驗證年份／年代／熟悉度／看番狀態／排序與每頁筆數。
- `getSettings()` 對 preset array 與 filters 做深拷貝，避免呼叫者透過回傳值修改內部狀態。
- `src/index.html`／`src/ui/catalog-browser.js` 新增選取、命名保存、同名更新、套用與刪除。操作失敗有狀態提示，保存失敗不更新 store state。
- 活動篩選狀態仍由 `AMQCatalogBrowser` controller 唯一持有；App Settings Store 只保存命名快照，沒有重複的 live filter source of truth。
- `src/styles.css` 增加最小必要的控制列與響應式網格規則，沒有進行全面 UI/CSS 重構。

### 猜歌進階篩選盤點
- 年份起迄、未知年份開關、作品類型、難度上下界、歌曲類型與看番狀態已在 `src/ui/quiz-panel.js` 接線，並由既有 quiz eligibility/filter composition 測試覆蓋。
- 季別欄位目前沒有可信且已驗證的 AMQ/EMQ source contract，因此不從標題、年份或其他欄位推算季別。文件明確記錄此限制。
- Catalog UI 的熟悉度目前支援 0–4；修正舊契約文件裡過時的 0–3 描述。

### 範圍管理
- 新增 `docs/PRODUCT_SCOPE_DECISIONS_BATCH187.md` 作為最新使用者範圍決策：明確不做探索新歌、歌手圖鑑、答案別名提示；深色主題／背景與全面 UI/CSS 重構延後；osu!stable／OSK 既定方向保留。
- `docs/FUNCTION_INVENTORY.md`、`docs/CATALOG_FILTERS_CONTRACT_BATCH87.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md` 已更新。

## 測試與證據

- `tests/app-settings-store.test.cjs`：8/8 PASS，含 preset 驗證、保存／重新載入、巢狀快照隔離、未知欄位拒絕、重複名稱拒絕與 30 組上限。
- `tests/catalog-browser.test.cjs`：6/6 PASS；filter controller matrix PASS。
- `tests/catalog-browser.integration.test.cjs`：PASS，包含命名保存、套用 filter/sort/page size、刪除及狀態提示。
- `tests/backup-restore.test.cjs`：11/11 scenarios PASS。
- `tests/quiz-panel.test.cjs`：selector eligibility 768/768；`tests/filter-matrix.test.cjs`：filter composition 2048/2048。
- 全量 73 個 `tests/*.test.cjs`：逐檔 exit code 73/73 為 0。逐檔 log：`artifacts/batch187-regression/node-tests/`；狀態：`artifacts/batch187-regression/status/`；摘要：`node-tests.json`／`node-tests.tsv`。外層 xargs orchestration 命令在所有狀態檔產生後觸及執行工具時間限制；每個測試程序的獨立 exit code 都是 0。
- Architecture Checker：1,080 PASS／0 FAIL，`artifacts/batch187-regression/architecture.log`。
- OSK import panel harness：12/12 assertions PASS，`artifacts/batch187-regression/osk-harness.log`。
- 168 個 JS/CJS `node --check` PASS，`artifacts/batch187-regression/syntax-checks.json`。
- AMQ `data.js` SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `emq-data.js` SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，均與 Batch186 ZIP 內資產一致。

## 未驗收／阻塞

- Fake DOM integration 與 Node tests 不代表真實瀏覽器視覺／互動驗收。
- 真實音訊、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤及 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- 工作副本無 `.git`，未初始化。Candidate302 與 Candidate382 Stage 0 原始檔不在副本，未做 hash／相容性聲稱。

## 下一批 Batch188

1. 先核對 Catalog record identity、資料 schema 與現有 tag API；AMQ／EMQ 相同數字 ID 不得合併。
2. 實作 source-aware 多筆選取及可用的批次套用操作，確保篩選／排序／分頁後不會誤操作其他記錄。
3. 完成歌曲標籤 CRUD 與 Catalog 篩選整合；只建立一份 tag 狀態來源，並測試保存失敗／重新載入。
4. 全量 Node tests、architecture、OSK、syntax，更新同一份清單並交付完整 ZIP／SHA-256。
