# Batch 105 交接包

日期：2026-10-28

## 本批決策
使用者選擇方案 A：私人自架伺服器只供本人與朋友使用。採一次性管理者初始化與管理者發出的單次邀請碼，不開放陌生人自由註冊。

## 實作成果
- 新增 `server/database.cjs`：SQLite users、invitations、per-user/per-source SRS schema。
- 新增 `server/account-service.cjs`：帳號驗證、scrypt 密碼雜湊、一次性 setup、邀請 token hash/expiry/single-use、管理者權限。
- 新增 `server/srs-repository.cjs`：沿用 FSRS scheduler 驗證；排程依 authenticated user ID 與 AMQ/EMQ source 隔離；revision compare-and-swap 保護舊快照。
- 新增 `server/http-server.cjs`：setup/auth/invite/member/SRS API、HttpOnly SameSite cookie、Origin check、登入失敗限流、request body 上限、靜態路徑隔離。
- 新增 `server/start.cjs`：本機啟動入口與一次性 setup token 輸出。
- 新增 `tests/server-auth-srs.integration.test.cjs`：真實 HTTP integration test。
- 新增 `docs/PRIVATE_SERVER.md`，更新 README、架構、驗收、主清單、工作狀態、AI 開工提示與下一階段 prompt。

## 驗證結果
- `node --test tests/server-auth-srs.integration.test.cjs`：PASS。
- 45/45 非-tooling `tests/*.test.cjs` scripts 逐檔 exit 0。
- `node --test tests/tooling.test.cjs`：9/9 PASS。
- `node tools/check-architecture.cjs`：726 passed／0 failed。
- `src/`、`tests/`、`tools/`、`server/` JavaScript/CJS syntax：106/106 PASS。
- Source audit／mapper PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；Catalog 55,660 records；跨來源 song/work ID collision 0。
- 5 次 catalog benchmark PASS，Node catalog build 約 1,306.02 ms（僅觀察值，不是瀏覽器效能保證）。
- 來源資產 hash unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- ZIP CRC PASS；Manifest 238 項，解壓後 missing 0、extras 0、hash mismatches 0。

覆蓋：health/static path boundary、一次性 bootstrap token、只允許建立一次 admin、無邀請註冊拒絕、單次邀請、admin/member authorization、HttpOnly/SameSite cookie、密碼／邀請碼不以明文儲存、每人排程隔離、client 偽造 userId 無法跨帳號寫入、AMQ/EMQ source isolation、FSRS/source validation、revision conflict、cross-origin rejection、logout、login throttling、restart 後帳號與 SRS 持久化而 session 失效。

## 部署限制
- 測試環境 Node 22.16；最低記錄為 Node 22.5+，`node:sqlite` 仍顯示 ExperimentalWarning。
- 預設只綁 `127.0.0.1`。不要把明文 HTTP 直接公開到公網；外部存取需 VPN 或 HTTPS reverse proxy。
- Session 目前只存在記憶體，重啟後需重新登入；SQLite 帳號、邀請及 SRS 排程持久保存。

## 尚未完成
- 前端 setup/login/logout/invitation UI。
- 既有 SRS Store 到遠端 API 的 bridge；未登入 local SRS 必須保留。
- 多裝置 revision conflict reload/merge、離線佇列。
- 真實瀏覽器／多 client E2E、WebSocket transport、跨程序房間狀態及公網部署。

## 下一批
先讀 `docs/PRIVATE_SERVER.md` 與 `docs/WORK_STATUS.md` 最新 Batch105，再接前端帳號 UI 與 SRS bridge。切換帳號時不可共用排程；不得自動上傳未具 user identity 的舊 localStorage schedule。新增 UI/bridge integration tests，並維持既有單人模式。
