# Batch 81 交接：Random Sample、片段定位與自動下一題

日期：2026-10-27

## 本批成果

- `src/persistence/app-settings-store.js`：沿用既有 `appSettingsStore`，新增 `randomSample`、`clipStartSeconds`、`autoNextDelaySeconds`，包含型別與範圍驗證。舊 settings schema 缺欄位時採 `false`／`0`／`0` 預設值。
- `src/index.html`：新增 Random Sample、固定片段起始秒數與自動下一題延遲控制；自動下一題 0 秒代表關閉。
- `src/ui/quiz-panel.js`：設定載入、持久化及啟動回合時傳遞設定；隨機片段啟用時停用固定起點欄位。
- `src/audio/audio-service.js`：新增片段起始定位。隨機模式等待 `loadedmetadata`，使用 `duration - clipSeconds` 作為最大起點；固定模式同樣 clamp，避免要求片段窗口超出音訊長度。0 秒固定起點維持原播放路徑。
- `src/engine/quiz-session.js`：由 Session 持有 auto-next timeout，作答／逾時／揭曉／已播放後跳過後排程；未播放跳過不排程。手動下一題、結束、重設與 dispose 會取消 timeout，token 阻擋已排入佇列的 stale callback。AudioService 的 `playing` 仍是倒數唯一啟動條件。
- 測試：`tests/app-settings-store.test.cjs`、`tests/audio-service.test.cjs`、`tests/quiz-session.test.cjs`、`tests/quiz-panel.test.cjs`、`tests/backup-restore.test.cjs`。
- 文件：`docs/MASTER_CHECKLIST.md` AMQ-969–982、`docs/WORK_STATUS.md`、`docs/ACCEPTANCE.md`、`docs/ARCHITECTURE.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`、`MANIFEST.sha256`。

## 已知邊界

- 本批只證明 Node／FakeMedia 的事件與狀態契約，並未完成真實瀏覽器或真實音訊驗收。
- 若媒體無法提供有限 `duration`，隨機起點無法計算，會等待 metadata／候選 timeout 與既有 fallback；真實來源覆蓋率尚待實機驗收。
- 已知 Chromium 頁面導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不要重試同一條路徑。
- 工作副本沒有 `.git` metadata。未初始化 Git，未假造 branch／commit。
- 未修改 Candidate302、Candidate382 Stage 0 或 `src/data/assets/` 曲庫資產。

## 下一批直接執行

1. 完成最終測試矩陣、Manifest 與 ZIP integrity 的獨立驗證；更新 `docs/WORK_STATUS.md` 中任何「待最終重跑」文字為實際結果。
2. 中文標題 Provider：只根據可核實的靜態參考／資料契約建立 API adapter，明確處理啟用開關、取消、快取與失敗；不得編造 endpoint。
3. 再處理資料庫更新／匯入的版本化格式、預檢、原子替換與失敗回復。之後推進自由播放歷史、統計儀表板、自由播放器、外部服務與多人模式。
4. 保持 UI／CSS 大重構延後，正式基準與曲庫資產唯讀。

## 最終驗證結果

- `tests/*.test.cjs`：30/30 腳本逐一執行 exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：524 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839；duplicate IDs、dangling references、cross-source collisions 均為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660 筆。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；Catalog build 1,278.678 ms（本機觀察值）。
- `node --check`：72 個 JS/CJS 檔案 PASS。
- Manifest：170 個條目全部匹配；ZIP CRC PASS；封包內 170 個非 Manifest 檔案與 Manifest 完全一致，missing／extra／hash mismatch 均為 0。
- 曾有一個串接所有驗證的長命令逾時；沒有把該命令算作成功，架構檢查與其餘驗證皆以獨立命令完成並記錄結果。
- 交付包：`AMQ_Full_Rebuild_Batch81_Handoff_20261027.zip`；最終檔案大小與 SHA-256 由交付訊息提供，避免在封包內記錄自身雜湊造成循環。

## 下一批直接執行

1. 先核實中文標題 Provider 的實際契約與可用來源；只依靜態證據與現有資料介面接線，不得編造 endpoint。完成 cache／取消／失敗回復及答案建議整合測試。
2. 再設計資料庫更新／匯入的版本、預檢、原子替換及失敗回復。
3. 接續自由播放歷史、統計儀表板、自由播放器、外部服務及多人模式；UI／CSS 大重構仍最後做。
