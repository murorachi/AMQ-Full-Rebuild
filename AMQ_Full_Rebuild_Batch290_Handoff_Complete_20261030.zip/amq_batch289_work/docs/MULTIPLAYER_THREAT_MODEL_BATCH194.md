# Multiplayer projection and synchronization threat model (Batch194)

Date: 2026-10-28
Scope: current authenticated HTTP-polling implementation, single SQLite database and single server process. This document describes current guarantees and limits; it does not claim browser E2E or hostile-client resistance.

## Assets and trust boundaries

- Trusted: server-side room state machine, server clock/deadline, answer assessor, membership/host authorization, command idempotency records, and server-side SRS writes.
- Untrusted: all browser state, submitted answer text, client clock, polling order, client-provided actor identifiers, and any values copied from a public room snapshot.
- Sensitive: canonical question identity, answer/title/artist/work metadata, aliases, and local question-to-audio mappings.

## Current exposure

- Active snapshots expose `state.currentRound.questionId` (currently source plus bundled record ID) and `questionProjection` exposes the same identifier plus playable audio candidate URLs.
- Projection omits canonical title, artist, work title, aliases, answer-evaluator data, and the trusted record. This is useful accidental-disclosure reduction, not strong anti-cheat: a client that can inspect the bundled AMQ/EMQ catalog or correlate audio URLs may infer the answer.
- Hiding `questionId` only in the projection would not be sufficient while it remains in `state.currentRound`. A real opaque-identity migration must change the public snapshot contract and UI comparison together, while retaining the server's private question mapping for assessment. Do not partially redact one field and claim the threat is solved.
- Audio URLs are delivered to clients so they can play the round. They can be copied, inspected, unavailable in some regions, or resolve at different speeds. URL secrecy is not a viable security boundary.

## Synchronization guarantees and non-guarantees

- The server owns round transitions, deadline, answer assessment and persisted score. Client countdown is display-only and must use `serverNow` as an anchor rather than claiming client time is authoritative.
- RoomSession applies only snapshots with strictly newer revisions; unchanged revisions preserve the existing snapshot. Stop/dispose aborts the current poll where AbortController is available and generation checks ignore late completions.
- Polling is not real-time transport. Network delay, browser throttling, different audio availability, decode latency, autoplay restrictions and client clock drift prevent a guarantee that every player hears the same sample at the same instant.
- AudioService remains the only browser playback owner. Any future synchronization work must call the existing service and must not create a parallel HTMLAudioElement or competing playback state.
- Persistence guarantees currently assume one server process and one SQLite database. No multi-node lock/queue or WebSocket guarantee is claimed.

## Next safe work

1. Keep regression tests for monotonically newer revisions, stale poll completions, abort/generation changes, and request-idempotent command retries.
2. If stronger resistance to catalog inspection is a product requirement, design an explicit public/private round DTO boundary and opaque public round identifier; assess audio URL correlation and local catalog availability separately. Do not call it strong anti-cheat until hostile-client assumptions are specified and tested.
3. Browser multi-client/audio acceptance remains blocked by the documented browser navigation environment and requires a real browser environment to resolve.
