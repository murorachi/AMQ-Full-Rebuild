# Batch 66 交接：使用者驗收失敗後的定點修正

日期：2026-10-27

## 使用者新證據

使用者回報 Batch 65 的答案下拉選單仍無法使用，EMQ 音訊仍失敗。控制台訊息包括：
- `OpaqueResponseBlocking`，涉及 `erogemusicquiz.com/selfhoststorage/userup/weba/*.weba`。
- 原始 userup MP3 回應 HTTP 500。

使用者明確要求不得回到舊版的補丁式開發，不得為了遮問題而不斷追加 `!important`、重複函式覆寫或全域事件攔截。這是本專案持續硬性要求。

## 音訊判讀

- HTTP 500：原始來源伺服器回應錯誤。
- ORB：瀏覽器阻擋回應；可能與回應內容／MIME／跨來源行為有關，僅憑警告不能確定 CORS 根因。
- 舊版 Candidate381 V82.54／V82.55 靜態程式碼證據顯示 CDN host rewrite、Catbox direct mirror 與 WebA→WebM sibling fallback；目前未找到足以證明存在獨立 server-side proxy 的證據。
- `src/data/audio-candidates.js` 已對 userup URL 產生 Asia CDN host candidate 並保留原始 URL。新增 userup MP3 candidate order test，確認 Asia URL 在原始 URL 之前。沒有再盲目增加新候選或新增 proxy server。
- 實際 CDN 是否可播放仍未驗收。下一輪需看 UI 顯示的 candidate source／failure reason，確認 Asia candidate 是否確實嘗試，避免只從瀏覽器 console 的原始 URL 錯誤推斷整個 fallback 沒執行。

## 下拉選單定點修正

- `src/ui/quiz-panel.js` 以同一個 `AMQUI.answerSuggestions.createController` 管理單一答案欄與「全部三項」的作品、歌手、歌曲名稱欄位。搜尋、排序、鍵盤與 IME 邏輯仍只有 `src/ui/answer-suggestions.js` 一份，不複製、不覆寫。控制器可在有當前題目的 `ready`／`playing`／`paused` 階段啟用；舊條件要求 `phase === playing`，會在自動播放關閉或音訊尚未開始時阻止建議顯示，與答案建議本身不應依賴音訊播放狀態的責任不符。
- `src/index.html` 為三個 all-target 欄位加入獨立 listbox。
- `src/styles.css` 加入 `#quiz-single-answer-label[hidden] { display:none; }`，避免 `display:grid` 覆蓋 hidden 狀態。沒有使用 `!important`。
- `tests/quiz-panel.test.cjs` 驗證 all-target 三個欄位各自顯示建議、單一欄位 wrapper 正確隱藏，以及自動播放關閉時 session 處於 `ready` 仍可顯示建議。
- `tests/audio-candidates.test.cjs` 新增 userup MP3 Asia CDN 順序測試。

## 修改檔案

- `src/index.html`
- `src/ui/quiz-panel.js`
- `src/styles.css`
- `tests/quiz-panel.test.cjs`
- `tests/audio-candidates.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH66.md`
- `AI_START_HERE.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `README_FIRST.md`
- `MANIFEST.sha256`

## 驗證

- 全部 `tests/*.test.cjs`：27/27 scripts exit 0。
- `tests/answer-suggestions.test.cjs`：8/8。
- `tests/quiz-panel.test.cjs`：PASS。
- `tests/audio-candidates.test.cjs`：8/8。
- `tests/audio-service.test.cjs`：13 個情境 PASS。
- `node --test tests/tooling.test.cjs`：8/8。
- `node tools/check-architecture.cjs`：480 passed／0 failed。
- source audit、mapper verifier、5 次 benchmark PASS。
- 全量 `node --check` 命令在 120 秒工具逾時，不能聲稱全量 syntax PASS；後續需針對 `src/`、`tests/`、`tools/` 中排除大型資料資產的 JS/CJS 再執行。
- 真實瀏覽器與音訊尚未驗收。自動化／fake DOM 測試不等於實機修復成功。
- `src/data/assets/data.js` 與 `src/data/assets/emq-data.js` 未修改；未初始化 Git、未 commit／push。

## 下一步

1. 由使用者下載本批 ZIP，在桌面瀏覽器驗收單一答案模式及「全部三項」模式的下拉建議。
2. 若仍無建議，回報是在輸入後「完全不顯示」、顯示但「點選無效」，或方向鍵／Enter 無效；這三種是不同故障層，禁止再以猜測替代定位。
3. EMQ 音訊仍失敗時，以畫面中的 candidate source／failure reason 判斷 Asia CDN 是否被嘗試及失敗類型。沒有證據前不增加 proxy server 或無限擴張候選清單。
4. 不搜尋 Candidate302、不猜收藏 identity、不提前全面 UI／CSS 重構。
