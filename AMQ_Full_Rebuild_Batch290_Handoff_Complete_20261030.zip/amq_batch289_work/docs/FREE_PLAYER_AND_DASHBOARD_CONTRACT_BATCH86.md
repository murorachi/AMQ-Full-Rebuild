# 自由播放 Dock 與統計儀表板契約（Batch 86）

## 自由播放
- 單一播放 owner 為 `AMQAudio.audioService`。Dock 不建立 QuizSession，不操作 QuizSession timer，不建立待聽佇列。
- 可播放清單來自當前 runtime Catalog，僅收錄 `source` 為 AMQ／EMQ 且 `audioCandidates` 非空的 record。搜尋匹配歌曲名、歌手、作品與已有 aliases。
- Dock 支援播放／恢復、暫停、停止與隨機播放。切歌前結束舊音訊序列，保持 history record 與播放曲目身份一致。
- 只有 AudioService 實際進入 `playing` 後才開始累積時間；達 5 秒才記錄一次。少於 5 秒的試播不記錄；同一 sequence 不能重複記錄。`durationSeconds`／`positionSeconds` 由 AudioService 的 metrics snapshot 提供。
- 歷史寫入失敗時 UI 明確顯示失敗，不假裝已保存。QuizSession 音訊完全不經 Dock 的寫入路徑。

## 統計儀表板
- 讀取現有 quiz history、familiarity、AMQ／EMQ SRS 與 playback history Store snapshots。
- 以 `AMQLearning.statisticsDashboard.buildDashboard()` 作為唯一衍生計算；不保存第二份計數。
- 無答題資料時 accuracy 使用 null 並顯示「尚無資料」。Store 回報 read-blocked／無法可靠讀取時停止投影並顯示錯誤。
- 監聽既有同頁更新事件與 storage event，並提供手動刷新；dispose 時解除監聽與釋放面板所擁有的 Store。

## 驗收界線
- Node 測試驗證模組契約與事件時序，不證明真實 HTMLAudioElement 可聽性或瀏覽器持久化。
- 真實瀏覽器驗收仍需確認播放／暫停／恢復／停止、至少 5 秒門檻、播放歷史、切歌身份、Dashboard reload、storage quota 與跨分頁更新。
