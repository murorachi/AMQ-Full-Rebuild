# Batch 31 交接：跨模式生命週期回歸保護

## 本批變更
- 擴充 `tests/quiz-panel.test.cjs`，覆蓋 AMQ → MIX（來源載入失敗／成功）→ EMQ → AMQ。
- 驗證 mode switch 會重建 pool 與 reset shared `questionStatus`，AMQ blacklist 不會以相同裸 ID 套用到 EMQ，EMQ SRS 卡片仍在 EMQ store 且不會出現在 AMQ store／pool。
- 未修改 runtime 行為，只增加既有契約的整合回歸保護。

## 驗證
- 針對性 `node tests/quiz-panel.test.cjs` PASS。
- 本批交付前應依 `docs/WORK_STATUS.md` 最後一節完成完整 Node tests、architecture、source audit、mapper verifier、benchmark、syntax 與 manifest／ZIP 驗證。

## 已知阻塞與下一步
- Chromium headless smoke 已在 25 秒逾時，沒有 DOM dump；目前環境不適合重複同一啟動方式。真實瀏覽器 UI／音訊仍未驗收。
- MIX legacy AMQ-specific filter suppression 暫緩，因新版尚無對應 watchlist／season／difficulty／hard-pool UI；不要先造一套篩選 UI 來滿足相容分支。
- 下一批先從主清單找不依賴瀏覽器、可用 Node 測試完整驗證的最高優先級任務開始。
