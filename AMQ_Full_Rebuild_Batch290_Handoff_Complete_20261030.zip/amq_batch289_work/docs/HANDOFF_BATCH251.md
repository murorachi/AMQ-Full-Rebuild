# Batch251 Handoff：跨頁焦點、狀態保持與 44px Settings controls

## 基準與安全
- 唯讀基準：`/mnt/data/AMQ_Full_Rebuild_Batch250_Backup_Restore_Closure_20261029.zip`，SHA-256 `7861fa1c55b8693ff55732b5702d68f9e18be551321b7de3c844ac5985686f6d`，與 sidecar 一致。
- 工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch251_Cross_Page_E2E/AMQ_Full_Rebuild_Batch245_Project`。沒有 `.git`，未初始化；未覆蓋 Batch250 ZIP。
- AMQ raw data hash `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ raw data hash `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，未修改。

## 實作
- `src/ui/app-shell.js`：修正一般目的頁 heading 無法程式化 focus 的問題。`h2`／`h3`／section fallback 在不是原生互動控制項時取得 `tabIndex=-1` 後再 focus；不改變 Tab 順序。保留 Quiz setup 專用焦點與 route scroll reset。
- `src/styles/ui-shell.css`：Settings 統計排序、快捷鍵錄製、工作區 reset、Skin Mapping reset 與五個 Settings quick-nav 按鈕最小高度 44px。
- `tests/app-shell-navigation.contract.test.cjs`：新增 route focus／ARIA／scroll contract。
- `tests/batch251-cross-page.browser.py`：鍵盤 Home menu、路由／焦點／scroll、Catalog query state retention、Settings quick-nav、status semantics、reduced motion、390px 六頁溢位與 44px 控制項。
- `tests/ui-shell-css.contract.test.cjs`：保護 Settings 觸控尺寸。

## 驗證結果
- Cross-page Chromium **45/45 PASS**。
- Formal app-shell Chromium **150/150 PASS**；Home/Catalog **22/22 PASS**；Quiz/Results **19/19 PASS**；Backup/Restore **8/8 PASS**。
- Node `*.test.cjs` **91/91 files 最終逐檔 exit 0**；`quiz-pool.test.cjs` 與 `tooling.test.cjs` 在外層彙總時間限制後補跑，兩者均成功。
- Architecture Checker **1,286 PASS／0 FAIL**；JS/CJS syntax **194/194**；Python compile **14/14**。
- Visual role audit：48 roles，35 wired、13 unsupported、31 有測試檔線索；這仍是靜態稽核，非逐角色 browser closure。
- 證據目錄：`artifacts/batch251-regression/`；逐檔 Node logs／`results.tsv` 在 `node-tests/`。

## 未驗收／下一步
- HTTP-origin IndexedDB 仍受 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；環境未變，本批不重試同一 probe。
- Live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0、native osu!stable fidelity 未驗收。
- 35 wired Skin roles 仍需逐角色 apply/fallback/reset；13 unsupported 維持 unsupported。
- 下一批 Batch252：檢查真實 `.osk`／skin.ini 相容界線（@2x、動畫、state pair、blend/tint、edge-repeat、geometry），對可證明的行為補 pixel／integration regression，不宣稱 native compositor 相容。
