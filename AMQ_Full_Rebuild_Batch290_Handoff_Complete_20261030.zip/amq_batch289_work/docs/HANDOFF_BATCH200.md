# Batch200 交接：正式 UI 視覺一致性第一輪

日期：2026-10-28

## 使用者要求與範圍
使用者明確要求：如果 UI 尚未完成，下一批先做 UI。故 Batch201 優先完成正式頁面視覺與互動，不再把底層測試／架構整理當主要工作。UI 不可使用假曲庫、假統計或隨機 OSK 圖片冒充成品。

## Batch200 實作
- `src/ui/app-shell.js`：猜歌、學習中心、設定頁加入專屬頁面標題區；猜歌頁單人面板排在多人房間之前。
- `src/styles/ui-shell.css`：首頁大餅式主選單、導覽、頁面標題、五頁面板視覺一致性；修正猜歌 question/history/SRS 與 learning statistics 卡片殘留白底。
- `tests/app-shell.browser.test.py`：擴充到 37 個 Chromium assertions，涵蓋頁面標題、單人優先順序、桌面／手機溢位及頁面截圖。

## 證據
- `artifacts/batch200-regression/app-shell.browser.log`：37/37 PASS。
- `artifacts/batch200-regression/architecture.log`：1,123 PASS／0 FAIL。
- `artifacts/batch200-regression/syntax-failures.txt`：174 個 JS/CJS 檔案無語法失敗。
- 截圖：`home-desktop.png`、`home-mobile.png`、`catalog-desktop.png`、`catalog-mobile.png`、`quiz-desktop.png`、`quiz-mobile.png`、`learning-desktop.png`、`settings-desktop.png`、`settings-mobile.png`。
- 8 個重點 Node test files 已逐檔通過，包含 Catalog layout/controller、Skin adapter/store/transfer、quiz panel、statistics dashboard。

## 尚未完成
- 正式 UI 仍未結案。Batch200 是視覺一致性第一輪，猜歌與學習中心內容資訊層級、設定長表單密度、OSK role 全面接線尚未完成。
- Catalog 瀏覽器 fixture 仍顯示 `DATA_SOURCE_READ_FAILED`；沒有真實曲庫／封面／音訊驗收。localhost Chromium 導覽受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；真實 HTTP-origin IndexedDB／`.osk` E2E 未驗收。
- 完整 Node suite 未執行；不可宣稱全量通過。
- 工作副本無 `.git`，未初始化。Candidate302／Candidate382 Stage 0 原始基準缺席，未覆蓋資料資產。

## Batch201 下一步（UI 優先）
1. 讀取本文件、`AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/OSK_SKINNING_CATALOG_AND_AMQ_UI_CONTRACT_BATCH195.md`。
2. 以 `prototype/ui-v2-osu-select-batch146` 作為視覺參考，不複製 mock data／假統計。
3. 完成猜歌區視覺分組與答題舞台，保留現有 DOM IDs、engine、stores、AudioService owner。
4. 完成學習中心可掃讀資訊層級，所有空資料／讀取失敗均明確顯示。
5. 整理設定頁長表單與手機分區；逐角色接入可驗證的 OSK UI slot。
6. 最後補互動回歸、manifest、ZIP；不可把測試當成 UI 工作的替代品。
