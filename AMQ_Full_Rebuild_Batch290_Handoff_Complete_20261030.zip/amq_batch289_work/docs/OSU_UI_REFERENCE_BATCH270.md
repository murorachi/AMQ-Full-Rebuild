# osu! UI Reference Map（Batch270）

本文件對應使用者提供的五張 osu! Wiki 介面截圖。官方參考圖本體已放入 `artifacts/osu-reference/`，方便後續視覺對照；來源 URL 保留如下。

| 本地參考圖 | 官方來源 | AMQ 對應 | 借用的設計規則 |
|---|---|---|---|
| `osu-main-menu.jpg` | https://osu.ppy.sh/wiki/images/Client/Interface/img/main-menu.jpg | Home／首頁 | 大型主視覺與垂直主選單分工，主選項可直接操作 |
| `osu-intro-screen.jpg` | https://osu.ppy.sh/wiki/images/Client/Interface/img/intro-screen.jpg | 品牌視覺、載入／啟動狀態 | 背景與標誌分層、控制視覺噪音；不增加無功能的啟動畫面 |
| `osu-song-selection.jpg` | https://osu.ppy.sh/wiki/images/Client/Interface/img/song-selection.jpg | Catalog／選歌 | 封面、列表選取、作品詳情、底部播放控制形成一個工作區 |
| `osu-multiplayer-lobby.jpg` | https://osu.ppy.sh/wiki/images/Client/Interface/img/multi-lobby.jpg | Quiz 中的多人房間區 | 房間狀態與玩家視覺密度、房間列表、固定操作區 |
| `osu-game-modifiers.jpg` | https://osu.ppy.sh/wiki/images/Client/Interface/img/game-modifiers.jpg | Quiz 的遊戲條件／未來 Mod 設定 | 分類、可辨識圖示、啟用狀態、倍率摘要、集中操作 |

## 使用原則
- 參考構圖、密度、狀態與操作，不直接複製 osu! 的品牌、規則或未確認授權的其他資源。
- Home 的作品圖只允許由正式 playback history、明確 workId mapping 與既有 artwork provider 驅動；不得猜 URL 或用測試圖假扮推薦。
- Catalog fixture 截圖只能證明布局，不代表正式曲庫／外部 artwork 載入成功。
- Multiplayer 與 Mod 參考目前只是明確對應和待辦，不代表這兩個區域已完成重構。
- 最終視覺 gate 必須人工對照參考圖，功能測試不能取代構圖、密度與焦點驗收。
