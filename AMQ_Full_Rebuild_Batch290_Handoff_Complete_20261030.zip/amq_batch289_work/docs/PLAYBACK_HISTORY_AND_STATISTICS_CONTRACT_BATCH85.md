# Playback History & Statistics Contract · Batch 85

## Playback history

- Owner: `window.AMQPersistence.playbackHistoryStore` in `src/persistence/playback-history-store.js`.
- Key: `amqLearningPlaybackHistoryV1`; envelope `{ schemaVersion: 1, entries: [...] }`; hard cap 1,000 records.
- Every row has unique `id`, `source` (`AMQ` or `EMQ`), non-empty `songId`, ISO `playedAt`; optional `workId`, title, artist, work title, duration and playback position.
- `source` is part of identity. Equal numeric IDs across AMQ/EMQ must not be merged.
- API: `recordPlayback`, `getEntries({limit})` (newest first), `clear`, `refresh`, `subscribe`, `getPersistenceStatus`, `dispose`.
- A failed read/schema validation blocks writes to avoid replacing unknown existing data. Failed writes do not replace the in-memory snapshot or claim persistence. Stable event IDs are deduplicated.
- The store does not listen to global audio events. The future free-player Dock must call `recordPlayback` at a defined playback-start threshold. QuizSession audio must not be logged as free playback.
- Existing backup/restore v1 now validates and carries this key. Old partial v1 exports that omit the key keep current data unchanged.

## Statistics projection

- Pure API: `window.AMQLearning.statisticsDashboard.buildDashboard(input)`.
- Inputs: `quizHistory`, `familiarityAMQ`, `familiarityEMQ`, `srsAMQ`, `srsEMQ`, `playbackHistory` snapshots.
- Output includes quiz totals/correct rate/average elapsed, source and target groups, recent 30 active days, familiarity levels, SRS counts, and playback source totals.
- It does not access storage or DOM and does not persist derived totals. Empty accuracy is `null`, not NaN or a fabricated 0%.
- UI must distinguish missing/failed store reads from valid empty snapshots; do not silently substitute zero for unreadable stores.

## Evidence and limitations

- `tests/playback-history-store.test.cjs`: 5 scenarios PASS.
- `tests/statistics-dashboard.test.cjs`: PASS.
- `tests/backup-restore.test.cjs`: 9/9 PASS including playback history round-trip and invalid-row rejection.
- Full Node suite: 37/37 scripts exit 0; tooling 9/9; architecture 614/0.
- Not verified: actual browser quota, browser storage events, actual audio event integration, free-player Dock or dashboard UI.
