# Batch157 交接：Artwork provider factory 與正式 app lifecycle 接線

## 工作副本／基準保護
- 工作副本：`/mnt/data/amq_batch153_work`。
- 無 Git metadata；未初始化 Git。
- Candidate302、Candidate382 Stage 0、`src/data/assets/data.js`、`src/data/assets/emq-data.js` 維持唯讀。

## 已實作
- 新增 `src/integrations/artwork-provider-factory.js`，以明確外部 ID 建立 artwork providers。
  - EMQ 僅在 `artworkRef.vndbId` 是有效 `vNNN` ID 時呼叫 VNDB `getVisualNovel`。
  - AMQ 僅在 `artworkRef.anilistId` 是明確數字 ID 時呼叫 AniList `getMediaById`。
  - 不以 AMQ/EMQ 本地 work ID 充當外部 ID，不使用標題搜尋猜封面。
  - 保留 provider 名稱、來源 attribution 與官方作品頁來源 URL。
  - 取消訊號會傳至既有 external-service client；factory 支援 dispose。
- `src/integrations/anilist-adapter.js` 新增精確 `getMediaById(id, {signal})`，不做搜尋式匹配。
- `src/integrations/vndb-adapter.js` 的 `getVisualNovel(id, {signal})` 支援取消。
- `src/app.js` 建立 VNDB client／feature adapter／provider factory／artwork adapter，將 adapter 注入 Catalog，並在 app lifecycle dispose 時清理資源。
- 更新正式頁面、browser test 頁的 script load order 與 architecture check。
- 新增 `tests/artwork-provider-factory.test.cjs`，覆蓋明確 ID、source attribution、拒絕猜測、取消與 dispose。

## 驗證證據
- `node --check src/integrations/artwork-provider-factory.js src/integrations/anilist-adapter.js src/integrations/vndb-adapter.js src/app.js`：PASS。
- `node --test tests/artwork-provider-factory.test.cjs tests/artwork-adapter.test.cjs tests/external-service-adapter.test.cjs tests/external-service-feature-adapters.test.cjs tests/source-mappers.test.cjs tests/catalog-browser.test.cjs tests/catalog-browser.integration.test.cjs`：14/14 top-level tests PASS，0 FAIL。
- `node tools/check-architecture.cjs`：1023 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- 無真實外部網路 API 呼叫測試；目前以注入 fixture 驗證契約，故不宣稱已在網路環境確認 VNDB／AniList 回應可用。

## 尚未完成／阻塞
- AMQ `artworkRef` 目前沒有可證實的 `anilistId` crosswalk，所以 AMQ 封面仍安全 fallback；不得把 AMQ work ID 猜成 AniList ID。
- EMQ 只有在來源資料確實附有 `vndbId` 時才會查封面。無 ID 或 VNDB API 失敗／429 時，Catalog 顯示 fallback；目前不自動重試，避免額外請求與速率限制。
- MAL provider 未接入：現有 MAL API 需要明確 OAuth credential provider；不為封面擅自要求使用者登入或新增憑證。
- 對 `src/data/assets/emq-data.js` 僅在記憶體中解壓並統計，未寫回資產：6,645 個 works 中 6,570 個具有格式有效的 VNDB `vNNN` ID（98.87%），75 個缺失／格式無效；共有 16,839 首歌曲。
- 尚未執行全部 67 個 Node test files 的完整分組回歸；本批只執行受影響測試組及 architecture/browser tests。
- 真實 `.osk` 與非 opaque HTTP-origin IndexedDB 驗收仍受既有環境阻礙。
- 正式 osu!stable Song Select 全面視覺替換仍未完成。

## 下一批
1. 已唯讀統計 EMQ 原始資料：6,570/6,645 works 有格式有效的 VNDB ID（98.87%）；75 個無 ID／無效 ID。
2. 尋找已有且可驗證的 AMQ→AniList crosswalk；若無可靠來源，維持 fallback，不做標題猜測。
3. 補 app lifecycle integration test，驗證 mount/dispose 時 artwork resources 正確建立與清理。
4. 再分層改造正式 osu!stable Song Select UI，先做可維護的視圖結構替換，保留既有搜尋／篩選／排序／分頁／鍵盤／個人清單／學習狀態。
