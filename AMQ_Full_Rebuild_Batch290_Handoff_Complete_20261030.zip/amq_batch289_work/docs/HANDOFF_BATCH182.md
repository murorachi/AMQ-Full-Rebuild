# Batch182 交接：QuizSession revoke reentrancy 與 dispose 後遲到操作

## 缺陷與修正
1. `revokePlaybackLease()` 呼叫 `engine.endRound()` 時會同步通知 listeners。listener 立即呼叫 `startRound()` 會重設已計分的 completedCount/result，之後因 coordinator 正在撤銷而取得播放權失敗。現在 `revokingPlayback` guard 覆蓋整個撤銷流程，包含最後一次同步通知；重入 mutation 回傳 `playback-revoking`。
2. dispose 後公開 `submitAnswer()`／`skip()` 原本仍可能被舊 UI event 呼叫，engine 還在 playing phase 時會接受答案並持久化。現在公開 mutation methods、clock tick/timeout、audio listener 都尊重 disposed 狀態；已排入的 auto-next callback 也會因 disposed/token guard 失效。
3. 新增 regression：revoke listener reentrant startRound、dispose 後 late scoring、dispose 後 stale auto-next。修正前失敗證據在 `artifacts/batch182-regression/quiz-session-before-fix.log`。

## 驗證
- QuizSession 28/28；Playback Coordinator 7/7；全部 71 個 Node test files exit 0。
- Database Update Runtime Integration 3 scenarios；Database Update 8 scenarios。Backup/restore 11/11、panel 8/8、SRS 20/20、Remote SRS 12/12、History Store 21/21、AudioService 22 scenarios。
- Architecture 1,051/0；OSK 12/12；160 syntax checks PASS。證據在 `artifacts/batch182-regression/`。

## 未驗收
Node controlled callback/fake timer tests 不等於真實瀏覽器多分頁音訊 E2E。真實音訊、ANN API/CORS/封面、真實 OSK、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。Candidate302／Candidate382 Stage 0 原始檔缺席；無 `.git`，未初始化。

## Batch183 下一步
1. 先讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、本 handoff 與 `docs/NEXT_SESSION_PROMPT.md`。
2. 檢查 revoke callback 中同步 listener 重入 `dispose()`／`reset()`／`endRound()` 的完整矩陣。
3. 檢查 lease 被撤銷後 reacquisition policy，確保舊 session 只能由明確使用者操作重新開始，auto-next／late audio callback 不得自動搶回播放權。
4. 先建立修正前失敗的 regression，再只修 P0/P1；保留四級熟悉度、單一播放 owner、`playAttemptId`／`playbackEpoch`。
5. 跑全部 71 Node tests、architecture、OSK、160 syntax checks，更新主清單與交付 ZIP／SHA-256。
