# Multiplayer Room Command Service Contract（Batch 93）

## Purpose and boundary

`src/multiplayer/room-command-service.js` composes the pure room state machine and server-owned answer assessor without selecting a network framework or loading into the single-player app. It is a transport-neutral server command handler, not a network server.

## Trusted dependencies

- `initialState`: room state created by the room state machine.
- `selectQuestion(context)`: trusted server-side selector returning a `questionId` already registered in the assessor. Client `questionId` is ignored.
- `createRoundId(context)`: trusted server-side unique round ID factory. Client `roundId` for round creation is ignored.
- `now()`: server clock. Client timestamps are ignored.
- `roundDurationMs`: server-owned duration (1–300 seconds). Client `durationMs` is ignored.
- `assessor`: trusted server-owned question/target mapping and existing title-only assessment adapter.
- `authContext`: must be built by the trusted transport after authentication; the service requires `authenticated === true` and takes actor identity only from `authContext.playerId`. Never construct this context from client JSON.

## Client command handling

The client allowlist is `player.join`, `player.leave`, `player.ready`, `round.start`, `answer.submit`, `round.close`, and `room.close`. `round.timeout` is deliberately server-only. The service ignores caller-provided `actorId`, target, questionId, roundId for starting a round, duration, outcome, correctness, grade, score, and timestamps. `expectedRevision` is a concurrency token and must match the current room revision when provided.

For `answer.submit`, the service first asks the room state machine to validate membership, active round, round ID, deadline, and duplicate submission. It then assesses against the trusted question ID / target and server clock, and only commits the new immutable room state if assessment succeeds. The returned event does not include raw answer text; the viewer-specific snapshot shows only that viewer's answer during an active round.

## Server deadline expiry

`expireRound()` is not exposed through `dispatch`. It rejects calls before the server deadline, generates grade-1 timeout assessments for players who did not submit, excludes already answered players to avoid duplicate assessment, and closes the round using the server-only `round.timeout` transition. Results are returned to the trusted server caller; this module does not persist SRS schedules.

## Remaining production work

The real transport must authenticate connections, build trusted auth context, serialize concurrent commands per room or use revision compare-and-swap, rate-limit commands, schedule `expireRound()`, deliver per-viewer snapshots, persist assessment results to the correct user/source SRS store if product requirements permit, and test reconnect / disconnect / multi-client behavior. No websocket server, deployment, authentication provider, or live multiplayer E2E is included.

## Batch 94 addendum: request idempotency

Client commands may include a stable `requestId` (non-empty string, max 128 chars). The service keys successful results by authenticated player ID plus request ID. Replaying the same command returns the original result with `replayed: true` and does not execute another state transition or assessment. Reusing the same request ID for a different command payload returns `ROOM_REQUEST_ID_REUSED`. Request IDs are isolated per authenticated player.

The in-memory FIFO cache defaults to 256 entries and can be configured with `maxIdempotencyEntries` from 0 to 10,000. Zero disables caching. Only successful results are cached; errors may be retried. This cache is process-local and volatile, so the real transport/server still needs durable idempotency and per-room command serialization for cross-process concurrency. Commands without `requestId` retain Batch93 behavior for compatibility; retrying clients should always supply one.

## Batch 94 addendum: per-player command rate limit

The service applies an in-memory sliding-window limit per authenticated player. Defaults are 60 new commands per 10,000 ms. Configure `maxCommandsPerWindow` (1–100,000) and `commandWindowMs` (100–600,000) via trusted service dependencies. Exceeding the limit raises `ROOM_RATE_LIMITED` with `retryAfterMs`, `limit`, and `windowMs`. A cached exact idempotent replay does not consume another slot. A reused request ID with a different payload consumes a normal command slot before returning `ROOM_REQUEST_ID_REUSED`, so conflict attempts cannot bypass the limit. Expired player windows are pruned during dispatch. This is a local safety boundary only; the real transport still needs connection/account/IP limits, observability, and distributed enforcement where applicable.
