# Batch 77 Handoff：備份／還原 UI 接線

## 基準與環境
- 工作副本：`/mnt/data/amq_batch76_work/AMQ_Full_Rebuild_Batch74_Handoff`（交付 ZIP 內路徑仍為 `AMQ_Full_Rebuild_Batch74_Handoff/`）。
- 無 `.git` metadata；沒有初始化 Git、commit 或 push。
- Candidate302 與 Candidate382 Stage 0 不在本包內，沒有修改正式基準或曲庫來源資料。
- Node v22.16.0、npm 10.9.2；無 `package.json`。

## 實作
- `src/ui/backup-restore-panel.js`：新增獨立 UI 控制器，使用既有 `AMQPersistence.backupRestore` API。
- `src/index.html`：新增 JSON 備份下載、選檔、預檢、資料項目預覽、確認還原及狀態區。
- `src/styles.css`：只新增局部工具面板樣式，未啟動全面 CSS 重構。
- `src/app.js`：將控制器掛入 lifecycle scope，dispose 時移除事件監聽。
- `tests/tests.html`、`tools/check-architecture.cjs`：更新載入順序與測試 DOM。
- `tests/backup-restore-panel.test.cjs`：6 組 UI 控制器測試。
- `docs/MASTER_CHECKLIST.md` AMQ-933–941、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md` 已更新。

## 安全行為
- 匯出產生 JSON 備份下載，錯誤明確顯示。
- 匯入先讀檔與 preflight；驗證失敗時還原按鈕保持停用，並告知資料未修改。
- 預覽待處理資料類別；明確提示未包含的 key 不會變更。
- 還原前顯示覆蓋範圍並要求確認；取消不呼叫 restore API。
- 還原成功提示重新載入頁面，避免暗示記憶體中的 Store 已自動刷新。
- rollback 不完整時顯示嚴重警告與錯誤 key。

## 驗證邊界
- 全部 `tests/*.test.cjs`：30/30 scripts exit 0。
- UI 控制器 Node mock DOM 測試：6/6 PASS；persistence API 測試：7/7 PASS。
- Tooling：8/8 PASS；architecture：524 passed／0 failed。
- Source audit PASS：AMQ 38,821、EMQ 16,839；重複 ID／懸空關聯／跨來源 ID 衝突均為 0。Mapper verification PASS，Catalog 55,660 筆。
- 五次 catalog benchmark PASS，build 1,134.493 ms（本機 Node 觀察值）。`src/`、`tests/`、`tools/` 全部 JS/CJS syntax PASS。
- Manifest：166/166 SHA-256 通過；ZIP：180 entries，CRC 與封包內 manifest 驗證 PASS。
- 真實瀏覽器下載／檔案選取／storage quota／跨分頁 storage event／reload 後一致性仍未驗收；不得把 mock DOM 結果當成 E2E。

## 下一批
1. 以實際可用的瀏覽器通道驗收下載、選檔、預檢、確認還原及 reload 後資料一致性。
2. 若瀏覽器仍被環境政策阻擋，不重試相同已知失敗路徑，記錄阻塞後繼續資料安全測試。
3. 保持 UI/CSS 大重構延後；不要把 Node/mock DOM 描述成實機驗收。
