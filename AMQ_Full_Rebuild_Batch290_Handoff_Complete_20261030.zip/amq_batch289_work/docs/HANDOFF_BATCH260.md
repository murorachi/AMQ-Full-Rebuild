# Batch260 交接：首頁直達入口與 UI 文案清理

## 基準與安全
- 起始基準：Batch259 ZIP，原始 ZIP 保持不變。
- 工作副本沒有 `.git`，未初始化 Git。
- 未將 prototype mock songs 混入正式曲庫；AMQ/EMQ 原始資料檔未改動。

## 已完成
- 正式 Home 移除中心大圓盤、隱藏式主選單及其「這不是 osu! 原生元件」說明。
- 六個主要功能入口直接可見；加入主視覺區與誠實的「尚無學習紀錄」空狀態。
- 移除產品 UI 裝飾性英文 eyebrow、重複頁面描述及工程範圍 footer。
- 新增 `docs/UI_COPY_POLICY.md`，規範未來不得把 AI 式注釋、設計自我解說或無功能裝飾文字帶入產品 UI。
- Skin home roles 改接到新 Home DOM 元件。
- Catalog 保留正式三欄工作區與共享狀態來源。

## 驗證證據
- `python tests/batch260-design-copy.browser.py`: 39/39 PASS。
- `python tests/app-shell.browser.test.py`: 144/144 PASS。
- `node tools/check-architecture.cjs`: 1,293 PASS／0 FAIL。
- `node tests/app-shell-navigation.contract.test.cjs`: 2/2 PASS。
- `node tests/skin-theme-adapter.test.cjs`: 20/20 PASS。
- `node tests/catalog-browser.test.cjs`: 6/6 PASS。
- `node tests/catalog-browser.integration.test.cjs`: PASS。
- 截圖在 `artifacts/batch260-design-landing/`，包含 Home/Catalog 的 1920×1080、1440×900、1024×768、390×844。

## 阻塞／未驗收
- Chromium loopback HTTP 被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋，HTTP-origin IndexedDB 與真實資料載入未驗收。
- 截圖使用 opaque origin，Catalog 顯示的 IndexedDB 錯誤是測試環境限制下的真實錯誤狀態，不代表已證實正式 HTTP 環境也失敗。
- 最終 osu! 視覺相似度尚未結案。首頁主視覺仍需作品導向的視覺素材；Catalog 要在允許 HTTP-origin 的環境重新截圖比較。

## Batch261 優先順序
1. 取得可用 HTTP-origin Chromium 測試環境，驗證真實 IndexedDB、曲庫與封面。
2. 在不造假的前提下把 Home 的作品視覺區接到實際近期紀錄/封面 provider；沒有資料時維持清楚空狀態。
3. 調整 Catalog 的三欄比例、密集曲目視覺與固定底部播放 Dock，產生同尺寸參考對照與差異表。
4. 擴大 UI 文案政策測試到動態元件，避免重新引入英文眉標與工程註釋。
5. 更新同一份主清單、狀態、UI traceability、handoff、next prompt、AI_START、manifest 與交付包。
