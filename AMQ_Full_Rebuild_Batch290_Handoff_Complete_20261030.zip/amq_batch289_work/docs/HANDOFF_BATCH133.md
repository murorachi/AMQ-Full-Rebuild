# AMQ 新版重建交接：Batch133（多人 deadline／timeout／SRS event race）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 唯讀。

## 修改
- `server/multiplayer-host.cjs`：移除完全重複的 `requireMember()` guard，保留單一成員檢查。
- `tests/multiplayer-http.integration.test.cjs`：server clock 到達 deadline 時，並行送出 late answer 與兩個 snapshot；確認 late answer 拒絕、房間逾時只提交一次、另一玩家不能讀取 host timeout assessment，host 可讀自己的結果。
- 驗證 SQLite `srs_assessment_events` 對同 room／round／player 只寫入一筆 timeout event，SRS revision 只增加一次。

## 驗證
- `node --check server/multiplayer-host.cjs`、`node --check tests/multiplayer-http.integration.test.cjs`：PASS。
- `node --test tests/multiplayer-http.integration.test.cjs tests/multiplayer-host.integration.test.cjs`：2/2 PASS。
- Batch132 其餘 55 個非-tooling test scripts 已逐檔通過，且本批只修改上述 server host 與 HTTP integration test；修改後兩個相關腳本重新執行通過。

## 未解決
- 真實多 client browser／跨程序／多節點 E2E 未驗收；同 instance HTTP／SQLite tests 不代表多節點競態驗收。

## 下一步
Batch134：稽核 `server/http-server.cjs` 的多人 HTTP body limit、request schema、authentication、room membership 與 rate-limit 邊界，先利用現有 guard，只有確認有缺口才修改。
