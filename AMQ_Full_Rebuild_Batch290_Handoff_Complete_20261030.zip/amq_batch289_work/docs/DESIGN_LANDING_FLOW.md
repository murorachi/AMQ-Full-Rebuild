# 設計落地流程（Batch259 起採用，優先級 P0）

## 目的與不可妥協的結果

本流程的目標不是「深色主題」或「能匯入 OSK」，而是讓正式 `src/` 介面在資訊架構、視覺重心、版面密度、導航方式、封面呈現與互動回饋上，一眼可辨識為 osu! 風格的桌面音樂遊戲介面，同時保留 AMQ 的選歌、猜歌、學習、多人與資料功能。OSK 皮膚是套用在 UI 架構上的外觀系統，不是 UI 架構本身。

**不可宣稱完成的條件：**只要正式版截圖仍與參考的主要構圖有明顯差異、只有顏色接近、仍保留與目標衝突的首頁主導元件，或只展示 prototype 而未整合 `src/`，視覺落地就必須標示「未通過」。功能測試通過不能覆蓋視覺未通過。

## 參考來源與提取規則

- 官方介面結構參考：`https://osu.ppy.sh/wiki/en/Client/Interface`。
- 官方皮膚元件參考：`https://osu.ppy.sh/wiki/en/Skinning/Interface`。
- 先提取結構而非抄顏色：主選單／Play 導航、Song Select 的左側控制與搜尋、中央密集曲目選擇、選中曲目資訊區、持續存在的播放／狀態區、明確的選中／懸停狀態。
- AMQ 對應：首頁提供清楚的大型功能入口；選歌頁採左篩選、中央曲目／封面、右側選中作品資訊；猜歌頁以題目／音訊／答案操作為中心；設定集中在設定頁；多人房間仍屬猜歌功能的一部分。
- 不宣稱 AMQ 是 osu! 原生介面；借鑑其信息架構與交互語言，不複製其商標或將 osu! 原生資產當成可任意重用素材。

## 階段閘門

### Gate 0：基準凍結與現況證據
- [x] 確認 Batch258 ZIP 的 SHA-256，原 ZIP 保持唯讀。
- [x] 確認正式介面在 `src/`，既有 osu 方向原型位於 `prototype/ui-v2-osu-select-batch146/`，兩者並非同一實作。
- [x] 以正式版 Home 截圖與原型 Home/Catalog 截圖作為視覺差距證據。
- [x] 記錄無 `.git`，不初始化 Git、不假裝存在提交紀錄。

### Gate 1：設計規格與參考分解
- [x] 定義四個主要區域：全域導航、頁面內容、曲目／作品視覺、持續播放控制。
- [x] 設定桌面主驗收尺寸 1920×1080；附加 1440×900、1024×768 與 390×844。
- [x] 設定「無頁面整體垂直捲動」為桌面目標；必要的內容區內部捲動須限定在明確容器內。
- [ ] 對首頁、選歌、猜歌、設定、結果逐頁建立參考截圖、正式版截圖、差異表。
- [ ] 為每頁定義主要視覺重心、密度、封面比例、固定區域、狀態、互動及響應式降級。

### Gate 2：正式 UI 骨架
- [ ] 正式 `src/` 實際採用穩定的全域導航、內容舞台、播放 Dock 與固定頁面區域。
- [ ] 移除／替換與新資訊架構衝突的舊 UI，不以 `display:none` 長期藏起來充數。
- [ ] 保留既有模組單一狀態來源及功能 owner，不複製一套假資料 UI。
- [ ] 所有頁面切換、焦點、鍵盤操作與 Skin role selector 有明確映射。

### Gate 3：頁面垂直切片（必須整合正式版）
- [ ] 首頁：直接可見主要入口、作品視覺與最近學習／播放資訊，不使用大型孤立圓盤作為唯一導航。
- [ ] 選歌：左側篩選、中央密集曲目／封面列表、右側選中作品資訊、固定底部播放控制；保留現有搜尋／篩選／排序／選擇行為。
- [ ] 猜歌：AMQ 問題核心優先，單人／多人切換清晰，音訊、答案輸入、回合狀態、結果不互相搶焦點。
- [ ] 設定：分區導覽，設定項目在固定內容框架中組織，不把所有內容堆成長頁卡片。
- [ ] 結果／學習／個人檔案使用同一視覺語言，資料空狀態明確，不偽造統計。

### Gate 4：Skin System 接線
- [ ] 每個已登記 skin role 對應正式 DOM 元件，列明 unsupported 原因。
- [ ] OSK parser、asset mapper、resolver、page/region/component override 不得替代頁面布局決策。
- [ ] 以正式頁面驗證 skin apply／missing fallback／reset，並檢查元件尺寸、對比、遮擋、裁切與可點擊性。

### Gate 5：視覺驗收（不得被功能測試取代）
每個頁面都需有同尺寸截圖與差異表，以下條件全部符合才可標為「視覺驗收通過」：
1. **構圖**：主要區域位置與比例符合參考規格；不能只換顏色。
2. **密度**：沒有不必要的大面積空白、裝飾卡片堆疊或超大解說文字。
3. **焦點**：封面／作品視覺、選中項目、主要操作一眼可辨識。
4. **結構**：導航、內容、資訊面板、播放控制位置穩定；不同頁不各自發明一套骨架。
5. **狀態**：default、hover、selected、disabled、loading、empty、error、recovery 可見且一致。
6. **可操作性**：無重疊、不可點擊遮罩、鍵盤焦點遺失、文字裁切或觸控目標過小。
7. **響應式**：1920×1080、1440×900、1024×768、390×844 有對應證據；窄螢幕可採折疊／抽屜，但不得水平溢位。
8. **差異關閉**：任何阻礙「一眼看上去像」的 P0 差異都必須修正後重拍，不能以已知問題帶過。

### Gate 6：功能回歸與交付
- [ ] 執行改動相關 browser tests、Node tests、架構與語法檢查。
- [ ] 更新 `WORK_STATUS.md`、`MASTER_CHECKLIST.md`、`UI_TRACEABILITY.md`、handoff、next prompt、AI start 與 manifest。
- [ ] 交付正式版截圖、差異表、測試日誌、完整 ZIP、SHA-256 sidecar。
- [ ] 清楚標示「已實作／自動化已測／視覺已驗收／外部環境未驗證」，不混為一談。

## 本批執行決策

Batch259 不再沿用 Batch258 原先「先補更多 error-state 測試」的優先順序。先建立設計閘門與正式版視覺骨架的替換工作，再分批整合首頁與選歌。既有測試仍需保護功能，但不得阻止對已確認錯誤的視覺架構進行完整替換；變更時同步更新測試契約。


## Batch262 更新
- Home playback history 的作品封面已接上正式 workId mapping 與既有 artwork adapter。這是實際接線與 fixture 驗證，不代表 live ANN/VNDB 已成功載入。
- 舊 Home pie selectors 已從 `src/styles/ui-shell.css` 移除，避免已刪除 DOM 的舊視覺規則持續增加維護成本。
- 空資料 Home 主視覺仍有明顯留白，Home/Catalog osu! 視覺 gate 保持未通過。正常 Catalog data fixture 截圖、live artwork 與 HTTP-origin IndexedDB 仍是阻擋項目。


## Batch264 Quiz 正式版切片
- 正式 Quiz 的遊玩區現在先於設定區顯示，CSS order 不建立第二份 DOM 或狀態來源。
- 四尺寸 browser fixture 38/38；App Shell 144/144；Quiz focused tests 已分組通過。
- 此切片仍未通過最終視覺 gate：截圖 fixture 沒有真實音訊與題目 artwork，且 HTTP-origin IndexedDB 阻塞未解除。


## Batch266 Settings／Results／Multiplayer 更新
- Settings 已落地五類 tablist 與有界內容工作區，保留現有 DOM IDs/state owners；ARIA selected/controls 與方向鍵導覽有 browser evidence。
- Results 移除舊 `01 / ROUND RESULTS` pseudo-element；Multiplayer surface 使用 gradient overlay + 已存在的 Skin role token。
- 四尺寸 browser 58/58，App Shell 144/144；截圖是正式 DOM/CSS fixture/empty-state，live data/audio 與人工 osu! 視覺 gate仍未通過。
- 不得因本批 Settings 結構改善而關閉全域視覺 gate；Home/Catalog P0 差距仍優先處理。
