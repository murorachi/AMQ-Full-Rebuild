# Batch231 交接：Catalog 作品封面 fallback 視覺與來源語義

日期：2026-10-29
工作副本：`/mnt/data/amq_batch231_work/project`
來源交付：`AMQ_Full_Rebuild_Batch230_Navigation_Touch_Target_UI_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch231_Catalog_Artwork_Fallback_UI_20261029.zip`

## 開工檢查與基準
- 已讀取 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、工作狀態／主清單、Batch230 handoff／next prompt、UI traceability 與 OSK role audit。
- 工作副本無 `.git`，未初始化；Candidate302 正式維護基準與 Candidate382 Stage 0 原始檔缺席，未猜測或覆蓋。AMQ／EMQ 資產唯讀。

## 實作
- `src/ui/catalog-browser.js`：作品封面 fallback 由作品標題首個 Unicode 字元衍生 mark，附上來源 AMQ／EMQ／MIX 與 ANIME／GAME／MIX 標籤。真實 artwork adapter 成功時仍顯示真圖；缺少來源／不安全 URL／provider 無結果／圖片錯誤時使用 fallback，不假造封面。
- `src/styles/ui-shell.css`：新增 mark、來源標籤、來源差異色、loading pulse 與 reduced-motion 規則，列表小封面與詳情大封面共用語義結構。
- `tests/catalog-browser.integration.test.cjs`：擴充來源語義、mark、GAME label 與無 adapter fallback assertions。
- `tests/ui-shell-css.contract.test.cjs`：新增 fallback source／mark／motion CSS contract。
- `tests/app-shell.browser.test.py`：增加 desktop／390px mobile computed-style 與 reduced-motion 測試；證據在 `artifacts/batch231-regression/`。

## 驗證結果
- Chromium formal shell：139/139 PASS；桌面／390px 手機、來源 badge、標題 mark、reduced-motion、無水平溢位與無 uncaught browser exceptions。
- Catalog integration + CSS contracts：3/3 PASS。
- OSK import panel browser harness：12/12 PASS。
- Architecture Checker：1,172 PASS／0 FAIL。
- 非-tooling Node test files：81/81 最終逐檔 PASS。首次並行測試時兩個 audio tests 在資源競爭下偶發失敗，序列重跑均 PASS；`quiz-pool` 序列 10/10 PASS。
- `tests/tooling.test.cjs` 全檔未跑；source audit／benchmark／release／signing-key／verifier focused subset 11/11 PASS，Architecture Checker 獨立 PASS。
- 181 JS/CJS syntax PASS；2 Python `py_compile` PASS；AMQ／EMQ asset SHA-256 與 Batch230 相同。

## 未解／阻塞
- HTTP-origin IndexedDB save/reload 仍受 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。
- 真實 `.osk`、live 曲庫／封面 provider／音訊、Candidate302／Candidate382 Stage 0 相容性與實機 UI 未驗收。
- UI 主線未結案；本批只改善 Catalog artwork fallback。

## 下一批：Batch232
1. 盤點首頁與結果頁可重現的 UI／狀態缺口，優先實作主要 CTA、鍵盤 focus、空狀態與手機觸控。
2. 保留真實 round data owner，不造分數；保留 source-aware artwork 契約。
3. 更新同一份清單、工作狀態、traceability、證據、Manifest 與完整 ZIP。
