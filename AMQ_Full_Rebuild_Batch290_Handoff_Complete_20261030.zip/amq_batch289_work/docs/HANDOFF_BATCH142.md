# AMQ 新版重建交接：Batch142（SQLite integrity diagnostics 有界記憶體）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 維持唯讀。

## 修改
- `server/database-integrity.cjs` 對 `PRAGMA integrity_check` 與 `PRAGMA foreign_key_check` 改用 `StatementSync.iterate()`，不再把所有違規 rows 收入 `.all()` array。
- integrity／FK errors 保留完整 count，sample 最多 5 筆；正常 DB 的通過契約不變。
- `tests/database-integrity.test.cjs` 新增 250 筆 orphan command fixture，驗證錯誤總數 250 且 sample 長度 5。

## Targeted test
- `node --test tests/database-integrity.test.cjs`：6/6 PASS。
- 完整回歸與最終封包結果以 `docs/WORK_STATUS.md` Batch142 收尾段落為準。

## 下一步
Batch143：補齊 invalid JSON／unknown phase 的 diagnostic contract；維持 read-only、不自動修復／刪除。
