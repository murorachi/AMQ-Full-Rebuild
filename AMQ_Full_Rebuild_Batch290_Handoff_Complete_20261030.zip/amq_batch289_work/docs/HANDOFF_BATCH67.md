# AMQ Batch 67 交接：答案建議穩定性與換題清空

日期：2026-10-27

## 本批目的
根據使用者對 Batch 66 的實機回報，修正答案建議下拉選單鍵盤索引重設、滑鼠點選不穩定、下拉高頻重建及新題答案殘留；同時增加 EMQ 音訊候選診斷的可辨識度。沒有進行 UI 視覺大改版。

## 程式修改
- `src/ui/answer-suggestions.js`
  - `refresh()` 現在可區分強制更新與一般 render refresh。
  - 一般 render 若 query 沒變，不再重建 option DOM，不重置 activeIndex，不會讓 pointerdown 與 click 之間的 DOM target 被替換。
  - 使用者關閉／選取後，後續 timer render 不會因相同 query 又打開下拉。
- `src/ui/quiz-panel.js`
  - 以新題目物件 identity 作為答案 draft 生命周期邊界。
  - 換題時清空單一答案、作品、歌手、歌曲四欄並關閉舊建議。
  - 音訊失敗列出候選 index、來源 host、檔案格式與失敗原因。
- `src/audio/audio-service.js`
  - 每個失敗候選加入格式副檔名；不將完整 URL／query token 輸出到 UI。
- 測試更新：`tests/answer-suggestions.test.cjs`、`tests/quiz-panel.test.cjs`、`tests/audio-candidates.test.cjs`、`tests/audio-service.test.cjs`。

## EMQ 音訊證據
- 使用者回報歌曲 ID：`2000042847`。
- 唯讀來源資料顯示曲名 `Karera Rashisa`，原始 `v` 只有一個 URL：`https://erogemusicquiz.com/selfhoststorage/userup/weba/58495f58-0048-4177-9b9e-0f1d55b11e32.weba`。
- 目前 resolver 預期生成四個候選：Asia WebA、原始 WebA、Asia sibling WebM、原始 sibling WebM。
- 使用者回報的 UI 只列出 `erogemusicquiz.com：播放請求遭拒`，與預期四候選不一致。Batch 67 會讓每個錯誤明確列出候選索引及 `.weba`／`.webm` 等格式，以驗證實際執行路徑。
- 這些資料只證明本地候選建構，不證明網路可達或可聽。HTTP 500／ORB 不足以單獨證明 CORS，也不足以證明必須新增代理服務。

## 測試證據
- `tests/answer-suggestions.test.cjs`：9/9 PASS。
- `tests/quiz-panel.test.cjs`：PASS。
- `tests/audio-candidates.test.cjs`：9/9 PASS。
- `tests/audio-service.test.cjs`：13 個情境 PASS。
- 全部 `tests/*.test.cjs`：依序執行完畢，全部 exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：480 passed／0 failed。
- source audit、mapper verification PASS。
- 修改 JS/CJS `node --check` PASS。
- Catalog benchmark 本批命令超出工具執行時限，未取得新數據；沒有修改 benchmark 或資料來源，保留 Batch 66 benchmark 結果。
- 未進行真實瀏覽器 E2E；不能把 fake DOM／Node PASS 當作實機驗收。

## 下一步
1. 使用者驗收 Batch 67：方向鍵是否逐項移動且不回滾、滑鼠單擊是否直接選取、答案欄是否停止閃爍、換題是否清空答案。
2. 再測 EMQ ID `2000042847`，記錄候選索引、來源、格式與失敗原因。應能辨識 Asia/original WebA/WebM 是否逐項嘗試。
3. 若錯誤仍只顯示一項，確認執行中的專案是否為 Batch 67 並檢查 runtime 候選陣列；不要直接新增 URL 或代理。
4. 不搜尋 Candidate302、不猜收藏 identity、不重試已知失敗的相同 Chromium CLI；UI／CSS 全面重構仍排最後。

## 來源資料保護
- AMQ `data.js` SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`
- EMQ `emq-data.js` SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`
- 本批未修改來源資料、舊版基準或 Git metadata。
