# Batch204 交接：OSK runtime 跨頁套用修正

本批定位到一個實際整合缺陷：`theme-adapter.js` 原本在 `#catalog-browser` 不存在時直接中止 `apply()`，因此即使首頁／設定／猜歌頁的 role selector 存在，該頁的 roleMappings 也無法套用。現在 role-aware mapping 可以獨立套用到實際 target；legacy `background`／`selectionFrame`／`characterOverlay` 仍限定 Catalog，避免誤用全域背景。沒有 target 且沒有 role mapping 時仍拒絕套用。

## 變更
- `src/skins/theme-adapter.js`
- `tests/skin-theme-adapter.test.cjs`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/HANDOFF_BATCH204.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `artifacts/batch204-regression/*`

## 測試證據
- Adapter tests 13/13 PASS。
- OSK panel Chromium fixture 12/12 assertions PASS。
- Architecture 1,123 PASS／0 FAIL。
- 本批 JS/CJS syntax checks PASS。

## 未驗收
真實 `.osk`、HTTP-origin IndexedDB save/reload、完整正式頁面視覺、真實曲庫／音訊與 Candidate302／Candidate382 Stage 0 相容性都未驗收。工作副本沒有 `.git`，沒有初始化。AMQ／EMQ 資產未修改。

## 下一批
Batch205：逐頁核對 runtime role selector／CSS consumer 的語義，尤其區分選曲列表背景、作品封面、面板背景與裝飾素材；補齊 apply/reset contract tests。不要以角色數量或架構檢查通過代替 UI 驗收。
