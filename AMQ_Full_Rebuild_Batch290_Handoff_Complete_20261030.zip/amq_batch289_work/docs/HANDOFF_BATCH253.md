# Batch253 Handoff：交付證據一致性與最終缺口判定

## 基準與安全
- 唯讀基準 Batch252 ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch252_Skin_Fidelity_20261029.zip`。
- SHA-256：`514f7dd94063105617609fc89d5ad048ee4531c62900dfe2dfa7517c7ea9be3b`，已與 sidecar 核對；ZIP CRC 通過。
- Batch252 handoff 曾記錄錯誤 hash `a090ef...`，本批更正工作副本內的 `docs/HANDOFF_BATCH252.md`；未覆蓋原始 ZIP。
- 工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch253_Final_Audit/AMQ_Full_Rebuild_Batch245_Project`；無 Git repository，未初始化。

## 實作
- `tools/audit-visual-role-coverage.cjs` 支援 `--output-dir <path>`，保留原本無參數輸出路徑以相容既有 tests。
- `tests/visual-role-audit.test.cjs` 新增隔離輸出測試，確認歷史 Batch245 JSON 不被改寫。
- role audit：48 total／35 wired／13 unsupported／35 CSS consumers／31 direct-test source hints／33 with static gaps。此為靜態 triage，不是逐角色 browser acceptance。

## 測試證據
- Node：92/92 `*.test.cjs` files 最終逐檔 exit 0；`artifacts/batch253-regression/node-tests/results.tsv`。
- Architecture：1,293 PASS／0 FAIL。
- JS/CJS syntax：186/186；Python compile：14/14。
- Chromium app-shell：150/150；cross-page：45/45；Home/Catalog：22/22；Backup/Restore：8/8；Skin Canvas：9/9。
- 證據根目錄：`artifacts/batch253-regression/`。
- AMQ raw data SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ raw data SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 封包驗證
- `MANIFEST.sha256` 共 6900 entries（排除 manifest 本身）；逐項 SHA-256 驗證通過。ZIP CRC 與 ZIP 內逐項 manifest 核對於封裝後完成。
- ZIP SHA-256 以交付旁的 `.sha256` sidecar 為準，避免將自我雜湊寫入封包內造成循環。

## 未完成／下一步
- 35 wired roles 的逐角色 browser apply/fallback/reset；13 unsupported roles。
- HTTP-origin IndexedDB `ERR_BLOCKED_BY_ADMINISTRATOR`、live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0、native osu!stable compositor fidelity。
- 工程候選已完成本地回歸整理，但產品最終驗收未完成。
- Batch254：先完成可本地驗證的 Skin role browser matrix，保留每一角色的 evidence 與明確缺口。
