# AMQ／EMQ 來源資料靜態稽核

日期：2026-10-27  
狀態：**來源檔案結構稽核完成；Batch 20 已將這兩份來源副本納入新版並完成全量 mapper／Catalog 驗證。Candidate302 配套關係、真實瀏覽器 E2E 與音訊播放仍未驗收。**

## 1. 來源與可信範圍

本次從 ChatGPT Library 取得兩個實際檔案：`data.js`、`emq-data.js`。已確認 Candidate382 Stage I 參考 HTML 以 `<script src="data.js">` 與 `<script src="emq-data.js">` 引用這兩個檔名；參考 HTML SHA-256 為 `e4c497b72f3803f538fc9900f33ed2ffa6f1cb65c68774a8631b545290ac6747`。

這只能確認它們符合 Candidate382 Stage I 的來源檔名與結構入口。**尚未證明這兩個檔案就是 Candidate302 的配套資產，也未證明 Candidate382 Stage 0 使用相同內容。** 本報告不升格任何基準、不修改原始檔、不把來源相容性或音訊可播放性當作已驗收。

## 2. 檔案雜湊與大小

| 檔案 | 大小 | SHA-256 | 已確認結構 |
|---|---:|---|---|
| `data.js` | 4,975,244 bytes | `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3` | `window.DB`，含 `anime`、`songs` 陣列 |
| `emq-data.js` | 2,684,266 bytes | `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc` | gzip + Base64 封裝的 JSON |

EMQ 解壓後 JSON 為 8,383,856 bytes，`version=1`、`createdAt=2026-10-16`，來源標記為 `EMQ public song DB dump 2026-10-16`。

## 3. 實際稽核結果

| 檢查 | 結果 |
|---|---:|
| AMQ 作品 | 9,516 筆，固定每列 7 欄 |
| AMQ 歌曲 | 38,821 筆，固定每列 12 欄 |
| AMQ 作品 ID 重複 | 0 |
| AMQ 歌曲 ID 重複 | 0 |
| AMQ 歌曲指向不存在作品 | 0 |
| EMQ 作品 | 6,645 筆 |
| EMQ 歌曲 | 16,839 筆 |
| EMQ 作品 ID 重複 | 0 |
| EMQ 歌曲 ID 重複 | 0 |
| EMQ 歌曲指向不存在作品 | 0 |
| AMQ／EMQ 作品 ID 碰撞 | 0 |
| AMQ／EMQ 歌曲 ID 碰撞 | 0 |
| EMQ 歌曲含至少一個 HTTPS 音源候選 | 16,839 筆 |
| EMQ 歌曲具有非空歌名及歌手 | 16,839 筆 |

AMQ 歌曲欄位 9、10、11 的非空數量分別為 37,939、14,888、28,875。這些只是欄位非空統計，不代表連結有效或可播放。

## 4. 欄位結構與映射證據

### AMQ

- `DB.anime` 每列 7 欄。Candidate382 Stage I 程式碼使用 `[0]` 作作品 ID、`[1]`／`[2]` 作作品名稱、`[3]` 作季度文字、`[4]` 作作品類型、`[5]` 作年份、`[6]` 傳入封面查詢函式作 MAL ID。
- `DB.songs` 每列 12 欄。Candidate382 Stage I 程式碼使用 `[0]` 作作品關聯 ID、`[1]` 作歌曲 ID、`[2]` 作歌曲類型、`[3]` 作顯示順序、`[4]` 作歌名、`[5]` 作歌手、`[6]` 作難度顯示；音源處理程式把 `[9]` 當音訊檔名、`[10]`／`[11]` 當影片檔名。
- 上述欄位語意以 Candidate382 Stage I 程式碼的讀取方式為證，不代表 Candidate302 已驗證使用相同 schema。

### EMQ

- JSON 頂層包含 `version`、`createdAt`、`source`、`songs`、`works`。
- `works` 欄位聯集：`i`、`t`、`n`、`y`、`st`、`r`、`vndbId`。
- `songs` 欄位聯集：`i`、`o`、`w`、`r`、`t`、`a`、`aa`、`n`、`ta`、`v`、`d`、`k`、`y`、`wt`、`wn`、`wa`、`st`、`links`。
- Candidate382 Stage I 的載入程式檢查版本及 `songs`／`works` 陣列，並檢查 ID 唯一性、AMQ／EMQ ID 衝突及歌曲對應作品存在。這些規則可作為後續契約候選，但仍需與正式基準及產品需求對照。

## 5. 自動化工具

新增 `tools/audit-source-data.cjs`，可對使用者指定的兩個來源檔案重複執行：

```bash
node tools/audit-source-data.cjs /path/to/data.js /path/to/emq-data.js
```

工具檢查陣列結構、固定列長、ID 唯一性、歌曲作品關聯、跨來源 ID 碰撞、EMQ gzip／JSON 格式，並輸出 SHA-256 與統計 JSON。它不會將原始資料寫回或修改。

新增 `tools/check-architecture.cjs`，檢查模組載入順序、HTML 本地引用、重複 ID、JavaScript 語法、明確禁止的過期 API、核心／資料層依賴方向及重複函式宣告。

## 6. 尚未完成（依目前專案規範更新）

1. 不再搜尋 Candidate302；使用者明確指定以其提供的 `AMQ382(1).html` 作為舊版參考。該檔 title 顯示 Candidate381，且有 Stage I 線索，不得把它宣稱為 Candidate382 Stage 0。
2. 保留使用者指定的 Candidate382 Stage 0 CSS 比較基準身份，但在未取得／核實實際檔案內容前，不宣稱已完成精確 CSS 相容性比較。
3. AMQ／EMQ 資料 mapping 與 source-runtime 已有 Node 驗證；剩餘問題是實際瀏覽器中的音源 HTTP 回應、跨域與可聽性。
4. 在可用瀏覽器中完成真實載入、localStorage 跨頁行為與 UI／E2E 驗收。
5. SRS 黑名單資料源尚未接入；EMQ SRS 暫不支援，因舊版 schedule 卡片沒有 source 欄位。


## Batch 20 工作包接線紀錄

本批將兩份原始檔以位元組完全一致的副本放入 `src/data/assets/data.js` 與 `src/data/assets/emq-data.js`，其 SHA-256 與上表相同。`src/index.html` 載入這兩份靜態資產；`src/data/source-runtime.js` 以既有 mapper 與資料管線建立 AMQ／EMQ adapter。原始資產沒有被改寫，也沒有映射音源欄位為可播放候選。MIX 仍明確阻擋，直到產品來源規則被核實。


## Batch 22：quiz 音源候選生成驗證

使用者提供參考 HTML（SHA-256 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`）的第 673 行列出 AMQ audio mirror 順序；第 696 行 `mediaFiles(s)` 以 AMQ 歌曲 row[9] 作音訊候選、row[10]/row[11] 作影片候選；第 700–701 行呈現 host／候選 fallback；第 6,151 行 EMQ `getAudioUrls(id)` 對 Catbox selfhoststorage URL 先加入 `files.catbox.moe` mirror，再保留原 URL並去重。

Batch 22 將這些可直接觀察到的規則實作到 `src/data/audio-candidates.js`，並接入 mapper／validator。全量 mapping 的候選統計：AMQ 38,821 首中 37,939 首有音訊候選、882 首無 row[9] 音訊檔名，共 113,817 個鏡像 URL；EMQ 16,839 首全部有候選，共 20,085 個 URL。這些統計只代表候選字串已生成且符合新版內部結構，不證明 URL 有效或實際可聽。


## Batch 24：舊版熟悉度儲存規則

使用者提供參考 HTML 的第 403 行 `loadStatus()`、第 405 行 `save()` 及第 870–872 行 `__aniHistoryAPIv51.getStatus/setStatus` 證實：AMQ 熟悉度使用 `aniCollection_v2`，讀取時可 fallback 到 `anisongFieldGuide_v1`，寫入派發 `ani-familiarity-updated-v51`，level 0–3；設成 0 會刪除 key。

新版 `FamiliarityStore` 保留 AMQ 的既有 key 與事件；因 EMQ song ID 與 AMQ 數字 ID 可重疊，EMQ 使用獨立 key `amqLearningFamiliarityV1`，不把來源不明的舊 status map 自動解讀成 EMQ 熟悉度。這是為避免資料互相覆蓋而採取的明確 source-aware 分隔，不是聲稱舊版已有此 EMQ key。


## Batch 27：SRS UI 整合與目前未驗收項目

- FSRS-6 scheduler／SRS store 已接入既有 QuizSession UI。SRS 評級 1–4 是使用者對回憶難度的獨立判斷，不會從猜歌正誤或 familiarity level 自動推導。
- `aniSrsScheduleV1` 卡片沒有 source 欄位，因此目前只支援 AMQ。黑名單資料源尚未核對與接線；EMQ SRS 不會被猜測加入舊版裸 ID map。
- 現有 source-runtime Node integration 使用實際 `src/data/assets/data.js` 與 `src/data/assets/emq-data.js`，得到 AMQ 37,939 筆、EMQ 16,839 筆可播放 pool；此結果只證明內部 mapping／候選結構，不證明真實 URL 可播放。
- 真實瀏覽器 E2E、跨頁 localStorage／storage event、autoplay／CORS 與音訊實際可聽性仍未驗收；環境既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋未解除。
