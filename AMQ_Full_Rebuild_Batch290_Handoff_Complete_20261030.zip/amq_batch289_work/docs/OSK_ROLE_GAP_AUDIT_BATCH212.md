# OSK Runtime Role 缺口盤點（Batch212）

日期：2026-10-29

## 本批新增的真實 target

- `results.panel`：接到既有 `#quiz-round-results`，使用 `--amq-skin-role-results-panel`。該 DOM 是真實、資料驅動、只在 QuizSession `finished` 顯示的本輪結果面板。CSS 以深色半透明遮罩疊在 skin asset 上，避免高對比素材直接破壞結果文字可讀性。此 role 只代表面板外觀，不會把 osu!stable ranking score／PP 套成 AMQ 計分規則。
- `tests/app-shell.browser.test.py` 實際套用一個 fixture skin asset 到此 role，驗證 DOM target、runtime mapping 與 CSS token consumer。這不是對真實 `.osk` 的驗收。

## Batch214 新增支援：`multiplayer.ready-state`

- `src/ui/multiplayer-panel.js` 將每位玩家的名稱與準備狀態拆成獨立語義節點；狀態 badge 使用 `data-ready`、`aria-label` 與可見文字區分「已準備／未準備」。
- `src/skins/theme-adapter.js` 將 role token 放在穩定存在的 `#multiplayer-players` 容器，避免房間尚無玩家列時被誤判 unsupported；CSS 只在 `.multiplayer-player-ready-state` badge 消費該 token，不會把準備素材套到整列，並保留文字對比與手機排版。
- Chromium fixture 會核對 selector 與 CSS consumer；多人面板 integration test 核對 ready 狀態更新後 DOM 反映正確狀態。這不表示已驗收真實多人 server／多客戶端。

## Batch214 當時仍不支援的 15 個 role（歷史盤點；Batch215 已解除兩項）

| Role | 保持 unsupported 的原因 | 解除條件 |
|---|---|---|
| `app.home.ambient-effect` | optional snow effect 尚無 home-only animation host／reduced-motion lifecycle；既有 `app.ambient-effect` 是通用 header visual，不可混用 | 建立首頁專用效果 host、reduced-motion 與 dispose 測試 |
| `app.navigation.options` | 目前沒有獨立的 options button DOM；設定導航不是同一個原生選項按鈕語義 | 明確設計並建立實際 options entry |
| `catalog.action.random` | Catalog 沒有「隨機選曲」操作；播放器的隨機播放不是隨機選曲 | 先確定產品操作語義並建立真實控制項 |
| `catalog.difficulty-marker` | Catalog 列目前不顯示難度星標，不能把其他欄位偽裝成難度 | 在需求確認後新增真實難度標記 DOM／CSS |
| `catalog.song-artwork` | 這是實際作品封面，不是 OSK 角色圖；stable asset manifest 沒有可安全當作品封面的通用資產 | 由真實 artwork provider 提供作品封面，或使用明確可替換的專用 artwork asset 契約；不得用隨機角色圖 |
| `feedback.success` | 成功提示目前由多個狀態文字共用，沒有獨立且穩定的 success-only visual target | 建立明確的成功狀態 token／語義，不把一般狀態文字都當成功 |
| `learning.history.item` | 現有 dashboard 各統計列表不是已確認的單一 history item role | 指定真實歷史列 DOM 並加入 CSS consumer／空狀態測試 |
| `learning.review.item` | SRS 複習項目目前不是獨立可映射的 review row role | 建立正式 review item DOM 後再接入 |
| `quiz.result.correct` | `stable.ranking.grade.a` 是 osu! 成績等級，不等於 AMQ 答案正確；不能直接套用 | 若需要此 role，需獨立 AMQ 正誤視覺契約，不能映射 osu! grade |
| `quiz.result.incorrect` | 同樣沒有語義專屬的錯誤回饋 target；不得把一般 alert 變成錯誤專屬素材 | 建立真實錯誤回饋狀態／target |
| `results.grade` | osu! grade 與 AMQ 目標正誤／熟悉度／SRS 不同；目前沒有對等 AMQ grade | 產品明確定義 AMQ 結算等級後再決定是否適用 |
| `results.primary-action` | 本輪結果面板沒有獨立且固定的 primary action；開始新回合仍由既有控制流程管理 | 明確設計結果頁主要操作並建立真實 DOM |
| `settings.dialog` | 設定頁不是 dialog，且沒有 settings-only `<dialog>` target | 真正建立可存取的設定對話框後再接入 |
| `settings.entry` | 沒有獨立的設定入口元件；導航按鈕與 options entry 不能混成一個角色 | 確認入口 UI 與語義後建立 target |
| `settings.slider` | 設定頁目前沒有 range input；播放器進度條不是設定滑桿 | 建立真實設定滑桿後再接入 |

## 規則與驗收

- runtime selector 由 31 增至 32；manifest、adapter、CSS token consumer 與 Chromium contract test 同步更新。
- Batch212 當時的 `tests/skin-contract-manifest.test.cjs` 鎖定 16 個 unsupported roles；Batch214／215 後續新增語義 target 時必須同步更新此審查清單與目前數量。Batch215 目前是 34 個 runtime roles、13 個 unsupported roles。
- 不為了追求角色數量而把 skin 資產套到語義不相關的 UI。剩餘 role 都需要先滿足解除條件，再新增 runtime selector。


## Batch215 後續：Learning history／review role 已接入

Batch212 的 15-role 表格是當時的歷史盤點，保留不改寫。Batch215 建立兩個真實學習清單後，以下兩個 role 已有語義正確的 DOM target、CSS consumer 與回歸測試：

- `learning.history.item`：selector `#learning-history-list`，每筆答題紀錄顯示歌曲名稱、來源／作品、作答目標、實際結果與時間。資料只讀既有 Quiz History Store，最多顯示最近 8 筆；儲存讀取失敗時清空清單並明示失敗，不把錯誤顯示成空資料。
- `learning.review.item`：selector `#learning-review-list`，項目只取既有 SRS store `chooseSession()` 回傳的到期 ID，再以 `snapshot()` 核對卡片狀態／到期時間；新卡與暫停卡不會被列成到期複習。顯示全部到期數與最多 8 筆可加入複習的卡片。由於目前 SRS 卡片本身不保存作品標題，清單以明確的曲目 ID 顯示，不捏造歌曲標題；待可靠的 source-aware title resolver 可注入時再改善顯示。
- 兩個 role 的 token 分別由 `.learning-history-item`／`.learning-review-item` 消費，使用深色可讀底層與 Skin 視覺疊加。Selector 掛在穩定的 list container，避免空清單時 role 被誤判為不存在。
- Runtime selector inventory 由 32 增至 34；47 個契約角色中，13 個仍明確 unsupported。`tests/skin-contract-manifest.test.cjs` 與 Chromium shell contract 已同步鎖定此狀態。

驗證：`statistics-dashboard-panel.test.cjs` PASS，涵蓋真實歷史 row、僅顯示到期 SRS 卡、讀取失敗不顯示假空狀態；`tests/app-shell.browser.test.py` 86/86 PASS，檢查兩個 role target／CSS consumer、手機單欄與設定快速導覽。這些仍是合成資料／inline Chromium 契約測試，不等於 HTTP-origin 持久化或真實外部曲庫驗收。


## Batch216 後續：學習列作品封面不是新的 OSK role

- `learning.history.item` 與 `learning.review.item` 保持現有兩個 role，不因增加 artwork slot 就擴充 role inventory。兩個 role 的 token 仍由真實 list item 背景消費；封面本身使用 app artwork adapter，不從 OSK 角色圖推測作品封面。
- 學習列只在 Catalog exact source + song ID 對應成功且 record 有 `artworkRef` 時請求封面。未對應、沒有 provider、載入錯誤與 stale Promise 都使用 fallback；不改動剩餘 13 個 unsupported role 的狀態。
- `tests/statistics-dashboard-panel.test.cjs` 驗證跨來源相同 song ID 不互相命中、封面非同步更新與 dispose 後 late completion。真實 `.osk` 與 live provider 仍未驗收。


## Batch217：不新增 OSK role

- Catalog row focus restoration／44px touch target 與多人 `aria-busy` 都是既有元件的互動／可存取性改善，不是新的 skin role；runtime role inventory 維持 34 supported／13 unsupported。
- 不把 ready/busy/error 狀態圖形套到通用 role；狀態仍由可見文字、ARIA 與原本 server snapshot 契約表達。剩餘 13 roles 不因本批互動樣式而改變狀態。


## Batch218：驗證現有角色／狀態契約，不新增 role

- 本批只擴充 QuizPanel completed-round remount、Catalog focus fallback 與 multiplayer pending-command lifecycle 測試，不新增或重映射 skin roles。runtime inventory 維持 34 supported／13 unsupported。
- `aria-busy`、server error 與 result restoration 是狀態／生命週期契約，不把它們映射成 osu!stable 成績圖或新的角色素材。


## Batch219：命令錯誤修正不新增 OSK role

- `commandError` 是多人命令生命週期狀態，不映射成新的 osu!stable-inspired role；runtime inventory 仍為 34 supported／13 unsupported。
- `ROOM_COMMAND_REJECTED` 保留在既有 `#multiplayer-error[role=alert]`，成功 retry 清除。未把伺服器拒絕誤當成 ready／room phase 改變。


## Batch220：network recovery regression 不新增 OSK role

- Multiplayer network error／offline recovery 只使用既有 `#multiplayer-error[role=alert]` 與 `aria-busy`，不新增或重映射 skin role。runtime inventory 仍為 34 supported／13 unsupported。


## Batch221：Catalog empty-state 修正不新增 role

- 新增的 Catalog mode-switch integration 與 `empty`／`filtered-empty` 狀態優先序修正不改 skin role inventory；runtime 仍為 34 supported／13 unsupported。
- 不把空曲庫、篩選無結果或載入失敗映射成 OSK 圖片 role；這些狀態由既有 status／empty/error DOM 與 `data-catalog-state` 表達。


## Batch222：Catalog 狀態矩陣不新增 OSK role

- `partial`／`failed`／`empty`／`filtered-empty` 均由既有 status／empty/error DOM 與 `data-catalog-state` 表達，不映射成新 skin role。runtime inventory 維持 34 supported／13 unsupported。


## Batch223：錯誤／重試 UI 不新增 OSK role

- Catalog `partial`／`failed`／`retrying` 的狀態由既有 `#catalog-status`、`#catalog-error`、`#catalog-reload`、`aria-busy` 與 `data-catalog-state` 表達。這些互動狀態不等於新的 stable 資產角色。
- Runtime roles 維持 34 supported／13 unsupported；沒有把 error banner、retry button 或 partial-count 資訊塞進語義不符的 OSK role。


## Batch224：結果 CTA／多人 focus 不新增 OSK role

- 結果頁主要操作仍是 AMQ 自訂導覽，不把 stable 的 back／menu 素材誤當成成績等級或 native results action。
- Multiplayer command busy、focus restoration 與 44px touch target 由現有 DOM／CSS／ARIA 契約管理，不映射到不相干的 stable 角色。
- Runtime inventory 維持 34 supported／13 unsupported。


## Batch225：Quiz audio／error state 不新增 OSK role

- Audio status 與 error banner 使用既有 Quiz UI 元件的 ARIA／data-state 投影；不把 blocked／failed 誤映射成 osu!stable 原生 ranking 或 combo role。
- 操作與建議清單的 touch target、hover、disabled 狀態由正式 CSS consumer 管理；沒有新建或錯誤宣稱 OSK runtime role。
- Runtime inventory 維持 34 supported／13 unsupported。


## Batch226：多人狀態與結果明細不新增 OSK role

- Multiplayer round/audio/error state 使用既有 DOM 的 `data-*`／ARIA 語義與 CSS consumer；不將 active／expired／failed 假稱為 stable 原生 ranking／combo role。
- 結果明細長標題與 unsaved note 的換行是 AMQ 自訂資料呈現，不需要新的 stable 素材 role。
- Runtime inventory 維持 34 supported／13 unsupported。


## Batch227：Question-card 樣式替換不新增 OSK role

- 移除 global `.quiz-question-card` light surface，改由 quiz stage／multiplayer card 的實際 DOM consumer 各自定義樣式。
- 不因 CSS card 重新歸屬而增加 stable role；runtime inventory 維持 34 supported／13 unsupported。
