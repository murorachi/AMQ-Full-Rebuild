# 歌曲標籤與曲庫批次操作契約（Batch188）

## 單一資料來源

- 標籤定義與歌曲關聯只由 `AMQPersistence.songTagsStore` 管理，保存於 `amqSongTagsV1`。
- 標籤 ID、名稱及關聯的衍生 `tagIds` 可出現在 Catalog query-index snapshot，但不在 query-index 或 UI 另行保存。
- 只接受來源 `AMQ` 或 `EMQ`。歌曲關聯鍵使用 `AMQData.identity.createIdentity(source, id)`，保留來源與 ID 型別，避免 AMQ／EMQ 同 ID 撞號。
- 最多 200 個標籤；名稱 trim、合併連續空白、最多 32 字，不分大小寫不可重複。
- 刪除標籤會在同一次 storage commit 中移除所有對應歌曲關聯。
- 批次套用／移除標籤透過 `setSongTagForMany()` 單次提交；寫入失敗時不更新記憶體 state。

## Catalog 篩選

- Query-index 接受 `tagId` 條件，與其他條件 AND 組合；`tagId` 若為陣列，符合任一標籤即可。
- Catalog Browser 透過 Tag Store 將 `tagIds` 加入每次重建的 query-index record snapshot。
- 標籤 CRUD／跨分頁 storage event 會刷新衍生索引。刪除目前正在使用的篩選標籤會清除失效的篩選值。
- 具名曲庫篩選預設也保存 `tagId`，因此套用預設可恢復標籤條件；如果標籤已刪除，套用時會清除不存在的條件。

## 批次操作

- 每列 checkbox 與「選取本頁歌曲」使用 source-aware song identity；選取狀態可跨分頁保留，切換 AMQ／EMQ／MIX 時清空，避免跨模式誤操作。
- 批次操作包括：加入目前自訂清單、套用標籤、移除標籤。清單操作依來源明確作品參照去重；標籤操作使用單次提交。
- 自訂清單是作品層級，歌曲標籤是歌曲層級，兩者不可混為同一資料。
- 批次加入清單可能因現有個人清單 API 的逐作品提交而部分成功；UI 會回報成功／失敗數量，不宣稱原子性。標籤批次操作則是單次提交。

## 備份／還原

- `amqSongTagsV1` 已加入既有版本 1 backup envelope 的支援 key；匯出及 preflight 使用同一個 `songTagsStore.normalizePayload()` schema 驗證。
- 舊備份若省略標籤 key，還原時不會刪除使用者目前標籤。無效標籤資料在 preflight 階段拒絕，不進入寫入階段。
