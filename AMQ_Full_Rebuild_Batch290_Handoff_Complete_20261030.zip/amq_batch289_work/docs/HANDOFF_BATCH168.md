# Batch168 交接：Catalog root validation 與 Quiz Panel constructor rollback

## 確認
- 工作副本：`/mnt/data/amq_batch153_work`。工作副本無 `.git` metadata，未初始化 Git。
- Candidate302、Candidate382 Stage 0、原始 AMQ／EMQ 曲庫資產維持唯讀。
- 已讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、Batch167 handoff 與 next prompt。

## 實作
- `src/ui/catalog-browser.js`：在建立任何自有 Store／Chinese Title Provider 前先驗證 `#catalog-browser` root，缺少 root 時立即 fail fast。
- `src/ui/quiz-panel.js`：新增初始 Store acquisition transaction。已建立的自有 Blacklist、AMQ／EMQ SRS、Familiarity、Quiz History、App Settings、Personal Library stores 會在後續建構或 `personalLibraryStore.refresh()` 拋錯時依反向取得順序 dispose。注入的外部資源不列入清理；原始錯誤重拋，清理例外掛到 `cleanupErrors`。
- `tests/catalog-filter-layout.contract.test.cjs`：新增 Catalog root check 順序及 Quiz Panel acquisition rollback boundary contract tests。

## 驗證證據
- 受影響測試：12/12 top-level suites PASS。
- Architecture：1,051 PASS／0 FAIL。
- OSK panel：12/12 assertions PASS。
- `src`、`tests`、`tools`、`server` 共 160 個 JS/CJS 檔案語法檢查 PASS。
- 71 個 Node test files 分組完成，167/167 tests PASS、0 FAIL；所有已記錄組別 exit 0。首次 orchestration 超過外層工具時間限制後，剩餘組別拆小執行，未將中斷命令宣稱成功。
- 完整日誌、檔案清單、Exit Code 與 `summary.json`：`artifacts/batch168-regression/`。

## 限制／待辦
- 本批 rollback 邊界只覆蓋 Quiz Panel 初始 Store acquisition 與 Personal Library refresh；後續 Chinese Title Provider 建立及剩餘 mount wiring 的 failure-path 尚未做實際注入測試。
- 真實瀏覽器 viewport、ANN API／CORS／圖片、真實 `.osk`、非 opaque HTTP origin IndexedDB save/reload/clear 仍未驗收。
- 工作副本沒有 Git metadata。

## 下一批 Batch169
1. 為 Quiz Panel 後續初始化（Chinese Title Provider、session 建立與後續訂閱／接線）建立實際 failure injection，確認 mount 失敗時所有先前取得的自有資源都會釋放。
2. 若需擴大 rollback 範圍，採最小交易式 mount helper，避免雙重 dispose 並保留原始錯誤。
3. 盤點其他仍有多資源 constructor 的 panel，只修可重現漏洞。
4. 執行受影響測試、architecture、syntax 與全量 Node 分組回歸。
5. 完成生命週期缺口後，把主線轉回最小可玩版本核心流程的實際功能缺口，不無限延長架構批次。
