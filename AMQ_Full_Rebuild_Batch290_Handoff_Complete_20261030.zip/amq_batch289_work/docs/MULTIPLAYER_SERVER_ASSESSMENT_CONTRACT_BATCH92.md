# Multiplayer Server-Owned Answer Assessment Contract（Batch 92）

## Purpose

`src/multiplayer/server-answer-assessment.js` is a server-side adapter that connects trusted question records to the existing answer evaluator and the existing `work-title-latency-v1` assessment engine. It does not write SRS schedules, create a scheduler, or run inside the single-player app.

## Trusted inputs

- `questions`: server-owned `{ questionId, target, record }` entries. IDs must be unique and target is fixed by trusted round configuration; an unknown question ID or missing／invalid target is rejected.
- API: `assessSubmission(submission, trustedContext)` keeps client submission data separate from trusted server context. `submission` carries only the question ID and answer text(s); `trustedContext` supplies the lifecycle outcome (`answered`, `timeout`, `skip`, `revealed`, `unplayed-skip`, `cancelled`) and server timestamps. Never copy these context fields directly from a client payload.
- `startedAt` / `receivedAt`: trusted server timestamps. Client timestamps are not accepted as a source; missing timestamps produce unknown latency, and invalid / reversed timestamps are rejected.
- `target`: fixed in the server-owned question context, not read from a submission.
- `acceptPartial`: configured once in assessor dependencies, not controlled per submission by the client.

## Assessment rules

- For `anime`, the trusted evaluator compares only the submitted work title against the trusted record and aliases.
- For `all`, only `answers.anime` is evaluated. Song title and artist answers never affect automatic SRS grade.
- Timeout and an answered-round skip are incorrect work-title signals (grade 1). Reveal, unplayed skip and cancellation are no-grade outcomes.
- Correct title with trusted latency reuses the existing rule: 0–10 seconds => grade 4; >10–15 seconds => grade 3; >15 seconds => grade 2. Correct title with missing latency has no grade. The existing `work-title-latency-v1` rule and FSRS semantics are unchanged.
- Client-provided `correct`, `correctByTarget`, `grade`, `score`, `elapsedSeconds` and `acceptPartial` fields are ignored. Output contains the server-derived work-title correctness and assessment only; raw answer text is not echoed.

## Boundary and limitations

The adapter still requires a trusted server caller to authenticate room membership, bind the submitted answer to a single accepted `answer.submit`, and provide the trusted context/timestamps. Client-supplied target, outcome, and timestamps are ignored because the target comes from the server-owned question context and outcome/time come from the separate trusted-context argument. It does not authenticate connections, own transport, persist schedules, or prevent callers from invoking it with fabricated trusted arguments. Server integration and multiplayer E2E remain unimplemented.
