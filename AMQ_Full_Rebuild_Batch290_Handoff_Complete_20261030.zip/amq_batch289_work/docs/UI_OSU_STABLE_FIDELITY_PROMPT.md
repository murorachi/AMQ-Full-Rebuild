# AMQ UI 忠實重建提示詞（Stable Screenshot Fidelity + OSK Mapping）

> 這份文件是後續 UI 開發的強制提示詞。它覆蓋「只參考 osu! 風格」這種寬鬆解讀。使用者要的是依 Stable 預設 Skin 截圖忠實重建，目的是讓 OSK 資產能對應到可替換的元件。

## 0. 任務定義

你是 AMQ UI 的實作者，不是自由發揮的視覺設計師。

主要視覺基準：
- `artifacts/osu-reference/osu-main-menu.jpg`
- `artifacts/osu-reference/osu-intro-screen.jpg`
- `artifacts/osu-reference/osu-song-selection.jpg`
- `artifacts/osu-reference/osu-multiplayer-lobby.jpg`
- `artifacts/osu-reference/osu-game-modifiers.jpg`

原始碼研究參考：
- 專案內 `references/osu-master.zip`（由使用者上傳），SHA-256：`973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`
- 詳細研究：`docs/OSU_SOURCE_RESEARCH_BATCH271.md`

Stable 截圖決定視覺；Lazer 原始碼只用於理解可借鑑的元件分層、狀態、動畫、資產解析和 fallback。禁止將 Lazer 目前畫面當成 Stable 截圖的替代品。

## 1. 嚴禁自行改設計

- 不得將參考圖改成通用 SaaS Dashboard、白色卡片牆、平均分欄或無目的圓角卡片。
- 不得只換成深色、粉紫色或加幾個斜角，就宣稱「像 osu!」。
- 不得用 emoji、隨機漸層、純色方塊或空白圖像取代參考圖中的圖示、Logo、作品封面或背景藝術。
- 不得把背景、Logo、按鈕、圖示、文字和狀態一次烘焙進一張不可拆分的圖片。
- 不得自行刪除參考圖中的資訊區、操作區、狀態顯示或密度，只因為覺得畫面比較清爽。
- 不得在 AMQ 中虛構不存在的分數、倍率、房間、玩家、近期作品或排行榜。
- 不得複製 osu! 專屬遊戲規則來填補 AMQ 功能缺口。
- 不得要求使用者匯出 Stable 預設 Skin 的 `.osk`；使用者已說明預設 Skin 無法匯出。
- 不得將 fixture 截圖當作正式資料、外部封面、音訊或多人伺服器的驗收證據。
- 不得在沒有並排截圖與差距表的情況下宣稱視覺驗收通過。

## 2. 實作前的必做確認

1. 讀 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/UI_TRACEABILITY.md`、`docs/DESIGN_LANDING_FLOW.md`、`docs/DESIGN_GAP_REGISTER.md`、`docs/UI_COPY_POLICY.md`、最新 handoff 與本提示詞。
2. 讀 `docs/OSU_SOURCE_RESEARCH_BATCH271.md`，理解 Stable screenshot 與 Lazer source 的證據界線。
3. 找出目前正式 DOM、CSS、事件 handler、state/store/API owner；列出精確 selector／檔案路徑後才修改。
4. 先檢查現有 Skin Registry、Asset Mapper、Resolver、OSK parser、角色稽核與測試，不要另建重複系統。
5. 每個頁面先定義 screenshot traceability：參考圖區域 → AMQ 功能 → DOM owner → Skin component ID → asset mapping → interaction state → test evidence。

## 3. Main Menu：必須照圖重建

參考：`osu-main-menu.jpg`。

### 構圖
- 使用全畫面背景圖層，暗色但不是純黑死底。
- 中央偏左放置大型圓形主視覺，具有白色外圈與粉紅色內部圖樣。
- 主視覺在視覺上與右側主選單相互重疊；不可改成彼此分離的兩張卡片。
- 右側排列四條縱向主選單：Play、Edit、Options、Exit 的結構。
- 選單列是長條、略帶斜切／shear 端點的按鈕，紫色底、白色文字，右側有對應圖示。
- 主選單的高度、間距、對齊和 Logo 比例以原圖為準；不要以 CSS Grid 的均分結果代替像素對照。
- 角落系統資訊保持低干擾；不能另加一堆眉標、裝飾數字或產品說明。

### 元件分層
至少拆分：
- `home.background`
- `home.logo`
- `home.logo.inner-art`
- `home.logo.outer-ring`
- `home.logo.particle-layer`
- `home.menu.button.play`
- `home.menu.button.edit`
- `home.menu.button.options`
- `home.menu.button.exit`
- 每個按鈕的 `background`、`icon`、`label`、`hover-overlay`、`pressed-overlay`
- `home.system-status`
- `home.online-status`（只有正式資料存在時顯示）

### 互動
- hover：底板延伸／展開或可驗證的等價效果，圖示與文字維持對齊。
- pressed：明確的遮罩／亮度回饋。
- focus：鍵盤可見 focus，不可只支援滑鼠。
- activation：使用既有 `navigate()` 和真實 route；不得建立第二個 navigation owner。
- reduced-motion：關閉或縮短非必要粒子與彈性動畫。
- 每個視覺狀態都應由明確狀態驅動，不可用 hover-only CSS 假裝選取狀態。

Lazer source `MainMenuButton.cs` 顯示可拆的 background/backgroundContent/hover layer/icon，並使用 shear 和 OutElastic 展開動畫；可用來理解分層方式，但不要直接把其數值當作 Stable 原圖的真實尺寸。

## 4. Song Select：必須照圖重建

參考：`osu-song-selection.jpg`。

### 畫面分區
- 全畫面作品背景。
- 左側排名／成績欄，含玩家頭像、名次標記、名稱、分數與精度資訊。
- 右側歌曲／難度佇列，使用緊密的橫向列與有層次的選取狀態；禁止改成每首歌一張白色卡片。
- 頂部 Group、Sort、Collections、Recently Played、By Artist、By Difficulty 等控制列。
- 搜尋框與篩選結果數量位於右上工作區。
- 選取作品／難度需呈現封面、標題、作者／來源、難度和星級。
- 底部固定操作列保留 Mode、Mods、Random、Beatmap Options 的位置與層級。
- 個人資訊與成績列要像客戶端 HUD 一樣緊密，不要擴成 profile 卡片。

### 背景規則
- 背景來源必須是當前選取作品的正式 artwork provider 結果。
- 對背景使用獨立的 dim/blur overlay，不能直接把原圖永久改暗。
- 選取變更時背景同步更新，失敗時保留清楚可辨識的 fallback；不得依標題猜外部 URL。
- 背景不能阻擋列表、搜尋、選取、鍵盤操作或音訊操作。

### 列表與狀態
- default、hover、selected、focused、disabled 必須可區分。
- 使用者鍵盤上下鍵移動選取，Enter 的行為沿用現有正式契約，不得暗中播放音訊。
- 搜尋、分組、排序、分頁及多選只保留單一現有 Catalog controller/query owner。
- 選取的作品詳情與 Dock 狀態必須與同一個 selected record 同步。
- 每首歌都必須有真實作品封面或有意義且可替換的 artwork 表現；不允許最終使用純文字卡或通用色塊。

## 5. Multiplayer Lobby：必須照圖重建

參考：`osu-multiplayer-lobby.jpg`。

### 結構
- 頂部標題與目前播放／狀態區。
- 緊湊的模式分類列。
- 房間篩選、搜尋與狀態切換。
- 高密度房間清單，每列包含模式／房名／地圖或題目資訊／進度／玩家槽位。
- 玩家使用真實頭像或明確的空槽位；空槽位不可偽裝成玩家。
- 房間狀態以可辨識顏色與文字表示，顏色必須來自真實狀態。
- 底部固定操作區：返回、建立房間、快速加入等實際支援的操作。
- 聊天獨立放在底部或側邊區域，與房間清單分開。

### 資料規則
- 先追蹤 `#multiplayer-panel`、`#multiplayer-status`、`#multiplayer-source`、`#multiplayer-message`、`#multiplayer-error` 與 server/polling owner。
- 不可建立第二套 room state，不可用靜態假房間冒充 live server。
- 若 API 缺少參考圖需要的欄位，列出缺口，先完成可由真實資料支援的切片。
- 加入／離開房間、搜尋、排序、空狀態、錯誤和載入狀態均須保留既有操作。

## 6. Mod Select：必須照圖重建，但不照搬 osu! 規則

參考：`osu-game-modifiers.jpg`。

- 以 modal／overlay 方式覆蓋目前遊戲設定或猜歌頁，背景使用獨立暗化層。
- 上方顯示 AMQ 真正計算出的 multiplier／條件摘要；若尚未有 multiplier owner，不得顯示假倍率。
- 中間依類別呈現固定網格的圖示按鈕；每個按鈕包含圖示、名稱、啟用狀態與必要說明。
- 底部集中放 Reset All 與 Close。
- 保留鍵盤導覽、焦點管理、Escape 關閉、ARIA dialog semantics 及互斥規則。
- 只呈現已定義的 AMQ Mods。候選 Reverse、Beat Shuffle、Fade Out、Vocal Only、Background Only 必須先確認實際實作、倍率、互斥與 audio owner。
- 不得移植 osu! Easy、No-Fail、Hard Rock、Hidden 等規則或倍率。
- 若 AMQ 目前沒有穩定的 Mod state owner，先記錄架構缺口，不能只做沒有行為的假按鈕。

## 7. Intro / Transition 視覺

參考：`osu-intro-screen.jpg`。

- 把背景、品牌標誌、放射粒子、狀態資訊分層。
- 不要求新增無功能啟動畫面；將分層與動畫原則用於實際 loading／transition 或品牌區域。
- 粒子、動態光線與 Logo 必須分開映射，支持 reduced-motion。
- 不可將 Logo 與背景合併成一張不可替換圖片，除非該原圖本身就是使用者明確選擇的整體背景資產。

## 8. OSK / Skin System 強制契約

### Registry
每個可換皮元件使用穩定 `componentId`，不可直接以易變 CSS class 作為唯一 ID。至少記錄：
- `componentId`, `pageId`, `regionId`
- `assetType`, `supportedStates`
- `logicalSize`, `sourceScale`, `fitMode`, `anchor`
- `defaultAsset`, `skinAssetMapping`
- `pageOverride`, `componentOverride`
- `mappingConfidence`, `mappingSource`, `needsManualMapping`
- `fallbackAsset`, `previewMetadata`

### Resolver
使用唯一 resolver。專案規格為 Default → Selected Skin → Page/Region Override → Component Override；如程式現況或產品決策與此不同，先記錄並統一規則，不可由 CSS specificity 偶然決定。
- missing asset 必須 fail-safe 並記錄 warning。
- reset 必須清除 token、active markers、object URLs 與暫存引用。
- 不得因套用 skin 而更改業務狀態。

### OSK Parser / Asset Mapper
- 解壓縮要防路徑穿越、重複路徑、資源耗盡與壓縮炸彈。
- 檢查檔案大小、總解壓大小、MIME、圖片解碼、設定 schema 與未知欄位。
- 使用已知命名、配置與明確規則進行映射；不得隨機分配。
- 不確定的項目放進人工映射佇列，顯示原檔名、尺寸、格式、候選元件、信心度與預覽。
- 提供匯入預覽、套用、重設、匯出與失敗報告。
- 覆蓋率必須分開列出 mapped / partially mapped / unmapped / unsupported；禁止用「圖片成功載入」推導「100% 相容」。

### 測試
- Registry completeness、resolver priority、fallback、reset、object URL revoke。
- OSK zip slip、超大檔、重複路徑、損壞圖片、錯誤 skin.ini、未知版本。
- 每個主要頁面和元件狀態的 screenshot matrix。
- Skin apply 前後的 Catalog selection、Quiz answer/audio、Results、Multiplayer state 不得改變。
- 四尺寸：1920×1080、1440×900、1024×768、390×844。
- 截圖必須與參考圖並排，附差異表；fixture 與 live data 分開。

## 9. 視覺驗收的硬門檻

每個頁面都必須有：
1. 參考圖裁切區域或整圖。
2. 正式 AMQ 實際畫面同尺寸截圖。
3. 構圖／位置／比例／顏色／密度／文字／背景／互動狀態差異表。
4. 逐元件 Skin ID 與資產映射。
5. 測試證據與限制。
6. P0 差距清單。

自動化 layout tests 通過，只能說幾何／DOM 契約通過。不能等同視覺相似度通過。未經人工並排比較不得將 UI 標記完成。

## 10. 工作交付

一次完成一組完整頁面／模組，不只分析、不只寫文件、不只補測試。交付時更新：
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/UI_TRACEABILITY.md`
- `docs/DESIGN_GAP_REGISTER.md`
- `docs/HANDOFF_BATCH###.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `README_FIRST.md`
- `MANIFEST.sha256`
- ZIP 與 `.sha256`

永遠保留使用者提供的五張官方 Stable 參考圖與最新一輪對照截圖；舊的比較截圖可以移除，但不能刪除程式碼、必要測試、核心資產或未確認用途的檔案。
