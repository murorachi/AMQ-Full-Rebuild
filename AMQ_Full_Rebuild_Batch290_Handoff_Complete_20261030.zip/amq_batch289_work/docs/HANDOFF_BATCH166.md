# Batch166 交接：Catalog 封面／標題／來源資訊密度與可讀性

## 開工確認
- 已閱讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH165.md` 與 `docs/NEXT_SESSION_PROMPT.md`。
- 工作副本 `/mnt/data/amq_batch153_work` 沒有 `.git` metadata；`git status --short --branch` 回報 `fatal: not a git repository`。沒有初始化 Git。
- Candidate302、Candidate382 Stage 0 與 AMQ／EMQ 原始曲庫資產均維持唯讀，未覆蓋或升格其他候選版本。
- 可見 `/usr/bin/chromium` 與 Python Playwright，但 Node Playwright／Puppeteer／jsdom 未安裝；既有紀錄已證實相同環境的 file／localhost 導覽被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。本批沒有重試已知無效的導覽路徑，也未宣稱完成真實 viewport 驗收。

## 實作
- `src/ui/catalog-browser.js`：有 artwork 的歌曲標題欄位加上明確 `catalog-title-cell catalog-title-cell--artwork` layout class，限定作用範圍，不改查詢、排序、選取、播放或 artwork provider 邏輯。
- `src/styles.css`：把封面固定在 42px 欄，標題與 attribution 連結放在可縮放的文字欄；長歌曲／作品資訊可換行，來源連結限制在儲存格寬度並保留可見鍵盤焦點。避免來源文字與封面／長標題互相擠壓。
- `tests/catalog-filter-layout.contract.test.cjs`：新增 contract test，驗證專用 cell class、封面／文字 grid、長標題換行、來源連結換行與 focus-visible。
- 沒有變更 Catalog selection／Free Player playback 責任邊界；沒有新增第二個播放狀態 owner。

## 驗證
- 受影響回歸：`node --test tests/catalog-filter-layout.contract.test.cjs tests/catalog-browser.integration.test.cjs tests/catalog-browser.test.cjs tests/app-artwork-lifecycle.integration.test.cjs tests/app-lifecycle.integration.test.cjs`，10/10 top-level tests PASS，0 failures。
- 架構檢查：`node tools/check-architecture.cjs`，1,051 PASS／0 FAIL，exit 0。
- OSK 匯入面板：`python tests/osk-import-panel.browser.test.py`，12/12 assertions PASS。
- 語法檢查：`src`、`tests`、`tools`、`server` 共 160 個 JS／CJS 檔案，0 failures。
- `tests/` 內 71 個 `*.test.cjs` 分 9 組執行；165/165 tests PASS、0 failures；9 組 exit code 全部 0。每組命令檔案清單、log、exit code、總結位於 `artifacts/batch166-regression/`。
- 變更檔案 SHA-256 位於 `artifacts/batch166-regression/changed-files.sha256`。

## 未解決／阻塞
- 真實 Chromium 1440／1024／820／390 viewport、水平捲動、焦點順序與 Skin selection frame 尚未實機驗收。
- ANN API／CORS／實際圖片載入仍未線上驗收；真實 `.osk` 與非 opaque HTTP origin IndexedDB save/reload/clear 仍阻塞。
- 工作副本無 Git metadata；沒有初始化 Git。

## 下一步 Batch167
1. 繼續做可由程式碼與整合測試驗證的 Catalog／Skin 行為檢查，不重試已知被阻擋的瀏覽器導覽。
2. 檢查 app mount 時所有 panel／adapter 的「取得後立即註冊 cleanup」模式，找出有證據且能用回歸測試重現的生命週期缺口；不為了追求一致而盲目改寫。
3. 檢查 artwork attribution 的來源 URL、鍵盤互動與過期 async response 保護；只修實際可證明的缺陷。
4. 每批繼續更新工作狀態、主清單、handoff 與 next prompt。
