# Batch 24 交接：熟悉度持久化

## 已完成
- `src/persistence/familiarity-store.js` 依參考 HTML 第 403、405、870–872 行封裝 AMQ 熟悉度 key `aniCollection_v2`，fallback `anisongFieldGuide_v1`，並保留 `ani-familiarity-updated-v51` 事件。
- EMQ 使用 source-aware key `amqLearningFamiliarityV1`，避免與 AMQ 的相同數字 ID 覆寫。舊版共用 map 中來源不明的 EMQ 狀態不自動遷移。
- QuizSession 依引擎計分結果保存 familiarity level；揭曉與未播放跳過不更新。寫入失敗回報 `persisted:false`。
- 測試：familiarity store 6/6、session 8/8、AudioService 11/11、architecture 339/0。

## 限制
- 答題歷史與摘要未寫入：`aniQuizHistory_v1`、`aniQuizHistorySummaryV1`、`aniQuizTargetSummaryV1` 有獨立 dedupe／summary／recovery 規則。不得只 append detail 並忽略摘要。
- SRS／FSRS 尚未接入。真實瀏覽器音訊與 UI E2E 未驗收。

## 下一步
1. 建立 source-aware quiz history store，完整測試 detail cap、summary totals、target totals、dedupe window、legacy import 與損壞 summary quarantine。
2. 讀取舊版 history 只作唯讀遷移來源；不直接覆蓋既有摘要。
3. 接入 UI 歷史摘要，之後再處理 SRS／FSRS。
