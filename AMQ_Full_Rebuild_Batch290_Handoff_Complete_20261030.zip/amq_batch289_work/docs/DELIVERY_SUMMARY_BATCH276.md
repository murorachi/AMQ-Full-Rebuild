# Batch276 交付摘要（2026-10-30）

- 基於 Batch275 工作副本延續；Batch274／Batch275 原始 ZIP 不覆寫，未初始化 Git。
- Catalog artwork loading state 已修正：只有實際 image `load` 成功才標記 available、隱藏 fallback 與顯示來源連結；error 清除 stale attribution link 並恢復 fallback。
- AniList feature/client 已接入 artwork provider composition；ANN 仍優先，AniList 僅在有明確 crosswalk 時 fallback。Crosswalk provider 由 artwork provider bundle 建立、與 Catalog 共用、由 bundle 統一 dispose；app.js 不直接依賴 AMQData。AniList adapter optional。
- 驗證：Node 98 files 分 20 組，306/306 subtests PASS；focused Node 52/52；Architecture 1,335/0；JS/CJS syntax 192/192；Python AST 36/36；Home/Catalog browser 85/85；Home artwork fixture 14/14；Multiplayer Skin roles apply/fallback/reset/scope 5/5。
- 最新證據：`artifacts/batch276-regression/`、`artifacts/batch276-home-menu/`、`artifacts/batch276-home-artwork/`；視覺差距表 `artifacts/batch276-home-menu/visual-gap-table.md`。
- 尚未結案：live ANN/VNDB/AniList network 與正式 artwork、IndexedDB real-origin persistence、人工 osu! Stable visual gate、外部 AMQ/EMQ 可聽音訊、Windows／實機驗收。HTTP/HTTPS localhost navigation 被 `ERR_BLOCKED_BY_ADMINISTRATOR` 擋在 document load 前，不繞過政策。
- 最終 package SHA-256 放在 ZIP 同名外部 sidecar；`MANIFEST.sha256` 逐項驗證，ZIP CRC 與 manifest hash verification 已在交付前執行。
- 下一批 Batch277 見 `docs/NEXT_SESSION_PROMPT.md`。
