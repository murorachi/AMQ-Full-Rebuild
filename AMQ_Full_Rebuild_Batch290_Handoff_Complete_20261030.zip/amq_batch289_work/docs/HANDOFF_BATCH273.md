# Batch273 Handoff：Skin component IDs 與 Multiplayer role apply/fallback/reset

## 本批完成
- 已對照 `artifacts/osu-reference/osu-main-menu.jpg` 與正式 `src/ui/app-shell.js`／`src/styles/ui-design-landing.css`，將 Home 六個主入口改為 Stable 風格斜切按鈕、紫色漸層、右側圖示與可見 focus；尊重 reduced-motion，未改導航行為。新增 `tests/batch273-home-menu.browser.py` 與 `artifacts/batch273-home-menu/` 四尺寸最新 JPEG／差距表。
- 從 Batch272 工作副本開始，確認輸入 ZIP SHA-256 `49ccf77682eb56855fbdc411c990cd9971b470e2415aa9e85766ba6b921e7def`、674 entries、CRC PASS；工作副本無 Git，不初始化 Git，未覆寫來源包。
- UI 工作前開啟 `artifacts/osu-reference/osu-main-menu.jpg`、`osu-multiplayer-lobby.jpg`，並閱讀 Stable fidelity prompt、Batch271 lazer source research 與現有正式 DOM/CSS。視覺 gate 仍未通過。
- `src/skins/theme-adapter.js` 的 `multiplayer.lobby.tab`、`multiplayer.lobby.room-list`、`multiplayer.lobby.create-room` 改用 `data-skin-component` selector。
- `src/index.html` 的 `#multiplayer-players` 新增 `data-skin-component="multiplayer.member-list"`；`src/ui/multiplayer-panel.js` 產生 player row／ready-state 時標註 component ID。既有 room snapshot／session owner 不變。
- 新增 `tests/batch273-multiplayer-skin-component.contract.test.cjs` 與 `tests/batch273-multiplayer-skin-visible.browser.py`。5 個角色 apply 5/5、missing asset fallback 5/5、reset 5/5、scope 5/5、0 page errors；player row 使用明確測試 fixture，非 live data。
- 使用者提供 `AMQ-Scripts-master(1).zip`，97 entries、CRC PASS、SHA-256 `76fc073a51da180d087ba4c6636b22531053ed5b1affeb5a8330e7de7c4aad04`，保留原包於 `references/AMQ-Scripts-master.zip`。`docs/AMQ_COMMUNITY_SCRIPT_AUDIT_BATCH273.md` 記錄六個相關腳本的實際觀察與移植限制。

## 測試證據
- `python tests/batch273-home-menu.browser.py`：四尺寸 Home/Catalog 81/81 PASS（1920×1080、1440×900、1024×768、390×844）；包括斜切按鈕／圖示位置、六入口、空歷史、無水平溢位、桌面無整頁垂直溢位。Catalog 為 layout fixture／opaque-origin error 分離證據，不代表正式曲庫。
- `node --test tests/batch273-multiplayer-skin-component.contract.test.cjs tests/batch272-multiplayer-lobby-visual.contract.test.cjs tests/skin-theme-adapter.test.cjs tests/skin-resolver.test.cjs tests/ui-shell-css.contract.test.cjs`：38/38 PASS。
- `python tests/batch273-multiplayer-skin-visible.browser.py`：5 roles apply/fallback/reset 全 PASS，0 page errors。此測試用 `validateImage` test seam 檢查 mapping lifecycle，不驗證 OSK 實際圖像解碼。
- `python tests/batch272-multiplayer-lobby.browser.py`：四尺寸 geometry 32/32 PASS（1920×1080、1440×900、1024×768、390×844），0 page errors，無水平溢位。
- `node --check src/skins/theme-adapter.js`、`node --check src/ui/multiplayer-panel.js`：PASS。

## 未驗收／阻塞
- Home/Catalog 正式曲庫、真實 artwork、live providers、HTTP-origin IndexedDB、live audio/multiplayer E2E、全量 `node --test tests/*.test.cjs` 已嘗試執行，但在工具時間窗口中途逾時，未取得 aggregate；Windows／實機與人工 osu! Stable 視覺 gate未驗收。
- Multiplayer Stable 圖中的玩家頭像槽位、歌曲縮圖、聊天區、完整底部操作列仍無足夠正式 server/API owner，不用假資料補齊。
- AMQ Mods canonical owner 尚不存在；不虛構倍率。

## 下一批 Batch274
1. 優先追蹤 Home playback history → 正式 work index → ANN/VNDB artwork provider 的可驗證流程；不重複探測已知被政策阻擋的 loopback。
2. 對 Home/Catalog 做下一輪正式 DOM／CSS 與 osu! 參考並排差距檢查，沒有真實 artwork 時保留誠實 fallback。
3. 擴大 Skin role route-visible matrix，確認可見角色的 apply/fallback/reset 與 scope；不能只驗證初始 Home route。
4. 將社群腳本的鍵盤／autocomplete 觀察轉成新版行為測試，不複製舊 prototype patch。
5. 更新同一份工作清單、狀態、traceability、gap register、handoff、next prompt、manifest、ZIP 與 SHA-256。

## 交付封裝
- 交付包：`AMQ_Full_Rebuild_Batch273_Skin_Component_Mapping_20261030.zip`。
- `MANIFEST.sha256` 包含 659 個檔案；封裝完整性與逐檔 manifest 校驗結果由交付報告記錄。
- ZIP SHA-256 由同名 `.zip.sha256` sidecar 提供，避免在壓縮檔內記錄自身雜湊造成循環依賴。
- 使用者提供的社群腳本原始 ZIP 保留於 `references/AMQ-Scripts-master.zip`，未執行／未注入正式網站。
