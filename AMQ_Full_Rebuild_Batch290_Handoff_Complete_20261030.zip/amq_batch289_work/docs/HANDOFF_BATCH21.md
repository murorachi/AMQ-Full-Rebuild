# Batch 21 交接：答案比對與猜歌回合核心

## 已完成
- `src/engine/answer-evaluator.js`：以使用者提供參考 HTML 的靜態證據實作答案正規化、精確匹配、可選部分匹配、aliases、AMQ 同曲名／歌手跨作品接受規則及三目標分別評估。
- `src/engine/quiz-engine.js`：無 DOM 狀態機，包含 idle、ready、playing、paused、answered、timed-out、revealed、finished；有播放門檻、暫停時間排除、超時、跳過、揭曉、熟悉度建議、有限題數與 reset。
- 已載入主頁與測試頁，架構檢查要求 engine 不依賴 DOM／UI。
- 測試：答案比對 6/6，回合引擎 10/10。

## 不要誤報
- 這只是核心邏輯，猜歌 UI、AudioService、歷史／SRS 持久化尚未接線。
- `markAudioStarted()` 必須由真實播放 `playing` 事件呼叫；engine 不建立 timer、不操作 media element。
- 目前來源 mapper 沒有舊版完整中文 aliases，沒有資料就不補造。
- MIX 規則、真實瀏覽器 E2E、Candidate302／Stage 0 相容性與音訊可播放性仍未驗收。

## 下一步
1. 建立單一 AudioService 及測試，完成播放開始、取消、錯誤及 fallback 契約。
2. 以 engine snapshot 接上猜歌 UI，不在 UI 建立第二份 phase／題目狀態。
3. 再接熟悉度／答題歷史持久化，並執行 Node 回歸；瀏覽器環境恢復後再做真實 E2E。
