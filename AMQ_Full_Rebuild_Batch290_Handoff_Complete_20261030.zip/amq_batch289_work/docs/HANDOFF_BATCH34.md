# Batch 34 交接：Repository 契約與取消邊界防護

## 本批結論
Repository 現在會對 Adapter Promise 與 abort signal 競速，並在 Adapter 結果進入資料驗證與 Catalog 建立前，先驗證來源 envelope。此防護針對注入式／未來來源 Adapter，避免 Composite Adapter 以外的 Adapter 回傳不合契約資料時仍流入共享狀態。

## 修改檔案
- `src/data/repository.js`：取消／新請求 supersede 時不等待忽略 signal 的 Adapter；新增 `validateSourceResult()`；驗證 `records`、`sourceCount`、可選的 `sourceCounts` 與每筆 `source` 標籤分布。不合契約使用 `DATA_ADAPTER_RESULT_INVALID` 走既有失敗狀態路徑。
- `tests/core.test.cjs`：新增 malformed result 拒絕、合法 per-source count 接受、不合作 Adapter 取消與 supersede 測試。
- `docs/MASTER_CHECKLIST.md`：新增 AMQ-417～425（AMQ-422 為瀏覽器阻塞紀錄）。
- `docs/WORK_STATUS.md`：更新目前批次、測試證據、阻塞與下一步。
- `docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`、`README_FIRST.md`、`AI_START_HERE.md`：更新 Repository 邊界契約。

## 契約
- `records` 必須是陣列。
- `sourceCount` 必須是非負安全整數，且等於映射後 records 數量。現行 Adapter 是一筆 raw record 對應一筆 mapped record，不允許靜默過濾。
- 若有 `sourceCounts`，必須為非空物件，所有來源名稱非空、計數為非負安全整數、加總等於 `sourceCount`；每筆 record.source 必須屬於已宣告來源，且實際分組筆數與宣告計數一致。
- 不合約結果回報 `DATA_ADAPTER_RESULT_INVALID`，不發布 Catalog。

## 驗證狀態
- `node tests/core.test.cjs`：71/71 PASS。
- `tests/*.test.cjs`：21/21 scripts exit 0；`node --test tests/tooling.test.cjs`：8/8；`node tools/check-architecture.cjs`：415 passed／0 failed。
- Source audit PASS；mapper verifier PASS：AMQ 38,821、EMQ 16,839、Catalog 55,660；5 次 catalog benchmark PASS（Catalog 建置約 789.017 ms，標題搜尋 P50 約 10.033 ms，僅為 Node 觀測值）。
- 所有 `src/`、`tests/`、`tools/` JS／CJS 語法檢查 PASS。完整日誌位於 `/mnt/data/amq_batch34_logs/`。
- 真實瀏覽器 E2E 仍受環境 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋，未宣稱通過。
- `AMQ382(1).html`、`src/data/assets/data.js`、`src/data/assets/emq-data.js` 均只讀；本地工作目錄不是 Git repository，沒有初始化或推送。

## 下一批
進一步檢查來源失敗、validator failure 與 Catalog failure 的 state／snapshot 原子一致性；不重複建立第二套載入狀態或錯誤系統。
