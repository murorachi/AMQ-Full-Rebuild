# Batch 30 交接：EMQ SRS 來源感知儲存與 UI

## 已實作
- `src/persistence/srs-store.js` 現在可依 `source: AMQ | EMQ` 建立獨立 store instance。
- AMQ 保留 legacy key `aniSrsScheduleV1` 及既有 schema；不搬移、不覆寫、不雙寫。
- EMQ 使用 `amqLearningEmqSrsScheduleV1`，recovery prefix `amqLearningEmqSrsRecoveryV1_`；schedule root 與每張 card 都必須有 `source: "EMQ"`。
- EMQ source-less、AMQ-tagged 或 card source 不一致的資料會先 quarantine；失敗時封鎖寫入並保留原始資料。
- Quiz panel 在 AMQ／EMQ 模式使用各自 store，支援加卡、暫停／恢復、評級、預覽與到期 queue。EMQ 不套用 source-less AMQ blacklist。
- MIX SRS 暫停使用；MIX 猜歌本身可用。原因是固定 question queue 目前沒有 source+ID identity，不能安全把 AMQ／EMQ queue 混成一組。

## 測試
- `node tests/srs-store.test.cjs`：15/15 PASS。
- `node tests/quiz-panel.test.cjs`：PASS，涵蓋 EMQ 模式與 source-aware SRS 評級。
- 交付前需依 `docs/WORK_STATUS.md` 第三十批區段記錄完整回歸結果。

## 未驗收
- 真實瀏覽器 localStorage、跨頁 storage event、UI 視覺與音訊播放仍未驗收。
- MIX 的 legacy AMQ-specific filter suppression 尚未實作。
- 沒有自動遷移 AMQ SRS 到 EMQ；兩來源歌曲身份不等價。

## 下一步
1. 讀取 `docs/WORK_STATUS.md` 最後一節與 `docs/MASTER_CHECKLIST.md` 尾端。
2. 執行完整回歸與 Chromium smoke；環境阻塞只嘗試一次，記錄後繼續。
3. 評估並實作 MIX legacy AMQ-specific filter suppression，不新增無關架構層。
