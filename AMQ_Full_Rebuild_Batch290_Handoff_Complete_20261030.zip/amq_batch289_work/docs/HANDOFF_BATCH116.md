# AMQ 新版重建交接：Batch116

日期：2026-10-28  
前一批：Batch115（多人房間 HTTP transport）  
Git：工作副本沒有 `.git` metadata；未初始化 Git、未 commit、未 push。

## 本批目標

改善 Remote SRS 在一般網路中斷時的恢復方式，同時保留既有 revision conflict fail-closed，不把 pending schedule 放進共用 localStorage，也不假裝完成 durable offline queue。

## 實作成果

1. `src/persistence/remote-srs-bridge.js` 新增 `retryPending(source?)`。只處理 transport error；既有 `conflict` 不會自動重試。
2. PUT 失敗後，最新序列化排程仍留在目前登入工作階段的 bridge memory。按重試時先 GET server schedule，只有 `server revision === last confirmed revision` 才重送最新完整排程。
3. 如果 server revision 已改變，bridge 產生 `SRS_REVISION_CONFLICT`，不執行第二次 PUT，並繼續封鎖寫入。這避免重試把其他分頁／裝置的更新覆蓋掉。
4. `src/index.html` 與 `src/ui/account-panel.js` 新增「重試未同步的 SRS 保存」按鈕。只有存在 network-error source 時顯示；成功後隱藏。Conflict 仍需使用者明確確認後重新載入伺服器排程。
5. 新增 bridge regressions：網路恢復且 revision 未變時可重試成功；revision 漂移時不寫入並維持 fail-closed。
6. 新增 account-panel regression，驗證 UI 顯示 retry action、重試成功後恢復 synced。

## Targeted validation

- `node tests/remote-srs-bridge.test.cjs`：5/5 PASS。
- `node tests/account-panel.integration.test.cjs`：PASS，包含 safe retry UI。
- 驗證日誌放在交付包外 `/mnt/data/amq_batch116_validation_logs/`。
- `node tests/quiz-panel.test.cjs`：PASS。
- `node tests/server-auth-srs.integration.test.cjs`：6/6 PASS。
- 全量回歸：54/54 `tests/*.test.cjs` scripts 逐檔 exit 0；`node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：836 passed／0 failed；JavaScript/CJS syntax 128/128 PASS。
- Source audit／mapper／5-run catalog benchmark：PASS；Catalog 55,660 records，AMQ 38,821 songs／9,516 works，EMQ 16,839 songs／6,645 works。
- 唯讀曲庫 SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- Node v22.16 的 `node:sqlite` 仍會顯示 ExperimentalWarning。

## 重要限制

- Pending schedule 只在目前登入工作階段記憶體中保留；重新載入／關閉頁面前若尚未成功保存，變更仍可能遺失。
- 本批**不是** durable offline queue，不是多裝置 merge，也沒有可靠 unload flush。
- 不會把 pending schedule 寫入 `localStorage`，避免不同登入者共用或誤上傳舊排程。
- Revision conflict 不自動合併；使用者需確認後重新載入 server schedule。真實 browser／multi-device E2E 仍待最終集中驗收。

## 變更檔案

- `src/persistence/remote-srs-bridge.js`
- `src/ui/account-panel.js`
- `src/index.html`
- `tests/remote-srs-bridge.test.cjs`
- `tests/account-panel.integration.test.cjs`
- `docs/PRIVATE_SERVER.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `README_FIRST.md`

## 下一批建議順序

1. 優先調查多人 UI／AudioService／QuizSession 接線，重用現有 AudioService 與 Clock，不建立第二套音訊／計時 owner；避免單人猜歌與多人房間同時爭用音訊。
2. 再評估 durable offline queue、multi-device merge 與 unload flush。若要跨 reload 保存 pending schedule，必須有 per-user/source namespace、revision conflict contract 與 logout/reload 安全，不能使用共享 localStorage 或靜默覆蓋 server。
3. AniList／MAL OAuth credential lifecycle、token refresh 與 provider list mapping 可以繼續，但不得把 client secret 放進前端，也不得未經確認覆寫 personal library/watch status。
4. 真實瀏覽器、音訊與 multi-client 驗收依使用者要求最後集中進行。
