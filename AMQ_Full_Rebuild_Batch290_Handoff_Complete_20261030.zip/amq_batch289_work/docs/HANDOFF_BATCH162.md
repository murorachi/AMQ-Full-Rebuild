# Batch162 交接：正式 Catalog 常用／進階篩選分層

## 開工確認
- 已閱讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH161.md` 與 `docs/NEXT_SESSION_PROMPT.md`。
- 工作目錄 `/mnt/data/amq_batch153_work` 無 `.git` metadata；`git status` 回報不是 Git repository，未初始化 Git。
- Candidate302、Candidate382 Stage 0 與原始 AMQ／EMQ 資料資產未修改。

## 實作
- 參照 `prototype/ui-v2-osu-select-batch146/` 的 osu!stable Song Select 分層方向，正式 Catalog 不再把全部篩選控件平鋪在同一個大 grid。
- `src/index.html` 將搜尋、來源、歌曲類型、看番狀態、排序依據／方向放在常用控制列。
- 新增原生 `<details id="catalog-advanced-filters">`，將作品類型、作品細分類、年代、年份起迄、未知年份及熟悉度收納為進階篩選。原生 disclosure 可由鍵盤操作，不需要新增 JS 狀態或第二個狀態來源。
- 所有既有 input/select IDs 保持不變，`src/ui/catalog-browser.js` 的 controller／query-index binding 未改，避免破壞篩選行為。
- `src/styles.css` 新增常用／進階 controls layout、summary focus-visible 與 1000px／600px responsive rules。
- 新增 `tests/catalog-filter-layout.contract.test.cjs`，驗證欄位分組、進階 disclosure、焦點與響應式 CSS contract。
- 更新 `AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md` 與 `docs/NEXT_SESSION_PROMPT.md`。

## 驗證證據
- `node --check src/ui/catalog-browser.js`：PASS。
- `node --test tests/catalog-filter-layout.contract.test.cjs tests/catalog-browser.integration.test.cjs tests/catalog-browser.test.cjs tests/app-lifecycle.integration.test.cjs tests/ann-artwork-adapter.test.cjs tests/artwork-provider-factory.test.cjs tests/artwork-adapter.test.cjs`：25/25 PASS。
- `node tools/check-architecture.cjs`：1044 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- 真實 Chromium viewport 截圖／互動驗收未完成。既有環境有頁面導覽政策阻擋紀錄；本批未把 Node／CSS contract 當作真實視覺驗收。

## 未解決與下一步
1. Batch163 補足可自動化的 keyboard focus、details open/close、窄螢幕布局契約，並繼續正式選曲列表／選取資訊面板分層。
2. 真實 ANN API／CORS／圖片載入、真實 `.osk` 與 HTTP-origin IndexedDB save/reload/clear 仍待合適環境。
3. 正式 Song Select UI 仍屬逐批替換，不能標示整體完成。
