# Batch287 Handoff: VNDB Quiz Character Strip

## Product behavior
- Settings category: `猜歌角色` (`#vndb-character-settings-panel`).
- Enter VNDB character IDs such as `c123`, click `加入角色` or press Enter. Maximum 8 unique IDs. IDs persist in localStorage key `amqVndbQuizCharactersV1`.
- Quiz bottom strip: `#quiz-character-bar` / `#quiz-character-items`, only shown for characters with successfully loaded images. Each item shows the VNDB character image and name. No fake placeholders.
- API adapter: `AMQIntegrations.vndbAdapter.createAdapter(client).getCharacter(id, options)` requests `https://api.vndb.org/kana/character` with fields `id,name,original,aliases,image.url,vns.title`.
- Skin roles: `quiz.character.bar`, `quiz.character.item`; manifests and runtime selectors are synchronized.

- VNDB API contract reference: https://api.vndb.org/kana (POST `/character`, `image.*` fields and `or` filters). Live external requests remain unverified.

## Verification evidence
- `node tests/external-service-feature-adapters.test.cjs`: PASS (includes character API contract).
- `node tests/skin-contract-manifest.test.cjs`: 12/12 PASS.
- `node tests/skin-theme-adapter.test.cjs`: 24/24 PASS.
- `python tests/batch287-vndb-character-settings.browser.py`: 35/35 PASS across 1920x1080 and 390x844; API/image are explicit isolated fixtures.
- `python tests/batch286-quiz-gameplay-layout.browser.py`: 55/55 PASS across 4 viewport sizes.

## Not verified
- Live VNDB HTTP/API/image availability.
- Real OSK skin visual apply/fallback/reset screenshots for the two new roles.
- Windows/device manual acceptance and human visual gate against the supplied AMQ screenshot.
- Full Node suite aggregate exit code.

## Next
1. Verify live VNDB character lookup without using fixture data as evidence.
2. Visually compare Quiz bottom strip to the supplied AMQ gameplay reference and refine height/spacing while preserving the existing game layout.
3. Continue Quiz correct/incorrect/skip/reveal/next state integration and its history UI.
4. Keep osu! Stable fidelity as a P0 across other pages.
