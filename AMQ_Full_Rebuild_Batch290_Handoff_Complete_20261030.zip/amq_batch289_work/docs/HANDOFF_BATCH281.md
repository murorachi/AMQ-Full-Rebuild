# Batch281 Handoff：AMQ 音符＋問號品牌圖示與 Skin role

## 使用者方向
首頁不需要 AMQ 三個大字；改用音符＋問號組合試做。視覺靈感可借用 osu! 遊戲客戶端的清晰圖標語言，但不可照抄 osu! 標誌或配色。Home 不恢復 header／側欄／底部 recent panel。

## 本批實作
- 新增原創透明 PNG `src/assets/amq-note-question.png`，裁切透明邊界後 494×512、約 163 KB。珊瑚紅／暖白／石墨黑，不使用 osu! logo。
- `src/ui/app-shell.js`：Home 初始 brand mark、空 history fallback、功能頁返回首頁按鈕使用同一圖示；移除動態 fallback 仍插入「AMQ」文字的缺口。
- `src/styles/ui-design-landing.css`：圓盤底色由高飽和粉色改成石墨色，保留細緻環線；圖示以 contain 顯示，不裁切透明邊界。
- `src/skins/theme-adapter.js`：新增 `app.home.logo` runtime role，selector `.home-brand-mark, .app-brand-icon`，token `--amq-skin-role-app-home-logo`。可透過現有 role mapping 替換並 reset。
- 新增/更新 `tests/skin-theme-adapter.test.cjs`、`tests/batch280-home-chrome.contract.test.cjs`，瀏覽器 fixture 將本地圖示轉為 data URL，讓四尺寸截圖實際顯示圖示。
- 更新 30 項工作索引、WORK_STATUS、MASTER_CHECKLIST、UI_TRACEABILITY、DESIGN_GAP_REGISTER、AI_START_HERE、README_FIRST。

## 驗證證據
- `python tests/batch273-home-menu.browser.py`：102/102 PASS，1920×1080、1440×900、1024×768、390×844。Catalog 為 layout fixture，不是正式資料驗收。
- `node --test tests/skin-theme-adapter.test.cjs tests/batch280-home-chrome.contract.test.cjs tests/ui-shell-css.contract.test.cjs tests/app-shell-navigation.contract.test.cjs`：39/39 PASS。
- `node --check src/ui/app-shell.js`、`node --check src/skins/theme-adapter.js`、Python AST compile：PASS。
- 最新 Home 截圖 `artifacts/batch281-home-catalog/home-1920x1080.jpg`；並排差距圖 `artifacts/batch281-home-catalog/home-vs-osu-stable.jpg`。

## 未完成／限制
- Home 和 osu! Stable 的人工視覺 gate仍未通過；目前只完成品牌 fallback，不是正式作品 artwork 或完整 Stable 主選單背景。
- Catalog layout 使用 fixture；真實曲庫、live artwork、Dock 對真實列表遮擋、Windows／實機尚未驗收。全量 Node suite本批未跑。
- 工作副本無 `.git`，未初始化；Batch280 ZIP 未覆寫。

## 下一批 Batch282
1. 從 `docs/BATCH279_UI_TASK_SELECTION.md` 接續未完成工作。
2. 優先檢查 Catalog Dock、pagination、可視列表底部的實際幾何關係；在四尺寸加入 dock/list overlap assertions，能安全修正的直接修正。
3. 再處理 Home/Catalog 視覺差距與正式 Skin roles，不重做本批 logo role／四尺寸 matrix。
4. 更新同一份清單、工作狀態、traceability、gap register、handoff、next prompt、manifest 與 ZIP。
