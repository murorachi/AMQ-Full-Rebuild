# Batch283：Catalog 與 osu! Stable Song Select 逐項對照

日期：2026-10-30

## 參考與證據

- Stable 參考：`artifacts/osu-reference/osu-song-selection.jpg`（使用者提供的官方 osu! Wiki 介面圖；不是 lazer 截圖）。
- AMQ 畫面：`artifacts/batch283-catalog-stable/catalog-data-fixture-1920x1080.jpg`。
- 並排圖：`artifacts/batch283-catalog-stable/catalog-vs-osu-stable-1920x1080.jpg`。
- 展開播放器：`artifacts/batch283-catalog-stable/catalog-dock-expanded-1920x1080.jpg`。
- 四尺寸瀏覽器檢查：`tests/batch283-catalog-stable.browser.py`，148/148 PASS。

**證據界線：** AMQ 畫面中的六筆歌曲、封面 SVG 與選取作品圖片是測試 fixture，只證明布局及互動幾何；不是正式曲庫、ANN/VNDB live artwork 或外部資料成功。未收到成功的 artwork provider 圖片時，背景保持空狀態，不猜 URL、不把 OSK 角色圖冒充作品封面。

## 本批依照參考圖做的結構改動

1. 將 AMQ／EMQ／MIX 三個來源切換按鈕移到頂部緊湊列，沿用既有模式狀態 owner；把狀態資訊折疊收納，不再用高大的模式儀表板擠佔選歌區。
2. 桌面視覺順序改為左側篩選、中央選取作品舞台、右側緊密歌曲佇列，對應 Stable 圖中「左側資訊／中間作品背景／右側歌曲佇列」的視覺重心；沒有虛構不存在的全球排名或成績。
3. 歌曲列採更緊密的遊戲客戶端列式視覺、清楚的選取／hover／鍵盤焦點層次，保留表格語義、來源、歌手、作品及類型資料欄位。
4. 新增由真實 artwork provider 成功載入後才啟用的選取作品背景層。背景與前景封面分離；切換選取時清除舊背景，過期請求、失敗請求與 dispose 不得回寫舊圖。
5. 讓播放器初始收合狀態保持約 52px；展開時改為有界的控制台布局，將搜尋、播放狀態、進度、控制鍵、音量／模式及佇列分區。依 ResizeObserver 發布的實際 Dock 高度重新計算列表，分頁不可被遮住。
6. 新增 `catalog.selected-artwork-background`、`catalog.selected-work-stage`、`catalog.selected-work-details` 穩定 Skin component IDs；既有 `catalog.mode-selector` role 轉接到新的頂部來源列。

## 逐項視覺差距

| 區域 | Stable 參考 | Batch283 AMQ | 狀態 |
|---|---|---|---|
| 全畫面作品背景 | 大幅、真實作品圖，主導畫面 | 已有獨立背景 layer，但 fixture 無 live provider 圖片時維持空背景 | 結構完成；live artwork 未驗收 |
| 左側資訊區 | 真實 Global Ranking、頭像、分數／精度 | 使用真實可用的 AMQ 搜尋／篩選，不偽造排名 | AMQ 語義映射；非像素複製 |
| 頂部控制 | Group、Sort、Collections、Recently Played、Artist、Difficulty | AMQ／EMQ／MIX 頂部 tabs；查詢／排序在左側控制區 | 部分對應；Collections 類功能需另行評估與現有預設功能整合 |
| 右側歌曲佇列 | 層疊色帶、封面、標題、難度與星級 | 緊密表格式列，封面／歌手／作品／類型／來源 | 構圖已向右側佇列靠攏；仍需以真實 artwork 與難度資料改善列內容 |
| 中央選取作品 | 背景與選取列同步，背景藝術可見 | 有選取作品舞台與 provider 驅動背景；無 provider 時誠實 fallback | 互動結構完成；真實圖像驗收未完成 |
| 底部操作列 | Mode、Mods、Random、Beatmap Options | 保留 AMQ 自由播放 Dock，並非照搬 osu! Mods | AMQ 功能差異；需後續設計精簡控制條，不可虛構 Mod |
| 播放 Dock | 原圖為緊密的固定操作條 | 收合預設精簡，展開後提供完整播放控制 | 四尺寸幾何測試通過；人工操作驗收未完成 |
| 行動裝置 | Stable 參考為桌面介面 | 篩選／作品舞台／歌曲佇列依閱讀順序堆疊 | 自動幾何通過；真機尚未驗收 |

## 本批驗收

- Chromium 四尺寸：1920×1080、1440×900、1024×768、390×844；148/148 PASS。
- 桌面列表、分頁與 Dock：測試收合及展開兩種狀態；分頁保持在 Dock 上方。
- Focused Node：39/39 PASS，涵蓋新 layout contract、Catalog integration、query/layout、Skin adapter 與 Free Player Dock。
- Architecture Checker：1,358 PASS／0 FAIL。
- JavaScript/CJS syntax：205/205 PASS；Python AST：37/37 PASS。

## 尚未關閉的差距

- 並排圖證明布局方向已調整，但仍明顯不同於 Stable：AMQ 左側是篩選而非排名、右側佇列不是 Stable 彩色疊層、中央缺少已驗證的真實作品背景。
- 不得將此 fixture 截圖標記為 live artwork／真實曲庫驗收，也不得標記 Stable 視覺 gate PASS。
- 下一批優先把同樣的「先看原圖、再記差距、最後實作」流程套用到 Multiplayer Lobby 與 Quiz；使用 `osu-multiplayer-lobby.jpg`、`osu-intro-screen.jpg` 和 AMQ 實際功能，不造假玩家、房間或 Mods。
