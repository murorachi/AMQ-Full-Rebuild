# Batch 65 交接：EMQ 音源轉換與猜歌答案建議恢復

日期：2026-10-27

## 交付結論

本批已完成兩項具體缺口：
1. EMQ 候選 URL 轉換依 Candidate381 舊版靜態程式碼補齊。
2. 新版猜歌答案建議下拉選單與鍵盤操作恢復，並補上候選失敗詳情。

這些是程式碼與 Node／fake DOM 測試證據，不代表真實瀏覽器或實際音訊可聽性已驗收。

## 舊版線索與音訊資料統計

參考檔 `AMQ382(2).html`：
- SHA-256：`65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`
- 檔案內 title／標記指向 Candidate381，因此只作靜態行為線索，不是 Candidate302 或 Candidate382 Stage 0 的正式基準。
- V82.54／V82.55 的 `getAudioUrls` 對 Catbox URL 先加入 `https://files.catbox.moe/{filename}`；對 `erogemusicquiz.com/selfhoststorage/userup/` 優先將 host 改成 `asiadist.erogemusicquiz.com`；符合 `/weba/{id}.weba` 的候選另嘗試 `/userup/{id}.webm`，並保留原始候選。
- 新版現在採用以下候選順序：Asia WebA → 原始 WebA → Asia WebM → 原始 WebM。Catbox mirror → 原始 URL。只對已觀察到的格式做 rewrite。
- 唯讀解壓 `src/data/assets/emq-data.js` 統計：16,839 songs、16,877 個非空音訊 URL；13,648 個 userup URL、7,909 個 `.weba` URL、3,208 個 Catbox URL、21 個其他格式 URL。URL 數量不等於歌曲數，單曲可能有多個候選。

## 猜歌答案建議行為

新增 `src/ui/answer-suggestions.js`，接入 `src/index.html`、`src/ui/quiz-panel.js` 與 `src/styles.css`：
- 從目前 Catalog／AMQ、EMQ 或 MIX 模式建立對應目標候選值（作品／歌曲／歌手）。
- NFKC、大小寫、空白、連字號與斜線等價搜尋；去重、穩定排序並最多顯示 25 項。
- ArrowDown／ArrowUp 移動 active option。
- Enter 選取目前建議；若未移動則選第一項。選取不會直接提交答案，使用者需再次 Enter 或點提交。
- Escape 關閉建議。
- IME composition 中不執行鍵盤選取，compositionend 後刷新。
- 支援滑鼠點選、無結果隱藏、ARIA combobox/listbox 與 dispose 清理。
- 此為依舊版線索恢復核心互動；舊版所有中文 alias provider、特殊符號 highlight 等完整細節尚未宣稱一比一相容。

## 音訊失敗診斷

`QuizSession.getState()` 現在公開唯讀的 `audioErrorInfo` 與 `audioFailures` 快照。QuizPanel 在 `AUDIO_ALL_CANDIDATES_FAILED` 時呈現歌曲 source／ID、各候選 source 與 reason（timeout、media-error、play-rejected、play-threw、media-create-failed），方便使用者回報失敗曲目。會依 `HTMLMediaElement.error.code`（1–4）區分媒體中止、網路錯誤（可能包含網路／跨域限制）、解碼錯誤與不支援格式；若瀏覽器沒有提供 MediaError code，才回退至一般媒體錯誤。這仍不能單靠程式碼證實具體 CORS 根因。

## 修改檔案

- `src/data/audio-candidates.js`
- `src/engine/quiz-session.js`
- `src/index.html`
- `src/styles.css`
- `src/ui/answer-suggestions.js`（新增）
- `src/ui/quiz-panel.js`
- `tests/answer-suggestions.test.cjs`（新增）
- `tests/audio-candidates.test.cjs`
- `tests/quiz-panel.test.cjs`
- `tests/tests.html`
- `docs/DATA_CONTRACT.md`
- `docs/FUNCTION_INVENTORY.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `README_FIRST.md`
- `docs/HANDOFF_BATCH65.md`

## 測試證據

- 全部 `tests/*.test.cjs`：27/27 scripts exit 0。
- `node tests/answer-suggestions.test.cjs`：8/8 PASS。
- `node tests/audio-candidates.test.cjs`：7/7 PASS。
- `node tests/quiz-panel.test.cjs`：PASS，包含建議 UI 接線與音訊失敗詳細資訊投影。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：480 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；重複 ID、懸空歌曲作品參照與跨來源 ID 碰撞皆為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，AMQ 38,821、EMQ 16,839、Catalog 55,660。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，僅為 Node in-memory benchmark。
- `node --check` 對 `src/`、`tests/`、`tools/` 全部 JS/CJS：PASS。
- 日誌目錄：`/mnt/data/amq_batch65_logs/`。
- `src/data/assets/data.js` SHA-256 維持 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`。
- `src/data/assets/emq-data.js` SHA-256 維持 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 本工作副本無 `.git`；沒有初始化 Git、commit 或 push。

## 未驗證與阻塞

- 真實瀏覽器 E2E 仍 BLOCKED。沒有新瀏覽器環境，本批不重試已知 `ERR_BLOCKED_BY_ADMINISTRATOR`／Chromium 啟動失敗方法。
- 真實 EMQ 音訊是否能播放仍需使用者本機驗收。新候選轉換只依舊版靜態證據，不等於所有音源已修復。
- Dropdown 的 Node／fake DOM 測試通過；實際視覺、焦點、中文輸入法與瀏覽器事件順序待使用者驗收。
- 收藏 UI 尚未提供；`aniFavorites_v1` identity 與 source-less legacy IDs 仍未知，不猜測或自動遷移。
- Candidate302／Candidate382 Stage 0 相容性未驗收；不搜尋 Candidate302。

## 下一步 Batch 66

1. 使用者本機驗收答案建議：輸入文字、ArrowDown／ArrowUp、Enter 選取不提交、再次 Enter 提交、Escape、中文 IME。
2. 優先測 EMQ `userup/weba/*.weba` 與 Catbox 曲目；若仍失敗，回報歌曲標題／ID與 UI 列出的候選來源／失敗原因。
3. 依新證據做針對性修正；不要重做已通過的全量核心稽核，不提前進行 UI／CSS 大重構。
4. 收藏 UI 與資料 identity 分開處理；不得猜測舊 key。
