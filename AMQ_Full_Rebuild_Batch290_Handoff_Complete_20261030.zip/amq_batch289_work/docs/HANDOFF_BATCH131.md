# AMQ 新版重建交接：Batch131（出題池跨模組 eligibility 矩陣）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 唯讀。

## 修改
- `tests/quiz-panel.test.cjs`：新增獨立參考 predicate，直接以 fixture 與設定計算 expected eligible records，不重用 production eligibility closure。
- 覆蓋 year range、includeUnknownYear、animeType、difficulty bounds、songType、source-aware watchStatus、source-aware custom list、SRS enabled，與 AMQ／EMQ／MIX 三模式交叉，共 768 組。
- 驗證 AMQ blacklist 不會套用到 EMQ、相同 work ID 跨來源隔離、EMQ 缺失 metadata 不會猜值，以及 SRS toggle 不改變 pool eligibility。
- 沒有修改 production code，因 matrix 未發現可重現 defect。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`、`README_FIRST.md`。

## 驗證
- `node tests/quiz-panel.test.cjs`：768/768 matrix cases PASS。
- `node tests/quiz-pool.test.cjs`：10/10 PASS。
- `node tests/quiz-session.test.cjs`：23/23 PASS。
- `node tests/personal-library-store.test.cjs`：10/10 PASS。
- `node tests/srs-store.test.cjs`：19/19 PASS。
- 全量 57 個非-tooling test scripts 逐檔 exit 0，分組執行；tooling 13/13、architecture 893/0、source audit／full mapper／5-run benchmark PASS。
- AMQ asset SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ asset SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，與既有紀錄一致。

## 封包驗證
- 最終 Manifest／ZIP 在交付前重新生成並核對；manifest hash、ZIP CRC 與檔案集合均通過，未包含 `.pem`／`.key` 私鑰檔。

## 未解決
- 真實瀏覽器 filter／跨分頁／音訊 E2E 未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試。
- Candidate302 舊版規則相容未證明。

## 下一步
Batch132：檢查 Remote SRS bridge 與 AccountPanel 在帳號切換、持久化 pending、登出／dispose、in-flight request 及 stale callback 的生命週期邊界；若有可重現缺陷就補 regression 並修復，若無則記錄證據後繼續其他 persistence 缺口。
