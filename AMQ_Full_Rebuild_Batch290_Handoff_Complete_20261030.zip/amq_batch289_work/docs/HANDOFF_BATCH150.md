# Batch150 交接：OSK Skin Theme 持久化

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。沒有 Git metadata，未初始化 Git。

## 本批完成
- 新增 `src/persistence/skin-theme-store.js`，IndexedDB database `amq-learning-skin-themes`、schema v1，保存素材 Blob 與主題設定。
- 主題 schema 包含 metadata、background、selectionFrame、characterOverlay、accentColors、motionPreference、enabled、updatedAt。
- 限制最多 5,000 項、單檔 24 MiB、素材總量 120 MiB；拒絕未知 schema、無效 mapping、重複路徑、超限素材。保存成功只在 IndexedDB transaction complete 後回報。
- 更新 `src/ui/skin-import-panel.js`：匯入後保存，套用時保存 mapping，初始化時嘗試還原，清除時刪除持久化記錄及目前預覽。
- 更新 `src/index.html`、`tests/tests.html`、`tools/check-architecture.cjs`；新增 `tests/skin-theme-store.test.cjs`。

## 測試證據
- `node --test tests/skin-theme-store.test.cjs`：4/4 PASS。
- 核心組合：`node --test tests/core.test.cjs tests/app-lifecycle.integration.test.cjs tests/skin-theme-store.test.cjs tests/osk-importer.test.cjs tests/app-settings-store.test.cjs`：0 FAIL；core 81/81、app settings 7/7、importer 6/6、theme store 4/4，lifecycle integration PASS。
- 跨模組組合：`node --test tests/tooling.test.cjs tests/data-pipeline.integration.test.cjs tests/source-runtime.integration.test.cjs tests/audio-session.integration.test.cjs tests/quiz-session.test.cjs tests/quiz-panel.test.cjs`：18/18 top-level groups PASS；data pipeline 20/20、QuizSession 23/23。
- `python tests/osk-import-panel.browser.test.py`：9/9 assertions PASS，但此測試使用 `page.set_content()` opaque origin，Chromium 拒絕 IndexedDB；不能視為瀏覽器持久化通過。
- `node tools/check-architecture.cjs`：961 PASS／0 FAIL。
- 另完成三組鄰接回歸：persistence/backup/SRS 6/6 files PASS；audio/catalog/query/filter 6/6 files PASS；multiplayer protocol/state/command/session/client/panel 6/6 files PASS。細項見 `docs/WORK_STATUS.md`。

## 阻塞
1. 真實瀏覽器 IndexedDB save/reload/clear：需在非 opaque origin 測試。現有環境對本機 HTTP／file 導覽有管理政策阻擋；尚未取得真實瀏覽器持久化證據。
2. 真實 `.osk`：curl 嘗試 KaKKeY release 下載，DNS 回報 `Could not resolve host: github.com`，無實際檔案可測。
3. `tests/` 下 64/64 個 `*.test.cjs` 檔案已分組執行，所有批次均 0 FAIL。未執行單一 `node --test tests/*.test.cjs` 全包命令；不要把這兩件事混為一談。

## 下一批最高優先
1. 讀 `AGENTS.md`、`AI_START_HERE.md`、`WORK_STATUS.md`、`MASTER_CHECKLIST.md` 與本交接。
2. 64/64 個 Node test files 已在分組中通過；不要重跑已驗證測試，除非程式碼變更影響它們。
3. 若有可用的非 opaque browser origin，驗證 IndexedDB 實際 save/reload/clear；若被政策阻擋，記錄一次證據後跳過，不重複徒勞嘗試。
4. 再嘗試取得真實 `.osk`；若 DNS 仍不可用，記錄阻塞，繼續 Theme Adapter 與 fallback 測試。
5. 將 theme mapping 接入正式 osu-style Song Select 的背景／卡片框架／角色裝飾；預設主題不得受影響。

Candidate302、Candidate382 Stage 0、AMQ／EMQ source assets 未修改。不要將模擬 IndexedDB 測試描述成真實瀏覽器驗收。
