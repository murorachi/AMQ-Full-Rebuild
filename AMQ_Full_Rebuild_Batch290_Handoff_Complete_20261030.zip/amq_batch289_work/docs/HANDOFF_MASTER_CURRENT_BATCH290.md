# 下一個 AI 接手總文件（2026-10-30，Batch290 package）

> **先讀這份，再讀 `AGENTS.md`、`PROJECT_RULES.md`、`AI_START_HERE.md`、`README_FIRST.md`。** 本文件把目前已知進度、使用者要求、證據界線、阻塞及下一批工作集中在一起。若與舊批次摘要衝突，以日期較新、且有實際檔案／測試證據的 Batch290 記錄為準。不要把歷史計畫當成現在已完成。

## 0. 一分鐘接手摘要

- 目前工作包：`AMQ_Full_Rebuild_Batch290_Quiz_Mods_Owner_20261030.zip`，內部根目錄仍名為 `amq_batch289_work/`。這是沿用的資料夾名稱，不代表它是 Batch289。
- 本包是新版 AMQ 獨立重建專案。解壓工作副本沒有 `.git`，沒有可用的 branch/commit/diff；不要假裝有 Git 歷史。先檢查 ZIP、Manifest 和程式實況。
- 最新實作：Batch289 Quiz 結果視覺狀態；Batch290 建立 `src/engine/quiz-mods.js` 的 Mods registry/selection store。
- Mods **還不是完整可玩功能**：未接 AudioService、未做 Mods overlay、未套用正式分數、Vocal/Background 音源分離不可用。不可把狀態 store 說成音訊 Mod 已完成。
- 近期主線仍是使用者指定的 **Skin System First + osu! Stable 視覺保真**。功能修補不能成為忽略 UI 的藉口；Mods 是一個需要真實行為與視覺一起完成的 UI slice。
- Batch290 測試：focused Mods 5/5；相關 focused suite 11/11；Quiz 四尺寸 browser 55/55；Architecture Checker 1,394 PASS/0 FAIL；Python AST 40/40。全量 Node suite在 120 秒限制內逾時，沒有 aggregate exit code，狀態是 **NOT VERIFIED**。人工視覺、live audio/provider、HTTP-origin IndexedDB、Windows/手機實機都未驗收。
- 下一個建議批次：Batch291。先研究 AudioService 的生命週期與來源限制，優先做一個確實可運作且有測試的 Mod（評估 Fade Out），再接 overlay/Settings、Skin IDs、鍵盤與 ARIA；找到 canonical score owner 後才接倍率。

## 1. 使用者需求與不可違反的工作方式

### 專案交付規則
1. 先讀工作狀態、主清單、交接、下一輪提示、架構與測試，再改程式；先確認正式 owner 和依賴。
2. 一次完成有清楚邊界的功能批次，包含實作、測試、文件、Manifest、乾淨解壓驗證及 ZIP，不要只分析或交付零碎 patch。
3. 單一責任／單一狀態來源；不重複實作、不互相覆蓋，不做無止境重構。清除舊碼前先查用途和依賴。
4. 保留已驗收功能與視覺；重構要真正替換舊實作，不能只隱藏舊 UI。
5. 不得覆蓋原始工作包；交付新版本並保留來源包。
6. 嚴格區分已實作、已測試、已驗收、未驗證。沒有證據不得宣稱 PASS。
7. 卡住就記錄阻塞、影響與解除條件，先做不受阻的項目；不要因單一問題無限重試或反覆問使用者批准。
8. 每批更新同一份 `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/UI_TRACEABILITY.md`、`docs/DESIGN_GAP_REGISTER.md`、handoff、next prompt、`AI_START_HERE.md`／`README_FIRST.md` 與 Manifest。
9. 交付前檢查新增 UI 字串，禁止將 TODO、開發備註、AI 自我解說、測試 fixture 標籤放進玩家介面。

### UI／Skin 方向
- 目標不是「套一層 osu 顏色」，而是 AMQ 專用功能採用 osu! Stable 的資訊層級、遊戲客戶端結構、密度、狀態回饋與素材呈現方式；不要整頁卡片化、白底化或看起來像 AI 產生的通用管理面板。
- 主要參考圖在 `artifacts/osu-reference/`：`osu-intro-screen.jpg`、`osu-main-menu.jpg`、`osu-song-selection.jpg`、`osu-multiplayer-lobby.jpg`、`osu-game-modifiers.jpg`。每個 UI slice 開工前要實際查看對應原圖與現有正式 DOM/CSS/state owner，交付時寫差距而非只聲稱「像 osu」。
- Skin 系統需要 OSK 匯入、Skin Registry、OSK Parser（zip/settings/assets/errors/safety）、Asset Mapper（有語意的映射，不可隨機指派圖片）、Resolver 優先序（defaults → selected skin → region/page override → component override）、Layout Configuration、持久化、匯入／匯出、live preview、mapping report 和 coverage report。不得宣稱 100% coverage，除非有逐項證據。
- 可視區域覆蓋目標包括 Home、Song Select、game settings、Quiz、player、answer input、results、profile、leaderboard、learning center、settings、navigation、dialogs、dropdowns、toasts、loading/empty、keyboard states。
- 主要桌面驗收尺寸至少 1920×1080，另測 1440×900、1024×768、手機 390×844；使用者偏好頁面避免整頁垂直捲動，不能以破壞手機可用性換取桌面無捲動。
- Home 是以大主視覺／圓盤概念為中心、周圍有入口；Quiz 要像 AMQ 遊戲本身；Song Select 以封面／作品視覺為重心；Settings 收納設定（房間／Lobby 專屬設定除外）。封面優先真實 ANN 資料（DB 有 ANNID），未來整合 AniList/MAL/VNDB；沒有真實圖片時不要用隨機圖冒充封面。
- 遊戲 UI 禁止解說性 meta copy。角色圖只顯示成功載入的真實 VNDB 人物，沒有設定／圖片時隱藏，不放假角色佔位。
- 使用者已修正：Candidate302／Candidate382 Stage 0 不再是新版重建必需基準或阻塞；不要花時間尋找它們，也不要聲稱本包已包含它們。

### 已決定的功能範圍／偏好
- 不列入待辦：探索新歌／未探索歌曲、歌手圖鑑、答案別名提示。
- 仍在候選清單：具名曲庫篩選預設、Quiz 進階篩選完整性、批次選取套用、Free-play player Dock、queue/play modes/history wiring、backup/restore UI、song tags CRUD/filter、作品級學習進度、玩家視覺化、AniList/MAL/VNDB 匯入、多玩家 Quiz、快捷鍵管理與衝突檢查、有限選項工作區自訂。
- 競技 Mods 是後續功能，不可搶先宣稱完成。使用者排除 Short Reveal、Speed Up、Slow Motion。候選 Mod：Reverse ×1.12、Fade Out ×1.06、Beat Shuffle ×1.12、Vocal Only、Background Only；Vocal Only／Background Only 互斥。倍率只有在正式 score owner 存在且接線驗證後才能對外顯示為真實分數倍率。1v1 Lazer-like 後續再做，不是現在的阻塞。
- 學習方向可保留：個人熟悉度、遺忘預測／間隔複習、個人化弱點補強。

## 2. 目前已完成（有工作包內文件／測試證據）

### Batch290
- 新增 `src/engine/quiz-mods.js`：單一 Mods registry、倍率計算、選取正規化、互斥來源設定、本機持久化、subscribe、reset、dispose。
- Registry 包含 Reverse、Fade Out、Beat Shuffle、Vocal Only、Background Only；不含已排除的三個 Mods。
- `src/index.html`、`tests/tests.html` 和 Architecture Checker 的載入順序契約已更新。
- 新增 `tests/quiz-mods.test.cjs`。
- `docs/HANDOFF_BATCH290.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md` 已記錄此批邊界與測試。

### Batch289 及更早仍保留的成果
- Quiz 三欄遊戲區比例與寬度收斂；結果 phase/result/timer 的 DOM 視覺投影；答對、答錯、跳過、未播放跳過、逾時、揭曉、倒數的狀態樣式；答案揭曉 aria-label。
- VNDB 角色欄：設定位於 Settings、最多 8 個 ID、去重、保存／移除／批次查詢、成功載入才顯示，空欄不放假圖。
- Answer suggestions 多詞任意順序、拉丁重音折疊、鍵盤與 dismissal 行為的既有測試。
- Home、Catalog、Quiz、Lobby 等路由與 UI 已有多批調整及相應測試；請先看既有文件，不要無差別重做已通過的 geometry。
- 以上歷史批次不代表整體 UI 已達到 osu! Stable 視覺驗收；人工 gate 仍未結案。

## 3. Batch290 測試證據與不能推論的事

| 項目 | 證據／狀態 | 限制 |
|---|---|---|
| `node --test tests/quiz-mods.test.cjs` | 5/5 PASS | 只測 registry/store 契約 |
| focused Mods + Quiz panel + Batch289 result-state | 11/11 PASS | 不等於 live audio/session E2E |
| `python tests/batch286-quiz-gameplay-layout.browser.py` | 55/55 PASS | 四尺寸 geometry/fixture，不證明真實音訊／外部 provider |
| Architecture Checker | 1,394 PASS / 0 FAIL | 靜態契約，不是產品端到端驗收 |
| Python AST | 40/40 PASS | 語法層驗證 |
| `node --test tests/*.test.cjs` | **NOT VERIFIED** | 120 秒工具限制逾時，沒有 aggregate exit code；不可標 PASS |
| clean-extract 關鍵測試 | Batch290 handoff 當時待做 | 必須重新執行並記錄實際結果 |
| osu! Stable 人工視覺 gate | 未驗收 | 必須看實際截圖與參考圖並記錄差距 |
| Live audio／ANN artwork／VNDB HTTP | 未驗收 | fixtures 不代表真實服務可用 |
| HTTP-origin IndexedDB | 未驗收 | opaque/file origin 測試不能代替 HTTP-origin |
| Windows／手機實機 | 未驗收 | Chromium fixture 不等於實機 |

## 4. 明確未完成事項與阻塞

### P0：下一批直接處理
1. **AudioService 真實 Mod 效果**：先讀 `src/audio/audio-service.js`、現有 AudioService tests、媒體建立／候選 fallback／play-pause-resume-stop／dispose。選一個可在實際音源限制下可靠實作的效果（提示優先評估 Fade Out）；不能假設所有來源都可 fetch/decode，不能留下跨題效果狀態。加入失敗回退與 teardown 測試。
2. **Mods overlay／Settings 接線**：先確認正式 route／settings／skin owner，建立真正 overlay，不加裝飾按鈕。只讓已實作的 Mod 可選；加入鍵盤焦點、Escape、Reset、Close、ARIA dialog、焦點還原與 component IDs。對照 `osu-game-modifiers.jpg`。
3. **正式 score owner**：全包搜尋目前 score calculation/owner；若有，先寫清楚資料流再接 multiplier；若不存在，記錄產品阻塞，不要新造第二套分數 owner，也不要顯示假倍率。
4. **Quiz session transition matrix**：以真實 `quiz-session.js`／panel owner 測試 correct、wrong、skip、reveal、timeout、next、pause/resume/end 及 stale audio completion，不要只測 CSS attributes。
5. **UI/視覺驗收**：產生實際 screenshot、與 osu 原圖並排及 gap list；掃描玩家介面文案，移除開發式註釋。
6. **可靠測試／打包**：全量 Node tests 分組跑並保存 exit codes；Architecture Checker、JS/CJS syntax、Python AST、相關 browser matrix；更新 Manifest，clean-extract 後重跑關鍵測試並核對 SHA-256。

### 其他仍未結案的 P0／重要差距
- osu! Stable 人工視覺 gate；整體仍有背景素材深度、遊戲 overlay 分層、角色／玩家 avatar、真實 artwork 等差距。Quiz 背景依使用者要求暫不處理。
- Live audio、live artwork/ANN、VNDB 真實 HTTP 請求、真實 multiplayer/server 的 E2E。
- HTTP-origin IndexedDB 持久化／多分頁行為。
- Windows 與手機實機操作、鍵盤／viewport 驗收。
- 作品封面與外部 provider 的真實資料品質、錯誤與 CORS 行為。
- Skin System OSK 真實匯入、asset mapping 的真實 coverage 及逐區 fallback/override/reset 的視覺證據仍須依當前清單逐項核對，不可僅因有舊 prototype 就算完成。

## 5. 交接包中缺少／無法從此包取得的資料

這裡的「缺少」是指目前交接 ZIP／環境未提供或不能作為證據，不代表它們一定不存在於使用者自己的電腦：
- **Git metadata**：工作副本沒有 `.git/`，因此缺少 branch、commit、diff、remote 狀態與可追溯歷史。不要自行初始化後把它說成原 repo。
- **Candidate302／Candidate382 Stage 0 原始基準**：本包沒有包含；依使用者最新決策，這不是目前重建的阻塞，不必追回。
- **真實服務憑證／外部執行環境**：包內沒有可證明 live ANN／VNDB、live AMQ multiplayer server、實際音訊來源可用性的憑證或環境。不得把 fixture 當真實服務證據，也不要在文件寫入秘密。
- **HTTP-origin／Windows／手機人工驗收證據**：包內沒有可證明這些項目已驗收的結果；需要可用執行環境後補驗。
- **使用者電腦上可能存在的其他最新工作包、原始參考圖或尚未上傳的檔案**：本次只可確認本 ZIP 內容與既有上下文，不能聲稱已掃描使用者整台電腦。
- **全量 Node suite 的總結退出碼**：Batch290 沒有取得；必須重跑分組測試產生新的證據，不能從部分輸出推斷全通過。

本包內存在 `artifacts/osu-reference/` 的五張參考圖、程式碼、測試、文件與 `MANIFEST.sha256`。打包前應確認 Manifest 是依實際檔案重新產生，而不是保留舊雜湊。

## 6. 建議下一個 AI 的操作順序

1. `pwd`、列出工作目錄、檢查 ZIP 解壓根目錄、Manifest、`.git` 是否存在；保留原 ZIP，不覆寫。
2. 閱讀本文件、`AGENTS.md`、`PROJECT_RULES.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md`、`docs/UI_TRACEABILITY.md`、`docs/DESIGN_GAP_REGISTER.md`、`docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`、`docs/HANDOFF_BATCH289.md`、`docs/HANDOFF_BATCH290.md`。
3. 實際查看 `artifacts/osu-reference/osu-game-modifiers.jpg`；檢查 `src/engine/quiz-mods.js`、`src/audio/audio-service.js`、`src/engine/quiz-session.js`、`src/ui/quiz-panel.js`、正式 `src/index.html`、Settings 與 Skin registry/role manifest；先找 owner，不猜測。
4. 用 `rg`／測試查出正式 score owner、audio hooks、settings owner、Skin IDs 與現有 Mod/UI 的任何殘留實作。把發現記入差距文件。
5. 完成 Batch291 一個完整切片：至少一個真實音訊 Mod + 狀態清理 + overlay/Settings + tests + UI screenshot/gap + docs + manifest + clean ZIP。若音訊能力阻塞，先完成不依賴它的 overlay 基礎，但未接通效果必須 disabled/明確不可選。
6. 驗證：focused Node；AudioService/Quiz session 相關測試；Architecture Checker；JS/CJS syntax；Python AST；四尺寸 browser；全量 Node 分組跑並記錄每組 exit code；打包後 clean-extract 再跑核心測試。
7. 更新同一組主文件與 checklist，將無法驗收的事保留未完成，交付 ZIP、SHA-256、精簡結果及下一輪提示。

## 7. 產品 UI／功能總待辦（按目前優先級）

- [P0] osu! Stable fidelity：逐頁實際對照，優先 Mods overlay／Quiz；Home、Song Select、Settings、Results、Profile、Leaderboard、Learning Center、Nav/dialog/dropdown/toast/empty/loading/keyboard states 仍需逐項核實。
- [P0] Skin System First：真實 OSK import、registry/parser/mapper/resolver/layout/persistence/preview/report，逐個 component role 覆蓋並能 fallback/reset。
- [P0] Audio/Quiz 真實效果與 session phase transitions；Mod effects teardown／fallback。
- [P0] 全量測試可追溯 aggregate、clean-extract、live/HTTP-origin／實機 gate。
- [P1] 真實作品 artwork 來源整合與缺圖處理；AniList/MAL/VNDB import integration。
- [P1] 具名曲庫篩選預設、進階篩選完整性、批次操作、song tags、queue/play/history、Free-play Dock、backup/restore UI。
- [P1] 作品級學習進度、玩家視覺化、快捷鍵管理與衝突檢查、有限選項 workspace customization、多玩家 Quiz。
- [Future] 1v1 Lazer-like；PP-like 分數公式；個人化記憶／遺忘預測／間隔複習／弱項補強。不可讓未來功能拖住目前 P0。

## 8. 結案規則

每項只可標記：`IMPLEMENTED`、`TESTED`、`VISUALLY ACCEPTED`、`LIVE VERIFIED`，並附相應證據。CSS fixture pass 不等於人工視覺驗收；mock provider pass 不等於 live API；store test pass 不等於功能已接 UI/audio/score。下一個 AI 不必重新調查所有歷史批次，但必須重新驗證它要改動的正式 owner 和依賴。
