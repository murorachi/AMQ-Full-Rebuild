# Batch174 交接：timeout stale callback 與 History Store consistency

## 工作副本與基準
- 工作副本：`/mnt/data/amq_batch153_work`。無 `.git` metadata，未初始化。Node v22.16.0、Python 3.13.5。
- Candidate302 是正式維護基準，Candidate382 Stage 0 是 CSS 比較基準；原始檔不在副本中，未 hash 比對或覆蓋。AMQ／EMQ 曲庫資產未修改。

## 本批正式修改
1. `src/audio/audio-service.js`：新增 `scheduleCandidateTimeout(request, index)`。初始播放與 resume 共用 timeout helper；timeout callback 執行時重新檢查 request、candidate index、playbackStarted、blocked、userPaused。已排隊的 stale callback 不再在播放成功後切換備援，也不能誤用 request 當前 index 淘汰後續候選。
2. `tests/audio-service.test.cjs`：新增 fake timer 回歸。修正前測試失敗，stale timeout 會建立第二個 backup media；修正後狀態仍 playing，mediaFactory 只建立一個 media。
3. `src/persistence/quiz-history-store.js`：summary 持久化現在要求 authoritative detail history 未處於 write-failed/read-blocked 狀態。detail 未持久化時保留 summary pending 並回報 failure；detail 寫入恢復後 flush 先存 detail 再存 summary。
4. `tests/quiz-history-store.test.cjs`：新增 detail write 失敗、20 筆達 summary batch threshold 的測試。修正前 summary total 先變 20 但 detail key 不存在；修正後 summary bytes 不變、fullyPersisted false，修復 storage 後 flush 寫入 20 筆且 summary total=20。
5. 未修改 QuizSession production code、熟悉度規則、`playAttemptId`／`playbackEpoch` 或曲庫資產。

## 驗證證據
- AudioService：21/21 scenarios PASS，`artifacts/batch174-regression/audio-service.log`。
- Quiz History Store：14/14 PASS，`artifacts/batch174-regression/quiz-history-store.log`。
- QuizSession：25/25 PASS，`artifacts/batch174-regression/quiz-session.log`。
- 71 個 `tests/*.test.cjs` 分 9 組，9/9 exit 0，`group-01.log` 至 `group-09.log`。
- Architecture Checker：1,051 PASS／0 FAIL。OSK harness：12/12 assertions。160 個 JS/CJS 語法檢查 PASS。
- 修正前失敗證據：`audio-timeout-before-fix.log`、`history-partial-write-before-fix.log`。總摘要：`summary.json`。

## 尚未驗收
真實瀏覽器音訊與可聽性、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。Fake timer／storage tests 不代表實機驗收。Candidate302／Candidate382 Stage 0 原始檔缺席，未做 hash 比對。

## Batch175 下一步
1. 檢查播放開始後 `error` 事件與 stale listener／candidate fallback 的事件順序。
2. 以 fake timer 檢查 summary debounce callback 已排程後遇 flush／dispose 的 stale callback 與重複寫入。
3. 只修可重現 P0／P1 缺陷；保留單一播放 owner、`playAttemptId`、`playbackEpoch`、detail-first summary consistency 與四級熟悉度規則。
