# AMQ 新版重建交接：Batch129（備份／還原舊 envelope 相容矩陣）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。原始工作副本 `/mnt/data/amq_batch120_work` 未修改。此目錄沒有 `.git` metadata，未初始化 Git。

## 修改
- `tests/backup-restore.test.cjs`：新增版本化 backup envelope compatibility matrix。涵蓋 wrong format、formatVersion 0／未來版本／小數／字串、缺少 `payload.values`、unsupported payload schema、unknown storage key、non-string raw value、checksum mismatch、malformed JSON、無效已知 key JSON。
- 同時驗證 version-1 JSON string 匯入、explicit `null` 只移除備份列出的 key、omitted key 保持原值。舊 settings schema、AMQ／EMQ SRS provenance、playback history、partial backup 與 rollback failure 仍由既有測試覆蓋。
- `docs/MASTER_CHECKLIST.md`：AMQ-910 依新回歸證據結案，新增 AMQ-1357–1362。
- `docs/WORK_STATUS.md`：補上 Batch128 收尾驗證與 Batch129 變更／證據／阻塞。

## 驗證
- `node tests/backup-restore.test.cjs`：10/10 scenarios PASS。
- 57 個非-tooling `tests/*.test.cjs`：逐檔 exit 0；第一輪工具時限到期時 53 個通過，剩餘 4 個分開重跑皆成功。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：893 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；重複 ID、dangling references、跨來源 ID collisions 均為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839、Catalog 55,660。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；Catalog build 1,131.881 ms（僅 Node 本機觀測值）。
- 唯讀 AMQ／EMQ assets SHA-256 與先前紀錄一致。

## 未解決
- 真實瀏覽器下載／選檔、storage quota、跨分頁與 reload E2E 未驗收；Node 測試不是 browser E2E。
- Candidate302 相容性未證明；不可修改正式基準或唯讀來源。

## 下一步
Batch130：擴充 query-index filter matrix，使未知年份 include/exclude 與其他條件獨立組合，加入搜尋 query 與 source-aware animeId；用獨立參考 predicate 驗證交集、facet、排序與分頁。
