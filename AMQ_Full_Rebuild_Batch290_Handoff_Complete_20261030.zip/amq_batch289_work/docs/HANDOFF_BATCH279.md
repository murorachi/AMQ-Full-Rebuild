# Batch279 Handoff：回到 UI 設計主線，選定 30 項既有待辦

## 本批範圍
- 依既有 `MASTER_CHECKLIST.md`、`DESIGN_GAP_REGISTER.md` 選出 30 項未結案 UI 工作，集中在 Home、Catalog、osu! Stable 視覺比對、Skin targets、recent history 與正式封面驗收；索引見 `docs/BATCH279_UI_TASK_SELECTION.md`。
- 本批沒有將 IndexedDB／外部 provider／音訊阻塞作為主工作，也沒有重複探測被政策封鎖的本機 HTTP origin。

## 實作
- `src/styles/ui-design-landing.css`：Home 桌面網格將主視覺與右側入口作為優先區域，最近學習區改為較低比例；六個入口容器在大型桌面高度上限 690px 並垂直置中，避免視窗高度增加時按鈕被拉得過高。
- 空歷史狀態的 recent area 使用緊湊 padding／最小高度。仍由正式 playback-history state 呈現誠實空狀態，不新增假作品、假封面或另一份資料 owner。
- 修正 CTA 原本與右側最後一個入口垂直重疊的 DOM/CSS 佈局：將「開始」按鈕移入 feature copy 區，置於「選歌」標題下方；保留 `data-go-page="catalog"` 與 Skin component ID。新增四尺寸桌面 CTA／入口不重疊契約。
- `tests/batch273-home-menu.browser.py` 改為將本批最新截圖輸出到 `artifacts/batch279-home-menu/`，並新增桌面空歷史高度契約。
- `docs/BATCH279_UI_TASK_SELECTION.md` 列出 30 項原清單工作與各自狀態。只有本批實際改動與執行的測試列為已完成，人工 gate／live data 仍保持未驗收。

## 驗證證據
- `python tests/batch273-home-menu.browser.py`：90/90 PASS，涵蓋 Home/Catalog 的 1920×1080、1440×900、1024×768、390×844 幾何／DOM／狀態；無水平溢位，桌面無整頁垂直溢位，沒有 browser page errors。
- Focused Node tests：37/37 PASS（Skin theme adapter 21/21、App Shell navigation contract 2/2、UI shell CSS contract 9/9、Catalog row visual contract 5/5）。
- `node tools/check-architecture.cjs`：1,344 PASS／0 FAIL；`python -m py_compile tests/batch273-home-menu.browser.py` 與 `node --check src/ui/app-shell.js` PASS。
- 此 browser harness 省略 heavyweight live data/runtime，Catalog rows/artwork 為明確 layout fixture。它不是正式曲庫、live artwork、HTTP-origin IndexedDB 或人工 osu! Stable 視覺驗收。
- 未執行全量 Node suite、Architecture Checker、外部音訊、CI runner workflow 或 Windows／實機驗收；本批不宣稱這些通過。

## 仍未完成
- 30 項工作清單大多仍是待驗收／待實作；本批只推進 Home 空狀態與主視覺空間的 CSS 收斂。
- Home/Catalog 人工 Stable gate、正式作品封面／曲庫、Skin role 全量核對、播放器 Dock 遮擋、其他頁面視覺 gate仍未結案。
- 不得將 90/90 layout assertions 當成視覺差距已關閉。

## 下一批
1. 按 `docs/BATCH279_UI_TASK_SELECTION.md` 繼續做可由正式 DOM/CSS／現有 state owner 完成的 UI 工作，優先 Catalog Dock／可視列數與 Home recent keyboard/focus。
2. 產生 Batch279 四尺寸 Home/Catalog JPEG，將其與 `artifacts/osu-reference/osu-main-menu.jpg`、`osu-song-selection.jpg` 並排記錄差距；只在具備真實資料時驗收作品封面。
3. 逐一更新 30 項狀態，保留尚需人工或批准 runner 的項目，不將它們標為完成。
