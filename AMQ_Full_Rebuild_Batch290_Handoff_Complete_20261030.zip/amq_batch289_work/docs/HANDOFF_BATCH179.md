# Batch179 交接：曲庫更新 active-read stale snapshot race

## 工作副本／基準
- 工作副本 `/mnt/data/amq_batch153_work`；無 `.git` metadata，未初始化。Node v22.16.0。
- Candidate302 是正式維護基準，Candidate382 Stage 0 是 CSS 比較基準；原始檔不在副本，未覆蓋／未宣稱相容性。AMQ／EMQ 曲庫資產未修改。

## 缺陷與修正
- 原本 `apply()`／`clearActive()` 經 `enqueue()` 序列化，但 `getActiveDataset()` 直接讀取、驗證 active envelope。若 A 的 read/validation 尚未完成，B 可以先 apply／clear；A 的 promise 隨後仍回傳舊 normalized catalog。
- `src/data/database-update.js` 現在將 `getActiveDataset()` 放進同一 operation queue，與 apply／clear 共用序列化邊界。移除已冗餘的 `activeValidationPromise`，保留 checksum-based `validatedActive` cache。
- `tests/database-update.test.cjs` 新增兩個 controlled async regression：active read vs apply、active read vs clear。修正前 apply race 實際失敗；log `artifacts/batch179-regression/database-update-active-read-before-fix.log`。修正後兩者通過。

## 測試證據
- `node tests/database-update.test.cjs`：8 scenarios PASS。
- Database update runtime integration、source integration、panel tests PASS。真實 bundled source preflight：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works。
- 全部 71 個 Node test files 通過；database-update test 在兩個新 regression 加入後另行重跑。逐檔日誌與索引在 `artifacts/batch179-regression/`。
- Backup/restore 11/11；panel 8/8；SRS Store 20/20；Remote SRS Bridge 12/12；History Store 21/21；AudioService 22；QuizSession 25/25。Architecture 1,051/0；OSK 12/12；160 syntax checks PASS。

## 未驗收／阻塞
- Controlled async store 不等於真實跨分頁 IndexedDB E2E。真實瀏覽器音訊、ANN API／CORS／封面、真實 OSK、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。
- Candidate302／Candidate382 Stage 0 原始檔缺席，無法 hash／相容性比對。

## Batch180 下一步
1. 讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、本 handoff 與 `docs/NEXT_SESSION_PROMPT.md`。
2. 稽核 `src/data/source-runtime.js`、`src/data/runtime-bootstrap.js` 與相關 tests，檢查 mode switching、override clear、load cancellation、catalog snapshot publication 的 stale-result race。
3. 先新增可重現 regression，再只修 P0/P1；保留 single Catalog/runtime owner、`playAttemptId`／`playbackEpoch` 與四級熟悉度規則。
4. 跑全量 71 Node tests、architecture、OSK、160 syntax checks，更新同一份主清單並交付 ZIP／SHA-256。
