# Batch189 交接：自由播放 Dock、佇列與播放歷史

日期：2026-10-28
工作副本：`/mnt/data/amq_batch153_work`

## 實作摘要

### AudioService
- 新增 `setVolume(0..1)`、`setMuted(boolean)`、`seek(seconds)`，只由 AudioService 操作媒體。volume/mute 套用至目前 media 與之後 fallback candidates；seek clamp 到有效 duration，失敗回傳 false。
- 接入原生 `ended` 事件。先發布 ended state 讓訂閱者讀取最終 metrics，再終止 request 並釋放 media；request identity guard 保留。

### Free Player Dock
- 新增進度條／seek、音量、靜音、收合；底部 sticky dock 有最大高度及內部捲動。
- 新增 source-aware queue、加入所選歌曲、播放佇列項目、移除項目、清空佇列、上一首／下一首。
- 播放模式為 sequential／loop／shuffle。自然 ended 會依模式自動推進；順序模式末項結束後停止自動推進，循環模式回到首項，隨機模式在多項佇列中避免立即重播目前項。
- 移除目前播放項會停止並清除 current record；移除其他項修正 index；清空佇列停止播放並清空 queue history。
- 直接播放的歌曲若未入列會自動加入佇列；同一 source-aware typed identity 不重複入列。
- 播放歷史保留至少 5 秒實際 playing 門檻；同一 AudioService sequence 不重複記錄。歷史 ID 使用 Dock lifetime ID + sequence + entry counter，避免 remount 後 sequence 重置造成 duplicate ID。
- Dock 使用獨立 AudioService instance，不與 QuizSession 共用播放狀態 owner。

## 測試

- `tests/free-player-dock.test.cjs`：PASS，覆蓋 queue dedupe、loop／shuffle／sequential、previous／next、自然 ended 自動推進、volume／mute／seek／collapse、移除／清空與 remount history ID。
- `tests/audio-service.test.cjs`：全套 PASS，含 volume／mute／seek、active media 更新、ended state 與既有 fallback/stale callback regression。
- Batch188 狀態仍保留：Song Tags Store 8/8、Catalog integration PASS、backup/restore 11/11。
- 全量 74 個 `tests/*.test.cjs`：74/74 exit 0；逐檔 log／status 在 `artifacts/batch189-regression/node-tests/`、`status/`、`node-tests.tsv`／`node-tests.json`。`quiz-pool.test.cjs` 單獨重跑 10/10 PASS。
- Architecture Checker：1,095 PASS／0 FAIL，`artifacts/batch189-regression/architecture.log`。
- OSK harness：12/12；170 個 JS/CJS `node --check` PASS。
- AMQ／EMQ 資產 hash 未變：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 尚未驗收

- 真實 HTMLAudioElement 音量／seek／ended、背景播放、sticky dock viewport、瀏覽器鍵盤互動尚未驗收。
- Candidate302／Candidate382 Stage 0 原始檔缺席；無 `.git`，未初始化。

## 下一批 Batch190

1. 完成備份／還原 UI 的選檔、預檢、確認、錯誤、提交與回滾全流程，納入 `amqSongTagsV1`。
2. 整合作品層級學習進度與現有資料層／統計 UI，不混用歌曲熟悉度與作品進度。
3. 全量回歸、更新清單／handoff 並交付 ZIP／SHA-256。
