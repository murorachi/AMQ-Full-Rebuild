# AMQ Batch 63 交接：核心工程範圍結案評估

日期：2026-10-27

## 本批工作

本批依使用者的「先完成必要核心，不要無限重構」規則，檢查唯一主清單尾端、`PRODUCT_CORE_CONTRACT.md`、`FUNCTION_INVENTORY.md`、Batch 56–62 handoff 與最新測試證據。沒有發現另一項有充分證據、可在不猜測舊版規則／資料身份且不依賴真實瀏覽器的 P0/P1 核心程式缺陷。

這不是產品最終驗收，而是將「可在現有環境中可靠實作／驗證的核心工程範圍」暫時結案，避免為了增加批次而反覆翻修穩定模組。

## 文件修正

- `docs/FUNCTION_INVENTORY.md`：更新 FUNC-001 至 FUNC-010 的現況，區分新版內部 Node／integration evidence 與舊版相容／瀏覽器／真實音訊驗收。修正早期對鍵盤選取、清單 CRUD、SRS UI 等已過時描述。
- `docs/FINAL_GAP_ASSESSMENT_BATCH49.md`：新增 Batch 63 最新證據，修正「清單／鍵盤未實作」的歷史摘要，並分開列出核心工程暫結案與產品仍未驗收。
- `docs/MASTER_CHECKLIST.md`：新增 AMQ-681 至 AMQ-688。
- `docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`、`README_FIRST.md`：更新核心範圍結論與下一步。

## 最新測試證據（沿用 Batch 62 實際執行）

- 全部 `tests/*.test.cjs`：26/26 scripts exit 0。
- App lifecycle integration：2/2 PASS。
- Data pipeline integration：20/20 PASS。
- Tooling：8/8 PASS。
- Architecture：466 passed，0 failed。
- Source audit：AMQ 38,821、EMQ 16,839；重複 ID／失效關聯／跨來源碰撞為 0。
- Mapper：Catalog 55,660 筆 PASS。
- Catalog benchmark：5 次 Node 記憶體內量測 PASS。
- JavaScript／CJS syntax：64/64 PASS。
- 來源 SHA-256 未變，見 `docs/HANDOFF_BATCH62.md` 與 `/mnt/data/amq_batch62_logs/`。

本批只有文件變更，沒有程式碼變更；因此不把 Batch 62 的測試描述成 Batch 63 新執行的程式測試。

## 仍未結案的產品驗收

1. 真實瀏覽器 mount／dispose／remount、主要操作、響應式、鍵盤與跨分頁 storage。既有 Chromium CLI 無 DOM 輸出及頁面導覽 `ERR_BLOCKED_BY_ADMINISTRATOR` 仍為環境阻塞，不重試相同方法。
2. 真實音訊可聽性、跨域／autoplay 與乾淨 Windows 啟動。
3. Candidate302／Candidate382 Stage 0 正式相容性。Candidate381 僅靜態參考，遵照使用者指示不搜尋 Candidate302。
4. `aniFavorites_v1` 身份與 source-less legacy IDs 的來源歸屬。未取得可信證據前不寫收藏、不自動遷移。
5. 階段 5 UI／CSS 重構與視覺驗收。必須保留已認可畫面，真正替換舊實作；缺少可用瀏覽器與核准視覺基準時不宣稱驗收。
6. 深色主題、背景 IndexedDB、多人與外部匯入維持 P2／待確認，不阻擋單機核心工程暫結案。

## 下一步

目前不應再自動發明新的核心重構工作。下一步需取得可用的真實瀏覽器驗收通道，以及階段 5 可用的核准視覺基準／必要參考證據；取得後再執行 UI／CSS 與最終驗收。整個產品目前仍未結案。
