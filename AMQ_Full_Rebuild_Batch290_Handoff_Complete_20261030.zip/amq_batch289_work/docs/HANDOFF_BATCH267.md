# Batch267 交接：Home／Catalog 視覺密度改善

## 基準保護
- 從 Batch266 工作副本繼續，Batch266 ZIP 未覆寫；本目錄沒有 Git repository，未初始化 Git。
- AMQ／EMQ 原始資料、source mapper、query/data/audio owner 未修改。

## 實作
- `src/styles/ui-design-landing.css`：將 Batch261–263 的重複 Home/Catalog override 區段整合成單一 Batch267 區段。
- Home 改成較短的主視覺、六個桌面橫向入口、平板三欄兩列、手機兩欄三列；最近學習仍由 `playbackHistoryStore` 持有。空紀錄不造假。
- Catalog 保留正式左篩選／中央列表／右詳情／底部 Dock 結構；桌面曲目列 CSS track 56px、縮圖 34×45px；平板兩欄、手機單欄。
- `tests/ui-shell-css.contract.test.cjs` 更新舊 Batch262 Home rows contract，改為保護 Batch267 新布局。
- 新增 `tests/batch267-home-catalog.browser.py` 與 `artifacts/batch267-home-catalog/` 四尺寸截圖、正常 Catalog layout fixture 與獨立 opaque-origin error screenshots。

## 驗證
- Batch267 Home/Catalog layout browser：63/63 PASS，尺寸 1920×1080、1440×900、1024×768、390×844；0 page errors，無水平溢位；桌面整頁無垂直溢位。
- `tests/app-shell.browser.test.py`：輸出 144/144 PASS；命令包裝器在摘要後清理階段超時，無殘留程序。
- `tests/ui-shell-css.contract.test.cjs`：8/8 PASS。
- `tests/batch266-settings-workspace.contract.test.cjs`：3/3 PASS。
- `tests/batch265-visual-structure.contract.test.cjs`：6/6 PASS。
- `tests/results-ui.contract.test.cjs`：7/7 PASS。
- `tests/quiz-ui-state.contract.test.cjs`：5/5 PASS。
- `node --check src/ui/app-shell.js`、Python AST compile：PASS。

## 證據界線與未完成
- 本批 browser harness 使用正式 app-shell 與 CSS，但為避免載入完整 AMQ／EMQ data/runtime bundle，測試時省略重量級資料腳本，並由 fixture 建立 Catalog workspace、六筆歌曲與 SVG 封面。因此 63/63 只證明 UI layout／CSS，不是正式 Catalog runtime 或 live artwork 驗收。
- Home 截圖在沒有 playback history 時正確顯示空狀態，但仍缺少真實作品圖像。最終 osu! 視覺 gate 明確未通過。
- Catalog 六筆 fixture 的列表下方空間不代表正式 25 首資料布局；需在可用 HTTP-origin 取得真實資料畫面。
- HTTP-origin `ERR_BLOCKED_BY_ADMINISTRATOR` 未重試；live ANN/VNDB、音訊、多用戶、Windows／實機與全量 Node suite 未驗收。

## Batch268 下一步
1. 檢查 runtime／Catalog snapshot 是否能在不新增狀態 owner 的前提下提供可驗證的 featured work；只顯示明確來源與 workId。
2. Home 只有在 provider 回傳真實圖片時才呈現作品封面，無資料仍維持誠實 fallback。
3. 取得正式 Catalog 25/50 首列表與 live artwork 截圖；如果環境阻擋 HTTP-origin，記錄阻塞並繼續做可完成的正式 UI 工作，不重複同一 probe。
4. 逐項核對 osu! Client Interface 參考圖，保留差距表；未關閉 P0 不得標記視覺通過。

## 交付封裝原則（Batch268 起生效）
詳見 `docs/DELIVERY_PACKAGE_POLICY.md`。完整工作區與每批主要交付包分離；不得無條件攜帶所有歷史 PNG 與測試日誌。精簡前必須檢查引用與重建方式，保留最新驗收證據、歷史摘要索引、manifest 與 SHA-256；20–40 MB 是初始目標，不是犧牲完整性或可執行性的硬性配額。
