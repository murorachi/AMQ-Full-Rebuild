# AMQ 新版重建交接：Batch139（備份後多人歷史語義保留）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 維持唯讀。

## 實作
- 新增 `tests/multiplayer-backup-semantics.test.cjs`，使用實際 temporary SQLite DB 建立 closed room、成功 room.close command replay record、timeout assessment payload 與 SRS assessment event。
- 透過正式 `backup-private-server.cjs` 建立一致性 snapshot，再用 `verify-private-server-backup.cjs` 驗證。
- 逐欄比對 source／backup 的 room row、command fingerprint/result/timestamp 與 SRS event identity/status/revision/result。
- 對 backup 使用 read-only SQLite connection 啟動 host，驗證 retained member 的 closed snapshot、個人 timeout assessment 與原 room.close requestId replay。沒有還原或覆寫 live DB。

## Targeted test
- `node --test tests/multiplayer-backup-semantics.test.cjs`：1/1 PASS。
- 完整回歸與封包結果以 `docs/WORK_STATUS.md` Batch139 收尾段落為準。

## 限制／下一步
- 測試證明目前 schema／fixture 的 SQLite snapshot 語義保留，不等於所有舊 schema 都已驗收。
- Batch140：檢查 SRS event idempotency 與 schema drift 診斷；維持 read-only，不自動 migration／restore／刪除資料。
