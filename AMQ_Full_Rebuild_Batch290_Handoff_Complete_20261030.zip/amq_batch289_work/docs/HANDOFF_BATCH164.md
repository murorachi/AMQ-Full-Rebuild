# Batch164 交接：Catalog 窄螢幕表格與播放狀態責任（2026-10-28）

## 開工確認
- 已讀取 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH163.md` 與 `docs/NEXT_SESSION_PROMPT.md`。
- 工作副本 `/mnt/data/amq_batch153_work` 沒有 `.git` metadata；`git status` 回報不是 Git repository，未初始化 Git。
- Candidate302、Candidate382 Stage 0 及 AMQ／EMQ 原始曲庫資產未修改。

## 實作
- `src/index.html`：正式 Catalog 表格容器加上可存取名稱、`role="region"` 與 `tabindex="0"`，允許鍵盤使用者聚焦水平捲動區；表格新增隱藏 caption，說明歌曲列的方向鍵／Enter 操作。
- `src/styles.css`：Catalog 表格最小寬度 620px，窄螢幕由外層容器水平捲動，不把五欄壓縮成難以閱讀的窄欄；容器有可見 `focus-visible` 樣式。列表與詳情在 820px 以下仍堆疊，詳情面板回到正常文件流。
- `tests/catalog-filter-layout.contract.test.cjs`：新增窄螢幕水平捲動／焦點區／caption／桌面雙欄契約測試，並檢查 Catalog selection 與 Free Player 音訊狀態責任分離。
- 確認 `src/ui/catalog-browser.js` 的列選取只更新 Catalog selection，Enter 只選取、不播放；`src/ui/free-player-dock.js` 透過其 AudioService subscription 決定播放狀態。沒有把播放狀態複製進 Catalog，也沒有新增第二個播放 owner。

## 驗證
- `node --test tests/catalog-filter-layout.contract.test.cjs tests/catalog-browser.integration.test.cjs tests/catalog-browser.test.cjs tests/app-lifecycle.integration.test.cjs`：8/8 top-level tests PASS。
- `node tools/check-architecture.cjs`：1,044 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- `node --check src/ui/catalog-browser.js`、`node --check src/app.js`、`node --check src/ui/free-player-dock.js`：PASS。
- 日誌位於 `artifacts/batch164-regression/`。
- 本批未執行 70 個 Node 測試檔案的全量回歸；只執行受影響的測試組合及架構檢查。

## 未解決／阻塞
- 真實 Chromium viewport 截圖／滑鼠、鍵盤及觸控實機驗收仍未完成。此前 file／localhost 導覽被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；本批沒有重試相同無效路線。
- ANN 真實 API／CORS／圖片載入、真實 `.osk`、允許 HTTP origin 下的 IndexedDB save/reload/clear 仍待環境解除。
- Free Player 目前有獨立 AudioService owner；Catalog 的 Enter 不播放是既有明確行為。本批沒有擅自把列表選取與播放綁在一起。若產品未來要求「從 Catalog 播放」，應以明確的共享播放服務／命令設計另立批次，不要把 selection 當成播放狀態。

## 下一步（Batch165）
1. 以可用瀏覽器環境驗收窄螢幕水平捲動、焦點順序與詳情面板堆疊；若仍被政策阻擋，記錄並繼續其他工程工作。
2. 檢查列表列密度、欄位標題與長標題／來源連結在小尺寸下的可讀性，保留可存取性與 Skin selection frame。
3. 完成目前可執行的核心回歸；不要只因 UI 批次持續就跳過整合驗證。
4. ANN API、`.osk`、IndexedDB 真實瀏覽器驗收保持明確阻塞狀態。
