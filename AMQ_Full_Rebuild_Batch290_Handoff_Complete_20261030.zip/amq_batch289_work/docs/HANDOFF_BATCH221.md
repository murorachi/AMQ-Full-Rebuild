# Batch221 交接：Catalog mode-switch／空曲庫狀態

日期：2026-10-29
工作副本：`/mnt/data/amq_batch216_work/project`
來源交付：`AMQ_Full_Rebuild_Batch220_MultiplayerNetworkRecovery_Tests_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch221_CatalogModeSwitch_EmptyState_20261029.zip`

## 實作

- 新增 `tests/catalog-mode-switch.integration.test.cjs`，使用獨立 fake DOM、state store 與 runtime，驗證 AMQ／EMQ／MIX mode switch，不再把既有多 mount 共用 DOM 的 Catalog integration fixture 當作 mode-switch 驗收。
- mode switch 期間清除舊 row／selected detail，焦點回到搜尋欄；新 source snapshot 載入後只顯示該 mode 的 records。舊 AMQ load response 在 MIX request 後完成時不得覆蓋 MIX。failed load 不得保留舊 rows，且錯誤可見。
- 修正 `src/ui/catalog-browser.js` 空曲庫狀態判定：`dataStatus="empty"` 現在優先於 `state.hasCatalog && state.total===0` 的 filtered-empty 判斷。真正 source-empty 顯示 `empty`；有 catalog 但 filter 無匹配才顯示 `filtered-empty`。

## 驗證

- 全量 Node suite：78/78 PASS。平行跑時 `database-update-panel.test.cjs` 有一次 timing-sensitive failure，個別重跑通過；最終所有 78 個 test files 均有 PASS status/log。
- `tests/catalog-mode-switch.integration.test.cjs` PASS：AMQ／EMQ／MIX、focus、stale load、failed、empty。
- Chromium formal shell 92/92 PASS；Architecture 1,144/0；173 JS/CJS syntax PASS；3 Python `py_compile` PASS。
- AMQ／EMQ 靜態資產 hash 未變。

## 限制

- HTTP-origin test 未重跑，Chromium loopback `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變；真實 save/reload 未驗收。
- 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成。無 `.git`，未初始化；正式基準原始檔缺席，不宣稱相容。
- UI 主線未結案。

## 下一批優先

1. Catalog failed／partial／empty／filtered-empty 狀態矩陣與 focus／error recovery。
2. Multiplayer network／command error recovery 維持；production source 有變更時跑完整 Node suite。
