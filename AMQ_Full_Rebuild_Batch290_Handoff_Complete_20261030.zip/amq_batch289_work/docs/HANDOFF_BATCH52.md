# Batch 52 交接：來源明確個人清單與猜歌出題池

## 結果

Batch 52 已完成 source-aware work membership、source-aware watch status、曲庫 UI 接線、同頁 store 共享與 customListId 對 quiz eligibility 的整合。

## 核心契約

- 新清單成員：`workRefs: [{ source: "AMQ" | "EMQ", id: string }]`。
- AMQ:104 與 EMQ:104 是兩個不同 work refs。
- legacy `animeIds` 仍保存和展示，但因缺來源，不自動對應 AMQ／EMQ，也不進入猜歌出題池。
- 新看番狀態使用 source-aware key `@work:[source,id]`，舊 source-less 狀態仍保留，沒有猜測遷移。
- `QuizPanel` 透過 `isEligible(record)` 將選取清單接入題庫；比較 `record.source + record.animeId`。MIX record 的 `source` 仍是歌曲原始來源。
- app.js 同一 app lifetime 共享個人清單與設定 store；dispose 後清空引用以支援 remount。

## 修改檔案

`src/persistence/personal-library-store.js`、`src/ui/catalog-browser.js`、`src/ui/quiz-panel.js`、`src/app.js`、`tests/personal-library-store.test.cjs`、`tests/catalog-browser.integration.test.cjs`、`tests/quiz-panel.test.cjs`、`docs/PERSONAL_LIBRARY_CONTRACT_BATCH50.md`、`docs/DATA_CONTRACT.md`、`docs/ARCHITECTURE.md`、`docs/PRODUCT_CORE_CONTRACT.md`、`docs/FUNCTION_INVENTORY.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`、`README_FIRST.md`、`MANIFEST.sha256`。

## 驗證

- `tests/*.test.cjs`：25/25 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- Architecture：459 passed／0 failed。
- Source audit：PASS；AMQ 38,821、EMQ 16,839。
- Mapper：PASS；Catalog 55,660，AMQ candidates 37,939，EMQ 16,839。
- Benchmark：5 iterations PASS（Node in-memory only）。
- JS/CJS syntax：PASS。
- 真實瀏覽器 E2E：仍 BLOCKED，既有 `ERR_BLOCKED_BY_ADMINISTRATOR`；不重試相同導覽方式。

## 下一批

1. 核對持久化 UI 的 write failure／recovery warning 投影與跨 store 狀態。
2. 依必要功能真相表完成尚可安全驗證的 P1 缺口。
3. 強化 AudioService／QuizSession／mode switch 跨模組回歸。
4. UI／CSS 大重構仍排階段 5。

## 不得做

- 不得將 source-less `animeIds` 猜成 AMQ 或 EMQ。
- 不得寫入身份未證實的 `aniFavorites_v1`。
- 不得宣稱真實瀏覽器／音訊／Windows 啟動／Candidate302／Candidate382 Stage 0 相容性已驗收。
- 不得初始化 Git 或修改來源資料資產。
