# 曲庫更新／匯入契約（Batch 84）

## 目標與範圍

這是**完整 AMQ + EMQ 原始來源資料包**的離線匯入流程，不是線上自動更新器。沒有經核實的官方更新 endpoint，因此不會假造下載 API。使用者可以從目前 runtime 匯出更新包，也可用 `tools/create-database-update.cjs` 將可信的 `data.js` 與 `emq-data.js` 來源檔打包。

## JSON 格式

```json
{
  "format": "amq-learning-database-update",
  "formatVersion": 1,
  "createdAt": "ISO-8601 timestamp",
  "payload": {
    "schemaVersion": 1,
    "sources": {
      "AMQ": {
        "schema": "candidate382-stageI-library-data-v1",
        "anime": [],
        "songs": []
      },
      "EMQ": {
        "schema": "candidate382-stageI-library-emq-v1",
        "version": 1,
        "works": [],
        "songs": []
      }
    }
  },
  "checksum": "SHA-256 hex"
}
```

`checksum` 是對 `payload` 的 canonical JSON（物件鍵按字典序遞迴排序、陣列維持原順序）計算 SHA-256。checksum 不覆蓋 `createdAt`，但格式版本與 schema 會在預檢中獨立嚴格檢查。格式不接受未知 schema，不自動猜測或轉換其他資料格式。

## 預檢與差異

1. 解析 JSON，不執行匯入檔內的程式碼。
2. 驗證 envelope、格式版本、payload schema、AMQ／EMQ source schema、非空作品與歌曲表。
3. 驗證 SHA-256。
4. 使用現有 AMQ／EMQ mapper 建立正規化記錄，完整執行 `validateRecords()`；拒絕重複來源 ID、懸空作品參照、欄位錯誤及不完整來源標籤。
5. 與目前有效來源資料比較，預覽每個來源的作品／歌曲新增、修改、移除數量。
6. 預檢不寫入任何儲存。

## 套用與 runtime 消費

- 成功套用以 IndexedDB `amq-learning-database-updates` / `datasets` / key `active` 的**單一 readwrite transaction** 原子替換完整 envelope。交易失敗或 quota error 不會提交半份 AMQ／EMQ 資料；既有 active envelope 保持不變。
- 不使用 localStorage 儲存大型曲庫，也不覆寫 `src/data/assets/data.js`、`src/data/assets/emq-data.js`。
- 新 runtime 會先讀取 active envelope，重新驗證 checksum／schema／完整映射，再直接把正規化記錄交給既有 Repository／Validator／Catalog。若 active envelope 損壞，runtime fail closed；不會靜默以內建資料假裝更新仍有效。
- 套用成功後必須重新載入頁面，避免現有 runtime／UI 持有舊 Catalog snapshot。UI 提供「恢復內建曲庫」，以獨立 IndexedDB transaction 移除 active override，不改內建資產。
- 匯入要求完整 AMQ + EMQ，確保兩來源在同一筆交易中切換；不支援只替換單一來源的半套資料包。

## CLI 打包

```sh
node tools/create-database-update.cjs <trusted-data.js> <trusted-emq-data.js> <output.json>
```

工具只解析單一 `window.DB = <JSON>` 與 `window.__EMQ_PACKED_B64 = <JSON string>` 指派，不執行來源 JavaScript。工具檢查基本來源 shape 並計算 checksum；完整 mapper／關聯驗證仍由應用匯入預檢執行。輸出使用 `wx`，不會覆蓋既有檔案。請只提供可信來源檔，並保管好可能很大的更新包。

## 測試證據與限制

- `tests/database-update.test.cjs` 覆蓋版本化格式、checksum、完整 mapping／validation、差異、錯誤資料拒絕、預檢後 checksum 鎖定、套用、儲存失敗保留原包及移除 override。
- `tests/database-update-runtime.integration.test.cjs` 使用小型 fixture 與注入式 store 證明 runtime 會消費匯入後 AMQ／EMQ 正規化記錄，並在清除 override 後回到內建來源。
- `tests/database-update-panel.test.cjs` 覆蓋預檢失敗不套用、差異預覽、確認套用、重新載入提示、匯出及恢復內建曲庫 UI 流程。
- `tests/tooling.test.cjs` 覆蓋 CLI 打包與 checksum。
- 上述 Node／注入式 store 測試**不等於真實瀏覽器 IndexedDB transaction、quota、跨分頁及 reload E2E**。這些仍待使用者在可用瀏覽器環境實機驗收；已知 Chromium 導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重試同一路徑。
