# Batch205 交接：Wiki 語義追溯與 Skin mapping 防誤用

## 使用者新增的要求
每個 UI 模組開發都必須對照 osu! 官方 Wiki。Wiki 不是交付後的附註，而是元件語義與驗收依據。不能只做「像 osu!」的視覺，亦不可把 AMQ 自訂版型冒充 stable 原生元件。

## 本批修改
- 新增 `docs/OSU_STABLE_WIKI_TRACEABILITY_BATCH205.md`，列出官方 Client / Interface、Skinning / Interface、skin.ini、Options 與 AMQ 正式 UI 的語義對照。
- `menu-button-background.png` 只映射 Catalog 歌曲列背景／選取狀態，不再建議給歌曲詳情、播放器、多人、學習、設定面板。
- `songselect-bottom.png` 只映射 Catalog 底框，不再自動映射獨立播放器底座。
- 同步 `docs/skin-contract/*.json` 與 `src/skins/skin-contract.js`，加上語義防回歸測試。
- 更新 `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md`。

## 驗證
- `node --test tests/skin-contract-manifest.test.cjs tests/skin-theme-adapter.test.cjs tests/catalog-filter-layout.contract.test.cjs tests/free-player-visual-contract.test.cjs`: 33/33 top-level tests PASS；Free Player contract 21 assertions。
- `python tests/osk-import-panel.browser.test.py`: 12/12 assertions PASS。
- `node tools/check-architecture.cjs`: 1,123 PASS / 0 FAIL。
- `node --check src/skins/skin-contract.js`: PASS。
- `python -m py_compile tests/osk-import-panel.browser.test.py`: PASS。

## 限制
本批只完成有 Wiki 證據的素材語義修正，不是全量測試，也不代表 UI 完工。真實 `.osk`、HTTP-origin IndexedDB、真實曲庫／音訊與完整桌面／手機視覺仍未驗收。Candidate302／Candidate382 Stage 0 原始檔缺席；工作區無 `.git`，沒有初始化；AMQ／EMQ 資產未修改。

## 下一批 Batch206
逐頁對照首頁、選曲、猜歌、學習中心、設定的 Wiki 行為與正式 DOM，建立每頁元件清單／差距／驗收條件，並直接修正可證明的 UI 缺口。維持 stable 原生元件與 AMQ extension slots 的明確區分。
