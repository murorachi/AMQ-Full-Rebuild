# Batch 29 交接：MIX 正式來源規則與猜歌接線

## 已完成
- 靜態參考 `AMQ382(1).html` 的 `__aniEmqAPI.chooseQuestion`：MIX 兩個來源皆有未出題候選時，以 2/3 機率抽 AMQ、1/3 抽 EMQ；某來源無候選時 fallback 到非空來源。
- `src/data/source-runtime.js` 的 MIX 使用 AMQ／EMQ composite adapter，不再回報 `DATA_MODE_UNCONFIGURED`。
- `src/engine/quiz-pool.js` 支援 MIX 並用 source+ID 區分身份；`quiz-session.js` 實作 source weighting。
- `quiz-panel.js` 在 MIX 讀取兩個來源的聯合 catalog，並可開始猜歌；SRS 仍 AMQ-only、黑名單只套用 AMQ。
- 真實資料整合測試：AMQ 38,821、EMQ 16,839、MIX 55,660 normalized records；MIX 可播放池 54,778。

## 尚未移植的 legacy MIX 篩選語義
- 舊版 AMQ 專屬限制（watchlist／watch status／season／anime type／difficulty／hard pool）在 MIX 會抑制 EMQ，除非有明確 EMQ 自訂清單範圍。新版目前沒有這些篩選 UI，所以本批沒有憑空加入未存在的篩選系統。
- EMQ SRS 尚未支援；legacy SRS schedule 沒有 source 欄位。
- 真實瀏覽器 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。

## 測試
- `node tests/source-runtime.integration.test.cjs` PASS（真實資料）。
- `node tests/quiz-pool.test.cjs` 5/5 PASS。
- `node tests/quiz-session.test.cjs` 13/13 PASS。
- 完整 Node 回歸 PASS：core 67/67、data pipeline 15/15、blacklist 9/9、catalog browser 6/6、familiarity 6/6、FSRS scheduler 6/6、quiz history 9/9、quiz pool 5/5、quiz session 13/13、SRS store 13/13、source mapper 6/6、tooling 8/8；architecture 400/0；source audit／mapper verifier／所有 JS/CJS syntax PASS。
