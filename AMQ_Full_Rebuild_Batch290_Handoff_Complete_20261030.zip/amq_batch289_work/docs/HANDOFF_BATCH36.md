# Batch 36 交接：錯誤診斷快照與可變資料隔離

## 結論
`src/core/errors.js` 現在會把 `details` 轉成有界、遞迴凍結的診斷快照，避免呼叫端後續修改原始物件時改寫已發布的錯誤狀態。深度最多五層、每個陣列或物件最多 100 項；非 plain object 轉成字串。`cause` 摘要的 name 最長 100 字元、message 最長 1000 字元，並凍結。錯誤契約仍不依賴 DOM 或 console。

## 修改檔案
- `src/core/errors.js`
- `tests/core.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH36.md`
- `MANIFEST.sha256`

## 驗證
- Core 76/76 PASS。
- `tests/*.test.cjs` 21/21 腳本 exit 0。
- Tooling 8/8 PASS。
- Architecture 415 passed / 0 failed。
- Source audit、mapper verification、五次 benchmark、全量 JS/CJS syntax PASS。
- AMQ 38,821、EMQ 16,839、Catalog 55,660。
- 具體日誌位於 `/mnt/data/amq_batch36_logs/`。

## 限制
- 真實瀏覽器 UI／音訊 E2E 維持 BLOCKED；不以 Node 測試替代。
- 舊版參考檔 `AMQ382(1).html` 與來源資料未修改。
- 工作目錄沒有 Git metadata，無有效 branch/commit/diff。

## 下一批
檢查 UI 顯示錯誤的投影規則與資料來源，確認 UI 只使用穩定錯誤欄位、不依賴原始 exception 物件；針對 quiz panel、catalog browser、app message 增加對 normalized errors／缺欄位／特殊字元的整合測試。避免改動產品視覺與錯誤文案，除非測試證明存在缺陷。
