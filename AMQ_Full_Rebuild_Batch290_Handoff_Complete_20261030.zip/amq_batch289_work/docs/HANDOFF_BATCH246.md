# Batch246 交接：Mapping Studio 操作閉環

## 基準與安全
- 唯讀基準 ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch245_Visual_Role_Audit_20261029.zip`。SHA-256：`2f860223b7ac0313f194b6f892dcd2d4177af481e366ca7cd3b8967c5283babb`，與 ZIP 附帶 `.sha256` 一致。舊 Batch245 handoff 內的 `c050330c...` 不一致，採實際 ZIP hash 並已記錄。
- 獨立工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch246_Mapping_Studio_Closure/AMQ_Full_Rebuild_Batch245_Project`。無 `.git`，未初始化；基準 ZIP 未覆蓋。
- AMQ／EMQ 原始資料 hash：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 修改檔案
- `src/persistence/skin-theme-store.js`：超過 500 個 roleMappings 或 100 個 roleStateMappings 時拒絕，避免 `.slice()` 靜默截斷。
- `src/skins/theme-transfer.js`：同樣的映射數量上限明確 fail closed，錯誤碼 `THEME_TRANSFER_INVALID_SCHEMA`。
- `src/ui/skin-import-panel.js`：apply 防重入、disabled／aria-busy、例外回報、finally 恢復狀態與焦點。
- `src/styles/ui-shell.css`：Mapping Studio select 實際 min-height 44px，修正高 specificity 42px 規則。
- `tests/skin-theme-store.test.cjs`、`tests/skin-theme-transfer.test.cjs`、`tests/ui-shell-css.contract.test.cjs`、`tests/osk-import-panel.browser.test.py`：加入資料上限、busy/error/focus contract、touch target、真實 pair apply/reset 與 fit／position／@2x regression。

## 驗證
- 全量 Node：90/90 test files，275 cases，0 failures；逐檔 log `artifacts/batch246-regression/node-tests/`，摘要 `node-suite-summary.txt/json`。
- Focused adapter/store/transfer/UI contract：41/41 PASS。
- Chromium formal shell：150/150；Home/Catalog：19/19；Quiz/Results：19/19；Canvas：15/15；Mapping Studio／OSK browser harness 成功，涵蓋 pair 預覽、44px、focus、fit／position、實際套用與 reset。
- Architecture Checker：1,279 PASS／0 FAIL；JS/CJS syntax 197/197；Python compile 13/13。
- 詳細日誌與截圖在 `artifacts/batch246-regression/`。

## 執行器紀錄
- 首次全量 Node 串行／並行彙整被工具總時限中斷，沒有將中斷視為成功。已補跑缺少的 `quiz-pool`（約 19.6 秒）、`server-auth-srs`、`source-runtime`、`tooling`（13/13）及 `database-update-panel`，最後依逐檔 TAP logs 重新彙總為 90/90。
- 初次 Mapping Studio browser run 發現 computed min-height 仍被 specificity 42px 規則覆蓋；已修正後再次通過。後續因 UI 成功文案改變，修正 browser wait predicate 後重跑成功。

## 未解與下一批
- 13 個 visual roles 仍 unsupported；35 個 wired roles 尚未逐一完成 browser apply/fallback/reset。
- HTTP-origin IndexedDB save/reload 仍受 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋，不重試相同探測；需環境政策或可用 origin 改變。
- Live artwork／曲庫／真實音訊、Windows／實機、Candidate302／Candidate382 Stage 0 與 native osu!stable fidelity 未驗收。
- Batch247：首頁／Catalog loading、empty、error、retry、搜尋／篩選／排序／鍵盤選取、真實 artwork adapter 與 390px/reduced-motion 回歸。
