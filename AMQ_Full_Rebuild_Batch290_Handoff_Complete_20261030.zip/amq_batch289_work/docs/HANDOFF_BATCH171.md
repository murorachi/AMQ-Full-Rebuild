# Batch171 交接：AudioService 事件接線失敗回滾

## 1. 工作副本與基準
- 工作副本：`/mnt/data/amq_batch170_work/amq_batch153_work`
- 工作副本沒有 `.git` metadata；未初始化 Git，沒有 branch／commit／diff 可報告。
- Candidate302 是既有正式維護基準，Candidate382 Stage 0 是 CSS 比較基準。兩份原始檔不在本工作副本；只保留既有指定，不宣稱已對原始檔做 hash 比對或瀏覽器相容驗收。
- `src/data/assets/data.js` 與 `src/data/assets/emq-data.js` 未修改；未覆蓋任何基準／曲庫資產。

## 2. 已實作
### `src/audio/audio-service.js`
- `request.handlers` 建立後，將 `addEventListener` 註冊迴圈放入 `try/catch`。
- 若任一事件接線拋錯，呼叫既有 `failCandidate(request, index, "media-listener-failed", error)` 並立即返回。
- 既有 `releaseMedia()` 會清除 timer、嘗試移除整組 handlers（包括部分已註冊與未註冊 handler，後者由 media API 安全忽略）、pause media、清除 source／load；接著嘗試下一個候選。
- 沒有新增第二套播放狀態、owner 或 retry loop；沿用 AudioService 原本的候選順序與錯誤 diagnostics。

### `tests/audio-service.test.cjs`
- 新增 runtime failure injection：primary media 在 `playing` listener 註冊時拋出 `listener wiring failed`，此前的 `loadedmetadata`／`canplay` listeners 已部分註冊。
- 驗證最終結果是 backup candidate `playing`、`candidateIndex === 2`、failure reason 為 `media-listener-failed` 且 message 保留原始錯誤內容。
- 驗證 primary media 已 pause、source 清空，且部分 listener 全部 detach。

## 3. 測試證據
- `node tests/audio-service.test.cjs`：18/18 assertions PASS。
- `tests/` 下 71 個 `*.test.cjs` 分 9 組逐檔執行：9/9 組 exit 0，0 failed files。初始 orchestration 曾碰到外層工具時間限制，之後分組逐檔重跑完成；中斷命令本身不計為成功。日誌：`artifacts/batch171-regression/group-01.log` 至 `group-09.log`，摘要：`artifacts/batch171-regression/summary.json`。
- `node tools/check-architecture.cjs`：1,051 PASS／0 FAIL，`artifacts/batch171-regression/architecture.log`。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS，`artifacts/batch171-regression/osk-panel.log`。這是既有 OSK 面板 harness，不代表真實 `.osk` 匯入驗收。
- `node --check`：`src/`、`tests/`、`tools/`、`server/` 共 160 個 JS/CJS 檔案 PASS，`artifacts/batch171-regression/syntax.log`。

## 4. 尚未驗收／阻塞
- 真實瀏覽器音訊播放、片段起點、跨域來源與實際可聽性。
- ANN 線上 API／CORS／圖片、真實 `.osk` 相容性、HTTP-origin IndexedDB save/reload/clear、真實 viewport／鍵盤流程。
- Candidate302／Candidate382 Stage 0 原始檔缺席，不能完成對原始基準的 hash／相容比對。
- 以上不阻擋繼續做 Node 可重現的音訊競態與持久化回歸，但不得將 mock 測試冒充真實環境驗收。

## 5. 下一批 Batch172
1. 檢查 AudioService 的 cancel、pause、timeout、fallback 事件交錯；每項缺口先以可重現測試證明。
2. 檢查 QuizSession playback epoch、mode switch 與遲到的 audio promise／media event；沿用現有 guard，不建立第二套狀態機。
3. 補結果持久化 failure matrix 與下一題／回合結束整合；不改熟悉度 0–10s=4、>10–15s=3、>15s=2、錯／超時=1，且 all 模式只看作品標題。
4. 更新同一份主清單、狀態、handoff、下一批提示詞；測試、架構、語法與 ZIP hash 一併交付。
