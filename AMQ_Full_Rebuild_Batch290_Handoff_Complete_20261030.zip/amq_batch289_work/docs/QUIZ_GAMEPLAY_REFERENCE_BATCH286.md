# Batch286：依使用者提供的 AMQ 遊戲畫面重建 Quiz 位置與功能

日期：2026-10-30

## 參考來源
- 使用者提供畫面原檔：SHA-256 `3ba957004e70d59faab1e7fdcd0522e102719beb78ccde28629de8ffd632001f`
- 封裝用參考圖：`artifacts/quiz-reference/amq-gameplay-layout-reference.jpg`
- 本批正式 UI 截圖：`artifacts/batch286-quiz-gameplay-layout/quiz-1920x1080.jpg`
- 並排差距圖：`artifacts/batch286-quiz-gameplay-layout/quiz-reference-side-by-side.jpg`
- 四尺寸 Browser regression：`tests/batch286-quiz-gameplay-layout.browser.py`

使用者指定先忽略背景，主要參考位置與功能。原圖為多人遊戲畫面，AMQ 新版 Quiz 仍以單人猜歌為主，因此保留位置語義，不憑空加入聊天室、全球排名、玩家分數或虛構角色。

## 原圖到 AMQ 正式 DOM 的映射

| 原圖區域 | Batch286 AMQ 實作 | 真實資料／事件 owner | 限制 |
|---|---|---|---|
| 頂部離開、快捷操作與模式列 | `#app-shell-nav` 在 Quiz route 改為 38px 水平遊戲列；手機 42px | `src/ui/app-shell.js` route owner | 保留現有導航；沒有假造 osu! 專用按鈕行為 |
| 頂部中央題數 | `.quiz-game-hud .quiz-game-progress` | `#quiz-progress`，由 Quiz session 更新 | 真實題數／總題數；不生成排名 |
| 中央大型題目區 | `.quiz-game-primary` + `.quiz-question-card` | `src/ui/quiz-panel.js`／Quiz session | 背景暫用 AMQ 基礎層，使用者要求本批不處理背景 |
| 左側目前排名卡 | `.quiz-game-left-rail .quiz-game-session-card` | `#quiz-status`、`#quiz-pool-size` | 顯示回合狀態與實際可播放曲目數，不假冒全球排名或玩家分數 |
| 右側問號作品圖塊 | `.quiz-hidden-song-tile` | `src/assets/amq-note-question.png` | 只表示答案尚未揭曉，不假裝是真實作品封面 |
| 右側聊天面板 | `.quiz-game-rail` 的音訊狀態與既有 `#quiz-history` 答題紀錄 | `#quiz-audio-status`、quiz history store | 單人頁沒有聊天 API，所以使用真實答題紀錄；沒有建立假聊天室 |
| 底部答案輸入列 | `.quiz-answer-form`，輸入與提交在同一列 | `#quiz-answer`、`#quiz-submit`、`answer-suggestions.js` | 原生輸入、候選選單與鍵盤互動保留 |
| 回合操作列 | `.quiz-actions` | 原有 start/play/pause/reveal/skip/next/end handlers | 不改變 Quiz phase owner 或音訊狀態機 |
| 原圖底部狀態列 | 本批沒有另造一組全域數值 | 既有應用狀態與設定 | 不用假貨幣、假 PP 或假玩家資料填版面 |

## Skin System

新增並接通六個 Quiz role，manifest、runtime role registry、visual-needs registry、theme adapter selector 與 CSS token 同步：
- `quiz.game-hud`
- `quiz.game-session-summary`
- `quiz.game-stage`
- `quiz.game-status-rail`
- `quiz.answer.panel`
- `quiz.answer.reveal`

Role inventory 更新為 58 roles、46 runtime selectors、12 explicitly unsupported。這只代表可映射的 runtime targets 增加，不代表 46 個 role 都完成 OSK 真圖套用驗收。

## 已知視覺差距
- 使用者原圖有多人聊天室、玩家 avatar／ready 狀態、中央玩家分數與真實背景 artwork；單人 Quiz 沒有相同的資料 owner，因此本批不偽造這些功能。
- 主題背景、角色 artwork 與遊戲特效未納入本批，符合使用者「背景先不用管」的要求。
- 中央 stage、右側 rail 與原圖仍有比例差距；並排圖只用於差距檢查，不代表人工視覺驗收通過。
- 尚未驗證 live audio provider、HTTP-origin persistence、Windows／真機及正式曲庫資料。
