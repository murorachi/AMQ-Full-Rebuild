# Batch 40 交接：必要功能真相表與熟悉度讀取失敗防覆寫

## 結論
已新增以實際模組、測試與限制為依據的必要功能真相表，並修正 familiarity store 在 storage 讀取失敗時可能把未知的既有 map 當成空 map、進而覆寫資料的風險。沒有改動來源曲庫或舊版參考檔，沒有進行 UI／CSS 視覺重構。

## 實作
- `src/persistence/familiarity-store.js`：`readMap()` 明確回傳讀取結果；AMQ／EMQ 分開追蹤 `readBlocked` 與錯誤。讀取失敗保留原本記憶體快照、拒絕該來源寫入；成功的 storage event reload 才解除阻塞。新增 `getPersistenceStatus()`。
- `tests/familiarity-store.test.cjs`：新增 read failure regression，驗證不覆寫原始 storage bytes、寫入被拒絕、storage 讀取恢復後 reload 並成功保存。
- `docs/FUNCTION_INVENTORY.md`：增加必要功能真相表，明確區分核心已實作但待驗收、未實作、延後及阻塞項目。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`，並新增本 handoff。

## 測試證據
- `tests/*.test.cjs`：21/21 scripts exit code 0。
- `node tests/familiarity-store.test.cjs`：7/7 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：415 passed／0 failed。
- Source audit：AMQ 38,821 songs、EMQ 16,839 songs；重複 ID、dangling references、跨來源 ID collision 均為 0。
- Mapper verification：PASS；Catalog 55,660 筆，AMQ 38,821、EMQ 16,839。此結果只證明目前來源資料符合新版 mapper 契約，不證明 Candidate302 相容或音源可播。
- Catalog benchmark：5 iterations PASS；目前本機 Node 觀測值，不是瀏覽器效能保證。
- `node --check` 對 `src/`、`tests/`、`tools/` 全部 JS/CJS：PASS。
- 來源資產 hash 未變：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 完整日誌位於 `/mnt/data/amq_batch40_logs/`。

## 限制
- 真實瀏覽器 E2E 仍 BLOCKED，先前導覽回報 `ERR_BLOCKED_BY_ADMINISTRATOR`；本批不重試相同方式。
- 答題歷史明細與摘要是不同 localStorage key，不能宣稱跨 key 原子交易；需繼續核對部分失敗、重載與摘要重建。
- 尚無獨立完整版本化設定 store；收藏／自訂清單完整 CRUD、多人服務端及外部匯入未完成或延後。
- 真實音訊可聽性、跨域與真實瀏覽器 media event 時序未驗證。
- 工作副本無 `.git` metadata，未初始化 Git、未 commit／push。

## 下一批 Batch 41
1. 追查答題歷史明細／摘要部分失敗時的資料一致性、重載與重建，補有證據的回歸。
2. 評估並實作最小必要版本化設定 store，具備讀寫失敗降級、來源無關設定的明確 schema 與測試；不要順手做 UI 大改。
3. 執行熟悉度／歷史／SRS／黑名單／設定跨模組必要回歸。
4. 更新唯一清單、狀態、handoff、啟動指引、manifest 與完整 ZIP。

## Batch 40 最終交付封包
- 完整 ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch40_PersistenceTruthTable_20261027.zip`。
- `MANIFEST.sha256`：108 個檔案項目（不含 manifest 本身）。
- 封包包含 122 個 ZIP entries；`zipfile.testzip()` 為 `None`；從 ZIP 內逐項重算 manifest，108/108 hash 一致。
- ZIP 已完成 CRC 與 manifest 全項驗證。
