# AMQ 新版重建交接：Batch117

日期：2026-10-28  
基礎交付：`AMQ_Full_Rebuild_Batch116_Handoff_20261028(1).zip`  
Git：交付包沒有 `.git` metadata；未初始化 Git、未 commit、未 push。

## 本批目標

建立多人房間 authenticated HTTP API 的前端 client 邊界，為後續 room session/controller 與 UI 接線提供可測試基礎；不進行 UI/CSS 視覺重構。

## 實作成果

1. 新增 `src/multiplayer/http-client.js`，統一 list/create/join/snapshot polling/commands 路由。
2. 預設使用 `credentials: same-origin`；命令自動產生 `requestId`，呼叫端亦可提供固定 ID，供安全冪等重試使用。
3. room ID、ready 布林值、answer 字串在發送前驗證。
4. server error 的 code/status/details 保留；`ROOM_REVISION_CONFLICT` 不會被模糊化。網路錯誤轉為 `MULTIPLAYER_NETWORK_ERROR`，AbortError 原樣傳遞。
5. 將 client 加入 `src/index.html` 載入順序，並更新 `tools/check-architecture.cjs`，明確允許此 client 不載入至純核心 `tests/tests.html`。
6. 新增 `tests/multiplayer-http-client.test.cjs`，驗證 credentials、JSON body、requestId、API routes、revision polling、輸入驗證、server conflict、network failure 與 abort。

## 驗證證據

- `node --test tests/multiplayer-http-client.test.cjs`：5/5 PASS。
- `node tools/check-architecture.cjs`：850 passed／0 failed。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- JavaScript/CJS syntax：130/130 PASS。
- `node tests/quiz-pool.test.cjs`：10/10 PASS，約 21 秒；此測試包含大量抽樣，不應用過短 timeout 判定失敗。
- 55 個 `tests/*.test.cjs` 已逐檔執行；並行執行時 `database-update-panel.test.cjs` 與 `tooling.test.cjs` 曾因架構工具的並行子程序／負載短暫失敗，之後各自重跑通過。其餘逐檔結果為 PASS。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；曲庫 SHA-256 與 Batch116 相同。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS。
- Node v22.16.0；`node:sqlite` ExperimentalWarning 仍是既有環境限制。

## 尚未完成／明確限制

- 多人 UI 尚未接入；目前沒有可供使用者完整建立／加入／遊玩房間的前端流程。
- 本批沒有建立 polling timer/controller；輪詢生命週期、revision snapshot state、重連與 dispose 後遲到結果防護仍待完成。
- 尚未將多人 session 與既有 `AudioService`／`QuizClock` 安全協調；必須避免單人 QuizSession 與多人房間同時搶同一個 media owner。
- 多人 SRS 自動寫入、WebSocket、多節點一致性與真實瀏覽器／多客戶端／音訊 E2E 尚未完成。
- Candidate302、Candidate382 Stage 0 與來源曲庫資產仍唯讀；此批不宣稱舊版相容或音源真實可播放。

## 下一批優先順序

1. 建立 lifecycle-managed multiplayer room session/controller：單一 snapshot/revision owner、可取消 polling、避免重複輪詢與 dispose 後 stale response。
2. 增加 controller regression：poll start/stop/dispose、AbortSignal、unchanged/changed revision、網路恢復、command replay/conflict。
3. 做必要功能性 UI 接線，UI 僅投影 server snapshot，不自行決定評級、題目、計時長度或房間權威狀態。
4. 審核 AudioService／QuizSession／QuizClock 的播放 owner 交接；若需要，先建立單一 playback coordinator 與測試，不複製第二套音訊服務。
5. 集中更新工作清單、狀態、handoff、提示詞、架構／驗收文件與 manifest，再產生並驗證 ZIP。
