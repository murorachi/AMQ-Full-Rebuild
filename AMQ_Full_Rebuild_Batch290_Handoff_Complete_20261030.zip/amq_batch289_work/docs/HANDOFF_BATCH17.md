# AMQ 重建交接包：Batch 17 完成後

## 接手目的
延續 AMQ 學習工具全新架構重建。Batch 17 已完成目前核心基礎設施範圍內的狀態契約與生命週期取消強化。下一位 AI 不應再從頭分析整個專案，也不應為了「架構完整」持續增加抽象層。

## 開工順序
1. 先讀 `AI_START_HERE.md`、`README_FIRST.md`、`PROJECT_RULES.md`、`docs/WORK_STATUS.md` 最後一節、`docs/MASTER_CHECKLIST.md` 最後一節、`docs/ARCHITECTURE.md` 第十七批補充。
2. 先核對 ZIP 的 `MANIFEST.sha256`，再執行現有測試。不要因歷史測試紀錄而跳過本地驗證。
3. 確認實際工作目錄、是否為 Git 工作樹、版本與 diff；不要把此 ZIP 當成有 Git metadata 的 repository。
4. 不要重跑已被環境政策阻擋的相同瀏覽器導覽，除非執行環境有實質改變。

## Batch 17 已完成
- `src/core/state.js`：state patch 欄位白名單、非負安全整數計數驗證、subscriber 例外隔離、最多 50 筆 subscriber 診斷錯誤查閱與清除 API。
- `src/core/lifecycle.js`：scope 提供穩定 `signal`；dispose 時先 abort，再按 LIFO 清理。
- `tests/core.test.cjs`：新增 3 項核心回歸。
- `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/ARCHITECTURE.md`、`README_FIRST.md` 更新。

## Batch 17 驗證證據
- Core：67/67 PASS。
- Data pipeline：15/15 PASS。
- Query index：10/10 基礎 + 3/3 排序 + 4/4 組合／分組 PASS。
- Tooling：8/8 PASS。
- Source mappers：6/6 PASS。
- Architecture：154 passed、0 failed。
- 所有 `src/tests/tools` 中 JS/CJS 語法檢查 PASS。
- 目前可用的 AMQ／EMQ 來源稽核與 mapper/catalog 驗證 PASS，合計 55,660 筆；這不證明 Candidate302 配套或音訊可播放。
- ZIP 完整性 PASS；manifest 48/48 PASS。交付 ZIP 含 56 個項目。

## 仍未完成，不可宣稱已驗收
- Candidate302 正式維護基準本體及雜湊尚未取得。
- Candidate382 Stage 0 CSS 比較基準本體及雜湊尚未取得；Stage I 只可作參考。
- 真實瀏覽器 E2E 因 `ERR_BLOCKED_BY_ADMINISTRATOR` 維持 BLOCKED。
- 正式 UI、遊戲引擎、AMQ／EMQ／MIX 出題規則、模式切換重置、音訊備援與實際播放尚未驗收。
- 設定持久化與完整全域日誌策略尚未完成。核心 state 的 subscriber 錯誤佇列不是完整 logging 系統。

## 下一步優先順序
1. 低成本重跑現有完整測試，確認接手環境沒有退化。
2. 使用者已提供 `AMQ382(1).html` 並指定以 382 作舊版參考；本次已記錄其 SHA-256。依使用者指示不再搜尋 Candidate302，也不把上傳檔案自行改稱 Stage 0。
3. 若基準仍不可取得，停止擴張底層架構，改以 `docs/FUNCTION_INVENTORY.md` 將可證實的必要功能整理成一個完整的產品功能批次；不得猜測遊戲規則。
4. 下一個合理工程目標是建立可驗證的產品核心契約與最小可操作功能切片，而非再增加通用抽象或重複測試工具。
5. 每次交付只更新同一份 `docs/MASTER_CHECKLIST.md` 與 `docs/WORK_STATUS.md`，重新產出 manifest 與 ZIP，列明測試證據、阻塞、檔案 SHA-256。沒有使用者明確授權，不推送 GitHub、不覆蓋正式基準。

## 建議交接指令
「請依 `docs/HANDOFF_BATCH17.md` 接手。先確認檔案、版本、manifest 並重跑現有測試；不要重新掃描整個專案，不要重做 Batch 17。接著處理下一個可證實的高價值批次，優先取得正式基準；若基準不可得，記錄阻塞後轉做不依賴猜測產品規則的功能盤點與契約工作。批次完成後更新唯一主清單與工作狀態，測試、封包並交付。不得推送 GitHub或覆蓋舊版基準。」


## Batch 18 追加交接

- 已重跑現有 Node 測試及架構檢查，全部通過，詳細結果見 `docs/WORK_STATUS.md`。
- 使用者指定 `AMQ382(1).html` 作舊版參考；本地計算 SHA-256 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`。其 title 實際標記 Candidate381，並有 Stage I 線索，故僅按使用者用途作靜態參考，不宣稱 Stage 0。
- 使用者明確要求不再找 Candidate302，本專案後續不得把尋找 Candidate302 當作必要前置工作。
- 新增 `docs/PRODUCT_CORE_CONTRACT.md`，下一批優先接入曲庫瀏覽 UI；目前工作包未包含真實來源資料，接線前需明確處理來源缺失。
