# Batch159 Handoff：ANNID 直連動畫封面

## 已完成
- AMQ work row 的 `row[6]` ANNID 已被用作 ANN 封面查詢 ID。
- 新增 `src/integrations/ann-artwork-adapter.js`，請求 ANN Encyclopedia XML、解析 Picture `src`、官方 HTTPS host allowlist、ANN source URL／attribution、快取、取消與預設 1 req/sec 序列化節流。
- `artwork-provider-factory.js` 目前 AMQ 先查 ANN；ANN 無圖片時才使用明確 AniList ID 或傳入的 ANNID crosswalk。EMQ 仍用明確 VNDB ID。
- `app.js` 已建立／dispose ANN adapter，HTML 與架構檢查已更新。

## 驗證證據
- `node --test tests/ann-artwork-adapter.test.cjs tests/artwork-provider-factory.test.cjs tests/artwork-adapter.test.cjs tests/source-mappers.test.cjs tests/chinese-title-provider.test.cjs`：17/17 PASS。
- `node tools/check-architecture.cjs`：1,037 PASS／0 FAIL。
- 三個修改 JS 檔案 `node --check` PASS。

## 已知缺口
- 沒有在目前環境成功完成真實 ANN API／瀏覽器圖片載入驗收；fixture 測試不能當作真實 API 證據。
- 已補上 ANN 非取消類錯誤後的 AniList crosswalk fallback；AbortError／取消訊號不會被吞掉。不同 HTTP 429／500／timeout 類別仍待更細分測試。
- Attribution／ANN entry link 尚未在 UI 上呈現，只在 artwork result 內提供。
- `.osk` 真實檔案與 IndexedDB HTTP-origin 測試仍維持既有阻塞。
- 工作目錄 `/mnt/data/amq_batch153_work` 沒有 `.git` metadata；未初始化 Git，未覆蓋基準與原始曲庫。

## 下一批直接執行
1. 修正 ANN provider error fallback：ANN 非取消類錯誤時允許嘗試明確 AniList crosswalk；取消必須直接傳遞，不可吞掉。
2. 補測 ANN 429／HTTP 500／network／abort 與 AniList fallback。
3. 將 ANN attribution 及作品百科 link 接入可存取的 Catalog artwork detail／link UI，避免每列塞入冗餘文字。
4. 跑受影響回歸與架構檢查，然後繼續正式 osu!stable Song Select UI 分層替換。
