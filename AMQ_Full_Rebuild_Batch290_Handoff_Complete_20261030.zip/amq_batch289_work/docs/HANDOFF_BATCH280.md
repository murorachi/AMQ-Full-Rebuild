# Batch280 Handoff：Home 去除多餘外框，繼續 30 項 UI 工作

## 使用者回饋與方向
使用者確認 UI 有改善，但首頁與 osu! Stable 仍有明顯差距；明確要求移除側邊欄，並指出上方／底部 UI 使首頁擁擠。Home 必須優先提供全螢幕主視覺與遊戲入口，不需要全域 header、route sidebar 或底部最近紀錄面板。

## 本批實作
- `src/ui/app-shell.js`：`navigate()` 依 route 隱藏／顯示全域 header 與 route navigation；Home 初始狀態立即套用無 chrome 版面。Router 和 `currentPage` 仍是唯一導航 owner。最近紀錄使用 `displayText()` 過濾 null、undefined、NaN 等無效顯示值，避免污染標題與 metadata；動態 recent item/artwork/title 增加穩定 `data-skin-component` IDs。
- `src/styles/ui-design-landing.css`：Home 佔滿 viewport，移除 header、側邊 rail、recent 底部面板；主視覺左側、六個 osu!-style 斜切入口右側。其他頁面改用精簡水平導覽。Catalog Dock 的固定 left offset 改為 12px，避免保留舊側欄空間；Home 標題支援長字換行，recent keyboard focus 有明確樣式。
- `tests/batch273-home-menu.browser.py`：改用 Home 正式入口進 Catalog，新增 Home chrome 隱藏、底部面板隱藏、功能頁導航恢復檢查。
- `tests/batch280-home-chrome.contract.test.cjs`：新增 5 項結構性 regression。
- `docs/BATCH279_UI_TASK_SELECTION.md`：逐項更新 30 個工作狀態。

## 驗證證據
- `python tests/batch273-home-menu.browser.py`：102/102 PASS，1920×1080、1440×900、1024×768、390×844；Catalog 內容為明確 layout fixture。
- `node --test tests/ui-shell-css.contract.test.cjs tests/skin-theme-adapter.test.cjs tests/batch268-catalog-row-visual.contract.test.cjs tests/app-shell-navigation.contract.test.cjs`：33/33 PASS。
- `node --test tests/batch280-home-chrome.contract.test.cjs`：5/5 PASS。
- `node tools/check-architecture.cjs`：1351 PASS／0 FAIL。
- `node --check src/ui/app-shell.js`：PASS。
- `python tests/app-shell.browser.test.py`：逾時，未重試，未視為通過。

## UI 差距仍未結案
- 已檢視 `artifacts/osu-reference/osu-main-menu.jpg` 與最新 Home 截圖。新版去掉多餘 chrome 後更寬敞，但目前 AMQ 品牌 fallback 仍非正式作品背景，背景質感、入口尺寸／間距和 osu! Stable 的整體圖像構圖仍有差距。
- Home/Catalog 人工 Stable gate、正式資料與 live artwork、Dock 不遮擋真實列表、OSK recent 元件的可映射 resolver role、Windows／實機未驗收。
- 全量 Node suite 未執行；不得把 layout fixture 或 contract tests 當成產品驗收。

## 30 項工作狀態
完整逐項狀態在 `docs/BATCH279_UI_TASK_SELECTION.md`。已完成可由現有程式碼證實的 Home chrome、metadata fallback、keyboard focus、Catalog Dock offset 與列表密度；其餘人工視覺 gate、正式資料、provider runner 仍明確保持未完成。

## 下一批 Batch281
1. 依 `docs/BATCH279_UI_TASK_SELECTION.md` 剩餘項目繼續，不重做已完成項目。
2. 先把 Home 真正對應到 osu! Stable main menu 的背景／圓盤／斜切入口分層整理成可由 Skin System 替換的正式 targets；不要把 AMQ logo fallback 冒充 artwork。
3. 完成 Home recent 元件與 Skin Registry／Resolver 的可映射角色，補實際 apply/reset/fallback tests。
4. 做 Catalog Dock 與可視列數的 browser geometry / overlap regression；保留 live-data 未驗收狀態。
5. 更新同一份清單、狀態、traceability、差距登記、handoff、提示詞、manifest 與交付 ZIP。
