# osu!stable OSK 素材解讀與 AMQ UI 契約（Batch195）

日期：2026-10-28  
狀態：規格盤點完成；正式 UI 重新架構尚未實作或驗收。

## 1. 核心決策

AMQ 正式 UI 必須以 osu!stable Skin 的既有元件語意作為第一級設計約束。先建立與 OSK 命名／用途對應的 UI 元件，再以這些元件組成 AMQ 頁面。不能先做與 Skin 無關的任意卡片／表單版型，再要求使用者手動把素材塞進去。

但必須區分兩件事：

1. `.osk` 是 osu!stable Skin 素材包，通常包含固定檔名的圖片、音效與 `skin.ini`；它不是網頁 DOM 版型檔，不會提供任意頁面樹、CSS grid、每個元件的瀏覽器座標或 AMQ 專屬元件定義。
2. AMQ 需要實作一層明確的 **Stable Skin Compatibility Contract**：把 stable 已定義的素材名稱、狀態、用途、尺寸提示與 fallback 對應到 AMQ 元件。對沒有 stable 對應物的 AMQ 專屬功能，使用明確擴充角色，並在 UI 中標示其預設樣式與可覆寫素材槽位。

因此目標是「以 osu!stable 元件系統為骨架、擴充 AMQ 專屬槽位」，不是聲稱能把每一個 OSK 原樣變成完整網站模板。

## 2. 官方資料與版本邊界

- osu! Skin 概述：<https://osu.ppy.sh/wiki/zh-tw/Skin>
- Stable Interface skinning 元件表：<https://osu.ppy.sh/wiki/en/Skinning/Interface>
- `skin.ini`：<https://osu.ppy.sh/wiki/en/Skinning/skin.ini>
- 可自訂音效：<https://osu.ppy.sh/wiki/zh-tw/Skinning/Sounds>
- osu!stable 的主要遊戲客戶端原始碼沒有公開；`ppy/osu` 公開 repository 是 osu!lazer，不應拿它當 stable 原始碼。可用 Wiki 的 stable 元件規格作為契約，必要時再以真實 OSK 與 stable 實機畫面交叉驗證。
- OSK / `skin.ini` 有版本差異。Importer 必須保留 skin version，對未知或不支援項目採用安全 fallback，不應把 lazer 專屬元素或 beatmap skin 元素誤判為 stable 主介面素材。

## 3. 重要 Skin 資料分類

### A. 主選單／首頁

主要參考素材：
- `menu-background.jpg`：主選單背景，依 cover 方式填滿視窗並裁切；格式要求需遵守官方規格。
- `welcome_text.png`：啟動歡迎視覺。
- `menu-snow.png`：可選的主選單粒子／雪花視覺。
- `menu-back.png`：選曲等介面使用的返回圖形，可能是動畫序列 `menu-back-{n}.png`。
- 主選單的 osu! cookie 與主入口在 stable 介面中是固定互動概念；部分按鈕本身不是獨立可替換圖片，因此 AMQ 必須把「可換圖」與「只沿用互動／幾何語意」區分開。

AMQ 對應：首頁全屏背景、主選單中心大餅／核心入口、主入口周圍展開的導航項目、返回控制、可選裝飾動效。大餅入口是 AMQ 的互動設計，但應使用 stable 的主選單素材語意與主題規則，而不是硬宣稱有一個 OSK 專用「大餅」檔名。

### B. 選曲／歌曲瀏覽（最高優先）

重要素材與語意：
- `menu-button-background.png`：選曲難度項目／按鈕背景，也用於多個相關區域；官方規格有縮圖與最小尺寸提示，狀態 tint 可能改變顏色。
- `selection-bar.png`：選取條／列表選取狀態，須依 skin 版本處理。
- `selection-tab.png`：選曲分頁外觀。
- `selection-mode.png`、`selection-options.png`、`selection-random.png` 及相應圖示：選曲操作入口。
- `songselect-top.png`、`songselect-bottom.png`：選曲頁上／下框架素材，部分會依視窗寬度延展或重複。
- `star.png`、`star2.png`：難度星星與視覺效果，若 AMQ 沒有對應難度概念，不應為了使用素材而虛構難度數據。
- `ranking-*.png`、`ranking-panel.png` 等：視版本與用途用於分數／排名或面板，不應未驗證就當成通用卡片背景。
- `menu-back.png`：返回操作視覺。

AMQ 對應：中央密集歌曲列表、明確的選取／hover／focus 狀態、左側搜尋與篩選、右側選取歌曲資訊、清單／曲庫切換、底部播放控制。每個 UI 槽位要能在素材管理器中按「元件角色」找到，不可要求使用者靠檔名猜用途。

### C. 遊戲中 HUD／答題流程

Stable Skin 中有大量 gameplay 專用元素，例如倒數、進度條、判定／分數數字、游標、暫停與結果視覺、combo／hit feedback、遊戲音效等。這些元素的原始語意與 AMQ 猜歌不會完全相同。

AMQ 對應時要分層：
- 可直接重用的通用裝飾、背景、按鈕、面板與聲音。
- 可轉譯的進度／計時／判定視覺，例如把 stable 的狀態語意轉成 AMQ 倒數或答題結果，但不得直接把 osu! hit judgement 圖片當成 AMQ 的語意而不做設計。
- 無合理對應的元素不套用，並顯示 fallback 原因。

### D. 結算／排名

`ranking-*`、成績面板、重試／繼續等相關素材可作為 AMQ 結算頁的參考或對應槽位。AMQ 必須提供自己的分數、答題正確率、回合統計與下一步操作；不得假設所有 stable ranking 元素都適合直接套用。

### E. 設定／面板／按鈕

Skin 不會替每種網站設定表單提供完整元件模板。AMQ 應建立共用 `SkinButton`、`SkinTab`、`SkinPanel`、`SkinSlider`、`SkinToggle`、`SkinDropdown`、`SkinDialog`、`SkinTooltip` 等元件。對 stable 有對應素材的使用對應素材；沒有專用圖片的元件則依 skin.ini 色彩、通用框架、字體／間距 token 與預設樣式生成，並允許 AMQ 專屬角色覆寫。

### F. `skin.ini` 設定

至少應解析並保留：
- `[General]`：`Name`、`Author`、`Version` 與已知通用行為設定。
- `[Colours]`：可支援的色彩參數，包括 `ComboN`、`MenuGlow`、`SongSelectActiveText`、`SongSelectInactiveText` 等。色彩欄位需按語意映射，不可把 `Combo1` 等所有色彩一律當成網站主題色。
- `[Fonts]`：字體圖像前綴與 overlap 等數字字體設定。若 AMQ 不支援圖像數字字體，需保留 metadata 並明確標記 unsupported，不可假裝已套用。
- 各遊戲模式專用段落：只在 AMQ 有明確對應時使用；否則保留為已讀取／未套用的設定。

Parser 必須保留未知鍵值／原始 `skin.ini`，避免使用者匯入後失去未支援設定。大小寫、版本、色彩格式與缺值均需有測試。

### G. 音效

官方 Skin 支援多種音效檔案，但多數是 osu! 特定遊戲事件。AMQ 只應將具備明確語意映射的音效接到事件，例如：
- `menuhit`／`menuclick` 類：選單操作（須按實際 stable 名稱表核對）。
- `back` 類：返回操作。
- `pause`／`failsound`／`applause` 等：只有在 AMQ 有對應事件且聽感合理時才使用。

必須從官方 Sounds 頁建立完整檔名盤點與事件映射，不可猜測檔名、也不可將所有聲音任意隨機播放。音效可由設定控制開關／音量，並需遵守瀏覽器 autoplay 限制。

## 4. 必須建立的 AMQ 元件契約

正式 UI 需要建立穩定、可被 OSK mapping 指向的角色 ID。第一版建議角色族：

- `app.home.background`
- `app.home.primary-action`
- `app.navigation.back`
- `app.navigation.tab`
- `catalog.frame.top` / `catalog.frame.bottom`
- `catalog.item.background` / `catalog.item.selected` / `catalog.item.hover`
- `catalog.filter.background` / `catalog.search.background`
- `catalog.song-artwork`（優先用真實曲庫作品封面；不能把 OSK 角色圖自動當歌曲封面）
- `catalog.song-detail.panel`
- `player.dock.background` / `player.control.play` / `player.control.pause` / `player.progress.track` / `player.progress.thumb`
- `quiz.background` / `quiz.timer` / `quiz.answer.input` / `quiz.result.correct` / `quiz.result.incorrect`
- `multiplayer.room.panel` / `multiplayer.member.item` / `multiplayer.ready-state`
- `learning.progress.panel` / `learning.history.item` / `learning.review.item`
- `settings.panel` / `settings.toggle` / `settings.slider` / `settings.dropdown` / `settings.dialog`
- `results.panel` / `results.grade` / `results.primary-action`
- `feedback.success` / `feedback.warning` / `feedback.error`

以上是 AMQ 的語意角色，不表示每個角色在 OSK 中都有一個同名檔案。每個角色都要記錄 `stableAssetNames`、`mappingPolicy`（exact / derived / unsupported）、`fallback`、支援狀態、預覽與驗收條件。若沒有 exact stable asset，必須由已定義的 derived role／AMQ extension slot 提供，不可變成任意上傳後不知放哪。

## 5. 現有實作差距（已由原始碼確認）

目前 `src/skins/osk-importer.js` 只把資產映射成少數角色：`background`、`selectionBar`、`selectionMode`、`selectionRandom`、`selectionOptions`、`songSelectTop`、`songSelectBottom`、`rankingPanel`、`characterCandidates`。`skin.ini` 只抽取 Name／Author／Version 及 `[Colours]` 的 `ComboN`，並沒有解析完整的 Interface 元件表、色彩語意、字體、音效或版本能力。

目前 `src/ui/skin-import-panel.js` 的人工映射只有 `background`、`characterOverlay`、`selectionFrame` 三個角色；`src/persistence/skin-theme-store.js` 的 schema 也只有這三個角色。這足以證明「能讀 OSK」與「正式 UI 可完整換 Skin」是兩個不同階段。

現有 `characterOverlay` 候選篩選使用檔名猜測角色，不能當作可靠的通用自動映射；不能因為某張圖是 PNG/JPG 就預設它是角色立繪。素材管理 UI 應顯示建議角色、可信度／依據、預覽與手動覆寫，並允許不套用。

## 6. 建議落地順序

1. 建立版本化 stable asset manifest：官方檔名、用途、版本、動畫命名、尺寸提示、是否延展／tint、是否有可靠的 AMQ 對應。
2. 建立 AMQ role manifest：每個正式 UI 槽位、可接受素材類型、映射策略、fallback、頁面使用位置與預覽。
3. 擴充 importer：完整列出圖片、音效、`skin.ini`、未知項目；不丟棄原始檔案或未知設定。
4. 建立 Skin Preview／Mapping Studio：按「主選單、選曲、猜歌、結算、設定、學習中心」預覽角色；每個槽位能找到、替換、還原預設、保存與匯出。
5. 依 manifest 重建正式 UI 元件和頁面。先做首頁與選歌頁，再做猜歌、學習中心、設定。
6. 加入 contract tests：每個頁面使用的 skin role 必須存在或有明確 fallback；不允許頁面直接引用任意 OSK 檔案路徑；保存／恢復／匯入匯出角色 mapping 穩定。
7. 使用真實 `.osk` 驗收。測試樣本要包含有 `skin.ini`、缺少部分圖片、動畫序列、大小寫／子資料夾、不同 Skin version、透明 PNG 與音效的情況。測試環境若拿不到真實 OSK，明確標記阻塞，不得用自製 ZIP 冒充實機驗收。

## 7. 驗收定義

- 使用者可以在每個正式頁面的每個可換 Skin 槽位找到對應角色；名稱和預覽能說明會影響哪個元件。
- 匯入 OSK 後自動映射合理、可解釋，未知／歧義素材進入待確認區，不要求使用者從幾百張圖中自行猜用途。
- 使用者可以替換、清除、還原預設、保存、重載恢復與匯出 mapping。
- 所有頁面使用同一個 Skin runtime／token／元件契約；不允許首頁、選歌、猜歌各自造一套主題機制。
- AMQ 專屬元件有明確 extension slot；沒有 stable 對應的地方顯示清楚 fallback，不偽稱是原生 OSK 元件。
- 保留單一 AudioService、Catalog、QuizSession 與持久化責任；Skin 僅負責呈現，不接管遊戲狀態。
- 不因套用 Skin 而破壞文字可讀性、互動焦點、窄螢幕布局或遊戲資訊辨識。

## 8. 尚未完成

本文件是規格盤點與架構契約，尚未實作新的 manifest、完整 importer、mapping studio 或正式 UI 重建。既有 12/12 OSK harness 只證明現有匯入面板的有限測試通過，不代表上述功能已驗收。需要後續批次實作與真實 OSK／瀏覽器驗收。
