# AMQ Batch154 交接：Catalog Skin 選取框素材渲染與回歸

## 本批變更
- `src/styles.css`：修正 selectionFrame 的渲染方式。舊規則將 `border-image` 套在 `<tr>`，瀏覽器對 table-row 的 border-image 呈現並不可靠；現在將 osu! selection-bar 素材作為選取列背景紋理，跨整列縮放並加上低強度遮罩，保持文字可讀性。只有 `#catalog-browser` 內且主題已設定 frame 的選取列受影響。
- `tests/skin-theme-adapter.test.cjs`：新增 CSS 契約測試，確認選取列使用背景紋理、cell 背景透明，且不再使用 table-row border-image。
- `artifacts/batch154-regression/`：記錄 Node 測試分組執行輸出；首次分組 runner 因工具 120 秒執行上限中斷於第 8 組，已將最後 10 個測試檔分成兩組重新執行並成功完成，沒有把中斷的 runner 當成通過。

## 開工確認
- 已讀取 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH153.md` 與 `docs/NEXT_SESSION_PROMPT.md`。
- 工作副本：`/mnt/data/amq_batch153_work`。該目錄無 `.git` metadata；`git status`／`git log` 回報不是 Git repository，未初始化 Git。
- Candidate302、Candidate382 Stage 0 與 `src/data/assets/data.js`／`emq-data.js` 未修改。

## 驗證證據
- `node --check src/skins/theme-adapter.js src/skins/theme-transfer.js src/ui/skin-import-panel.js tests/skin-theme-adapter.test.cjs`：PASS（各檔案分別執行）。
- `node --test tests/skin-theme-adapter.test.cjs tests/skin-theme-store.test.cjs tests/skin-theme-transfer.test.cjs tests/osk-importer.test.cjs`：16/16 top-level tests PASS；OSK importer 內部案例 10/10 PASS。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- `node tools/check-architecture.cjs`：991 PASS／0 FAIL。
- Node 回歸：`tests/` 內 66 個 `*.test.cjs` 檔案已全數在成功的分組命令中執行。前 56 個檔案分成 7 組，每組 8 檔且 exit 0；最後 10 檔分成 5 檔＋5 檔重新執行，兩組均 exit 0。最後兩組詳細輸出可在交付包測試命令結果中取得；本批不宣稱單一 `node --test tests/*.test.cjs` 全包命令執行成功。
- 測試檔清單數量：66。沒有已知 Node test failure。

## 尚未完成／阻塞
- 真實 HTTP origin 的 IndexedDB save/reload/clear：Batch153 已記錄 Chromium `net::ERR_BLOCKED_BY_ADMINISTRATOR`；本批不重複同一條路徑，仍為 BLOCKED。
- 真實 `.osk` 相容性：尚未取得真實檔案；人工 ZIP fixture 不是實際 Skin 相容性證據。
- 完整 osu!stable Song Select 介面仍未整合；本批只修正現有 Catalog 選取列的 Skin frame 渲染，不宣稱完整 UI 改版完成。
- 沒有使用者視覺驗收；使用者目前無電腦，外觀只能由程式／自動化檢查驗證。

## 下一步
1. 先檢查 Skin adapter reset、Catalog state 與 theme persistence 的整合邊界，補上可由 Node 測試證明的 lifecycle／重複套用回歸。
2. 盤點正式 Catalog 是否有可用的作品封面 provider／快取責任，依舊版 ANN／VNDB linking 證據設計卡片 artwork adapter，不把外部圖片授權或 URL 可用性當成已驗證。
3. 完整 Song Select UI 應分層替換現有表格呈現，但保留搜尋、篩選、排序、分頁、鍵盤導覽與個人清單操作；獨立原型不直接覆蓋正式頁面。
4. 真實 `.osk` 與 HTTP origin 阻塞解除後補做驗收。
