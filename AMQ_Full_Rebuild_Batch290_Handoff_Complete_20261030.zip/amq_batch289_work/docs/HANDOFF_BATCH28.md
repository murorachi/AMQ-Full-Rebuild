# Batch 28 交接：歌曲／作品黑名單整合

## 已完成
- 根據 `AMQ382(1).html` 核對 `aniBlacklistedSongs_v1`、`aniBlacklistedAnime_v1`、`ani-blacklist-changed-v51`。
- `src/persistence/blacklist-store.js` 管理兩種 ID set，保留 legacy 同頁事件與跨頁 storage event；兩個 scope 有各自 recovery／write-block。
- Quiz panel 支援歌曲／作品黑名單切換；一般 AMQ 抽題與 SRS due queue 都排除歌曲及作品黑名單。
- 測試：blacklist store 9/9、quiz panel integration PASS、架構檢查 400/0。

## 限制
- Legacy blacklist IDs 沒有 source，所以不套用到 EMQ。
- EMQ SRS 需要獨立 source-aware schedule；真實瀏覽器 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。

## 下一步
1. 實作 EMQ source-aware SRS schedule，保留 AMQ legacy key 不覆蓋。
2. 瀏覽器環境恢復後驗收真實音訊、跨頁儲存及黑名單 UI。
