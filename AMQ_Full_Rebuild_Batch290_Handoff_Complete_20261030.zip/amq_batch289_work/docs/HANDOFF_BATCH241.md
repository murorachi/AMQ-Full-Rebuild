# Batch241 Handoff：可測試的 Skin Pixel Contracts

## 基準與安全
- 唯讀來源：`/mnt/data/AMQ_Full_Rebuild_Batch240_Skin_Renderer_State_Pairs_20261029.zip`
- Batch240 ZIP SHA-256：`61ea9a3cf8841a1ae50925bdad17876f6bd487508f4190e3af57dcd4d0792ea7`
- 獨立工作副本：`/mnt/data/amq_batch241_work`
- 工作目錄沒有 Git repository；沒有初始化 `.git`，沒有覆蓋 Batch240 ZIP。
- AMQ／EMQ 原始資料未修改：`data.js` SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 本批實作
- 新增 `src/skins/skin-blend.js`：`multiplyRgba()`／`multiplyRgbaBuffer()`，對 RGB 執行明確的乘色公式，保留來源 alpha，拒絕無效 buffer 幾何。
- 新增 `src/skins/skin-edge-repeat.js`：`extendRightEdgeRgba()`，呼叫者明確指定右側重複像素寬度；輸出可測試 RGBA buffer，無效尺寸 fail closed。
- `src/index.html` 將兩個 helper 放在 `skin-renderer.js` 之前；renderer 暴露 `multiplyTintRgba`、`multiplyTintRgbaBuffer`、`extendRightEdgeRgba` 與版本化 capability names。
- `nativeStableFidelity.multiplicativeTint` 和 `songselectTopEdgeRepeat` 明確維持 `false`。目前只完成通用像素契約，不宣稱完整 osu!stable blend/compositor 或 `songselect-top` 精確演算法。
- 新增 `tests/skin-blend.test.cjs`、`tests/skin-edge-repeat.test.cjs`，更新 `tests/skin-renderer.test.cjs` 與 `tests/skin-contract-manifest.test.cjs`；合計 41 個 focused Skin／renderer 測試 PASS。
- 更新 `docs/SKIN_FRAMEWORK_CONTRACT.md` 與 `docs/AMQ_VISUAL_NEEDS_TRACEABILITY_BATCH240.md`，清楚區分 AMQ pixel primitive 與 native stable fidelity。

## 驗證結果
- 全部 `tests/*.test.cjs` 逐檔執行：**88/88 檔案成功，253 個測試案例，0 failures**。每檔 log 在 `artifacts/batch241-regression/node-tests/`，摘要在 `node-suite-summary.txt`。
- Focused Skin／renderer：**41/41 PASS**。
- Chromium Mapping Studio：**30/30 PASS**。
- Chromium Home/Catalog：**19/19 PASS**。
- Chromium Quiz/Results：**19/19 PASS**。
- Formal app-shell Chromium：**150/150 PASS**。
- Architecture Checker：**1,256 PASS／0 FAIL**。
- JavaScript／CJS syntax：**180/180 PASS**；Python browser harness `py_compile`：**5/5 PASS**。
- AMQ／EMQ 原始資產 hash 與 Batch240 一致。

## 阻塞與未完成
- `tests/app-shell.http-origin.test.py` 本批重試仍回報 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR`。真實 HTTP-origin IndexedDB theme save/reload assertions 沒有執行；證據在 `artifacts/batch241-regression/http-origin-blocker.txt`。
- 新增的 multiply／edge-repeat 是純 RGBA contracts，尚未整合成圖片解碼、canvas/compositor 或 `songselect-top` 完整版本／解析度感知渲染流程。不得宣稱原生 stable fidelity 已完成。
- `app.navigation.options`、`settings.entry`、`catalog.action.random`、`catalog.filter.background`、`catalog.song-artwork`、correct/incorrect feedback 與 result grade 等角色仍 unsupported，因為缺乏完整且核實的語義 DOM target／CSS consumer。
- Live catalog/artwork/audio、真實使用者裝置與 Candidate302／Candidate382 Stage 0 相容性仍未驗收；原始基準檔缺席。

## 下一批 Batch242
1. 若環境有可達且允許的非 loopback HTTP origin，先用它驗收 schema v4 `roleStateMappings` IndexedDB save/reload；若無，保留阻塞，不以 opaque origin 冒充。
2. 為 multiply／edge-repeat 增加 image decode／canvas integration seam 與 geometry-aware browser test，但 native support 仍需以官方規則及可授權 fixture 驗證。
3. 對剩餘視覺角色逐項核實 DOM、CSS token consumer、state、geometry 與 fallback；只有全項成立才加入 runtime adapter。
4. 保護 Batch240／241 測試與 QuizSession、AudioService、結果 persisted gate；更新同一份 checklist/status/handoff/prompt、manifest 與完整 ZIP。
