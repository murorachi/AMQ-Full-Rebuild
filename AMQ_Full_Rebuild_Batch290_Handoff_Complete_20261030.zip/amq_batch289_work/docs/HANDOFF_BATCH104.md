# Batch 104 交接包

日期：2026-10-27

## 本批成果
- 新增 `getSnapshot(sinceRevision)` future revision regression：client 宣稱的 revision 大於 server revision 時，回傳完整目前 snapshot，revision 保持 server 現值。
- 新增 closed room snapshot regression：保留 membership 的玩家可取得 closed room snapshot，也可用相同 revision 得到 `unchanged: true`。
- 新增空 closed room regression：最後玩家離開後，可信 state-machine caller 仍可讀取空 room snapshot 並使用 revision polling。
- 本批只有測試與文件變更，production code 未修改；未發現需要修改 state-machine production code 的缺陷。

## 修改檔案
- `tests/multiplayer-room-state-machine.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `docs/HANDOFF_BATCH104.md`
- `MANIFEST.sha256`

## 驗證證據
- `node tests/multiplayer-room-state-machine.test.cjs`：PASS。
- 非-tooling `tests/*.test.cjs`：44/44 個腳本逐檔 exit 0，日誌 `/mnt/data/amq_batch104_validation.log`。
- `node --test tests/tooling.test.cjs`：9/9 PASS。
- `node tools/check-architecture.cjs`：719 passed／0 failed。
- JavaScript／CJS syntax：100/100 PASS。
- Source audit／mapper PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；Catalog 55,660 records；cross-source ID collisions 0。
- 5 次 Catalog benchmark PASS；本機 Node build 約 1,299.491 ms，非瀏覽器效能保證。
- 來源資產 hash unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 下一步與阻塞
- 調查離房後重連的 transport/session authorization；目前沒有正式 transport/auth provider，因此不能聲稱已驗收。
- durable idempotency、跨節點 state／serialization、reconnect、多 client E2E 尚未實作。
- 多人 SRS persistence 需產品決策；真實瀏覽器／音訊／storage 未驗收。
