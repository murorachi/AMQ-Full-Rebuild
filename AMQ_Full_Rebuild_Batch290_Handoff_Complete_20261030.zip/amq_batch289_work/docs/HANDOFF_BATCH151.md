# AMQ Batch151 交接：OSK Theme Adapter（2026-10-28）

## 目標與結果
在 Batch150 已有的 IndexedDB Theme schema 上，將 Skin 套用責任從 `src/ui/skin-import-panel.js` 抽離成正式的 `src/skins/theme-adapter.js`。Adapter 將主題 role mapping 轉換成 AMQ 的 CSS custom properties、角色裝飾與選取框樣式，不管理 QuizSession、曲庫或音訊狀態。

## 修改檔案
- `src/skins/theme-adapter.js`（新增）：集中處理 background／selectionFrame／characterOverlay、accent color、物件 URL 生命週期、圖片解碼失敗 fallback、停用主題與 reduced-motion 偏好。
- `src/ui/skin-import-panel.js`：改由 Theme Adapter 套用與重設；保存失敗訊息不再掩蓋素材是否實際套用。
- `src/index.html`、`tests/tests.html`：加入 Adapter 並維持載入順序。
- `src/styles.css`：使用 Skin accent 作為 focus/selection 提示色；reduced-motion 下移除角色動畫／轉場。
- `tools/check-architecture.cjs`：檢查 Adapter 載入順序及 UI 委派責任。
- `tests/skin-theme-adapter.test.cjs`（新增）：5 個 adapter 測試。
- `tests/osk-import-panel.browser.test.py`：載入正式 Adapter、使用有效 PNG fixture，等待實際套用結果再斷言。
- `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`：更新進度與交接。

## 驗證證據
- `node --test tests/skin-theme-adapter.test.cjs tests/skin-theme-store.test.cjs tests/osk-importer.test.cjs tests/app-lifecycle.integration.test.cjs`：11/11 top-level test files/subtests passed，0 fail。Adapter 5 項、Theme store 4 項、Importer 10 項及 app lifecycle integration 均通過；TAP 的總計是 11 個 top-level tests，importer/store 自有摘要另列各自案例數。
- `python tests/osk-import-panel.browser.test.py`：9/9 assertions PASS。這仍使用 `page.set_content()` opaque origin；驗證的是匯入面板與 Adapter 套用／重設，不是 IndexedDB 持久化。
- `node --check src/skins/theme-adapter.js`、`src/ui/skin-import-panel.js`、`tools/check-architecture.cjs`：PASS。
- `node tools/check-architecture.cjs`：977 PASS／0 FAIL。

## 尚未驗證／阻塞
- IndexedDB 真實瀏覽器 save/reload/clear：仍需非 opaque origin；現有 browser test 故意只驗證 UI fallback 與 adapter，不能當持久化驗收。
- 真實 `.osk` 相容性：GitHub DNS 先前不可解析，仍只有人工 ZIP fixture。
- 正式 AMQ 的完整 Song Select 尚未由獨立原型接管。Adapter 目前提供正式背景、選取框架、角色與 accent 接口，但不能宣稱已完成整個 osu!stable 選曲版面重構。
- 先前 64 個 Node 測試檔分組全通過；本批新增第 65 個 `*.test.cjs`，目前受影響的 Skin／lifecycle 測試已跑，其他 64 個未因本批變更而全部重跑。
- 工作目錄無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0、AMQ／EMQ source assets 未修改。

## 下一批優先順序
1. 檢查並改善 importer 的 `skin.ini` 文字編碼處理（UTF-8 BOM／UTF-16 BOM／Windows-1252 fallback），以 fixture 測試，不依賴真實 Skin。
2. 將 osu! skin 常見選曲素材的 mapping 規則整理成可測試的 asset-role catalog，避免 UI 用 filename regex 重複定義規則。
3. 研究主題設定匯出／匯入格式與資產來源提醒；匯出採使用者明確操作，不上傳素材。
4. 有可用 HTTP origin 時再做真實 IndexedDB reload 驗收；網路可用時再測真實 `.osk`。
5. 受影響測試、架構檢查、文件與 ZIP 交付。
