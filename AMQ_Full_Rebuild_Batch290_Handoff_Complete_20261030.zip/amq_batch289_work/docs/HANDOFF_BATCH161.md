# Batch161 Handoff：正式 Catalog 選取資訊面板第一階段

## 已完成
- 正式 Catalog 現在明確分成歌曲列表與右側選取資訊區；小螢幕改為上下堆疊。
- 選取資訊顯示歌曲標題、作品、歌手、歌曲類型、年份與來源。
- 詳情面板使用既有 Artwork Adapter 顯示封面與來源 attribution；generation guard 防止舊封面結果覆寫目前選取項目。
- 未搬入 prototype mock data，未重寫 query-index／personal-library 狀態，也未移除原有列表或 Skin selection frame。

## 修改檔案
- `src/index.html`
- `src/ui/catalog-browser.js`
- `src/styles.css`
- `tests/catalog-browser.integration.test.cjs`
- `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH161.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`

## 驗證
- `node --check src/ui/catalog-browser.js`：PASS。
- Catalog／ANN／provider targeted tests：15/15 PASS。
- App lifecycle + Catalog + artwork integration：22/22 PASS。
- `node tools/check-architecture.cjs`：1037 PASS／0 FAIL。
- Fake DOM integration 已驗證選取資訊更新與封面區存在；真實 Chromium viewport screenshot／焦點順序尚未驗收。

## 已知限制
- 這是正式 Song Select 的第一個結構切片，不是完整 osu!stable UI 完成。
- 真實 ANN API／CORS／圖片載入、真實 `.osk`、非 opaque HTTP-origin IndexedDB 仍待可用環境驗證。

## Batch162 直接執行
1. 讀取 `prototype/ui-v2-osu-select-batch146/` 的已認可選曲版面及 CSS，盤點正式 Catalog 目前控制項。
2. 進行下一個正式 UI 切片：將過多的篩選控制整理成主搜尋／常用篩選與可展開進階篩選，保持現有 DOM IDs／controller filter contract 或一次性同步更新所有依賴。
3. 不移除排序、分頁、看番狀態、熟悉度、個人清單及學習狀態。
4. 加入 filter integration tests、responsive contract tests 與 architecture checks。
5. 真實 Chromium 不能啟動時，不得假裝完成 screenshot 驗收；先完成不依賴瀏覽器的實作與測試。
