# Batch219 交接：多人命令錯誤保持與重試恢復

日期：2026-10-29
工作副本：`/mnt/data/amq_batch216_work/project`
來源交付：`AMQ_Full_Rebuild_Batch218_ResultRestore_BusyLifecycle_UI_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch219_MultiplayerCommandErrorRecovery_20261029.zip`

## Production fix

- `src/ui/multiplayer-panel.js` 原本在 command failure catch 中呼叫 `setError(...)`，但 `finally` 的 `render(session.getState())` 看到 connected snapshot 後會立即 `setError("")`，導致 server rejection 提示閃失。現在用 `commandError` 明確管理 command lifecycle。
- 開始新操作時清除上一個 command error；失敗時保留 error message／code；connected snapshot rerender 不會覆蓋；成功 retry 清除錯誤。若 session 真的 offline，offline alert 仍優先顯示；network command error 可在 offline→connected recovery 後清理。
- Room phase／player ready／revision 仍只由 server snapshot 決定，沒有建立第二個 state owner。

## Tests

- `tests/multiplayer-panel.integration.test.cjs` 注入 HTTP 409 `ROOM_COMMAND_REJECTED`，確認錯誤在 connected rerender 後仍可見、`aria-busy=false`、重試成功後錯誤清除且 ready state 由 server snapshot 更新。
- `tests/catalog-browser.integration.test.cjs`：pagination focus fallback、filter focus restore PASS。
- `tests/quiz-panel.test.cjs`：fresh-mount restore completed result，且只顯示 matching roundId rows。
- `tests/quiz-history-store.test.cjs`：completion marker persistence／round isolation PASS。
- 全量 Node 77/77、Chromium shell 92/92、Architecture 1,137/0、172 JS/CJS syntax、3 Python `py_compile` PASS。

## 限制

- HTTP-origin test 未重跑：Chromium loopback `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變。真實 save/reload 未驗收。
- 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；全球排行榜無可信 backend owner，不造 PP／排名／PB。
- 工作副本無 `.git`，未初始化；正式基準原始檔缺席，不宣稱相容。UI 主線未結案。

## 下一批優先

1. Catalog AMQ／EMQ／MIX mode switch 與 loading／failed／empty／filtered-empty 的焦點／選取整合回歸。
2. Multiplayer offline→connected 的 command error／busy recovery，確認可重試。
3. 若修改 production source，跑完整 Node suite、Chromium、architecture、syntax。
