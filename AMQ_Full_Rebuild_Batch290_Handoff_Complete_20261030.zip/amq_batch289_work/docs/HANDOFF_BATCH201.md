# Batch201 交接：正式 UI 答題舞台、學習中心、設定頁與 OSK 接線

日期：2026-10-28

## 使用者目標
使用者明確要求先把整套 UI 完工。這是持續目標，不得因一輪 CSS／測試通過就宣布 UI 結案。後續批次仍以正式 UI 與可用元件角色為優先，不可退回大量底層盤點。

## 本批實作
- `src/styles/ui-shell.css`
  - 猜歌頁重排既有元件視覺：四格回合資訊、設定控制區、答題舞台、輸入／提交區、操作列、答案揭曉、歷史紀錄及 SRS；未改變 QuizSession、store 或 AudioService owner。
  - 學習中心七項真實統計使用四欄桌面摘要卡，手機單欄；不產生假統計。
  - 設定頁工作區偏好／統計排序採雙欄，快捷鍵桌面三欄、手機單欄；帳號、備份、曲庫更新與 OSK 匯入區維持可見且可操作。
  - 修正工作區／OSK status 沿用舊版白色提示底色。
  - 為額外 OSK 角色接入實際 CSS consumers：返回按鈕、倒數、錯誤／警告提示、自由播放隨機操作、播放器進度滑塊、多人玩家區、設定下拉與 header 環境視覺。
- `src/skins/theme-adapter.js`：正式 runtime role 由 21 擴展到 30。新增角色必須有真實 DOM selector；未存在的結果頁、作品封面等角色仍不冒充 supported。
- `docs/skin-contract/amq-skin-role-manifest.v1.json`：更新狀態文字，明示 30 個 runtime roles 與其餘未接線角色。
- `tests/app-shell.browser.test.py`：正式 HTML fixture 的 UI 驗收由 37 擴展到 50 項，檢查頁面層級、手機版重排、runtime selector 與 CSS token consumer。

## 驗證證據
- Chromium formal app-shell：50/50 PASS，`artifacts/batch201-regression/app-shell.browser.log`。
- Focused Node tests：9 個測試檔，38/38 PASS，`artifacts/batch201-regression/focused-tests.log`。
- Architecture Checker：1,123 PASS／0 FAIL，`artifacts/batch201-regression/architecture.log`。
- `src/` 與 `tests/` JavaScript／CJS 語法檢查通過，`artifacts/batch201-regression/syntax-check.log` 為空。
- 截圖：`home-desktop.png`、`home-mobile.png`、`catalog-desktop.png`、`catalog-mobile.png`、`quiz-desktop.png`、`quiz-mobile.png`、`learning-desktop.png`、`learning-mobile.png`、`settings-desktop.png`、`settings-mobile.png`，位於 `artifacts/batch201-regression/`。

## 明確未完成／阻塞
- UI **尚未結案**。47 個契約角色中只有 30 個有 runtime selector／CSS consumer；其他角色需要先確認實際 UI target，尤其結果頁／答對答錯回饋／學習歷史項目／設定對話框與滑桿等。
- 真實曲庫載入、作品封面、可聽音訊、HTTP-origin IndexedDB 與真實 `.osk` 匯入／套用／匯出／重載尚未驗收。inline `set_content()` 為 opaque origin，IndexedDB 被環境拒絕；localhost Chromium 導覽曾回 `ERR_BLOCKED_BY_ADMINISTRATOR`。
- 截圖內 `DATA_SOURCE_READ_FAILED`、多人 API 連線錯誤及 IndexedDB denied 是本次測試環境的真實狀態，不可當成正式資料流程通過。
- 完整 Node suite 未跑；本批只宣告 9 個 focused files 通過。
- 無 `.git`，未初始化；Candidate302／Candidate382 Stage 0 原始基準檔仍缺席，沒有修改 AMQ／EMQ 曲庫資料。

## Batch202 下一步
1. 盤點 47-role manifest 與正式 UI：對每個未支援角色確認是否存在語義正確的現有元件；存在才接 selector、CSS consumer、fallback/reset 與測試，不為了數字硬接。
2. 完成 Catalog 選取鍵盤互動（方向鍵／Enter／checkbox／篩選後清空）及 Mapping Studio reset／import-export／reload 的可執行 fixture 回歸。
3. 改善 OSK Mapping Studio 的角色卡資訊層級與預覽區；清楚區分 runtime-supported、保存但未接線、授權／檔案限制。
4. 再逐頁審視首頁、選歌、猜歌、學習中心、設定的窄螢幕與 focus／hover／disabled／error 狀態；不把 UI 工作轉成純測試。
5. 若瀏覽器環境未變，只記錄 HTTP-origin 阻塞，不反覆重試；繼續其餘可做工作。
6. 更新同一份工作清單與交接文件，重新產生 manifest／ZIP；不宣稱全套 UI 已完成。
