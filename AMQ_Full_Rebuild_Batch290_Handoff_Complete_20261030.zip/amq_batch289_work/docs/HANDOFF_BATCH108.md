# Batch108 交接包：密碼下限與曲庫來源可發現性

日期：2026-10-28

## 本批決策與成果

1. 一般帳號密碼最短長度由 12 降為 8 個字元，最大仍為 128。
2. 首次管理者初始化與一般註冊 UI 同步使用 `minlength="8"`；登入欄位沒有 `minlength`，不會因新政策阻擋既有帳號。
3. scrypt 雜湊參數、session cookie、安全邊界及登入／註冊速率限制沒有降低。
4. 密碼整合測試證明 7 字元拒絕、8 字元接受。
5. 曲庫更新面板新增 AMQ、EMQ 上游服務參考與 EMQ 上游 GitHub 專案連結，並說明目前內建曲庫為隨版本附帶的唯讀快照。

## 一鍵曲庫更新：目前狀態與阻塞

**尚未實作。** 已知上游網站／程式碼不等於可直接下載並安全套用的 AMQ＋EMQ 完整資料包。目前沒有經確認的固定 bundle URL、版本 manifest 或發布流程。任意下載會帶來供應鏈風險，且可能因上游 schema 變更而破壞曲庫。

解除條件：
- 定義 AMQ＋EMQ bundle 產生方式與公開託管位置。
- 定義版本 manifest、格式版本、bundle URL 與 SHA-256；若需要抵禦託管端被竄改，應採簽章並明確管理公鑰。
- 下載後仍使用既有 schema／記錄／作品關聯／checksum 預檢，顯示差異，經確認後透過 IndexedDB 原子套用。
- 失敗時保留現有曲庫；沒有相容性證據時拒絕更新。

在上述前置條件成立前，UI 保留手動匯入、完整預檢、差異預覽、原子套用與恢復內建曲庫功能，不顯示虛假的「已可一鍵更新」。

## 變更檔案

- `server/account-service.cjs`
- `src/index.html`
- `tests/server-auth-srs.integration.test.cjs`
- `tests/account-panel.integration.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/PRIVATE_SERVER.md`
- `AI_START_HERE.md`
- `README_FIRST.md`
- `docs/HANDOFF_BATCH108.md`

## 驗證結果

- 非-tooling test scripts：49/49 PASS（逐檔執行；整體 loop 在最後 tooling 檔前觸及執行時間上限，49 個非-tooling 腳本均已有成功退出結果）。
- Tooling：`node --test tests/tooling.test.cjs`，9/9 PASS。
- Architecture：769 passed／0 failed。
- 全量 JS/CJS syntax：PASS。
- Source audit：PASS。
- Source mapper：PASS；AMQ 38,821 songs／9,516 works，EMQ 16,839 songs／6,645 works，Catalog 55,660。
- 5-run benchmark：PASS（僅 Node 記憶體內觀測值）。
- ZIP：`AMQ_Full_Rebuild_Batch108_Handoff_20261028.zip`；最終封包大小與 SHA-256 以交付回覆及實際檔案為準。
- Manifest：248 個檔案項目；ZIP CRC PASS；解壓後缺檔 0、hash mismatch 0。
- 真實瀏覽器表單、Google OAuth、曲庫一鍵更新 E2E：未驗證。

## 基準保護

- `src/data/assets/data.js` SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`
- `src/data/assets/emq-data.js` SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`
- 未修改 Candidate302／Candidate382 Stage 0 基準，未初始化 Git，未推送或覆蓋任何正式基準。

## 下一批建議

優先定義可公開託管的 AMQ＋EMQ 更新 bundle／manifest 發布契約，再實作一鍵檢查、下載、預檢、差異預覽與安全套用。不要先把任意上游網站當作直接資料 API。UI／CSS 大重構仍留到最後。
