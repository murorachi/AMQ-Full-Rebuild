# Batch181 交接：Playback Coordinator reentrant revoke bug

## 缺陷與修正
- 原 `acquire()` 先 `revokeCurrent()`；撤銷回呼同步重入 `acquire()` 可安裝內層 lease，外層接著覆寫 `current`。內層 lease 被靜默取代，沒有 revoke callback，可能讓 owner 誤以為仍持有播放權。
- `src/audio/playback-coordinator.js` 新增 `revoking` guard，撤銷回呼期間重入 acquisition 明確以 `PLAYBACK_COORDINATOR_REVOKING` 拒絕。`dispose()` 先標記 disposed 再撤銷，避免 dispose callback 建立幽靈 lease。
- 修正前測試失敗證據：`artifacts/batch181-regression/playback-coordinator-before-fix.log`。修正後 Playback Coordinator 7/7 PASS。

## 驗證
- QuizSession 25/25；全部 71 個 Node test files exit 0。
- Database Update Runtime Integration 3 scenarios；Database Update 8 scenarios。Backup/restore 11/11、panel 8/8、SRS 20/20、Remote SRS 12/12、History Store 21/21、AudioService 22 scenarios。
- Architecture 1,051/0；OSK 12/12；160 syntax checks PASS。完整證據在 `artifacts/batch181-regression/`。
- Batch177–180 的 handoff 與證據分開保留。AMQ／EMQ 資產與熟悉度規則未修改。

## 未驗收
真實瀏覽器多分頁音訊、ANN API/CORS/封面、真實 OSK、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。Candidate302／Candidate382 Stage 0 原始檔缺席，無 `.git`，未初始化。

## Batch182 下一步
1. 讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、本 handoff 與 `docs/NEXT_SESSION_PROMPT.md`。
2. 檢查 QuizSession `revokePlaybackLease()` 觸發 `engine.endRound()` 時同步 listener 是否可重入 session API，並檢查 auto-next、late audio completion 與 persistence failure 的交錯。
3. 先建立修正前失敗的 regression，再只修 P0/P1。保留四級熟悉度、單一播放 owner、`playAttemptId`／`playbackEpoch`。
4. 全量 71 Node tests、architecture、OSK、160 syntax checks，更新清單與 handoff，交付 ZIP／SHA-256。
