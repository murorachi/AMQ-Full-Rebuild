# 新版架構草案

## 原則
這是可調整的架構起點，不是要求盲目照抄。任何調整都必須有明確理由並更新本文件。

## 建議責任分層
- `app`：初始化、生命週期、組裝模組。
- `core`：共用型別、狀態契約、事件契約、錯誤型別。
- `data`：資料來源、正規化、驗證、索引、查詢。
- `engine`：AMQ/EMQ/MIX 規則與題目狀態。
- `audio`：播放、候選音源、重試、逾時、取消、錯誤。
- `features`：搜尋、篩選、選取、歷史、設定等功能。
- `ui`：畫面呈現與互動，不直接掌管遊戲核心狀態。
- `persistence`：本機設定、收藏、歷史及資料遷移。
- `adapters`：瀏覽器 API、網路、外部服務、多人體驗。
- `tests`：單元、整合、回歸及瀏覽器驗收。

## 依賴規則
1. UI 呼叫功能介面，不直接修改核心狀態。
2. 核心規則不得依賴 DOM。
3. 資料來源經由 Adapter/Repository 轉成內部資料契約。
4. 音訊模組不負責改寫遊戲模式或搜尋狀態。
5. 功能模組不可互相任意存取內部變數。
6. 計時器、事件監聽、網路請求與 Observer 必須有明確生命週期與清理方法。
7. 狀態只能有一個權威來源；UI 的顯示狀態是衍生資料，不是第二套真相。
8. 外部服務失敗不能讓整個應用程式無法啟動。
9. 共享邏輯應明確抽出；只有相似外觀但不同規則的功能不必硬合併。
10. 任何新增依賴都要記錄必要性、風險與替代方案。

## 初始技術策略
目前骨架採用原生 HTML/CSS/JavaScript，避免 npm、框架、建置器成為開工阻塞。若程式規模與測試證據證明需要 TypeScript、打包工具或框架，再提出有證據的升級方案。不得只因流行就增加依賴。

## 建議的主要模組契約
- DataRepository：`load()`, `validate(records)`, `query(criteria)`。
- GameEngine：`start(config)`, `submitAnswer(answer)`, `nextQuestion()`, `reset()`。
- AudioService：`play(candidates, options)`, `stop()`, `cancel()`。
- SettingsStore：`get(key)`, `set(key, value)`, `migrate()`。
- EventBus（若確實需要）：`on(event, handler)`, `emit(event, payload)`, `dispose()`。
所有介面只是初稿，AI 必須在盤點功能後再確認並補上明確資料型別與錯誤語意。


## 第一批補充：資料真相與模組契約

- 曲庫契約集中於 `docs/DATA_CONTRACT.md`；來源欄位未確認前，所有歌曲欄位映射皆為待驗證，不得用猜測的 adapter 讀取真實資料。
- 功能靜態線索集中於 `docs/FUNCTION_INVENTORY.md`。HTML 中存在某段 UI 或函式不等於功能已通過驗收。
- `src/core/state.js` 僅是初始狀態 store，不是正式遊戲引擎。擴充狀態前需先定義狀態轉移與測試。
- `src/core/event-bus.js` 是可選工具；若模組間直接介面更清楚，優先使用直接介面，不為使用事件而使用事件。
- 目前沒有 Node 套件依賴；核心測試使用 Node 內建 `node:assert` 與 `node:vm`，不需要安裝套件。


## 第二批補充：生命週期責任

- `src/core/lifecycle.js` 提供可由模組持有的 scope：集中管理 event listener、timeout、interval、observer 與自訂清理函式。
- `dispose()` 以後進入終止狀態，重複呼叫不會重複清理；清理以後進先出執行。清理失敗會回傳錯誤陣列，呼叫方應記錄或處理，不應無聲丟棄。timeout／interval 的個別取消與 scope dispose 都會在回呼執行時再次檢查有效性；即使 host 已將 callback 排入事件佇列，已取消／已 dispose 的 callback 也不得執行使用者邏輯。
- `src/app.js` 透過 lifecycle scope 持有模式按鈕監聽與 state subscription，提供 `window.AMQApp.mount()` / `dispose()`，支援重掛載。`mount()` 的資源註冊採 rollback：若初始化中途拋出例外，已登記的監聽、runtime 與 store 會依 scope LIFO 清理，scope 及模組參照重設，原始例外仍向外拋出；後續呼叫可重新嘗試，不會被半初始化的 scope 擋住。模組在返回 handle 前自行建立、但未成功註冊的內部資源仍須由該模組自己保證失敗安全。
- 此模組是骨架基礎設施，並不代表舊版所有 observer/timer/listener 已被遷移或清理；舊版責任證據見 `docs/CANDIDATE382_STAGEI_STATIC_AUDIT.md`。


## 第三批補充：錯誤契約與歌曲記錄驗證

- `src/core/errors.js` 提供無 DOM 依賴的標準錯誤物件，欄位包含 `code`、`category`、`message`、`retryable`、`details` 與可選的安全化 `cause`。未知分類降級為 `unknown`；錯誤建立不會自動寫入 console。
- `src/data/validate.js` 僅驗證新版內部契約，不負責從 Candidate302 或舊版資料映射欄位。最低必填為非空字串/有限數字 `id` 與非空 `title`；可選欄位若出現則檢查型別。
- `validateRecords()` 回報 `loaded`、`partial`、`failed` 或 `empty`，並提供有效/拒絕數量及逐筆錯誤。重複 ID 以型別區分（數字 `1` 與字串 `"1"` 不視為相同），保留第一筆有效記錄，拒絕後續重複項。
- 驗證器保留輸入記錄本體，不做正規化或就地修改。以上是新版內部契約第一版；真實來源欄位、音源候選及 AMQ/EMQ/MIX 規則仍須在取得正式資料後對照修訂。


## 第四批補充：資料載入狀態控制

- `src/data/load-state.js` 負責協調資料驗證結果、共用 state store 與標準錯誤物件；不負責取得網路/檔案來源，也不假設舊版曲庫格式。
- 載入狀態為 `not-loaded`、`loading`、`loaded`、`partial`、`empty`、`failed`。狀態與輸入/有效/拒絕數量集中寫入 state store，UI 只讀取並呈現。
- `begin()` 回傳 generation token；非同步來源應將 token 帶給 `accept(records, token)`。若載入已被更新、重置或失敗流程取代，過期結果會被忽略。`fail(error, { generation })` 也必須傳入原 token，防止舊請求的失敗回報覆蓋新狀態；驗證器自身拋出例外時會轉成 `DATA_VALIDATION_FAILED`。
- `accept()` 只接收已取得的原始陣列並呼叫內部驗證器；資料部分成功時仍保留有效記錄並附 `DATA_PARTIAL` 錯誤，完全無效資料會標為 `failed`。空陣列是 `empty`，不等同載入錯誤。
- `fail()` 將來源例外轉成標準錯誤；`reset()` 使舊 token 失效並清除統計與錯誤。來源 adapter 尚未建立，故目前只完成狀態協調層。


## 第五批補充：資料來源 Adapter 邊界與模式選擇契約

- `src/data/source-adapter.js` 將來源讀取與欄位映射集中在單一注入介面：建立 adapter 時必須提供 `read({ signal })` 與 `mapRecord(raw, index)`。未提供 mapping 時直接拒絕建立，避免在缺少 `Data.js` / `EmqData.js` 時猜測舊版 schema。
- `src/data/source-registry.js` 將已建立的來源 adapter 與 AMQ／EMQ／MIX 模式的來源集合透過明確 `modeSources` 設定集中管理；目前 MIX 明確映射 AMQ + EMQ composite adapter，來源抽樣權重由 `quiz-session.js` 管理，不由 registry 推測。未配置的其他模式仍會明確報錯。
- `src/data/runtime-bootstrap.js` 提供單一 runtime 載入入口，從共享 state 讀取目前 mode，再呼叫 registry 建立 adapter 並交給唯一 Repository；模式改變時呼叫 `repository.invalidate()`，即使沒有活動請求也清除舊 Catalog／loaded 狀態。它不會自動重載，也不會推測未驗收的遊戲重置規則。
- `load({ signal })` 僅接受來源陣列，回傳映射後的 `records` 與 `sourceCount`。來源讀取、來源格式、映射、逾時及取消分別回報標準錯誤碼；逾時及呼叫方取消會透過 `AbortController` 通知來源停止工作。實際來源的 abort 支援程度仍由 adapter 的 `read` 實作決定。
- Adapter 不自行驗證新版內部歌曲契約，也不直接改寫共享 state；呼叫方應將 `records` 交給 `src/data/load-state.js` 的控制器，並傳遞同一輪 `begin()` 產生的 generation token。Adapter 測試只使用人工 fixture，不是舊版資料相容性證據。
- 目前模式選擇只驗證 AMQ、EMQ、MIX 三個合法狀態可由單一 state store 表示。模式切換時應清除哪些題目、計時器、答案或音訊狀態，仍須根據真實功能盤點定義；本批不自行猜測或實作引擎重置規則。
- `src/app.js` 的狀態呈現會在錯誤清除或狀態重設後清除過期錯誤訊息，避免畫面殘留舊錯誤。


## 第五批補充：Repository 組裝層

- `src/data/repository.js` 是來源 Adapter 與 `load-state` 控制器之間的組裝層：啟動載入、傳遞 generation token、將映射結果送進驗證、把來源錯誤送進共用狀態，並回傳可供呼叫方判斷的結果。
- 同一 Repository 開始新載入時，會 abort 舊請求；舊請求無論成功或失敗都不能覆蓋新狀態。`cancel()` 只取消目前載入；`invalidate()` 則用於模式／來源上下文改變，會取消進行中的載入並同步重設 catalog 與 `not-loaded` 狀態，即使當下沒有活動請求也會清除舊快照。若呼叫 `load({ signal })` 時 signal 已經 aborted，Repository 必須在呼叫注入 Adapter 前結束取消流程，避免 Adapter 在檢查 signal 前先執行副作用。若 invalidate 後立刻開始新一代載入，舊請求的遲到成功／失敗與 finally 清理不得清除新一代狀態或 active request。
- Repository 不持有第二份資料狀態，`snapshot()` 只讀取 `load-state` controller 的共享狀態。它也不負責提供舊版 mapping；來源 mapping 必須由取得並盤點真實資料後的組裝端注入。
- 本批已以 Node 測試驗證成功載入、來源錯誤、使用者取消、舊請求被新請求取代及依賴缺失。測試採人工 fixture，真實曲庫驗收仍為 BLOCKED。


## 第六批補充：依賴方向與來源資料稽核工具

- `tools/check-architecture.cjs` 是無外部套件的靜態防護工具，檢查 HTML script 載入順序與本地引用、重複 ID、inline／外部 JavaScript 語法、明確列出的過期 API、core/data/app 依賴方向及重複函式宣告。它不是完整 AST 分析器，也不保證能找出所有重複邏輯或動態依賴。
- `tools/audit-source-data.cjs` 讀取指定來源檔案，稽核 AMQ 固定列長、EMQ gzip JSON 結構、ID 唯一性、作品關聯與跨來源 ID 碰撞，輸出檔案雜湊與資料統計。它只讀取來源，不改寫來源。
- Library 目前可取得 `data.js` 與 `emq-data.js`，而 Candidate382 Stage I 參考 HTML 以同名 script 引用它們。由於 Candidate302 本體尚未取得，來源相容性仍待確認，不能將 Stage I 欄位映射直接套用為 Candidate302 已驗收契約。


## 第七批補充：有證據範圍的來源 Mapper（2026-10-27）

- `src/data/source-mappers.js` 提供明確的 AMQ 與 EMQ mapper。AMQ 映射依目前 Library `data.js` 的 7 欄作品列、12 欄歌曲列及 Candidate382 Stage I 讀取方式；EMQ 映射依目前 `emq-data.js` 的作品／歌曲物件欄位及 Stage I 的使用線索。
- mapper 僅輸出內部歌曲 metadata，不生成 `audioCandidates`。AMQ 的欄位 9–11 是被 Stage I 當成音訊／影片檔名處理，不是已確認的完整 URL；EMQ 的 `v` 即使包含 HTTPS 候選也尚未做 HTTP／播放驗證，因此不能直接標記為可播放。
- `sourceSchema` 標籤刻意帶出 schema 證據來源，避免誤把 Library／Stage I 資料映射視為 Candidate302 或 Stage 0 相容性驗收。
- `tools/verify-source-mappers.cjs` 對指定的真實來源全量映射，再呼叫新版內部驗證器；目前 AMQ 38,821／38,821 與 EMQ 16,839／16,839 筆通過。此結果只證明 mapper 對目前兩份來源可處理，不能證明基準版本配套關係、遊戲規則或音訊可用性。

## 第九批補充：可重建查詢索引（2026-10-27）

- `src/data/query-index.js` 接收已映射、已通過內部契約驗證的歌曲記錄，建立不可變快照與預先正規化的搜尋欄位；它是衍生索引，不是第二份權威資料。來源更新後應從最新有效記錄重建 catalog。
- `createCatalog(records)` 與 quiz pool 共用 `src/data/identity.js`，以 `source + ID 型別 + ID 值` 作為身份範圍，因此不同來源可以有相同 ID；同一來源內重複身份會明確拒絕。索引會複製並凍結記錄及 aliases 陣列，避免呼叫方改寫輸入後造成搜尋資料與索引不一致。
- `search(criteria)` 支援 `query`、`source`、`type`、`workKind`、`animeId`、`offset`、`limit`。可搜尋歌曲標題、歌手、作品標題、作品別名及歌曲 aliases；精確篩選條件以 AND 組合，陣列條件代表該欄位的 OR。結果依原始輸入順序穩定排列，`total` 是分頁前匹配總數。
- 搜尋正規化僅作用於索引副本：Unicode NFKC、`toLocaleLowerCase('und')`、連續空白合併與首尾空白移除；不改寫顯示文字。搜尋是預先正規化字串的子字串比對，不宣稱語意搜尋、拼音搜尋或模糊容錯。
- 未知條件、無效篩選、錯誤 offset/limit 會拋出明確例外，不靜默忽略。`limit` 預設 100，允許 0 到 10000；`offset` 預設 0。
- `tools/verify-source-mappers.cjs` 已增加真實資料 catalog 建置與 AMQ/EMQ 各一筆搜尋探針；這只證明目前 Library 來源可經現有 mapping 建立與查詢，不證明 Candidate302 配套、瀏覽器 UI 或音訊可用性。


## 第十批補充：可重複的 catalog 效能量測

- `tools/benchmark-catalog.cjs` 以指定的 Library AMQ／EMQ 來源，經目前有證據的 mapper、內部驗證器與 `queryIndex.createCatalog()` 建立 catalog，量測 catalog 建置時間及 6 類查詢案例。
- 查詢每個案例先暖身一次，再依使用者指定的 5–500 次迭代計算 min/P50/P95/max/mean；預設 30 次。輸出包含 runtime、資料筆數、來源／歌曲類型／作品類型分布與每種查詢的匹配筆數。
- 此工具只作可重複比較的觀察性基線，不設定未經產品需求支持的效能門檻。Catalog 建置時間不含讀檔、解壓縮、mapping 與驗證；查詢時間不含 DOM 渲染；不代表瀏覽器效能。
- 第十批實測結果見 `docs/CATALOG_BENCHMARK_20261027.md` 與 `.json`。來源配套與 Candidate302 相容性仍未確認。


## 第十一批補充：查詢排序與穩定性

- 查詢層支援明確的 `sortBy`／`sortDirection`，可用欄位與缺值規則集中於 `src/data/query-index.js`，不由 UI 自行實作第二套排序。
- 篩選先執行，接著可選排序，最後分頁。未提供 `sortBy` 時保留原始輸入順序；排序同值以原始 ordinal 作穩定 tie-breaker。
- 缺失值固定在最後，與 asc/desc 無關；無效排序參數明確報錯。這是新版內部 API，不是對舊版排序偏好或 UI 選項的推斷。
- 回歸測試位於 `tests/query-index.test.cjs`，瀏覽器自我測試頁也增加排序案例；但該頁因目前環境 `ERR_BLOCKED_BY_ADMINISTRATOR` 尚未能真實執行。


## 第十二批補充：可重用的曲庫分組統計與組合查詢

- `queryIndex.groupBy(field, criteria)` 提供共用篩選計數，不讓各 UI 控制項自行掃描曲庫或重複維護計數。允許欄位為 `source`、`type`、`workKind`、`animeId`、`animeTitle`、`artist`。
- `groupBy` 使用與 `search` 相同的 query/source/type/workKind/animeId 篩選邏輯，回傳 `{ total, groups }`；total 是篩選後總筆數，groups 不受搜尋分頁限制。缺少分組值的記錄不產生 group，但仍計入 total。
- 群組依 count 降冪、正規化標籤排序；值以型別和值共同識別，避免數字 ID `1` 與字串 ID `"1"` 合併。結果與每個 group 都是唯讀。此 API 是新版通用契約，不推斷舊版篩選 UI 的具體選項。
- 真實曲庫驗證器現在檢查來源分組筆數與來源總數一致，並執行真實資料排序／分頁探針；benchmark 新增來源分組及來源篩選後類型分組的 30 次量測。


## 第十三批補充：多來源資料組裝與 Catalog 原子發布

- `source-adapter.js` 提供單來源 `createAdapter()` 與多來源 `createCompositeAdapter()`。Composite 只組合明確映射的 adapter，不知道任何舊版 schema；來源名稱必須唯一且映射結果的 `source` 必須吻合。任何來源失敗即取消同一組裝操作，避免把單一來源成功誤當成完整 MIX 曲庫。
- `repository.js` 對 Adapter Promise 與 abort signal 競速，取消或被新載入取代時不必等待忽略 signal 的注入 Adapter；若外部 signal 在呼叫前已取消，則不會呼叫注入 Adapter。過期結果不會發布。它也在載入結果進入 validator 前先驗證 Adapter 結果契約：`records` 必須是陣列，`sourceCount` 必須是非負安全整數且等於映射記錄數；若提供 `sourceCounts`，每個來源計數、總數及記錄上的 `source` 標籤必須完全一致。不合契約以 `DATA_ADAPTER_RESULT_INVALID` fail-closed，不會發布 Catalog。它也注入查詢索引 factory；`load-state.js` 在共享狀態更新前先驗證記錄並建立 Catalog，確保狀態進入 loaded/partial/empty 時，對應快照已準備好。索引建立失敗會以 `DATA_CATALOG_BUILD_FAILED` 進入 failed，且清除 Catalog。
- Catalog 是由有效記錄衍生的不可變快照，由載入控制器持有；開始新 generation、失敗及 reset 都會失效舊快照。呼叫端使用 `repository.catalogSnapshot()` 取得目前版本，不應另行保留第二份可變曲庫。
- 來源內 ID 唯一性由 `validateRecords()` 和 `createCatalog()` 一致地以來源 + ID 型別 + ID 值判斷，讓不同來源可以使用相同 ID。
- 真實來源 55,660 筆仍由既有 mapper／驗證工具獨立驗證；本批沒有把真實來源直接接入 runtime，因為 Candidate302 配套關係與載入來源部署方式尚未確認。


## 第十四批補充：明確注入式 Source Registry

- `source-registry.js` 接收 `sources` adapter map 與 `modeSources` mapping；每個模式選取哪些來源由呼叫方明確設定。模組不把 AMQ／EMQ／MIX 的舊版行為寫死，也不在設定缺失時推測 fallback。
- `sourceNamesForMode(mode)` 回傳唯讀來源清單；`createAdapterForMode(mode)` 依設定建立 composite adapter，後續可交給同一 Repository 建立單一 Catalog。未知模式、未配置模式、未知來源、重複來源或空來源集合都會明確報錯。
- 測試中的 `MIX: ["AMQ", "EMQ"]` 是用來驗證注入設定可正常運作的 fixture，不是已核實的 Candidate302 模式規格。正式 runtime config 必須在舊版基準取得後再對照。


## 第十五批補充：Runtime Bootstrap 與模式切換競態

- `runtime-bootstrap.js` 建立單一 Repository，`loadCurrentMode()` 每次從共享 state 讀取當前 mode，並把 mode 明確傳給 Repository 的 adapter 邊界；資料來源選擇仍由 Source Registry 的注入設定決定。
- Bootstrap 訂閱共用 state 的 mode 變化；若載入中發生模式切換，立即取消舊載入並清除該載入狀態，避免舊模式資料延遲覆蓋新模式。模式切換後不自動載入，呼叫端需明確呼叫 `loadCurrentMode()`。
- `dispose()` 會解除 state subscription，並優先呼叫 `repository.invalidate()` 同步取消請求、清空 Catalog 與重設共享載入狀態；僅在注入的舊 Repository 沒有 `invalidate()` 時退回 `cancel()`。這避免舊 runtime 已終止但共享 state 仍顯示 `loaded`，使重新掛載後的新 Repository（尚無 Catalog）與 UI 狀態不一致。dispose 可重複呼叫；已 dispose 的 bootstrap 不允許再開始載入。
- 此模組只處理資料載入生命週期，不規定 AMQ／EMQ／MIX 的出題規則、計分、播放、UI 重置或實際來源 mapping。

## 第十六批補充：非合作來源的取消保證

- `createCompositeAdapter()` 現在把外部取消視為立即完成的載入結果：它會 abort 傳給各來源的 signal，並立刻以 `DATA_LOAD_CANCELLED` 結束等待；不再等待忽略 `AbortSignal` 的注入 adapter 自行 resolve。
- 因此 Repository 的 `cancel()`、Runtime Bootstrap 的模式切換與 `dispose()` 都能將當前 loading 狀態重設為 `not-loaded`，而不讓延遲的舊來源卡住資料生命週期。延遲來源稍後完成時不會發布 records 或覆蓋共享 state。
- Composite adapter 也會原樣傳遞 `mode` 到各來源 adapter；來源可選擇忽略它。這只保留呼叫脈絡，不新增任何 AMQ／EMQ／MIX 產品規則。


## 第十七批補充：核心狀態與生命週期邊界（2026-10-27）

- `src/core/state.js` 的 patch 欄位採白名單；新增共享狀態欄位必須先更新 schema 與測試，未知欄位不會被靜默接受。資料計數欄位必須是非負安全整數，整個 patch 先驗證再提交。
- State 更新在驗證成功後先提交不可變的頂層 snapshot，再通知 listener。listener 例外不會回滾已提交狀態，也不會阻止其他 listener；最近最多 50 筆訂閱錯誤可由 `getSubscriberErrors()` 查閱，並由 `clearSubscriberErrors()` 清除。這是有界診斷佇列，不是完整日誌系統。 通知採 FIFO queue；listener 在通知途中再次呼叫 `update()` 時，新 snapshot 會排在目前通知輪次之後，確保所有仍有效的 listener 先收到原始 snapshot，再依提交順序收到後續 snapshot。訂閱錯誤紀錄保存發生錯誤的那一份 snapshot，不讀取可能已被重入更新替換的全域 state。
- `src/core/lifecycle.js` 的 scope 暴露穩定 `signal`（環境支援 `AbortController` 時）。`dispose()` 先 abort signal，接著以 LIFO 清理註冊資源；呼叫方可把該 signal 傳給 fetch／source adapter 等支援取消的工作。若下游忽略 signal，scope 只能發出取消通知，不能強制終止其內部工作。
- 網路逾時與取消由 source adapter 契約負責；Runtime／Repository 負責世代控制與阻止過期結果發布。核心生命週期 scope 負責模組擁有的資源，不另建第二套資料載入狀態。
- 本批完成的是核心基礎設施契約，不是正式遊戲狀態機。`questionStatus` 仍是佔位欄位；設定持久化、AMQ／EMQ／MIX 遊戲狀態轉移、模式切換重置規則仍需根據正式基準與功能盤點另行定義。


## Batch 20：瀏覽器資料接線邊界

- `src/data/assets/data.js` 與 `src/data/assets/emq-data.js` 是原始來源資產副本；不由 UI 解析、不在來源檔內新增新版邏輯。
- `src/data/source-runtime.js` 負責把這兩份已盤點來源轉為注入式 adapter，並以明確 registry 將 AMQ／EMQ 各自連到 runtime。EMQ 壓縮 payload 只在第一次需要時解壓並快取解碼結果。
- `src/app-runtime.js` 是應用層組裝邊界；`src/app.js` 不直接讀取 `AMQData` 或原始 `DB` globals。
- `src/ui/catalog-browser.js` 僅呼叫 runtime 的 `loadCurrentMode()`／`catalogSnapshot()`，以共享 state 呈現載入結果；load sequence 防止前一請求的 finally 覆寫後續請求的 loading 狀態。
- Batch 20 當時 MIX adapter 明確回報 `DATA_MODE_UNCONFIGURED`；此歷史狀態已由 Batch 29 supersede，現在 MIX 使用 AMQ + EMQ composite adapter 與 2:1 source weighting。
- 來源 mapping 的 schema 標記只反映目前可證實的 Candidate382 Stage I 資料證據，不表示 Candidate302／Stage 0 相容。


## Batch 21：猜歌核心邏輯責任界線

- `src/engine/answer-evaluator.js` 是純資料邏輯，負責正規化與目標欄位答案比對；不依賴 DOM、音訊或持久化。
- `src/engine/quiz-engine.js` 擁有猜歌回合相位、當前題目、完成題數、播放起始時間、暫停偏移與結果快照。它只提供明確狀態轉移，不建立 timer、不操作 media element、不自行保存熟悉度。
- 音訊服務需在實際媒體進入 `playing` 後呼叫 `markAudioStarted()`；只有在 `playing` phase 可提交答案或超時。未播放即跳過不計分，手動揭曉不增加完成題數。
- 引擎輸出的 `familiarityLevel` 是待持久化層採用的結果，不直接寫入收藏／歷史／SRS；`keepHigher` 由注入的 `getFamiliarity(question)` 取得既有等級。
- 目前只有核心模組及 Node 測試，尚未連接猜歌 UI、AudioService、設定持久化或歷史服務。


## Batch 22：音源候選與播放服務

- `src/data/audio-candidates.js` 只把已觀察的 AMQ／EMQ 來源欄位轉成有序 audio candidates；它不執行網路請求、不檢查可播放性。AMQ 只生成音訊鏡像候選，不將影片候選混入 quiz；EMQ Catbox mirror 先於原始 URL。
- `src/data/source-mappers.js` 透過上述 helper 填入 `audioCandidates`，`src/data/validate.js` 驗證候選結構與同曲目 URL 去重。來源候選順序只對使用者提供的參考 HTML 靜態證據成立。
- `src/audio/audio-service.js` 接受呼叫端提供的候選陣列並依序嘗試，負責 canplay／playing 狀態、載入逾時、錯誤／play rejection 備援、`NotAllowedError` 保留候選等待使用者手動播放、AbortSignal、替代請求取消、stop 與 dispose。它不自己猜候選、不持有 UI 狀態，也不把 `play()` Promise resolve 當成已播放；只有 `playing` 事件才是播放成功。
- Batch 32：AudioService 在保留既有字串 `error` 的同時，提供共享錯誤契約格式的 `errorInfo`（category `audio`）；錯誤資訊是額外診斷欄位，不代表真實媒體已播放成功。
- AudioService 的 `ready` 只代表媒體可開始播放；`playing` 才可通知 quiz engine 開始計時。真實媒體事件與音訊可聽性尚未在瀏覽器驗收。


## Batch 23：猜歌產品接線

- `src/engine/quiz-pool.js` 建立當前來源模式的可播放題庫並處理 no-repeat；MIX 現已支援 source-aware pool，並由 `quiz-session.js` 按 2:1 source weighting 選題。
- `src/engine/quiz-clock.js` 是唯一倒數 timer owner；`src/engine/quiz-session.js` 是 UI 之上的協調層，接收 AudioService 狀態並將 `playing` 事件轉為 engine `markAudioStarted()`，暫停／恢復時同步 engine 與 clock。
- `src/ui/quiz-panel.js` 僅負責 DOM 呈現與操作派送。題目、phase、計時結果由 session／engine 管理；共享 `questionStatus` 是相位投影，不是第二份來源。
- 模式切換／元件 dispose 會釋放 session、AudioService、timer 與訂閱。未實作熟悉度／歷史／SRS 持久化。
- 真實瀏覽器 E2E 與實際 URL 播放仍受環境阻擋，Node mock 測試不能取代它們。


## Batch 24：熟悉度持久化

- `src/persistence/familiarity-store.js` 負責讀寫熟悉度，不由 UI 或 quiz engine 直接操作 `localStorage`。
- AMQ 使用參考 HTML 已證實的 `aniCollection_v2`，並可讀取 `anisongFieldGuide_v1` fallback；EMQ 使用 source-aware 的 `amqLearningFamiliarityV1`，避免 AMQ／EMQ 相同數字 ID 覆寫。
- `quiz-session.js` 透過 store 的 `getLevel(record)` 提供 engine `keepHigher` 判定，並在有計分結果且 familiarity level 非 null 時寫回。store 寫入失敗會回報並由 session 顯示提示。
- 歷史紀錄與兩種舊版摘要仍未接入，不能只寫 `aniQuizHistory_v1` 而忽略其 summary／dedupe 契約。


## Batch 25：答題歷史持久化

- `src/persistence/quiz-history-store.js` 擁有新版 detail／summary 寫入與去重；`QuizSession` 只提交引擎已標記 `scored:true` 的結果。
- 新版 storage keys 與舊版分開。舊版 detail、summary、target summary 只讀，用於最近紀錄及可用統計展示，不被新流程修改。
- `all` 目標拆成三筆 per-target history；summary 的 `bySong` 以 source prefix 區分 AMQ／EMQ。
- Detail 上限 2,000；摘要的 processed-ID ring 5,000；摘要 debounce 20 個目標紀錄／30 秒，並在 pagehide、visibility hidden 與 dispose 時 flush。
- 新版 detail／summary 損壞時先 quarantine；若 recovery 寫入失敗，阻止覆蓋原資料。Storage write failure 會在 UI 呈現警告。
- SRS／FSRS 尚未接線；歷史摘要不是 SRS 排程器。


## Batch 25：答題歷史持久化邊界

- `src/persistence/quiz-history-store.js` 擁有新版 detail／summary 儲存、legacy read-only 讀取、去重、recovery 與生命週期 flush；`quiz-session.js` 只把已計分結果交給 store，不直接操作 `localStorage`。
- UI 只訂閱 store snapshot／status 並呈現紀錄數、最近紀錄與錯誤訊息；不在 UI 重算摘要或寫 storage。
- 舊版 detail／summary key 不被新版覆寫；新版採 source-aware key 與 song summary identity。SRS／FSRS 是獨立排程與評級責任，不把一般猜歌正誤直接映射為 FSRS grade。
- 本批 Node 測試證明 adapter 契約與模擬 storage 行為；真實瀏覽器 localStorage、跨頁 storage event 與 pagehide 行為仍待瀏覽器驗收。


## Batch 26：FSRS scheduler 與 SRS persistence

- `src/learning/fsrs-scheduler.js` 是純排程計算模組，不依賴 DOM、storage、UI 或 app；只負責 FSRS-6 計算、卡片狀態與 interval。
- `src/persistence/srs-store.js` 負責既有 `aniSrsScheduleV1` 相容、enrollment／rating／queue／settings／recovery。Store 依賴 `AMQLearning.fsrsScheduler`，不直接依賴 quiz engine 或 UI。
- SRS 需要使用者明確評級 1–4；quiz engine 的正誤與熟悉度 level 不直接映射成 FSRS rating。UI 尚未接線前，這些模組不代表頁面已提供 SRS 操作。
- 舊 schedule 沒有 source 欄位，目前只支援 AMQ；EMQ 必須有獨立 source-aware schema 才能安全支援。


## Batch 27：FSRS／SRS UI 整合

- `src/learning/fsrs-scheduler.js`：純演算法層，負責 FSRS-6 記憶模型、間隔計算、學習步驟、卡片狀態轉移及 preview；不操作 DOM 或 storage。
- `src/persistence/srs-store.js`：負責 legacy-compatible `aniSrsScheduleV1` 讀寫、卡片 enroll／suspend／resume、評級、due queue、dailyNew／batchSize 設定、storage event 與 recovery。
- `src/ui/quiz-panel.js`：SRS UI adapter，負責將 AMQ 曲庫 ID resolver 注入 store、啟動到期回合、顯示評級／預覽及在 dispose 時釋放 store。
- 舊版 SRS 卡片沒有 source 欄位，所以目前只對 AMQ 啟用。EMQ SRS 與黑名單資料源整合仍未完成。


## Batch 28：黑名單狀態與 eligibility cache

- `src/persistence/blacklist-store.js` 是 `aniBlacklistedSongs_v1` 與舊版變更事件的唯一讀寫 owner；UI 不直接操作 localStorage。
- `quiz-panel.js` 訂閱黑名單更新並呼叫 `QuizSession.refreshEligibility()`；`quiz-session.js` 在下一次選題時使用動態 eligibility cache。
- SRS store 接收黑名單 predicate，排除 queue／active counts，但不刪除已存在的 SRS card；解除黑名單後可恢復。
- 黑名單目前只套用 AMQ；EMQ 使用相同數字 ID 時不套用 AMQ blacklist。


## Batch 28：黑名單資料與 eligibility

- `src/persistence/blacklist-store.js` 同時管理 legacy song blacklist (`aniBlacklistedSongs_v1`) 與 work blacklist (`aniBlacklistedAnime_v1`)，保留舊版 `ani-blacklist-changed-v51` 事件契約。
- 兩種 scope 獨立 quarantine／write-block 狀態；損壞資料無法先保存時不覆寫該 scope 的原始 key。
- `QuizSession` 的 eligibility resolver 以 AMQ song ID 與 animeId 檢查兩層黑名單；SRS queue 使用同一 resolver，因此被排除的歌曲／作品不會進入一般抽題或到期複習。
- Legacy blacklist IDs 沒有 source，故不對 EMQ 套用。EMQ SRS 將使用 source-aware 新 schema，而不是猜測 legacy ID 歸屬。


## Batch 29：MIX composite source 與 source-weighted selection

- `source-runtime.js` 將 MIX 映射到 AMQ／EMQ 兩個 source adapter 的 composite adapter；來源 mapper 必須各自標記 `source`，repository 驗證後由同一 query-index 建立聯合 catalog。
- `quiz-pool.js` 的 MIX pool 保留 source+ID identity；`quiz-session.js` 負責 2:1 AMQ／EMQ source weighting，pool 本身不以整個聯合陣列做均勻抽樣。
- SRS queue 的固定 ID 順序優先於一般 MIX source weighting；AMQ blacklist 不會套用到 EMQ 的裸數字 ID。
- Legacy AMQ-specific filter suppression 尚未實作，因新版 UI 尚無對應 watchlist／season／difficulty 等篩選；這是已知相容性差異，不可隱藏。


## Batch 30：source-aware SRS store

- `src/persistence/srs-store.js` 可按 `source: AMQ | EMQ` 建立 store instance，仍共用同一 FSRS scheduler，不重複實作排程演算法。
- AMQ instance 使用 `aniSrsScheduleV1` 維持 legacy schema；EMQ instance 使用 `amqLearningEmqSrsScheduleV1`，並在 schedule 根節點及每張 card 寫入 `source: "EMQ"`。
- Store 對來源驗證、卡片驗證、recovery、settings、daily quota、queue 與 storage listener 皆以該 instance 的來源 key 為邊界。AMQ legacy schedule 不做自動遷移／雙寫；EMQ 不會讀取或覆寫 AMQ key。
- `quiz-panel.js` 根據當前歌曲來源選擇 SRS store；MIX 暫不開啟 SRS session，因現有 session 固定 queue 以 song ID 表示，未設計跨來源的 queue identity。


## 第三十三批補充：資料身份責任

`src/data/identity.js` 為 validator、query index 與 quiz pool 的共同身份來源，避免重複拼接字串造成型別歧義或分隔符碰撞。搜尋正規化仍由 query index 的文字正規化負責，且只作用於搜尋副本；identity helper 不依賴標題／歌手，因此不會把同名歌曲自動合併。


## Batch 38 補充：猜歌暫停與 deadline 原子順序

- `QuizEngine` 是題目 phase／結果的權威來源；`QuizSession` 協調 engine、單一 `QuizClock`、`AudioService` 與持久化；`QuizPanel` 只呈現 session snapshot 並派送操作。
- Clock 只在 AudioService 真正進入 `playing` 後開始。暫停時必須先讓 Clock 計算 deadline，再將 Engine phase 轉成 `paused`。若 deadline 已到，Clock 的 timeout callback 必須在 Engine 還處於 `playing` 時執行，否則 Engine 會拒絕 timeout 並造成 session 卡在 paused。
- `QuizSession.pause()` 現在先呼叫 `clock.pause()`；若該操作已同步觸發 timeout，則回傳 `deadline-reached` 且不暫停音訊。若 Clock 無法暫停則拒絕該操作；若 Engine pause 意外失敗則恢復 Clock，維持兩者一致。此順序由 `tests/quiz-session.test.cjs` 的延遲 interval／deadline 回歸保護。
- 此修正處理的是計時／狀態競態，不代表真實瀏覽器背景節流、音訊輸出或 E2E 已驗收。


## Batch 39 補充：AudioService readiness 與播放 deadline

- `canplay` 代表媒體已可開始播放，不等於已進入 `playing`。autoplay 模式在 `canplay` 後仍保留候選 deadline；若期限內沒有真正的 `playing` 事件，該候選會被釋放並嘗試下一候選。這避免媒體永遠停在 ready 而失去 fallback。
- `autoPlay: false` 在 `canplay` 後進入 ready，等待明確使用者操作；`resume()` 會重新啟動候選 deadline。
- 使用者暫停時設定 `userPaused` 並清除 `playbackStarted`；遲到的 `playing` 事件不得覆寫 paused。resume 會重設等待狀態，只有新的有效 `playing` 事件才發布 playing。
- `tests/audio-service.test.cjs` 驗證 canplay stall fallback 與 pause 後遲到事件。此為 mock media 契約測試，真實瀏覽器事件時序、外部 URL 可用性與音訊可聽性仍未驗收。

## Batch 41：答題歷史讀取安全與版本化猜歌設定

- `src/persistence/quiz-history-store.js` 的摘要讀取錯誤現在與 JSON 格式錯誤分開處理。讀取 `amqLearningQuizHistorySummaryV1` 拋出例外時，store 以記憶體摘要維持 API 可用，但設置 `summaryWriteBlocked`，禁止初始化／flush 將未知的既有摘要覆蓋；後續成功的 storage event reload 才解除阻塞。真正的無效 JSON 仍走 quarantine，再重建摘要。
- `src/persistence/app-settings-store.js` 擁有 `amqLearningAppSettingsV1`，schemaVersion 1 保存 `target`、`questionCount`、`clipSeconds`、`acceptPartial`、`autoPlay`、`customListId`、`srsEnabled` 及 Batch80 新增的年份／未知年份、作品類型、歌曲類型、難度範圍與看番狀態篩選。新增欄位對舊 schemaVersion 1 payload 向後相容，缺少時使用明確預設值；年份／難度範圍非法或倒置會拒絕。讀取失敗會阻止寫入；格式／schema 不合法時先寫入 `amqLearningAppSettingsRecoveryV1` 備份，備份失敗則保護原始 key 並阻止寫入；setItem 失敗不提交記憶體狀態。
- `src/ui/quiz-panel.js` 只作設定 store 的 DOM adapter：mount 時恢復值，控制項 change 時保存，外部 storage event 更新未聚焦的控制項，dispose 時釋放訂閱與自有 store。核心引擎不直接依賴持久化模組。
- 測試覆蓋 summary read failure 不覆寫、讀取恢復後重新載入、設定 schema／恢復備份／讀寫失敗、UI 設定持久化接線。測試使用 mock storage；真實瀏覽器跨分頁行為仍待驗收。


## Batch 42：持久化失敗恢復與 UI 狀態真實性

- `srs-store.js` 收到 storage event 後重新讀取失敗時，保留最後可用的記憶體 schedule，並將寫入設為 blocked；只有後續成功讀取或確認 key 已清除，才以新狀態取代快照。讀取失敗不能被當成空 schedule。
- `quiz-history-store.js` 的新版 detail 讀取失敗時保留上次可讀取的明細快照並封鎖寫入；舊版唯讀明細讀取失敗時保留上次快照，透過 `legacyReadError` 明確投影到 persistence status／UI。成功重新讀取後解除錯誤並替換快照。
- `app-settings-store.js` 寫入失敗時通知訂閱者 `source: "write-failed"`，且不提交候選設定。無效設定成功隔離備份後透過 `recoveryNotice` 表示待修復狀態；quiz panel 顯示提示，直到有效設定成功保存或外部狀態成功重新載入。
- storage clear（`event.key === null`）對 settings、SRS、blacklist、history 與 familiarity 都按各自契約重新讀取；清除事件與讀取例外不可混為一談。跨分頁與 quota 行為目前仍以 Node mock 測試驗證，真實瀏覽器驗收尚未完成。
- 回歸證據：`tests/srs-store.test.cjs`、`tests/quiz-history-store.test.cjs`、`tests/app-settings-store.test.cjs`、`tests/quiz-panel.test.cjs`。這些測試驗證 store 的快照／阻塞／恢復契約，不證明瀏覽器 E2E。


## Batch 43：持久化狀態與訂閱一致性

- 各 persistence store 的寫入失敗須透過狀態 API 回報；對 UI 有訂閱的 store 同時發出失敗通知。Blacklist 將讀取錯誤與寫入錯誤分欄，避免錯誤分類。
- Quiz history detail 與 summary 是獨立持久化目標。`persisted` 欄位為向後相容仍代表 detail 寫入結果；需判斷整批完整性時使用 `fullyPersisted`，summary 尚在 debounce queue 時 `summaryPersisted` 為 false。
- 重啟時以 detail 作為統計恢復來源，使用 summary 的 `processedIds` 去重；這不能消除跨 key crash window，但能在 summary 失敗後重建目前可見 detail 的統計。
- 真實瀏覽器 E2E 仍因環境頁面導覽政策阻塞，不能由 Node mock 測試替代。


## Batch 46：History partial-failure 傳遞到 QuizSession

Quiz history 的 `persisted` 為舊呼叫端相容欄位，只代表 detail 保存結果。`summaryFailed` 表示 summary 寫入明確失敗或阻塞；`summaryPending` 則可能只是正常 debounce。QuizSession 只將明確 `summaryFailed` 視為持久化失敗，避免把正常待寫入狀態誤報，也避免 detail 成功／summary 失敗被當成全數成功。


## Batch 47：QuizSession persistence adapter 隔離

QuizSession 對 familiarity/history store 的寫入呼叫現在各自捕捉 adapter 例外。某一 store 丟出例外不會中止另一 store 的寫入，也不會讓已提交的答案判定失去正常回傳／通知；失敗會轉成既有的部分持久化警告。這是邊界防禦，不取代各 store 自身的 storage error handling。


## Batch 48：持久化警告獨立於短暫 session message

QuizSession 將 `persistenceWarning` 與音訊／回合 `message` 分開保存。`historyStore.beginRound()` 失敗不再寫入會被 `nextQuestion()` 或後續 AudioService `playing` 事件覆蓋的短暫 message；quiz panel 同時呈現目前操作訊息與持久化警告。


## Batch 50：個人清單持久化邊界

- `src/persistence/personal-library-store.js` 是自訂作品清單與看番狀態的單一持久化 owner。UI 不直接存取 `localStorage`，不自行重複驗證 payload。
- 清單沿用靜態參考中可證實的 `aniCustomPracticeListsV1`，看番狀態沿用 `aniAnimeWatch_v1`；兩者使用各自快照、錯誤／阻塞狀態及 recovery。
- `refresh()`、`subscribe()` 與 `dispose()` 管理跨分頁 `storage` event 生命週期；寫入失敗時不發布候選記憶體狀態。
- 此模組已加入 HTML 載入順序與 Node tests。它尚未接入新版 UI；不能因 store API 存在就宣稱產品 CRUD 完成。收藏 `aniFavorites_v1` 的 ID 身份尚未證實，故沒有收藏寫入 API。
- 來源證據與精確限制見 `docs/PERSONAL_LIBRARY_CONTRACT_BATCH50.md`。參考檔標示 Candidate381，不是 Candidate382 Stage 0；不得宣稱 Candidate302／Stage 0 相容。


## Batch 51：個人清單 UI 與曲庫選取 owner

- `src/persistence/personal-library-store.js` 是清單／看番狀態持久化唯一 owner；`src/ui/catalog-browser.js` 只呼叫 store API，不直接讀寫 localStorage。
- 曲庫列以 `source + ID` 作為目前選取身份；點擊與列內鍵盤操作共用 `selectRecord()`。方向鍵只在可見結果列之間移動選取，Enter 只確認選取並明確提示目前沒有曲庫列播放 owner，不觸發音訊。輸入、textarea、select、button、contenteditable 焦點不由列鍵盤操作攔截。
- 個人清單 UI 支援建立／重新命名／刪除、把目前選取歌曲所屬作品加入／移出清單，以及設定六種看番狀態或清除狀態。清單刪除不會刪作品或看番／學習資料。
- `amqLearningAppSettingsV1` schemaVersion 1 增加可選相容欄位 `customListId`，用來保存目前選取清單；讀取舊 payload 時預設空字串。刪除目前選取清單後，UI 會清除此設定參照。兩個 localStorage key 不具交易原子性；若清單刪除成功但設定寫入失敗，UI 必須明確回報部分成功，不宣稱完整完成。
- 目前清單只提供管理與保存，尚未將清單成員接入猜歌出題池；不得把「選取清單」誤稱為已按清單出題。收藏 `aniFavorites_v1` 仍不寫入。


## Batch 52：個人清單與 Quiz Pool 的來源邊界

- `personal-library-store.js` 管理持久化與身份正規化，不負責決定題目是否可播放。
- `catalog-browser.js` 使用 `source + animeId` 的 work ref 寫入清單與看番狀態；不再把裸 work ID 當作跨來源唯一身份。
- `quiz-panel.js` 把選取的 `customListId` 轉成 `quiz-session` 的 `isEligible(record)` 條件；由 `record.source + record.animeId` 查詢清單 membership。`quiz-session` 仍負責可播放條件、no-repeat 與 MIX 來源權重。
- `app.js` 在單一 app lifetime 建立並共享 personal library / app settings stores，確保同一分頁內跨 UI 的訂閱通知一致。UI mount/dispose 順序由 lifecycle scope 管理。
- Legacy `animeIds` 沒有來源，不能安全地映射到任何來源；出題池不會自動使用這些值。這些 ID 仍顯示於清單狀態，供後續有明確使用者確認的遷移工作處理。


## Batch 59：共享 State 的重入通知順序（2026-10-27）

- `src/core/state.js` 將每次成功提交的不可變 snapshot 放入通知 FIFO queue。若 listener 在通知期間呼叫 `update()`，巢狀更新只提交狀態並排隊；目前這輪 listener 完成後才通知新 snapshot，避免其他 listener 收到重複的新狀態或錯過原始提交。
- listener 例外的診斷記錄保存當輪被通知的 snapshot；有界錯誤佇列與 listener 例外隔離行為維持不變。`update()` 的回傳行為仍是同步通知結束時的目前 state，避免不必要地改變既有呼叫端語義。
- Node 回歸測試驗證重入更新的通知順序；這不是瀏覽器端對端驗收。


## Batch 77：備份／還原 UI 邊界（2026-10-27）
- `src/persistence/backup-restore.js` 是備份 envelope、checksum、schema preflight 與多 key rollback 的唯一 owner。
- `src/ui/backup-restore-panel.js` 只負責檔案下載／讀取、預檢摘要、確認流程與結果訊息；不重寫 checksum、key allowlist 或資料 schema。
- `src/app.js` 將面板控制器納入 lifecycle scope，確保 dispose 時解除 DOM listeners。
- 還原成功後提示使用者重新載入，因目前各 Store 在頁面啟動時持有記憶體 snapshot；面板不偷偷重建全體 Store，也不宣稱 localStorage 寫入會自動更新同分頁狀態。
- Node mock DOM 測試只驗證控制器分支，不取代真實瀏覽器下載、file picker、quota、storage event 或 reload 一致性驗收。

## Batch 81 補充：片段定位與自動下一題責任
- `AudioService` 是唯一媒體播放與片段定位責任者。`randomSample`、`clipStartSeconds`、`clipSeconds` 由 `QuizSession` 透過 `AudioService.play(candidates, options)` 傳入；需要隨機定位時等待 `loadedmetadata`，固定定位與隨機定位皆將起始位置限制在可用片段範圍。
- `QuizClock` 仍只由 AudioService 發布的實際 `playing` 狀態啟動。`loadedmetadata`、`canplay`、seek 不等於播放，不能提前計時。
- 自動下一題的延遲由 `QuizSession` 持有，UI 只提供設定。手動前進、結束、重設、dispose 取消 timer；generation token 防止已排入事件佇列的過期 callback 觸發下一題。
- `autoNextDelaySeconds=0` 為相容舊版的預設手動模式；舊版設定缺少新欄位時使用 `randomSample=false`、`clipStartSeconds=0`、`autoNextDelaySeconds=0`。


## Batch 82：中文標題資料服務邊界

- `data/chinese-title-provider.js` 是純資料 adapter：驗證 pinned dataset 格式、建立 MAL／VNDB／AniList 對照、處理 IndexedDB cache、請求取消與失敗回退；不讀 DOM、不直接管理設定、不修改 catalog record。
- `ui/quiz-panel.js` 是啟用開關與生命週期 owner：只在 `chineseTitlesEnabled=true` 時載入 OpenCC／遠端資料，關閉或卸載時取消尚未完成的請求。Provider 的標題／別名由 UI 在答案建議與揭曉顯示時讀取。
- `appSettingsStore` 仍是設定單一來源；新增 `chineseTitlesEnabled` 預設 false，透過既有版本化設定及備份／還原保存。沒有新增獨立設定 Store。
- 外部來源失敗只降低中文標題可用性，不影響曲庫載入、猜歌出題、原有答案建議或答題流程。


## Batch 84：安全曲庫更新與 runtime override

- `src/data/database-update.js` 擁有版本化 JSON 更新包、canonical SHA-256、完整來源 mapping／validator preflight、差異摘要及 IndexedDB 單記錄原子交易。更新包不會執行其內容。
- `src/data/source-runtime.js` 在每個來源載入時讀取已驗證的 active override；已映射記錄會經既有 Source Adapter／Repository／Validator／Catalog 流程，不另建第二個 Catalog。沒有 override 時仍使用唯讀內建資產。
- `src/ui/database-update-panel.js` 提供匯出、選檔、預檢、差異預覽、確認套用與恢復內建曲庫。成功套用要求 reload，避免 runtime 的記憶體 snapshot 與 IndexedDB 不一致。
- 原子替換的唯一持久化責任位於 IndexedDB `amq-learning-database-updates` 的單一 `active` record；不使用 localStorage，也不修改 `src/data/assets/`。完整契約見 `docs/DATABASE_UPDATE_CONTRACT_BATCH84.md`。


## Batch 85：播放歷史與統計投影邊界

- `persistence/playback-history-store.js` 是自由播放事件的唯一持久化 owner；不寫入 `quiz-history-store.js` 的答題結果或摘要。身份由 `source + songId` 組成，事件 ID 只用於去重；最近播放讀取順序為新到舊，最多保留 1,000 筆。
- `persistence/backup-restore.js` 仍是所有可備份 localStorage key 的唯一 allowlist／schema preflight／rollback owner；播放歷史沿用現有 envelope v1，不另建備份流程。
- `learning/statistics-dashboard.js` 是純函式 projection，輸入為現有 stores 的 snapshots，不讀 DOM／storage、不寫入統計，也不建立第二個計數真相。UI 只能消費此投影並處理載入／錯誤狀態。
- 自由播放器尚未完成前，播放歷史 store 不會自行監聽全域 audio events；後續 Dock 必須明確呼叫 `recordPlayback()`，不得把猜歌音訊自動混入自由播放紀錄。


## Batch 86：自由播放與統計 UI 邊界
- `ui/free-player-dock.js` 是自由播放操作邊界，使用現有 runtime catalog 與唯一 `AudioService`；不建立 `QuizSession`、第二個 timer owner 或待聽佇列。
- `AudioService.getPlaybackMetrics()` 只回傳當前媒體位置／長度等快照，不把 HTMLAudioElement 交給 UI。Dock 只在 `playing` 狀態累積播放時間達 5 秒後呼叫 `playbackHistoryStore.recordPlayback()`；QuizPanel 不連接此寫入路徑。
- `ui/statistics-dashboard-panel.js` 僅組合既有 persistence snapshots 並呼叫 `AMQLearning.statisticsDashboard.buildDashboard()`；衍生數字不持久化。各 Store 報告讀取阻塞時停止投影並顯示錯誤。
- `app.js` lifecycle scope 管理兩個面板的建立與 dispose；全域視覺重構仍延後，Batch86 只增加局部 CSS。


## Batch 87：Catalog facet 與持久化 metadata
- `query-index.js` 純資料契約支援年份範圍／未知年份、作品細分類、年代、看番狀態與熟悉度；篩選在排序／分頁前套用，facet 依其他篩選條件重算。
- `catalog-browser.js` 只把 runtime Catalog 分頁複製到獨立 browse index，加入由作品年份、既有 Personal Library 與共用 Familiarity Store 推導的 metadata；原始 Catalog record 與來源 assets 不變。
- App 是 Familiarity Store 的唯一 owner，Catalog Browser 與 QuizPanel 共用同一 instance；兩個子模組不 dispose 共用 Store。
- 中文標題 Provider 只在 `chineseTitlesEnabled` 狀態變更時重新建立索引，避免非相關設定更新觸發全曲庫掃描。

## Batch 89：外部服務與多人協定邊界

- `src/integrations/external-service-adapter.js` 是可選的外部服務 request boundary。它不在建立時發出網路請求，服務操作需由 feature adapter 明確觸發；憑證以注入 provider 提供，只在當次 header 使用，不進入 Store／備份。服務 host、HTTPS、auth policy、rate limit、timeout、AbortSignal 與 dispose 在同一層處理。MAL 配額／具體操作仍標記待官方文件確認。
- `src/multiplayer/protocol.js` 只負責 versioned envelope、訊息／payload 驗證、版本協商與 per-peer sequence guard；不包含 transport、server 或 UI。協定驗證不得取代 server-side auth、room membership 與 anti-cheat。
- 兩個模組不參與 app mount 的必要啟動流程，外部服務或多人服務缺失不會阻止單機 AMQ／EMQ／MIX。


## Batch 90：外部請求與多人 payload 安全邊界

- External service client 禁止呼叫端直接提供 `Authorization` header；憑證只能由注入的 credential provider 按 auth policy 注入。Fetch 固定使用 `credentials: "omit"` 與 `redirect: "error"`，避免 cookie 及重新導向改變已驗證的 origin／host 邊界。
- Multiplayer envelope 的 payload 必須先成為 JSON-compatible value，按序列化後 UTF-8 byte length 檢查大小，再建立獨立副本、重驗 schema 並遞迴 freeze。這可防止 caller-owned object 在驗證後被修改；它仍不構成 server-side trust boundary。
- 新增的安全規則由 `tests/external-service-adapter.test.cjs` 與 `tests/multiplayer-protocol.test.cjs` 回歸保護。


## Batch 91：多人房間狀態轉移（純邏輯）

- `multiplayer/room-state-machine.js` 管理 server-side room state transition：membership、host transfer、ready、round lifecycle、server receipt time、單回合每玩家一次答題、revision optimistic concurrency 與 snapshot resync。模組不建立 transport／server，亦未接入單機 app lifecycle。
- 房間快照於 round active 時會遮蔽其他玩家的 answer text；只有 round close 後才將答案放入公開 snapshot。若 server 需要 viewer 自己的答案，`authenticatedViewerId` 必須由已驗證連線導出，不能採信 client 自報身份。
- `round.start`／`round.close`／`room.close` 受 host 權限限制；答題時間以 server clock 記錄，拒絕錯誤 round ID、重複提交及 deadline 已過的答案。此層不判定答案正確與否、不計分，避免把 client claim 當成權威。
- 純邏輯 Node tests 不能證明真實 server authentication、rate limiting、transport、reconnect 或多人互通。詳細契約見 `docs/MULTIPLAYER_ROOM_STATE_CONTRACT_BATCH91.md`。


## Batch 92：多人服務端答案評級邊界

- `multiplayer/server-answer-assessment.js` 將可信 server question records 與既有 `answerEvaluator`、`assessmentEngine` 接合；`target` 固定於 server-owned question context，submission 與 trusted server outcome／timestamps 分參數傳入；不建立第二份評級規則／FSRS scheduler，不寫入 SRS store，也不接入單機 app。
- 評級只採 server-owned `outcome`、題目 record、target 與 server timestamps；`acceptPartial` 是 assessor 建立時的可信設定。忽略 client 傳入的 correctness、grade、score、elapsedSeconds 與 acceptPartial。
- `anime`／`all` 只評估作品標題；`all` 中歌名與歌手不影響 grade。重用 `work-title-latency-v1`：答錯／超時／作答後跳過=1，答對 0–10 秒=4，>10–15 秒=3，>15 秒=2；揭曉／未播放跳過／取消不評級；缺少可靠 latency 的正確答案不評級。
- 模組只提供可測試的 server-owned logic boundary；呼叫端仍需保證身份、房間成員、單次提交與 server timestamps 可信。沒有真正 server／transport／SRS write／多人 E2E。契約見 `docs/MULTIPLAYER_SERVER_ASSESSMENT_CONTRACT_BATCH92.md`。


## Batch 93：transport-neutral room command orchestration

- `multiplayer/room-command-service.js` 組合 room state machine 與 server-owned assessment adapter；身份只來自可信 `authContext`，題目 ID／round ID／duration／clock 由 server-injected selector／factory／clock 提供。Client `actorId`、開始回合的 questionId／roundId／duration、target、outcome、correctness、grade、score、timestamps 均不作權威依據。
- `dispatch()` 僅允許 client command allowlist；`round.timeout` 不允許從 client dispatch。`answer.submit` 先驗證 membership／round／deadline／duplicate，再計算既有 title-only assessment，成功後才 commit immutable state。
- `expireRound()` 只供 trusted server caller，deadline 未到拒絕，對未答玩家產生 timeout grade，已答玩家不重複評級，並以 server-only timeout transition 關閉回合。結果仍未寫入 SRS store。
- 此為 transport-neutral orchestration，不是 websocket／server deployment；真實 auth、command serialization、rate limiting、reconnect、SRS persistence 與 multi-client E2E 仍未完成。詳細契約見 `docs/MULTIPLAYER_ROOM_COMMAND_SERVICE_CONTRACT_BATCH93.md`。

## Batch 94：多人命令 request-id 冪等重放

- `room-command-service.js` 支援可選 `requestId`，以已驗證的 player ID 與 request ID 作為冪等快取鍵；相同身份、相同 ID、相同 JSON 命令重放時回傳原始成功結果，不再次執行狀態轉移或評級。
- 同一身份重用 request ID 但命令內容不同時明確拒絕；不同玩家的 request ID 命名空間互相隔離。命令 fingerprint 使用排序後的 JSON key，避免只因物件屬性順序不同就誤判成不同命令，並拒絕循環參照／非 JSON 值。
- 快取使用有界 FIFO，預設最多 256 筆，可注入設定，範圍 0–10,000；超出容量時淘汰最舊紀錄。requestId 是向後相容的可選欄位，transport 應對會重試的命令提供穩定 requestId。
- 此快取只保證單一 service instance 存活期間的重放；process restart、跨節點與並行分散式請求仍需由正式 server 的持久化 idempotency store／每房間序列化處理。它不是分散式鎖，也不替代認證或 rate limiting。
- 同一命令服務加入每個 authenticated player 的滑動視窗 command rate limit；預設每 10 秒最多 60 個命令，可注入 `maxCommandsPerWindow`／`commandWindowMs`，拒絕時回報 `ROOM_RATE_LIMITED` 與 `retryAfterMs`。已命中的冪等重放不消耗額度；過期 player window 會被清理。
- Rate limit 只保護此 service instance 的命令入口；正式 transport 仍應加連線／IP／帳號層限制、監控與分散式配額，不能把 in-memory limit 當成部署級 DDoS 防護。

## Batch 95：房間初始狀態結構驗證與 ownership

- `room-state-machine.js` 新增 `normalizeState()`，對初始 room state 做 JSON-compatible detached clone、結構驗證與 deep freeze；拒絕循環參照、非有限數字、非 plain object、symbol／accessor、稀疏或帶額外屬性的陣列及非 JSON 值。
- 結構檢查包含 schema／phase／revision／capacity、唯一成員與 host role、used round ID 唯一性、current round 與 phase／deadline／duration 一致性、每回合玩家答案唯一性及時間範圍。service 建立時不再直接持有呼叫者提供的 mutable initialState。
- 此驗證保護 service 初始狀態邊界，但不是資料庫持久化 schema migration 或跨節點一致性機制；真正 server 仍需自己的 durable state／concurrency control。
- 重用已存在 requestId 但提供不同命令內容的嘗試會先計入該玩家 rate limit，再拒絕 `ROOM_REQUEST_ID_REUSED`；避免透過反覆提交衝突 ID 繞過命令額度。只有完全匹配的成功重放不再消耗額度。


## Batch 96：多人命令 canonical JSON 與 revision 邊界

- `room-command-service.js` 在讀取任何命令欄位前，先將整個 client command canonicalize／parse 成 detached JSON 副本，因此有無 `requestId` 都不會執行 caller getter。拒絕非有限數字、循環參照、symbol、accessor、稀疏／額外屬性陣列及非 plain objects；物件 key 以排序後的 canonical JSON 比較。
- `requestId` 在 fingerprint 前先 trim 正規化；跨 VM／realm 的一般 plain object 仍視為合法 JSON object，不以本 realm 的 `Object.prototype` identity 做錯誤拒絕。
- `room-state-machine.applyCommand()` 在 revision 到達 `Number.MAX_SAFE_INTEGER` 時以 `ROOM_REVISION_EXHAUSTED` 拒絕變更，避免發布不可安全表示的 revision。
- 回歸包含 24 次可重現 round traces、snapshot answer privacy、timestamp／answer 邊界 mutation、revision exhaustion 與 request fingerprint 不安全值。以上仍是 Node 純邏輯測試，不代表 transport／server E2E。


## Batch 97：room command service 時鐘與失敗原子性

- `room-command-service.js` 在 service instance 生命週期內要求注入的 server clock 單調不回退；低於最後觀測時間的值會 fail closed 為 `ROOM_SERVER_TIME_REGRESSION`。相同 timestamp 可接受，不要求每次呼叫都嚴格遞增。這是 process-local guard，不取代正式 server 的可信時鐘／分散式協調。
- `answer.submit` 先產生 tentative state transition，再執行 assessment，只有 assessment 成功後才更新 service state。回歸測試驗證 assessment throw 不提交答案／revision，亦不快取失敗 requestId；相同命令可在依賴恢復後重試。
- `expireRound()` 的 timeout assessments 仍依序計算後才提交 transition；目前 assessor 是純邏輯契約，但若未來接入具外部副作用的 adapter，需先明確定義 all-or-nothing／outbox 或可重試語義，不能假設逐一計算具交易性。


## Batch 98：timeout failure atomicity 與 round-start preflight
- `expireRound()` 會先計算所有未答玩家的 timeout assessment，所有 assessment 成功後才執行／提交 `round.timeout` transition。若中途 assessment 拋錯，service state／revision 保持不變；回歸驗證重試可完整回傳評級並只提交一次 transition。此契約假設 assessor 為純邏輯；未來外部寫入需另設交易／outbox／冪等契約。
- `round.start` 在呼叫 question selector 與 round ID factory 前，先拒絕玩家不足或非 host 玩家尚未 ready 的狀態，避免可預見的拒絕路徑消耗注入資源。這是副作用前置檢查，不取代 `room-state-machine.applyCommand()` 的最終權威驗證。


## Batch 99：命令時間戳一致性
- 對未命中成功冪等快取的新 client command，`room-command-service.dispatch()` 只取得一次可信 server timestamp，並將同一數值用於 rate-limit window accounting 與 room state transition。這避免同一命令在限流檢查與 deadline／event 時間判定間使用不同時刻。
- 完全相同的成功冪等重放不需要讀取新時間；requestId payload mismatch 仍會消耗一次 rate-limit 額度再拒絕。窗口 cutoff 採 `timestamp > now - windowMs`，恰好落在 cutoff 的紀錄視為已過期。
- 此一致性只在單一 service instance／單一同步 dispatch 內成立；不是 distributed clock、transport-level rate limiting 或跨節點一致性保證。


## Batch 100：關閉命令的重試語義
- `round.close`／`room.close` 成功命令若帶有 requestId，重放應由 idempotency cache 回傳原始結果，不再次提交狀態或增加 revision。
- 失敗命令不得寫入成功結果快取；例如 active round 中 `room.close` 拒絕後，待回合關閉後，同一 requestId／payload 可以重試並成功。
- 以上是單一 service instance 的記憶體快取契約；快取淘汰、程序重啟與跨節點場景仍需 durable idempotency 設計。


## Batch 101：離房結果與房主轉移排序
- `player.leave` 提交後，離房者已不再是 room member；命令服務回傳結果時不得再用離房者 ID 要求 viewer-scoped snapshot，否則會在狀態已變更後錯誤拋出 `ROOM_PLAYER_NOT_MEMBER`。離房命令使用一般 room snapshot；它只能在 lobby 執行，最後一位玩家離開則房間關閉。
- 房主離開且仍有成員時，先依 `joinedAt` 升序，再以明確字串 code-unit 順序比較 player ID。不得依賴 `localeCompare()` 的 runtime locale，確保相同 room state 在不同環境選出相同房主。
- 成功離房命令的 requestId 重放仍回傳原始成功結果，不重複移除成員／轉移房主／增加 revision。重放的授權身份來自原 authenticated player；非冪等的新命令仍依當前 membership／host role 驗證。
- 以上僅是純邏輯 service 契約；沒有 durable idempotency、真正 transport/auth、跨節點一致性或 multi-client E2E。


## Batch 102：加入冪等重放與 FIFO 淘汰
- `player.join` 同一 authenticated player／requestId／payload 的成功重放回傳原始 event，不再次新增 membership 或增加 revision。
- idempotency cache 是 insertion-order FIFO，不是 LRU；成功 replay hit 不刷新 entry 的插入順序。達到容量時淘汰最早插入的 entry；淘汰後同 requestId 可被視為新命令處理。
- 成功 replay 保留原始 event／assessment；若 caller 仍是 room member，snapshot 會依目前 state 重新產生，避免延遲重試回傳舊 revision。若 caller 已離房，replay 保留原始 leave response snapshot，不透過快取取得新的 membership-authorized snapshot。


## Batch 103：冪等重放與最新快照
- Idempotency cache 保留原始 event／assessment，確保重試不會再次提交狀態或評級。
- 若 replay 的 authenticated caller 仍是 room member，service 以目前 state 重新建立 viewer-scoped snapshot；原始 event／assessment 不變，revision 不增加。這避免延遲重試把較新的 client state 覆蓋成舊 snapshot。
- 若 caller 已離房（例如重試成功的 `player.leave`），不得透過 cache hit 取得 fresh membership-authorized snapshot；回傳原始 leave result snapshot。
- 此為單一 service instance 的純邏輯契約；真實 transport/session authorization 與跨節點 durable idempotency 仍未實作。


## Batch 104：snapshot revision／closed room 契約
- `getSnapshot(state, sinceRevision, authenticatedViewerId)` 在 `sinceRevision` 等於目前 revision 時回傳 `unchanged: true`；若 revision 較舊或較新，回傳完整目前 state，並始終以 server 的實際 revision 為準。
- `sinceRevision` 大於 server revision 不代表 server 具有未來狀態；回傳完整權威 snapshot 讓 client 重新同步。
- closed room 仍保留成員時，成員可以讀取 closed snapshot；最後一位玩家離開後的空 closed room 可供可信 server-side caller snapshot／revision polling。這不代表離房 client 在 transport 層仍有讀取權限。


## Batch 105：私人自架伺服器與每人 SRS 持久化

- 產品選擇為私人自架，只允許管理者建立一次性邀請；不提供公開自由註冊。
- `server/database.cjs` 使用 Node 內建 `node:sqlite`；`server/account-service.cjs` 負責 8–128 字元密碼的 scrypt 雜湊、一次性 setup、開放註冊與帳號驗證；`server/http-server.cjs` 負責 HTTP 路由／session／請求邊界；`server/srs-repository.cjs` 只接受經 session 驗證的 user ID，依 `user_id + source` 保存 AMQ／EMQ schedule。
- SRS 寫入以 revision compare-and-swap 防止舊快照靜默覆蓋新資料；revision 衝突回 `409 SRS_REVISION_CONFLICT`，呼叫端必須重新載入並處理。
- Batch111 起，session token 的 SHA-256 雜湊、user ID、建立時間與 12 小時到期時間持久化在 SQLite；明文 bearer token 不寫入資料庫，logout 會撤銷記錄，伺服器重啟不會使尚未到期的 session 自動失效。此版本仍是單一 SQLite／單一程序部署，不代表多節點水平擴展。
- Node `node:sqlite` 在本批驗證的 Node 22.16 仍顯示 experimental warning；無外部 npm 依賴，但部署版本必須符合 Node 22.5+。
- 本批只完成後端 API 與 HTTP integration tests；前端帳號 UI、SRS bridge、離線／衝突合併尚未接線，不得宣稱多人 SRS 已在產品 UI 可用。詳細契約見 `docs/PRIVATE_SERVER.md`。


## Batch 106：帳號 UI 與遠端 SRS bridge

- `src/ui/account-panel.js` 管理 setup/login/register/logout/invitation UI，使用 same-origin API 與 HttpOnly session cookie；不將 token 寫入 localStorage。
- `src/persistence/remote-srs-bridge.js` 以 memory-only storage 接入既有同步 `srs-store.js`，啟動時先讀取目前 session 的 AMQ／EMQ schedule；遠端更新使用序列化 queue 與 server revision compare-and-swap。此 bridge 不會讀取或寫入 browser localStorage。
- `src/ui/quiz-panel.js` 提供 `configureSrsStores()`，在本機 store、遠端 store 與隔離空排程之間切換。未登入使用原本本機 store；遠端 schedule 載入失敗時切換到隔離空排程，避免把其他瀏覽器使用者的 localStorage 排程顯示給已登入帳號。登出後恢復本機 store，不會把本機排程上傳。
- 遠端保存發生 409 或網路錯誤時 bridge fail-closed 並透過帳號 UI 呈現狀態；使用者可選擇捨棄未同步變更、重新載入伺服器 schedule。尚未實作離線佇列、合併策略或自動重試。

## Batch 107：公開註冊與可選 Google OIDC

- 產品決策已更新：移除邀請碼註冊及管理者建立邀請 UI/API；完成首次管理者 bootstrap 後，開放一般帳密註冊。未完成 bootstrap 時，帳密註冊與 Google 首次登入都會被拒絕，避免一般使用者搶先成為資料庫第一個帳號。
- `server/google-oidc.cjs` 專責 Google Authorization Code Flow、PKCE S256、JWKS 簽章驗證與 ID token claim 驗證；使用 Node 內建 crypto/fetch，不新增 npm 依賴。驗證 `RS256`、Google issuer、client audience、expiry、issued-at、nonce 與必要的 `azp` 條件。
- `server/http-server.cjs` 負責一次性 state、短效 HttpOnly/SameSite=Lax state cookie、callback、session cookie 與公開註冊速率限制；OAuth secret 僅從環境變數讀取。登入流程不將 Google token 放入 browser storage。
- `server/database.cjs` 對 Batch105/106 SQLite schema 做非破壞式 migration，新增唯一 Google `sub` 與 profile display name 欄位；既有帳號及 SRS 不會被刪除。舊 `invitations` table 為相容性保留，但不再由活躍 API 使用。
- Google `sub` 是唯一 Google 身分關聯；不請求 email 權限、不依 email 自動合併。Google 帳號與一般帳密帳號目前是獨立身分，尚無顯式連結流程，因此可能各自擁有不同 SRS。
- Google OAuth 未配置時回報 `configured: false`，前端隱藏 Google 按鈕但保留一般帳密註冊／登入。部署文件位於 `docs/PRIVATE_SERVER.md`。


## Batch 108：帳號密碼與曲庫來源更新邊界
- `server/account-service.cjs` 的新密碼政策為 8–128 字元；前端新密碼欄位同步 `minlength=8`，登入欄位不施加最短長度，避免既有帳號鎖死。scrypt 與速率限制維持不變。
- `src/index.html` 的曲庫更新區提供 AMQ／EMQ 上游參考連結與清楚限制說明。這些是服務／專案參考，不是已驗證的 AMQ＋EMQ bundle endpoint。
- 一鍵更新需要可信任 bundle hosting、版本 manifest、完整性／來源驗證與既有 atomic apply 的整合；在更新端點未確認前，維持手動匯入流程，不新增任意 URL 自動覆蓋。


## Batch109：遠端曲庫 release manifest

遠端更新的發布端由 `tools/create-database-update-release.cjs` 產生版本化 JSON bundle 與 `latest.json`；前端由 `src/ui/database-update-panel.js` 負責先以固定 Ed25519 SPKI 公鑰驗證 manifest 簽章與 key ID，再限制來源與傳輸方式、核對檔案 SHA-256／payload checksum，最後交給既有 `databaseUpdate` manager 完整預檢。前端不直接解析或執行來源 JavaScript。只有使用者確認後才呼叫 `manager.apply()`，其底層仍以單一 IndexedDB readwrite transaction 替換 active envelope。

`src/data/database-update-config.js` 是自架者設定預設 manifest URL 與固定發布公鑰的入口，manifest URL 預設空白。`tools/create-database-update-signing-key.cjs` 產生自架簽章金鑰；`tools/verify-database-update-release.cjs` 在上傳前離線驗證已簽署的 release。公開固定端點未核准前不內建假 URL。Manifest 必須通過固定 Ed25519 公鑰驗簽；SHA-256 另用於 bundle 位元組一致性。簽章私鑰不納入原始碼與交付 ZIP。


## Batch 111：持久化登入 session

- `server/database.cjs` 新增 `sessions` 表與 expiry index，session 以 SHA-256 token hash 為主鍵，透過外鍵跟隨帳號刪除。
- `server/http-server.cjs` 建立 session 時只將 token hash、user ID、createdAt 與 expiresAt 寫入 SQLite；程序內 Map 只作熱快取。每次驗證仍檢查 TTL 與帳號存在，logout 同時清除快取及資料庫記錄。
- Session TTL 仍為 12 小時。伺服器重啟不再無故登出所有使用者；已到期的 session 會在使用時撤銷，建立新 session 時會清除其他過期記錄。
- 這不提供多節點共用資料庫以外的分散式鎖、跨節點 rate limit 或部署安全保證；正式外網仍需 HTTPS／反向代理與安全審查。


## Batch 112：私人伺服器 SQLite 備份工具

- `tools/backup-private-server.cjs` 使用 SQLite `VACUUM INTO` 建立一致性 snapshot，不直接複製 live database 檔案；拒絕覆蓋已存在的目標。
- 備份完成後驗證 integrity check、foreign key check 與必要資料表，再輸出 SHA-256／表筆數。POSIX 備份檔使用 owner-only `0600` 權限。
- `tools/verify-private-server-backup.cjs` 可離線重新驗證備份完整性與必要 schema。工具不自動覆寫線上資料庫或執行 restore，避免把備份驗證誤當還原驗收。


## Batch 113：Google 帳號明確連結／解除

- `users.password_enabled` 區分一般密碼登入是否可用；既有 Google-bound row migration 時設為 0，避免把不可得知的隨機密碼視為已設定。
- `account-service.cjs` 提供 `linkGoogleIdentity()`、`unlinkGoogleIdentity()`、`setPassword()`。Google `sub` 唯一且不可跨 AMQ 帳號連結；不以 email 合併帳號或搬移 SRS。
- `/api/auth/google/link` 綁定當前 session user ID；callback 若 session 缺失或變更即拒絕。`/api/auth/google/unlink` 要求帳號保留 password auth method；Google-only 使用者需先在已登入狀態設定密碼。
- `account-panel.js` 提供連結、解除與密碼設定操作；Google-generated username 會顯示，避免使用者設定密碼後不知道一般登入帳號。


## Batch 114：AniList／MAL／VNDB service-specific adapters

- `src/integrations/anilist-adapter.js` 將既有通用 HTTPS client 封裝成 GraphQL media search、viewer profile、MediaListCollection 與 SaveMediaListEntry；驗證輸入、GraphQL errors 與回傳資料形狀。
- `src/integrations/mal-adapter.js` 封裝 MAL v2 anime search、`/users/@me/animelist` 與 `my_list_status` PUT；更新使用 application/x-www-form-urlencoded，OAuth token 仍由通用 client 的 credential provider 提供。
- `src/integrations/vndb-adapter.js` 封裝 VNDB Kana VN search／ID lookup，驗證 `v<number>` ID 與回傳 schema。
- 三個 adapter 只使用固定 HTTPS provider endpoints，不能自行傳入任意 URL；credential policy、timeout、abort、rate-limit 與錯誤分類沿用 `external-service-adapter.js`。
- 本批未實作 OAuth token acquisition/refresh、UI 工作流程或真實外部 API E2E；這些需要各服務的實際 OAuth 設定、產品操作決策與使用者最後瀏覽器驗收。


## Batch 115：持久化多人房間 HTTP transport

- `server/multiplayer-runtime.cjs` 在隔離 VM 中載入 bundled AMQ／EMQ 唯讀資料、現有 source mappers、answer evaluator、assessment engine 與 room state machine，建立 server-owned question assessor。
- `server/multiplayer-host.cjs` 提供 create/list/join/dispatch/snapshot；房間 state、已用 question IDs、timeout assessment 與 command requestId/fingerprint/result 存入 SQLite。每房命令以 Promise queue 序列化；同 requestId 的同 payload 在重啟後仍可重放，異 payload 回 409。
- `room-command-service.js` 新增 `exportState()`，只供 server persistence 取得 detached／frozen authoritative state；UI 不應呼叫此 API，也不可把未遮蔽的 raw state 發給其他玩家。
- `server/http-server.cjs` 接入 authenticated REST endpoints；player ID 由 session user ID 產生。`round.start` 的 question／round ID／duration 由 server 決定，答案評級由 server 的作品標題 evaluator 決定。
- Active round snapshot 遮蔽其他玩家答案；server timer 自動關閉過期 round，timeout assessment 僅回給對應玩家。
- 目前為 HTTP polling，不是 WebSocket；前端多人 UI、音訊同步、多人 SRS 自動寫入與 multi-node transport 尚未完成。


## Batch 116：Remote SRS revision-checked retry

- `remote-srs-bridge.js` 對 transport error 保留最新 serialized schedule in-memory，提供 `retryPending(source?)`。重試前先 GET authoritative schedule；只有 revision 未變才 PUT latest snapshot。
- 若 revision 已變，錯誤正規化為 `SRS_REVISION_CONFLICT`，不送出 PUT，維持 writes blocked。既有 conflict 不可透過 retry API 自動解除。
- `account-panel.js` 只在存在 network-error source 時顯示 retry action；conflict 仍使用明確 reload confirmation。
- Pending schedule 不寫入 `localStorage`，也不跨頁面 reload 保存；本批不是 durable offline queue，不做多裝置 merge。


## Batch 117：多人 HTTP client 邊界

- `src/multiplayer/http-client.js` 是 authenticated same-origin HTTP API 的瀏覽器 client，負責 room list/create/join/snapshot polling 與 command request，不持有房間權威狀態、不自行播放音訊或建立 polling timer。
- 命令預設產生 requestId，並允許呼叫端提供固定 requestId 以安全重試；HTTP 錯誤保留 server code/status/details，revision conflict 不會被轉成一般錯誤。
- Room ID、ready flag 與 answer type 在發送前驗證；網路錯誤與 AbortError 分開處理。輪詢排程、UI 與音訊同步由後續整合層負責。


## Batch 118：多人房間 Session／Controller

- `src/multiplayer/room-session.js` 以單一 session 物件持有目前 room ID、server snapshot/revision、timeout assessment、連線狀態與待重試命令。UI 只能訂閱 `getState()` 投影，不可自行推算 authoritative room state。
- Polling 使用單次 `setTimeout` 串接請求，不使用可能重疊的 interval；`stop()`／`dispose()` 清除排程並 abort 請求，generation guard 阻止停止或換房前的遲到回應發布。即使 transport 忽略 abort，舊結果也不能更新狀態或重新排程。
- Snapshot revision 僅單調增加；相同 revision 的 unchanged response 不取代目前快照，較舊或同 revision 的不同 payload 會忽略。網路失敗採有上限的退避重試。
- 命令網路失敗時，在 session memory 保留原 requestId、原 expectedRevision 與原 payload；即使後續 polling 看到較新 revision，重試仍沿用原冪等命令，讓 server 回放或明確回報 revision conflict。非網路錯誤不保留待重試命令。
- 本批沒有接 UI，也沒有改造 AudioService／QuizSession／QuizClock。單人與多人播放 owner 的安全交接仍是下一批必要工作；不得宣稱多人音訊已整合。


## Batch 119：單一播放權協調器

- `src/audio/playback-coordinator.js` 提供 app-scope 的獨占 playback lease；同一 owner 重複 acquire 是冪等操作，不同 owner 取得權限時會先撤銷前任 lease 並同步呼叫其 `onRevoke`。舊 lease 無法釋放或清除新 owner。
- `src/app.js` 建立一個 app-scoped coordinator，並在 quiz panel 前註冊 cleanup，確保反向 dispose 時 quiz session 先釋放 lease。`src/ui/quiz-panel.js` 將 coordinator 注入既有 `QuizSession`，沒有建立第二個 AudioService 或 QuizClock。
- `src/engine/quiz-session.js` 在有效回合取得 lease；其他模式取得播放權時會取消自動下一題、停止既有 AudioService／QuizClock、結束單人回合並清除剩餘計時。正常結束、reset、dispose 也會釋放 lease。過期的 play Promise completion 由 playback epoch 擋下。
- 此協調器現在已接入單人 QuizSession。多人 UI 尚未存在，因此多人尚未實際 acquire lease；未來多人 UI 必須使用同一個 app-scoped coordinator，並在 revoke 時停止多人音訊／時鐘。這是播放所有權基礎，不等於音訊同步已完成。


## Batch 120：多人 UI 邊界與播放權
- `src/ui/multiplayer-panel.js` 是既有 multiplayer HTTP client／RoomSession 的 UI adapter。大廳、房間與玩家列表皆由伺服器資料投影；UI 不自行推導題目、評級、revision 或回合秒數。
- 目前 `/api/auth/me` 僅用於辨認當前玩家，權限仍由 server endpoint 驗證；UI disabled state 不是安全邊界。
- 多人回合透過 app-scoped `playbackCoordinator` 取得 lease，與單人 QuizSession 共用同一 owner coordinator；本批尚未把多人題目音訊接入 AudioService／QuizClock，因此 UI 必須揭露尚不能完成真實多人聽歌流程。不得為多人另建 AudioService 或 Clock。
- `RoomSession` 是房間快照與 revision 的唯一前端狀態來源；UI 不直接保存第二份 authoritative snapshot。


## Batch 122：共享 AudioService 與多人 deadline 投影
- `src/app.js` 是共享 AudioService 與 playback coordinator 的生命週期 owner；單人 QuizSession 與 MultiplayerPanel 都注入同一服務。注入服務的 session 不得自行 dispose app scope 服務，預設未注入時維持原擁有權語意。
- MultiplayerPanel 只能使用 server snapshot 的 `questionProjection`，並驗證 roundId／questionId 與 HTTP(S) 候選；UI 不接觸答案記錄。
- `serverNow` 是 server snapshot 的顯示時鐘錨點。前端 `QuizClock` 只顯示 `deadlineAt` 的剩餘時間；是否逾時、是否可答與評級完全由 server state machine 決定。
- Lease revoke／離房／非 active round／dispose 必須取消共享音訊，清除 clock 與 subscriptions；不能因 polling render 重新搶回已撤銷 lease。


## Batch 124：多人評級與 SRS 原子交易
- `server/multiplayer-host.cjs` 只從 server-owned questionId、authenticated playerId、server assessment grade 建立 SRS event；忽略 client correctness／grade／latency。MIX 依實際題目來源選擇 AMQ／EMQ schedule。
- `server/srs-repository.cjs` 的 `applyMultiplayerAssessmentInTransaction()` 只可在 host 已開啟的 SQLite transaction 中呼叫。Room state、command idempotency record、SRS schedule update 與 `srs_assessment_events` event record 同一 transaction commit／rollback。
- Event key 為 `(user_id,event_id)`；同 fingerprint 重放回傳既有結果，不重複 review；同 key 不同 payload 以 conflict fail-closed。
- 僅自動評級已入庫且未 suspended 的卡片，不自動 enrollment；AMQ source-less legacy schedule 只允許其原有 AMQ cards，不將資料遷移至 EMQ。


## Batch 128：全候選音訊失敗與自動 SRS 評級隔離
- `src/ui/quiz-panel.js` 只有在全域 SRS 開啟、答題已評分、回合可前進、來源為 AMQ／EMQ 且 `state.audioStatus !== "failed"` 時，才呼叫既有 AssessmentEngine 並寫入 SRS。
- 音訊播放開始後若所有候選仍失敗，既有 elapsed time 不可當成有效學習訊號；普通答題歷史／熟悉度仍可照既有規則記錄，但不自動建立或評級 SRS 卡片。
- 手動評級仍是明確使用者操作；本 guard 只阻止 automatic assessment，不更改 FSRS scheduler 或 assessment rule version。


## Batch184：Workspace Preferences 與 Keyboard Commands

- `src/persistence/workspace-preferences-store.js` 是工作區偏好唯一持久化來源，使用獨立 `amqWorkspacePreferencesV1` key，不把 UI 設定混入既有 quiz `app-settings-store` schema。它持有 shortcuts、visibility、defaultSection、statisticsOrder，負責驗證、壞資料隔離與 storage-event refresh。
- `src/ui/workspace-preferences-panel.js` 是唯一 UI／鍵盤路由 adapter，透過 App 注入的 store 訂閱設定；`src/app.js` 以同一 lifecycle scope 擁有 store 與 panel。快捷鍵只呼叫既有 DOM 操作入口，不直接改寫 QuizSession、AudioService、PlaybackCoordinator 或答題狀態。
- 鍵盤路由忽略 editable targets、IME composition、AltGraph 與 repeat events；自訂組合需包含 Ctrl／Alt／Meta 並經 store 驗證唯一性。錄製期間 Escape 取消。快捷鍵操作只在目標存在、可見且 enabled 時執行。
- 工作區隱藏只切換呈現，不 dispose 模組、不清除資料。統計順序只重排現有統計 grid 的六個子區塊。預設入口預設不自動捲動，以保留既有首頁行為。
- Node／static contract tests 已通過；目前 Chromium 無法啟動，實機焦點、快捷鍵與響應式版面仍未驗收。
