# 驗收規則與證據格式

## 狀態定義
- `NOT_STARTED`：尚未開始。
- `IN_PROGRESS`：進行中。
- `PASS`：已執行驗證且通過。
- `FAIL`：已執行驗證且失敗。
- `BLOCKED`：因明確缺失或外部條件無法驗證。
- `NOT_APPLICABLE`：不適用，必須附理由。

## 每項完成工作都應記錄
- 任務編號與範圍。
- 修改檔案。
- 執行的命令或測試步驟。
- 真實輸出或結果摘要。
- PASS/FAIL/BLOCKED。
- 尚未覆蓋的風險。

## 禁止事項
- 沒有執行測試就寫 PASS。
- 用模擬曲庫宣稱真實曲庫驗收完成。
- 把靜態檢查通過等同於瀏覽器端對端測試通過。
- 把能開啟頁面等同於核心功能已完成。
- 隱藏失敗、忽略錯誤或把 BLOCKED 改成 PASS。
- 只交報告不交修改檔案，卻聲稱實作已完成。

## 驗收層級
1. 靜態檢查：語法、重複定義、依賴方向、已淘汰 API。
2. 單元測試：純邏輯、資料驗證、規則。
3. 整合測試：模組間狀態、事件、錯誤傳遞。
4. 瀏覽器測試：主要操作、響應式、控制台錯誤。
5. 真實資料與外部服務：真實曲庫、音源、多人服務等。
6. 回歸測試：重大整合後確認其他模式與既有功能沒有退化。

## 最低結案條件
必要功能符合規格；重大結構性技術債已處理；測試證據可信；未驗證項目有明確記錄；啟動與測試步驟可重現；工作清單與交接完整。


## Batch 53：持久化錯誤 UI 回歸補充

- 任一 persistence action 回傳 `persisted: false` 時，不得使用成功文案；跨 store 部分成功需說明已完成與未完成的子步驟。
- Recovery／read-blocked 狀態不能被舊的「已保存」訊息遮蔽；相關 store 的 UI 狀態必須在下一次寫入前即可見。
- Node／VM fake storage 只驗證狀態投影與錯誤分支，不等於真實瀏覽器跨分頁／quota／pagehide 驗收。


## Batch 54：音訊／Session／模式切換回歸補充

- primary 候選播放失敗後，必須釋放該媒體並嘗試下一個候選；只有真正 `playing` 的候選能啟動倒數。
- `canplay` 不等於播放；dispose 後遲到的媒體事件不得建立 timer 或發布 session 狀態。
- 模式切換後舊 session/audio 事件不得改寫新模式的共享 phase projection。
- FakeMedia／Node integration 只能證明事件與生命週期契約，不代表真實音源可聽或瀏覽器 E2E 通過。

## Batch 81：音訊片段與自動下一題驗收條件
- `randomSample=true` 時必須等媒體 metadata 可用，再依 `duration - clipSeconds` 選取合法起始秒數；不可將 seek 視為 `playing` 或啟動猜歌倒數。
- `randomSample=false` 時套用 `clipStartSeconds`；固定起始位置不得讓要求的片段窗口超出已知音訊長度。
- `clipStartSeconds=0`、`randomSample=false` 必須維持既有播放行為。
- `autoNextDelaySeconds=0` 不自動前進；1–30 秒由 QuizSession 管理延遲。手動下一題、結束、重設、dispose 取消等待中的自動前進。
- 未開始播放就跳過、音訊候選全部失敗或手動播放仍未啟動時，不應因自動下一題設定而意外連續跳題。
- Node FakeMedia／VM 測試僅為模組與事件契約證據；真實 HTMLAudioElement seek、音訊片段聽感與瀏覽器互動仍須獨立驗收。


## Batch 82：中文標題 Provider 驗收條件
- 未啟用 `chineseTitlesEnabled` 時不發起遠端標題資料下載；舊設定缺少此欄位時預設關閉。
- 啟用後只使用固定版本的 AniList Chinese／Bangumi-data 資料契約與已知 OpenCC 來源；MAL／VNDB 對應必須以明確 site ID crosswalk 完成，不可用標題相似度猜測。
- 來源成功時，中文別名出現在作品答案建議；揭曉時可顯示已對應的中文作品名。Provider 失敗不阻擋英文／羅馬字答案建議與基本猜歌。
- 快取有效期為 7 天；IndexedDB 不可用或寫入失敗時不得令有效遠端結果失敗。過期快取只在遠端來源不可用時作 stale fallback。
- 請求 timeout／取消後不得將未完整資料標記 ready，也不得在 UI dispose 後更新 UI。
- Node／mock IndexedDB 測試只證明資料契約與狀態分支；必須另外驗收真實瀏覽器外部資料、CORS／CDN 與 OpenCC 載入。


## Batch 84：資料庫更新／匯入驗收

- 更新 envelope 必須有已知 `format`／`formatVersion`／payload schema 與 SHA-256；損壞 checksum、未知 schema、重複 ID、懸空作品參照或任何 record validation error 均須在寫入前拒絕。
- 預檢須回報 AMQ／EMQ 作品及歌曲筆數，並比較來源 ID 後顯示新增／修改／移除數量；預檢本身不得寫入資料。
- 套用只允許完整 AMQ + EMQ package，使用單筆 IndexedDB readwrite transaction，失敗時原 active envelope 不變；成功後要求 reload。
- runtime 必須從 active override 讀取並經既有 mapper／Repository／Validator／Catalog 流程，不能只存 staging 檔。清除 override 後 runtime 回到內建來源。
- Node 測試與注入式 store integration 不等於真實 IndexedDB quota／transaction／跨分頁／reload E2E；瀏覽器驗收仍為待處理。


## Batch 85：播放歷史與統計 projection 驗收
- 自由播放歷史與猜歌答題歷史必須分離；來源身份使用 AMQ／EMQ scope，數字相同的 song ID 不可合併。
- 讀取／資料格式失敗不可覆蓋原始 bytes；寫入失敗不可回報 persisted 成功或取代已知快照；跨分頁更新僅能以 storage event 刷新，並在 dispose 後解除 listener。
- 播放歷史有上限、重複 ID 不增加筆數；備份／還原必須保留有效播放歷史並在 preflight 拒絕不合法來源／ID／時間／長度資料。
- Dashboard 只從既有 snapshots 推導；不得建立第二份持久化統計。缺少答題資料時 accuracy 必須是 null，不能是 NaN 或偽造 0%。
- Node fake storage 測試不是實際瀏覽器 quota／跨分頁 E2E。Dock 未接線前，不宣稱播放歷史已開始收集真實播放事件。


## Batch 86：自由播放 Dock 與統計儀表板
- Dock 只列出 AMQ／EMQ 且具有音訊候選的曲目；搜尋、選曲、播放／恢復、暫停、停止及隨機播放都由獨立 AudioService 管理，不建立 QuizSession 或待聽佇列。
- 播放歷史只有在 AudioService 真正進入 `playing` 且累積至少 5 秒後寫入；同一音訊 sequence 只記錄一次，source/song ID 與目前播放曲目一致。短暫試播不記錄，QuizSession 音訊不得混入。
- Dashboard 使用既有 Store snapshots 與純函式 projection；沒有答題資料時正確率顯示「尚無資料」，Storage 讀取不可靠時停止投影並顯示錯誤，不顯示假零。
- Node/fake DOM 回歸不等於真實瀏覽器驗收。HTMLAudioElement 可聽性、實際 5 秒時間、storage quota、跨分頁與 reload 仍待可用瀏覽器環境驗證。


## Batch 87：曲庫篩選與 facet
- 年份範圍先於排序／分頁套用；未知年份由明確開關決定是否保留。作品年代以實際年份分組，不從未知年份推算。
- 作品細分類、看番狀態與熟悉度篩選使用來源可用的真實欄位／既有 Store；EMQ 未提供作品細分類或難度時不得猜測補值。
- 多個 filter 必須 AND 組合，facet 計數依其他條件更新；分頁總數為篩選後、分頁前總數。
- Catalog Browser 與 QuizPanel 共用單一 Familiarity Store；看番狀態使用 source-aware work identity。真實瀏覽器跨分頁與儲存失敗情境尚未驗收，Node integration 不等於 E2E。


## Batch 88：篩選組合矩陣補充
- 使用獨立參考 predicate 驗證來源、歌曲類型、作品類型、年份範圍／未知年份、作品細分類、年代、看番狀態及熟悉度的 256 種組合；不可只用 production predicate 產生預期結果。
- Facet 應忽略自身已選中的 facet 條件，但保留搜尋與其他篩選條件；結果總數在分頁前計算。
- 年份升／降冪排序均將未知年份放最後；年份數值排序不得按字串排序。
- 上述 Node tests 僅證明 query/controller 契約，不取代真實瀏覽器跨分頁、storage failure 與大量資料互動驗收。


## Batch 89：外部服務與多人契約驗收

- External client 不得在建立時自動請求；只允許對應服務的 HTTPS API host，未配置必要認證時 fail closed。憑證不寫入持久化資料、備份或錯誤 details。
- 外部服務的 401／403、429、5xx、invalid JSON、network、timeout、AbortSignal cancel、client dispose 必須分別產生可判斷的標準錯誤；只有網路／timeout／服務端暫時錯誤與 rate limit 可標示 retryable。
- rate limit 以 response headers 為優先，不將動態配額硬編碼為永遠有效的常數。MAL 配額仍需官方文件核實；測試 client 不等於真實 OAuth／API 驗收。
- Multiplayer envelope 必須拒絕未知 protocol／message type、無效 ID／sequence、錯誤 payload schema 與超大 payload；版本協商無交集時明確失敗。序號 guard 必須識別重複／舊訊息與 gap。
- Multiplayer protocol 是 client-side contract，不是安全邊界；真正 server、權限、重連、反作弊與 E2E 仍未實作。多人與外部服務故障不得影響單機啟動。


## Batch 90：外部請求與多人 payload 加固驗收
- External client 必須拒絕任意 caller-provided `Authorization` header，且拒絕時不得呼叫 fetch 或留下 active timer。
- External fetch 必須明確使用 `credentials: "omit"` 與 `redirect: "error"`；不能依賴瀏覽器預設行為保護憑證邊界。
- Multiplayer payload 必須以 JSON 序列化後 UTF-8 byte length 檢查大小，建立與 caller input 分離的副本，重新驗證 schema，並遞迴凍結所有巢狀物件／陣列。循環參照、BigInt 與不可序列化 payload 必須明確拒絕。
- 上述 Node contract tests 不等於真實外部 API／OAuth／瀏覽器／多人 server E2E；server 必須自行驗證身份、房間成員與權限。


## Batch 91：多人房間純邏輯驗收
- 房間 revision 只在有效狀態變更時遞增；過期 expectedRevision 必須拒絕。
- 非 host 不得啟動／關閉 round 或關閉房間；host 離開時依規則轉移 host，空房間關閉。
- 不允許 round ID 重用；每位玩家每 round 只接受一筆答案；round ID 不符、deadline 已過或非成員命令必須拒絕。答案接收時間來自 server clock。
- Active-round snapshot 不得洩漏其他玩家答案文字；closed round 才能公開答案。viewer identity 必須由 server 的已驗證連線提供。
- 此驗收只涵蓋純邏輯／Node regression；真實 transport、server authentication、rate limiting、reconnect 與多 client E2E 繼續 BLOCKED／未實作。


## Batch 92：多人 server-owned assessment 驗收
- 評級必須查詢可信 server question set；未知 question ID／重複 question IDs 拒絕。
- 答案正確性必須由既有 answer evaluator 根據可信 record 計算；client correctness／correctByTarget／grade／score／elapsedSeconds 不得影響結果。
- latency 由 server startedAt／receivedAt 計算；缺少時間時正確答案不評級，時間逆序／非法時間拒絕。
- `acceptPartial` 由 server assessor 設定，不可由單次 client submission 打開。
- `anime`／`all` 僅依作品標題；沿用 `work-title-latency-v1` 門檻，FSRS scheduler 不變。
- Node contract tests 不等於已接入 server、身份驗證、SRS persistence 或多人 E2E。


## Batch 93：room command service 驗收
- 未驗證的 auth context 拒絕；actor identity 只取自可信 context，不採信 client `actorId`。
- client command 必須經 allowlist；`round.timeout` 只能由 server timer／內部 caller 觸發。
- round start 的 question ID／round ID／duration 必須來自 trusted selector／factory／server config；不採信 client 指定值。
- answer submit 需先通過 room membership、round ID、deadline、duplicate guard；assessment 成功後才 commit room state。
- timeout 只可在 server deadline 後執行；只對未答成員產生 timeout assessment，不重複評級已答成員。
- 本批為 Node 純邏輯測試；真實 transport authentication、併發 command ordering、rate limit、SRS persistence 與多 client E2E 仍 BLOCKED／未實作。

## Batch 94：多人命令重試安全驗收
- 同一已驗證玩家以相同 `requestId` 和相同命令重試時，必須回傳原始成功結果且不得再次增加 room revision 或重複評級。
- 同一玩家以相同 `requestId` 提交不同命令內容時必須拒絕；相同 request ID 由不同已驗證玩家使用時不得互相碰撞。
- request-id cache 必須有明確容量上限，超出上限時按 FIFO 淘汰；設定值不合法時建立 service 必須 fail fast。
- 冪等快取僅為單一記憶體 instance 的保護，不能視為跨程序／跨節點保證；真正 server 仍需 per-room serialization／durable idempotency、認證、rate limiting 與 multi-client E2E。
- Room command service 必須對每個已驗證 player 套用滑動視窗 rate limit；超限回報 `ROOM_RATE_LIMITED` 與正數 `retryAfterMs`，窗口過期後可再次接受命令。已成功命令的冪等重放不得消耗額度。
- Rate limit 參數需驗證上下限，過期玩家時間戳需清理；這只證明單一 service instance 的限流行為，不等於 transport／IP／跨節點防護。

## Batch 95：多人房間初始狀態驗收
- `normalizeState()` 必須將輸入轉成與 caller 脫離的 deep-frozen state；呼叫者在 service 建立後修改原物件不得改變 room host／members／revision。
- 必須拒絕錯誤 schema／phase、無效 revision／capacity、重複或不一致 host／player IDs、round ID／phase／deadline 不一致、重複答題者與無效時間。
- 不得執行 caller 提供的 getter；循環參照、accessor、symbol、非 JSON 值、稀疏／帶額外屬性的陣列均需明確拒絕。
- 已存在 requestId 的 payload mismatch 嘗試必須消耗正常命令額度後才拒絕，避免衝突 ID 重放繞過 rate limit；完全相同的成功重放不消耗額度。


## Batch 96：多人命令 canonicalization 與狀態轉移回歸
- 所有 client command 必須在讀取 `type`／`requestId`／其他欄位前完成安全 canonicalization；不論是否有 requestId，都不得執行 caller getter。`requestId` trim 後再做 fingerprint，object key 順序不影響結果。
- requestId 命令中的非有限數字、循環參照、symbol、accessor、稀疏／額外屬性陣列及非 plain object 必須拒絕；拒絕 accessor 時不得執行 getter。
- State machine revision 不可超出 JavaScript safe integer；達上限時必須拒絕 transition，不得發布不安全 revision。
- deterministic generated round traces 必須維持唯一 round IDs、正確 revision 增量、可 normalize 的狀態，以及 active-round answer privacy（只向本人暴露答案文字）。
- 此批自動化結果只證明純邏輯契約；真實 server、transport、跨節點 idempotency、authentication 與多人 E2E 仍未實作／驗收。


## Batch 97：多人命令時間與失敗原子性驗收
- 同一 room command service 生命週期中，server clock 回退必須 fail closed 為 `ROOM_SERVER_TIME_REGRESSION`，不得讓命令改變 room state；時鐘回到最後觀測 timestamp 後，service 可繼續。
- `answer.submit` 的 assessment 失敗時，room revision 與答案清單保持原樣，失敗 requestId 不進入成功冪等快取；依賴恢復後相同 requestId／payload 可成功重試且只提交一次。
- 上述只驗證 Node 純邏輯服務。`expireRound()` 的多筆 timeout assessment 部分失敗語義與正式 server／分散式交易仍待後續處理。


## Batch 98：timeout 原子性與 round-start preflight 驗收
- `expireRound()` 在多位玩家 timeout assessment 中途失敗時，不得改變 room revision、phase 或 current round status；依賴恢復後可重試，並對每位未答玩家產生一份 assessment，僅提交一次 round transition。
- 玩家不足或任何非 host 玩家尚未 ready 時，`round.start` 必須在呼叫 question selector／round ID factory 前拒絕；兩個 factory 的呼叫次數應為 0。
- 此驗收證明 Node 純邏輯服務的 state atomicity 與 injected function 呼叫順序，不代表未來具外部副作用依賴的交易保證。


## Batch 99：多人命令時間戳與限流截止驗收
- 新命令限流計數與 room transition 必須共用同一個 server timestamp；單次命令不可分別讀兩次時間。
- 相同成功 requestId 的重放回傳原結果，不讀取新時間、不再次轉移狀態，也不消耗 rate-limit 額度。requestId payload mismatch 仍消耗正常命令額度後拒絕。
- Sliding-window 保留條件為 timestamp 嚴格大於 `now - windowMs`；到達 cutoff 時舊紀錄過期。被拒絕命令的 `retryAfterMs` 應根據窗口中最早仍有效的 timestamp 計算。
- 自動化測試不代表跨程序／跨節點 rate limiting、正式 server transport 或多人 E2E 已完成。


## Batch 100：round／room close 重試驗收
- 相同 requestId 的成功 `round.close` 重放必須回傳原始事件／時間，且不增加第二次 revision。
- active round 中的 `room.close` 失敗不提交 revision、不快取成功結果；條件解除後，同一 requestId／payload 可以成功重試。
- 成功 `room.close` 的重放應回傳原始成功結果，revision 不再增加。
- 以上只驗證單一記憶體 service instance；不代表程序重啟或跨節點時的 durable idempotency 已完成。


## Batch 101：player.leave／host transfer
- `player.leave` 成功時，service 回傳必須成功；不得因離房者已被移除而在 viewer-scoped snapshot 階段回報錯誤。
- 房主離開後，event、snapshot、role 與 `hostId` 必須一致；同 requestId／同 payload 重放不重複提交 revision，且重放保留原始 event timestamp。
- 原房主離開後不得再用新命令取得 host 權限；新房主可執行 host-only command。
- 相同 `joinedAt` 的房主候選必須以 locale-independent ID tie-break 決定，最後一位玩家離開時 room 進入 closed。
- 本項 Node tests PASS 不代表真實多人 transport／auth／reconnect／multi-client E2E 已驗收。


## Batch 102：player.join 重放與 FIFO cache
- 同一成功 `player.join` requestId 重放必須不重複新增玩家、不增加 revision，並回傳原始 event。
- capacity=2 時插入 A、B、重放 A、插入 C，A 仍應被 FIFO 淘汰；重放不得改變 insertion order。
- 被淘汰的 requestId 再提交時會重新執行；若轉移是 no-op，revision 不增加。
- replay snapshot 是原始結果的一部分，可能已過時；除非另行更新協定，不可假設它是最新 room snapshot。


## Batch 103：冪等 replay snapshot 新鮮度
- 成功命令 replay 必須保留原始 event／assessment，且不重複增加 revision 或評級。
- 若 authenticated caller 仍是 member，replay snapshot revision 必須等於目前 service revision，內容反映最新狀態。
- 若 caller 已離房，replay 原始 leave command 不得藉 cache 命中取得 fresh room snapshot；回傳原始 leave response snapshot。
- 以上純 Node 測試不替代真實 transport/auth、reconnect 或多 client E2E。


## Batch 104：snapshot revision／closed room
- `sinceRevision === currentRevision` 回傳 `unchanged: true`。
- `sinceRevision` 小於或大於 current revision 均回傳完整目前 snapshot，且 snapshot revision 必須等於 server revision。
- retained member 可讀取 closed room snapshot；空 closed room 可由可信 state-machine caller 取得 snapshot。
- 這些測試只驗證 state-machine API，不代表 transport 層對離房後重連的授權已實作。


## Batch 105：私人自架帳號與 SRS API（後端基礎）

- 首次 setup 必須提供當次 server process 的 setup token；只有第一個管理者可透過 setup 建立。
- 朋友註冊必須使用管理者建立的單次邀請碼；邀請碼以 SHA-256 雜湊保存，過期／重複使用皆拒絕。
- 一般帳號密碼以 scrypt 雜湊保存，最短 8、最長 128 個字元；登入 session token 不以明文存入 session map，cookie 為 HttpOnly、SameSite=Strict；登入失敗達上限後回 429。
- SRS API 必須要求有效 session，user identity 由 session 派生，不接受 client 指定 user ID。AMQ／EMQ 與不同使用者排程互相隔離；測試包含 client 偽造 userId 欄位不能跨帳號寫入。
- SRS PUT 必須驗證既有 FSRS schema 與 source tag；expectedRevision 不符時回 409，不覆寫新資料。
- Batch111 起，伺服器重啟後帳號／SRS 與未到期 session 均保留；session 到期邊界、hash-only persistence、logout 撤銷與過期列清理須由 HTTP integration tests 驗證。
- `tests/server-auth-srs.integration.test.cjs` 覆蓋以上後端 HTTP 契約。前端登入／註冊 UI 與既有 SRS Store 整合仍未驗收。


## Batch 106：帳號 UI 與遠端 SRS bridge

- 首次設定、登入、邀請碼註冊、管理者建立邀請、登出均透過同源 API；使用者可見錯誤以 `textContent` 投影。
- 未登入保留原本 local SRS。登入成功後先讀取該 session 對應的伺服器 AMQ／EMQ 排程，建立 memory-only storage；不得把共用 localStorage 的舊排程自動上傳。
- 登出後回到本機 SRS；遠端載入失敗時使用隔離空排程，不退回讀取共用 localStorage。
- 遠端寫入按 source 序列化，expectedRevision 逐次遞增。409／網路錯誤後停止盲目重試，UI 顯示錯誤並提供明確的捨棄未同步變更／重新載入操作。
- `tests/remote-srs-bridge.test.cjs` 覆蓋序列化 revision 寫入、source isolation、localStorage 不接觸與 conflict fail-closed；`tests/account-panel.integration.test.cjs` 覆蓋首次設定、邀請 UI、登入、遠端 store 啟用、登出回復本機及遠端載入失敗隔離。
- 仍需真實瀏覽器／多裝置驗收；離線佇列與多端合併未實作。

## Batch 107：開放註冊與 Google OIDC（自動化驗收）

- 首次管理者 bootstrap 仍為一次性；在 bootstrap 完成前，一般註冊及 Google 首次登入不得建立使用者。
- bootstrap 完成後，一般帳密註冊不需要邀請碼；邀請 API 已移除。一般帳號密碼為 8–128 字元並以 scrypt 雜湊，公開註冊有每 IP 速率限制。
- Google 登入採 Authorization Code Flow + PKCE S256；使用一次性 state、nonce、短效 HttpOnly SameSite=Lax state cookie；Google ID token 必須通過 RS256/JWKS、issuer、audience、expiry、iat、nonce 驗證。
- Google OAuth 只要求 `openid profile`，不要求 email/Gmail 權限；資料庫以 `sub` 唯一關聯 Google 使用者，不能依 email 自動合併一般帳號。
- 既有 Batch106 SQLite schema migration 必須保留舊使用者資料與時間戳，且 Google `sub` 有唯一索引。
- Google OAuth 未配置時，狀態 API 回報 `configured: false`，一般帳密註冊／登入仍可用。
- `tests/server-auth-srs.integration.test.cjs` 覆蓋 open registration、bootstrap gate、Google callback state、個人 SRS 身分隔離與舊邀請 API 移除；`tests/google-oidc.test.cjs` 覆蓋 PKCE scope、JWT signature/claims、錯誤 nonce/audience 與 optional configuration；`tests/database-google-migration.test.cjs` 覆蓋舊 DB 非破壞性 migration；`tests/account-panel.integration.test.cjs` 覆蓋 UI 狀態、Google 按鈕與一般註冊。
- **驗收限制：**自動化使用 mock Google OAuth provider／本機簽署測試 JWT，並未使用真實 Google Client ID／Secret；尚未完成使用者真實瀏覽器 Google 登入、HTTPS 公網部署或正式安全審查。Node integration tests 不代表這些項目已驗收。


### Batch108 密碼與曲庫更新驗收
- 新註冊／首次管理者密碼最短 8 字元；7 字元由伺服器拒絕、8 字元可建立帳號。既有帳號登入欄位不得套用 minlength。
- 曲庫更新 UI 必須提供已知上游參考及明確來源說明；上游網站／程式碼連結不得被描述成可直接匯入的更新包。
- 一鍵更新只有在固定可信任的 bundle URL、版本 manifest、checksum／簽章驗證、相容性檢查與原子套用全部完成後才能標記已實作；目前仍待處理。


## Batch109 遠端曲庫更新驗收界線

- 自動化已覆蓋 release generator 的 manifest／bundle hash／payload checksum 與拒絕覆蓋；面板 mock-fetch 覆蓋遠端 manifest、同來源 bundle 下載、checksum 與完整預檢接線。
- 真實瀏覽器、真實 HTTPS hosting、CORS／redirect、IndexedDB quota／交易、重新載入及跨分頁仍未驗收。
- SHA-256 manifest 不是數位簽章；公開正式發布前應決定可信任 hosting，並評估獨立 Ed25519 簽章。
- 未配置 `src/data/database-update-config.js` 的 manifest URL 時，UI 允許手動輸入網址；不會自行猜測或從上游網站下載任意資料。


### Batch110 Ed25519 曲庫發布簽章
- 遠端 manifest 必須包含 Ed25519 signature，且 key ID 必須與應用程式固定公鑰設定相符。
- 簽章驗證先於 bundle 下載；缺簽章、key ID 不符、簽章被修改、WebCrypto 不支援 Ed25519 均必須拒絕遠端更新。
- 發布工具要求私鑰路徑，並在寫入 bundle 前驗證 key type；manifest 簽章覆蓋除 signature 外的 canonical JSON。
- 私鑰不得出現在公開原始碼或交付 ZIP；hosting 與真實瀏覽器驗收仍另行待辦。

- 自架發布者可用 `tools/create-database-update-signing-key.cjs` 建立自己的 Ed25519 key pair，並用 `tools/verify-database-update-release.cjs` 在發布前驗證簽章與 bundle checksum；私鑰不得放入公開專案或交付 ZIP。


## Batch 111：SQLite session 持久化驗收

- SQLite 僅保存 SHA-256 token hash，不得保存 cookie bearer token 原文。
- 有效 session 在 server restart 後仍可讀取 `/api/auth/me` 與個人 SRS。
- Logout 後同一 token 立即失效，包含伺服器重新啟動後的請求。
- session 在 `SESSION_TTL_MS` 到期的精確邊界失效，對應資料列被刪除。
- Cookie 的 HttpOnly／SameSite／Max-Age 行為維持不變。


## Batch 112：私人伺服器資料庫備份驗收

- 使用 SQLite-native snapshot，備份須保留 users、sessions 與 per-user/per-source SRS rows。
- 備份後執行 `PRAGMA integrity_check` 與 `PRAGMA foreign_key_check`，兩者均無錯誤。
- 目的檔已存在時拒絕覆蓋；source 與 output 同一路徑、來源不存在或 SQLite 檔損壞時失敗，且不得留下貌似成功的最終備份。
- 備份檔輸出 SHA-256、bytes 與必要資料表筆數；離線 verifier 可重新驗證。
- 備份含敏感帳號／SRS／session hash；工具不自動還原，不代表 restore procedure 已驗收。


## Batch 113：Google 帳號連結／解除驗收

- Google link flow 必須在登入 session 下開始，並在 callback 確認同一 user ID 的 session 仍有效。
- 同一 Google `sub` 不得連結到兩個 AMQ user；不按 email 自動合併，也不自動搬移 SRS。
- linked account 回報 `password` 與 `google` 兩種 auth methods；解除後仍保留 password login。
- Google-only account 解除前必須先設定密碼；既有密碼帳號更新密碼必須驗證目前密碼。
- 舊資料庫 migration 對既有 Google-only rows 設定 `password_enabled=0`，不誤把未知的隨機密碼視為可用登入方式。
- Mock OIDC HTTP integration 不得視為真實 Google OAuth／browser callback 驗收。


## Batch 114：外部服務 feature adapter 驗收

- AniList：搜尋參數範圍、media normalize、Viewer auth policy、list read 與 SaveMediaListEntry mutation payload 有 deterministic tests。
- MAL：搜尋、`@me` list read、狀態／分數／已看集數更新與 form-urlencoded payload 有 deterministic tests；OAuth credential 必須由 token provider 注入。
- VNDB：search／ID lookup、固定 endpoint、`v<number>` ID 與結果 normalize 有 deterministic tests。
- 三個 adapter 都只呼叫固定 HTTPS endpoints，輸入錯誤在網路請求前拒絕。
- Mock client 測試不代表 provider uptime、quota、OAuth callback 或真實 API E2E 通過；這些仍需外部設定與最後實機驗收。


## Batch 115：多人房間 HTTP transport 驗收

- 未登入請求拒絕；房間 snapshot 只允許成員讀取。 非成員可透過 `player.join` 加入 lobby；其他命令仍要求成員身份。
- Room state 與 requestId result 在 server restart 後保留；同 payload 重試 replay 原結果，不同 payload 409。
- 每房命令序列化；`round.start` 忽略 client 提供的 questionId／roundId／duration，使用 server-owned question／round ID／configured duration。
- Server 評級忽略 client correctness／grade／latency claims；只有作品標題的可信 evaluator 決定 grade。
- Active snapshot 隱藏其他玩家答案；deadline 到期後 server timer 關閉回合，timeout assessment 僅回給本人。
- 測試使用真實 bundled read-only data 與本機 HTTP；仍不等於多瀏覽器 UI／音訊同步／WebSocket／外網部署驗收。


## Batch 116：Remote SRS safe retry

- 網路 PUT 失敗後，最新待同步排程仍在目前 bridge session 中；明確 retry 會先 GET server revision。
- Revision 未變：只重送最新排程並以 server 回傳 revision 更新狀態；網路恢復後可回到 synced。
- Revision 已變：不發第二次 PUT，轉為 conflict 並封鎖後續寫入；不得自動 merge 或覆蓋另一裝置。
- Account UI 在 network error 顯示 retry button；成功後隱藏。Conflict 只提供明確 reload 流程。
- Pending schedule 是 memory-only，reload／close 前未保存仍可能遺失；真實 browser／multi-device E2E 尚未驗收。


## Batch 117：多人 HTTP client 驗收界線

- Node fake-fetch tests 覆蓋 same-origin credentials、JSON command/requestId、room route、revision polling query、輸入驗證、server conflict preservation、network error 與 abort propagation。
- 這些測試只驗證 client transport contract；不代表多人 UI、實際登入瀏覽器、多人房間操作、音訊同步或 multi-client E2E 已驗收。


## Batch 118：多人房間 Session／Controller 驗收

- 連續呼叫 start 不會建立第二個 polling loop；任一時間最多一個 snapshot request in flight。
- stop／dispose 清除 pending timer、abort in-flight request，且遲到結果不得修改狀態或重新排程。
- Snapshot revision 不得倒退；unchanged 與同 revision response 不可覆蓋已持有的快照。
- 網路失敗後會退避重試；成功恢復後重設正常輪詢間隔。
- 命令遇網路錯誤後，重試沿用原 requestId、payload 與 expectedRevision；revision conflict 不會被當作網路錯誤自動重試。
- 以上是 deterministic Node controller tests，不代表多人 UI、瀏覽器音訊或 multi-client E2E 已驗收。


## Batch 119：單一播放權協調驗收

- coordinator 任一時刻只授予一個有效 lease；不同 owner acquire 先撤銷前任，revoke callback 例外不阻止新 owner。
- 同 owner 重複 acquire 回傳同一 lease；release 重複呼叫安全，舊 lease 不得清除新 owner；dispose 後拒絕新 acquire。
- QuizSession 注入 coordinator 後，單人回合取得播放 lease；多人 owner acquire 會停止單人 AudioService、停止 QuizClock、清除剩餘秒數並結束單人回合。
- 單人回合自然結束、手動結束、reset 與 dispose 均釋放 lease；無 coordinator 的舊呼叫方式維持相容。
- Node fake AudioService 測試只驗證 owner handoff contract；多人 UI、真實瀏覽器音訊與同步仍未驗收。


## Batch 120：多人房間 UI 接線驗收
- 建立／加入／準備／房主開始／提交答案／離開／關閉均使用既有 HTTP client 與 RoomSession；權限最終由伺服器檢查，UI 狀態不得視為安全控制。
- 房間與玩家畫面只從 RoomSession 快照投影；不得以 UI 自行生成的 question／grade／duration／revision 覆蓋伺服器資料。
- 同一 app-scoped playback coordinator 只能有一個 active owner；owner 被取代後 UI 不可在每次 render／poll 反覆搶回 lease。
- VM/fake DOM integration 只驗證 UI 接線，不等於瀏覽器 E2E。若 server snapshot 未提供題目音源投影，必須明確標記多人音訊流程未完成，不能宣稱可完整遊玩。


## Batch 122：多人音訊／倒數整合驗收界線
- Panel integration 覆蓋只將 server projection candidates 傳入共享 AudioService、round 倒數呈現、全候選失敗訊息、lease revoke 禁止重播、離房與 dispose 清理。Host integration 驗證 active projection snapshot 帶 serverNow。
- 全量 Node tests／tooling／architecture／source audit／mapper／benchmark 通過，不等於真實瀏覽器音訊或 multi-client E2E 驗收。
- Client clock 僅為顯示用途；不可在 client 端依倒數自行提交 timeout assessment 或改變 server grade。


## Batch 124：多人 SRS 原子寫入驗收
- Server answer assessment 與 timeout grade 只能由 server 產生；client 傳入的 grade／correctness／latency 不得影響 SRS。
- 同一 room／round／player 只有一個 SRS assessment event；命令重播或 server restart 不得重複增加 review 次數／SRS revision。
- Room state、command replay record、SRS schedule 與 event idempotency record 同 transaction；SRS schema/storage failure 必須回滾答案命令，不能留下部分成功。
- AMQ／EMQ 依 question identity source 分離；MIX 不能以房間標籤決定歌曲來源。未入庫歌曲不自動 enrollment，suspended 卡片不被多人評級改寫。
- Node HTTP integration 覆蓋上述行為不代表真實瀏覽器／多 client E2E 已驗收。


## Batch 128：音訊失敗不自動評級
- 當音訊狀態為 `failed` 時，即使音訊曾播放並存在 latency，提交正確答案不得自動建立／評級 SRS 卡片。
- 一般答題歷史與熟悉度行為維持原有規則；不得因 SRS guard 阻止正常答題。
- 真實瀏覽器音訊供應商／CORS 根因仍需實機驗收；Node 測試只驗證狀態機保護規則。
