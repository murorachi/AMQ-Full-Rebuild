# Batch 38 交接：猜歌狀態／計時生命週期整合

## 結論
完成核心狀態責任核對，並修正一項可重現的競態：使用者在倒數 deadline 已到、但 interval callback 因背景節流尚未執行時按暫停，舊流程會先把 Engine 改成 `paused`，接著 Clock 的 `onTimeout()` 呼叫 `engine.timeout()` 被拒絕，造成 session 卡住。現在先讓 Clock 檢查／暫停，再轉 Engine phase；deadline 已到時會正常結算 timeout。

## 修改檔案
- `src/engine/quiz-session.js`：調整 pause 與 Clock／Engine 的順序，處理 `clock-not-running`、`deadline-reached`，Engine pause 失敗時恢復 Clock。
- `tests/quiz-session.test.cjs`：fake scheduler 新增 `jump(ms)`；新增 deadline 已過但 interval callback 延遲的回歸測試。
- `docs/ARCHITECTURE.md`：記錄 Engine／Session／Clock 狀態責任與 pause deadline 原子順序。
- `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`：更新進度與下一批。
- `docs/HANDOFF_BATCH38.md`、`MANIFEST.sha256`：本批交接與檔案完整性。

## 驗證
- `node tests/quiz-session.test.cjs`：14/14 PASS。
- `tests/*.test.cjs`：21/21 scripts exit code 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：415 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：AMQ 38,821、EMQ 16,839；duplicate IDs／dangling references／cross-source collisions 均為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839、Catalog 55,660。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；5 次樣本，Catalog build 約 696.556 ms（僅當前 Node 環境觀測）。
- `src/`、`tests/`、`tools/` 所有 JS/CJS `node --check`：PASS。
- 日誌位於 `/mnt/data/amq_batch38_logs/`。

## 基準與阻塞
- 工作副本沒有 `.git` metadata；未初始化 Git、未 commit／push。
- `src/data/assets/data.js` SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`src/data/assets/emq-data.js` SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，未修改。
- 真實瀏覽器 UI／音訊 E2E 仍 BLOCKED，先前頁面導覽受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；未重試同一方式。
- 不宣稱目前來源與 Candidate302 或 Candidate382 Stage 0 相容，也不宣稱真實音源可播放。

## 下一批 Batch 39
1. 核對 AMQ／EMQ／MIX 規則差異與已證實的來源權重／fallback。
2. 追蹤候選來源、備援、timeout、cancel、替代請求與 timer start 的跨模組生命週期。
3. 補測試並修正有證據的缺陷；保持 UI 大重構延後。

## 最終交付封包
- ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch38_QuizLifecycle_20261027.zip`。
- Manifest 106/106 SHA-256 PASS；ZIP CRC PASS；封包共 120 個項目。
