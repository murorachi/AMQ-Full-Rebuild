# Batch197 交接：正式 UI 外殼與 role-aware Skin runtime

## 本批實際變更
- 新增 `src/ui/app-shell.js`：將正式頁面分成首頁、選歌、猜歌、學習中心、設定。首頁有可展開的大餅主選單，四個入口為選歌／猜歌／學習中心／設定；頁面內導覽與返回首頁可用。
- 新增 `src/styles/ui-shell.css`：深色 osu!stable-inspired shell、粉色強調、低圓角、桌面／手機斷點與 reduced-motion。`src/index.html` 載入新 CSS 與 shell script。
- 現有模組按責任放置：Catalog／自由播放器在選歌；單人／多人在猜歌；統計在學習中心；workspace preferences、帳號、備份還原、曲庫更新、OSK 匯入在設定。既有模組 DOM IDs 保留。
- `src/skins/theme-adapter.js` 增加 11 個 role runtime mappings：首頁背景／大餅、導覽 tab、選曲 row／selected／hover、猜歌背景、多人面板、播放器底座、學習進度、設定面板。未知或尚未接線的 role 會回報 `unsupported-role`；不把保存映射當成已套用。
- `src/ui/skin-import-panel.js` 修正匯出下載：延遲移除 anchor 與 revoke Blob URL，避免 Chromium pending download 被同 task 清理取消。
- 新增 `tests/app-shell.browser.test.py`，完整 inline 本機 HTML／CSS／JS 以 Chromium 測試正式 DOM；輸出截圖在 `artifacts/batch197-regression/`。

## 驗證證據
- 76/76 Node `*.test.cjs` 個別執行 exit 0；逐檔 log 與 `node-tests.tsv` 在 `artifacts/batch197-regression/`。`quiz-pool.test.cjs` 10/10，約 18 秒。
- Full app-shell Chromium test：18/18 PASS；五頁路由、主選單展開、既有模組 ID、Skin role token 實際套用、unsupported role 警告、390px 無水平溢位，0 uncaught errors。
- OSK import panel Chromium fixture：12/12 PASS，含匯出下載事件。
- Skin contract／adapter／store／transfer focused tests：28/28 PASS。
- Architecture Checker：1,123 PASS／0 FAIL。
- JS/CJS syntax：174/174 PASS。
- AMQ／EMQ SHA-256 未變，見 `artifacts/batch197-regression/asset-sha256.txt`。

## 已知問題與驗收邊界
- 這是正式頁面外殼與部分 Skin runtime，不是完整 Catalog UI 重建。Catalog 內部仍有舊表單／表格排列，Batch198 必須真正重組為左側篩選、中央密集列表、右側歌曲資訊與底部精簡播放器。
- 47 個 roles 目前 11 個已接 runtime；其餘 roles 仍是保存映射但 unsupported。
- 環境禁止 localhost 導覽，所以 Chromium 測試把正式本機資源 inline 後以 `set_content` 執行。該 opaque origin 拒絕 IndexedDB，顯示 `DATA_SOURCE_READ_FAILED`／`storage-unavailable`；這不能代表正式 HTTP-origin 失敗，也不能當作持久化驗收成功。
- 真實使用者 `.osk`、真實封面／音訊、Candidate302／Candidate382 Stage 0 相容性仍未驗收。無 `.git`，未初始化；未覆蓋基準或曲庫。

## 下一批 Batch198
- 真正重建 Catalog 內部 DOM／布局，對照 `prototype/ui-v2-osu-select-batch146/`，保留既有資料／篩選／分頁／選取狀態的單一來源。
- 擴展 role runtime 並讓 Mapping Studio 清楚顯示 supported／unsupported。
- 優先取得一般本機 HTTP-origin 瀏覽器驗收環境，驗證 IndexedDB、曲庫載入、封面與音訊。
