# Batch282 Handoff：Catalog Dock-aware layout、導航列定位與交付包瘦身

## 使用者要求
- 每個版本必須是可驗證的有效更新，避免只補一兩個小 patch。
- 優先推進既有 UI 待辦，並盡量減少交付 ZIP 的體積。

## 本批實作
1. 修正 feature route 的 CSS Grid auto-placement：導航列明確放在第 1 列，頁面放在第 2 列；Home 跨列佔滿畫面。此前導航列可能落到頁面內容之後，造成底部導覽列與工作區空間浪費。
2. 自由播放器透過 ResizeObserver 量測自身實際高度，寫入 `--amq-player-dock-height`；沒有 ResizeObserver 時退回 resize listener。dispose 時斷開 observer/listener 並移除 CSS property。
3. 播放器將 collapsed state 寫到 `data-collapsed`，讓收合狀態可使用緊湊高度；播放狀態仍由既有 dock state owner 負責。
4. Catalog 列表高度以 viewport 與實際 Dock 高度計算；固定 Dock 在桌面／平板保持在底部，列表有獨立垂直捲動，分頁保留在 Dock 上方。手機改回 document flow，避免 fixed player 覆蓋曲目內容。
5. 新增 Skin targets：`catalog.song-list`、`catalog.pagination`、`player.dock`，沒有新增重複狀態 owner。
6. Browser matrix 新增 Dock／pagination 實際 bounding-box 檢查，四尺寸 118/118 PASS。最新截圖在 `artifacts/batch282-home-catalog/`。
7. 修正 Batch281 遺留的 Skin role manifest 漂移：`app.home.logo` 先前已在 adapter selector 出現，卻未同步進 runtime／documented manifest，造成角色總數與契約測試失敗。本批同步兩份 manifest，將 audit 更新為 52 roles／40 wired／12 unsupported，並更新對應測試。
8. 精簡主要交付包：保留正式 source、tests、docs、社群腳本參考包、官方 osu! UI 參考圖、Batch282 截圖、測試所需的歷史 audit JSON 與必要 blocker 摘要；移除歷史重複截圖／raw logs 和 28 MB 的 osu! source ZIP。研究結論與 archive metadata 保留在文件；先前 Batch281 ZIP 未修改，仍是完整源檔參照。

## 驗證
- `python tests/batch273-home-menu.browser.py`：118/118 PASS；四尺寸 1920×1080、1440×900、1024×768、390×844。Catalog 資料仍為 layout fixture，非 live 曲庫。
- `node --test tests/catalog-filter-layout.contract.test.cjs tests/catalog-browser.integration.test.cjs tests/skin-theme-adapter.test.cjs tests/free-player-dock.test.cjs`：38/38 PASS。
- `node --check src/ui/free-player-dock.js`、`node --check src/ui/catalog-browser.js`：PASS。
- `node --test` 將 100 個 Node test files 分成 4 組：74/74、66/66、74/74、104/104 subtests 全 PASS（共 318/318）。
- `node tools/check-architecture.cjs`：1,351 PASS／0 FAIL。
- JavaScript/CJS syntax 195/195；Python AST 35/35。
- 精簡包已解壓後驗證：Manifest 659/659、focused Node tests 55/55、Architecture 1,351/0、Browser 118/118；ZIP CRC PASS，SHA-256 sidecar 已產生。

## 未驗收
- Home/Catalog 與 osu! Stable 的人工視覺 gate仍未通過。
- Catalog browser 使用六筆明確 fixture；真實曲庫、ANN/VNDB artwork、外部音訊、HTTP-origin IndexedDB、Windows／真機仍未驗收。
- 全量 Node suite 本批未執行。

## 下一批
接續 `docs/BATCH279_UI_TASK_SELECTION.md` 未完成工作，優先 Catalog 真實曲庫下的分頁／播放 Dock 行為與 Skin target coverage，再收斂 Home 主視覺與 osu! Stable 差距。不要重做本批已通過的導航列 grid placement 與四尺寸 dock geometry，除非有新回歸證據。
