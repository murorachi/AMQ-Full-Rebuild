# Batch 95 交接包：多人核心狀態驗證與 ownership

## 起點與基準
- 起點為 Batch93 ZIP，獨立工作副本 `/mnt/data/amq_batch94_work`。
- 工作副本無 `.git`，沒有初始化 Git 或偽造 branch／commit。
- Candidate302、Candidate382 Stage 0 不在包內，未修改；`src/data/assets/data.js`、`src/data/assets/emq-data.js` 維持唯讀。

## Batch94 同批成果
- `src/multiplayer/room-command-service.js` 加入可選 requestId 冪等重放：可信 player ID + requestId 隔離、相同命令重放不重複 transition／assessment、同 ID 不同 payload 拒絕、有界 FIFO 預設 256 筆。
- 加入 per-player sliding-window rate limit，預設 60 commands／10 秒；超限 `ROOM_RATE_LIMITED`／`retryAfterMs`；重放不消耗額度，過期 window 清理。
- 專項測試涵蓋 replay、payload mismatch、player isolation、FIFO eviction、rate limit／window expiry／config validation。

## Batch95 成果
- `src/multiplayer/room-state-machine.js` 新增 `normalizeState()`：安全複製 JSON-compatible state、驗證結構與關聯 invariants，回傳 deep-frozen detached state。
- 拒絕 circular references、non-finite numbers、non-plain objects、symbol properties、accessors（不執行 getter）、sparse／額外屬性 arrays 及非 JSON 值。
- 驗證 schemaVersion、phase、revision、capacity、unique player IDs／host role、used round IDs、round phase/status/deadline/duration、answer uniqueness 與 receipt-time range。
- `src/multiplayer/room-command-service.js` 建立時強制呼叫 `normalizeState()`，非法初始 state fail fast 為 `ROOM_STATE_INVALID`。
- 測試補上 detached ownership、deep freeze、偽造 state、getter 不執行與非法狀態拒絕；另以 deterministic mutation matrix 覆蓋 8 類狀態不變量破壞。

## 重要檔案
- `src/multiplayer/room-state-machine.js`
- `src/multiplayer/room-command-service.js`
- `tests/multiplayer-room-state-machine.test.cjs`
- `tests/multiplayer-room-command-service.test.cjs`
- `docs/MULTIPLAYER_ROOM_COMMAND_SERVICE_CONTRACT_BATCH93.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`

## 驗證狀態
- 專項測試與兩個修改 JS 的 `node --check` 已 PASS。
- 完整 Node scripts、tooling、architecture、syntax、source audit、mapper、benchmark 與 ZIP/manifest 的最終結果需以本包交付報告及 `docs/WORK_STATUS.md` Batch95 終驗附記為準。

## 尚未完成／阻塞
- Idempotency cache／rate limit 是 process-local，不能取代 durable idempotency、per-room serialization、跨節點一致性或 transport-level limits。
- 無真正 transport／authentication provider／reconnect／multi-client E2E。
- 多人 SRS persistence 需產品決策；不得寫入沒有 user identity 的共用 localStorage key。
- 外部服務 feature APIs／OAuth／MAL quota、真實瀏覽器／音訊／storage 仍未驗收；Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一路徑。

## 下一步
1. 對 state machine round transition、snapshot privacy、normalizeState phase／answer／timestamp 做 targeted mutation／property-style regression。
2. 保持 SRS policy blocker；不擅自接線多人 SRS 寫入。
3. 沒有 transport／server 決策前不引入任意 server framework；UI／CSS 大重構最後做。
