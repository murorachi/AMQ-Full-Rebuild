# AMQ Visual Needs Traceability Matrix · Batch237

本表先定義 AMQ 頁面需要的視覺功能，再追蹤可映射的 osu!stable 素材。`unsupported` 不等於不需要該元件，而是目前尚無經驗證的正式 DOM/CSS consumer。

來源：官方 [Interface skinning](https://osu.ppy.sh/wiki/en/Skinning/Interface)、[`skin.ini`](https://osu.ppy.sh/wiki/en/Skinning/skin.ini)、[Skinnable sounds](https://osu.ppy.sh/wiki/en/Skinning/Sounds)。

| AMQ 需求 | 版面幾何契約 | AMQ 角色 | stable 素材候選 | Runtime 狀態 | 明確規則 |
|---|---|---|---|---|---|
| 全頁背景 | `cover` | `app.home.background` | `menu-background.jpg` | app.home.background: `"#page-home"` | 滿版氣氛底圖；不能把透明角色圖當背景 |
| 核心主入口 | `intrinsic/contain` | `app.home.primary-action` | AMQ extension / no verified equivalent | app.home.primary-action: `"#home-pie"` | osu!stable 沒有 AMQ 大餅入口的專用檔案，使用 AMQ 元件設計 |
| 返回控制 | `state-pair` | `app.navigation.back` | `menu-back.png`, `menu-back-{n}.png` | app.navigation.back: `"#app-back"` | 保留可鍵盤操作的按鈕 hit-area |
| 分頁切換 | `state-pair` | `app.navigation.tab` | `selection-tab.png` | app.navigation.tab: `"#app-shell-nav"` | 圖片只是視覺層，不替代文字與 aria 狀態 |
| 可選背景動效 | `animated-layer` | `app.home.ambient-effect` | `menu-snow.png` | app.home.ambient-effect: **unsupported** | 素材缺失時預設關閉 |
| 上框架 | `edge-repeat-x` | `catalog.frame.top` | `songselect-top.png`, `songselect-top@2x.png` | catalog.frame.top: `"#catalog-browser"` | 需要獨立框架容器及裁切邊界 |
| 下框架 | `stretch-x` | `catalog.frame.bottom` | `songselect-bottom.png`, `songselect-bottom@2x.png` | catalog.frame.bottom: `"#free-player-dock"` | 只用於選歌框架，不得挪作播放器底座 |
| 歌曲列表一般列 | `stateful-panel` | `catalog.item.background` | `menu-button-background.png` | catalog.item.background: `"#catalog-browser"` | 只允許有語義的選曲按鈕素材 |
| 歌曲列選取狀態 | `state-layer` | `catalog.item.selected` | `selection-bar.png`, `selection-bar@2x.png`<br>`menu-button-background.png` | catalog.item.selected: `"#catalog-browser"` | 不可假設所有版本兩者等價 |
| 歌曲列懸停狀態 | `state-layer` | `catalog.item.hover` | AMQ extension / no verified equivalent | catalog.item.hover: `"#catalog-browser"` | AMQ 生成狀態層，除非使用者明確指定可用素材 |
| 作品／動畫封面 | `artwork-cover` | `catalog.song-artwork` | AMQ extension / no verified equivalent | catalog.song-artwork: **unsupported** | 絕不把 OSK 角色圖自動當作品封面 |
| 歌曲詳細資訊面板 | `panel` | `catalog.song-detail.panel` | AMQ extension / no verified equivalent | catalog.song-detail.panel: `"#catalog-selection-details"` | 沒有 stable 專用素材時使用 AMQ 面板基礎 |
| 搜尋與篩選區 | `panel` | `catalog.filter.background` | AMQ extension / no verified equivalent | catalog.filter.background: **unsupported** | 以 AMQ 組件契約建構 |
| 隨機選曲按鈕 | `state-pair` | `catalog.action.random` | `selection-random.png` | catalog.action.random: **unsupported** | 缺素材使用可存取圖示 |
| 固定播放器底座 | `panel` | `player.dock.background` | AMQ extension / no verified equivalent | player.dock.background: `"#free-player-dock"` | AMQ 擴充槽位 |
| 播放／暫停控制 | `state-pair` | `player.control.play` | AMQ extension / no verified equivalent | player.control.play: `"#free-player-play"` | AMQ 擴充槽位，可使用共用圖示 fallback |
| 播放進度軌道與滑塊 | `track-thumb` | `player.progress.track` | AMQ extension / no verified equivalent | player.progress.track: `"#free-player-progress"` | 不把 osu! 遊戲進度條直接套到音訊播放器 |
| 答題背景 | `cover` | `quiz.background` | `menu-background.jpg` | quiz.background: `"#quiz-panel"` | 同一背景資產可跨頁使用，但頁面 overlay 各自控制 |
| 倒數與題目進度 | `stateful-meter` | `quiz.timer` | AMQ extension / no verified equivalent | quiz.timer: `"#quiz-timer"` | 不能將任意 gameplay 圖片當作計時器 |
| 答案輸入 | `form-control` | `quiz.answer.input` | AMQ extension / no verified equivalent | quiz.answer.input: `"#quiz-answer"` | 表單可讀性優先於裝飾 |
| 答對／答錯回饋 | `semantic-feedback` | `quiz.result.correct`<br>`quiz.result.incorrect` | AMQ extension / no verified equivalent | quiz.result.correct: **unsupported**<br>quiz.result.incorrect: **unsupported** | osu! ranking grade 不等於答題正誤 |
| 房間面板與成員列 | `panel-list` | `multiplayer.room.panel`<br>`multiplayer.member.item` | AMQ extension / no verified equivalent | multiplayer.room.panel: `"#multiplayer-panel"`<br>multiplayer.member.item: `"#multiplayer-players"` | AMQ 擴充槽位 |
| 學習進度面板 | `panel-data` | `learning.progress.panel` | AMQ extension / no verified equivalent | learning.progress.panel: `"#statistics-dashboard"` | AMQ 擴充槽位 |
| 歷史／複習清單列 | `list-row` | `learning.history.item`<br>`learning.review.item` | AMQ extension / no verified equivalent | learning.history.item: `"#learning-history-list"`<br>learning.review.item: `"#learning-review-list"` | 共用 list item 幾何 |
| 結算主面板 | `panel-contain` | `results.panel` | `ranking-panel.png`, `ranking-panel@2x.png` | results.panel: `"#quiz-round-results"` | ranking-panel 可參考結算面板，但須驗證內容適配 |
| 結算評級徽章 | `intrinsic` | `results.grade` | `ranking-XH.png`, `ranking-XH-small.png`<br>`ranking-S.png`, `ranking-S-small.png`<br>`ranking-A.png`, `ranking-A-small.png` | results.grade: **unsupported** | 無對應評級時使用文字評級 |
| 主要下一步操作 | `button-state` | `results.primary-action` | AMQ extension / no verified equivalent | results.primary-action: **unsupported** | AMQ 共用按鈕元件 |
| 開關／滑桿／下拉選單 | `native-control` | `settings.toggle`<br>`settings.slider`<br>`settings.dropdown` | AMQ extension / no verified equivalent | settings.toggle: `"#page-settings input[type=\"checkbox\"]"`<br>settings.slider: **unsupported**<br>settings.dropdown: `"#page-settings select"` | 不能把控制項整個替換成不可操作圖片 |
| 對話框與確認面板 | `dialog-panel` | `settings.dialog` | AMQ extension / no verified equivalent | settings.dialog: **unsupported** | AMQ 擴充槽位 |
| 成功／警告／錯誤訊息 | `semantic-status` | `feedback.success`<br>`feedback.warning`<br>`feedback.error` | AMQ extension / no verified equivalent | feedback.success: **unsupported**<br>feedback.warning: `".notice"`<br>feedback.error: `'[role="alert"]'` | 優先保留無障礙狀態語義 |

## 驗收規則

1. 每個需求先有自己的 AMQ layout/component slot，不能由匯入包裡「剛好有什麼圖」反推頁面結構。
2. 只有用途、幾何、狀態語義都吻合的 stable 資產才是自動建議。檔名完全匹配仍須受角色契約限制。
3. 作品封面必須來自對應作品的封面來源；OSK 的角色插畫不會自動變成歌曲封面。
4. `menu-button-background.png` 僅對應選曲列／官方指定語義，不能套用到設定面板、播放器底座或所有通用卡片。
5. `songselect-top.png` 與 `songselect-bottom.png` 幾何不同；上框架的邊緣重複需由專用 renderer 實作，不能把 `repeat-x` CSS 預覽當成正式等價。
6. `@2x`、hover/normal、動畫序列、skin.ini 版本與 blend/tint 必須各自驗收；缺少證據時保留 fallback。
7. 本批已建立 30 個視覺需求槽位，其中必要與選配分開。此表是初版需求基線，不表示所有角色已有正式 DOM selector 或已完成像素級渲染。
