# AMQ UI 原型交接：Batch147（封面載入與 Skin 素材研究）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata，未初始化 Git。正式 `src/`、Candidate302、Candidate382 Stage 0、AMQ／EMQ source assets 均未修改。

## 使用者硬性設計要求
- 參考 osu!stable Song Select 的版面、操作、視覺與資訊呈現（ABCD）；整體接近 osu，但保留 AMQ 原有有價值操作（AC）。
- 每張歌曲卡片／列必須有動畫或遊戲相關封面，並且最好有有意義的選取／懸停動效。不可交付只有文字的歌曲列或純色塊假封面。
- 避免 AI/SaaS dashboard 風格：過多卡片、漸層、徽章、裝飾性統計。

## 本批變更
- 修正 `tests/browser-smoke.py`：原本以 `page.set_content()` 載入 HTML，mock data 裡的相對路徑 `assets/covers/*.svg` 在 about:blank 下失效，導致截圖出現破圖。此執行環境會阻擋 Chromium 導覽 `file://` 和 localhost HTTP，因此測試現在把本地 SVG 以 data URI 內嵌至 mock-data JS，再執行完整互動測試。
- 增加兩項斷言：歌曲列表封面載入成功、選中歌曲詳情封面載入成功。
- 重產 1920×1080、1440×900、1024×768、390×844 等截圖；桌面選曲截圖現已顯示封面圖，不再破圖。
- 原型有 15 張原創 SVG 動畫風示意圖及懸停／選取動效。這些不是實際作品官方封面，仍需在正式接曲庫前以獲授權或可合法使用的封面替換。
- Skin 研究初步結果：Project Minimalist README 明示整個 Skin 採 Unlicense，可自由使用、修改、散布；Neon README 採 CC BY-NC 4.0，若 AMQ 未來有商業用途不可直接照搬其素材，且需署名。Skin 內的第三方插畫／音效仍須逐項查授權。

## 驗證
- `python prototype/ui-v2-osu-select-batch146/tests/browser-smoke.py`：**45/45 PASS**。
- 新增 cover load checks 2 項 PASS。
- Chromium page errors：0。
- 1440×900、1024×768、390×844 頁面層級溢位檢查 PASS。
- 截圖：`prototype/ui-v2-osu-select-batch146/artifacts/desktop-catalog-1920x1080.png` 等。
- 這些是原型互動與尺寸測試，不代表正式產品整合或使用者視覺驗收。

## 來源與授權注意
- Project Minimalist：`https://github.com/PopCat19/Project-Minimalist`，README 明示 Unlicense；仍須針對每個實際下載資產檢查來源及檔案內的第三方內容。
- Neon：`https://github.com/mcendu/neon`，README 採 CC BY-NC 4.0，不作商業用途直接移植的預設候選。
- osu skinning 文件：`https://osu.ppy.sh/wiki/en/Skinning/Interface`。
- 開源程式碼授權不自動涵蓋 Skin 中的圖片、音效、角色插畫或其他第三方素材。

## 尚未完成／下一步
1. 將現有示意封面視為暫時素材，繼續找可合法重用、具作品插畫／背景的 Skin 或素材庫；建立逐檔 asset/license/credit 清單，不要把 Skin 整包授權一概而論。
2. 找到可合法使用的真實作品風格素材後，替換示意 SVG，保留封面載入失敗的 fallback 與 prefers-reduced-motion 支援。
3. 先由使用者驗收選曲主畫面的視覺方向，再延伸其他頁面；不得因自動測試通過就宣稱設計驗收。
4. UI 原型不替代正式產品 Batch140–144 全量回歸與 ZIP 收尾。
