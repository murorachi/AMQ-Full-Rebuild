# Batch232 交接：跨頁導覽捲動位置修正

日期：2026-10-29
工作副本：`/mnt/data/amq_batch231_work/project`
來源交付：`AMQ_Full_Rebuild_Batch231_Catalog_Artwork_Fallback_UI_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch232_Route_Scroll_Reset_UI_20261029.zip`

## 實作
- `src/ui/app-shell.js`：跨頁 `navigate()` 在更新頁面與焦點後將視窗重置至頁首，使用 `behavior:auto`；不改動路由 owner、資料狀態或 QuizSession。
- Settings 區塊快速跳轉維持獨立 `scrollIntoView()`，不被跨頁重置改壞。
- `tests/app-shell.browser.test.py`：390px mobile 先將 Catalog 捲至 520px，再切換 Quiz，驗證新頁回到頁首且標題可見。證據在 `artifacts/batch232-regression/`。
- 累積保留 Batch231 Catalog title-derived artwork fallback。

## 驗證
- Chromium formal shell：141/141 PASS；無水平溢位與 uncaught browser exceptions。
- Catalog integration + UI CSS contract：3/3 PASS。
- OSK browser：12/12 PASS。
- Architecture：1,172 PASS／0 FAIL。
- Batch231 非-tooling Node test files 81/81、tooling focused subset 11/11；181 JS/CJS syntax、2 Python compile PASS。
- AMQ／EMQ asset SHA-256 未變。

## 未解／阻塞
- HTTP-origin IndexedDB 受 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。
- 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與實機 UI 未驗收。
- 無 `.git`，未初始化；正式基準原始檔缺席且未覆蓋。UI 主線未結案。

## 下一批：Batch233
- 首頁／結果頁空狀態、主要 CTA、焦點與手機 UI；跨頁導覽 scroll/focus 一致性；保留 Settings 區塊內跳轉語義。
