# Batch290 Mods Traceability

| 參考區域 | 正式 owner／本批變更 | 驗證與限制 |
|---|---|---|
| osu! Stable Mods multiplier | `src/engine/quiz-mods.js#getMultiplier`；目前只提供規則計算 | `tests/quiz-mods.test.cjs` 5/5；沒有 score owner，不代表正式計分已套用 |
| Mod registry／selection | `AMQEngine.quizMods`：registry、selection normalization、exclusive group、storage、subscribe/reset/dispose | 本機 storage contract 測試；尚未接 UI |
| Vocal Only／Background Only | `exclusiveGroup: audio-source` | 只驗證互斥，無可用音軌資料契約，音源分離尚未實作 |
| Reverse／Fade Out／Beat Shuffle | Registry metadata 與提議倍率 | AudioService effects 未接線；不得顯示為已生效 |
| Stable visual reference | `artifacts/osu-reference/osu-game-modifiers.jpg` | 已檢視；Mods overlay 與人工視覺 gate 未完成 |

---

# Batch287 VNDB Quiz 角色欄 Traceability

| 參考區域 | 正式 AMQ owner | 本批實作 | 驗證／限制 |
|---|---|---|---|
| 使用者 AMQ 原圖底部角色 | `#quiz-character-bar`, `#quiz-character-items` | 角色欄置於 Quiz round section 底部；無已載入圖片時隱藏 | Batch287 browser 35/35；fixture 圖片不代表 live VNDB 通過 |
| Settings 角色設定 | `#vndb-character-settings-panel`, `#vndb-character-id` | 新增／移除 c-ID、最多 8 個、去重、localStorage 保存 | 桌面／手機互動、remount 恢復 35/35 |
| VNDB character lookup | `src/integrations/vndb-adapter.js#getCharacter` | `https://api.vndb.org/kana/character`，取得 `id,name,original,aliases,image.url,vns.title` | external-service adapter contract PASS；live HTTP 未驗收 |
| Skin System | `quiz.character.bar`, `quiz.character.item` | role manifest、runtime selector、visual needs、CSS token 同步 | role inventory 60 total／48 runtime／12 unsupported；theme adapter 24/24 |
| UI 文字品質 | `src/ui/vndb-character-panel.js` | 遊戲內只呈現角色圖與名稱；未設定時隱藏，不顯示開發說明 | 靜態字串與 DOM contract 已檢查；人工視覺 gate 待完成 |

---

# Batch285 Quiz／Route UI Traceability

| 參考區域 | 正式 AMQ owner | 本批變更 | 驗證／剩餘差距 |
|---|---|---|---|
| osu! Stable Intro 背景／中心焦點 | `#quiz-panel`, `.quiz-question-card` | 將人工 equalizer 長條換成低對比同心環與放射線；保留 Skin background token | `quiz-vs-osu-stable.jpg`；仍不像 Stable，無人工 gate |
| Feature route canvas | `body`, `main`, `.app-page` | 單欄 grid，明確 header/main row；頁面內層捲動 | 四尺寸 browser 71/71；根本 split-grid regression 有測試 |
| Route navigation/status | `#app-shell-nav`, `#app-status` | status 移到 route bar；移除重複全域 header | 四尺寸可見狀態與全寬檢查 |
| Quiz setup | `#quiz-panel > .quiz-setup-section` | 原生 details 預設收合；所有原設定 ID 與 owner 保留 | Quiz panel integration PASS；尚未人工驗收設定展開畫面 |
| Answer autocomplete | `#quiz-answer`, `#quiz-suggestions` 等 | ArrowUp/Down、Enter、Escape、outside click、IME、dispose、多詞任意順序、重音折疊與原字串高亮 | `answer-suggestions.test.cjs` 20/20 PASS |
| App navigation shortcut | `src/ui/app-shell.js` | Alt+Left 忽略可編輯目標 | 四尺寸 browser 71/71 |

---

# Batch284 Multiplayer／Quiz 視覺追蹤

| 參考區域 | AMQ 正式 owner | 本批改動 | 驗證／狀態 |
|---|---|---|---|
| Stable Lobby title/status/tabs | `#multiplayer-panel`, `#multiplayer-mode-tabs` | 緊湊標題、狀態列、來源 tabs | 四尺寸 browser 43/43；視覺仍未結案 |
| Stable Lobby search/filter | `#multiplayer-room-search`, `#multiplayer-show-progress`, `#multiplayer-refresh` | 合併為緊湊工具列，保持既有 handlers | 四尺寸 browser PASS |
| Stable room rows | `#multiplayer-rooms` | 空 server state 壓縮至 78px；size 3 | server-backed list 保留；live rooms 未驗收 |
| Create/join | `.multiplayer-create-room`, `#multiplayer-join` | 兩欄布局、窄螢幕堆疊、focus-visible | existing client handler 保留；沒有 Quick Join owner |
| Quiz intro/stage | `#quiz-question-title`, `#quiz-question-meta`, `#quiz-audio-status` | 強化 stage hierarchy，未複製 osu! intro branding | 四尺寸 browser PASS；非人工像素 gate |
| Quiz answer flow | `#quiz-answer`, `#quiz-suggestions`, `#quiz-submit` | focus／selected suggestion visual state | 下一批補鍵盤行為矩陣；本批未改行為 owner |

---

# Batch272 Multiplayer Lobby traceability

| Stable screenshot region | AMQ DOM owner | Skin component role | Interaction/data owner | Evidence | Status |
|---|---|---|---|---|---|
| Title and current room state | `#multiplayer-heading`, `#multiplayer-status` | `multiplayer.room.panel` | `src/ui/multiplayer-panel.js` + server snapshot | Batch272 four-size browser matrix | Implemented structurally |
| Mode/source tabs | `#multiplayer-mode-tabs [data-room-source]` | `multiplayer.lobby.tab` | Local presentation filter over server-returned room list | `batch272-multiplayer-lobby-visual.contract.test.cjs` | Implemented |
| Search / in-progress filter | `#multiplayer-room-search`, `#multiplayer-show-progress` | shared form tokens | Local presentation filter; phase from server room summary | Node contract + Chromium geometry | Implemented |
| Dense room list | `#multiplayer-rooms` | `multiplayer.lobby.room-list` | `client.listRooms()` only | Four-size empty-list screenshots | Partial; server data only |
| Create-room form | `.multiplayer-create-room` | `multiplayer.lobby.create-room` | Existing `client.createRoom()` handler | Node contract + Chromium geometry | Implemented structurally |
| Player slots/avatar, room artwork | Not available in current room summary | Not mapped | Server/API currently lacks fields | `artifacts/batch272-multiplayer-lobby/visual-gap-table.md` | Blocked by data contract |
| Chat region | No DOM owner | Not mapped | No multiplayer chat protocol/API owner found | Gap table | Not implemented; no fake UI |
| Stable bottom Back/New Game/Quick Join strip | Existing room controls retained; no exact equivalent for all three actions | shared buttons | Existing navigation and room handlers only | Gap table | Partial |

The screenshot target is `artifacts/osu-reference/osu-multiplayer-lobby.jpg`. `references/osu-master.zip` contains mainly lazer code and is not a pixel-accurate Stable source. Browser evidence uses production DOM/CSS with no live rooms inserted.

# osu! 原始碼與 Stable 截圖映射（Batch271）

- 視覺基準：使用者提供的 `artifacts/osu-reference/osu-main-menu.jpg`、`osu-intro-screen.jpg`、`osu-song-selection.jpg`、`osu-multiplayer-lobby.jpg`、`osu-game-modifiers.jpg`。這些 Stable 預設 Skin 截圖是視覺驗收基準。
- 原始碼參考：使用者上傳 `osu-master.zip`，SHA-256 `973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`。其主要為 osu!lazer，不能視為完整 Stable source 或像素規格。
- Main Menu 參考檔：`osu.Game/Screens/Menu/MainMenu.cs`、`MainMenuButton.cs`。觀察到按鈕背景、背景內容、hover layer、icon 分層，shear 與 OutElastic 展開；AMQ owner 仍是 `src/ui/app-shell.js` 的 `navigate()` 和既有 route，禁止新建 navigation owner。
- Song Select 參考檔：`osu.Game/Screens/Select/SongSelect.cs`、`BeatmapCarousel.cs`、`osu.Game/Graphics/Carousel/Carousel.cs`。觀察到 carousel、背景 dim/blur、左側互動容器與 selection/key handling；AMQ owner 仍是 `src/ui/catalog-browser.js` 的 controller/query/data/audio owner。
- Skin 參考檔：`osu.Game/Skinning/SkinManager.cs`、`DefaultLegacySkin.cs`、`LegacySkin.cs`、`LegacySkinDecoder.cs`。觀察到 unified lookup/fallback、Legacy settings、`Skins/Legacy` resource namespace 與 Stable 480→768 scale factor 1.6。AMQ Skin Resolver 仍需以產品規格決定唯一優先順序，不得將該 scale 直接套用至 browser viewport。
- Mods 參考檔：`osu.Game/Overlays/Mods/ModSelectOverlay.cs`。只參考 overlay／selection/reset 結構，不複製 osu! 規則或倍率。
- 詳細證據與限制：`docs/OSU_SOURCE_RESEARCH_BATCH271.md`；實作強制提示詞：`docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`。
- 尚未驗收：沒有執行 dotnet tests、未完整 source audit、未確認所有 OSK 元件可映射；不宣稱原生 Stable fidelity。

# Settings 分類工作區、Results 文案清理與 Multiplayer Skin overlay（Batch266）

- Settings 唯一 runtime owner：`src/ui/app-shell.js` 建立 `.settings-workspace`、`.settings-quick-nav[role=tablist]` 與 `#settings-content`；五個既有面板 ID 保持不變，沒有建立第二份設定 store。`activateSettingsPanel()` 只切換既有面板 hidden 狀態、`role=tabpanel`、`aria-labelledby` 與 tab `aria-selected`。
- 鍵盤：分類 tab 支援 ArrowUp/Down/Left/Right、Home、End；切換後焦點移至該分類面板標題。桌面固定 Settings 外框、只有 `#settings-content` 內捲；手機導覽變成兩欄並保留內容區垂直捲動。
- CSS owner：`src/styles/ui-design-landing.css`；Results 舊裝飾性 `01 / ROUND RESULTS` pseudo-element 已從 `src/styles/ui-shell.css` 刪除，不是用 display:none 假裝清理。Multiplayer `#multiplayer-panel` 的文字可讀漸層疊在 `--amq-skin-role-multiplayer-room-panel` 上方。
- Browser：`tests/batch266-settings-results-multiplayer.browser.py` 58/58，四尺寸 Settings/Results/Multiplayer；`artifacts/batch266-settings-results-multiplayer/` 共 16 張截圖。截圖使用正式 DOM/CSS 的明確空狀態／布局 fixture；Settings fixture 不啟動所有資料密集型 feature bootstrap；Multiplayer screenshot 不代表 live server/audio。
- Contract：`tests/batch266-settings-workspace.contract.test.cjs` 3/3；`tests/batch265-visual-structure.contract.test.cjs` 6/6；`tests/results-ui.contract.test.cjs` 7/7；`tests/ui-shell-css.contract.test.cjs` 8/8。正式 App Shell 144/144、Quiz visual 38/38。
- 未驗收：Settings 設定保存／備份還原／OSK 匯入端到端未由本批 fixture 證明；HTTP-origin IndexedDB、live artwork/audio/multiplayer、Windows/實機與人工 osu! 視覺 gate未完成。

# Quiz 遊玩優先視覺結構（Batch264）
- 正式 owner：`src/index.html` 的 `#quiz-panel`、`#quiz-round-section`、`#quiz-question-title`、`#quiz-audio-status`、`#quiz-answer-form`、`.quiz-actions` 與 `#quiz-setup-section`（實際 ID 為 `#quiz-setup-heading` 所屬 `.quiz-setup-section`）。
- 順序：CSS flex `order` 讓 live round 先於 setup，接著為答題歷史與 SRS；原始 DOM IDs 與單一狀態 owner 不變。焦點導航仍以 `#quiz-setup-heading` 作為路由 focus target。
- 視覺規則：`src/styles/ui-design-landing.css` 的 Batch264 區塊。桌面四欄摘要、手機兩欄摘要；問題舞台突出、答案輸入加大、控制列層級收斂、手機按鈕最小高度 46px。
- 文案：移除裝飾編號、`QUESTION POOL` 眉標與產品內工程註記；保留操作、錯誤、狀態及必要說明。
- 測試：`tests/batch264-quiz-visual.browser.py`，38/38；`tests/app-shell.browser.test.py` 144/144；Quiz clock 4/4、engine 11/11、pool 10/10、session 41/41、panel integration PASS。
- 截圖：`artifacts/batch264-quiz-visual/quiz-ui-fixture-{1920x1080,1440x900,1024x768,390x844}.png`。題目／音訊文字為測試 fixture，僅供布局審視，不代表 live data/audio。
- 未驗收：真實音訊／HTTP-origin 曲庫／外部封面、Windows／實機與人工 osu! 視覺 gate。

# Batch263 Home／Catalog 視覺與資料證據追蹤

- Home production owner：`src/ui/app-shell.js` 的 `#home-feature-art`、`#home-feature-title`、`#home-feature-work`、`#home-recent-list`；背景封面與文字疊層規則在 `src/styles/ui-design-landing.css`。
- Home layout change：主視覺 art 區覆蓋 feature 全面，copy/action 位於底部；近期學習空狀態最小高度降為 42px。四尺寸截圖在 `artifacts/batch263-home-catalog/home-{1920x1080,1440x900,1024x768,390x844}.png`。
- Catalog screenshot evidence：`catalog-opaque-origin-error-*` 是 `page.set_content` opaque-origin 的 IndexedDB 失敗畫面；`catalog-data-fixture-*` 是六筆明確測試資料＋data SVG 的布局 fixture。後者不代表正式資料 runtime、HTTP-origin IndexedDB 或外部 artwork provider 已成功。
- Browser harness：`tests/batch263-home-catalog.browser.py`，47/47 PASS，包含四尺寸 route/overflow/DOM owner checks。Artwork adapter fixture 沿用 `tests/batch262-home-artwork.browser.py`，10/10 PASS。
- 永久文案政策仍由 `docs/UI_COPY_POLICY.md` 管理，沒有新增裝飾眉標或工程解說到產品 UI。



# Batch259 設計落地追蹤補充

## 正式版視覺落地 Gate
- 流程與驗收閘門：`docs/DESIGN_LANDING_FLOW.md`。
- 已確認差距登記：`docs/DESIGN_GAP_REGISTER.md`。
- 正式導航 owner：`src/ui/app-shell.js` 的 `#app-shell-nav`。
- 正式布局 CSS：`src/styles/ui-design-landing.css`，由 `src/index.html` 最後載入。
- 首頁 active state：`#app-back[aria-current="page"]`；其他 route 由 `[data-nav-page][aria-current="page"]` 表示。
- 新 browser test：`tests/batch259-design-landing.browser.py`，目前 17/17 PASS。
- 舊正式 shell 回歸：`tests/app-shell.browser.test.py`，更新正式 runtime role 數量契約為 36，最終 150/150 PASS。
- 截圖證據：`artifacts/batch259-design-landing/production-home-{1920x1080,1440x900,390x844}.png`。

## 重要限制
本批只完成全域骨架的第一個正式版切片。首頁主要視覺仍有與目標不符的空白／圓盤比重，Catalog 原型尚未接正式 Catalog／AudioService。此處的自動化測試是導航、viewport 與例外驗證，不是像素級或人工視覺驗收。

## Batch258：Learning／Settings／Multiplayer route-aware 可見狀態
- Browser harness：`tests/batch258-route-skin-visible.browser.py`；證據：`artifacts/batch258-regression/route-skin-visible-state.json` 與每頁截圖。
- Routes：Home、Catalog、Quiz、Results、Learning、Settings；只計實際可見的 runtime DOM role targets。48 個 role-route 配對均測 apply、missing-asset fallback、reset 與 CSS token scope。
- Learning owner：`#statistics-dashboard`、`#statistics-summary`、`#learning-history-list`、`#learning-review-list`、`#statistics-status`。這驗證真實容器與 status semantics，不虛構學習統計。
- Settings owner：`#page-settings` 內 checkbox/select 及 `#backup-restore-panel`。沒有真正 Settings range input，因此 `settings.slider` 仍不可接線。
- Multiplayer owner：`#multiplayer-panel` 位於 Quiz route；status `#multiplayer-status`、source `#multiplayer-source`、message `#multiplayer-message`、error `#multiplayer-error`。本地 DOM 驗證不等於 live server multi-client E2E。
- 六個 route 390px 無水平溢位，`aria-current` 同步，reduced-motion recognized，0 uncaught page errors。

## Skin role：Catalog 主要搜尋／篩選面板（Batch256）
- 實作 owner：`src/ui/catalog-browser.js` 的 `buildCatalogWorkspace()` 建立 `.catalog-sidebar`，並將 `.catalog-primary-controls` 移入該 sidebar。
- Skin runtime target：`.catalog-sidebar > .catalog-primary-controls`。
- CSS token：`--amq-skin-role-catalog-filter-background`，consumer 位於 `src/styles/ui-shell.css`；只作用於主要搜尋／篩選面板，不套用整個 `#catalog-browser`。
- Fallback：原面板背景 `#1d1f28`／後續 shell 規則保留；Skin missing target 時 adapter 回報 `role-target-unavailable`，不向全域退回。
- 回歸證據：`tests/skin-theme-adapter.test.cjs`（apply/reset/blob revoke、missing target），`tests/batch254-skin-role-production.browser.py`（正式 DOM role matrix）。

# UI Traceability：首頁、跨頁導航與成績結果

更新日期：2026-10-29；最新驗證批次：Batch251

## 首頁主要入口與作品視覺（Batch260–262）
- 實作 owner：`src/ui/app-shell.js`；Home 不再使用舊圓盤選單。
- 主要節點：`.home-feature`、`#home-feature-art`、`#home-feature-title`、`#home-feature-work`、`.home-main-actions`、`#home-recent-list`。
- 契約：六個主要目的地直接可見；近期紀錄只讀 `playbackHistoryStore`，無紀錄時顯示真實空狀態，不合成歌曲。Home artwork 以 source + workId 對正式資料索引取得 artworkRef，再使用既有 adapter；不從歌曲標題猜 URL。
- 回歸證據：`tests/app-shell.browser.test.py`、`tests/batch262-home-catalog.browser.py`、`tests/batch262-home-artwork.browser.py`；四尺寸截圖位於 `artifacts/batch262-home-catalog/`。

## 跨頁導航
- 實作 owner：`src/ui/app-shell.js` 的 `navigate()`。
- 入口：首頁圓形選單、sticky navigation、返回首頁、結果頁 CTA、Alt+Left。
- 契約：有效跨頁切換更新單一 `currentPage`、隱藏非目標頁、同步 `aria-current`、將焦點移至目的頁內容，並預設重置 `window.scrollY` 至 0；只有明確 `options.scroll === false` 可略過頁首重置。
- Settings `data-settings-jump` 是頁內導航，不應經過跨頁頁首重置；它會將焦點移至指定區塊標題並捲動至該區塊。
- 回歸證據：`artifacts/batch232-regression/app-shell-browser.log`（Batch232 捲動重置）及 `artifacts/batch233-regression/app-shell-browser.log`（跨頁、Alt+Left、Settings 區塊跳轉）。

## 成績結果頁
- 實作 owner：`src/ui/app-shell.js` 導航與既有 `src/ui/quiz-panel.js`／結果 UI。
- 主要節點：`#results-workspace`、`#results-empty`、`#results-return-to-quiz`、`#quiz-round-results`。
- 契約：沒有可顯示結果時應呈現真實空狀態；主要 CTA 導向猜歌設定並把焦點放在實際可見的 `#quiz-setup-heading`；不得虛構分數、排名、PP 或把揭曉／未播放跳過視為答題成績。
- 回歸證據：`tests/results-ui.contract.test.cjs`、`artifacts/batch233-regression/focused-node.log`、`artifacts/batch233-regression/app-shell-browser.log`。Browser fixture 對長標題／metadata 的測試只驗證版面契約，不代表真實資料持久化驗收。

## 尚未驗收
- HTTP-origin IndexedDB save/reload 受 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。
- 真實 `.osk`、live 曲庫／封面 provider／音訊與實機 UI 未驗收。
- Candidate302／Candidate382 Stage 0 基準檔未包含於本工作副本，未宣稱相容。


## Catalog 載入、重試與選取（Batch247）
- 實作 owner：`src/ui/catalog-browser.js`；搜尋／篩選／排序／分頁的單一狀態 owner 是 `createController()`，資料載入結果由 runtime 回傳並與共享 state store 一起呈現。
- 契約：runtime 完成但回傳未接受、非 stale、沒有明確 error 的結果，不得被呈現為空曲庫成功，也不得因共享 store 殘留 `dataStatus=loading` 而永久顯示載入中。此情況產生 request-local `DATA_LOAD_NOT_ACCEPTED`，狀態、錯誤提示、空狀態與 retry 文案一致。
- Retry：reload handler 只在 mount 時註冊一次；retry 不清除 controller 的 query／filter／sort state，成功取得新 catalog 後由同一份狀態重新篩選。`catalog-reload` 在桌面／390px 的 computed min-height 至少 44px。
- 鍵盤與選取：方向鍵／Enter 仍由每列的 keydown handler 與 `selectRecord()` 共用單一 selection owner；Enter 僅選取，不會隱式播放音訊；checkbox 點擊阻止 row click 的事件冒泡。既有 integration tests 驗證詳細資訊與選取同步、篩選移除所選列時清除 stale details 並恢復焦點。
- Artwork：只使用 `artworkAdapter.getArtwork(record)` 的安全 provider 結果；缺件、拒絕、不安全 URL 或 image error 皆退回作品標題衍生 mark 與 AMQ／EMQ／MIX 來源標籤，不使用 OSK 角色圖假裝封面。
- 回歸證據：`artifacts/batch247-regression/`；Catalog integration/controller/mode-switch/layout contracts、Home/Catalog Chromium 22/22、formal app-shell 150/150。
- 未驗收：Chromium 使用 inline assets／fixture；live provider／真實曲庫、HTTP-origin IndexedDB、實機觸控及 Candidate302／Candidate382 Stage 0 仍未驗收。


## Quiz round pointer clear failure（Batch248）
- 狀態 owner：`src/persistence/quiz-history-store.js` 的 `beginRound()` 回傳 `previousResultClear`／`warning`；`src/engine/quiz-session.js` 將非致命保存問題投影到 `persistenceWarning`；`src/ui/quiz-panel.js` 只呈現 warning，不推導分數。
- 契約：新回合可在 pointer clear failure 時繼續，但不得把失敗說成清除成功；若舊 pointer 仍留在 durable storage，Results 明示 reload 後恢復的舊回合不代表本輪成績。逐題明細仍嚴格按 `roundId` 過濾，正確率只計算已保存的計分目標。
- 回歸證據：`tests/quiz-history-store.test.cjs`、`tests/quiz-session.test.cjs`、`tests/results-ui.contract.test.cjs`；`artifacts/batch248-regression/quiz-results-browser.log`。
- 限制：Chromium browser harness 使用 inline assets／fixture，並未證明真實 HTTP-origin IndexedDB durable reload；該探測仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。


## Learning Center SRS persistence／recovery（Batch249）
- Owner：`src/persistence/srs-store.js` 的 `getPersistenceStatus()`；`src/ui/statistics-dashboard-panel.js` 的 `checkReadErrors()`／`getSnapshot()`。
- 契約：AMQ／EMQ SRS 任一來源若 blocked、error、recoveryAvailable 或 persisted=false，dashboard 不可把目前可能不可靠的排程快照顯示成正常「統計已更新」；Playback History persisted=false 亦列為異常。
- SRS 損壞排程被 quarantine 後，原始 bytes 留在 recovery key；當使用者成功保存有效替代排程或 flush 成功時，只清除 store 記憶體中的 recovery warning，不刪除 recovery backup。
- 回歸證據：`tests/statistics-dashboard-panel.test.cjs`（SRS write error／recovery state）、`tests/srs-store.test.cjs`（成功持久化後 warning 清除且 recovery bytes 保留）、`artifacts/batch249-regression/focused-node.log`。
- 限制：Node fixture 驗證狀態契約，不替代真實 HTTP-origin IndexedDB save/reload；該環境 gate 仍受 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。


## Settings Backup／Restore touch target（Batch250）
- Owner：`src/ui/backup-restore-panel.js`；正式樣式由 `src/styles/ui-shell.css` `.app-page--settings .backup-restore-actions button` 控制。
- 契約：匯出、預檢、還原、曲庫更新與 Skin 匯入的 Settings controls 最小高度 44px；桌面／390px 不得造成水平溢位。
- 回歸證據：`tests/ui-shell-css.contract.test.cjs`、`tests/batch250-backup-restore.browser.py`、`artifacts/batch250-regression/backup-restore-browser.log`。Chromium 直接量測三個正式按鈕的 computed min-height 與 bounding rect。
- Backup/restore persistence contract：匯入先驗 checksum/schema/key allowlist，commit failure 盡力 rollback，rollback failure 以嚴重警告顯示；Storage fixture 測試不構成真實 HTTP-origin IndexedDB acceptance。


## 跨頁 route focus 與 Settings 控制項（Batch251）
- **Owner：** `src/ui/app-shell.js` 的 `navigate()`；頁面本身與資料模組維持長駐，路由切換只隱藏非目標頁，不重建 Catalog／Quiz／Learning／Settings stores。
- **焦點契約：** route 目的頁若第一個目標為 `h2`／`h3` 等非原生可聚焦元素，必須先補 `tabIndex=-1` 再呼叫 `focus({preventScroll:true})`。不可把一般 heading 直接呼叫 `focus()` 當作焦點已移動。Quiz 仍把焦點放在 `#quiz-setup-heading`；Results CTA 導回 Quiz 時保持同一行為。
- **狀態契約：** Catalog query 在 Catalog → Quiz → Catalog 後保留；跨頁捲動預設回到頂部；Settings `data-settings-jump` 是頁內導覽，應聚焦指定區塊 heading 並捲動至該區，不得被跨頁 scroll reset 覆蓋。
- **觸控尺寸：** Settings quick-nav、統計排序按鈕、快捷鍵錄製、工作區恢復預設與 `#skin-mapping-reset` 最小高度 44px；Browser 量測可見 Settings／nav controls 43 個，0 個低於 44px。
- **回歸證據：** `tests/app-shell-navigation.contract.test.cjs`、`tests/ui-shell-css.contract.test.cjs`、`tests/batch251-cross-page.browser.py`、`artifacts/batch251-regression/cross-page-browser.log`（45/45）、`app-shell-browser.log`（150/150）。
- **Responsive／ARIA：** 390px Home／Catalog／Quiz／Results／Learning／Settings 無頁面水平溢位；首頁主選單 keyboard Enter／Escape、`aria-expanded`、各頁 `aria-current`、Quiz audio／Skin status live semantics 與 reduced-motion stylesheet 均有回歸證據。
- **外部 gate：** Browser 使用 inline local assets／fixtures，不能代表真實 HTTP-origin IndexedDB、live audio／catalog／artwork、實機觸控或 Windows 驗收。48 visual roles 仍為 35 wired／13 unsupported，逐角色 apply/fallback/reset 尚未完成。

## Batch252 Skin 相容性證據補記（2026-10-29）
- 真實 OSK audit：`artifacts/batch252-regression/aristia-hima-osk-audit.json`。`Version=latest` 只作 metadata；119 images、0 sounds；98 Mania references checked、0 resolved、98 missing。
- `@2x` logical size、state-pair、multiply RGBA 與 explicit edge-repeat 是分離的 AMQ contracts，不代表原生 osu!stable compositor。
- `nativeStableFidelity.multiplicativeTint`、`songselectTopEdgeRepeat` 及 Canvas native fidelity 維持 false。
- 35 wired roles 尚未逐角色 browser apply/fallback/reset；13 unsupported roles 保持 unsupported。


## Batch253 角色稽核證據隔離
- `tools/audit-visual-role-coverage.cjs --output-dir <path>` 可將 JSON／Markdown 報告輸出至指定批次目錄；不帶參數時仍維持原有 Batch245 輸出位置，以保留既有測試相容性。
- 本批稽核報告位於 `artifacts/batch253-regression/visual-role-audit/`。48 roles、35 wired、13 unsupported；35 CSS consumers、31 有直接測試檔線索、33 roles 有一個以上靜態 gap。
- `withTestEvidence` 僅表示測試原始碼中找到 role ID/token 字串，不保證測試已執行該角色的 browser apply/fallback/reset；逐角色 browser matrix 仍是後續待辦。


## Batch254 正式 DOM 逐角色 Skin runtime matrix
- `tests/batch254-skin-role-production.browser.py` 使用完整 `src/index.html` 與正式 runtime 啟動 Chromium，不以 synthetic DOM 代替正式掛載 DOM。35 runtime role selectors 全部找到 target；每個 role 分別套用可解碼 PNG、以缺失 asset 驗證 fail-closed warning、再 reset 並確認 CSS token／`data-amq-skin-role-active` 清除與 blob URL revoke。
- 結果：35/35 apply、35/35 missing fallback、35/35 reset，0 page errors。JSON `artifacts/batch254-regression/skin-role-production-dom.json`。初始 Home route 僅 4 個目標可見，其餘是掛載但隱藏的其他頁／狀態節點，仍需 route-aware 可見狀態驗收。
- `tests/batch254-skin-role-matrix.browser.py` 的 selector fixture matrix 也 35/35/35 PASS，但僅屬輔助診斷，不取代正式 DOM 結果。
- 13 unsupported roles 沒有被任意接線；native osu!stable fidelity 仍 false。


## Batch255 Skin role semantics
- 13 unsupported roles 已依 AMQ 語義逐項分級，詳見 `docs/BATCH255_UNSUPPORTED_ROLE_AUDIT.md`。
- Catalog filter background、random action、Settings slider 是候選，不代表已接線；需先確認精確 target 與 CSS consumer。
- 封面必須來自作品 artwork provider；正確／錯誤回饋必須由 AMQ 答題結果狀態驅動；osu! ranking grade 不可當作答對狀態、AMQ 熟悉度或未定義的 AMQ 難度。
- 方向決策：新版 AMQ 獨立開發，Candidate302／Candidate382 不再是必要基準。
- Batch255 Chromium route coverage：45/45 PASS；這是跨頁導航與響應式證據，不代表全部 Skin roles 已逐頁完成可見狀態視覺驗收。


## Batch257 route-aware Skin 可見狀態矩陣（2026-10-29）
- Browser harness：`tests/batch257-route-skin-visible.browser.py`。透過 Home pie／app-shell navigation 進入 Home、Catalog、Quiz、Results；selector 只有在目標 route 可見時才計入。
- 證據：`artifacts/batch257-regression/route-skin-visible-state.json` 與四張 route screenshot。Home 4、Catalog 15、Quiz 9、Results 4 可見 roles；共 32 role-route pairs，每個均驗證 PNG apply、missing asset fallback、reset 與 token 不外洩。
- Route matrix 64/64 PASS；跨頁 45/45；Home/Catalog 22/22；production role matrix 36/36 apply／fallback／reset。
- Results 空狀態時 `results.primary-action` 可見；`results.panel` 因沒有實際結果而隱藏，沒有計入可見覆蓋。不可為測試製造假成績。
- 下一步補 Settings／Learning Center／Multiplayer route visible state；live provider、HTTP-origin storage 與實機驗收仍分開追蹤。


## Batch260 Home／Catalog 視覺與文案追蹤

- Home 主要入口：`src/ui/app-shell.js` → `.home-main-actions`，六個入口不依賴隱藏互動。
- Home 主視覺：`.home-feature`；skin roles `app.home.welcome-visual`、`app.home.primary-action` 已接到新 DOM。
- 最近學習空狀態：`#home-recent-empty`，不得生成虛構紀錄。
- Catalog 三欄 owner：`src/ui/catalog-browser.js` → `.catalog-sidebar`／`.catalog-main-list`／`.catalog-detail-column`；資料仍由正式 shared Store／query index 提供。
- UI 文案規則：`docs/UI_COPY_POLICY.md`；Batch260 Browser 驗證 `tests/batch260-design-copy.browser.py`。
- 未結案：opaque-origin 截圖無法證明 IndexedDB／真實曲庫工作正常；loopback HTTP 被環境政策阻擋。


## Home playback history／feature（Batch261）
- Owner：`src/ui/app-shell.js` 的 `renderHomeRecent()`；讀取 `AMQPersistence.playbackHistoryStore`，只顯示 store 回傳的最近 6 筆紀錄。
- 最新紀錄映射到 `#home-feature-title` 與 `#home-feature-work`；列表由 `#home-recent-list` 持有。文字使用 `textContent`，不把使用者／資料內容當 HTML 注入。
- Store 無資料時顯示 `尚無學習紀錄`，不產生假曲目；history update event 與 store subscription 觸發重新渲染。
- `workId` 尚未與正式 catalog work record 完成映射，故本批不宣稱 Home 封面已接通。來源色塊／來源字樣只是 fallback，不是正式作品封面。
- 回歸：`tests/batch261-home-history.browser.py`（測試 fixture 6/6）；`tests/batch261-home-catalog.browser.py` 四尺寸 47/47。

## Catalog desktop dock／density（Batch261）
- Owner：`src/styles/ui-design-landing.css`；保留 `src/ui/catalog-browser.js` 建立的單一 workspace 與正式 store。
- 桌面三欄使用篩選／中央列表／右側詳情；底部播放 Dock 固定並預留內容底部空間；1180px 以下轉兩欄，760px 以下轉單欄與流式播放器。
- `page.set_content` 瀏覽器截圖仍為 opaque origin，Catalog IndexedDB 錯誤不是 live data acceptance。HTTP-origin 仍需允許 localhost 的環境。


## Home artwork mapping（Batch262）
- 播放歷史 owner：`src/persistence/playback-history-store.js`；每筆使用 source-scoped `source` + `workId`，不把 `songId` 當作品 ID。
- 明確作品解析：`src/data/source-runtime.js` 的 `resolveArtworkRecord(source, workId)`。AMQ 以正式 anime row 的 ANNID 建立 `artworkRef`；EMQ 以正式 work row 的 VNDB ID 建立 `artworkRef`。無效／未知來源或 workId 回傳 `null`，不做標題搜尋或猜 URL。
- Provider：`src/app.js` 將同一個 `artworkAdapter` 與 resolver 接入 `src/ui/app-shell.js`；實際 URL 仍由 ANN/VNDB adapter 回傳並由 artwork adapter 做 HTTPS 正規化。
- UI：`#home-feature-art` 與 `.home-recent-art` 只在 provider 回傳安全 URL 後建立 `<img>`；image error 會退回 AMQ/EMQ 標記。`data-artwork-status` 與 `data-artwork-provider` 用於狀態 traceability。
- 測試：`tests/source-runtime.integration.test.cjs` 驗證正式資料 workId mapping；`tests/batch262-home-artwork.browser.py` 使用明確 fixture adapter 驗證 DOM 顯示，不代表 live provider 網路已驗收。
- 未驗收：HTTP-origin IndexedDB、live ANN/VNDB 請求、真實封面成功率與人工視覺驗收。


## Batch265：Quiz 密度、Multiplayer 與 Results
- Quiz 設定 owner 仍為 `#quiz-panel > .quiz-setup-section`；advanced filter 仍是原生 `details.quiz-filter-panel`。
- Multiplayer owner 仍是 `#multiplayer-panel`、`#multiplayer-status`、`#multiplayer-source`、`#multiplayer-message`、`#multiplayer-error`；只調整表面與間距。
- Results owner 仍是 `#results-workspace`、`#results-empty`、`#quiz-round-results`、`#quiz-round-results-list`；空狀態不產生成績。
- CSS contract：`tests/batch265-visual-structure.contract.test.cjs` 5/5；Results 7/7；Quiz UI state 5/5；Quiz visual regression 38/38。
- 未驗收：App Shell browser regression 本次超時；正式 Results/Multiplayer 四尺寸視覺與人工 osu! gate 未完成。


## Home／Catalog compact visual pass（Batch267）
- **Home layout owner：** `src/ui/app-shell.js` 的 `.home-dashboard`、`.home-feature`、`.home-main-actions`、`#home-recent-list`；本批只改 `src/styles/ui-design-landing.css` 的視覺幾何，不新增播放紀錄或作品狀態 owner。
- **Home 契約：** 六個主入口桌面單列、平板三欄兩列、手機兩欄三列；空歷史仍顯示 `#home-recent-empty`，不得生成假曲目。Artwork 仍只由 playback history `workId` → `resolveArtworkRecord()` → 既有 adapter/provider 呈現。
- **Catalog layout owner：** `src/ui/catalog-browser.js` 的 `.catalog-sidebar`／`.catalog-main-list`／`.catalog-detail-column` 與既有 `#free-player-dock`。本批只調整正式 CSS，未改 query/index/store/audio 接線。
- **尺寸與證據：** `tests/batch267-home-catalog.browser.py`、`artifacts/batch267-home-catalog/`；63/63 checks PASS。Catalog workspace 和六筆歌曲/SVG 封面由測試建立，只驗證 CSS/DOM layout；測試為控制啟動成本省略 data/runtime bundles，不證明正式資料成功。
- **仍未驗收：** live ANN/VNDB artwork、HTTP-origin IndexedDB、正式 Catalog 正常資料與音訊、人工 osu! 參考畫面比較、Windows／實機。

## Batch269 Catalog 視覺追蹤
- `#page-catalog .catalog-list-wrap`：viewport-bounded list region，四尺寸檢查。
- `.catalog-title-cell--artwork .catalog-artwork`：desktop 46×60、tablet 42×56、mobile 38×50。
- `#catalog-rows > tr[aria-selected="true"]`：左側強調線＋選取背景；不另建 selected-state owner。
- `.catalog-selection-cover-image`：3:4 artwork frame；provider／live load 尚未驗收。
- 參考依據：`docs/OSU_SONG_SELECT_REFERENCE_BATCH269.md`。


## Batch270：osu! 主選單參考與 Home 新構圖
- 官方參考圖本體：`artifacts/osu-reference/osu-main-menu.jpg`、`osu-intro-screen.jpg`、`osu-song-selection.jpg`、`osu-multiplayer-lobby.jpg`、`osu-game-modifiers.jpg`；來源與 AMQ 對應見 `docs/OSU_UI_REFERENCE_BATCH270.md`。
- Home 唯一 DOM owner 仍為 `src/ui/app-shell.js` 建立的 `.home-dashboard`、`.home-feature`、`.home-main-actions`、`#home-recent-list`；CSS 幾何由 `src/styles/ui-design-landing.css` 控制。桌面為主視覺左、縱向功能選單右、近期學習在下；900px 以下轉堆疊，手機主要入口兩欄。
- `renderHomeRecent()` 仍是 playback history 與 artwork 的唯一 owner。API 不存在時也呼叫原 renderer，設定 `#page-home[data-history-state="empty"]`，不生成假作品。真實封面仍須 playback history `workId` → `resolveArtworkRecord()` → 原 artwork adapter/provider。
- Catalog owner 與 Batch269 相同：`.catalog-sidebar`、`.catalog-main-list`、`.catalog-detail-column`、`#free-player-dock`；沒有建立第二個 query/index/store/audio owner。
- Browser evidence：`tests/batch270-home-catalog.browser.py` 77/77 PASS；此測試省略 heavyweight data/runtime bundle，Catalog 六首歌及 SVG artwork 是 layout fixture，opaque-origin error screenshots 是環境錯誤證據，不能視為 live catalog。
- 尚未落地：osu! Multiplayer Lobby 對應的房間列表視覺切片，以及 Mod／遊戲條件控制的產品狀態 owner 盤點。


## Batch273 Multiplayer Skin component mapping

| Stable 參考區域／AMQ 元件 | 正式 DOM owner | state/API owner | Skin role | CSS consumer | 驗證 |
|---|---|---|---|---|---|
| 大廳來源 tabs | `#multiplayer-mode-tabs[data-skin-component="multiplayer.lobby.source-tabs"]` | `src/ui/multiplayer-panel.js` 的 source filter | `multiplayer.lobby.tab` | `--amq-skin-role-multiplayer-lobby-tab` | `tests/batch273-multiplayer-skin-visible.browser.py` |
| 房間清單面板 | `.multiplayer-room-browser[data-skin-component="multiplayer.lobby.room-list"]` | server `client.listRooms()` projection | `multiplayer.lobby.room-list` | `--amq-skin-role-multiplayer-lobby-room-list` | 同上；空清單 DOM，不代表 live rooms |
| 建立房間面板 | `.multiplayer-create-room[data-skin-component="multiplayer.lobby.create-room"]` | 原有 room command service | `multiplayer.lobby.create-room` | `--amq-skin-role-multiplayer-lobby-create-room` | 同上 |
| 房間成員列表／列背景 | `#multiplayer-players[data-skin-component="multiplayer.member-list"]`，動態列有 `multiplayer.member-item` ID | 原有 room snapshot 的 `state.players` | `multiplayer.member.item` | `--amq-skin-role-multiplayer-member-item` 由列表繼承至列 | 明確標記 fixture 的 browser matrix；未驗收 live server |
| 準備狀態 | 同一 `multiplayer.member-list` 範圍；動態狀態節點有 `multiplayer.ready-state` ID | 同一 room snapshot `player.ready` | `multiplayer.ready-state` | `--amq-skin-role-multiplayer-ready-state` 由列表繼承至狀態節點 | 明確標記 fixture 的 browser matrix；未驗收 live server |

Batch273 的 Skin role apply/fallback/reset 是 UI 元件映射測試，不表示伺服器資料、玩家列表或多人音訊已通過端到端驗收。

## Batch273 Home 主選單按鈕視覺映射

| Stable 參考區域 | 正式 AMQ DOM owner | 狀態／行為 owner | Skin component | CSS／驗證 |
|---|---|---|---|---|
| Stable Main Menu 右側斜切主按鈕 | `src/ui/app-shell.js` 產生的 `.home-main-action[data-go-page]` | 原有 `data-go-page` 導航事件委派；沒有新建路由狀態 | 現有 `app.home.primary-action` 角色／共用 button tokens | `src/styles/ui-design-landing.css` 的 Batch267 正式 Home 區塊；`tests/batch273-home-menu.browser.py` 四尺寸 81/81 |
| 按鈕尾端圖示 | `.home-main-action > .home-action-icon` | 圖示只作導航語義提示，不承載第二份狀態 | 跟隨主按鈕容器樣式；保持 DOM 獨立可替換 | computed `order:2`／`margin-left:auto` 由 browser matrix 驗證 |

參考圖：`artifacts/osu-reference/osu-main-menu.jpg`。本批實作了斜切剪影、紫色漸層與尾端圖示，不宣稱已復刻 Stable 原始素材／動畫；首頁主視覺真實 artwork 仍未驗收。`prefers-reduced-motion: reduce` 時停用主按鈕 transition／transform。

## Batch274 blocker evidence refresh
- Home/Catalog 最新四尺寸 browser matrix：`tests/batch273-home-menu.browser.py`，81/81 PASS；但這只證明 layout/DOM，不代表真實 artwork 或正式 catalog data。
- Multiplayer lobby：`tests/batch272-multiplayer-lobby.browser.py`，32/32 PASS；仍為空 server room list，不代表已連接部署 server。
- Multiplayer Skin roles：`tests/batch273-multiplayer-skin-visible.browser.py`，5 roles apply/fallback/reset/scope 5/5，0 page errors；圖片解碼 test seam 不等於實際 OSK 檔案完整性驗收。
- Native audio：`tests/audio-service.native-browser.test.py` 5/5，Chromium `HTMLAudioElement` 對生成 WAV 成功解碼並取得 duration、fallback 和 stop 清理有效；headless 狀態停留 `ready`，不代表可聽輸出或外部 AMQ/EMQ provider 可用。
- HTTP-origin blocker：`artifacts/batch274-regression/http-origin-blocker.txt`。127.0.0.1 與容器非 loopback 介面 HTTP navigation 都遭 `ERR_BLOCKED_BY_ADMINISTRATOR`，真實 IndexedDB/save/reload 仍未驗收。
- Node test suite：`artifacts/batch274-regression/node-suite-summary.json`，98 個 test files 分 20 組，303/303 subtests PASS；原始 monolithic invocation 不宣稱通過。


# Batch275 Home Stable構圖與Artwork／Skin追蹤

| Stable 參考區域 | AMQ DOM owner | State／API owner | Skin component／role | CSS consumer | 測試／證據 | 狀態 |
|---|---|---|---|---|---|---|
| 中央偏左大型圓形主視覺 | `#home-feature-art`、`.home-brand-mark` | `app-shell.js` 的 playback-history owner；`setArtworkAdapter()`；`renderHomeRecent()` | `home.feature.artwork`、`home.logo`；`app.home.welcome-visual` | `src/styles/ui-design-landing.css` 圓形 surface；`src/styles/ui-shell.css` welcome visual token | `tests/batch273-home-menu.browser.py` 85/85；`tests/batch275-home-artwork.browser.py` 14/14；`artifacts/batch275-home-menu/home-1920x1080.jpg` | 構圖改善；人工 Stable gate 未通過 |
| 右側六條斜切主入口 | `.home-main-action[data-go-page]` | 唯一 `navigate()` 委派，不另建 route state | `home.menu.catalog/quiz/learning/profile/results/settings`；共用 `app.home.primary-action` | `src/styles/ui-design-landing.css` 斜切按鈕；`src/styles/ui-shell.css` role background image | Home/Catalog 85/85；`tests/skin-theme-adapter.test.cjs` 21/21 | role 已接線；人工視覺 gate 未通過 |
| Feature CTA | `.home-feature-action` | 原有 `data-go-page="catalog"` navigation | `home.feature.action`；共用 `app.home.primary-action` | 共用 Skin role token | Skin theme adapter 21/21 | 已接線 |
| 真實作品封面 | `#home-feature-art img`、`.home-recent-art img` | playback history + `runtimeBundle.resolveArtworkRecord()` + `artworkAdapter.getArtwork()` | `app.home.welcome-visual` 只管 artwork surface；作品圖片仍由 provider 結果提供 | 圓形裁切與 `object-fit:cover` | `tests/batch275-home-artwork.browser.py` 14/14 為明確 fixture | Live ANN/VNDB 尚未驗收；不得標成正式封面通過 |

**Artwork fallback 規則：** 沒有歷史時顯示原創 AMQ 品牌圖形，不顯示假作品；provider 無結果／圖片 decode error 時回到 fallback，並清除舊的 provider／attribution/source URL metadata。Fixture 的來源網址只用來測試 DOM metadata，不代表外部來源真的被訪問。


# Batch276 Artwork provider／Catalog load state追蹤

| 功能 | Owner | 狀態契約 | 來源追蹤 | 測試證據 | 剩餘限制 |
|---|---|---|---|---|---|
| Catalog 列表封面 | `src/ui/catalog-browser.js` `renderLibrary()` | `missing → loading → available` 只在 `img.load` 成功後轉換；`error` 恢復 fallback 並移除 source link | `createArtworkSourceLink()` 只允許 HTTPS source URL；link 只在 load 成功後顯示 | `tests/catalog-browser.integration.test.cjs`、`tests/ui-shell-css.contract.test.cjs` | 仍需 live provider 與正式曲庫驗收 |
| Catalog 選取詳情封面 | `renderSelectionDetails()` | 共享相同 loading/load/error 狀態；以 `selectionArtworkSequence` 擋 stale response | attribution link 綁定目前成功載入的 image | Catalog integration test | 尚無 live image decode證據 |
| AMQ artwork | `src/integrations/artwork-provider-factory.js` | ANN stored ANNID 優先；AniList 僅明確 crosswalk fallback，不做 title search | `ANN`／`AniList` provider + attribution/source URL | `tests/artwork-provider-factory.test.cjs`、`tests/app-artwork-lifecycle.integration.test.cjs` | Live endpoint/CORS/rate-limit 尚未驗收 |
| EMQ artwork | `artwork-provider-factory.js` + `vndb-adapter.js` | 只用明確 VNDB ID；缺失即 fallback | VNDB source URL + attribution | artwork provider factory tests | Live VNDB endpoint/cover 尚未驗收 |
| Crosswalk provider ownership | `artwork-provider-factory.js` 建立並持有，app 將同一 instance 傳給 Catalog | provider bundle dispose 時 dispose crosswalk；Catalog 不 dispose 外部注入的 provider | 單一 shared instance，避免重複 fetch/cache/lifecycle | app artwork lifecycle + Catalog integration tests | 跨層 live runtime仍受 browser navigation policy 阻擋 |


## Batch277 Artwork diagnostics traceability

| Provider pipeline region | Runtime owner | Diagnostics | Test evidence | Acceptance limit |
|---|---|---|---|---|
| AMQ anime artwork (ANN primary → explicit AniList crosswalk) | `src/integrations/artwork-provider-factory.js` | `getDiagnostics()` records provider/outcome/stable code/kind/source; no title/ID/URL | `tests/artwork-provider-factory.test.cjs` | Fixture contracts only; live ANN/AniList endpoint, image decode and attribution not accepted yet |
| EMQ VN artwork | Same factory; explicit `vndbId` only | Records missing crosswalk, unavailable adapter, missing cover or stable provider error code | `tests/artwork-provider-factory.test.cjs` | Live VNDB not verified |
| Shared runtime adapter | `src/integrations/artwork-adapter.js`, composed in `src/app.js` | `getDiagnostics()` projects a bounded provider event list and cache/pending/disposed counters through an allowlist | `tests/artwork-adapter.test.cjs`, `tests/app-artwork-lifecycle.integration.test.cjs` | Does not imply browser-origin or production image request succeeded |


| Source data mapping coverage | `src/data/assets/data.js`／`emq-data.js` → `source-mappers.js` | `tools/audit-artwork-coverage.cjs` | `artifacts/batch277-regression/artwork-coverage-audit.json` + `tests/artwork-coverage-audit.test.cjs` | AMQ ANNID 99.72% work coverage; EMQ VNDB ID 98.87%; IDs do not prove live image load |


## Batch278 real-origin acceptance traceability

| Target | Formal owner | Runner | Report | State |
|---|---|---|---|---|
| Skin theme IndexedDB save/reload | `src/persistence/skin-theme-store.js` (`skinThemeStore`) | `tests/approved-runner-live-acceptance.py` on `.github/workflows/amq-acceptance.yml` | `artifacts/approved-runner-acceptance/acceptance-report.json` | Harness added; not executed on hosted runner |
| Live ANN response and returned image decode | `src/integrations/ann-artwork-adapter.js` + explicit ANNID from `window.DB` | Same hosted browser runner | Same report `liveAnnArtwork` | Harness added; network/CORS outcome pending |


## Batch279 Home desktop density adjustment
- Reference: `artifacts/osu-reference/osu-main-menu.jpg`; comparison target: `artifacts/batch279-home-menu/home-1920x1080.jpg` and other viewport captures.
- Formal owner remains `#page-home .home-dashboard`, `.home-feature`, `.home-main-actions`, `.home-recent`; no new state owner.
- The six-item menu is vertically centered and capped at 690px on desktop so larger viewport height does not stretch each button without bound. Empty history remains an honest status and is visually compact.
- Browser layout contract: `tests/batch273-home-menu.browser.py` 87/87 PASS. Catalog in this harness is a layout fixture, not live data. Human osu! Stable visual gate remains open.


## Batch280：Home 全視窗 chrome 與 route navigation
- Home 正式 owner：`src/ui/app-shell.js` 的 `navigate()`；`body[data-current-page="home"]` 是 route projection。Home route 隱藏 `.app-header` 與 `#app-shell-nav`；離開 Home 時顯示精簡水平導覽。沒有新增第二份 route state。
- Home layout：`src/styles/ui-design-landing.css`，`.home-dashboard` 全 viewport、左側主視覺、右側六入口；底部 `.home-recent` 不再占用首頁空間。最近學習仍保留原 store owner 與 render function，供後續獨立入口／Skin mapping 工作接續。
- Recent entries：button semantics 保留；`displayText()` 清理 null／undefined／NaN；`home.recent.item`、`home.recent.artwork`、`home.recent.title` 為穩定 DOM component IDs。這些 IDs 尚未全部映射到 Skin Resolver role registry，狀態為部分完成。
- Catalog Dock：`#page-catalog #free-player-dock` 桌面 left/right 12px，移除原固定側欄 offset；真實列表遮擋仍需進一步驗收。
- Evidence：`tests/batch273-home-menu.browser.py` 102/102 四尺寸；`tests/batch280-home-chrome.contract.test.cjs` 5/5；focused Node 35/35；Architecture 1351/0。`tests/app-shell.browser.test.py` 本批逾時，不算通過。


## Batch281 Home brand icon and Skin target
- User design request: replace the oversized “AMQ” letters with a music-note + question-mark mark; do not copy osu!'s palette.
- Production source: `src/assets/amq-note-question.png`; usage in `src/ui/app-shell.js` via `.home-brand-mark` and `.app-brand-icon`; fallback uses the same brand image when no playback-history artwork exists.
- CSS consumer: `src/styles/ui-design-landing.css`, `--amq-skin-role-app-home-logo` with original image fallback.
- Skin runtime mapping: `src/skins/theme-adapter.js` role `app.home.logo` targets `.home-brand-mark, .app-brand-icon`; role is explicitly replaceable and resettable.
- Evidence: `tests/skin-theme-adapter.test.cjs` role apply/reset; `tests/batch280-home-chrome.contract.test.cjs` brand asset contract; `tests/batch273-home-menu.browser.py` four-size browser matrix 102/102.
- Visual gate remains open: `artifacts/batch281-home-catalog/home-vs-osu-stable.jpg` is a review aid, not a claim of pixel-level parity.


## Batch282 component traceability
| UI target | Stable component ID | Runtime owner | Verification | Boundary |
|---|---|---|---|---|
| Catalog song list viewport | `catalog.song-list` | `src/ui/catalog-browser.js` | 114/114 four-size browser geometry + catalog filter contract | Browser data is a six-song layout fixture |
| Catalog pagination | `catalog.pagination` | `src/ui/catalog-browser.js` | Pagination bounding-box stays above fixed dock on desktop/tablet | Live data pagination not verified in HTTP-origin environment |
| Persistent free-play dock | `player.dock` | `src/ui/free-player-dock.js` | ResizeObserver layout property, dispose contract, 38 focused Node tests | Headless layout does not prove external audio playback |
| Feature route navigation | existing `#app-shell-nav` | `src/ui/app-shell.js` + CSS grid | 114/114 route/layout regression | Human visual gate still open |


## Batch282 Skin manifest integrity
- `app.home.logo` now exists consistently in `docs/skin-contract/amq-skin-role-manifest.v1.json` and runtime `src/skins/skin-contract.js`, matching the existing `src/skins/theme-adapter.js` selector and CSS token consumer.
- Updated inventory: 52 roles total, 40 runtime selectors wired, 12 explicitly unsupported. Audit JSON/Markdown regenerated and manifest contract tests pass. This count is not a claim of 100% visual coverage.


## Batch283：Catalog Stable 參考對照與實際元件映射

| Stable 區域／需求 | AMQ 正式 DOM owner | 狀態／資料 owner | Skin component／role | CSS／證據 | 限制 |
|---|---|---|---|---|---|
| 左側資訊區映射 | `.catalog-sidebar` 與原有搜尋／篩選控制 | `catalog-browser.js` query controller；沒有全球排名資料，因此不顯示假排名 | `catalog.filter.background` | `src/styles/ui-design-landing.css` Batch283；四尺寸 browser 148/148 | AMQ 篩選與 Stable ranking 語義不同 |
| 頂部 Group/Sort 控制區映射 | `#catalog-mode-selector` 中原有 `.mode-row` | 原有 AMQ/EMQ/MIX mode owner | `catalog.mode-selector` | `tests/batch283-catalog-stable-layout.contract.test.cjs` | 仍需評估將 saved presets 映射為更完整 Collections UX |
| 中央選取作品舞台 | `.catalog-detail-column`、`#catalog-selection-details` | 原有 selected record 與 artwork adapter | `catalog.selected-work-stage`、`catalog.selected-work-details`；既有 `catalog.song-detail.panel` | `artifacts/batch283-catalog-stable/catalog-data-fixture-1920x1080.jpg` | fixture 封面不是 live artwork |
| 選取作品背景 | `.catalog-scene-background img` | 既有 artwork adapter，只有成功 load 的 HTTPS/blob URL 可套用；selection sequence 防止 stale result | `catalog.selected-artwork-background` | `src/ui/catalog-browser.js` `setCatalogSceneArtwork()`；contract 7/7 | 需要 live provider 圖片才會出現背景；不可用 fixture 假裝 live |
| 右側歌曲佇列 | `.catalog-main-list`、`#catalog-rows`、`.catalog-list-wrap` | 原有 query/index/selection owner | `catalog.song-list`、`catalog.item.background`、`catalog.item.selected` | `catalog-vs-osu-stable-1920x1080.jpg`；browser 148/148 | 列式資料仍與 Stable 彩色疊層有差距 |
| 底部分頁與播放器 | `.pagination`、`#free-player-dock` | 原有 page controller、free player dock | `catalog.pagination`、`player.dock` | Dock collapsed/expanded 四尺寸 bounding boxes | live data／真機尚未驗收 |

視覺差距詳見 `docs/OSU_CATALOG_VISUAL_GAP_BATCH283.md`。

## Batch286 Quiz gameplay reference layout 與 Skin roles
- Reference: 使用者提供的 AMQ gameplay screenshot；來源 SHA-256 `3ba957004e70d59faab1e7fdcd0522e102719beb78ccde28629de8ffd632001f`。對照文件 `docs/QUIZ_GAMEPLAY_REFERENCE_BATCH286.md`，並排圖 `artifacts/batch286-quiz-gameplay-layout/quiz-reference-side-by-side.jpg`。
- Runtime owner：`src/ui/quiz-panel.js`、`src/ui/answer-suggestions.js`、`src/ui/app-shell.js`；沒有新增 Quiz session state owner。
- DOM regions：`.quiz-game-hud`、`.quiz-game-left-rail`、`.quiz-game-primary`、`.quiz-game-rail`、`.quiz-answer-form`、`#quiz-answer-reveal`。
- 真實資料映射：左側摘要讀 `#quiz-status`／`#quiz-pool-size`；HUD 讀 `#quiz-progress`／`#quiz-timer`；右側讀 `#quiz-audio-status`／`#quiz-history-*`；答案揭曉讀既有 anime/title/artist fields。
- Skin roles 新增 6 個：`quiz.game-hud`、`quiz.game-session-summary`、`quiz.game-stage`、`quiz.game-status-rail`、`quiz.answer.panel`、`quiz.answer.reveal`。manifest/runtime/visual-needs/theme-adapter/CSS tokens 已同步。
- Browser evidence：Batch286 55/55、Batch264 38/38、Batch285 route 71/71、Batch283 Catalog 148/148；focused Skin role contract 2/2 included in 17/17 group。
- 限制：原圖是多人遊戲畫面，單人 Quiz 以真實答題紀錄替代聊天室；背景按使用者要求未重建。自動化測試不是人工視覺驗收，也不證明 live audio/data 或 OSK 真素材 apply/reset 已完成。

## Batch286 Skin role inventory update
- Total roles: 58; runtime selectors: 46; explicitly unsupported: 12. Audit has CSS consumers for all 46 wired roles and direct test references for 45 roles. Remaining role gaps remain visible; this is not 100% visual coverage.

## Batch289：Quiz 結果狀態與角色欄比例
- 原圖：`artifacts/quiz-reference/amq-gameplay-layout-reference.jpg`；新版：`artifacts/batch289-quiz-states/quiz-initial-1920x1080.jpg`、`quiz-initial-390x844.jpg`；並排差距：`quiz-reference-comparison.jpg`。
- CSS owner：`src/styles/ui-design-landing.css` 的 `.quiz-game-board`、`.quiz-game-primary`、`.quiz-question-card` 與 `.quiz-character-bar`；桌面 board 有界寬並置中，角色欄在 board 下方，手機仍 reflow。
- State owner：`src/ui/quiz-panel.js` 的既有 `session.getState()`；DOM attributes `data-quiz-phase`、`data-result-state`、`data-timer-state` 僅是 state projection，不持有額外狀態。
- 結果映射：`submitted + correct` → `correct`；`submitted + incorrect` → `incorrect`；`skip` → `skipped`；`unplayed-skip` → `unplayed-skip`；`timeout` → `timeout`；`revealed` → `revealed`。未知結果使用 `none/answered` fallback，不猜測結果。
- 驗證：`tests/quiz-result-visual-states-batch289.contract.test.cjs` 與 focused Node 合計 31/31 PASS；Batch286 browser 55/55 PASS。後者不是 live session／VNDB／audio E2E。
- AI 式註釋政策：本批新增測試檢查正式 Quiz gameplay markup 不含開發者解說、TODO、fixture 標籤或「此區域將顯示」等 meta copy。測試／文件可以保留技術註解，玩家 UI 不可以。
