# 下一輪工作提示：Batch291（2026-10-30）

**先讀 `docs/HANDOFF_MASTER_CURRENT_BATCH290.md`。** 它是完整的使用者需求、目前狀態、測試證據、缺失資料與接手步驟總表。再讀 `AGENTS.md`、`PROJECT_RULES.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/UI_TRACEABILITY.md`、`docs/DESIGN_GAP_REGISTER.md`、`docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`、`docs/HANDOFF_BATCH289.md`、`docs/HANDOFF_BATCH290.md`。

## Batch291 目標
1. 開啟 `artifacts/osu-reference/osu-game-modifiers.jpg`，檢查正式 DOM/CSS/state owner。
2. 檢查 `src/engine/quiz-mods.js`、`src/audio/audio-service.js`、`src/engine/quiz-session.js`、`src/ui/quiz-panel.js`、Settings owner、Skin role manifest；搜尋並確認 canonical score owner，不要猜。
3. 先做一個在真實媒體來源限制下可用、可測試的音訊 Mod（優先評估 Fade Out）。確認 pause/resume/stop/next/dispose、候選 fallback 與跨題清理；不可假設所有來源可 fetch/decode。
4. 建立 Mods overlay/Settings 接線與 Skin component IDs、鍵盤焦點、Escape、Reset、Close、ARIA dialog、focus restore。只讓已接通的效果可選，不能做假按鈕。
5. 確認 score owner 後才接真實倍率；如果沒有 score owner，記錄阻塞，不要造第二套分數來源或顯示假倍率。Vocal Only/Background Only 仍缺音軌分離資料契約，維持不可用／不宣稱完成。
6. 擴充 Quiz session correct/wrong/skip/reveal/timeout/next/pause/resume/end transition matrix，包含 stale audio completion。
7. 做真實 screenshot 與 osu 原圖差距表，掃描玩家 UI meta copy；Quiz 背景目前按使用者要求暫不處理。
8. 分組執行全量 Node suite並保留每組 exit code；跑 focused tests、Architecture Checker、JS/CJS syntax、Python AST、四尺寸 browser。更新文件、Manifest，clean-extract 後重跑關鍵測試，再封裝 ZIP 和 SHA-256。

## 驗收誠信
Batch290 focused Mods 5/5、相關 focused suite 11/11、Quiz browser 55/55、Architecture 1,394/0、Python AST 40/40 PASS。全量 Node suite在 120 秒限制逾時且沒有 aggregate exit code，因此 **NOT VERIFIED**。人工 osu 視覺、live audio/provider、HTTP-origin IndexedDB、Windows/手機實機未驗收。不得沿用舊結果宣稱新修改也通過。

## 交付
更新 `docs/HANDOFF_MASTER_CURRENT_BATCH290.md` 的現況或建立新的最新總交接，並同步更新 `WORK_STATUS`、`MASTER_CHECKLIST`、`UI_TRACEABILITY`、`DESIGN_GAP_REGISTER`、`AI_START_HERE`、`README_FIRST`、本文件與 `MANIFEST.sha256`。完整完成一批再交付，不要每完成一小項就停下詢問。

---

# Batch291 下一輪工作提示

- 先讀 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`PROJECT_RULES.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/UI_TRACEABILITY.md`、`docs/DESIGN_GAP_REGISTER.md`、`docs/HANDOFF_BATCH290.md`、`docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`。
- Batch290 已建立 `src/engine/quiz-mods.js` 作為唯一 Mods registry／selection owner，focused tests 5/5 PASS。它尚未被 UI 使用，音訊效果也尚未接入，不得宣稱 Mods 功能已完成。
- 先確認 AudioService 的媒體生命週期、候選 fallback、pause/resume/stop 與真實來源 CORS 限制，實作並測試一個可安全運作的效果（優先評估 Fade Out）；不可假設所有來源可 fetch/decode，也不可讓效果狀態跨題污染。
- 然後接入 Mods overlay／Settings：只啟用已接通的效果，提供鍵盤焦點、Escape、Reset、Close、ARIA dialog semantics 與 Skin component IDs。開工前開啟 `artifacts/osu-reference/osu-game-modifiers.jpg`，正式 DOM/CSS/state owner 必須先確認。
- 正式 score owner 尚未找到；未確認前不可顯示「實際得分倍率」或假分數。Vocal Only／Background Only 目前只有互斥規則，缺少可分離音軌的資料契約。
- 同批補 Quiz session result transition matrix，更新主清單／狀態／traceability／gap register／handoff／next prompt／Manifest。交付前執行 focused tests、Architecture Checker、syntax／AST、四尺寸 browser、分組 Node suite、clean-extract tests。未執行不可宣稱 PASS。

---

# Batch290 下一輪工作提示

- 先讀 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`PROJECT_RULES.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/UI_TRACEABILITY.md`、`docs/DESIGN_GAP_REGISTER.md`、`docs/HANDOFF_BATCH289.md`、`docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`。
- UI 是 P0，不能因為修功能或測試而忽略「目前不像 osu! Stable」的核心問題。每個 UI slice 先開對應 osu! Stable 原圖／使用者提供的 AMQ 原圖，再讀正式 DOM/CSS/state owner，再實作整批並排視覺差距與回歸。
- Batch289 已完成 Quiz 桌面三欄比例收斂、session phase/result/timer 視覺狀態、答案揭曉 aria-label、VNDB 角色欄比例調整。不要重做已通過的四尺寸 geometry；需補 live session transitions 的可追溯測試。
- 參考 `artifacts/osu-reference/osu-game-modifiers.jpg`，調查 canonical Mods registry/state/multiplier/audio owner。若不存在，先建單一可測試規則 owner，再設計 Mods/Settings UI；不做無功能裝飾按鈕。
- Quiz 背景按使用者要求暫不處理。角色 ID 管理維持 Settings；Quiz 只顯示成功載入的真實 VNDB 人物圖片。
- 玩家 UI 禁止 AI 式註釋、開發備註、TODO、測試 fixture 標籤或自我解說；交付前搜尋新增文案並檢視實際畫面。
- 社群腳本 `references/AMQ-Scripts-master.zip` 不是官方 AMQ 核心原始碼。只移植有證據且安全的行為，不直接注入或覆寫 prototype。
- 交付前需執行 focused tests、四尺寸 browser、architecture checker、JS/CJS syntax、Python AST、更新 Manifest，產生精簡 ZIP 與 SHA-256，clean-extract 後重跑關鍵測試。未執行的測試不可宣稱通過。
