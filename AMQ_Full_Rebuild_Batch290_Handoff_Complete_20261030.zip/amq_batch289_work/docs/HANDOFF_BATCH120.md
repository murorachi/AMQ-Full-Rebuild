# AMQ 新版重建交接：Batch120（多人房間最小 UI 接線）

日期：2026-10-28  
基礎交付：`AMQ_Full_Rebuild_Batch119_Handoff_20261028.zip`  
Git：工作副本沒有 `.git` metadata；未初始化 Git、未 commit、未 push。

## 實作成果

- 新增 `src/ui/multiplayer-panel.js`，使用既有 `AMQMultiplayer.httpClient` 與 `roomSession`；提供大廳列表、建立／加入房間、準備切換、房主開始回合、提交作品標題答案、離開及關閉房間。
- `src/index.html` 新增多人面板並載入 UI module；保留既有 UI/CSS，未做大規模視覺重構。
- `src/app.js` 將面板納入 app lifecycle，注入共用 playback coordinator。
- 面板透過 `/api/auth/me` 辨認玩家 ID；host-only 按鈕依 `hostId` 投影，最後仍由 server 強制驗權。
- RoomSession 是唯一房間快照來源。UI 不自行設定 question、grade、revision 或 round duration。
- 多人 active round 取得既有 playback coordinator lease；owner 被取代後設置 revoked latch，避免每次 poll render 反覆搶回 lease；離開／回合結束／dispose 時釋放。
- 新增 `tests/multiplayer-panel.integration.test.cjs`，驗證大廳、建立、ready、start、answer 與 dispose。
- `tools/check-architecture.cjs` 已納入 UI module 的語法與載入順序檢查。

## Targeted validation

- `node --check src/ui/multiplayer-panel.js`：PASS。
- `node --check tests/multiplayer-panel.integration.test.cjs`：PASS。
- `node --test tests/multiplayer-panel.integration.test.cjs tests/multiplayer-room-session.test.cjs tests/multiplayer-http-client.test.cjs tests/playback-coordinator.test.cjs tests/quiz-session.test.cjs`：19/19 subtests PASS；QuizSession 23/23。
- `node tools/check-architecture.cjs`：893 passed／0 failed。
- 全量回歸：57/57 非-tooling `tests/*.test.cjs` scripts 逐檔 exit 0；`node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：893 passed／0 failed。
- Source audit PASS，重複 work/song IDs、dangling references、跨來源 ID collisions 均為 0。Full mapper PASS：AMQ 9,516 works／38,821 songs，EMQ 6,645 works／16,839 songs，Catalog 55,660 records。5-run catalog benchmark PASS。
- 唯讀來源 SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 第一輪逐檔回歸 shell 總執行時間到上限時停在 `tests/tooling.test.cjs`；57 個非-tooling scripts 均已成功，tooling 隨後用 `node --test` 獨立執行並通過。

## 尚未完成／限制

- **多人模式尚不能完整遊玩。** Server snapshot 目前提供 questionId／round metadata，但沒有供瀏覽器播放的題目音源候選或安全題目投影。UI 已明確標示多人音訊播放尚未接線。
- 多人 AudioService／QuizClock 同步、回合倒數 UI、多人 SRS、自動多 client E2E、WebSocket／多節點仍未完成。
- 真實瀏覽器未執行；先前 Chromium 路徑已知 `ERR_BLOCKED_BY_ADMINISTRATOR`，本批未重試。
- 無 Git metadata，不初始化或假造提交紀錄。Candidate302、Candidate382 Stage 0 與來源 assets 唯讀。

## 下一步

1. 逐檔執行所有 `tests/*.test.cjs`；另外執行 tooling、source audit、full mapper verification、5-run catalog benchmark。
2. 更新最終 Manifest、封裝 Batch120 ZIP，重新驗證 CRC、檔案集合與 SHA-256。
3. 下一批優先安全題目投影與共用 AudioService／QuizClock 整合；server 必須繼續掌握 question／assessment／deadline，不能信任 client grade，也不複製第二套 audio engine。


## 最終交付封包

- 檔名：`AMQ_Full_Rebuild_Batch120_Handoff_20261028.zip`。
- 封包驗證：ZIP CRC PASS；Manifest 282 entries，缺檔 0／額外檔案 0／SHA-256 mismatch 0；ZIP 283 files（含 Manifest），沒有 `.pem`／`.key` 私鑰檔。
- 封包大小與 ZIP SHA-256 以最終交付回報為準；封包本身不內嵌自己的雜湊，避免自我參照。
