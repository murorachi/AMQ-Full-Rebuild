# Batch228 交接：表單控制項色板舊規則替換

日期：2026-10-29
工作副本：`/mnt/data/amq_batch228_work/project`
來源交付：`AMQ_Full_Rebuild_Batch227_Quiz_Card_CSS_Replacement_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch228_Form_Control_Palette_Replacement_20261029.zip`

## 開工檢查與基準
- 已讀取 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、Batch227 handoff／next prompt、Wiki traceability、OSK role audit、leaderboard trust contract 與 skin manifests。
- ZIP 工作副本沒有 `.git`；未初始化。Candidate302 正式維護基準及 Candidate382 Stage 0 CSS 比較基準原始檔缺席，未猜測或覆蓋。AMQ／EMQ 資產唯讀。

## 實作
- `src/styles/ui-shell.css`：移除全域 `input,select` palette 的 `!important`；由 `.app-page` 與 `#free-player-dock` 範圍管理普通輸入／選單的背景、邊框、文字、radius，排除 checkbox／radio／range／file。增加 disabled input/select feedback。
- `src/styles/ui-shell.css`：移除 quiz answer/all-answer palette 的重複 `!important`；單人答案欄位的專屬 border／radius／background／color 改為一般 shell 宣告。
- `tests/quiz-ui-state.contract.test.cjs`：新增舊 global palette／quiz answer `!important` 防回歸契約。
- `tests/app-shell.browser.test.py`：新增 Catalog、Free Player、Quiz、Multiplayer、Settings 的 computed-style assertions；產物獨立存於 `artifacts/batch228-regression/`。

## 驗證結果
- Chromium formal shell：127/127 PASS；桌面／390px 手機主要頁面無水平溢位、無 uncaught browser exceptions。
- OSK import panel Chromium harness：12/12 PASS。
- Architecture Checker：1,165 PASS／0 FAIL。
- 176 個 JS/CJS `node --check` PASS；2 個 Python browser test `py_compile` PASS。
- Node test files：80/81 PASS，證據 `artifacts/batch228-regression/node-tests/summary.tsv`。`tests/tooling.test.cjs` 全檔執行會啟動並行 Architecture Checker 子程序並超過工作命令時間限制；非 architecture 子集 11/11 PASS，Architecture Checker 已獨立通過。此檔未標為全檔通過。
- AMQ／EMQ 資產 SHA-256 與 Batch227 一致，見 `artifacts/batch228-regression/asset-hashes.txt`。

## 未解／阻塞
- HTTP-origin IndexedDB save/reload：Chromium loopback `ERR_BLOCKED_BY_ADMINISTRATOR`，未驗收。
- 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與實機驗收未完成。
- UI 主線未結案；本批只完成表單控制項色板舊規則的實際替換。

## 下一批：Batch229
1. 盤點設定頁 file input、OSK toggle checkbox、Free Player range track、settings dropdown skin image、notice／error banner 的剩餘 `!important` islands。
2. 逐一核對載入順序、selector specificity、skin token 與每個真實 consumer；只移除已由明確 owner 接管的舊宣告。
3. 持續實作並驗證 UI，包含 focus-visible／disabled／touch／390px 排版；不得只做核心測試而停下 UI。
