# Batch279 交付摘要

- 工作來源：`AMQ_Full_Rebuild_Batch278_Approved_Runner_Acceptance_20261030.zip` 所含的 Batch277 工作區；來源 ZIP 未修改。工作副本為獨立目錄。
- 本批主題：回到原有 UI 設計工作，選出 30 項既有未結案待辦，修正 Home 桌面入口拉伸、空歷史區過大及 CTA 與右側選單重疊。
- 主要改動：`src/styles/ui-design-landing.css`、`src/ui/app-shell.js`、`tests/batch273-home-menu.browser.py`；新增 `docs/BATCH279_UI_TASK_SELECTION.md`、`docs/HANDOFF_BATCH279.md`。
- 最新視覺證據：`artifacts/batch279-home-menu/` 的四尺寸 Home/Catalog JPEG。osu! Stable 參考圖仍在 `artifacts/osu-reference/`。
- 測試：Home/Catalog Chromium matrix 90/90 PASS；focused Node tests 37/37 PASS（Skin theme adapter 21、App Shell navigation contract 2、UI shell CSS 9、Catalog row visual contract 5）；Architecture Checker 1,344 PASS／0 FAIL；Python AST compile、`node --check src/ui/app-shell.js` PASS。
- 測試限制：Catalog 列與封面為明確 layout fixture；未執行全量 Node suite、批准 GitHub runner、HTTP-origin IndexedDB、live ANN/VNDB artwork、外部 AMQ/EMQ 可聽音訊、Windows／實機或人工 osu! Stable 視覺 gate。不得將這些標成通過。
- 封裝：保留完整來源與本批最新四尺寸 JPEG；沒有因追求 ZIP 大小而移除不確定用途的檔案。`MANIFEST.sha256` 列出除自身外的所有工作區檔案；ZIP CRC 與 ZIP SHA-256 需以交付旁檔驗證。
- 30 項追蹤：`docs/BATCH279_UI_TASK_SELECTION.md`；只有本批有實際實作／測試證據的項目標記完成，其餘維持待處理或待人工驗收。
