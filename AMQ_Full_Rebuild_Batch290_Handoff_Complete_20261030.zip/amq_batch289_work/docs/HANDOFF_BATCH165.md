# Batch165 交接：Artwork lifecycle 清理與全量 Node 回歸

## 開工確認
- 已讀取 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH164.md` 與 `docs/NEXT_SESSION_PROMPT.md`。
- 工作副本 `/mnt/data/amq_batch153_work` 沒有 `.git` metadata；`git status` 回報不是 Git repository，未初始化 Git。Candidate302、Candidate382 Stage 0 與原始 AMQ／EMQ 曲庫資產維持唯讀。
- 本環境未安裝 Node `playwright`／`puppeteer`／`jsdom` 套件；Python Playwright 套件存在，但既有記錄指出 file／localhost 導覽被政策阻擋，本批沒有重試已知失敗路徑。

## 實作
- `src/app.js`：個人清單、設定、熟悉度 store 在各自建立後立即登記 scope cleanup，不再等到 runtime 與 artwork 初始化之後才註冊。
- `src/app.js`：Artwork service client、provider bundle、adapter 各自在建立後立即登記 cleanup。provider factory 在建立中途拋錯時，已建立的 client 與 ANN adapter 可由 scope 回收。
- 新增 `tests/app-artwork-lifecycle.integration.test.cjs`：測試 Catalog 收到共用 artwork adapter、正常 dispose/remount 不重複洩漏、provider 初始化失敗後資源回滾與 retry、runtime 建立失敗時 store 釋放。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`。

## 驗證
- `node --test tests/app-artwork-lifecycle.integration.test.cjs tests/app-lifecycle.integration.test.cjs tests/catalog-browser.integration.test.cjs tests/catalog-filter-layout.contract.test.cjs`：8/8 top-level tests PASS。
- `node tools/check-architecture.cjs`：1,051 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- `node --check src/app.js`、`node --check tests/app-artwork-lifecycle.integration.test.cjs`：PASS。
- `tests/` 內 71 個 `*.test.cjs` 分 9 組完成，合計 164/164 tests PASS、0 failures；所有 9 組 exit code 0。首次 orchestration 因工具 120 秒上限在 group 8 中途停止，後續續跑 group 8、9 成功，並未把被中斷的 orchestration 誤報為成功。日誌、每組檔案清單、exit code 及 `summary.json` 位於 `artifacts/batch165-regression/`。

## 未解決／阻塞
- 真實 Chromium viewport（1440／1024／820／390）、鍵盤焦點、水平捲動與詳情面板堆疊尚未完成實機視覺驗收。
- ANN API／CORS／圖片真實載入尚未在線上瀏覽器驗收。
- 真實 `.osk` 相容性及允許 HTTP origin 下 IndexedDB save/reload/clear 仍受環境限制。
- 沒有 Git metadata，未建立 Git repo。

## 下一步 Batch166
1. 若有新且可用的真實瀏覽器導覽方式，驗收 Catalog 四種 viewport；不要重試已知被阻擋的路徑。
2. 若仍無瀏覽器，先做正式 Song Select 互動與資料契約的靜態／整合回歸，檢查列表密度、長標題、來源連結、Skin selection frame。
3. 追蹤是否仍有其他模組資源在初始化後、scope cleanup 註冊前可能拋錯；僅處理有證據的缺口。
4. 保持 selection 與 playback 狀態責任分離；真實 ANN／`.osk`／IndexedDB 限制持續記錄，不阻塞其他工程工作。
