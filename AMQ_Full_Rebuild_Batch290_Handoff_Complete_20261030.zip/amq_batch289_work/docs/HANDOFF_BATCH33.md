# Batch 33 交接：共用資料身份契約與去重規則

## 本批目標與結論
- 完成 AMQ-030／032／033 在新版內部資料模型範圍內的可執行規則。
- 不將標題相似度當成同一首歌的證據，不以標題生成替代 ID。
- 共用身份規則已接入資料驗證器、Catalog 查詢索引及猜歌題庫；數字 ID 與同值字串 ID 維持不同身份。

## 修改檔案
- 新增 `src/data/identity.js`：`isIdentifier`、`identifierKey`、`createIdentity`、`sameIdentity`。
- 修改 `src/data/validate.js`：重複記錄檢查使用共用身份 helper。
- 修改 `src/data/query-index.js`：Catalog identity 與 typed facet ID 使用共用 helper。
- 修改 `src/engine/quiz-pool.js`：題目身份不再把 ID 無條件 `String()` 化。
- 修改 `src/index.html`、`tests/tests.html`：按依賴順序載入 identity helper。
- 修改 `tests/core.test.cjs`、`tests/query-index.test.cjs`、`tests/data-pipeline.integration.test.cjs`、`tests/source-runtime.integration.test.cjs`、`tests/audio-candidates.test.cjs`、`tests/catalog-browser.test.cjs`、`tests/quiz-pool.test.cjs`、`tests/quiz-session.test.cjs`。
- 修改 `tools/check-architecture.cjs`、`tools/verify-source-mappers.cjs`、`tools/benchmark-catalog.cjs`，確保測試／工具依賴順序一致。
- 新增 `tests/data-identity.test.cjs`（6 項測試）。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/DATA_CONTRACT.md`、`docs/ARCHITECTURE.md`、`README_FIRST.md`、`AI_START_HERE.md`，新增本交接文件。

## 身份規則
- 唯一性由 `source + ID 型別 + ID 值` 決定，key 使用 JSON tuple encoding，避免自行拼接分隔符的碰撞。
- 不同 source 可以有相同 ID；同一 source 的數字 `1` 與字串 `"1"` 仍是不同 ID 型別。
- 同標題／相似標題但 ID 不同的歌曲分開保留，不自動合併。
- 搜尋 NFKC／大小寫／空白正規化只作用於查詢索引副本；不覆寫來源 ID 或顯示文字。
- 上游跨版本 ID 穩定性未獲來源保證。未來若上游重編 ID，需版本對照或穩定外部 ID；不得靠標題相似度猜測遷移。

## 驗證結果
- `tests/*.test.cjs`：21 個測試腳本全部 exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：415 passed、0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；來源原始結構、重複與關聯稽核無新增異常。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839，Catalog 55,660。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；只代表目前 Node／來源檔／記憶體 Catalog 的量測，不是瀏覽器效能保證。
- `src/`、`tests/`、`tools/` 所有 `.js`／`.cjs` `node --check`：PASS。
- 真實瀏覽器 E2E、跨頁 localStorage、真實外部音訊播放仍未驗收；本批未重試已證實受政策阻擋的 Chromium 導覽。

## 下一批
1. 檢查 Source Adapter／Repository／Composite Adapter 的 source 標籤契約是否全部使用相同的身份與來源語義，補齊可驗證的跨邊界測試。
2. 依優先級處理仍未完成的資料契約，不擴張到不存在的 UI 功能。
3. 保持 `AMQ382(1).html` 與 AMQ／EMQ 來源資料唯讀，不再搜尋 Candidate302。
