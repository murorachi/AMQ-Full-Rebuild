# AMQ 新版重建交接：Batch126（Remote SRS response-lost reconciliation）

日期：2026-10-28。沿用 Batch125 工作副本；無 `.git` metadata，未初始化／commit／push。

## 修改
- `src/persistence/remote-srs-bridge.js` 新增 stable JSON 比對。retry GET 發現 server revision 與原 revision 不同時，若 server schedule 與待同步 payload 完全一致，視為原 PUT 已成功但 response 遺失，直接對齊 revision 並解除 blocked，不送第二個 PUT。
- 若 server revision 已變且 schedule 不同，仍回報 `SRS_REVISION_CONFLICT` 並 fail-closed，不覆蓋其他裝置資料。
- `tests/remote-srs-bridge.test.cjs` 新增 committed-but-response-lost 測試，驗證不重複 PUT／revision，且安全恢復後可繼續寫入。

## 驗證
- Targeted `node --test tests/remote-srs-bridge.test.cjs tests/account-panel.integration.test.cjs tests/quiz-panel.test.cjs`：8/8 subtests PASS。
- 57/57 非-tooling test scripts 逐檔通過，分四組執行。
- Tooling 13/13 PASS；architecture 893 passed／0 failed。
- Source audit／full mapper／5-run benchmark PASS；Catalog 55,660 records，build 約 1,257.743 ms（僅 Node 本機觀測值）。
- Source SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 尚未完成
- 跨 reload durable retry queue 仍是 memory-only。完整實作需 user-ID-bound IndexedDB queue、ordered writes、revision／fingerprint／response-lost reconciliation、account isolation、discard semantics 與 storage failure handling。
- 真實瀏覽器／IndexedDB lifecycle E2E 受已知 `ERR_BLOCKED_BY_ADMINISTRATOR` 限制；本批未重試同一路徑，也未宣稱 durable queue 已完成。

## 下一步
Batch127：選擇可獨立驗證的高優先缺口；若繼續 durable queue，先定義與測試完整資料契約，再接 UI。
