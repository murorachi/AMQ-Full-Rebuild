# Batch 101 交接包

日期：2026-10-27

## 本批完成

1. 修復 `player.leave` 成功後的 snapshot 回應缺陷。狀態機先移除離房者，服務層再用該離房者身份取得 viewer-specific snapshot，導致已提交狀態後錯誤回報 `ROOM_PLAYER_NOT_MEMBER`。現在離房命令使用一般 snapshot。
2. 房主離開且仍有成員時，仍依最早 `joinedAt` 選新房主；若加入時間相同，以明確的字串 code-unit 順序比較 ID，不再依賴 `localeCompare()` 的 runtime locale。
3. 新增 regression 覆蓋房主轉移事件／snapshot／revision、成功 leave 的 requestId 重放、重放不重複提交、原房主失去權限、新房主取得 host-only 權限、相同時間戳下大小寫 ID 的排序，以及最後房主離開後關閉房間。

## 修改檔案

- `src/multiplayer/room-command-service.js`
- `src/multiplayer/room-state-machine.js`
- `tests/multiplayer-room-command-service.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `docs/HANDOFF_BATCH101.md`
- `MANIFEST.sha256`

未修改或刪除 Candidate302、Candidate382 Stage 0 或來源資料資產。工作目錄沒有 `.git`，沒有初始化 Git 或假造 commit。

## 驗證證據

- `node tests/multiplayer-room-command-service.test.cjs`：PASS，包含新增 host transfer／leave replay regression。
- `node tests/multiplayer-room-state-machine.test.cjs`：PASS。
- 非-tooling `tests/*.test.cjs`：44/44 個腳本逐檔 exit 0。第一次串接執行被環境 240 秒總 timeout 中止於第 41 個已通過腳本；剩餘 3 個腳本另行執行且全部通過，因此結論基於逐檔證據，不將被中止的合併命令當成 PASS。
- `node --test tests/tooling.test.cjs`：9/9 PASS。
- `node tools/check-architecture.cjs`：719 passed／0 failed。
- `src/`、`tests/`、`tools/` JavaScript／CJS syntax：100/100 PASS。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 songs／9,516 works，EMQ 16,839 songs／6,645 works；duplicate IDs、dangling references、cross-source collisions 均 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，Catalog 55,660 records。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；Catalog build 約 1,315.353 ms，僅是本機 Node 觀測值。
- 來源資產 SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 最終封包 CRC 通過；Manifest 227 entries、ZIP 228 個檔案項目（含 `MANIFEST.sha256`）與 14 個目錄項，缺失 0、額外檔案 0、hash mismatch 0。`sha256sum -c MANIFEST.sha256` 全部通過。封包 SHA-256 於交付回報提供，避免在封包內記錄自身 hash 形成自我參照。

## 未解決／阻塞

1. Idempotency 與 rate limit 僅在單一 service instance 的記憶體生命週期內有效；durable idempotency、per-room serialization、跨節點狀態一致性未實作。
2. 真正 transport/auth provider、reconnect、multi-client E2E 未實作。
3. 多人 SRS persistence 需產品決策；不得寫入沒有 user identity 的共享 browser localStorage key。
4. 真實瀏覽器／音訊／storage／外部 API 未驗收。已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一導覽路徑。
5. UI／CSS 大重構依計畫最後進行。

## 下一批優先事項

- 檢查 `player.join`／`player.leave` 重試與 closed-room snapshot。
- 檢查有限 FIFO idempotency cache 淘汰及 replay snapshot revision 新鮮度；先固定原始結果與最新 snapshot 的契約，再決定是否需要實作變更。
- 只修正可重現缺陷；不得把純 Node 邏輯測試宣稱為正式多人 server 或瀏覽器 E2E 驗收。
