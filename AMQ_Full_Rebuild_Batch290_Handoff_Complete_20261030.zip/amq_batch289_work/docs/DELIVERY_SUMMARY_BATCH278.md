# Batch278 交付摘要（2026-10-30）

- **輸入：** Batch277 工作副本；來源 Batch275/276/277 ZIP 未覆寫；工作目錄無 `.git`，未初始化。
- **新增：** `.github/workflows/amq-acceptance.yml` 與 `tests/approved-runner-live-acceptance.py`。Hosted runner 將正式 `src/` 透過 HTTP origin 開啟，以正式 SkinThemeStore 執行 IndexedDB save/reload/clear，並用資料內明確 ANNID 嘗試 live ANN artwork + image decode。無論結果如何均上傳 acceptance JSON；IndexedDB 未通過會令 job fail。
- **靜態驗證：** Workflow contract 6/6 PASS；Python AST 35/35 PASS。Batch277 Node 99 files／20 groups／310 subtests PASS；Architecture 1,344/0；JS/CJS 194/194。
- **執行狀態：** GitHub Actions workflow 尚未觸發。IndexedDB、live ANN/CORS/image decode 都是 NOT_RUN；本批沒有在已知封鎖的本機 origin 重複探測，也沒有繞過管理政策。不得將 harness 存在等同驗收完成。
- **封裝：** 保留 source、tests、workflow、最新證據、handoff、工作清單、traceability、gap register、manifest 與 SHA-256 sidecar。未刪除用途未明的歷史資產。
- **未驗收：** hosted runner live report、Home/Catalog 人工 osu! Stable visual gate、外部 AMQ/EMQ 可聽音訊、Windows／實機鍵盤與觸控。
