# Batch275 Handoff：Home Stable 構圖與 Artwork／Skin role 修正

## 本批實作
- Home 主視覺改成大尺寸圓形 AMQ 品牌 fallback，右側六個斜切入口與圓形主視覺有重疊關係；最近學習仍由原 playback-history store 負責。
- 無 history 時顯示原創 AMQ 品牌圖形，不偽造作品封面；有 history 且 provider 有正式圖時仍優先顯示 artwork。
- `app.home.primary-action` role 連接 feature CTA + 六個 Home menu buttons；`app.home.welcome-visual` 連接 `.home-feature-art`，相關 CSS 保留 Skin image token。
- `setArtwork()` fallback 會清除舊 provider／attribution/source URL metadata。Catalog row/detail 也改成只在 image `load` 成功後標記 `available` 與顯示 source attribution；載入期間保留可讀 title fallback，失敗會清除 source link。新增 integration/CSS contracts。
- 本批從 Batch274 解壓副本複製到獨立 `/tmp/AMQ_Batch275`；未修改來源 ZIP，沒有 `.git`，未初始化 Git。

## 測試證據
- `python tests/batch273-home-menu.browser.py`：85/85 PASS，四尺寸 Home/Catalog matrix；最新 JPEG 在 `artifacts/batch275-home-menu/`。Catalog data fixture 仍非正式曲庫。
- `python tests/batch275-home-artwork.browser.py`：14/14 PASS；測試 history fixture、provider metadata、source attribution metadata、broken image fallback、stale metadata 清理。這不是 live ANN/VNDB 證據。
- `node --test tests/skin-theme-adapter.test.cjs`：21/21 PASS。
- focused Node contracts（ANN artwork adapter、artwork adapter、provider factory、app artwork lifecycle、Skin theme adapter、UI shell CSS、Catalog artwork lifecycle）：51/51 PASS。全量 Node 98 files 分 20 組、305/305 PASS；Architecture 1,335/0；JS/CJS 192/192；Python AST 36/36。
- 已完成最後靜態檢查：Architecture 1,335 PASS／0 FAIL；JS/CJS syntax 192/192 PASS；Python AST 36/36 PASS。摘要位於 `artifacts/batch275-regression/architecture.log`、`js-cjs-syntax-summary.json`、`python-ast-summary.json`。

## IndexedDB／瀏覽器環境 blocker
- Batch274 的 HTTP／非 loopback navigation 已回報 `ERR_BLOCKED_BY_ADMINISTRATOR`。
- Batch275 為確認是否只封鎖 HTTP，嘗試以 ephemeral self-signed certificate 將實際 `src/` 透過 `https://localhost:18443/` 提供。Chromium 在 document load 前仍回報 `net::ERR_BLOCKED_BY_ADMINISTRATOR`。
- 測試用 server/certificate 已清理；保留 `artifacts/batch275-regression/secure-origin-navigation-blocker.txt`。不得再重複 localhost 探測或繞過管理政策。此結果只證明本環境封鎖 local app navigation，不代表應用層 IndexedDB 已通過或失敗。

## 仍未結案
1. Live ANN/VNDB artwork 與正式 Home/Catalog data；provider fixtures 不能替代 live response。
2. osu! Stable 人工視覺 gate；85/85 只代表 DOM/geometry contracts，不是人工像素驗收。
3. IndexedDB save/reload 的真實 app-origin 驗收；需要批准的 HTTP(S) browser/CI runner。
4. 外部 AMQ/EMQ 音訊可聽播放、Windows／實機鍵盤與觸控。

## 下一批 Batch276
- 先使用可正常載入本機／CI app 的批准瀏覽器環境；不要再次嘗試 localhost 以繞過政策。
- 優先做 Catalog 真實資料與 artwork source traceability、圖片 decode/error/fallback、provider attribution 和正式 Home/Catalog screenshot。
- 對 Stable 參考圖產生並排對照與差距表；若人工 gate不可執行，明確維持未通過。
- 重新跑 Batch274 20 組 Node suite、Batch275 focused/browser tests、Architecture、syntax、Python AST；更新同一份 checklist/status/handoff/next prompt/manifest/package。
