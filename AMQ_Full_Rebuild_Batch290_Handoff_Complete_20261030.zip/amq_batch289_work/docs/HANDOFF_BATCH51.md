# Batch 51 交接：個人清單 UI 與曲庫列選取

日期：2026-10-27

## 本批完成

- `src/ui/catalog-browser.js` 接入個人清單 store：建立／改名／刪除、目前作品成員新增／移除、看番狀態更新／清除。操作以 store 回傳結果判斷，不直接存取 localStorage。
- `src/persistence/app-settings-store.js` 新增向後相容的 `customListId` 設定欄位，舊 schemaVersion 1 payload 沒有此欄位時正規化為空字串。刪除目前選取清單時會清理設定參照；清單與設定是不同 localStorage key，沒有跨 key 原子性，若第二步失敗 UI 會回報部分成功。
- 清單刪除不刪作品、看番狀態或學習資料。收藏 `aniFavorites_v1` 不寫入。
- 曲庫列以 `source + id` 為 selection key。點擊選取；方向鍵在目前可見結果列間移動；Enter 僅選取並提示「新版尚無曲庫列播放 owner」，不呼叫 AudioService，也不宣稱播放。輸入、textarea、select、button、contenteditable target 不被快捷鍵攔截。
- UI 有最小操作區與 selected/focus CSS，未進行全面 UI／CSS 重構。

## 修改檔案

- `src/ui/catalog-browser.js`
- `src/index.html`
- `src/styles.css`
- `src/persistence/app-settings-store.js`
- `tests/catalog-browser.integration.test.cjs`
- `tests/app-settings-store.test.cjs`
- `tests/tests.html`
- `docs/ARCHITECTURE.md`
- `docs/DATA_CONTRACT.md`
- `docs/PRODUCT_CORE_CONTRACT.md`
- `docs/FUNCTION_INVENTORY.md`
- `docs/ACCEPTANCE.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`、`docs/HANDOFF_BATCH51.md`、`README_FIRST.md`

## 驗證

- `tests/*.test.cjs`：25/25 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- Focused `node tests/catalog-browser.integration.test.cjs`：PASS；`node tests/app-settings-store.test.cjs`：6/6；`node tests/personal-library-store.test.cjs`：9/9。
- Source audit PASS（AMQ 38,821 songs、EMQ 16,839 songs，無 duplicate/dangling/collision）；mapper PASS（Catalog 55,660、AMQ candidates 37,939、EMQ 16,839）；5 次 benchmark PASS；architecture 459/0；所有 JS/CJS syntax PASS。完整日誌位於 `/mnt/data/amq_batch51_logs/`。
- 封包驗證：`MANIFEST.sha256` 127 entries，無 missing／extra／hash mismatch；ZIP 128 entries（含 manifest），CRC PASS，封包內 127 個檔案逐項 SHA-256 與 manifest 相符。
- 真實瀏覽器未驗收：既有頁面導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重試同一方式。

## 限制與下一步

1. 清單管理尚未接入猜歌出題池。因 AMQ／EMQ work ID 可能重疊，Batch 52 先定義 source-aware work identity 與 filter contract，不能直接按數字 ID 過濾。
2. `customListId` 目前只保存目前選取的清單，尚未使猜歌 pool 使用該清單。
3. 清單刪除與設定清理跨兩個 key，不是原子交易；失敗時會明確回報部分成功。
4. 收藏身份、真實音訊可聽性、乾淨 Windows 啟動、Candidate302／Candidate382 Stage 0 相容性與真實瀏覽器操作仍未驗證。
5. 工作副本無 `.git` metadata，不初始化、不 commit、不 push；來源資料唯讀。

## 下一批 Batch 52

- 定義清單作品身份的 source-aware contract，設計與測試清單過濾猜歌 pool 的規則，避免 AMQ／EMQ ID collision。
- 測試 persistence write failure／recovery notice 在 UI 上不顯示成功。
- 按功能真相表挑選可在現有證據下完成的 P1 模組批次，完成測試與交付。
