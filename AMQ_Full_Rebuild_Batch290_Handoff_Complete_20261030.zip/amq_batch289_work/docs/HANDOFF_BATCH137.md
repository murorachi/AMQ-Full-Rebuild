# AMQ 新版重建交接：Batch137（唯讀 SQLite 完整性診斷）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。沒有 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 維持唯讀。

## 修改
- 新增 `server/database-integrity.cjs`：共用 SQLite `integrity_check`、`foreign_key_check`、必要表檢查與核心／SRS／multiplayer 表筆數。
- 新增 `tools/inspect-private-server-database.cjs <existing-amq.sqlite>`：唯讀檢查現有 DB，輸出檔案大小、SHA-256、表清單、表筆數與完整性狀態；不建立 DB、不 migration、不寫入。
- `tools/backup-private-server.cjs`、`tools/verify-private-server-backup.cjs` 改用共用檢查器，並報告 `multiplayer_rooms`、`multiplayer_commands`、`srs_assessment_events` 筆數。缺少 optional history tables 的舊 schema 仍可檢查。
- `tests/database-integrity.test.cjs` 新增三個 scenarios；`tests/private-server-backup.test.cjs` 增加歷史表計數／備份驗證 assertions。
- 更新 `docs/PRIVATE_SERVER.md`、`AI_START_HERE.md`、工作清單與交接提示詞。

## Targeted 驗證
- `node --test tests/database-integrity.test.cjs tests/private-server-backup.test.cjs`：5/5 PASS。
- `node tools/check-architecture.cjs`：909 passed／0 failed。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- 最終 Batch139 regression：61/61 非-tooling scripts、tooling 13/13、architecture 925/0、source audit／mapper／5-run benchmark、143 個 JS/CJS syntax checks PASS；最終 ZIP／Manifest 已驗證。

## 限制
- integrity／foreign-key 檢查不等於所有 JSON payload 的業務語義驗證；工具不會自動修復資料。
- 沒有新增帳號刪除 API。歷史房間／command／SRS rows 不自動清除。
- 真實瀏覽器／多節點 E2E 仍未驗收。

## 下一批
Batch138：加入 closed／active room、command replay 與 SRS event 的唯讀歷史量統計；不得輸出玩家敏感資料或刪除歷史 rows。
