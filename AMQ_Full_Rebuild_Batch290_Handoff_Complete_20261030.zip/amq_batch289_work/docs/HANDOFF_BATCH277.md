# Batch277 Handoff：Artwork provider diagnostics

## 實作
- `src/integrations/artwork-provider-factory.js` 新增有界 provider diagnostics：ANN、AniList、VNDB 的成功、缺圖、略過與失敗事件，使用穩定錯誤碼。事件只保留時間、provider、outcome、code、kind、AMQ/EMQ source；不保存作品標題、外部 ID、URL、原始錯誤訊息。
- Provider bundle 提供 `getDiagnostics()`／`clearDiagnostics()`，預設最多 100 筆、可配置上限 1–500。保留既有 ANN primary、明確 AniList crosswalk fallback、VNDB explicit ID 與取消政策。
- `artwork-adapter.js` 提供安全投影的 `getDiagnostics()`，包含 cache/pending/disposed 與 provider events；`app.js` 注入同一 provider bundle 的 getter，沒有建立第二個 provider/cache owner。

## 真實資料映射盤點（非 live provider 驗收）
- `tools/audit-artwork-coverage.cjs src/data/assets/data.js src/data/assets/emq-data.js` 實際盤點正式附帶資料：AMQ 9,516 works 中 9,489 有明確 ANNID（99.72%）；38,821 songs 中 38,761 關聯至具 ANNID 作品（99.85%）。EMQ 6,645 works 中 6,570 有符合格式的 VNDB ID（98.87%）；16,839 songs 中 16,639 關聯至具 VNDB ID 作品（98.81%）。JSON 報告 `artifacts/batch277-regression/artwork-coverage-audit.json`。
- 這些百分比只衡量資料 ID 覆蓋，不能推導封面可達、圖片可解碼、CORS、授權或 attribution 成功。

## 驗證
- Focused Node：`node --test tests/artwork-coverage-audit.test.cjs tests/artwork-adapter.test.cjs tests/artwork-provider-factory.test.cjs tests/app-artwork-lifecycle.integration.test.cjs`，19/19 PASS。
- 全量 Node：99 個 `tests/*.test.cjs` 分 20 組，20/20 組 exit 0、310/310 subtests PASS；每組 log 與 exit code 在 `artifacts/batch277-regression/node-groups/`，aggregate 在 `node-suite-summary.json`。
- Architecture：1,344 PASS／0 FAIL。JS/CJS syntax 194/194；Python AST 34/34。

## 未結案（不得改標 PASS）
1. Live ANN/VNDB/AniList、CORS、rate limit、正式作品圖片 load/decode/attribution。Diagnostics 只是讓未來 runner 能定位原因，不代表網路成功。
2. IndexedDB save/reload：已知 HTTP/HTTPS localhost navigation 在 document load 前遭 `ERR_BLOCKED_BY_ADMINISTRATOR`；本批沒有重複探測或繞過政策。解除條件是取得批准 browser/CI runner。
3. Home/Catalog 人工 osu! Stable visual gate、外部 AMQ/EMQ 可聽音訊、Windows／實機鍵盤與觸控。

## 下一批 Batch278
先取得批准 browser/CI runner 執行 live artwork + IndexedDB acceptance；若沒有，繼續正式資料 mapping audit／provider report，並以正式 Home/Catalog DOM/CSS 與 Stable 參考差距為 UI P0。不要重做 Batch275/276 lifecycle 與 AniList wiring。
