# Batch 93 交接包（2026-10-27）

## 本批實作

新增 `src/multiplayer/room-command-service.js`，以 transport-neutral 的方式組合 Batch91 room state machine 與 Batch92 server-owned assessment adapter。它不載入到單機 app，也不選定 WebSocket／伺服器部署方案。

- 要求可信 `authContext`，actor ID 只來自 `authContext.playerId`；client `actorId` 不採信。
- client command allowlist 不含 `round.timeout`。房間開始回合時，題目由注入的 trusted selector 選取、round ID 由 server factory 產生、duration 使用 server config；client questionId／roundId／duration 不採信。
- `answer.submit` 先驗證 membership／active round／round ID／deadline／duplicate，再呼叫既有 title-only assessor；只有 assessment 成功後才 commit room state。
- `expireRound()` 只供 trusted server caller；deadline 未到拒絕，對未答玩家產生 timeout assessment，排除已答玩家避免重複評級，然後關閉回合。
- 新增 `tests/multiplayer-room-command-service.test.cjs` 與 `docs/MULTIPLAYER_ROOM_COMMAND_SERVICE_CONTRACT_BATCH93.md`，更新 architecture／acceptance／主清單／狀態／下一階段提示。

## 本批整合邊界

目前仍是純邏輯 orchestration，並非可部署多人伺服器。沒有 transport、authentication provider、rate limiting、concurrent command serialization、reconnect、multi-client E2E 或 SRS persistence。不能讓一份共享房間服務直接寫入跨使用者的本機 SRS Store；下一批先核對 user/source-aware API 與私有資料隔離，再設計 persistence adapter。

## 驗證

- `node tests/multiplayer-room-command-service.test.cjs`：PASS，涵蓋未認證、未知命令、actor spoof、非 host start、stale revision、server-selected question／round／duration、client assessment metadata spoof、duplicate answer、snapshot membership、early timeout、timeout grade 與 timeout 重複呼叫。
- - 45 個 `tests/*.test.cjs` 腳本均有獨立成功證據：44 個非-tooling 腳本分兩批 22/22 與 22/22 PASS；`tests/tooling.test.cjs` 9/9 PASS。
- `node tools/check-architecture.cjs`：719 passed／0 failed。
- JS／CJS syntax：100/100 PASS。
- Source audit PASS：AMQ 38,821 songs／9,516 works、EMQ 16,839 songs／6,645 works；重複 ID、懸空參照、跨來源衝突均 0。
- Mapper verification PASS：Catalog 55,660；AMQ 37,939／38,821 有候選，EMQ 16,839／16,839 有候選。
- Catalog benchmark 5 次 PASS；build 約 1,160.784 ms，僅本機 Node 觀察值。
- Source hashes unchanged：`data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- Manifest／ZIP integrity 在本批文件更新後重新建立並驗證；最終 entry count／ZIP file count／SHA-256 以交付回報為準。

## 不變規則

Candidate302、Candidate382 Stage 0、`src/data/assets/` 保持唯讀；工作副本無 `.git` 不假造 branch／commit；UI／CSS 大重構最後做；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試相同導覽路徑。
