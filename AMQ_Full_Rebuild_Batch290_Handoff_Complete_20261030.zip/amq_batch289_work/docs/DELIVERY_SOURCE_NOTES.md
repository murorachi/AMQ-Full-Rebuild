# 交付包文件來源說明

更新日期：2026-10-27

本交付包包含使用者指定的四份接手文件，來源如下：

1. `AGENTS.md`：從 GitHub repository `murorachi/Amq-` 的 `main` 分支讀取。GitHub 回傳的 blob SHA：`3e2263b5ac0104add8a8f2cd4418af5aff8b1ef3`。原始頁面：https://github.com/murorachi/Amq-/blob/main/AGENTS.md
2. `AI_START_HERE.md`：使用 Batch 15 本地工作副本中的實際檔案。
3. `docs/WORK_STATUS.md`：使用 Batch 15 本地工作副本中的實際檔案。
4. `docs/MASTER_CHECKLIST.md`：使用 Batch 15 本地工作副本中的實際檔案。

已確認 GitHub `murorachi/Amq-` 的 `main` 分支存在 `AGENTS.md`，但根目錄 `AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md` 在該分支均回傳 404。因此，後三份文件不是從該遠端分支下載；它們是目前 Batch 15 重建工作副本內的版本，並已直接包含在本交付包中。不得把這三份本地文件描述為遠端 main 分支的內容。

這份說明用來保留來源與版本脈絡，避免 Codex 把不同位置或不同版本的文件混為一談。
