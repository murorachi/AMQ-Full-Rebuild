# AMQ 新版重建交接：Batch135（有界資源保護）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 唯讀。

## 修改
- `server/http-server.cjs`：login／registration attempt maps 增加每 60 秒最多一次的過期清理與硬容量，預設每張 map 4,096 entries；options `authAttemptMapMaxEntries`、`authAttemptCleanupIntervalMs` 可調。
- `server/multiplayer-host.cjs`：每 owner 預設最多 10 個 active rooms、10 次 room creations／60 秒；owner creation timestamps map 預設最多 10,000 owners。Room close 釋放 active cap。
- `server/http-server.cjs` 傳入 room limit options，並在 429 error 有 retryAfterMs 時回傳 `Retry-After` header。
- 新增 `server-auth-srs.integration.test.cjs` bounded map test；擴充 `multiplayer-http.integration.test.cjs` 驗證 cap／quota／window reset／Retry-After／既有 snapshot 和 close command 不受限制影響。

## 驗證
- `node --test tests/server-auth-srs.integration.test.cjs tests/multiplayer-http.integration.test.cjs tests/multiplayer-host.integration.test.cjs`：11/11 PASS。
- 全量 57 個非-tooling test scripts 逐檔 exit 0；tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
- AMQ／EMQ source hashes unchanged。

## 未解決
- Closed rooms 仍保留在 SQLite／host map，沒有 retention policy。本批不盲刪歷史資料。
- 真實瀏覽器／多節點 E2E 未驗收。

## 下一步
Batch136：盤點 closed-room 查閱用途、授權與 command replay 依賴；只有證明安全才加入 retention，否則只改 discovery／archive metadata，不刪歷史 room rows。
