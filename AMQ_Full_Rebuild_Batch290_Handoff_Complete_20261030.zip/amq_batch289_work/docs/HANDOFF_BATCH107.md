# Batch107 交接包：開放註冊與 Google OIDC（2026-10-28）

## 本批決策

使用者明確取消邀請制，改為「可選 Google 登入 + 一般帳號密碼註冊 + 個人 SRS」。目標是讓原始專案可公開分享並讓其他人自行架設。Google OAuth 是選配，未配置時帳密註冊／登入仍要可用。

## 已實作

- 移除前端邀請碼輸入、管理者建立邀請與邀請結果 UI。
- 移除活躍邀請建立 API、邀請驗證註冊流程。舊 SQLite `invitations` table 為了向後相容保留，但不再有 API 使用。
- 首位管理者仍需以啟動器的一次性 bootstrap token 初始化。初始化前拒絕一般註冊及 Google 首次登入，避免任何人先建立一般帳號而阻止合法管理者初始化。
- 開放一般帳號註冊，沿用 scrypt 密碼雜湊，並加每 IP 註冊速率限制。
- 新增 `server/google-oidc.cjs`：Authorization Code Flow、PKCE S256、state、nonce、短效 HttpOnly SameSite=Lax state cookie、Google JWKS RS256 驗證與 issuer/audience/expiry/iat/nonce/azp claims 檢查。
- 新增 `/api/auth/google/status`、`/api/auth/google/start`、`/api/auth/google/callback`。Google OAuth 未設定時 UI 隱藏 Google 按鈕，普通帳密照常使用。
- Google OAuth 只請求 `openid profile`，不請求 email/Gmail 權限；使用 Google `sub` 做唯一關聯，保存 profile display name，不按 email 自動合併。
- Google 登入建立一般使用者，SRS 經現有 session 及 remote SRS bridge 按 user ID/source 隔離。
- `server/database.cjs` 新增非破壞式 migration，保留 Batch106 舊資料，新增 `google_sub` 唯一索引及 `display_name`。
- 更新 `docs/PRIVATE_SERVER.md`、`docs/ARCHITECTURE.md`、`docs/ACCEPTANCE.md`、`README_FIRST.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`。

## 重要限制

- 一般帳密帳號與 Google 帳號目前是獨立身分；尚無明確 link/unlink 流程。禁止依 email 自動合併，否則可能錯誤合併帳號與 SRS。
- 真實 Google Client ID/Secret 尚未設定。自架者需自行在 Google Cloud Console 建立 OAuth Web client，並設定 `AMQ_GOOGLE_CLIENT_ID`、`AMQ_GOOGLE_CLIENT_SECRET`、`AMQ_GOOGLE_REDIRECT_URI`。不要將 Secret 寫入 ZIP 或貼到對話。
- 真實 Google 瀏覽器登入、HTTPS 公網部署、正式安全審查尚未驗收。mock OAuth／測試簽署 JWT 不等於真實 Google E2E。
- 一般帳密註冊需先完成第一次管理者 bootstrap；這是防止第一位註冊者搶先卡住管理者初始化，不是邀請制。
- 仍保留 Batch106 的 session 記憶體限制、遠端 SRS conflict fail-closed、無離線佇列／多端合併等限制。

## 新增／更新測試

- `tests/google-oidc.test.cjs`：最小 scopes、Authorization Code + PKCE、JWT signature/issuer/audience/expiry/nonce、錯誤 nonce/audience、未配置 OAuth。
- `tests/database-google-migration.test.cjs`：舊 SQLite schema migration、既有使用者保留、Google sub 唯一性。
- `tests/server-auth-srs.integration.test.cjs`：開放註冊、bootstrap gate、mock Google callback state 綁定、同一 `sub` 重複登入、個人 SRS 隔離、邀請 API 移除。
- `tests/account-panel.integration.test.cjs`：Google 配置狀態、Google 登入按鈕、一般帳號註冊、remote SRS lifecycle。

## 下一步

1. 執行完整 Node test scripts、tooling、architecture、syntax、source audit、mapper、5-run benchmark。
2. 修正所有實際測試失敗，不能把中斷／timeout 當 PASS。
3. 重建 `MANIFEST.sha256` 與 Batch107 ZIP，驗證 CRC、manifest entries、缺檔／額外檔／hash mismatch。
4. 使用者在自己的 Google Cloud Console 設定 OAuth client 後，再做真實瀏覽器 Google 登入與 SRS 保存驗收。
5. 不修改正式基準／來源資料，不初始化 Git，不提前進行 UI/CSS 大重構。
