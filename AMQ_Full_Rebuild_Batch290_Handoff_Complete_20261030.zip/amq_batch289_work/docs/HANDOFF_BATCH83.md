# Batch 83 交接：中文標題索引接入曲庫搜尋
日期：2026-10-27

## 本批完成
- `src/ui/catalog-browser.js` 接入既有 `appSettingsStore.chineseTitlesEnabled` 與 `chineseTitleProvider`。
- 啟用時 Provider 載入成功後，分頁讀取目前 runtime catalog，為複製的 record 合併 `animeAliases` 並重建搜尋索引；不改寫原始 catalog／曲庫來源資料。
- 設定關閉與 dispose 會使未完成的索引重建請求失效；Provider 失敗不會清除目前曲庫。

## 驗證
- `node --check src/ui/catalog-browser.js` PASS。
- `tests/*.test.cjs` 逐檔執行均 exit 0。
- `node --test tests/tooling.test.cjs` 8/8 PASS。
- `node tools/check-architecture.cjs` 修改後獨立執行 539 passed／0 failed；之後聚合長命令逾時，不將該次聚合命令計為通過。
- 未執行真實瀏覽器外部 JSON／CORS E2E。已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試相同路徑。

## 尚未完成
- AMQ-990 缺 catalog-browser 專項測試：Provider 成功、中文別名全文命中、關閉後原始索引恢復、Provider 失敗、延遲請求失效。
- AMQ-982 安全資料庫更新／匯入未實作，仍為下一批最高優先級。更新資料必須真正被 runtime 消費；不可只實作未接線的 staging API。
- 工作副本無 `.git`；未初始化 Git，無 branch／commit 可報告。未修改 Candidate302、Candidate382 Stage 0 或 `src/data/assets/`。
