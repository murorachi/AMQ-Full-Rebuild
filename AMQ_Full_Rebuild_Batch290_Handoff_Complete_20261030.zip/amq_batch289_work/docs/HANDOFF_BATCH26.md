# Batch 26 交接：FSRS／SRS

## 已完成
- `src/learning/fsrs-scheduler.js`：FSRS-6 default scheduler、learning／relearning steps、stability／difficulty、interval、preview。
- `src/persistence/srs-store.js`：使用 `aniSrsScheduleV1`、保留 schema，支援 enroll／suspend／resume／rate、due queue、dailyNew／batchSize、storage event 與 corrupt schedule quarantine。
- Quiz panel：AMQ 卡片加入／暫停／恢復、開始到期複習、Again／Hard／Good／Easy、預覽下次間隔與設定。SRS 卡片的已計分題目需評級或明確略過評級才能下一題。
- 測試：FSRS 6/6、SRS store 13/13、quiz session 10/10、panel integration PASS；架構 385/0。

## 限制
- SRS 目前只支援 AMQ，因 legacy schedule 卡片沒有 source 欄位；EMQ 不會被猜測遷移。
- 黑名單資料源尚未核對／接入。真實瀏覽器 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。

## 下一步
1. 核對舊版黑名單 key／schema／事件，再接入 SRS `isBlacklisted`。
2. 若要支援 EMQ SRS，先定義 source-aware schema 與無歧義遷移策略。
3. 瀏覽器環境恢復後驗證真實音訊與完整 UI。
