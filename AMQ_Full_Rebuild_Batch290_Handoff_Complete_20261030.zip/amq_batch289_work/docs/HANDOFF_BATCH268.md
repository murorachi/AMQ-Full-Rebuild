# Batch268：UI 優先與視覺證據精簡

## 工作優先級
UI 實作與視覺差距修正仍是主要工作；封裝瘦身只是支援工作，不得取代每批實際 UI 改善。下一批優先延續 Home／Catalog 的真實作品視覺、正式資料布局與 osu! 參考對照。

## 證據保留規則
- 只在主要交付包保留最新一輪完整對照組：Home 四尺寸、Catalog fixture 四尺寸、Catalog opaque-origin error 四尺寸。
- 上述 12 張最新對照圖轉為 JPEG quality 82；PNG 原檔不放入本次交付包。
- 移除其他歷史批次截圖、重複原型截圖與舊視覺照片。它們不是本批驗收所需證據。
- 移除歷史 artifacts/logs 內的原始 `.log`／`.out`；必要測試結果保留在 handoff／WORK_STATUS／測試摘要中。
- 不移除程式碼、測試、正式資源、必要 fixture、工作清單、差距表或交接文件。
- osu! 參考圖若已存在於後續批次或由使用者提供，必須列入明確 allowlist 保留。Batch267 ZIP 內沒有可明確辨識為官方 osu! 參考素材的獨立圖片；不可把 AMQ 原型截圖冒充 osu! 參考圖。官方參考仍以 `docs/DESIGN_LANDING_FLOW.md` 中的來源與比較規格為準。

## Batch268 封裝檢查
- 舊包中的圖片：578 張；本包保留最新對照圖 12 張（JPEG）。
- 舊包中的大量歷史測試日誌已從主要交付包排除；測試摘要仍保留在文件。
- 此次只做交付證據瘦身與政策落地，未宣稱完成真實曲庫、live artwork、audio 或最終 osu! 視覺驗收。
- ZIP CRC、manifest、SHA-256 需以實際驗證結果為準。

## 最新圖片對照
- `catalog-data-fixture-1024x768.jpg`（由 `catalog-data-fixture-1024x768.png` 轉換，僅供視覺比較）
- `catalog-data-fixture-1440x900.jpg`（由 `catalog-data-fixture-1440x900.png` 轉換，僅供視覺比較）
- `catalog-data-fixture-1920x1080.jpg`（由 `catalog-data-fixture-1920x1080.png` 轉換，僅供視覺比較）
- `catalog-data-fixture-390x844.jpg`（由 `catalog-data-fixture-390x844.png` 轉換，僅供視覺比較）
- `catalog-opaque-origin-error-1024x768.jpg`（由 `catalog-opaque-origin-error-1024x768.png` 轉換，僅供視覺比較）
- `catalog-opaque-origin-error-1440x900.jpg`（由 `catalog-opaque-origin-error-1440x900.png` 轉換，僅供視覺比較）
- `catalog-opaque-origin-error-1920x1080.jpg`（由 `catalog-opaque-origin-error-1920x1080.png` 轉換，僅供視覺比較）
- `catalog-opaque-origin-error-390x844.jpg`（由 `catalog-opaque-origin-error-390x844.png` 轉換，僅供視覺比較）
- `home-1024x768.jpg`（由 `home-1024x768.png` 轉換，僅供視覺比較）
- `home-1440x900.jpg`（由 `home-1440x900.png` 轉換，僅供視覺比較）
- `home-1920x1080.jpg`（由 `home-1920x1080.png` 轉換，僅供視覺比較）
- `home-390x844.jpg`（由 `home-390x844.png` 轉換，僅供視覺比較）


## UI 實作（本批主要工作）
- `src/styles/ui-design-landing.css`：改善 Catalog 曲目列 hover、選取狀態與鍵盤 focus-visible；選取狀態新增左側強調線，避免只靠背景顏色區分。
- 尊重 `prefers-reduced-motion`，不新增 DOM、不改資料狀態 owner、不影響查詢或音訊邏輯。
- 新增 `tests/batch268-catalog-row-visual.contract.test.cjs`，保護五項視覺／可及性規則。
- 這是局部視覺改善，不代表 Catalog 真實資料或最終 osu! 對照已驗收。
