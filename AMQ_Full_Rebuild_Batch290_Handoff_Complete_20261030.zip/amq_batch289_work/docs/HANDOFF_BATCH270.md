# Batch270 Handoff：以 osu! Main Menu 結構改善 Home

## 參考圖對應
- `artifacts/osu-reference/osu-main-menu.jpg`：首頁主選單，借用大型主視覺＋清楚的縱向主選項，不複製 osu! logo／原始功能。
- `artifacts/osu-reference/osu-intro-screen.jpg`：品牌入口與背景層次參考；AMQ 不另加無功能的啟動畫面。
- `artifacts/osu-reference/osu-song-selection.jpg`：選歌頁作品封面、選取列表、詳情及底部控制區參考。
- `artifacts/osu-reference/osu-multiplayer-lobby.jpg`：多人房間列表、房間狀態、玩家頭像與底部操作參考。
- `artifacts/osu-reference/osu-game-modifiers.jpg`：猜歌遊戲設定中的 Mod 選擇／倍率摘要參考；不直接移植 osu! 的規則。
- 圖片來源均是 osu! 官方 Wiki Interface 圖片，來源 URL 記錄於 `docs/OSU_UI_REFERENCE_BATCH270.md`。

## 本批實作
- `src/styles/ui-design-landing.css`：Home 改為桌面左側主視覺、右側縱向主要功能入口、下方近期學習區；平板維持分欄，900px 以下改為堆疊布局，手機主要入口採兩欄。
- `src/ui/app-shell.js`：當 playback-history API 不存在時也執行既有 render owner，明確呈現空狀態並設定 `data-history-state="empty"`，不留未初始化的狀態。
- `tests/ui-shell-css.contract.test.cjs`：更新過時的 Home grid 契約，保護新的主選單構圖。
- 新增 `tests/batch270-home-catalog.browser.py`，保留正式 app-shell/CSS，Catalog 資料仍明確為六筆 layout fixture。

## 測試證據
- Batch270 Home/Catalog 四尺寸：77/77 PASS（1920×1080、1440×900、1024×768、390×844），無水平溢位、桌面無整頁垂直溢位、0 page errors。
- `tests/ui-shell-css.contract.test.cjs`：8/8 PASS。
- `tests/batch269-catalog-visual.contract.test.cjs`：6/6 PASS。
- `tests/batch268-catalog-row-visual.contract.test.cjs`：5/5 PASS。
- Catalog browser tests 6/6；Catalog integration PASS；source-runtime integration PASS；navigation contract 2/2；Quiz UI state 5/5。
- Architecture Checker：1,321 PASS／0 FAIL。
- 新增四尺寸最新截圖位於 `artifacts/batch270-home-catalog/`，只保留 JPEG；Catalog fixture 與 opaque-origin error 截圖分開命名。
- 五張官方 osu! 參考圖實際封裝於 `artifacts/osu-reference/`。

## 限制／未結案
- Home 無真實播放紀錄時仍沒有作品封面，畫面結構已改善但藝術視覺密度仍低於 osu! 參考。不得以空白圖示當作完成的 artwork。
- Catalog 截圖中的正常列表是六筆測試 fixture，不是正式曲庫；HTTP-origin IndexedDB 仍受既知 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋，沒有重試。
- 尚未改造 Multiplayer Lobby 與 Mod 選擇畫面；本批將其參考對應與差距列入後續工作，不宣稱完成。
- 未執行全量 Node suite、live ANN/VNDB、live audio、Windows／實機與人工最終 osu! 視覺 gate。

## 下一批
Batch271 優先將 Main Menu / Multiplayer / Mod 三張參考圖映射到 AMQ 現有頁面 owner：先檢查 Multiplayer DOM 與現有設定／Mod 狀態，不另造第二份狀態；完成一個可用的多人房間視覺切片，並盤點猜歌 Mod 功能缺口。若現有產品沒有對應 Mod owner，先記錄阻塞，不虛構功能或倍率。
