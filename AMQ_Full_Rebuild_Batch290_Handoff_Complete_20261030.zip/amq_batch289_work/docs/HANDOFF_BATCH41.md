# Batch 41 交接：歷史摘要安全與版本化猜歌設定

## 已完成
- `src/persistence/quiz-history-store.js`：將摘要 storage read exception 與 JSON parse failure 分開。讀取失敗時 `summaryWriteBlocked=true` 並阻止 summary persist；成功 storage event reload 才解除阻塞。無效 JSON 仍先 quarantine 再重建。
- `tests/quiz-history-store.test.cjs`：新增 read failure 不覆寫原始摘要、flush 阻塞與 storage event recovery 回歸；測試數 10/10。
- 新增 `src/persistence/app-settings-store.js`：schemaVersion 1，設定欄位 `target`、`questionCount`、`clipSeconds`、`acceptPartial`、`autoPlay`。Key `amqLearningAppSettingsV1`；recovery key `amqLearningAppSettingsRecoveryV1`。
- 新增 `tests/app-settings-store.test.cjs`：5/5 PASS，涵蓋 save/restore、invalid schema、recovery failure、read failure/recovery、invalid mutation/write failure。
- `src/ui/quiz-panel.js` 接線：mount restore、control change save、storage event 更新未聚焦控件、顯示持久化警告、dispose cleanup。UI integration test 證實設定會保存。
- 更新 `src/index.html`、`tests/tests.html`、`tests/quiz-panel.test.cjs`、`tools/check-architecture.cjs` 與契約／進度文件。

## 驗證結果
- `tests/*.test.cjs`：22/22 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：430 passed／0 failed。
- Source audit PASS：AMQ 38,821、EMQ 16,839；重複 ID、dangling references、cross-source ID collisions 均 0。
- Mapper verifier PASS：Catalog 55,660；AMQ candidates 37,939、EMQ candidates 16,839。
- Catalog benchmark 5 iterations PASS；`node --check` 全量 JS/CJS PASS。
- 來源資產 SHA-256 未變，見 `/mnt/data/amq_batch41_logs/source-hashes.txt`。
- 詳細日誌在 `/mnt/data/amq_batch41_logs/`。

## 交付封包
- ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch41_HistorySettings_20261027.zip`。
- 封包與 manifest 逐項 SHA-256 驗證通過；ZIP CRC 檢查通過。精確 entry／hash 數量記錄於 `/mnt/data/amq_batch41_logs/package-verification.json`。

## 限制
- 測試為 Node + mock storage；未驗證真實瀏覽器 localStorage、跨分頁 storage event、pagehide 與 quota 行為。
- 真實瀏覽器 E2E 仍因先前 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞；未重試相同方法。
- 歷史明細與摘要仍是不同 key，跨 key 不是原子交易。
- 設定 store 僅涵蓋目前 UI 實際存在的猜歌設定；深色主題、背景 IndexedDB、收藏／自訂清單等仍未完成／待確認。
- 工作副本無 `.git` metadata；未初始化 Git、未 commit／push。

## Batch 42 下一步
1. 建立 familiarity／history／SRS／blacklist／settings storage failure matrix。
2. 檢查 read/write/recovery/storage event/dispose 狀態是否一致。
3. 查驗跨模組 UI 持久化狀態投影，修正有測試證據的錯誤。
4. 驗證設定外部更新、聚焦輸入保護、storage clear 與 invalid recovery。
5. 全量回歸，更新同一份主清單、狀態、manifest 與 ZIP。
