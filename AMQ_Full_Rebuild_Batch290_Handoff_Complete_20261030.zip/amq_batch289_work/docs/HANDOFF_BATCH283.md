# Batch283 Handoff：Catalog 對照 Stable、來源列重構與 Dock 控制台

## 本批目標與視覺參考
- 使用者明確指出：除首頁外，其他 UI 以前沒有真的逐張對照原圖。這批先以 `artifacts/osu-reference/osu-song-selection.jpg` 為準，並輸出 AMQ／Stable 並排圖與逐項差距表。
- 不把 fixture 說成 live data，也不把自動幾何 PASS 說成視覺驗收 PASS。

## 完成的實作
1. Catalog 頂部將 AMQ／EMQ／MIX tabs 從原本高大的 mode/status panel 拆出，改為緊湊來源列；狀態資訊折疊收納。沿用原有 mode buttons 與 state owner。
2. 桌面布局改為左篩選、中央選取作品舞台、右側歌曲佇列，對照 Stable 的背景主視覺與右側歌曲列。沒有虛構排行榜、玩家成績、歌曲難度或 Mods。
3. 新增 selected artwork scene layer。只有既有 artwork adapter 回傳 HTTPS／blob 圖片且圖片載入成功後才會更新背景；選取變更清除舊背景，請求序號與 dispose 防止過期回寫。
4. Dock 預設收合約 52px；展開後將搜尋、目前播放、進度、控制按鈕、模式／音量與播放佇列放入有界控制台。ResizeObserver 實際高度驅動列表高度，收合／展開兩態都驗證分頁不被遮擋。
5. 新增 `catalog.selected-artwork-background`、`catalog.selected-work-stage`、`catalog.selected-work-details` component IDs；保留原有 Catalog query／selected record／audio／router owner。
6. 更新四尺寸瀏覽器測試及 7 項 focused contract，並提供 `tests/batch273-home-menu.browser.py` 相容入口，舊交接中的測試命令仍可執行。

## 證據
- 並排圖：`artifacts/batch283-catalog-stable/catalog-vs-osu-stable-1920x1080.jpg`。
- 差距表：`docs/OSU_CATALOG_VISUAL_GAP_BATCH283.md`。
- 四尺寸 browser：`python tests/batch283-catalog-stable.browser.py`，148/148 PASS；1920×1080、1440×900、1024×768、390×844。
- Focused Node：`node --test tests/batch283-catalog-stable-layout.contract.test.cjs tests/catalog-filter-layout.contract.test.cjs tests/catalog-browser.integration.test.cjs tests/skin-theme-adapter.test.cjs tests/free-player-dock.test.cjs`，39/39 PASS。
- Architecture Checker：1,358 PASS／0 FAIL。
- JS/CJS syntax：205/205 PASS。Python AST：37/37 PASS。

## 尚未驗收／明確限制
- 並排畫面仍與 Stable 有明顯差距。AMQ 左側顯示篩選而不是全球排名，這是刻意保留真實產品語義；中央背景目前只會在真實 provider artwork 載入成功後出現。
- 截圖的六首曲目與 SVG 封面是明確 fixture，不是正式曲庫、ANN/VNDB live artwork 或外部音訊證據。
- 人工 osu! Stable 視覺 gate、HTTP-origin IndexedDB、Windows／真機、外部音訊與正式曲庫仍未完成。
- Node suite 已分 10 組執行全部 101 個 `*.test.cjs` 檔案，319/319 subtests PASS；第一個總控命令觸及工具時間窗口後，G08–G10 分別執行並取得 exit 0。

## 下一批
優先按 Stable 參考圖處理 Multiplayer Lobby 與 Quiz：先產生實際並排圖與差距表，再改正式 DOM/CSS。不得造假玩家、房間、聊天、排行榜或 Mods。精簡 ZIP 只保留本批最新截圖、五張官方參考圖、必要測試資產與歷史摘要。
