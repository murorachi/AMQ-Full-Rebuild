# AMQ 產品核心功能契約（Batch 18）

## 用途與證據邊界

本文件把 `docs/FUNCTION_INVENTORY.md` 的靜態線索轉成可逐步驗收的產品契約。它不是對舊版行為的臆測，也不表示下列功能已全部實作。

參考檔：使用者上傳的 `AMQ382(1).html`
- bytes: 1,611,096
- SHA-256: `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`
- HTML title: `AMQ學習工具 · Candidate381 第二批無障礙與資料品質維護候選 · 081713b9`
- 定位：使用者指定的 Candidate382 參考檔；內容存在 Candidate381 標記及 Stage I 歷史線索。為避免偽造版本身份，本文件保留檔案實際證據，不把它改稱 Stage 0。
- 本批沒有搜尋 Candidate302，也沒有修改或覆蓋參考檔。

## 產品切片與驗收契約

### PC-01 曲庫載入與狀態
- 唯一權威狀態是 `AMQCore.state`／既有 load-state controller。
- 必須區分 `not-loaded`、`loading`、`loaded`、`partial`、`empty`、`failed`。
- 載入中的新請求必須使舊請求失效；取消不可永久卡在 loading。
- UI 不得只依 Promise 是否 resolve 自行推斷第二套載入狀態。
- 測試：來源成功、空來源、部分無效、來源例外、取消、舊請求延遲完成。

### PC-02 曲庫瀏覽與搜尋
- 查詢必須走 `AMQData.queryIndex`，UI 不得另寫一套曲庫掃描。
- 搜尋欄位依目前已實作內部契約：歌曲標題、歌手、作品標題、作品別名、歌曲 aliases。
- 結果顯示 `total`，分頁只改變目前可見列，不得改寫 Catalog。
- 空資料、無結果、載入中、載入失敗必須有不同畫面狀態。
- 顯示原始標題文字；搜尋正規化不得改寫使用者看到的文字。

### PC-03 篩選、排序與分組
- 篩選使用 query index 的共用條件語意；不在 UI 重複實作篩選規則。
- 執行順序：篩選 → 排序 → 分頁。
- 未指定排序時保留輸入順序；指定排序時同值穩定排序；缺值固定排最後。
- 分組計數必須涵蓋全部符合篩選的資料，不受分頁影響。
- 舊版有哪些篩選選項、預設排序與排序標籤，須逐項從參考檔／實測核實，不因新版 API 存在就宣稱相容。

### PC-04 AMQ／EMQ／MIX 模式邊界
- 模式只有一個權威狀態欄位。
- 每種模式的來源集合需由明確設定提供；不得自行推定 MIX 的混合方式。
- 模式改變時取消舊資料載入，避免舊模式結果發布。
- 模式改變是否重置回合、分數、答案、計時器與音訊，必須由已核實產品規則決定。
- 本契約不把「模式按鈕可切換」視為遊戲模式已完成。

### PC-05 猜歌回合狀態機（新版核心已實作；舊版細節與瀏覽器待驗收）
實作前必須以來源證據確認狀態與轉移：
- 候選狀態至少需要評估 idle、ready、playing、paused、answered、timed-out、finished。
- 必須定義 start、pause、resume、submit、next、timeout、end、reset 的合法來源狀態及副作用。
- 同一回合重複提交、計時器競態、重複 next 與過期回呼不得重複計分。
- 以上狀態名稱只是待評估草案，不是宣稱舊版已有相同狀態機。

### PC-06 答案比對（新版核心已實作；舊版完整別名／規則待核對）
- 分離輸入正規化與答案正確性判斷。
- 別名資料來源、大小寫、Unicode、標點、空白、大小寫折疊、重複提交及答案揭示時機都必須有明確契約。
- 不得只因 query index 的搜尋正規化存在，就將其直接當作答案比對規則。
- 建立固定 fixtures，至少涵蓋正確答案、合法別名、錯誤答案、空答案、重複提交與 Unicode 邊界。

### PC-07 音訊播放（AudioService 核心與 mock integration 已通過；真實音訊待驗收）
- 所有播放請求由單一 AudioService／播放 owner 管理。
- 每次新請求使舊請求失效；stop/cancel/dispose 具有明確差異。
- 候選來源排序、音訊與影片類型、timeout、HTTP error、媒體 error、play() rejection、重試上限必須有測試。
- 必須分開記錄「候選已找到」「媒體元素載入」「play() promise 成功」「使用者實際可聽」；前三者不能單獨代表最後一項。
- 不在音源 URL／檔名順序未核實前生成正式 `audioCandidates`。

### PC-08 收藏、清單與持久化（清單／看番狀態 UI 與出題池已接線；瀏覽器待驗收）
- 自訂清單使用 `aniCustomPracticeListsV1`；新版新增 `workRefs: [{ source: "AMQ" | "EMQ", id: string }]`，舊 `animeIds` 保留但因無來源資訊不自動套用。看番狀態使用 `aniAnimeWatch_v1`，新 API 以來源明確 work-ref key 保存，舊裸 ID 狀態不自動遷移。
- Batch 51–53 已接入清單 CRUD、成員新增／移除、看番狀態、清單選擇與猜歌出題池 eligibility，並修正 persistence failure UI 文案／recovery 投影。AMQ／EMQ 相同數字 work ID 不互相匹配。證據見 `docs/PERSONAL_LIBRARY_CONTRACT_BATCH50.md` 與 `docs/HANDOFF_BATCH52.md`、`docs/HANDOFF_BATCH53.md`。
- CRUD 必須處理重複操作、刪除清單後設定參照清理、損壞儲存及配額／權限失敗；相關 Node／VM integration 已測試，跨 key 寫入仍不具交易原子性。
- 收藏 `aniFavorites_v1` 的身份範圍與實際 handler 尚未由目前靜態證據證實，因此不寫入、不推定作品／歌曲身份。
- 持久化失敗不得讓當前 UI 假裝永久保存成功。大型曲庫不放入同步 key-value 儲存。

### PC-09 UI 與可存取性（功能性接線已有 Node integration；真實瀏覽器／響應式待驗收）
- UI 只呈現核心狀態，不創造第二份權威狀態。
- 主要互動有可見 focus、語意化標籤、鍵盤操作與錯誤狀態。
- 響應式驗收需涵蓋桌面及窄螢幕；靜態 CSS 檢查不能取代真實瀏覽器驗收。
- 保留參考檔中已認可的視覺方向，但採新元件替換舊實作，不以隱藏舊 UI 冒充重構完成。

## Batch 18 結論與下一批

- 已完成：來源證據範圍記錄、12 個產品功能切片的最低契約、依賴次序及不可推定項目。
- 尚未完成：正式遊戲規則、音訊備援、真實 UI 接線與瀏覽器驗收。
- 下一批建議直接實作 PC-01 至 PC-03 的曲庫瀏覽切片，使用既有 query index，不新增通用架構層。若真實來源未放入工作包，需以明確的未載入狀態呈現，不能用假曲庫資料冒充正式資料。

## Batch 19 實作補充：曲庫瀏覽 UI

- `src/ui/catalog-browser.js` 是曲庫瀏覽 UI 與可獨立測試的瀏覽控制器；搜尋／篩選／排序／分頁全部委派給 `AMQData.queryIndex`，不複製資料掃描規則。
- UI 支援標題、歌手、作品、歌曲類型、來源欄位顯示；查詢索引也支援作品別名與歌曲 aliases 搜尋。
- 篩選條件會組合，結果總數在分頁前計算；頁碼與每頁筆數不會改寫 Catalog。
- 篩選選單的分組計數來自 `catalog.groupBy()`，且計算選單選項時會排除該選單自身條件，避免選中某項後其他選項消失。
- 空曲庫、無搜尋結果、未載入、載入中及載入錯誤有獨立文字狀態。重新載入或載入被取消時會清除舊 Catalog 的畫面，避免把舊模式資料留在新模式下。
- 真實來源仍需透過已配置的 Source Registry／Runtime Bootstrap 注入；目前工作包沒有正式資料來源檔，所以按鈕在未配置 runtime 時保持停用。UI 未內建示意歌曲。
- 驗收邊界：Node 控制器測試不等於真實瀏覽器視覺／互動驗收；瀏覽器 E2E 仍受環境政策阻擋。


## Batch 20 實作補充：真實曲庫載入

- 已將已核對雜湊的 AMQ／EMQ來源副本放入 `src/data/assets/`，透過 `src/data/source-runtime.js` 接入現有 adapter／registry／repository／runtime；UI 仍只讀共用載入狀態與 Catalog 快照。
- 初次啟動自動載入 AMQ；切換到 EMQ 會取消舊載入並載入 EMQ；手動重新載入也會使用目前模式。
- MIX 已由 Batch 29 接入 AMQ + EMQ composite catalog；兩個來源皆有未出題候選時以 2:1 權重抽題，單一來源耗盡時退回另一來源。這是依 `AMQ382(1).html` 靜態 `combinePool`／`chooseQuestion` 證據建立的重建規則，不代表 Candidate302／Stage 0 已驗收。AMQ 專屬篩選抑制 EMQ 的條件分支尚未接入，因新版目前沒有相應篩選 UI。
- 全量 mapping 已在本批實際重跑：AMQ 38,821／38,821、EMQ 16,839／16,839 通過新版內部資料契約。來源 schema 仍只代表目前可證實的 Candidate382 Stage I 資料證據，不代表 Candidate302／Stage 0 相容。


## Batch 21 實作補充：答案比對與回合狀態機

### 答案比對（PC-06：核心已實作，別名資料仍有限）
- 參考來源：使用者提供的 `AMQ382(1).html`，SHA-256 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`。靜態程式碼顯示使用 NFKC、`toLocaleLowerCase()`，並移除空白與 Unicode `C` 類控制字元；不自動刪除標點。
- 預設只做正規化後的精確匹配；`acceptPartial` 預設 false。開啟後，輸入至少 4 個正規化字元，且長度至少達別名的 55%，並且是別名前綴或子字串，才接受部分匹配。
- 可傳入作品、歌曲、歌手 aliases。AMQ 若同一正規化歌曲名稱及歌手對應多個作品，可接受關聯作品名稱；EMQ 不套用這項跨作品規則。
- `evaluateAll()` 分開回傳作品、歌手及歌曲名稱結果。現有來源 mapper 尚未擁有舊版所有中文別名資料，沒有資料的別名不會自行編造。

### 回合狀態機（PC-05：核心已實作，UI／音訊整合待完成）
- 相位：`idle`、`ready`、`playing`、`paused`、`answered`、`timed-out`、`revealed`、`finished`。
- 只有 `playing` 可提交答案或超時；空答案不會結束題目；重複提交及非法相位轉移被拒絕。
- `markAudioStarted()` 是計時起點；暫停期間不計入答題時間；引擎不自行建立 timer，外部 timer owner 必須呼叫 `timeout()`。
- 作品辨認熟悉度建議等級：答錯／跳過為 1；答對且耗時不超過 `instantSeconds` 為 3；其他答對為 2。`keepHigher` 預設保留較高既有等級，既有等級由注入的 `getFamiliarity()` 讀取。歌名／歌手輔助練習不回傳熟悉度更新。
- 未播放就跳過不計分也不增加完成題數；播放後跳過視為答錯；手動揭曉不計分、不增加完成題數。有限回合在完成指定題數後，下一次請求新題時進入 `finished`。
- 驗證：`node tests/answer-evaluator.test.cjs` 6/6、`node tests/quiz-engine.test.cjs` 10/10。這些測試只證明純邏輯契約，尚不代表猜歌 UI、實際音訊、歷史／SRS 寫入或瀏覽器流程已驗收。


## Batch 22 實作補充：音源候選與 AudioService（PC-07 核心已實作）

- `src/data/audio-candidates.js` 依參考 HTML 第 673、696、700–701、6,151 行的靜態規則生成候選：AMQ 音訊欄位第 9 欄按三個鏡像主機順序展開；EMQ `v` 先 Catbox mirror、再原 URL、去重。
- 正規化歌曲記錄現在有 `audioCandidates: [{url, source, kind:'audio'}]`。AMQ 沒有音訊檔名時為空陣列；不把 AMQ 的影片欄位放入 quiz 音訊候選。
- `src/audio/audio-service.js` 負責單一播放請求、候選 fallback、12 秒預設載入逾時、媒體 `error`、`play()` rejection、`NotAllowedError` 手動恢復、AbortSignal、替代請求取消、stop／dispose。候選由呼叫端注入，Service 不猜來源順序。
- AudioService `ready` 不是播放成功；只有媒體 `playing` 事件代表播放開始，未來 UI 應據此呼叫 quiz engine `markAudioStarted()`。
- 測試：音源候選生成／驗證 5/5；AudioService 11/11。此為 mock media Node 測試，未證明真實 URL 可播放。


## Batch 23 實作補充：猜歌 UI／Session 整合

- `src/engine/quiz-pool.js` 只挑選當前 AMQ／EMQ 來源、作品名與歌手非空且至少有一個音源候選的歌曲；以來源＋歌曲 ID 去重，並提供 no-repeat 隨機抽題。MIX 明確拒絕。
- `src/engine/quiz-clock.js` 是單一倒數 owner。只有 AudioService 的 `playing` 狀態才會啟動；暫停時間不扣除，恢復播放後再繼續。
- `src/engine/quiz-session.js` 整合 engine、evaluator、audio service、clock 及 no-repeat pool。`src/ui/quiz-panel.js` 是薄 DOM adapter，提供目標（作品／歌曲／歌手／全部）、題數、秒數、自動播放、部分答案、提交、播放／恢復、暫停、揭曉、跳過、下一題與結束回合。
- 主頁共享 `questionStatus` 僅作 engine phase 的投影；模式切換時 dispose 舊 session，MIX 不建立題庫。
- 測試：quiz pool 5/5、quiz clock 4/4、quiz session 6/6、quiz panel integration PASS；真實資料可播放候選 pool 為 AMQ 37,939、EMQ 16,839。
- 尚未持久化熟悉度／答題歷史／SRS；真實瀏覽器與媒體播放仍未驗收。


## Batch 24 實作補充：熟悉度持久化（PC-08 部分完成）

- `src/persistence/familiarity-store.js` 已實作 AMQ 舊版 status map 讀寫、0–3 驗證、0 值刪除、舊 key fallback、儲存失敗回報、storage event 重新載入及生命週期清理。
- EMQ 使用獨立 source-aware key，避免與 AMQ 的相同數字 ID 衝突。AMQ 舊版熟悉度可直接讀取；舊版共用 map 中來源不明的 EMQ 值不會被猜測遷移。
- QuizSession 在作答、超時及已播放後跳過的可計分結果中，依引擎回傳的 familiarity level 寫入；手動揭曉與未播放跳過不更新。
- 測試：familiarity store 6/6、quiz session 8/8、quiz panel integration PASS。
- 答題歷史、長期 summary、target summary 與 SRS 尚未接線，另有獨立 schema／去重／修復契約，不能用簡化寫入取代。


## Batch 25 實作補充：答題歷史與摘要（PC-08 部分完成）

- `src/persistence/quiz-history-store.js` 以新版獨立 key 儲存 detail／summary，舊版 `aniQuizHistory_v1`、`aniQuizHistorySummaryV1`、`aniQuizTargetSummaryV1` 只讀，不直接覆寫。
- 來源、目標、歌曲與日期統計皆由 persistence store 統一產生；UI 不重複計算。`all` 目標拆為作品／歌曲／歌手三筆。
- 有 2,000 筆明細上限、5,000 筆去重窗口、批次／延遲摘要保存、損壞資料 recovery 與儲存失敗狀態。
- 驗證：`node tests/quiz-history-store.test.cjs` 9/9、`node tests/quiz-session.test.cjs` 10/10、`node tests/quiz-panel.test.cjs` PASS。真實瀏覽器 localStorage／跨頁事件尚未驗收。
- SRS／FSRS 尚未接入；其評級 1–4 與熟悉度 0–3 是不同語義，不可混用。


## Batch 26 實作補充：FSRS 核心（PC-08 部分完成）

- FSRS scheduler 與 SRS store 已實作／Node 測試，但 UI 尚未接線。
- Grade 1–4 是使用者評估回憶難度，與猜歌答案正誤及熟悉度 0–3 完全不同；不可自動互相轉換。
- 目前 SRS 僅支援 AMQ，因 legacy schedule cards 沒有 source 欄位。排程 UI 應注入既有 quiz session 的固定題序，不能複製 audio／timer／engine。
- 驗證：`node tests/srs-store.test.cjs` 13/13；架構檢查 385 passed、0 failed。真實瀏覽器 E2E 未驗收。


## Batch 27 實作補充：FSRS／SRS UI（PC-09 UI 已接線）

- 新增 `src/learning/fsrs-scheduler.js` 與 `src/persistence/srs-store.js`，保留舊版 `aniSrsScheduleV1` schema、FSRS-6 default 權重、學習步驟、due queue 與評級轉移。
- SRS UI 支援 AMQ 卡片加入／暫停／恢復、到期複習、Again／Hard／Good／Easy、下次間隔預覽與設定。
- SRS 卡片 schema 無 source 欄位，因此拒絕 EMQ，不猜測 ID 歸屬。
- FSRS scheduler 6/6、SRS store 13/13、quiz panel integration PASS、架構檢查 385/0。
- 黑名單資料源、EMQ SRS 與瀏覽器真實播放驗收仍待完成。


## Batch 28 實作補充：黑名單（PC-09 部分完成）

- 黑名單持久化由 `blacklist-store.js` 統一管理；UI 不直接寫 storage。
- 歌曲與作品黑名單變更刷新 QuizSession eligibility cache，並影響後續 AMQ 抽題與 SRS queue；既有卡片不刪除。
- 黑名單 store 9/9、quiz panel integration PASS；完整回歸與架構檢查 400/0。
- EMQ SRS 尚未支援，舊 SRS schema 沒有 source 欄位；真實瀏覽器 E2E 仍受環境阻擋。


## Batch 28 實作補充：歌曲／作品黑名單

- `src/persistence/blacklist-store.js` 讀寫已核對的 `aniBlacklistedSongs_v1` 與 `aniBlacklistedAnime_v1`，保留同頁事件 `ani-blacklist-changed-v51`，並為損壞資料保留 recovery。
- 猜歌 UI 增加歌曲與作品排除控制；同一 eligibility predicate 供一般隨機題庫及 SRS due queue 使用。
- 測試：blacklist store 9/9；quiz panel integration PASS；架構檢查 400 passed／0 failed。
- Legacy ID 無 source，黑名單只套用 AMQ。EMQ SRS 仍需 source-aware schedule key。


## Batch 29 實作補充：MIX（PC-01／PC-03 部分完成）

- MIX 已正式載入 AMQ + EMQ composite catalog，source-aware pool 不合併兩個來源的身份。
- 兩個來源都有未出題候選時按 2/3 AMQ、1/3 EMQ 選來源；單一來源沒有候選時 fallback 到另一個來源。
- 真實資料測試：55,660 normalized records、54,778 playable candidates。
- Legacy AMQ-specific filter suppression 尚未移植；EMQ SRS 尚未支援；真實瀏覽器 E2E 未驗收。


## Batch 49 核心結案狀態（2026-10-27）

- PC-01 至 PC-04：新版內部資料載入、查詢、來源模式及 MIX 規則有 Node／整合測試；真實瀏覽器與舊版完整相容仍未驗收。
- PC-05 至 PC-06：新版 QuizEngine／QuizSession／AnswerEvaluator 核心與回歸測試已實作；舊版完整別名與細節相容未證實。
- PC-07：AudioService、候選 fallback、取消、timeout、playing 起點及 QuizSession 整合有 mock media 測試；真實可聽性仍 BLOCKED。
- PC-08：familiarity、history、settings、SRS、blacklist 已實作與測試；收藏／自訂清單／看番狀態 CRUD 未實作，因原始參考 HTML 不在目前工作副本且資料 schema 未證實。
- PC-09：核心 UI integration 已有 Node fake-DOM 測試；鍵盤選取、響應式、focus、真實瀏覽器 E2E 仍未驗收，純 UI／CSS 重構仍是階段 5。
- PC-12：多人與外部匯入列為 P2 延後，不阻擋單機核心；若重開範圍需提供服務協定／認證條件。

這些狀態是依目前工作副本與測試證據整理，不代表 Candidate302 或 Candidate382 Stage 0 相容已確認。


### PC-10：自訂清單控制猜歌出題池（Batch 52）

- 沒有選取清單時，猜歌池沿用目前來源、可播放候選、黑名單及 MIX 規則。
- 選取清單時，僅允許 work ref 完全符合 `source + animeId` 的歌曲進入候選池；同數字 ID 不跨 AMQ／EMQ 匹配。
- 清單成員變更會刷新 eligible pool。source-less legacy `animeIds` 不會被猜測遷移，因此舊清單可能暫時得到空題庫；UI 會提供明確提示。
- 驗證層級：Node VM store／quiz panel integration PASS；真實瀏覽器操作與音訊仍未驗收。


### PC-07 Batch 54 回歸補充

- Node integration 現已驗證 primary candidate play rejection 後 fallback 到 backup；倒數只會在 backup 真正進入 `playing` 後啟動。
- `canplay` 但沒有 `playing` 不會啟動計時；session dispose 後遲到的 media event 不會再發布 session state。
- QuizPanel mode switch 後，舊 AudioService 的遲到事件不會覆蓋新模式的共享 phase projection。
- 以上是 fake media／Node integration 證據；真實 URL 可聽性與瀏覽器媒體事件仍未驗收。
