# Batch 82 交接：中文作品標題 Provider 第一版接線
日期：2026-10-27

## 本批已完成
- 新增 `src/data/chinese-title-provider.js`，依舊版 Candidate381 靜態參考的固定版本 AniList Chinese／Bangumi-data JSON 建立標題 Provider；OpenCC 轉繁體按需載入。
- Provider 使用 Bangumi `sites` 的明確 MAL／AniList／VNDB ID crosswalk；不使用相似標題猜配。AMQ 使用 MAL work ID；EMQ mapper 將來源 `vndbId` 映射至 `animeVndbId`。
- IndexedDB cache TTL 7 天；支援過期 cache stale fallback、請求 timeout、AbortSignal 取消、AniList 部分來源失敗及無效資料拒絕。
- `appSettingsStore` 新增 `chineseTitlesEnabled`，預設 false 並向後相容。QuizPanel 只在啟用時載入外部資料／OpenCC，中文別名加入作品答案建議，答案揭曉時顯示已對應中文作品名。
- 更新 `src/index.html`／`tests/tests.html` script 順序、架構檢查、資料契約、功能盤點、工作清單與交接提示。

## 最終驗證證據
- `tests/*.test.cjs`：31/31 scripts exit 0。
- `tests/chinese-title-provider.test.cjs`：6/6 PASS。
- `tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：539 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 songs／9,516 works、EMQ 16,839 songs／6,645 works；duplicate IDs、dangling references、cross-source ID collisions 均 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，Catalog 55,660 筆。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；完整輸出在工作階段外部日誌。
- 74 個 `src/`、`tests/`、`tools/` JS／CJS 檔案 `node --check` 全部 PASS。
- `src/data/assets/data.js` SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`、`src/data/assets/emq-data.js` SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，與 Batch81 Manifest 一致。

## 尚未驗收／阻塞
- 真實瀏覽器外部 JSON／CORS／CDN／OpenCC 轉換與中文標題覆蓋率尚未驗收。已知 Chromium 導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不要重試同一條受阻路徑。
- 中文別名尚未動態加入曲庫全文搜尋索引，AMQ-990 待處理。
- 資料庫更新／匯入仍未實作；下一批優先 AMQ-982，先定義格式版本、checksum、預檢、更新預覽、原子替換及失敗回復。
- 不修改 Candidate302、Candidate382 Stage 0 或曲庫來源資產；工作副本無 `.git`，不得假造 branch／commit。

## 修改範圍
程式：`src/data/chinese-title-provider.js`（新增）、`src/data/source-mappers.js`、`src/persistence/app-settings-store.js`、`src/ui/quiz-panel.js`、`src/index.html`。
測試：`tests/chinese-title-provider.test.cjs`（新增）、`tests/app-settings-store.test.cjs`、`tests/source-mappers.test.cjs`、`tests/backup-restore.test.cjs`、`tests/quiz-panel.test.cjs`、`tests/tests.html`、`tools/check-architecture.cjs`。
文件與清單：`docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`、`docs/ACCEPTANCE.md`、`docs/CHINESE_TITLE_PROVIDER_CONTRACT_BATCH82.md`、`docs/FUNCTION_INVENTORY.md`、`docs/FUNCTION_PARITY_AUDIT_BATCH70.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`、`MANIFEST.sha256`。
