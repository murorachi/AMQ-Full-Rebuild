# Batch192：AniList／MAL／VNDB provider audit 與安全邊界

日期：2026-10-28

## 本批確認的既有實作

- `src/integrations/external-service-adapter.js` 是固定 HTTPS host 的共用 HTTP／認證／取消／timeout／HTTP 錯誤邊界。沒有自動重試；錯誤的 `retryable` 僅提供分類，不代表安全地重送 mutation。
- `src/integrations/anilist-adapter.js` 支援公開媒體搜尋、精確 ID 讀取、Viewer、MediaListCollection 與 SaveMediaListEntry。GraphQL errors、無效 schema 與輸入錯誤會明確拒絕。
- `src/integrations/mal-adapter.js` 支援 anime 搜尋、`/users/@me/animelist` 讀取與 my-list-status 更新。MAL schema 不與 AniList schema 混用。
- `src/integrations/vndb-adapter.js` 支援 Kana visual novel 搜尋與精確 `v<number>` ID 查詢。只對明確 VNDB ID 進行 lookup；不以 AMQ／EMQ 本地 ID 或相似標題猜身份。
- 正式 app 目前只在 Artwork provider 中建立 VNDB public client；AniList／MAL 帳號同步、OAuth callback／refresh 與外部服務 UI 尚未接線。不能把 adapters 存在等同產品整合完成。

## 本批修改

1. MAL `publicReadAuth` 改為 `clientId` policy，透過顯式 `clientIdProvider` 設定 `X-MAL-CLIENT-ID`；不再錯誤地把公開搜尋強制當成使用者 OAuth Bearer 操作。MAL private list 與 mutation 仍需要 OAuth token。缺少 provider、provider 拋錯、空白／不合法 client ID 都會 fail closed。呼叫端不能透過任意 headers 覆寫該 client ID。
2. AniList、MAL、VNDB feature adapter 將呼叫端 `AbortSignal` 與可選 `timeoutMs` 傳遞至共用 client，包含搜尋、精確讀取、私人清單與 mutation。
3. MAL 對空／null row 與非物件 paging metadata 做安全正規化，避免上游部分 malformed rows 變成未分類 TypeError。AniList MediaListCollection 對異常 list／entry 做防禦性處理。
4. VNDB 共用 client 預設 timeout 2.5 秒，單次 request 上限 2.8 秒，低於官方文件所述 3 秒 server cutoff。沒有新增自動重試。

## 外部服務政策盤點

### AniList

- 公開 GraphQL read 不需登入；私人資料與修改清單需 OAuth2 Bearer token。官方文件說目前 access token 長效約一年且不支援 refresh token，因此過期後需重新授權；不得自行假設 refresh token 流程存在。
- 官方 rate-limit 文件正常標示 90 requests/minute，但目前文件帶有暫時 degraded 狀態，限制為 30 requests/minute。應以回應的 `X-RateLimit-*`、`Retry-After` 為準，不將 90/min 寫死為保證。
- OAuth callback、token storage 與重新登入 UI 尚未實作。Client secret 不可放在前端。若選 Authorization Code Grant，token exchange 必須在可保護 secret 的 server；純前端流程只能選符合官方限制的 client-side grant。

### MyAnimeList (MAL)

- 目前 adapter 將 public reads 與 user-private／mutation 分離：public reads 透過顯式 `X-MAL-CLIENT-ID`，私人清單與修改使用 OAuth2 Bearer token。未設定 public client ID 時會回報 `EXTERNAL_CLIENT_ID_REQUIRED`，不使用硬編碼的第三方 client ID。
- MAL quota 在本批仍標記 `quotaVerified: false`；不推斷固定請求速率。遇 429 時沿用共用 client 的 `Retry-After`／rate-limit error contract。
- 尚未實作 OAuth authorization／callback／refresh；沒有 token 不可存取 `/users/@me/animelist` 或 mutation。正式啟用前須核對當前官方 API reference 的 client registration、允許的 grant 與 quota 政策。

### VNDB

- Kana endpoint：`https://api.vndb.org/kana`。大部分資料查詢可匿名；user list 操作需 VNDB token，透過 `Authorization: Token ...`。目前 adapter 僅實作公開 `/vn` 查詢，不假裝已有個人 VNDB list 同步。
- 官方文件列出最多 200 requests／5 minutes、每分鐘 1 秒執行時間預算、超過 3 秒的請求會中止。本批設定 2.5 秒預設與 2.8 秒上限；仍未實作全域跨 client rate scheduler，因此多個 client／tab 的總請求量尚未由本地節流保證。
- API 資料遵循 VNDB Data License；若未來儲存或重新發布資料，必須先確認授權條件。

## 官方／服務文件

- AniList GraphQL：<https://docs.anilist.co/guide/graphql/>
- AniList Authentication：<https://docs.anilist.co/guide/auth/>
- AniList Rate Limiting：<https://docs.anilist.co/guide/rate-limiting>
- MAL API v2 reference：<https://myanimelist.net/apiconfig/references/api/v2>（本執行環境無法直接讀取此 reference；quota 與 OAuth grant 細節仍列待核實，不引用非官方數字作為保證）
- VNDB Kana API v2：<https://api.vndb.org/kana>

## 驗收範圍與限制

- `tests/external-service-adapter.test.cjs` 驗證 host／HTTPS、client ID 與 OAuth policy、header 防偽、401／403、429、5xx、JSON／網路錯誤、取消、timeout、dispose。
- `tests/external-service-feature-adapters.test.cjs` 驗證三家資料映射、輸入限制、空結果、malformed schema 防禦與 signal／timeout 傳遞。
- `tests/artwork-provider-factory.test.cjs` 驗證精確外部 ID、ANN／AniList fallback 與取消不可被吞掉。
- **沒有執行 live API request、OAuth 流程、真實外部 CORS 或帳號同步驗收。** 不存在已設定的使用者 token／MAL client ID，也不建立假憑證。
- Candidate302／Candidate382 Stage 0 基準不在工作副本；本批沒有覆蓋基準或 AMQ／EMQ 曲庫資產。工作副本無 `.git`，未初始化。
