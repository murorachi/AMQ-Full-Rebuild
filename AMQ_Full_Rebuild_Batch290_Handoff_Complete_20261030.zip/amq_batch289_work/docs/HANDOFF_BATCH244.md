# Batch244 交接：Renderer 幾何邊界與資源生命週期

## 基準與安全
- 唯讀基準 Batch243 ZIP SHA-256：`8d247450d1de34e67c41a12982b51b76252458b87e8a4b5dc16ad74baa506bf6`。
- 工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch244`。沒有 Git repository，未初始化 `.git`，未覆蓋基準 ZIP。
- AMQ／EMQ 原始資料 SHA-256 未變：`data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 實作
- `src/skins/skin-canvas-renderer.js`：幾何使用 safe integer／乘法結果／RGBA byte length／32-bit 上限檢查；Canvas factory/readback/writeback 例外轉為穩定 `SKIN_*` codes；bitmap dimension cleanup 對 close exception 採 best-effort。
- `src/skins/skin-edge-repeat.js`：來源／目標 pixel 與 byte length 在 TypedArray allocation 前驗證；非法幾何、超限、配置失敗皆 fail closed。
- `tests/skin-canvas-renderer.test.cjs`、`tests/skin-edge-repeat.test.cjs` 增加邊界及錯誤路徑回歸；新增 `tests/batch244-skin-canvas.browser.py`。
- 本批沒有將任何未支援視覺角色強行接線；traceability 已補記 renderer 安全性與接線判斷。

## 驗證證據
- Focused Node renderer/edge：19/19 PASS。
- Canvas Chromium：15/15 PASS。
- Home/Catalog：19/19 PASS；Quiz/Results：19/19 PASS；OSK Mapping Studio：30/30 PASS；formal app-shell：150/150 PASS。
- 全量 Node：89/89 files、269 cases PASS。`quiz-pool.test.cjs` 初次個別 12 秒上限逾時，90 秒重跑於 23.24 秒通過。
- Architecture Checker：1,270 PASS／0 FAIL。JS/CJS syntax：182/182 PASS。Python harness `py_compile`：11/11 PASS。
- 詳細 log、JSON 與 Chromium screenshot 在 `artifacts/batch244-regression/`。

## 未解與阻塞
- HTTP-origin IndexedDB save/reload 仍受已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；未重做同樣探測。
- 真實音訊／live artwork／曲庫、乾淨 Windows／實機、Candidate302／Candidate382 Stage 0 與 native osu!stable compositor fidelity 未驗收。
- Visual-role 主線未結案：仍有角色缺少完整語義 selector、CSS consumer、state/geometry、fallback/reset 或真實 artwork provider。維持 unsupported。

## 下一批 Batch245
1. 建立 visual-needs 與 runtime-role 的自動一致性盤點，列出 selector／CSS consumer／state／geometry／fallback／reset 缺口。
2. 只選擇已存在真實語義 consumer 的角色做完整 apply/fallback/reset 接線及測試；不把 OSK 角色圖當作品封面。
3. 完成 Mapping Studio 的可驗證操作閉環缺口與首頁/Catalog UI；依實際證據調整範圍。
4. 保持主清單、WORK_STATUS、traceability、handoff、next prompt、Manifest 與完整 ZIP 同步。
