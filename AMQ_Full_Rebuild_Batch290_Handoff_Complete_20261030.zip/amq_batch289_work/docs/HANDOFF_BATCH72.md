# Batch 72 交接：作品標題四級自動評估

## 本批結果
- 新增純函式 `src/learning/assessment-engine.js`，由 `src/index.html` 載入。
- 使用者確認的規則：作品標題答錯／超時 grade 1；答對 0–10 秒 grade 4；>10–15 秒 grade 3；>15 秒 grade 2。
- 只依作品標題評估。歌名與歌手不影響 SRS；`all` 目標只讀 `correctByTarget.anime`。
- 缺少可靠時間、揭曉、未播放跳過等不產生自動評級。
- 既有 SRS 回合答題後自動套用評級，保存 automatic provenance；同題保留手動覆寫，覆寫以原始卡片狀態重算，避免 reps 重複累加。
- FSRS 原生四級與演算法公式未更動；未建立第二 scheduler/store。

## 修改檔案
- `src/learning/assessment-engine.js`（新增）
- `src/index.html`
- `src/persistence/srs-store.js`
- `src/ui/quiz-panel.js`
- `tests/assessment-engine.test.cjs`（新增）
- `tests/srs-store.test.cjs`
- `docs/SRS_AUTOMATIC_ASSESSMENT_SPEC_BATCH71.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH72.md`
- `AI_START_HERE.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `MANIFEST.sha256`

## 驗證界線
- 全部 `tests/*.test.cjs`：28/28 腳本通過。
- `node --test tests/tooling.test.cjs`：8/8 通過；architecture：495 passed／0 failed。
- Source audit／mapper verification PASS；Catalog 55,660 筆；5-run benchmark Catalog build 約 1,073.52 ms。
- 所有 JS/CJS 語法檢查 PASS；156 個 manifest 項目逐一 hash 驗證通過。
- ZIP `unzip -t` 無錯，ZIP 內包含全部 manifest 檔案，沒有缺漏。
- Node 測試不等於真實瀏覽器或音訊驗收。
- 本批未完成全域 SRS 開關及一般猜歌流程接線，不得宣稱全域 SRS 已完成。

## 下一批建議
1. 先檢查本批交付後測試／manifest 狀態，勿重做已完成的評級門檻。
2. 接續實作全域 SRS toggle，沿用 `appSettingsStore`，不新增第二份設定真相。
3. 接一般 AMQ／EMQ 評估，MIX 以歌曲 `source` 回寫原來源 store，不建立 MIX schedule。
4. 再做 eligibility-first selector 與新題／到期題動態權重；保留 FSRS due date 與現有 MIX 2:1 source weighting。
5. 全程遵守 P0 使用者驗收政策，UI/CSS 大重構仍最後進行。


## 待辦清單入口
下一批請以 `docs/MASTER_CHECKLIST.md` 的 AMQ-869–AMQ-918 為準。優先完成全域 SRS 開關與一般 AMQ／EMQ／MIX 接線，再完成 eligibility-first selector、動態相對權重、備份／還原與整合回歸。不要把本批僅接入 SRS 專用複習回合的自動評級誤報為全域 SRS 已完成。
