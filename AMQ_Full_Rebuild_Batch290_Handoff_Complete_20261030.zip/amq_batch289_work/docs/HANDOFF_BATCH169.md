# Batch169 交接：Quiz 初始化回滾與四級作品熟悉度

## 開工確認
- 已讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、Batch168 handoff 與 next prompt。
- 工作副本 `/mnt/data/amq_batch153_work` 沒有 `.git` metadata；未初始化 Git。
- Candidate302、Candidate382 Stage 0 與 AMQ／EMQ 原始曲庫資產維持唯讀。

## 實作
1. `src/ui/quiz-panel.js`：Chinese Title Provider 建立納入 owned-resource acquisition；建構拋錯時走既有反向 rollback helper，釋放先前建立的自有 stores。
2. `src/engine/quiz-engine.js`：作品熟悉度改為四級判定：答錯／超時=1；答對且耗時 >15 秒=2；11–15 秒=3；0–10 秒=4。`all` 模式只看作品標題欄位的正確性，歌名與歌手不影響作品熟悉度；標題／歌手單項練習不改作品熟悉度；`keepHigher` 上限提高至 4。
3. `src/persistence/familiarity-store.js`：讀寫允許熟悉度 0–4，保留 0 為未標記／刪除值，舊 1–3 資料不需遷移。
4. `src/data/query-index.js`、`src/ui/catalog-browser.js`、`src/index.html`：查詢索引、篩選控制與作品熟悉度欄位支援 0–4，標示四級含義。
5. `src/learning/statistics-dashboard.js`：統計熟悉度加入 level4。
6. `src/persistence/backup-restore.js`：備份驗證允許 4 級資料，避免合法新熟悉度被拒絕。
7. 測試更新：`tests/catalog-filter-layout.contract.test.cjs`、`tests/quiz-engine.test.cjs`、`tests/quiz-panel.test.cjs`、`tests/quiz-session.test.cjs`、`tests/familiarity-store.test.cjs`、`tests/query-index.test.cjs`、`tests/catalog-browser.test.cjs`、`tests/statistics-dashboard.test.cjs`、`tests/backup-restore.test.cjs`。

## 驗證
- 受影響測試組：15/15 top-level test files PASS。
- Quiz engine 專項：11/11 tests PASS，包含 10 秒、10.001 秒、15 秒、15.001 秒邊界及 all-target 只依作品標題評級。
- `node tools/check-architecture.cjs`：1,051 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- 160 個 JS／CJS 檔案 `node --check`：0 failures。
- 71 個 Node test files 分 9 組完成，168/168 tests PASS、0 FAIL。group-01 至 group-07 初次完成後，外層工具達時間限制；group-08、09 後續完成。group-02 在更新備份測試的 level-4 fixture 後重新執行。詳見 `artifacts/batch169-regression/`。

## 未解決／限制
- Provider rollback 新增了程式路徑與架構契約測試；由於既有 `AMQPersistence`／Provider namespace API 為 frozen object，本次既有大型 quiz-panel harness 無法直接 monkey-patch factory 做 runtime failure injection，故不能宣稱已用真實注入證明該分支；後續應以獨立可注入 harness 補強。
- 真實瀏覽器 viewport、ANN API／CORS／圖片、真實 `.osk`、非 opaque HTTP origin IndexedDB save/reload/clear 仍未驗收。
- 無 Git metadata，沒有 Git diff／commit 可報告。

## 下一批 Batch170
1. 盤點正式猜歌核心與使用者已定規則的差距，優先補足單人完整回合／音訊狀態／答案判定的實際缺口。
2. 為 Quiz Panel provider/session/subscription 後續 mount wiring 建立可注入的實際 failure-injection harness，不只依賴 source contract。
3. 針對熟悉度 0–4，檢查匯出／還原、統計呈現及所有 UI 標籤，補跨模組回歸。
4. 不再無限擴大一般 lifecycle 清理；處理有證據的阻塞後，主線轉回最小可玩版本。
