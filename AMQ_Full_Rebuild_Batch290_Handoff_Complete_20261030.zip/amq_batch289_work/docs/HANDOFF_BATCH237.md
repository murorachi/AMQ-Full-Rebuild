# Batch237 Handoff：AMQ Visual Needs First

## 本批成果
- `docs/skin-contract/amq-visual-needs.v1.json`：30 個需求槽位，與 OSK archive inventory 分離。
- `src/skins/amq-visual-needs.js`：runtime registry / coverage API。
- Mapping Studio 的 `AMQ 版面需求基準`：顯示 required/optional、素材映射覆蓋、runtime support 覆蓋。
- `docs/AMQ_VISUAL_NEEDS_TRACEABILITY_BATCH237.md`：逐需求 geometry、role、stable candidates、runtime selectors 與限制。
- 新增 `catalog.filter.background` 角色，仍明確 unsupported。

## 驗證
- Focused Node：50/50 PASS。
- Chromium synthetic OSK integration：25/25 assertions PASS。
- Architecture Checker：1,214 PASS / 0 FAIL。
- JavaScript/CJS syntax：162 files PASS; Python browser harness compile PASS.
- 全量 Node suite未跑；真實 stable renderer 與 HTTP-origin IndexedDB 未驗收。

## 交付封包
- `AMQ_Full_Rebuild_Batch237_Visual_Needs_First_20261029.zip`

## 重要決策
先定義 AMQ 的 UI 視覺需求與幾何，再允許 stable assets 依語義契約映射。OSK 只提供可選素材，不得決定 AMQ 的版面結構。作品封面、播放器、答題回饋、搜尋面板等無 stable 等價物時，使用 AMQ extension slots。

## 下一批順序
1. 先完成首頁、選歌、猜歌、結算四頁的 DOM/CSS/geometry traceability，並真正建構漂亮、穩定的框架。
2. 實作 cover/crop、state pair、@2x、tint 與上框架 edge-repeat renderer primitives。
3. 完成 Skin Override Editor 和持久化 round-trip。
4. 分批執行全量 Node tests，調查 formal shell harness timeout。

不可宣稱全部角色已支援或任意 Skin 已完美還原。
