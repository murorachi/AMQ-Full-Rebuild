# Batch 57 交接：Repository invalidate 新一代載入競態

## 摘要

Batch 56 已新增 `repository.invalidate()`，並在模式改變時清除舊 Catalog。本批追查 invalidate 舊請求遲到完成與新一代載入之間的邊界，補上尚缺的整合回歸，沒有發現需要再改寫 Repository 實作的證據。

## 修改

- `tests/data-pipeline.integration.test.cjs`
  - 新增 `an invalidated non-cooperative request cannot clear a newer mode catalog`。
  - AMQ 來源故意忽略 abort 並延遲回傳；切換 EMQ 後，舊請求取消，新一代 EMQ 成功載入；最後讓舊 AMQ 來源遲到完成，確認 `dataStatus` 仍為 `loaded`，Catalog 仍只包含 EMQ。
- `docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`
  - 記錄 invalidate 後 generation 與舊請求 finally/catch 的隔離責任。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`、`README_FIRST.md` 與本交接。

## 測試與環境

- `node tests/data-pipeline.integration.test.cjs`：17/17 PASS。
- 真實瀏覽器替代通道嘗試：`timeout 25s chromium --headless --no-sandbox --disable-gpu --disable-dev-shm-usage --dump-dom file://.../tests/tests.html`，exit 124；DOM 輸出為 0 bytes，stderr 顯示 DBus／zygote 問題。這不是測試通過，真實瀏覽器仍 BLOCKED。
- `tests/*.test.cjs`：25/25 個測試腳本 exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：459 passed，0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 首、EMQ 16,839 首，重複 ID／dangling references／跨來源 ID 衝突皆 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660 筆。候選音源數不代表真實可播放。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，5 次本機 Node in-memory benchmark。
- `node --check` 對 `src/`、`tests/`、`tools/` 的 63 個 JS／CJS 檔：PASS。
- 完整日誌位於 `/mnt/data/amq_batch57_logs/`。
- `src/data/assets/data.js` 與 `src/data/assets/emq-data.js` 未修改，來源 hash 保持原值。
- 工作副本沒有 `.git` metadata；未初始化 Git、未 commit／push。

## 未驗收／阻塞

- 真實瀏覽器 UI、響應式、鍵盤、跨分頁 storage。
- 真實音訊可聽性、乾淨 Windows 啟動。
- Candidate302／Candidate382 Stage 0 相容性；Candidate381 僅靜態參考。
- `aniFavorites_v1` ID 身份、舊 source-less IDs 的來源遷移。

## 下一批 Batch 58

1. 先尋找是否有新的可操作瀏覽器通道或使用者提供的正式基準證據；Chromium CLI 目前也無法在本環境完成頁面載入，不重複相同方法。
2. 若沒有新證據，繼續處理有明確契約且未被既有測試覆蓋的核心缺口；不猜測收藏身份、legacy IDs 或 P2 行為。
3. 保持 UI／CSS 大重構於最後階段，更新同一份主清單、狀態、handoff、manifest 與 ZIP。
