# Batch285 Handoff：修正 Feature Route 根本版面錯位，繼續 osu! UI Fidelity

## 重要發現
上一版 Quiz 截圖顯示內容只佔右側約一半畫面。原因是 Batch280 將 `body` grid rows 收斂成單列，但沒有明確指定 `.app-header` 與 `main` 的 grid placement。兩個可見子元素在同一 auto-placement row 進入不同 implicit columns。這是正式 UI bug，不是截圖工具問題。本批修正為 body 單欄、header row 1、main row 2；Home header/nav 仍隱藏，feature routes 全寬。

## 本批變更
- `src/styles/ui-design-landing.css`：根本修正 body/main grid，route page 使用內層 overflow；Quiz stage 背景由人工 equalizer bar 改為低對比同心環／放射線，保留 skin background token；Quiz settings 改為預設收合的 details。
- `src/ui/app-shell.js`：將 app status 放入 route navigation bar，功能頁不再顯示重複全域 title header；Alt+Left 在 input/textarea/select/contenteditable 焦點時不攔截。
- `tests/answer-suggestions.test.cjs`：新增 ArrowUp wrap/aria-activedescendant、Escape dismissal、outside-click close。
- `tests/batch285-quiz-route-ui.browser.py`：71/71 PASS，四尺寸檢查 route 全寬、status、shortcut、Quiz/Lobby 控制、無水平溢位。
- `tests/batch283-catalog-stable.browser.py`：148/148 PASS，feature nav/status 改動後 Catalog regression 仍通過。
- `node tests/quiz-panel.test.cjs` PASS；`app-shell-navigation` 2/2、`results-ui` 7/7、`ui-shell-css` 9/9、`quiz-ui-state` 5/5 PASS；Architecture 1,358/0。全量 Node 101 檔 runner 觸及 300 秒上限；101 個 log 無失敗標記，但總控未保存 exit-code summary，故不宣稱全量 PASS。`tests/app-shell.browser.test.py` 逾時，未算 PASS。

## 參考來源
- `artifacts/osu-reference/osu-intro-screen.jpg`；並排 `artifacts/batch285-quiz-route-ui/quiz-vs-osu-stable.jpg`。
- `/mnt/data/osu-master.zip` 是 lazer source，SHA-256 `973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`，不是 Stable 完整 source。
- `references/AMQ-Scripts-master.zip` SHA-256 `76fc073a51da180d087ba4c6636b22531053ed5b1affeb5a8330e7de7c4aad04`。

## 尚未驗收
- 視覺並排明確顯示 AMQ Quiz 仍不像 osu! Stable：缺少真實背景細節、中心 artwork、overlay depth、遊戲式操作層級。此 batch 不宣稱人工 gate pass。
- 未驗證 live audio／live catalog／Windows／真機；未完成全量 Node suite。
- Mods canonical owner 尚未確認；不得虛構 Mod 倍率或裝飾按鈕。

## 下一批
1. 先對照 `osu-game-modifiers.jpg` 與正式 AMQ 設定／Quiz UI，找出 canonical Mods registry/state/multiplier/audio owner。
2. 如果沒有單一 owner，先建立可測試的最小規則與狀態模組，再建 UI。
3. 主線繼續 osu! Stable fidelity：重新設計 Quiz overlay、答案區與控制列；逐頁原圖比較，不做顏色式假改版。
4. 先補全量 Node suite 分組結果與乾淨交付包驗證。

> Compact Batch286 package note: the Batch285 screenshot binaries are superseded by `artifacts/batch286-quiz-gameplay-layout/` and are not duplicated in the latest package. The historical test result remains in `docs/WORK_STATUS.md`.
