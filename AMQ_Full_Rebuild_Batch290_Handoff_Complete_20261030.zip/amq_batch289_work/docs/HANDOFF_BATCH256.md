# Batch256 Handoff：Catalog filter Skin role 精確接線

## 交付封包
- ZIP：`AMQ_Full_Rebuild_Batch256_Catalog_Filter_Skin_Role_20261029.zip`
- SHA-256：`a8ed5b9beaeac2849ff863a73d606ec27528d622755caa3a869cf1bd46290fb1`（本文件後續有改動時需重新產包並更新 hash）

## 已完成
- `src/skins/theme-adapter.js`：新增 `catalog.filter.background`，selector 精確限定 `.catalog-sidebar > .catalog-primary-controls`，token 為 `--amq-skin-role-catalog-filter-background`。
- `src/styles/ui-shell.css`：專屬 token 只套用在 Catalog 左側主要搜尋／篩選面板，保留原有底色 fallback、cover 幾何與背景定位。沒有把整個 `#catalog-browser` 當 filter panel。
- `tests/skin-theme-adapter.test.cjs`：新增套用／reset／Blob URL revoke 與 target 缺失 fail-closed 測試。`tests/skin-contract-manifest.test.cjs`、`tests/visual-role-audit.test.cjs` 更新 runtime role count 與 unsupported inventory。
- 靜態稽核：48 total、36 wired、12 unsupported、36 CSS consumers、31 direct test evidence、33 roles 有靜態 gap。報告位於 `artifacts/batch256-regression/visual-role-audit/`。

## 驗證證據
- Focused Node：4 個檔案合計 36/36 tests PASS。
- 全量 Node：92/92 `tests/*.test.cjs` files exit 0，逐檔 log 與 TSV 位於 `artifacts/batch256-regression/node-tests/`。
- Architecture Checker：1,293 PASS／0 FAIL，`artifacts/batch256-regression/architecture.log`。
- JS/CJS syntax：186 files，0 failures。
- Python compile：16/16。
- Home/Catalog Chromium：22/22 PASS，`artifacts/batch256-regression/home-catalog-browser.log`。
- Production role Chromium：36/36 apply、36/36 missing-asset fallback、36/36 reset／URL revoke、0 page errors，`artifacts/batch256-regression/skin-role-production-dom.log`。這仍是每個 target 的 apply/fallback/reset，不代表所有 route visible-state 都已驗收。
- Raw data SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 明確不接線的兩個角色
- `catalog.action.random`：目前 Catalog 沒有獨立隨機選曲按鈕或事件 owner；現有 `#free-player-random` 是播放器隨機播放，語義不同。下一批可先定義 Catalog 隨機選曲行為，再決定新增元件。
- `settings.slider`：Settings 頁目前沒有 range input；`#free-player-progress` 與音量 range 屬於播放器，不可錯標為 Settings。等真正 Settings slider 存在再接線。

## 環境／專案狀態
- 工作副本沒有 `.git`；未初始化 Git。未覆蓋 Batch255 ZIP。
- Candidate302／Candidate382 不再是新版基準、工作項目或阻塞條件。
- HTTP-origin IndexedDB 仍受既有 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 限制；本批未重試同一 probe。Live providers/audio 與 Windows／實機尚未驗收。

## 下一批 Batch257
1. 建立 route-aware visible-state browser matrix，先 Home、Catalog、Quiz、Results。
2. 對每頁已接線角色確認路由啟用後 target 可見，套用／缺件／reset 不污染其他頁面。
3. 保護鍵盤焦點、ARIA、390px layout 與 reduced-motion。
4. Catalog 隨機選曲先確認產品行為及資料 owner，不重用播放器 random handler。
