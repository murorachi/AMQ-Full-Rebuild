# Batch211 Handoff：回合結果生命週期與 Catalog 封面 fallback

日期：2026-10-29

## 來源與保護
- 工作副本：`/mnt/data/amq_batch209_work/project`，承接 Batch210；Batch210 ZIP 與 `artifacts/batch210-regression/` 不覆寫。
- 本工作副本沒有 `.git`，未初始化 Git。Candidate302 正式基準與 Candidate382 Stage 0 CSS 比較基準原始檔缺席，不宣稱相容、不猜測或覆蓋基準。
- AMQ／EMQ 曲庫唯讀；封面 API 只使用既有明確 artwork references，沒有新造外部圖片資料。

## 修改檔案
- `src/ui/catalog-browser.js`：新增作品標題型 artwork fallback helpers；每個歌曲列都建立封面 slot；選取詳情也總是有作品視覺 slot。沒有 adapter、沒有 `artworkRef`、provider 無結果／reject 時使用 fallback；圖片載入錯誤會移除壞圖並重新顯示 fallback，更新 `data-artwork-status` 與 ARIA label。
- `src/styles/ui-shell.css`：調整列表 fallback 文字可讀性與作品詳情封面 fallback 版面；沒有以空白色塊冒充封面。
- `tests/catalog-browser.integration.test.cjs`：驗證可用 HTTPS 封面、圖片載入錯誤、provider throw、provider 無結果、無 adapter／無 artworkRef 與選取詳情 fallback。
- `tests/quiz-session.test.cjs`：新增手動結束、新 round ID、跨輪隔離、reset、pool exhaustion，以及 reveal／unplayed skip 不入史的 regression。
- `tests/quiz-panel.test.cjs`：新增 all-target 三目標結果、手動結束結果顯示與 detail persistence failure／未保存提示斷言。
- `tests/app-shell.browser.test.py`：輸出路徑改為 `artifacts/batch211-regression/`，避免覆寫 Batch210 證據。
- `docs/MASTER_CHECKLIST.md`：新增 AMQ-2216–2229；`docs/WORK_STATUS.md`、Wiki traceability、`AI_START_HERE.md`、`README_FIRST.md`、`docs/NEXT_SESSION_PROMPT.md`、本 handoff 與 `MANIFEST.sha256` 更新。

## 已執行驗證
- `node tests/quiz-session.test.cjs`：38/38 PASS。
- `node tests/quiz-panel.test.cjs`：PASS；eligibility matrix 768/768。
- `node tests/catalog-browser.integration.test.cjs`：PASS，含 provider throw／no-result、圖片 load error、無 adapter／無 artworkRef fallback。
- `node tests/catalog-browser.test.cjs`：6/6 PASS；filter matrix、self-excluding facet 與 tag filter regressions PASS。
- `python tests/app-shell.browser.test.py`：72/72 PASS；桌面／390px 無水平溢位、首頁五入口不重疊、無 uncaught browser exceptions。證據 `artifacts/batch211-regression/`。
- `node tools/check-architecture.cjs`：1,137 PASS／0 FAIL。
- 全量 77 個 `tests/*.test.cjs` 檔案逐檔 exit 0；summary `artifacts/batch211-regression/node-tests/summary.tsv`，每檔 log 同目錄。
- 172 個 JS/CJS 檔案 `node --check` PASS；`python -m py_compile tests/app-shell.browser.test.py` PASS。
- `node tools/check-architecture.cjs`：1,137 PASS／0 FAIL；`python tests/app-shell.browser.test.py`：72/72 PASS；AMQ／EMQ 資產 hash 維持既有值，見 `artifacts/batch211-regression/asset-hashes.txt`。
- `MANIFEST.sha256` 3,236 entries 逐檔驗證零錯誤；交付 ZIP `AMQ_Full_Rebuild_Batch211_Quiz_Lifecycle_Artwork_Fallback_20261029.zip` 的壓縮完整性通過，ZIP 內 3,236 個 manifest entries 均存在且 SHA-256 一致。

## 尚未驗收／阻塞
- 真實 HTTP-origin localStorage／IndexedDB、非空持久化資料重載、正式曲庫、外部封面 API、真實音訊與真實 `.osk` 未驗收。
- Candidate302／Candidate382 Stage 0 原始檔缺席；無 `.git`，不能提供 branch／commit／diff status。
- `docs/LEADERBOARD_TRUST_CONTRACT.md` 已定義未來可信身份、server-authoritative scoring、ruleset／season version、冪等提交、排名 tie-break、隱私及啟動條件；目前只是規格草案。正式 backend owner、身份方案與評分規則未指定，因此沒有新增競技 API／帳號／反作弊系統，排行榜只保持未接入狀態，不造 PP／排名／PB。
- UI 主線未結案。

## Batch212 下一步
1. 補 artwork lookup 的 stale-response／取消／dispose lifecycle 回歸。
2. 逐角色核對 OSK manifest、正式 DOM target 與 CSS consumer，只接入語義相符的角色。
3. 盤點可信排行榜資料契約，但沒有後端 owner 前不造假排名。
4. 全量測試、更新同一份清單／狀態／traceability／handoff／manifest／ZIP。
