# AMQ 新版重建交接：Batch146（osu!stable Song Select 原型 v2）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。工作目錄沒有 `.git` metadata，未初始化 Git。Candidate302、Candidate382 Stage 0、AMQ／EMQ source assets 均未修改。

## 使用者已確認的設計方向
- osu!stable Song Select 的整體版面、操作方式、視覺風格、資訊呈現都要參考（ABCD）。
- 整體接近 osu!stable，但保留 AMQ 原本有價值的操作習慣（AC）。
- 使用者指出 v1 看起來有明顯 AI 風格：卡片過多、漸層／裝飾過度、像 SaaS dashboard。不可把這類設計當成基礎。

## 本批交付
- v1 保留：`prototype/ui-v1/`。
- 新版獨立目錄：`prototype/ui-v2-osu-select-batch146/`。
- 新增 `styles/osu-select.css`：深灰底、少量粉色強調、較小圓角與較少陰影；選曲頁為左側搜尋／分類／篩選、中央密集歌曲列表、右側歌曲資訊、底部播放列。
- 保留 mock data 與既有控制器互動，避免視覺重構造成行為退化。
- README 已更新；測試載入新的 CSS 並核對新頁面標題。

## 驗證證據
- 執行 `python prototype/ui-v2-osu-select-batch146/tests/browser-smoke.py`：43/43 PASS。
- 未捕捉的 browser page errors：0。
- 1440×900、1024×768、390×844 頁面層級溢位檢查 PASS。
- 最新桌面選曲截圖：`prototype/ui-v2-osu-select-batch146/artifacts/desktop-catalog-1920x1080.png`。
- 截圖由 Chromium 產生，但尚未經使用者視覺驗收；自動化 PASS 不代表設計已驗收。

## 目前狀態與限制
- 已實作：選曲頁扁平化與 osu!stable 方向的初步視覺候選；既有 mock 互動保留。
- 已測試：43/43 browser smoke tests，三種響應式尺寸無頁面層級溢位。
- 未驗收：使用者是否接受選曲主畫面的資訊密度、配色、欄位比例及選中效果。
- 未完成：首頁／設定／答題／歌曲資訊等頁面尚未完整重設；封面與背景為 mock，未接正式資料、音源或產品服務。
- 本批沒有接入正式 `src/`，沒有變更正式核心與資料管線。
- Batch140–144 正式產品全量回歸與 ZIP 收尾仍需另行完成，不應被 UI 原型測試替代。

## 下一批
1. 先看 v2 選曲截圖，依使用者明確回饋修正比例／資訊層級；若方向可接受，再將視覺語言延伸到其他頁面。
2. 完成後重新產生 1920×1080、1440×900、1024×768、390×844 的主要畫面截圖，檢查鍵盤、搜尋、收藏、篩選、選中狀態及資訊可讀性。
3. 不接正式資料與音訊，直到 UI 方向及正式元件／狀態責任計畫清楚。
4. 另行完成 Batch140–144 的正式產品完整回歸與封包驗證。
5. 持續更新 `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md`。
