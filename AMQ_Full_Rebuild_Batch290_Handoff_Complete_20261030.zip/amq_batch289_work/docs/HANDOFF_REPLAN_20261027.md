# AMQ 重建交接：核心優先、UI 大重構延後（2026-10-27）

## 1. 本次決策
使用者明確確認：**UI 可以放到最後再做，因為舊項目本來就還要進行 UI 重構。** 因此新版重建採「核心優先、UI 大重構最後」的順序。這是專案範圍與排序決策，不是宣稱其他項目已完成。

## 2. 五階段工作順序
1. 核心架構收尾：狀態、錯誤契約、生命週期、模組責任及已知核心缺陷。
2. 核心功能整合：猜歌引擎、AMQ／EMQ／MIX、資料管線、題目池、音訊備援與計時流程。
3. 資料與持久化：設定、熟悉度、歷史、SRS、黑名單、來源隔離及舊資料相容性範圍。
4. 必要功能完整性與回歸：對照功能真相表，補必要缺口並跑跨模組測試。
5. UI／CSS 大重構與最終驗收：保留已認可畫面，依視覺基準真正替換舊實作，清除確認廢棄的 UI／CSS，再執行整體驗收。

## 3. UI 現階段界線
### 可提前處理
- UI 與核心模組的事件/API 接線錯誤。
- 錯誤訊息、載入狀態及模式狀態投影錯誤。
- 阻礙必要功能或整合測試的 UI Bug。
- 對以上項目補充 Node／VM／fake DOM 整合測試。

### 必須延後
- 大規模視覺改版、布局重設。
- 全面 CSS 分層與命名重寫。
- 純美化、非必要動畫與不影響功能的樣式整理。
- 尚未確認依賴前就刪除舊 UI／CSS。

延後 UI 大重構不代表免除 UI 整合測試。進入最後階段時，必須保留已認可的視覺與互動體驗，且採真正替換而非隱藏舊 UI 的方式。

## 4. 已確認的專案現況
- 最新完成批次：Batch 36。
- Batch 36 的錯誤診斷快照修正已完成；core 76/76、21/21 test scripts exit 0、tooling 8/8、architecture 415/0、source audit、mapper verifier、benchmark、syntax PASS。
- 真實瀏覽器 E2E 仍 BLOCKED：頁面導覽曾回報 `ERR_BLOCKED_BY_ADMINISTRATOR`，不再重試同一環境／方式。
- 工作目錄沒有 `.git` metadata；不得初始化 Git、commit 或 push，除非使用者明確授權。
- 不修改 `AMQ382(1).html` 或 `src/data/assets/data.js`、`src/data/assets/emq-data.js`。
- 使用者已指示不再搜尋 Candidate302。`AMQ382(1).html` 實際 title 顯示 Candidate381，含 Stage I 線索，不能宣稱為 Candidate382 Stage 0。
- AMQ／EMQ 資料目前已通過新版內部 mapper／契約檢查，但 Candidate302 配套關係與真實音訊可播放性仍未驗證。
- MIX 已接入 2:1 AMQ／EMQ source weighting；舊版 AMQ-specific filter suppression 尚未移植，因新版目前沒有對應篩選 UI，不能宣稱完全相容。

## 5. 下一批 Batch 37
**主題：normalized error projection 與整合回歸；不是 UI 視覺重構。**

1. 檢查 `src/app.js`、`src/ui/catalog-browser.js`、`src/ui/quiz-panel.js` 如何呈現 `appState.dataError`、`result.error`、`audioError`。
2. 確認 UI 消費穩定的錯誤欄位，不直接依賴原始 exception object。
3. 新增／更新測試，覆蓋缺少 `code`、`message`、可選欄位、特殊字元與安全文字呈現。
4. 特殊字元必須以 text rendering 顯示，不能被當成 HTML 執行。
5. 僅修復測試證實的缺陷，保留現有視覺與文案。
6. 執行相關測試、全量 Node tests、架構檢查、source audit、mapper verifier、syntax；瀏覽器 E2E 維持 BLOCKED 並如實記錄。
7. 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、本次 handoff、`AI_START_HERE.md`、`MANIFEST.sha256` 及完整 ZIP。

## 6. 後續批次排序
- Batch 37：normalized error projection 與整合測試。
- 後續：猜歌 Session／狀態流程與模式規則核對。
- 後續：音訊備援、逾時、取消、計時起點的整合回歸。
- 後續：持久化與必要功能範圍核對。
- 後續：必要功能完整性、跨模組回歸與已知缺陷清理。
- 最後：UI／CSS 大重構及整體視覺／互動驗收。

以上不是固定批次數承諾；依每批實際證據更新同一份主清單，不要為了追求漂亮的完成百分比而虛構進度。

## 7. 直接交給下一個 AI 的文件
- 主指引：`AI_START_HERE.md`
- 唯一主清單：`docs/MASTER_CHECKLIST.md`
- 當前狀態：`docs/WORK_STATUS.md`
- 下一批直接開工提示詞：`docs/NEXT_SESSION_PROMPT.md`
- 最近技術批次交接：`docs/HANDOFF_BATCH36.md`

