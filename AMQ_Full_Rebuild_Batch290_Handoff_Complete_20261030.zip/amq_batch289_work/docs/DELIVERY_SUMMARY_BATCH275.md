# Batch275 交付摘要（2026-10-30）

- 輸入：Batch274 工作副本；原 ZIP 保持不變。工作目錄沒有 Git repository，未初始化 Git。
- 主要變更：Home 圓形 AMQ 品牌主視覺與六個斜切入口重疊構圖；Home artwork fallback metadata 清理；`app.home.primary-action` 與 `app.home.welcome-visual` Skin roles 真正接到 DOM/CSS；新增 artwork fallback regression。
- Catalog artwork lifecycle：圖片 load 成功前維持 loading 與可讀 fallback，load 後才顯示來源連結；error 時清除過期來源連結，已加 integration/CSS contracts。
- 測試：Node 98 個測試檔分 20 組，20/20 組 exit 0、305/305 subtests PASS；Architecture 1,335 PASS／0 FAIL；JS/CJS syntax 192/192；Python AST 36/36；Home/Catalog browser 85/85；Home artwork fixture browser 14/14；Multiplayer Skin role browser apply/fallback/reset/scope 5/5；focused Node 51/51。
- 保留的最新視覺證據：`artifacts/osu-reference/`、`artifacts/batch275-home-menu/`（四尺寸 Home、Catalog fixture/error JPEG 與差距表）、`artifacts/batch275-home-artwork/`（fixture screenshot）。Catalog fixture 不代表正式曲庫。
- 未結案：live ANN/VNDB artwork、正式 Catalog data、人工 osu! Stable visual gate、IndexedDB app-origin persistence、外部 AMQ/EMQ 可聽播放、Windows／實機驗收。
- IndexedDB 環境證據：`artifacts/batch275-regression/secure-origin-navigation-blocker.txt`。HTTP／HTTPS localhost navigation 被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；沒有嘗試繞過管理政策。
- 交付完整性：`MANIFEST.sha256` 對每個列出的檔案逐項比對；ZIP CRC 與封裝後檔案數在交付前驗證。最終 ZIP SHA-256 由同名外部 `.zip.sha256` sidecar 提供。
- 下一批：依 `docs/NEXT_SESSION_PROMPT.md` Batch276 先完成 Catalog 正式資料與 artwork traceability；取得批准的 browser/CI runner 後才重跑真實 app-origin persistence。
