# Batch249 Handoff：Learning Center SRS persistence fail-closed

## 基準
- 唯讀基準：Batch248 ZIP `/mnt/data/AMQ_Full_Rebuild_Batch248_Quiz_Results_Closure_20261029.zip`，SHA-256 `2f1f065a0834f143c25e189243108c15925e7b7776092bc0aa7cf120173a4908`。
- 獨立工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch249_Settings_Learning_Multiplayer/AMQ_Full_Rebuild_Batch245_Project`。沒有 Git repository，未初始化 `.git`。

## 修改
- `src/ui/statistics-dashboard-panel.js`：SRS `blocked/error/recoveryAvailable/persisted=false` 與 Playback History `persisted=false` 都會使 dashboard snapshot unavailable，避免非持久化或待復原排程冒充正常統計。
- `src/persistence/srs-store.js`：`persist()`／`flush()` 成功保存有效 schedule 後清除記憶體 `recoveryRaw`／warning 狀態，但 quarantine bytes 仍留在 storage recovery key。
- `tests/statistics-dashboard-panel.test.cjs`：新增 SRS write error 與 recovery state 的 fail-closed regression。
- `tests/srs-store.test.cjs`：新增有效替代排程成功保存後 recovery warning 清除、原始 recovery bytes 仍保留的 regression。

## 驗證
- SRS store 20/20；Statistics dashboard panel PASS；focused 10 個 Node test files PASS。
- 全量 90/90 Node test files 最終逐檔 exit 0；Architecture 1,279 PASS／0 FAIL；JS/CJS syntax 193/193；Python compile 12/12。
- Chromium app-shell 150/150，兩個既有 harness 都通過。
- `node tools/audit-visual-role-coverage.cjs`：48 roles、35 wired、13 unsupported、31 有測試線索。
- AMQ／EMQ raw hashes 未變。

## 範圍與阻塞
- Settings 與 Multiplayer 既有 store save/error、busy/rejected/focus contracts 已檢視並跑 focused tests；本批沒有證據支持重寫。完整 backup/restore browser E2E 與 multiplayer multi-client E2E 仍未完成。
- HTTP-origin IndexedDB 仍被 Chromium 管理政策阻擋，不重試相同探測。live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0、native osu!stable fidelity 未驗收。
- 35 wired Skin roles 尚未逐一 browser closure；13 unsupported 保持 unsupported。

## 下一批 Batch250
先確認持久化驗收環境是否有實際條件變更；若沒有，將既有阻塞封存並繼續可在本地驗證的資料復原／備份流程與端到端回歸，不重複跑已知會被政策攔截的 probe。
