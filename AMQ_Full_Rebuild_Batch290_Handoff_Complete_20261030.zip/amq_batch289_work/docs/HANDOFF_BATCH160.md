# Batch160 Handoff：ANN 封面錯誤處理與來源可存取性

## 本批已完成
- ANN adapter 具備 timeout、429／500／network／body failure／abort 的明確錯誤分類。
- Catalog 在封面旁顯示來源連結與 attribution，並具備可存取名稱、安全新分頁屬性及鍵盤事件隔離。
- 新增 ANN 錯誤型態測試及 Catalog source link regression。

## 修改檔案
- `src/integrations/ann-artwork-adapter.js`
- `src/ui/catalog-browser.js`
- `src/styles.css`
- `tests/ann-artwork-adapter.test.cjs`
- `tests/catalog-browser.integration.test.cjs`
- `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH160.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`
- `artifacts/batch160-regression/`

## 驗證
- 受影響 7 個 test files：23/23 top-level tests PASS。
- App lifecycle regression 組合：22/22 PASS。
- Architecture：1037 PASS／0 FAIL。
- Chromium OSK panel：12/12 assertions PASS。
- 全部 69 個 Node test files 均有成功執行證據；前 56 個分組執行，後 13 個逐檔執行。初始全組 orchestration 在 120 秒上限中斷，不宣稱該命令成功。細節見 `artifacts/batch160-regression/summary.json`。

## 尚未驗證
- 真實 ANN API／CORS／圖片實際載入；目前使用 fixture／fake DOM。
- 真實 `.osk` 與非 opaque HTTP-origin IndexedDB save/reload/clear。
- 正式 osu!stable Song Select 完整分層替換與視覺驗收。

## Batch161 直接執行
1. 閱讀 `prototype/ui-v2-osu-select-batch146/` 的 HTML、CSS、互動模型及既有 smoke tests，對照正式 `src/index.html`／`src/ui/catalog-browser.js`。
2. 在正式 Catalog 實作第一個完整 UI 替換切片：把「控制區／選曲列表／選取作品資訊」建立為明確的視圖區域，保持 controller、query-index、personal-library、artwork adapter 為唯一資料／狀態來源。
3. 不直接搬入 mock data，不覆蓋正式資料流，不隱藏舊 UI 假裝重構完成。
4. 補 DOM integration／responsive contract tests，驗證搜尋、篩選、排序、分頁、鍵盤、個人清單、看番狀態及 Skin target 未退化。
5. 真實外部服務與 `.osk`／IndexedDB 阻塞維持明確標記。
