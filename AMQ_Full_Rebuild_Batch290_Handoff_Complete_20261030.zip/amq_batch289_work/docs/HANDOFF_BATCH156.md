# Batch156 交接：Artwork work-reference 與 Catalog thumbnail groundwork

## 工作副本與保護邊界
- 工作目錄：`/mnt/data/amq_batch153_work`
- 無 Git metadata；不要初始化 Git。
- Candidate302、Candidate382 Stage 0、AMQ／EMQ 原始曲庫 assets 保持唯讀，未修改。
- 開工必讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、本文件及 `docs/NEXT_SESSION_PROMPT.md`。

## 本批已實作
- AMQ／EMQ song mappers 增加 frozen `artworkRef`，包含 work kind/source/id；EMQ 有 `vndbId` 時保留明確外部 ID。
- Artwork adapter 以 `artworkRef` 做 cache/provider identity，同一作品多首歌共用 cache。
- Catalog 支援注入 adapter 並呈現作品封面／fallback，僅使用 adapter 驗證過的 HTTPS URL；非同步 render generation guard 防止舊畫面回寫。
- 新增 cache identity 與 Catalog integration regressions，更新 architecture checks。

## 測試證據
- `node --test tests/artwork-adapter.test.cjs tests/source-mappers.test.cjs tests/catalog-browser.test.cjs tests/catalog-browser.integration.test.cjs`：9/9 top-level PASS。
- `node tools/check-architecture.cjs`：1009 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 PASS。
- `tests/` 67 個 Node test files 均有成功執行證據：分組 01–09、11–12 成功；group 10 原始批次達整體 120 秒限制後，拆成 6 個逐檔執行，6/6 成功。日誌在 `artifacts/batch156-regression/`。

## 不可誇大的狀態
- **Artwork UI 尚未正式供應真實封面**：Catalog 可接 adapter，但正式 `app.js` 尚無可靠 provider factory。現有 AniList／MAL／VNDB adapter 有 search/get APIs，不等於 AMQ/EMQ work ID 已對應外部作品 ID。不要直接按標題自動採用模糊候選，也不要每列直接發網路請求。
- 真實 `.osk` 仍未取得；fixture 不等於真實 skin 驗收。
- IndexedDB 真實 browser save/reload/clear 仍需非 opaque origin，已知 Chromium localhost 導覽被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋，不要無限重試。
- 正式 osu!stable Song Select 全面 UI 替換仍未完成。

## 下一步
1. 調查舊版 ANN／VNDB linking approach 或外部 ID 來源，定義可追溯的 anime/game work identity mapping。
2. 完成可靠 provider factory（請求取消、快取、速率限制、失敗 fallback、來源 attribution），再由 app 注入 adapter。
3. 補 provider integration tests 後，才把真實封面供應標記完成。
4. 之後替換正式 Song Select UI，保留搜尋／篩選／排序／分頁／鍵盤／個人清單／學習狀態。
5. 繼續將真實 `.osk`、非 opaque IndexedDB 驗收列為阻塞，不把 fixture/mock 測試冒充真實環境驗收。
