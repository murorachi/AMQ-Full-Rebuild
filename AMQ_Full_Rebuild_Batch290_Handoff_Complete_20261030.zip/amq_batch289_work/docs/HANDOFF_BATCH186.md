# Batch186 交接：AudioService callback 重入保護

## 本批完成
- `src/engine/quiz-session.js` 新增 `sessionTransitionInProgress`。在 `nextQuestion()` 停止舊音訊並設定新題、未播放 `skip()` 停止音訊、`pause()`、`reset()`、`endRound()` 的同步 callback 區間，Session 自己不發布中間快照，重入 mutation 會回傳 `session-transitioning`。
- 保留 Batch185 `mutateEngine()` 與 `persistProgress()` 的 `persistence-in-progress` guard。
- `tests/quiz-session.test.cjs` 新增三個 regression：nextQuestion stop callback 重入 reset；reset/endRound stop callback 重入 startRound；未播放 skip stop callback 重入 startRound。
- `playbackEpoch`、AudioService `playAttemptId`、熟悉度規則、all-target 作品標題判定、單一 playback owner 與曲庫資產未修改。

## 測試證據
- QuizSession：37/37 PASS。
- 全部 73 個 Node `*.test.cjs`：73/73 exit 0，0 failures。`artifacts/batch186-regression/node-tests.tsv` 與 `node-tests/` 有逐檔結果。
- Architecture Checker：1,080 PASS／0 FAIL。
- OSK harness：12/12。
- 168 個 JS/CJS `node --check` PASS。
- AMQ／EMQ 資產 hash 與 Batch184 ZIP 相同。

## 修改檔案
- `src/engine/quiz-session.js`
- `tests/quiz-session.test.cjs`
- `AI_START_HERE.md`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `docs/HANDOFF_BATCH186.md`
- `artifacts/batch186-regression/*`

## 尚未驗收／限制
- 真實瀏覽器／音訊、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤與 Candidate302／Candidate382 Stage 0 相容性未驗收。
- 無 `.git`，未初始化；正式基準原始檔缺席。
- 具名多組曲庫篩選預設尚未實作。下一批先盤點既有 App Settings／Catalog filter schema，再決定安全的最小接法。

## Batch187
1. 盤點既有 filter schema／UI／storage contract，避免第二份 filter source of truth。
2. controlled audit 剩餘 Session／AudioService callback reentry，只修可重現 P0/P1。
3. 全量回歸與交付 ZIP／SHA-256。
