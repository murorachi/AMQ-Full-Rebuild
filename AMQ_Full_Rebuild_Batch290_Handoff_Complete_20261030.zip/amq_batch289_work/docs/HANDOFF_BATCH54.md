# Batch 54 交接：必要功能真相表與音訊／Session 回歸

## 完成

- 移除 `src/ui/quiz-panel.js` 在 dataStatus 非 loaded 分支重複呼叫 `disposeSession()` 的冗餘程式碼。
- `tests/audio-session.integration.test.cjs` 新增兩組跨模組情境：primary play rejection 後 fallback 到 backup，只有 backup 真正 `playing` 才啟動一個倒數；session dispose 後遲到的 `playing` 不會啟動 timer 或發布狀態。
- `tests/quiz-panel.test.cjs` 新增 mode-switch 遲到舊 AudioService 事件的回歸，確保舊事件不能改寫新模式的 `questionStatus`。
- 更新功能真相表與產品契約中已過時的「清單未接出題池」「設定未持久化」「SRS UI 未接線」等描述。

## 修改檔案

`src/ui/quiz-panel.js`、`tests/audio-session.integration.test.cjs`、`tests/quiz-panel.test.cjs`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/FUNCTION_INVENTORY.md`、`docs/PRODUCT_CORE_CONTRACT.md`、`docs/ACCEPTANCE.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`、`README_FIRST.md`、`MANIFEST.sha256`。

## 驗證

- `tests/*.test.cjs`：25/25 scripts exit 0。
- Tooling：8/8 PASS。
- Architecture：459 passed／0 failed。
- Source audit：PASS，AMQ 38,821、EMQ 16,839，cross-source collisions 0。
- Mapper：PASS，AMQ 38,821、EMQ 16,839、Catalog 55,660。
- Benchmark：5 iterations PASS（Node in-memory only）。
- JS/CJS syntax：PASS。
- Browser E2E：BLOCKED，既有 `ERR_BLOCKED_BY_ADMINISTRATOR`；未重試相同導覽方式。

## 下一批 Batch 55

1. 核對剩餘 P0/P1 核心契約並逐項分類：已由 Node 證據完成、可安全實作、真實瀏覽器待驗收、或因基準／參考缺失而 BLOCKED。
2. 有明確契約且尚未實作的必要功能，直接完整實作與測試；不得為了擴大範圍猜測收藏身份或舊版行為。
3. 若只剩真實瀏覽器、音訊與正式基準阻塞，完成文件一致性整理後明確記錄，UI／CSS 全面重構仍排最後階段。
