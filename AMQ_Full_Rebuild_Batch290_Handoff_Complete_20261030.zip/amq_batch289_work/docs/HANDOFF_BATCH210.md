# Batch210 Handoff：共用資料 owner 的個人檔案頁

日期：2026-10-29

## 工作來源與版本保護
- 來源工作副本：`/mnt/data/amq_batch209_work/project`，其上已包含 Batch209 round-scoped result panel。
- Batch209 ZIP 與 `artifacts/batch209-regression/` 保持不變；本批新增證據在 `artifacts/batch210-regression/`。
- 工作副本沒有 `.git`，未初始化 Git。Candidate302 正式基準與 Candidate382 Stage 0 CSS 比較基準原始檔仍缺席，沒有猜測、覆蓋或宣稱相容。
- AMQ／EMQ 曲庫資料唯讀，hash 未變。

## 修改檔案
- `src/ui/statistics-dashboard-panel.js`：新增唯讀 `getSnapshot()`／`subscribe()`；原 dashboard 仍持有 History／Familiarity／SRS／Playback store instances，並在報表或讀取錯誤更新時通知訂閱者。
- `src/ui/profile-panel.js`：新增個人檔案 UI，讀取 shared dashboard snapshot，不建立重複 stores；真實錯誤顯示「暫不可用」，無樣本正確率顯示「尚無資料」。
- `src/index.html`：新增 `#profile-panel`，包括六個真實資料指標、來源／目標拆分、作品進度與全球排名未接入聲明。
- `src/app.js`：在 statistics dashboard mount 後建立 profile panel，依 scope lifecycle 先釋放 profile subscription 再釋放 dashboard owner。
- `src/ui/app-shell.js`：新增 profile 路由、導航、首頁第五個入口、頁面 intro 與標題／副標題。
- `src/styles/ui-shell.css`：新增 profile 桌面／手機樣式與首頁五入口排布；手機位置已調整以避免入口重疊。
- `tests/profile-panel.test.cjs`：新增 19 assertions，覆蓋讀取失敗、真實 snapshot、空狀態、作品列表與 unsubscribe。
- `tests/statistics-dashboard-panel.test.cjs`：新增共享 snapshot、訂閱通知與取消訂閱測試。
- `tests/app-shell.browser.test.py`：新增 profile route／指標／排名 disclaimer、五個入口 desktop/mobile 無重疊及 profile mobile layout assertions；測試產物指向 Batch210。
- `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/OSU_STABLE_WIKI_TRACEABILITY_BATCH206.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/NEXT_SESSION_PROMPT.md`、`MANIFEST.sha256`：更新工作紀錄。

## 驗證結果
- Profile panel：19/19 assertions PASS。
- Statistics dashboard panel：PASS，含 shared snapshot／subscribe／error propagation／unsubscribe。
- Chromium formal shell：72/72 PASS；首頁五個入口 desktop/mobile 無重疊，profile desktop/mobile layout PASS，390px 無水平溢位，無 uncaught browser exceptions。
- 77/77 `tests/*.test.cjs` 檔案逐檔 exit 0；詳細日誌 `artifacts/batch210-regression/node-tests/`。
- Architecture Checker：1,137 PASS／0 FAIL。
- 172 個 JS/CJS 檔案 `node --check` PASS；Python browser test `py_compile` PASS。
- AMQ／EMQ 資產 hash 未變，見 `artifacts/batch210-regression/asset-hashes.txt`。

## 限制
- inline Chromium fixture 使用 opaque origin，profile 的本機統計讀取在此環境顯示錯誤狀態。這是預期的 fail-closed 行為，不是非空統計資料驗收。真實 HTTP-origin 持久化與非空資料顯示仍未驗收。
- Profile 只呈現本機學習進度；沒有全球排行榜、PP、PB 或帳號身份。
- Batch209 的結果面板仍需更完整的 lifecycle edge-case regression；Catalog artwork fallback 也需確認沒有 adapter／provider failure 時的視覺品質。
- 真實 `.osk`、外部 API、曲庫／音訊及 Candidate302／Candidate382 Stage 0 相容性仍未驗收。

## Batch211 下一步
1. 補結果面板在手動結束、題庫耗盡、all-target、reveal／unplayed skip、儲存失敗與新回合開始時的 lifecycle tests。
2. 驗證 Catalog artwork provider 的缺資料、throw、圖片載入錯誤及無 adapter fallback；不要讓歌曲列退化成純文字或空白塊。
3. 盤點可信排行榜後端契約；沒有資料 owner 前只呈現未接入狀態，不造排名。
4. 更新同一份清單、狀態、traceability、handoff、manifest、測試證據與 ZIP；UI 主線仍未結案。
