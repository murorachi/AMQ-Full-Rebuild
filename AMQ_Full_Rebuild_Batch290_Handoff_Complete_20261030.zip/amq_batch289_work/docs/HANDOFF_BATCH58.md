# Batch 58 交接：Repository pre-aborted signal 邊界

## 結論

Batch 57 之後沒有新的真實瀏覽器執行環境或正式基準檔案可用。本批沒有重試已失敗的 Chromium CLI 導覽，而是沿著 Repository 取消契約找到一個明確的注入邊界缺口並修正。

`Repository.load({ signal })` 在呼叫前 signal 已經 aborted 時，先前仍會呼叫注入的 `adapter.load()`，再透過 Promise race 取得取消結果。內建 Source Adapter 會先檢查 signal，但 Repository 明確支援注入 Adapter；外部 Adapter 可能在自行檢查 signal 前執行副作用。這是 Repository 層應該保護的邊界。

## 修改

- `src/data/repository.js`
  - 在啟動注入 Adapter 前先檢查內部 signal。
  - 若外部 signal 在呼叫前已 aborted，直接進入既有標準 `DATA_LOAD_CANCELLED` catch/reset 流程，不啟動 Adapter。
  - 未改變活動請求取消、generation、`cancel()`／`invalidate()` 的既有語義。
- `tests/data-pipeline.integration.test.cjs`
  - 新增直接注入非合作 Adapter 的回歸，避免內建 Source Adapter 自身的 signal guard 掩蓋 Repository 缺口。
  - 修正前先以紅測試確認 Adapter 會被呼叫（17/18 PASS）；修改後 18/18 PASS。
- `docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`
  - 明確記錄 pre-aborted signal 不得啟動注入 Adapter 的契約。
- `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`、`README_FIRST.md`
  - 更新批次進度、驗證、阻塞與下一步。

## 驗證結果

- `tests/*.test.cjs`：25/25 個測試腳本 exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：459 passed，0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 首、EMQ 16,839 首；重複 ID、dangling references 與跨來源 ID 衝突均為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660 筆，AMQ 38,821、EMQ 16,839。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，5 次 Node in-memory benchmark；不代表瀏覽器效能。
- `node --check` 對 `src/`、`tests/`、`tools/` 共 63 個 JS/CJS 檔案：PASS。
- Checklist 任務 ID：648 個唯一 ID，重複 ID 0（本批也修正一處只在說明文字中重複提及既有 ID 的情況）。
- 來源資料 hash 未變：`data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 詳細執行日誌：`/mnt/data/amq_batch58_logs/`。

## 未驗收／阻塞

- 真實瀏覽器 UI、響應式、鍵盤、跨分頁 localStorage：BLOCKED／未驗收。Batch 57 的 Chromium CLI 在 25 秒內沒有 DOM 輸出且有 DBus／zygote 錯誤；本批沒有新執行環境，不重試相同方式。
- 真實音訊可聽性與乾淨 Windows 啟動：未驗收。
- Candidate302／Candidate382 Stage 0 相容性：未驗收；Candidate381 仍僅為靜態參考，不擅自升格。
- `aniFavorites_v1` ID 身份未知；legacy `animeIds`／watch status 缺少來源，不自動遷移。
- MIX 2:1 權重有內部測試證據；舊版 AMQ-specific filter suppression 尚未移植，因新版對應篩選控制尚未實作。
- 工作副本沒有 `.git` metadata；未初始化 Git、未 commit／push，也未修改正式基準與來源資料。

## Batch 59 下一步

1. 若有新真實瀏覽器通道或正式基準證據，先做對應驗收；否則不要重試已知失敗的相同 Chromium 導覽方式。
2. 從 `docs/MASTER_CHECKLIST.md` 尾端與核心契約中，找下一個有明確契約、可用回歸測試驗證的缺口；先建立會失敗的測試，再決定是否需要生產碼修改。
3. 不猜測收藏身份、legacy source-less IDs 或 P2 行為；UI／CSS 大重構仍排最後階段。
4. 完成本批後更新同一份清單／狀態、執行全量驗證並重建 manifest／完整 ZIP。
