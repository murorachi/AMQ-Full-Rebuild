# Candidate382 Stage I 靜態責任盤點（Batch 2）

- 來源：`/mnt/data/amq_candidate382_stageI_design_system_responsibility_split_20261027.html`
- 檔案大小：1,615,368 bytes
- SHA-256：`e4c497b72f3803f538fc9900f33ed2ffa6f1cb65c68774a8631b545290ac6747`
- 定位：**Stage I 參考檔，不是 Candidate382 Stage 0 CSS 比較基準，也不是 Candidate302 正式維護基準。**
- 方法：唯讀 HTMLParser、正規表示式及行號檢查。沒有執行瀏覽器、沒有載入外部資料，也沒有把靜態線索當成功能驗收。

## 靜態結構指標

| 指標 | 結果 | 解讀限制 |
|---|---:|---|
| HTML 行數 | 11,682 | 反映檔案規模，不代表每行都是獨立程式碼 |
| HTML DOM 中實際 `id` 屬性 | 275 個，275 個唯一值 | 只統計 HTMLParser 可見的靜態 DOM；執行時建立的 ID 不在此統計內 |
| `<script>` | 69 個：67 個 inline、2 個外部 | 大量 inline script 增加初始化順序及依賴追蹤成本 |
| `<style>` | 114 個 | 代表 CSS 分散於大量 style blocks；需追蹤來源、載入順序與覆寫，不能只憑數量判定全部可刪 |
| HTML `style` 屬性 | 8 個 | 不包含 JS 執行時動態寫入的 inline style |
| `@layer` 字串命中 | 119 次 | 是文字命中數，可能含程式碼字串；不等同有效 CSS layer 數 |
| `MutationObserver` 字串命中 | 44 次 | 暗示 observer 清理責任需逐個確認，不能直接批次刪除 |
| `ResizeObserver` 字串命中 | 3 次 | 需要確認觀察目標及 disconnect 生命週期 |
| `setInterval(` 字串命中 | 10 次 | 需配對清除路徑與 owner |
| `setTimeout(` 字串命中 | 121 次 | 是文字命中數，非唯一 timer 數；需逐模組追蹤取消及過期回呼 |
| `addEventListener(` 字串命中 | 470 次 | 是文字命中數，可能包含程式碼字串；不能直接當成唯一監聽器數 |
| 外部 API `fetch` 目標 | AniSongDB catalog dump、AniList GraphQL、VNDB API | 文字掃描只找到 4 次 `fetch(` 呼叫及 3 個不同 URL；尚未驗證網路行為 |

## 已確認的程式入口與責任線索

| 行號 | 靜態證據 | 後續處理 |
|---:|---|---|
| 451 | 載入外部 `data.js`，緊接著讀取 `DB.anime`、`DB.songs` | 必須取得與這份 HTML 配套的實際檔案；不能用別版資料替代 |
| 697 | `loadDB()` 以 IndexedDB `aniCollectionDB` 讀取 `cache/catalog`，錯誤時回傳 `null` | 需確認它是外部目錄快取，不可直接等同主曲庫載入流程 |
| 754 | 音訊 fallback timer、token 與失敗處理狀態放在模組級變數 | 應把播放請求序號、timer 取消、候選推進責任收斂到 AudioService；先建立回歸測試再遷移 |
| 755 | `startMediaCandidate()` 同時選來源、切換 audio/video 元素、掛載事件、設定逾時、呼叫 `load()` 與 `play()` | 單一函式責任偏多，是未來拆分候選解析、媒體元素 adapter 與播放政策的具體候選；目前不直接複製到新版 |
| 2,439 | 存在 `setMode(mode, {start=true}={})` | 需追查呼叫點、全域狀態與 UI owner，才能定義 AMQ/EMQ/MIX 的狀態轉移 |
| 3,019–3,025 | `initObservers()` 為歌曲列、discover、learning plan 建立多個 `MutationObserver` | 確認是否保存 observer 引用、是否有 dispose；不能只看初始化就宣稱有清理 |
| 3,064 | 透過 `pagehide` 寫入 localStorage，catch 區塊忽略錯誤 | 持久化需獨立錯誤狀態及可測試介面；此處只記錄風險，不直接修改參考檔 |
| 4,173 | quiz round label 監聽器建立 `MutationObserver` | 檢查 observer 是否會隨 quiz 模組生命週期 disconnect |
| 5,921–5,924 | resize listener 與 `ResizeObserver` 用於頭像/輸入框對齊 | 需確認監聽器及 observer 是否有共同 owner |
| 6,405 | 載入外部 `emq-data.js` | 需取得配套資料並核對 ID、schema 及 ready 時序 |
| 7,478–7,480 | 自訂清單管理邏輯含全域 click handler、grid observer 及 timer | 事件代理與 observer 應有明確生命週期，避免多次初始化重複綁定 |
| 8,298–8,300 | song select route 使用 `hashchange`、`popstate` 與 `MutationObserver` | 路由狀態與 observer 需要集中管理 |
| 8,977–8,980 | 有 `error` 與 `unhandledrejection` 全域事件監聽 | 需確認是否重複安裝、錯誤是否有可追蹤的分類及呈現方式 |

## 資料檔與基準追查結果

- 這份 Stage I HTML 的外部 script 路徑是小寫 `data.js` 與 `emq-data.js`。這只證明 HTML 的引用名稱，不代表目前已取得檔案內容。
- GitHub 預設分支的程式碼搜尋沒有找到 Candidate302、Candidate382、`data.js` 或 `EmqData` 的匹配。
- 找到分支 `amq-candidate302-stage3-emq-loader-validation-20261025`，但該分支的 `CURRENT_STATUS.md` 與 `BASELINE.md` 寫明 Candidate295 仍是正式維護基準，並列出 Candidate302 候選雜湊；這與新版重建專案規範「Candidate302 為正式維護基準」不同。該分支無法取回文件中所列 HTML 本體，且資料檔仍 404，因此**只作歷史線索，不作基準認定或資料來源**。
- 尚未找到 Candidate382 Stage 0 分支或確切檔案。

## 結論

本批只完成靜態證據整理，未修改參考 HTML。下一步應優先取得可核對的正式基準、Stage 0 與配套曲庫；在此之前，繼續完成獨立重建骨架的生命週期、錯誤契約及測試基礎，不應猜測舊版資料結構。
