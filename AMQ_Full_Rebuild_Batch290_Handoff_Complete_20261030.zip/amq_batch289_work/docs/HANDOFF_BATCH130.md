# AMQ 新版重建交接：Batch130（查詢篩選交叉矩陣）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與來源 assets 唯讀。

## 修改
- `tests/filter-matrix.test.cjs`：獨立組合 includeUnknownYear 與其他 filter 維度，加入 query、animeId，使用獨立 expected predicate 對照 production catalog。
- 10 個維度的所有 masks × includeUnknownYear true／false，共 2,048 種組合。新增多值 source/type 的 OR-within facet、AND-across facets 測試。
- 沒有改 `src/data/query-index.js`：矩陣沒有找到可重現的 production defect。第一版新增 assertion 的 expected list 漏列無年份但沒有啟用年份範圍時應保留的 A4，已修正 fixture。
- `docs/MASTER_CHECKLIST.md`：更新 AMQ-967／968 的證據範圍，新增 AMQ-1363–1368。
- `docs/WORK_STATUS.md`：記錄矩陣範圍、結果、測試 fixture 修正及下一步。

## 驗證
- `node tests/filter-matrix.test.cjs`：2,048/2,048 PASS；分頁、未知年份、年份排序、facet 與多值 filter assertion PASS。
- `node tests/backup-restore.test.cjs`：10/10 scenarios PASS。
- 57 個非-tooling test scripts 均逐檔 exit 0（長批次先完成 53 個，剩餘 4 個分開重跑）；tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
- AMQ／EMQ readonly asset SHA-256 unchanged。

## 封包驗證
- 最終 Manifest：292 entries；missing 0／stale 0／hash mismatch 0。
- ZIP：293 files；CRC PASS；archive file set 與工作副本完全一致，missing 0／extra 0；未包含 `.pem`／`.key` 私鑰檔。

## 未解決
- Selector 的 personal list／blacklist／SRS eligibility／source weighting 尚需另一組跨模組矩陣。
- 真實瀏覽器 facet 操作、跨分頁狀態及大量資料互動未驗收。
- Candidate302 schema compatibility 未證明。

## 下一步
Batch131：以獨立參考 predicate 測試 quiz selector 的 personal list、blacklist、SRS eligibility、AMQ／EMQ／MIX source weighting 與未知年份組合；僅在可重現失敗時修改 production code。
