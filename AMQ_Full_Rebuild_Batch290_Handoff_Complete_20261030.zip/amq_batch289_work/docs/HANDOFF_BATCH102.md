# Batch 102 交接包

日期：2026-10-27

## 本批成果
- 新增 `player.join` 成功重放 regression：相同 authenticated player／requestId／payload 回傳原始 event，不重複加入 membership、不增加 revision。
- 新增 capacity=2 FIFO cache regression：插入 A、B，重放 A，再插入 C；A 仍被淘汰，證明 replay hit 不會刷新 insertion order。
- 驗證被淘汰的 requestId 再次提交時會重新執行；如果狀態轉移是 no-op，revision 不增加。
- 本批只有測試與文件更新，production code 沒有變更。

## 修改檔案
- `tests/multiplayer-room-command-service.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `docs/HANDOFF_BATCH102.md`
- `MANIFEST.sha256`

## 驗證證據
- `node tests/multiplayer-room-command-service.test.cjs`：PASS。
- 非-tooling `tests/*.test.cjs`：44/44 個腳本逐檔 exit 0，日誌 `/mnt/data/amq_batch102_validation.log`。
- `node --test tests/tooling.test.cjs`：9/9 PASS。
- `node tools/check-architecture.cjs`：719 passed／0 failed。
- JavaScript／CJS syntax：100/100 PASS。
- Source audit／mapper PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；Catalog 55,660 records；cross-source ID collisions 0。
- 5 次 Catalog benchmark PASS；本機 Node build 約 1,108.441 ms，非瀏覽器效能保證。
- 來源資產 hash unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 契約邊界
冪等重放回傳快取的原始結果，其中 snapshot 可能比目前 room revision 舊。這符合目前「重放原始結果」契約，但消費端不能無條件用舊 snapshot 覆蓋更新狀態。下一批需檢查 `getSnapshot(sinceRevision)`、closed-room／離房者回應與 stale replay snapshot 的處理方式。未經契約測試前，不要暗中改成 fresh snapshot。

## 阻塞
- 真正 transport/auth、durable idempotency、跨節點 state／serialization、reconnect、多 client E2E 尚未實作。
- 多人 SRS persistence 需產品決策；瀏覽器／音訊／storage 未真實驗收。
- UI／CSS 大重構仍最後做。
