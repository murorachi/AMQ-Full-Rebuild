# AMQ 新版重建交接：Batch123（多人過期投影／重連回歸）

日期：2026-10-28。沿用 Batch122 工作副本；無 `.git` metadata，未初始化／commit／push。

## 本批修改
- `src/ui/multiplayer-panel.js`：安全 projection 檢查同時要求 roundId/questionId 與權威回合一致、候選非空、HTTP(S) URL、kind 僅 audio 或未提供。播放 handler 也再次驗證並過濾候選，不能靠 UI disabled state 充當安全邊界。
- `tests/multiplayer-panel.integration.test.cjs`：覆蓋 questionId mismatch、roundId mismatch、不安全 URL、空候選不可播放；有效投影恢復後可重新啟用播放；polling offline→connected 後維持 authoritative active round；server round closed 後禁用播放並清理本地 clock/audio；保留 Batch122 的 AudioService 共用、失敗診斷、lease revoke、leave/dispose 測試。

## 驗證
- 非-tooling tests：57 個 scripts 均有逐檔 exit 0 證據。單一長批次命令到達 300 秒工具時限，已完成 54 個；尾段 SRS 與兩個 statistics scripts 分開重跑成功。更新後的 multiplayer panel integration 另行重跑成功。沒有把超時的總命令當作通過。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：893 passed／0 failed。
- Source audit PASS，重複／懸空／跨來源 ID 問題皆 0。
- Full mapper PASS：AMQ 9,516 works／38,821 songs；EMQ 6,645 works／16,839 songs；Catalog 55,660。
- 5-run benchmark PASS，Catalog build 約 1,066.897 ms，僅 Node 本機觀測值。
- 唯讀來源 SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 限制
- 真實 browser／multi-client E2E 仍因既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞；沒有重試相同路徑。
- Node／VM 測試不代表真實音訊、CORS、供應商可用性或瀏覽器行為已驗收。
- 多人 SRS 自動寫入、durable offline queue／多裝置合併、WebSocket／多節點仍未完成。

## 下一步
Batch124：盤點 server assessment 與現有 SRS repository，設計 source-aware、revision-aware、idempotent 的多人 SRS 寫入契約，先測試再實作。
