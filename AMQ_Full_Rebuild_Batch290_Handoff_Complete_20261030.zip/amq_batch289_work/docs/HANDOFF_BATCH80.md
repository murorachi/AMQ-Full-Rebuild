# AMQ Batch 80 交接包

日期：2026-10-27
批次：猜歌出題篩選第一批實作

## 本批結論

已把目前來源資料能可靠支援的主要猜歌篩選接入出題池：年份起迄／未知年份、作品類型（AMQ 有來源欄位）、歌曲類型、難度起迄、看番狀態。篩選與模式來源、AMQ 黑名單、source-aware 個人清單以 AND 關係組合。新設定透過既有 `appSettingsStore` 持久化，並已測試備份／還原 round-trip。

這是完整篩選功能的第一個可驗證切片，不是整個功能結案。季別、Random Sample、片段起始位置、自動下一題延遲仍未完成；舊版 MIX 對 AMQ-specific filters 的 suppression 語義也尚未移植。

## 修改檔案

- `src/data/source-mappers.js`：映射 `animeYear`／`animeType`；未知欄位保留 null。
- `src/persistence/app-settings-store.js`：同一版本化設定 store 新增篩選欄位、驗證與舊設定預設相容。
- `src/index.html`、`src/styles.css`：加入收合式猜歌篩選控制及局部樣式。
- `src/ui/quiz-panel.js`：在 eligibility 階段執行篩選；個人清單、黑名單、模式來源繼續生效；看番狀態變更會更新資格池。
- `tests/app-settings-store.test.cjs`：範圍驗證與持久化回歸。
- `tests/source-mappers.test.cjs`：來源年份／作品類型 mapping 回歸。
- `tests/quiz-panel.test.cjs`：多條件組合與清除篩選的 integration regression。
- `tests/backup-restore.test.cjs`：篩選設定 backup/restore round-trip。
- `docs/DATA_CONTRACT.md`、`docs/FUNCTION_INVENTORY.md`、`docs/FUNCTION_PARITY_AUDIT_BATCH70.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`：更新資料契約、差異狀態、進度及交接。
- `MANIFEST.sha256`：打包前重建。

## 驗證證據

- `tests/*.test.cjs`：30/30 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：524 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839，重複 ID／懸空關聯／跨來源 ID 衝突均 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660 筆。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；build 約 1,177.067 ms（Node 本機觀察值，不是瀏覽器效能保證）。
- `src/`、`tests/`、`tools/` 共 72 個 JS/CJS 檔案 `node --check` PASS。
- `tests/app-settings-store.test.cjs` 7/7、`tests/source-mappers.test.cjs` 7/7、`tests/backup-restore.test.cjs` 8/8；`tests/quiz-panel.test.cjs` integration PASS。
- AMQ／EMQ 原始資產 SHA-256 未變：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

有一個長命令在 mapper 驗證階段逾時；之後 mapper、架構檢查、benchmark 都分別獨立重跑成功。逾時的長命令本身不計為通過。

## 未驗收／阻塞

- 真實瀏覽器的篩選互動、跨分頁設定更新與音訊回合未執行；已知 Chromium 頁面導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重試同一方法。
- 季別：來源 schema 無可信 season 欄位，禁止由年份推算。
- EMQ 作品類型欄位未核實，因此 `animeType` 為 null；啟用作品類型篩選時，EMQ 不會假裝匹配 AMQ 類型。
- Random Sample、片段起始位置、自動下一題延遲未實作。
- 資料庫更新、Chinese Title Provider、自由播放歷史、統計儀表板、自由播放欄、外部服務與多人模式仍待開發。

## 下一批建議

1. 完成 Random Sample／片段起始位置／自動下一題延遲，明確分工 AudioService 與 QuizClock 並補整合測試。
2. 核實舊版 Chinese Title Provider 的 API／資料契約後再接入，不得編造 endpoint。
3. 定義資料庫更新／匯入的版本、驗證、預覽、原子提交與回復契約。
4. 持續以 `docs/MASTER_CHECKLIST.md` AMQ-960–968 作為剩餘功能追蹤清單。

## 基準與 Git

- 工作副本由 Batch79 ZIP 解壓而來，沒有 `.git` metadata；未初始化 Git，沒有分支／提交可報告。
- 未修改 Candidate302、Candidate382 Stage 0 或來源資料資產；新版仍為獨立重建。
- 沒有進行 UI／CSS 全面重構。
