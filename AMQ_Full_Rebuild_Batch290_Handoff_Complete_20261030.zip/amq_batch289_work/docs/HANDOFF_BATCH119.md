# AMQ 新版重建交接：Batch119（包含 Batch118 Controller 與播放權協調）

日期：2026-10-28  
基礎交付：`AMQ_Full_Rebuild_Batch117_Handoff_20261028.zip`  
Git：工作副本沒有 `.git` metadata；未初始化 Git、未 commit、未 push。

## 本批目標

接續 Batch118 完成多人房間 Session／Controller，並實作單一 playback owner coordinator，將獨占播放權接入既有 QuizSession，避免後續多人 UI 與單人猜歌同時搶音訊。未進行 UI/CSS 視覺改版。

## 實作成果

1. 新增 `src/multiplayer/room-session.js`，管理 room ID、snapshot/revision、timeout assessment、連線狀態與 subscribers。
2. 使用 recursive `setTimeout`，同一時間最多一個 snapshot request；`start()` 重複呼叫不建立第二個 loop。
3. `stop()`／`dispose()` 清除 timer、abort 輪詢並使舊 generation 失效；即使底層 fetch 忽略 AbortSignal，遲到結果也不會更新 state 或重新排程。
4. Snapshot revision 僅單調增加。`unchanged`、較舊 revision 與同 revision 的非 unchanged payload 不會取代目前 snapshot。
5. Network error 使用有上限的退避輪詢；成功後恢復正常間隔。
6. 命令遇網路錯誤時保留原 requestId、原 payload 與原 expectedRevision。即使 polling 後看見較新 revision，重試仍重放原命令；revision conflict 不會被當作網路錯誤自動重試。
7. 新增 `tests/multiplayer-room-session.test.cjs` 七項測試，並將模組加至 `src/index.html` 載入順序與 architecture checker。

## Targeted validation

- `node --test tests/multiplayer-room-session.test.cjs`：7/7 PASS。
- `node --test tests/playback-coordinator.test.cjs`：5/5 PASS；`node tests/quiz-session.test.cjs`：23/23 PASS。
- `node tools/check-architecture.cjs`：待重新執行並更新最終數字。
- `node --test tests/tooling.test.cjs`：待重新執行並更新最終結果。
- 上述是 targeted／靜態證據；全量回歸、來源資產稽核、最終 ZIP／Manifest 結果以本文件最終更新段落為準。

## 變更檔案

- `src/multiplayer/room-session.js`（新增）
- `src/audio/playback-coordinator.js`（新增）
- `tests/playback-coordinator.test.cjs`（新增）
- `tests/quiz-session.test.cjs`（新增 owner handoff regression）
- `src/app.js`、`src/ui/quiz-panel.js`、`src/index.html`、`tests/tests.html`（播放權協調接線）
- `src/index.html`
- `tests/multiplayer-room-session.test.cjs`（新增）
- `tools/check-architecture.cjs`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `README_FIRST.md`
- `MANIFEST.sha256`（交付前重建）

## 尚未完成

- 多人 UI 尚未接入。
- 尚未建立單一 playback coordinator／owner lease；單人 `QuizSession` 與多人房間可能競爭音訊的整合風險仍需在 UI 接線前處理。
- 多人音訊同步、多人 SRS 自動寫入、WebSocket／多節點與真實瀏覽器／多 client E2E 尚未完成。
- Candidate302、Candidate382 Stage 0 與來源曲庫資產維持唯讀。沒有執行的真實瀏覽器／音訊測試不可宣稱通過。

## 下一批直接工作

1. 先閱讀 `src/app-runtime.js`、`src/ui/quiz-panel.js`、`src/engine/quiz-session.js`、`src/audio/audio-service.js` 與 `src/engine/quiz-clock.js`，追蹤 AudioService 實際實例生命週期與播放觸發入口。
2. 以最小安全 API 建立單一 playback owner coordinator／lease：單人 quiz 與 multiplayer 不可同時持有播放權；owner 交接必須先停止前任播放並取消 clock/session 的有效計時，不能複製 AudioService 或 QuizClock。
3. 為 owner acquire/release、重複 acquire、owner 切換、dispose 與 late async audio completion 加 regression。
4. 再以 `roomSession.subscribe()` 與 snapshot 投影接入最小多人功能 UI；不得讓 UI 自行決定 round duration、question、grade 或 revision。
5. 更新同一份主清單／狀態／handoff／prompt／架構／驗收／manifest，跑全量回歸與封包驗證。

## Batch119 同工作階段後續實作：播放權協調

- 新增 `src/audio/playback-coordinator.js` 與 `tests/playback-coordinator.test.cjs`，提供 app-scope 獨占 lease、owner revoke、同 owner idempotent acquire、錯誤隔離及 dispose。
- `src/app.js` 建立 coordinator 並注入 `src/ui/quiz-panel.js`；`src/engine/quiz-session.js` 在回合取得 lease，owner 被取代時停止 AudioService／QuizClock、取消 auto-next、結束回合並清除剩餘秒數；自然結束／reset／dispose 釋放 lease。
- `tests/playback-coordinator.test.cjs`：5/5 PASS；`node tests/quiz-session.test.cjs`：23/23 PASS，包含 owner handoff。
- 多人 UI 尚未接線，所以多人尚未實際使用 coordinator。未完成多人音訊同步、多人 SRS、WebSocket／多節點與真實 browser／multi-client E2E。

## 最終驗證

- 最終交付：`AMQ_Full_Rebuild_Batch119_Handoff_20261028.zip`。
- 全量 test scripts：57/57 個 `tests/*.test.cjs` scripts 均逐檔 exit 0。第一輪整體 shell 工具呼叫達執行時限後，剩餘 source-runtime／SRS／statistics／tooling 腳本改為個別執行並通過，沒有將工具總時限誤報成測試失敗。
- `tests/multiplayer-room-session.test.cjs`：7/7 PASS。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：879 passed／0 failed；此工具也對 `src/`、`tests/`、`tools/` JS/CJS 執行語法檢查。
- Source audit／full mapper verification／5-run catalog benchmark：exit 0。
- AMQ／EMQ 唯讀來源 SHA-256 與既有紀錄一致：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- Batch118 階段封包第一輪驗證曾確認 Manifest 276 entries、ZIP CRC PASS。Batch119 已新增 coordinator source/test 並更新多份文件，因此必須以本次最終 Manifest／ZIP 驗證為準。


## 最終封包驗證結果

- Batch119 最終封包驗證已於所有文件更新後執行並通過。Manifest 279 entries、missing 0／hash mismatch 0／extra work files 0；ZIP CRC PASS，280 files，ZIP missing 0／extra 0。
- 交付檔名：`AMQ_Full_Rebuild_Batch118_Handoff_20261028.zip`。
- Manifest 採每個專案檔案的 SHA-256，Manifest 自身不列入自身 hash。
- ZIP 必須包含 `MANIFEST.sha256` 及其列出的全部檔案，且不得有缺檔、額外檔案或 CRC 錯誤。最終 hash／大小於最終交付回報提供。
