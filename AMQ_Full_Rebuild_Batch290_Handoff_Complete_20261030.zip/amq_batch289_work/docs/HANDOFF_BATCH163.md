# Batch163 交接：正式 Catalog 篩選與選曲資訊層級（2026-10-28）

## 開工確認
- 已閱讀 `AGENTS.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH162.md` 與 `docs/NEXT_SESSION_PROMPT.md`。
- 工作副本 `/mnt/data/amq_batch153_work` 沒有 `.git` metadata；`git status` 回報不是 Git repository。未初始化 Git。
- Candidate302、Candidate382 Stage 0、AMQ／EMQ 原始曲庫資產均保持唯讀。

## 本批實作
- `src/styles.css`
  - 正式 Catalog 常用篩選改為明確六欄桌面配置：搜尋、來源、歌曲類型、看番狀態、排序依據、排序方向各有穩定的欄位責任，避免搜尋跨欄後把排序方向擠到意外的第二列。
  - 1100px 以下切換三欄並讓搜尋跨列；600px 以下改單欄。
  - 進階篩選的 `<summary>` 增加最小觸控高度、hover、focus-visible、open 狀態；仍使用原生 `<details>`，不建立第二套展開狀態。
  - 桌面選取資訊面板加寬為 290–330px，封面可用寬度提高；820px 以下改上下堆疊，避免桌面雙欄擠壓曲目表格。
  - 保留原有真實 Artwork Adapter、ANN attribution、Catalog row selection frame 與 Skin scope selector，沒有用色塊替代封面。
- `tests/catalog-filter-layout.contract.test.cjs`
  - 新增桌面六欄、進階展開狀態、hover/focus、資訊面板寬度及 820px 堆疊 breakpoint 契約。
- `artifacts/batch163-regression/`
  - 保存 70 個 Node 測試檔的清單、分組及測試日誌。

## 驗證
- 受影響測試組：`node --test tests/catalog-filter-layout.contract.test.cjs tests/catalog-browser.integration.test.cjs tests/catalog-browser.test.cjs tests/ann-artwork-adapter.test.cjs tests/artwork-provider-factory.test.cjs tests/artwork-adapter.test.cjs tests/skin-theme-adapter.test.cjs tests/skin-theme-store.test.cjs tests/skin-theme-transfer.test.cjs tests/app-lifecycle.integration.test.cjs`：43/43 tests PASS。
- `node tools/check-architecture.cjs`：1044 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- `node --check src/ui/catalog-browser.js`、`node --check src/app.js`：PASS。
- `tests/` 下 70 個 `*.test.cjs` 均有成功執行證據。Group 01–07、09 分組通過；Group 08 的 8 檔合併命令在外層 120 秒限制中斷，因此將其中 8 個檔案逐檔執行，包含較慢的 `quiz-pool.test.cjs` 與 `server-auth-srs.integration.test.cjs`，均各自 exit 0。不要宣稱 group-08 合併命令通過。逐檔與分組日誌位於 `artifacts/batch163-regression/`。
- 真實 Chromium 桌面／平板／手機 viewport 視覺驗收仍未完成；Node／CSS contract 不等於實際截圖驗收。

## 尚未解決／阻塞
- ANN 真實 API／CORS／圖片載入尚未取得瀏覽器驗收證據。
- 真實 `.osk` 檔案相容性仍未驗收。
- IndexedDB 需在允許的非 opaque HTTP origin 下驗收；先前 localhost 導覽被環境政策阻擋，不重試相同無效路線。
- 正式 Song Select 仍是逐步分層替換，尚未完成播放 dock／選取狀態與完整 UI 的視覺驗收。

## 下一批建議（Batch164）
1. 檢查正式 Catalog 表格在 820px 以下的橫向捲動、焦點順序與詳情面板堆疊契約，盡量增加不依賴外部導覽的自動化驗證。
2. 追蹤現有自由播放 dock 與 Catalog selection 的責任邊界，決定如何顯示播放狀態而不建立第二個播放狀態 owner。
3. 逐步改善表格列密度與作品資訊視覺層級，保留 keyboard selection、pagination、personal library、watch status、familiarity、artwork attribution、Skin frame。
4. 只有在可用瀏覽器環境允許真實 viewport 時才做截圖驗收；否則清楚記錄阻塞並繼續其他可驗證工作。
