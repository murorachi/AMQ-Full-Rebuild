# AMQ 自架帳號與個人 SRS

## 產品決策（Batch107）

- **取消邀請制**：完成首次管理者初始化後，任何人都能自行建立一般帳號，不需要邀請碼。
- **雙登入方式**：Google OpenID Connect 與一般帳號／密碼註冊、登入並存。Google OAuth 未設定時，一般帳密功能仍可使用。
- **個人資料隔離**：每個 AMQ 使用者帳號有獨立的 AMQ、EMQ SRS 排程與 revision；使用者身分只從已驗證的 server session 取得，不能由 request body 指定。
- **不自動合併帳號**：Google `sub` 是 Google 登入的穩定識別碼。一般帳號與 Google 帳號不會依電子郵件自動合併；同一人若分別建立兩種帳號，會有兩份獨立 SRS。未實作明確的已登入帳號連結流程前，不應猜測身份或用 email 自動合併。
- **最小 Google 權限**：只要求 `openid profile`，不要求 Gmail／email 權限。伺服器不會收到使用者的 Google 密碼；Google 密碼只由 Google 官方登入頁處理。
- **首次管理者初始化仍保留**：新伺服器必須先用啟動器輸出的一次性 bootstrap token 建立第一位管理者，之後才開放一般帳號註冊。這不是邀請制，而是避免陌生人搶先建立資料庫第一個帳號並拿到管理者身分。

## Google OAuth 設定

Google 登入是選配功能。未設定以下環境變數時，Google 按鈕會隱藏，帳號密碼註冊／登入照常工作：

- `AMQ_GOOGLE_CLIENT_ID`
- `AMQ_GOOGLE_CLIENT_SECRET`
- `AMQ_GOOGLE_REDIRECT_URI`

在 Google Cloud Console 建立 OAuth 2.0 Web application client，將下列 callback 加入「Authorized redirect URIs」。本機開發例子（redirect URI 必須逐字相同）：

`http://localhost:8000/api/auth/google/callback`

在啟動伺服器的 PowerShell 視窗設定環境變數，然後從同一個視窗啟動：

```powershell
$env:AMQ_GOOGLE_CLIENT_ID = "你的 Client ID"
$env:AMQ_GOOGLE_CLIENT_SECRET = "你的 Client Secret"
$env:AMQ_GOOGLE_REDIRECT_URI = "http://localhost:8000/api/auth/google/callback"
node server/start.cjs
```

請勿把真實 Client Secret 寫入原始碼、公開 ZIP、截圖或版本控制。每位自行架設者都應在自己的 Google Cloud 專案建立自己的 OAuth client。正式對外部署必須使用 HTTPS callback、反向代理並設定 `AMQ_COOKIE_SECURE=1`；不要將明文 HTTP 直接暴露到公網。Google 對 redirect URI 有精確比對要求，公開站點必須使用其實際 HTTPS 網址。

## Google 驗證流程

- 使用 Authorization Code Flow，搭配 PKCE（S256）、一次性 `state`、`nonce` 及短效 HttpOnly `SameSite=Lax` state cookie。
- 伺服器端交換 authorization code；驗證 Google ID token 的 RS256 簽章、Google JWKS key、issuer、audience、expiry、issued-at 與 nonce。
- 只保存 Google `sub` 與使用者選擇公開的 profile name；不請求、不保存 email 或 Gmail 資料。
- `sub` 對應資料庫內的個人帳號。首次 Google 登入會建立一般使用者，不會自動授予管理者權限。Google-only 帳號沒有可用的一般密碼；使用者可在已登入狀態設定密碼，再解除 Google 連結。
- Google 登入流程使用外部 Google 服務；網路、OAuth 設定或 Google 服務不可用時，使用者仍可改用一般帳密登入（前提是已建立一般帳號）。

## 一般帳號規則

- 帳號：3–32 個英數字、底線或連字號。
- 密碼：8–128 個字元，使用 scrypt 雜湊，不以明文保存。
- 註冊在首次管理者初始化完成後開放，並有每 IP 註冊速率限制；登入也有失敗限流。
- session 使用 HttpOnly、SameSite cookie；SQLite 只保存隨機 token 的 SHA-256 雜湊與 12 小時到期時間，因此正常伺服器重啟不會使未過期 session 失效。登出會立即撤銷 session；過期 session 在被使用或建立新 session 時清理。

## SRS 同步行為

- 未登入：沿用本機單人 SRS。
- 登入：先載入該帳號的 AMQ／EMQ server schedules，才切換至遠端 storage bridge。
- 不會自動把沒有 user identity 的舊 localStorage 排程上傳至新帳號。
- 遠端 revision 衝突會停止後續寫入並要求明確重新載入。一般網路錯誤可按「重試未同步的 SRS 保存」；重試前會重新讀取 server revision，只有 revision 未變才重送本次登入工作階段內最新排程。未同步快照僅保留於記憶體，重新載入／關閉頁面前若未成功保存仍可能遺失；手動重新載入會捨棄尚未同步的工作階段變更。
- 登出後恢復本機 SRS，不會把伺服器排程複製回共用 localStorage。
- 離線佇列、多裝置合併與可靠 unload flush 尚未實作。

## API 摘要

| 方法 | 路徑 | 用途 |
|---|---|---|
| GET | `/api/setup/status` | 查詢是否需要首次管理者初始化 |
| POST | `/api/setup` | 使用 bootstrap token 建立第一位管理者 |
| GET | `/api/auth/google/status` | 查詢 Google OAuth 是否已設定 |
| GET | `/api/auth/google/start` | 開始 Google Authorization Code Flow |
| GET | `/api/auth/google/callback` | 驗證 Google 回呼並建立 session |
| POST | `/api/auth/register` | 開放一般帳號註冊（首次管理者設定後） |
| POST | `/api/auth/login` | 一般帳號登入 |
| POST | `/api/auth/logout` | 登出並清除 session |
| GET | `/api/auth/google/link` | 要求已登入使用者明確連結 Google；callback 必須沿用同一 session |
| POST | `/api/auth/google/unlink` | 解除目前帳號的 Google 連結；需保留一般密碼登入方式 |
| POST | `/api/auth/password` | 設定／更新目前帳號密碼；已有密碼時需提供目前密碼 |
| GET | `/api/auth/me` | 目前登入身分 |
| GET | `/api/admin/members` | 管理者查看成員基本資訊 |
| GET | `/api/srs/AMQ`、`/api/srs/EMQ` | 讀取目前使用者排程與 revision |
| PUT | `/api/srs/AMQ`、`/api/srs/EMQ` | 以 expectedRevision 寫入完整排程 |
| GET | `/api/multiplayer/rooms` | 列出可加入的 lobby rooms（需登入） |
| POST | `/api/multiplayer/rooms` | 建立 AMQ／EMQ／MIX 房間 |
| POST | `/api/multiplayer/rooms/:id/join` | 加入 lobby，命令需 requestId |
| GET | `/api/multiplayer/rooms/:id?sinceRevision=N` | 讀取成員專屬 snapshot，支援 revision polling |
| POST | `/api/multiplayer/rooms/:id/commands` | 提交 ready／start／answer／close 等命令；身份與評級由 server 決定 |

邀請碼 UI、建立邀請 API 與邀請制註冊已移除。為了避免破壞 Batch105/106 已有 SQLite 資料，舊 `invitations` table 不會自動刪除，但不再有活躍 API 或註冊流程使用它。

## 部署限制

- Node.js 22.5+（使用內建 `node:sqlite`；目前 Node 仍可能顯示 ExperimentalWarning）。
- 預設綁定 `127.0.0.1`。讓其他人使用前，必須自行配置可信任的網路邊界與 HTTPS；不要只把 host 改成 `0.0.0.0` 就直接公開。
- SQLite 資料庫位於 `runtime-data/amq.sqlite`（可用 `AMQ_DATA_DIR` 更改）。請定期備份並限制作業系統檔案權限。建議先停止伺服器，或使用本包的 SQLite snapshot 工具建立一致性備份：`node tools/backup-private-server.cjs <source.sqlite> <new-backup.sqlite>`；目的檔必須不存在，工具拒絕覆蓋，並檢查 integrity／foreign keys。使用 `node tools/verify-private-server-backup.cjs <backup.sqlite>` 可離線再次驗證。備份含帳號與個人 SRS，必須像密碼資料一樣保密。
- session token 只以 SHA-256 雜湊保存於 SQLite，12 小時到期並支援登出撤銷；伺服器重啟後未過期 session 仍有效。帳號、Google `sub` 關聯及 SRS 資料也保存在 SQLite。
- Google OAuth 是外部身份供應商依賴；一般帳密是本機伺服器管理的獨立登入方式。自行架設者可以不配置 Google OAuth。
- 本批自動測試使用 mock Google OAuth provider，沒有使用真實 Client ID／Secret 完成真實 Google 登入，也不等同瀏覽器 E2E 或公網安全驗收。


## 密碼長度政策（Batch108）
一般帳密註冊與首次管理者初始化的密碼長度為 8–128 個字元。伺服器使用 scrypt 儲存密碼雜湊，並保留登入失敗限制。HTML 的 minlength 只套用於新密碼表單，不套用於登入欄位，避免舊帳號因規則調整而無法登入。建議使用不重複、難以猜測的密碼；長度下限不代表任意八字元密碼都安全。


## 私人伺服器資料庫備份（Batch112）

```sh
node tools/backup-private-server.cjs runtime-data/amq.sqlite backups/amq-2026-10-28.sqlite
node tools/verify-private-server-backup.cjs backups/amq-2026-10-28.sqlite
```

- 使用 SQLite `VACUUM INTO` 建立一致性 snapshot，包含已提交的 WAL 內容，不是直接複製一個可能正在寫入的 `.sqlite` 檔案。
- 目的檔不得已存在；透過 exclusive/atomic 建立避免靜默覆蓋。
- 建立後驗證 `PRAGMA integrity_check`、`foreign_key_check` 與 `users`／`sessions`／`srs_schedules` 表，輸出 SHA-256 與表筆數。
- POSIX 系統將備份檔權限設為 `0600`；Windows 權限語義不同，請另外限制 NTFS ACL。
- 備份包含個人資料、帳號資料與有效 session token hash，應存放在可信任且受限的位置。此工具只建立／驗證備份，不會自動覆寫線上資料庫或執行還原。


## 明確連結與解除 Google 登入（Batch113）

- 只有已登入的 AMQ session 才能啟動 `/api/auth/google/link`。OAuth flow 綁定當前 user ID；callback 必須仍由同一帳號 session 完成，避免在流程中切換帳號。
- Google `sub` 已連結至其他 AMQ 帳號時拒絕操作；不使用 email，也不搬移／合併兩邊的 SRS。
- 一般帳密帳號可連結 Google，並可在解除前保留密碼登入。Google-only 帳號必須先在登入狀態設定一般密碼，才能解除 Google；現有密碼帳號更新密碼時需提供目前密碼。
- SQLite migration 新增 `password_enabled`。舊版已綁定 Google 的帳號在 migration 時標記為 Google-only，避免把隨機產生且使用者未知的密碼誤認為可登入密碼。
- API 與 mock OIDC HTTP tests 不代表真實 Google OAuth client／瀏覽器 callback 已驗收；真實 OAuth 仍需要自架者提供自己的 Client ID／Secret。


## Multiplayer HTTP transport（Batch115）

- 房間建立、加入、命令與 snapshot 都要求登入 session；玩家 ID 從 session user ID 取得，不採信 request body 的 actorId。非成員不能讀取房間 snapshot。
- 房間狀態與命令 requestId/fingerprint/result 保存在 SQLite；每個房間的命令串行化，重複 requestId 同 payload 可跨程序重啟重放，不同 payload 回 409。每房保留最近 5,000 筆命令結果。
- `round.start` 的 questionId／roundId／duration 由 server 產生；只使用 bundled AMQ／EMQ playable records 與 server-owned work-title evaluator。Client 傳入的 correctness／grade／latency 不作為評級依據。
- Server timer 會在 deadline 到期後關閉回合並保存 timeout assessment；snapshot 只回傳目前登入玩家自己的 timeout assessment。Active round snapshot 會遮蔽其他玩家的答案內容。
- 本批提供 authenticated HTTP API 與 polling，不是 WebSocket，不代表前端多人房間 UI、語音／音訊同步、多人 SRS 自動寫入或多節點水平擴展已完成。這些仍需後續接線與真實 multi-client 驗收。


## Remote SRS network retry（Batch116）

- 一般 transport error 後，最新序列化排程留在目前登入工作階段的 bridge memory；UI 提供明確的重試按鈕。
- 重試先 GET `/api/srs/:source`。若 server revision 等於最後確認 revision，才以該 expectedRevision 重送最新排程；若已改變，回報 conflict 並禁止 PUT。
- Revision conflict 不自動 merge／retry，使用者需確認後重新載入 server schedule。
- 此功能不使用 `localStorage` 保存 pending schedule，因此不會把不同帳號的排程放入共用 key；它也不是 durable offline queue。重新載入／關閉頁面前未成功保存的變更仍可能遺失。


## 唯讀資料庫完整性檢查（Batch137）

對既有資料庫執行檢查時使用：

```sh
node tools/inspect-private-server-database.cjs runtime-data/amq.sqlite
```

- 以 SQLite read-only 模式開啟既有檔案；不建立新資料庫、不執行 schema migration、不寫入資料。
- 執行 `PRAGMA integrity_check` 與 `PRAGMA foreign_key_check`。
- 報告使用者、session、SRS 排程、SRS assessment events、多人房間及多人命令的筆數（表存在時），並列出缺少的 optional history tables，避免把舊 schema 的核心完整性 PASS 誤認為所有新版功能表都存在。
- 輸出資料庫檔案大小與 SHA-256，方便備份前後核對。
- 這是結構與外鍵檢查，不會證明所有 JSON payload 的業務語義正確，也不會自動修復資料。


## 多人歷史保留量報告（Batch138）

```sh
node tools/report-multiplayer-retention.cjs runtime-data/amq.sqlite
```

- 以唯讀模式統計 active／closed／unknown-phase room 數量、room updated-at 範圍、command replay 記錄數與每房最大 command 數、SRS assessment event 數與時間範圍。
- 不輸出 room ID、玩家名稱、答案、request ID 或 fingerprint。
- 舊資料庫若沒有 multiplayer／SRS assessment history tables，會回報 tablePresent=false，而不是建立表或執行 migration。
- 這是觀測工具，不會清除或修復資料；unknownPhase 可能包含舊 schema、缺欄位或損壞的 state JSON，需另外調查。
