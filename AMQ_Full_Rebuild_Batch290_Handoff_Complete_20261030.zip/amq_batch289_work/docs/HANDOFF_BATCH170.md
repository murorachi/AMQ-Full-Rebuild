# Batch170 交接：Quiz Panel 執行期回滾與單人流程盤點

## 1. 工作副本與基準

- 交接 ZIP：`AMQ_Quiz_Familiarity_Batch169.zip`
- 解壓工作副本：`/mnt/data/amq_batch170_work/amq_batch153_work`
- 工作副本無 `.git` metadata；未初始化 Git，沒有 Git diff／commit 可報告。
- Candidate302 是文件指定的正式維護基準；Candidate382 Stage 0 是文件指定的 CSS 比較基準。兩份原始基準檔未包含在本次交接 ZIP 中，因此本批未做原檔 hash 比對，也未修改／覆蓋它們。
- `src/data/assets/data.js`、`src/data/assets/emq-data.js` 未修改。沒有複製出第二份專案。

## 2. Batch170 實作

### Quiz Panel failure injection

修改 `src/ui/quiz-panel.js`：

1. 新增 `settings.factories.createChineseTitleProvider` seam。未提供 seam 時仍使用 `AMQData.chineseTitleProvider.createChineseTitleProvider`。
2. 新增 `settings.factories.createQuizSession` seam。未提供 seam 時仍使用正式 `AMQEngine.quizSession.createQuizSession`。
3. 新增 `settings.addEventListener(element, event, handler)` seam。未提供時仍直接呼叫 DOM `addEventListener`。
4. DOM event wiring 拋錯時，會移除先前已成功註冊的 listeners、取消已建立的 app settings／personal library／history／blacklist subscriptions、dispose suggestion controllers、abort Chinese title work、dispose session，最後依反向取得順序 rollback owned resources。原始 wiring error 保留；cleanup error 附加於 `error.cleanupErrors`。
5. Quiz Session factory 拋錯時，會 dispose 此次 `audioServiceFactory` 新建立的 AudioService；清理錯誤不會覆蓋 session 建構原始錯誤。
6. `disposeSession()` 現在先清空 session 與 unsubscribe 參照，再分別嘗試 unsubscribe 與 session dispose，避免 unsubscribe 拋錯造成 session 留存。
7. Panel `dispose()` 改成逐項 best-effort 清理；每項都會嘗試，最後若有清理錯誤才丟出 `AggregateError`。重複呼叫仍回傳 `false`。

修改 `tests/quiz-panel.test.cjs`：

- 注入 DOM event wiring failure，確認原始錯誤物件相同、已取得的 provider dispose 恰好一次、history listener 清空，外部注入 store 未被 dispose。
- 注入 Quiz Session factory failure，確認 session 專用 AudioService dispose 恰好一次，沒有暴露半成品題池。
- 測試 harness 增加 `src/core/errors.js` 載入，讓失敗路徑使用正式錯誤正規化依賴。
- 更新 `tests/catalog-filter-layout.contract.test.cjs` 的 Provider rollback source-contract assertion，讓它同時識別注入 factory 與正式 factory 路徑；這是因新增正式 seam 導致舊 regex 契約過時，已在全量回歸中重新驗證。

## 3. 核心遊戲流程盤點

追蹤 `src/ui/quiz-panel.js`、`src/engine/quiz-session.js`、`src/engine/quiz-engine.js`、`src/engine/quiz-clock.js`、`src/audio/audio-service.js` 及既有 integration tests 後，本批沒有證據支持另寫一套狀態機。現有流程已接通：

- Panel 透過 runtime Catalog 取得可播放候選，依 AMQ／EMQ／MIX 建立 Session。
- Session 擁有單一 Engine、Clock、AudioService 與 no-repeat pool；音訊 `playing` 狀態啟動作答倒數。
- UI 已接線 start、play/resume、pause、submit、reveal、skip、next、end。
- Engine／Session 測試涵蓋答題、timeout、reveal、next／end、無效 phase transition 與 deadline race。
- Quiz Panel integration 涵蓋 AMQ／EMQ／MIX、all-target、mode switch、SRS on/off、學習紀錄與四級作品熟悉度規則。

因此 Batch170 沒有重寫 Quiz Engine，也沒有另建狀態來源。剩餘主要缺口是使用者要求最後集中執行的真實瀏覽器音訊／操作驗收，以及外部環境依賴。

## 4. 本批驗證證據

日誌位置：`artifacts/batch170-regression/`

- `group-01.log` 至 `group-09.log`：71 個 Node `*.test.cjs` **逐檔獨立執行**，分 9 組記錄，9/9 組 exit code 0；不是把檔名當作單一 Node 命令參數。
- `summary.json`：記錄工作副本、Node 版本、檔案清單、分組結果及未驗證項目。
- `architecture.log`：`node tools/check-architecture.cjs`，1,051 PASS／0 FAIL。
- `osk-panel.log`：`python tests/osk-import-panel.browser.test.py`，12/12 assertions PASS。
- `syntax.log`：160 個 JS/CJS 檔案 `node --check`，0 failures。

這些是本次在目前工作副本的自動化結果，不是歷史 Batch169 數字。OSK panel 是既有 browser-test harness 的 12 項 assertions，不等於已驗收真實 `.osk` 檔案。沒有完成真實瀏覽器播放／ANN API／CORS／HTTP-origin IndexedDB 驗收。

## 5. 已知限制／阻塞

- Candidate302 與 Candidate382 Stage 0 原始檔不在本交接包；基準身份來自既有文件指定，未做原始檔 hash 比對。
- 無 Git metadata；無法提供 Git diff／commit。
- 真實瀏覽器音訊播放、ANN API／CORS／圖片、真實 `.osk` 相容性、HTTP-origin IndexedDB save/reload/clear 與真實 viewport 視覺仍未驗收。
- 目前注入測試覆蓋 provider 建立後 wiring failure 與 session factory failure。完整涵蓋每一種訂閱來源本身拋錯的獨立 injection 仍可後續補，但不應因此阻塞核心主線；若要補，應用單一 subscription seam 避免散落測試專用抽象。

## 6. 下一批優先順序

1. 先讀 `docs/NEXT_SESSION_PROMPT.md`。
2. 以證據為準，檢查剩餘必要功能缺口；不要重新分析已覆蓋的 Engine／Session 基本流程。
3. 優先補真實瀏覽器無法驗收以外、可在 Node integration 確認的音訊 fallback／取消、mode switch stale result 與結果持久化缺口。
4. 集中準備最後的真實瀏覽器驗收清單：AMQ／EMQ／MIX 出題、音訊片段與起點、倒數／提交／答案揭曉、四級熟悉度、下一題／回合結束、切換模式、保存與重新載入。
5. 不再擴大低影響 lifecycle 重構；遇到實際阻塞記錄後繼續其他項目。
