# Batch284 Stable 參考差距：Multiplayer Lobby 與 Quiz

## Multiplayer Lobby
參考：`artifacts/osu-reference/osu-multiplayer-lobby.jpg`。目前 AMQ：`artifacts/batch284-multiplayer-quiz/multiplayer-panel-1920x1080.jpg`。

| 區域 | Stable 原圖特徵 | AMQ 現況 | 本批處理／剩餘差距 |
|---|---|---|---|
| 頂部 | 遊戲標題、結果數、遊戲模式 tabs 與右上音樂控制 | 房間標題、連線狀態、AMQ/EMQ/MIX tabs | 已壓縮高度；產品語義不同，不偽造全站房間總數或音樂狀態 |
| 篩選列 | 多個快速 filter、search、進行中 | search、進行中、更新大廳 | 已整合成緊湊一列；其他 filter 不在現有資料契約內 |
| 房間列 | 多行房間、作品曲目、玩家槽位／頭像 | server-backed room select | 空列表壓縮；需 server/API 提供可用摘要才能做真正視覺化房間列，不能注入 fixture 假裝正式房間 |
| 右側操作 | Stable 以房間內容為主 | 建立房間表單 | 保留 AMQ 必要的建立房間功能；尚未有 Quick Join 的明確 owner |
| 底部 | Back to Menu／New Game／Quick Join 與 chat | 加入代碼、建立房間 | chat、quick join 未有 API/handler owner，不造假；下一輪先查可行 owner |
| Skin | Stable skin 背景／元素 | 既有 role: tab、room-list、create-room、member-list | 本批保留現有 role；尚未做每個 OSK asset 的真圖 apply/reset screenshot gate |

## Quiz
參考：`artifacts/osu-reference/osu-intro-screen.jpg`。AMQ：`artifacts/batch284-multiplayer-quiz/quiz-panel-1920x1080.jpg`。

Stable intro 以中心品牌圓形、背景圖案與音訊控制形成單一焦點。AMQ Quiz 必須以真實題目、播放狀態、答案與回合控制為核心，不能照抄 intro 畫面或放假題目。此批只強化題目舞台、回答焦點與摘要層次，未做人工像素相似度驗收。

## 來源參考與邊界
- osu! source archive 是 lazer source；只用於了解 UI 元件／Skin lookup 等模式，Stable screenshot 才是視覺錨點。
- AMQ community scripts archive 的 autocomplete/dropdown scripts 顯示鍵盤導航、候選項目與提交需要一起驗收；腳本依賴舊 AMQ prototype，不直接注入新版。
