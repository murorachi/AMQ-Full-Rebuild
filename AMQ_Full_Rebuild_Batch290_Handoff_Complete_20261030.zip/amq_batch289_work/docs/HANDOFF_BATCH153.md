# AMQ Batch153 交接：Skin Adapter 正式 Catalog 接線

## 變更
- `src/skins/theme-adapter.js`：新增 target selector（預設 `#catalog-browser`）；背景、選曲框架與 accent 套用至正式 Catalog；reset 清除目標屬性；角色 overlay 仍為 body 裝飾。
- `src/styles.css`：Skin 背景、選取框與 focus accent 改為 Catalog scoped，不再套用全頁背景或全站所有選取按鈕。
- `tests/skin-theme-adapter.test.cjs`：新增 Catalog target scope／reset integration test。
- `tests/osk-import-panel.browser.test.py`：新增 Catalog fixture，檢查套用及 reset 的實際 target。

## 測試
- `node --test tests/skin-theme-adapter.test.cjs tests/skin-theme-store.test.cjs tests/skin-theme-transfer.test.cjs tests/osk-importer.test.cjs`：15/15 top-level tests PASS。
- `python tests/osk-import-panel.browser.test.py`：exit 0，12/12 assertions PASS。Python startup 有 artifact_tool warmup traceback 訊息，但 browser test 本身 exit 0。
- `node tools/check-architecture.cjs`：991 PASS／0 FAIL。
- 真實 HTTP origin IndexedDB 尚未驗收；獨立 Python subprocess 建立 localhost HTTP server 後，Chromium 導覽回報 `net::ERR_BLOCKED_BY_ADMINISTRATOR`；因此未能執行 IndexedDB save/reload/clear，不能視為驗收。
- 真實 `.osk` 尚未取得；人工 ZIP fixture 不能當真實相容性證據。
- 完整 Node suite 未全量重跑。

## 基準與環境
- `/mnt/data/amq_batch129_work` 原始副本不可寫，因此複製為 `/mnt/data/amq_batch153_work` 後修改；本批只改工作副本，原始副本保留不動。
- 工作副本沒有 `.git` metadata，未初始化 Git。
- Candidate302、Candidate382 Stage 0、AMQ／EMQ source assets 未修改。

## 下一步
1. 變更 JS 語法檢查已 PASS；重新跑 targeted tests 與 architecture check 後再封包。
2. 用獨立 Python subprocess + localhost HTTP origin 嘗試 IndexedDB save/reload/clear。
3. DNS 可用時下載真實 `.osk`；若不可用，留下錯誤證據並繼續其他不依賴項目。
4. 後續才擴展完整 osu!stable Song Select 視覺結構，不能把這批 scope integration 當成完整 UI 改版。


### Batch153 交付封包
- ZIP：`AMQ_Skin_Catalog_Integration_Batch153.zip`
- SHA-256：`b76c07b422427f5e04e1a3570f3b906e82f2c19159578d315b50fd851d9c9fd5`
- 封包項目：390；`ZipFile.testzip()`：`None`（未發現損壞項目）。
