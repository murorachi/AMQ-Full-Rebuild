# Batch255：13 個 Unsupported Skin Roles 語義審查

日期：2026-10-29

## 判定原則

Skin role 只有在「AMQ 語義相符、正式 DOM target 明確、CSS token consumer 明確、fallback/reset 不破壞原功能」四項都有證據時才能接線。本批未為了提高 wired 數字而新增錯誤映射。

| Role | 本批判定 | 語義／風險 | 解除條件 |
|---|---|---|---|
| `catalog.filter.background` | 可接線候選，但本批不直接套任意 OSK 圖 | 真實搜尋／篩選容器由 Catalog UI owner 管理；應接到專屬面板容器或已存在的共享 panel token，不能把整個 #catalog-browser 當篩選區。 | 下一步需確認搜尋列 DOM 邊界與專屬 CSS consumer，再補 apply/fallback/reset 測試。 |
| `catalog.song-artwork` | 維持 unsupported | 作品封面必須由 artworkAdapter／作品 metadata 解析到正確作品；OSK 素材不是作品封面。隨機套圖會產生錯誤資料語義。 | 需要建立作品封面元件明確的 image target 與可替換 fallback，且 skin mapping 不得覆蓋真實 artwork provider。 |
| `quiz.result.correct` | 維持 unsupported | 正確答案回饋是 QuizSession／答題狀態語義，不是 osu! ranking grade。 | 需要追蹤正式 answer outcome renderer，對 correct 狀態建立獨立視覺層與 aria-live regression。 |
| `app.home.ambient-effect` | 維持 unsupported／預設關閉 | 可選動畫需要 reduced-motion、可關閉設定與可控生命週期；目前不得只因有 OSK snow asset 就全頁加動畫。 | 待確認效果 owner、開關設定與 cleanup/reduced-motion 的完整契約。 |
| `app.navigation.options` | 待確認對應元件 | 需找出正式導航中的 options 控制是否存在，以及是否有 normal/hover/focus 狀態容器。 | 先完成 DOM owner／互動狀態確認，否則保持 unsupported。 |
| `settings.entry` | 維持 unsupported | 目前 Settings 是頁面／導航目的地，不等同 osu! 選項按鈕素材的語義。 | 只有在存在專用 settings-entry 元件且狀態可分離時才接線。 |
| `catalog.action.random` | 可接線候選，但本批不硬接 | 隨機選曲屬 Catalog 操作；需確認實際按鈕 selector、disabled/loading 狀態和事件 owner。 | 補明確 selector 與專屬 token，並用瀏覽器驗證按鈕仍觸發原有 random action。 |
| `catalog.difficulty-marker` | 維持 unsupported／hidden fallback | 目前曲庫資料的難度標記不一定與 osu! star rating 同義；不能將星級素材當作 AMQ 難度或熟悉度。 | 先定義 AMQ 難度來源與語義；沒有對應資料時保持 hidden。 |
| `quiz.result.incorrect` | 維持 unsupported | 答錯回饋是 AMQ 語義，不能跟正確回饋共用一個不分狀態的圖像映射。 | 需要正式錯誤結果 renderer 的 state-specific target 與無障礙回歸。 |
| `settings.slider` | 可接線候選 | 設定滑桿是原生 range input；外觀 token 必須保留原生 value、鍵盤、焦點和觸控命中區。 | 需先限定 range input selector，避免對全頁輸入欄位泛用圖片背景。 |
| `settings.dialog` | 待確認對話框 owner | 對話框是動態／條件式 UI；不能把整個 Settings 頁面當 dialog target，也不能破壞 focus trap／關閉行為。 | 先找出正式 dialog 元件與可見狀態測試，再接線。 |
| `results.grade` | 維持文字 fallback | AMQ 的結果評級規則尚未以產品契約確立；正確率、SRS 熟悉度與 osu! ranking grade 是不同指標。 | 需先定義 AMQ 結算評級計算規則，未定義前保留文字，不映射 osu! ranking 圖。 |
| `feedback.success` | 維持 unsupported／文字圖示 fallback | 成功提示可由多種動態 status/toast owner 產生，泛用 selector 可能污染不相關狀態。 | 需明確 toast/status component owner、類型區分與 aria-live 規則。 |

## 本批結論

- 13/13 角色已逐一作語義分級；本批沒有把不明語義角色強行標成 supported。
- 可接線候選：`catalog.filter.background`、`catalog.action.random`、`settings.slider`，但需先建立精確 DOM/CSS 邊界並驗證原功能；本批不以廣泛 selector 冒險修改正式 UI。
- 封面、答對／答錯、難度星級、結算評級、環境特效等角色有明確語義風險，維持 unsupported 或安全 fallback。
- 下一步轉向精確元件 owner：先補 Catalog filter panel 與 random action 的獨立 target，再補 route-aware 可見狀態矩陣；滑桿在確認正式 range selector 範圍後再接線。

## 明確不作為結案條件

不再要求 Candidate302／Candidate382；新版以自己的產品需求、實際 DOM、測試與使用者驗收為依據。HTTP-origin IndexedDB policy、live audio/catalog/artwork、Windows／實機仍是環境驗收項目，與舊版基準無關。
