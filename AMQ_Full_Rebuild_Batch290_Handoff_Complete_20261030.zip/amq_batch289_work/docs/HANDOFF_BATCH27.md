# Batch 27 交接：SRS UI 整合

## 已完成
- `src/ui/quiz-panel.js` 已接入 `src/learning/fsrs-scheduler.js` 與 `src/persistence/srs-store.js`。
- 支援 AMQ 歌曲加入／暫停／恢復 SRS、due-first 複習回合、Again／Hard／Good／Easy 評級、下一次間隔預覽、每日新卡與每次複習上限。
- 已加入 SRS 的計分題目必須成功保存評級後才能下一題；若保存失敗，可結束回合，未成功保存的卡片排程不變。SRS 回合使用既有 QuizSession，不複製 AudioService／timer／engine。
- SRS 目前只支援 AMQ，並用可播放 AMQ song IDs 過濾排程卡；EMQ 不會寫入 source-less legacy schedule。

## 驗證
- FSRS scheduler 6/6、SRS store 13/13、quiz session 11/11、quiz panel integration PASS。
- 完整 Node 回歸 PASS；架構檢查 385 passed／0 failed；source audit、mapper verifier、catalog benchmark、JS/CJS 語法檢查 PASS。
- 真實瀏覽器 E2E 未執行，仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。

## 下一步
1. Batch 28 已核對並接入 `aniBlacklistedSongs_v1`／`ani-blacklist-changed-v51`，一般 AMQ 抽題與 SRS queue 都會排除黑名單歌曲。詳見 `docs/HANDOFF_BATCH28.md`。
2. EMQ SRS 需要 source-aware schedule schema 與遷移策略。
3. 瀏覽器環境恢復後驗收真實音訊、跨頁 localStorage 與 SRS UI。
