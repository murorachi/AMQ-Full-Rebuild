# Batch109 交接：曲庫遠端更新發布與下載流程

日期：2026-10-28

## 目標

把 Batch108「先有可信任 bundle／manifest 才能一鍵更新」的前置工作推進到可執行狀態：提供發布產物產生器，並在 UI 接上安全下載、完整預檢、差異預覽及確認後原子套用。未自行決定或假造公共 hosting URL。

## 實作

- `tools/create-database-update-release.cjs` 以既有 `tools/create-database-update.cjs` 建立完整 AMQ＋EMQ JSON bundle，再產生 `latest.json`。Manifest 包含 semver-like release version、格式相容範圍、byte length、bundle SHA-256、payload checksum、來源作品／歌曲數。若版本 bundle 或 manifest 已存在，拒絕覆蓋。
- `src/data/database-update-config.js` 提供 `window.AMQ_DATABASE_UPDATE_MANIFEST_URL` 設定入口，預設空字串。可設定自家 HTTPS manifest URL，也能從 UI 輸入。
- `src/index.html` 新增 manifest URL 欄位與「檢查並下載更新」按鈕。
- `src/ui/database-update-panel.js` 使用不帶 cookie、no-store、拒絕 redirect 的 fetch；只接受 HTTPS（localhost HTTP 開發例外），bundle 必須是相對於 manifest 的同來源 URL。檢查版本／格式、100 MB 上限、byte length、bundle SHA-256、payload checksum，再交給既有完整預檢。通過後顯示差異，仍需使用者確認才套用。
- `docs/DATABASE_UPDATE_RELEASE_CONTRACT_BATCH109.md` 記錄發布流程及安全限制。

## 驗證

- `node --check src/ui/database-update-panel.js`：PASS。
- `node --check tools/create-database-update-release.cjs`：PASS。
- `node --test tests/database-update-panel.test.cjs tests/tooling.test.cjs`：11/11 subtests PASS（含 release manifest 產生／hash／拒絕覆蓋與遠端 mock fetch 流程）。
- 49/49 非-tooling test scripts：PASS（逐檔執行）。聚合 shell loop 在 49 個都通過後觸及總執行時間上限；tooling 與後續檢查分開執行，不將 timeout 算 PASS。
- `node --test tests/tooling.test.cjs`：10/10 PASS。
- `node --test tests/database-update-panel.test.cjs tests/tooling.test.cjs`：11/11 PASS，含 hash mismatch／非 HTTPS host 拒絕。
- `node tools/check-architecture.cjs`：779 passed／0 failed。
- `node --check`：`src/`、`tests/`、`tools/`、`server/` 共 115 個 JS／CJS 檔案全部 PASS。
- Source audit／mapper verification：PASS；AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；Catalog 55,660 records；跨來源 ID collision 0。
- 5-run benchmark：PASS（Node 記憶體內量測）。
- 以內建真實來源資產產生 release preview：bundle 13,279,913 bytes，SHA-256 `4ea2f07516e566ff513b8c2b868df9aa629dfb1becf64a3bf142068a6fefac82`，payload checksum `793eb471b2c99de1b52548837d43b8ddd063291819c27862dd1e40246cd5607a`；只在本機預覽，沒有發布。
- 最終封包：`AMQ_Full_Rebuild_Batch109_Handoff_20261028.zip`，ZIP CRC PASS；268 entries（含目錄），253 個檔案項目，其中 `MANIFEST.sha256` 有 252 個受管檔案條目。解壓驗證缺檔 0、額外檔 0、SHA-256 mismatch 0。ZIP SHA-256 以交付回報為準，不寫入 ZIP 內避免自我參照。

## 安全與限制

- SHA-256 是一致性檢查，不是發布者簽章；同一 hosting 同時被攻陷時，攻擊者可替換 manifest 與 bundle。公開發佈前應考慮 Ed25519 簽章與 app 內固定公鑰。
- 專案尚無核准的公共 HTTPS hosting／manifest URL。UI 遠端流程已實作，但公開預設一鍵更新仍待擁有者決定並部署發布位置。
- 真實瀏覽器、CORS、redirect、HTTPS hosting、IndexedDB quota／原子交易／reload 未驗收。Node mock-fetch 不等於瀏覽器 E2E。
- 不修改 `src/data/assets/data.js`、`src/data/assets/emq-data.js`；不覆蓋 Candidate302／Candidate382 Stage 0；沒有 `.git`，不初始化 Git。

## 下一步

1. 執行全量回歸及封包驗證。
2. 由專案擁有者選定可信任 HTTPS 發布位置；不得未授權推送／發布。
3. 實作 Ed25519 簽章驗證並測試錯誤簽章 fail-closed。
4. 在使用者可用瀏覽器實機驗收遠端下載、差異預覽、取消、確認、reload 及恢復內建曲庫。
