# Batch 22 交接：音源候選解析與 AudioService

## 已完成
- `src/data/audio-candidates.js` 依使用者提供參考 HTML 的靜態證據生成 AMQ／EMQ quiz 音訊候選。AMQ row[9] 依三個 mirror host 順序展開；EMQ `v` URL 對 Catbox selfhoststorage URL 先生成 `files.catbox.moe` mirror，再保留原 URL並去重。
- `src/data/source-mappers.js` 已將候選加入正規化記錄，`src/data/validate.js` 驗證候選結構及重複 URL。
- `src/audio/audio-service.js` 提供 ordered fallback、12 秒載入逾時、canplay／playing、media error、play rejection、NotAllowedError 手動恢復、AbortSignal、替代請求取消、stop／dispose。
- 測試：候選 5/5、AudioService 11/11、真實來源 runtime integration PASS。
- 全量來源候選統計：AMQ 37,939 首有候選／882 首無候選／113,817 URLs；EMQ 16,839 首有候選／20,085 URLs。

## 限制
- 候選字串符合參考 HTML 靜態規則不代表 URL 仍有效或可聽。瀏覽器 E2E 未通過。
- AudioService 尚未接入 quiz UI／engine；沒有宣稱猜歌播放已完整可用。
- Candidate302／Stage 0 相容性、MIX 規則及歷史／SRS 持久化仍未驗收。

## 下一步
1. 建立最小猜歌 UI，將 quiz engine 與 AudioService 透過單一狀態來源接線。
2. 媒體 `playing` 事件呼叫 `markAudioStarted()`，timer owner 呼叫 `timeout()`。
3. 只從當前模式、有音源候選、未重複的曲庫抽題；MIX 維持未配置。
4. 瀏覽器環境可用後做真實音訊與互動 E2E。
