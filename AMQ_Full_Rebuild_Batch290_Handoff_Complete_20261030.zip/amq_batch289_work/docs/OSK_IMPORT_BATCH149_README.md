# AMQ `.osk` 匯入 Batch149 變更包

此 ZIP 是針對既有 AMQ 重建工作目錄的變更包，不是完整可獨立啟動的 AMQ 專案。請將檔案依 ZIP 內的相對路徑合併到專案副本，先備份同名檔案再覆蓋；不要覆蓋 Candidate302、Candidate382 Stage 0 或原始 AMQ／EMQ 資產。

## 內容
- `src/skins/osk-importer.js`：安全讀取 `.osk` ZIP 素材及 `skin.ini`。
- `src/ui/skin-import-panel.js`：正式 AMQ 匯入 UI 與工作階段預覽。
- `src/index.html`、`src/styles.css`、`src/app.js`：正式入口／樣式／生命週期接線。
- `tests/osk-importer.test.cjs`：6 項 importer 測試。
- `tests/osk-import-panel.browser.test.py`：Chromium file input 整合測試。
- `tests/tests.html`、`tools/check-architecture.cjs`：測試頁與載入順序檢查。
- `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH149.md`、`docs/NEXT_SESSION_PROMPT.md`：進度與交接。

## 驗證
- `node tests/osk-importer.test.cjs`：6/6 PASS。
- `python tests/osk-import-panel.browser.test.py`：9/9 assertions PASS。
- `node --test tests/core.test.cjs tests/app-lifecycle.integration.test.cjs tests/osk-importer.test.cjs`：3 個 test suites PASS、0 FAIL。
- `node tools/check-architecture.cjs`：946 PASS、0 FAIL。
- 全量 `node --test tests/*.test.cjs` 曾超過 120 秒工具時間上限，未取得總結，尚未驗證。

## 重要限制
目前匯入素材只在當前分頁有效；IndexedDB 持久化、主題匯出／匯入與真實 `.osk` 檔案測試尚未完成。已找到 KaKKeY Skin 的公開 `.osk` 下載候選，但工作容器 DNS 無法下載二進位檔，沒有假裝它已被測試。
