# Batch195 交接：OSK 契約與 UI 優先級修正

## 摘要
使用者明確要求 AMQ 正式頁面應依 osu!stable OSK／Skin 的元件模板設計，匯入素材後要能找到每個元件的替換位置。不能只讀取 `.osk` 後讓使用者自行找圖塞入不合適的框架。

## 本批完成
- `docs/OSK_SKINNING_CATALOG_AND_AMQ_UI_CONTRACT_BATCH195.md`：解讀 stable Skin 的重要分類、用途、限制與 AMQ 對應策略。
- `docs/skin-contract/stable-asset-manifest.v1.json`：初始 18 個 stable interface asset 定義。
- `docs/skin-contract/amq-skin-role-manifest.v1.json`：初始 47 個 AMQ UI role，含頁面、候選 stable asset、fallback 與必需性。
- 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`。

## 關鍵調查結果
- `src/skins/osk-importer.js` 可讀 ZIP 與圖片，但只映射少量 stable 資產角色；`skin.ini` 只抽取 Name／Author／Version 與 ComboN 顏色。
- `src/ui/skin-import-panel.js` 和 `src/persistence/skin-theme-store.js` 只提供 `background`、`characterOverlay`、`selectionFrame` 三個人工 mapping roles。
- `characterOverlay` 候選靠檔名猜測，不能可靠識別任意 OSK 角色圖。
- 公開 `ppy/osu` 是 osu!lazer 原始碼，不是 osu!stable；stable 應以官方 Skinning Wiki 的元件規格為準，並以真實 `.osk`／stable 實機交叉驗證。
- OSK 是命名資產與 `skin.ini` 契約，不是網站 DOM/CSS layout。AMQ 必須建立 stable asset manifest + AMQ role manifest + extension slots + fallback。

## 驗證
- `stable-asset-manifest.v1.json` JSON parse PASS（18 entries）。
- `amq-skin-role-manifest.v1.json` JSON parse PASS（47 roles）。
- Manifest contract + OSK importer + theme store/adapter/transfer focused tests：24/24 PASS；Architecture Checker 1,109 PASS／0 FAIL；新測試 `node --check` PASS。證據位於 `artifacts/batch195-regression/`。
- 本批未修改 production JS/CSS，未執行全量 Node tests；沒有宣稱 UI 或真實 OSK 驗收通過。

## 阻塞／未完成
- Stable manifest 是初始子集，不是完整官方元素目錄。
- Manifest 尚未接入 importer、theme store、runtime 或正式頁面。
- 真實 `.osk` 與真實瀏覽器驗收仍未完成。
- 正式 UI 尚未重建；本批只完成規格與映射基礎。

## 下一批
依 `docs/NEXT_SESSION_PROMPT.md` Batch196：擴充並驗證 manifest、建立 schema tests、擴充 importer 與保留原始設定、遷移 theme store，再開始 Mapping Studio 與正式 UI 接線。
