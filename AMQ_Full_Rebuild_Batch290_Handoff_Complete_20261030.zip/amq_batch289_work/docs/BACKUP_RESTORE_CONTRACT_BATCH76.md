# Backup / Restore Contract (Batch 76)

## Scope and status

This batch adds a persistence API, not a backup/restore UI. The browser module is loaded by `src/index.html` and exposed as `window.AMQPersistence.backupRestore`. No user data is written until `restoreBackup()` has completed full preflight validation.

## Envelope

```json
{
  "format": "amq-learning-tool-backup",
  "formatVersion": 1,
  "createdAt": "ISO-8601 timestamp",
  "checksum": "lowercase SHA-256 hex",
  "payload": {
    "schemaVersion": 1,
    "values": { "knownStorageKey": "raw JSON string or null" }
  }
}
```

The checksum is SHA-256 over a stable-key-ordered serialization of `payload`. Raw storage strings are preserved rather than normalized and rewritten, so supported legacy shapes can be round-tripped without migration side effects. The export covers 15 active/legacy data keys: app settings; AMQ/EMQ SRS; current history detail/summary and three read-only legacy history keys; AMQ legacy/current and EMQ familiarity; song/work blacklist; personal lists; and watch status. Recovery/quarantine keys are intentionally excluded: they may contain malformed fragments, and they are not active state.

## API

- `createBackupRestore({ storage?, crypto?, appSettings?, history?, now? })`
- `exportBackup()` returns `{ ok, backup }` or `{ ok:false, reason, key?, detail? }`.
- `preflight(backupOrJson)` verifies format/version, checksum, supported keys, raw value types, JSON syntax, and per-key schema before returning validated values. It performs no writes.
- `restoreBackup(backupOrJson)` runs preflight again, snapshots the old values of every included key, then applies the validated values. `null` removes that key. A version-1 envelope that omits keys is treated as a partial older export: omitted keys remain unchanged.
- `keys`, `format`, and `formatVersion` are read-only metadata.

## Validation and compatibility

- Settings use the existing `appSettingsStore.normalize`; older settings with missing optional `srsEnabled` remain valid.
- SRS payloads are validated structurally against the existing schema and AMQ/EMQ source identity; schedule values including automatic/manual assessment provenance are preserved byte-for-byte.
- Current quiz history summary uses the existing `quizHistoryStore.validateSummary`. Detail and legacy history values must be arrays of object rows; legacy summary keys accept map/array shapes.
- Familiarity maps validate levels 0–3; blacklist keys require primitive ID arrays; custom lists accept the legacy array or versioned `{lists:[...]}` shape; watch status validates the known status vocabulary.
- Unsupported keys, malformed JSON, invalid per-key shapes, checksum mismatch, or unsupported envelope/payload versions fail before writes.

## Atomicity boundary

`localStorage` has no multi-key transaction. Restore therefore snapshots all target keys and rolls back changed keys if a write/removal throws. The result explicitly reports `rolledBack` and any `rollbackErrors`; if the browser also refuses rollback writes (for example, persistent quota failure), complete rollback cannot be guaranteed and must not be described as atomic success.

## Known limitations

- No UI controls or downloadable file workflow are connected yet; callers must serialize the returned envelope and supply an envelope/JSON string to restore.
- This API validates known active data keys, not recovery/quarantine blobs or unknown application-specific keys.
- Browser storage quota/security behavior and real multi-tab storage events have not been verified in a real browser in this environment.
- The checksum detects accidental/tampered payload changes but is not a digital signature or proof of who created the file. Dedicated tests cover legacy settings without `srsEnabled`, the old custom-list array shape, AMQ/EMQ schedule source identity and assessment provenance, tampered/corrupt imports, recoverable rollback, and persistent rollback failure reporting. Tests also verify partial v1 backups leave omitted keys unchanged and unknown `formatVersion` values (including 0, for which no historical envelope contract exists) are rejected rather than guessed. A full UI/download workflow remains a follow-up.


## Batch 188 extension

`amqSongTagsV1` is now an explicitly supported backup key. Preflight validates tag definitions and source-aware song assignments through `AMQPersistence.songTagsStore.normalizePayload`; invalid tag data is rejected before any restore writes. Older version-1 backups that omit the key remain valid and do not delete the user's current tags.
