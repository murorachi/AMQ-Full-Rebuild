# Batch 78 Handoff：備份／還原非同步選檔競態防護

## 基準與環境
- 工作副本：`/mnt/data/amq_batch78_work/AMQ_Full_Rebuild_Batch74_Handoff`；交付 ZIP 內路徑仍為 `AMQ_Full_Rebuild_Batch74_Handoff/`。
- 工作副本無 `.git` metadata；未初始化 Git、未 commit／push。
- Candidate302 與 Candidate382 Stage 0 不在本包，未修改正式基準或曲庫來源資料。
- Node v22.16.0、npm 10.9.2，無 `package.json`。

## 本批修正
- `src/ui/backup-restore-panel.js` 新增選檔世代 `selectionVersion`，在選擇新檔與 dispose 時遞增。
- 檔案讀取與預檢只在請求世代仍有效時更新 UI。舊檔讀取／預檢即使晚到成功，也不能改寫目前檔名對應的狀態、預覽或還原按鈕。
- `tests/backup-restore-panel.test.cjs` 新增 pending preflight race regression：A 預檢尚未完成時改選 B，A 的結果返回後，還原仍 disabled 且 B 的狀態未被覆蓋。
- 未修改 persistence API／backup format／checksum／schema、資料源或 CSS。

## 驗證證據
- 全部 `tests/*.test.cjs`：30/30 scripts exit 0。
- `tests/backup-restore-panel.test.cjs`：7/7 PASS。
- `tests/backup-restore.test.cjs`：7/7 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：524 passed／0 failed。全套測試與架構檢查的第一次合併長命令逾時；架構檢查獨立重跑成功。
- Source audit PASS：AMQ 38,821、EMQ 16,839，重複 ID／懸空關聯／跨來源 ID 衝突 0。
- Mapper verification PASS：Catalog 55,660。
- 五次 Catalog benchmark PASS；本機 Node Catalog build 1,230.579 ms（觀察值）。
- `src/`、`tests/`、`tools/` 所有 JS/CJS syntax PASS。
- 真實瀏覽器 E2E 未執行；Node mock DOM 不代表瀏覽器驗收。已知 Chromium 導覽受政策阻擋，不重試相同方法。

## 修改檔案
- `src/ui/backup-restore-panel.js`
- `tests/backup-restore-panel.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH78.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `MANIFEST.sha256`

## 下一步
1. 在可允許頁面導覽的真實瀏覽器驗收下載、選檔、預檢、確認還原及 reload 後 Store 一致性。
2. 驗證真實 storage quota／security 錯誤與 rollback，以及跨分頁 storage event。
3. 若瀏覽器仍被阻擋，記錄新證據後繼續其他可測試的資料安全回歸，不重試相同阻塞路徑。
