# Batch 50 交接：參考檔證據與個人清單持久化

日期：2026-10-27

## 本批目標與結果

使用者上傳 `/mnt/data/AMQ382(2).html`，本批唯讀核對後依靜態證據建立自訂作品清單與看番狀態 persistence 模組。參考檔未被修改，也沒有複製進交付包。

- 參考檔：1,611,096 bytes，SHA-256 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`。
- 實際版本線索：`data-amq-candidate="381"`，title 顯示 Candidate381。不得稱為 Candidate382 Stage 0，不得宣稱 Candidate302 相容。
- 自訂清單 key：`aniCustomPracticeListsV1`；recovery key：`aniCustomPracticeListsRecoveryV825`。
- 看番狀態 key：`aniAnimeWatch_v1`；狀態：`current`、`completed`、`paused`、`dropped`、`planning`、`repeating`；`none` 會刪除記錄。
- `aniFavorites_v1` 只有讀取／備份線索，無法證實其 ID 是作品或歌曲，本批不實作收藏寫入。
- 舊 Song Select 靜態鍵盤行為已記錄：非 input／textarea／select／button／contenteditable 焦點時，ArrowUp／ArrowDown 移動目前歌曲列；Enter 呼叫 canonical choose-song owner；方向下可嘗試載入 tracklist 下一批。新版沒有同等播放 owner，尚未接線。

## 實作與修改檔案

- 新增 `src/persistence/personal-library-store.js`：
  - 自訂清單讀取／正規化／建立／改名／刪除／成員新增移除。
  - 看番狀態讀取／更新／移除。
  - storage read/write error、損壞 payload quarantine、寫入失敗不發布候選快照、跨分頁 storage event、subscribe/dispose。
- 新增 `tests/personal-library-store.test.cjs`：9/9 情境 PASS，另驗證舊資料重複清單名稱不會觸發整份資料隔離。
- 更新 `src/index.html`、`tests/tests.html`、`tools/check-architecture.cjs` 載入順序與測試頁 smoke test。
- 更新 `docs/PERSONAL_LIBRARY_CONTRACT_BATCH50.md`、`docs/PRODUCT_CORE_CONTRACT.md`、`docs/FUNCTION_INVENTORY.md`、`docs/ARCHITECTURE.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/FINAL_GAP_ASSESSMENT_BATCH49.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`。

## 驗證證據

- 所有 `tests/*.test.cjs`：25/25 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：459 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 songs、EMQ 16,839 songs，無重複 ID／dangling references／跨來源 ID collision。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660 records，AMQ audio candidates 37,939 songs、EMQ 16,839 songs。這不是實際播放測試。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；Node 記憶體內 benchmark，不是瀏覽器效能保證。
- `node --check` 對 `src/`、`tests/`、`tools/` 全部 JS/CJS：PASS。
- 真實瀏覽器未執行；既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 仍是 BLOCKED，不重試同一方式。

完整測試日誌與機器可讀報告位於 `/mnt/data/amq_batch50_logs/`（`node_test_scripts.log`、`tooling_tests.log`、`architecture_check.log`、`source_audit.json`、`mapper_verification.json`、`catalog_benchmark.json`、`summary.txt`）。

## 尚未完成／風險

1. 新版 UI 尚未連接個人清單 CRUD／看番狀態操作；store 存在不代表產品功能完成。
2. 收藏 ID 身份不明，保持不寫入。
3. 新版曲庫鍵盤選取／Enter 播放尚未實作；先建立唯一 selection owner，且不可在沒有 playback owner 時假稱播放成功。
4. Candidate382 Stage 0／Candidate302 相容性、真實瀏覽器、真實音訊可聽性與乾淨 Windows 啟動仍未驗收。
5. 工作副本無 `.git` metadata；沒有初始化 Git、commit 或 push。
6. `src/data/assets/data.js`、`src/data/assets/emq-data.js` 來源雜湊不變。

## Batch 51 直接執行

1. 讀取本 handoff、`docs/PERSONAL_LIBRARY_CONTRACT_BATCH50.md`、最新 `docs/WORK_STATUS.md` 與主清單。
2. 把 store 接到最小可操作 UI：清單建立／改名／刪除、作品成員新增／移除、看番狀態修改。清單刪除不可刪作品與學習資料；清理指向被刪清單的新版 quiz settings IDs。
3. 為新版 catalog row 建立單一鍵盤選取 owner；方向鍵改變選取，Enter 僅呼叫存在的 canonical action。沒有 playback owner 時只選取，不假稱播放。排除輸入與控制元件焦點，避免 click／keydown 重複觸發。
4. 收藏保持未實作，除非找到明確 ID 身份證據；不得宣稱 Candidate382 Stage 0／Candidate302 相容。
5. 新增 fake-DOM／VM integration tests，執行完整回歸、architecture、source audit、mapper、benchmark、syntax、manifest／ZIP 驗證。
