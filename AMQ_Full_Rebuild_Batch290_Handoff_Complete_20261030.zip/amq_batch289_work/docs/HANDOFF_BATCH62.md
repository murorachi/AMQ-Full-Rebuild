# AMQ Batch 62 交接：App mount 初始化失敗回滾

日期：2026-10-27

## 發現與影響

`src/app.js` 的 `mount()` 會依序建立 stores、註冊模式按鈕 listener、runtime、Catalog Browser、Quiz Panel 與 state subscription。如果中途（例如 `CatalogBrowser.mount()`）拋錯，原實作不會 dispose 已註冊的 lifecycle scope；`scope` 留在非 disposed 狀態，後續呼叫 `mount()` 會直接 return，造成半初始化狀態、listener／store 洩漏且無法重試。

## 實作

- `src/app.js`：將初始化放入 `try/catch`。失敗時呼叫 `scope.dispose()` 清理已登記資源，重設 `scope` 與模組參照，保留原始例外向外拋出；若 cleanup 本身回報錯誤，附加至原錯誤的 `cleanupErrors` 欄位，不覆蓋原始失敗。
- `tests/app-lifecycle.integration.test.cjs`：新增兩項 VM/fake DOM integration。
  - 正常 mount → dispose → remount → dispose：mode click handler 不重複，舊 runtime/store/browser/panel 有釋放。
  - Catalog Browser mount 第一次拋錯：舊實作重現 3 個 listener 殘留；修正後 listener/runtime/store 全部回滾，第二次 mount 成功。
- `docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`：記錄 rollback、重試與未註冊資源責任。

## 回歸證據

- 修改前：`node tests/app-lifecycle.integration.test.cjs` 的第二案例失敗，3 個 mode listener 殘留。
- 修改後：`node tests/app-lifecycle.integration.test.cjs` 2/2 PASS。
- 全部 `tests/*.test.cjs`：26/26 scripts exit 0。
- `node tests/data-pipeline.integration.test.cjs`：20/20 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：466 passed，0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839，duplicate IDs／dangling refs／cross-source collisions 皆為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，Catalog 55,660 筆。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，僅為 Node 記憶體內量測。
- `node --check`：64 個 JS/CJS 檔案 PASS。
- 日誌位於 `/mnt/data/amq_batch62_logs/`。

## 基準保護

- `data.js` SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`。
- `emq-data.js` SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 無 `.git` metadata；未初始化 Git、未 commit／push。未修改正式基準、來源資料或 UI/CSS 視覺。

## 尚未驗收／阻塞

- 真實瀏覽器 mount／dispose／remount、響應式、鍵盤及跨分頁 storage。
- 真實音訊可聽性與乾淨 Windows 啟動。
- Candidate302／Candidate382 Stage 0 正式相容性；Candidate381 僅靜態參考，遵照指示不搜尋 Candidate302。
- `aniFavorites_v1` 身份及 source-less legacy IDs 來源未知，不做猜測式遷移。
- VM/fake DOM integration 不是瀏覽器 E2E；不得將其宣稱為產品驗收。

## 下一批 Batch 63

1. 讀取主清單與狀態，盤點剩餘可驗證 P0/P1；不要為了製造批次而重構穩定模組。
2. 如果沒有新瀏覽器／正式基準證據，明確分類真實驗收阻塞、未知資料身份與可延後 P2。
3. 評估核心階段的結案條件；核心必要項目若已完成，就停止核心範圍擴張，將 UI 大重構與最終驗收保留為下一階段。
4. 仍有具體缺口才實作並測試；更新唯一清單、handoff、manifest 與完整 ZIP。
