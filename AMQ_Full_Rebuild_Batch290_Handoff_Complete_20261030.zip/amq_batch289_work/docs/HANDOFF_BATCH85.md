# Handoff Batch 85 · 2026-10-27

## Delivered
- `src/persistence/playback-history-store.js`: standalone source-aware free-play history, 1,000 row cap, event-ID dedupe, newest-first query, clear, refresh, subscriptions, storage-event refresh, persistence failure projection.
- `src/learning/statistics-dashboard.js`: pure dashboard projection from quiz history, familiarity, SRS and playback snapshots. No second persisted counter or store.
- `src/persistence/backup-restore.js`: adds `amqLearningPlaybackHistoryV1` to existing v1 backup allowlist and preflight validation.
- `src/index.html`, `tests/tests.html`, `tools/check-architecture.cjs`: script wiring/order updated.
- Tests: playback history 5 scenarios; dashboard projection; backup/restore 9/9.
- Main checklist updated with AMQ-991–995 and AMQ-962/963 partial status.

## Verification
- `tests/*.test.cjs`: 37/37 scripts exit 0.
- `node --test tests/tooling.test.cjs`: 9/9 PASS.
- `node tools/check-architecture.cjs`: 614 passed / 0 failed.
- Source audit PASS: AMQ 38,821 songs / 9,516 works; EMQ 16,839 songs / 6,645 works; duplicate IDs, dangling references and cross-source collisions are zero.
- Mapper verification PASS, Catalog 55,660.
- Five-iteration catalog benchmark PASS; local Node Catalog build ~1,120.599 ms, observational only.
- Browser E2E not run. Do not infer localStorage quota, cross-tab event, audio playback or reload behavior from Node tests.

## Limits
- No free-play Dock exists yet; store is an API only and does not capture actual playback events.
- Dashboard is a pure projection only; no dashboard UI yet.
- Real browser route is known blocked by `ERR_BLOCKED_BY_ADMINISTRATOR`; do not retry the same route.
- Worktree has no `.git`; no branch or commit claims.
- Candidate302, Candidate382 Stage 0 and `src/data/assets/` were not modified.

## Next batch
1. Implement a minimal free-player Dock independently of QuizSession; ensure media state and lifecycle have one owner.
2. Call `playbackHistoryStore.recordPlayback()` only from explicit Dock playback events with a documented threshold; never log quiz audio as free play.
3. Connect `statisticsDashboard.buildDashboard()` to a minimal dashboard UI using existing stores; expose loading/read-failure instead of treating failures as zero.
4. Update docs/manifest and deliver a full ZIP after tests.
