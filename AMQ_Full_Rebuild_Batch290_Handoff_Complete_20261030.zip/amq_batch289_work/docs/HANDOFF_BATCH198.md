# Batch198 交接：正式選歌工作區與 Skin runtime 擴充

日期：2026-10-28

## 本批完成

- `src/ui/catalog-browser.js` 新增 `buildCatalogWorkspace(root)`，在正式 Catalog mount 時將既有 DOM 重新分組為左側篩選／管理欄、中間密集曲目列表、右側歌曲詳情三欄。這是真正重組 DOM，不是只用 CSS 把舊表單染黑。
- 原有 `catalog-query`、來源／類型／年份／熟悉度篩選、篩選預設、標籤 CRUD、批次選取、個人作品清單、`catalog-rows`、`catalog-selection-details`、分頁等 DOM IDs 保留；查詢與選取狀態仍由既有 controller／store 持有，未建立第二份狀態。
- 進階篩選保留為原生 disclosure；篩選預設、歌曲標籤、批次操作、個人作品清單移入四個管理 disclosure，降低主要選曲畫面的雜訊。
- AMQ／EMQ／MIX mode panel 由 `src/ui/app-shell.js` 加上穩定 ID `catalog-mode-selector`，並移入選歌側欄；不再獨佔一整行推擠曲目列表。
- 自由播放器正式啟動時預設收合；桌面顯示為固定底部精簡 dock，手機改為文件流內的精簡 dock 以免遮擋側欄／曲目；展開仍可使用既有 AudioService、佇列、seek、音量與播放模式。`createFreePlayerDock()` 測試建立時預設不收合，避免改變既有測試／注入契約；正式 `mount()` 預設收合，可由 options 覆寫。
- `src/skins/theme-adapter.js` runtime role 從 11 個擴展到 20 個，新增 Catalog 上下框架、作品詳情面板、模式選擇器／分頁、播放器播放／暫停／進度、猜歌答案輸入與設定 checkbox。`querySelectorAll` 支援一個角色套用多個目標（例如設定頁所有 checkbox）；reset 會清理所有命中目標。
- 新增 `getRoleSupport()`／`runtimeRoles`，可按目前 DOM 回報 role selector、target count 與支援狀態。
- `src/ui/skin-import-panel.js` 的 Mapping Studio 每個角色卡現在明示「可套用」或「尚未接入正式元件」，避免把可保存映射誤報為已套用。
- 新增／更新 Catalog layout contract tests、adapter CSS-consumer test 與 Chromium shell 測試；產生桌面、手機截圖。

## 驗證證據

- Focused Node tests：10/10 檔案通過；另有 `app-lifecycle.integration.test.cjs` 與 `app-artwork-lifecycle.integration.test.cjs` 各自通過：
  - `catalog-browser.integration.test.cjs`
  - `catalog-browser.test.cjs`
  - `catalog-filter-layout.contract.test.cjs`
  - `free-player-dock.test.cjs`
  - `free-player-visual-contract.test.cjs`
  - `skin-theme-adapter.test.cjs`
  - `skin-theme-store.test.cjs`
  - `skin-theme-transfer.test.cjs`
  - `skin-contract-manifest.test.cjs`
  - `osk-importer.test.cjs`
- 正式 HTML Chromium shell test：31/31 PASS，含桌面三欄、模式面板位置、DOM reparent、玩家收合／展開、手機單欄／無水平溢位、runtime role target 與無未捕捉例外。
- Architecture Checker：1,123 PASS／0 FAIL。
- `src/` 全部 JS／CJS `node --check` PASS。
- AMQ asset SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`，未變。
- EMQ asset SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，未變。
- 截圖：`artifacts/batch198-regression/catalog-desktop.png`、`catalog-viewport.png`、`catalog-mobile.png`、`catalog-desktop-full.png`。
- 測試 log：`artifacts/batch198-regression/focused/`、`app-shell.browser.log`（由執行輸出另存）及 `architecture.log`。

## 未完成／阻塞

- 完整 76-file Node regression 本批未能取得可信的全量完成結果：個別 loop 與 `node --test tests/*.test.cjs` runner 在執行環境觸及工具時間限制。不要宣稱全量通過；Batch197 的 76/76 是前一批基線證據。本批受影響的 10 個重點測試檔已各自通過。
- Chromium 測試使用 `set_content()` inline-assets，opaque origin 的 IndexedDB／真實曲庫載入仍顯示 `DATA_SOURCE_READ_FAILED`。這不是正式 HTTP-origin 的持久化驗收，也無法驗證真實曲庫的封面與可聽音訊。
- 真實 `.osk`／使用者素材仍未驗收；runtime role 支援是 selector 存在且 CSS 有消費 token，不等於每一種 OSK 圖片比例在實際素材下都美觀。
- 沒有 `.git`，未初始化；Candidate302 與 Candidate382 Stage 0 原始基準檔仍缺席，沒有覆蓋 AMQ／EMQ 資產。
- 固定底部 dock 目前在桌面與手機可見且收合；展開時仍會佔用／覆蓋較多視窗空間，下一批應驗證捲動與焦點恢復行為。

## 下一批 Batch199

1. 在不猜測基準的前提下，嘗試可用的 HTTP-origin browser 驗收；若環境封鎖 localhost，保留阻塞證據並繼續可獨立完成的 UI 工作。
2. 加強 Catalog 真實資料狀態、作品封面缺失／載入／來源歸屬視覺，確認無資料、載入失敗與正常列表狀態都清楚；不得用原型假封面冒充真實曲庫。
3. 完成曲目選取詳情與列表鍵盤流程，確保方向鍵／Enter／checkbox 不重複觸發，並確認右側詳情在不同 viewport 不遮擋主要列表。
4. 對 Mapping Studio 做 role 支援狀態與實際套用／reset／重載的瀏覽器測試；優先接入剩餘有明確 DOM 目標的角色，不得把 unsupported 標為 supported。
5. 檢查自由播放器固定 dock 的展開、收合、視窗捲動、頁面切換與鍵盤焦點；維持單一 AudioService owner。
6. 更新同一份 `WORK_STATUS.md`、`MASTER_CHECKLIST.md`、`AI_START_HERE.md`、`README_FIRST.md` 與交接提示詞。
