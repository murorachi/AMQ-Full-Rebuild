# Batch271 Handoff：osu! 官方原始碼研究與 Stable 忠實重建規格

## 本批完成
- 確認 `/mnt/data/osu-master.zip` 存在且可讀，6,270 個項目，SHA-256 `973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`。
- 定向閱讀 MainMenu、MainMenuButton、SongSelect、Carousel、SkinManager、DefaultLegacySkin、LegacySkin、LegacySkinDecoder、ModSelectOverlay。
- 建立 `docs/OSU_SOURCE_RESEARCH_BATCH271.md`，記錄可驗證的檔案路徑、技術發現和限制。
- 建立 `docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`，定義五張 Stable 參考圖的構圖、分層、狀態、OSK mapping、測試與視覺驗收。
- 更新持續工作清單、工作狀態、traceability、gap register、next prompt、AI_START_HERE、README_FIRST、AGENTS。

## 核心發現
- 上傳 ZIP 主要是 osu!lazer／目前開源客戶端，不是可直接當成 Stable 原始 UI 的完整 source。
- `MainMenuButton.cs` 對按鈕背景／hover 層／icon 分層、shear 與動畫有實際實作；`SongSelect.cs` 提供 carousel、背景 dim/blur、選取與鍵盤處理；`SkinManager.cs` 與 Legacy Skin 類別提供資源查找與回退線索。
- `DefaultLegacySkin` 使用 `Skins/Legacy` resource namespace；本 ZIP 沒有可直接匯出為 Stable 預設 `.osk` 的完整資產包。尊重使用者已說明預設 Skin 無法匯出，不再索取該檔案。
- Stable 截圖負責視覺驗收，Lazer source 只用於理解元件與相容機制。不可將兩者混為一談。

## 未執行／未驗證
- 未執行 `dotnet test`、未編譯上游專案、未完整審計全部 UI/Skin/parser。
- 本批沒有修改 AMQ 業務程式碼，也沒有從上游複製程式碼／素材。
- AMQ Stable 視覺 gate 仍未通過。

## Batch272 下一步
依 `docs/NEXT_SESSION_PROMPT.md` 直接實作 Multiplayer Lobby 的正式 DOM/CSS 視覺切片。必須逐區對照 `artifacts/osu-reference/osu-multiplayer-lobby.jpg`，保留唯一 server/state owner，做 Skin component mapping、四尺寸截圖和差距表；同批盤點 Mod owner。不可只做文件或測試。


## 封裝與校驗
- 原始來源 ZIP 已放入 `references/osu-master.zip`，封裝內 SHA-256 與使用者上傳檔一致。
- `MANIFEST.sha256` 對專案文件、程式、測試、最新截圖、五張 Stable 參考圖與 source ZIP 逐檔校驗。
- 交付 ZIP：`AMQ_Full_Rebuild_Batch271_Osu_Source_Research_20261030.zip`；SHA-256 以同名 `.sha256` sidecar 為準。
- ZIP CRC、manifest 逐檔校驗、提示詞必需章節檢查通過。沒有執行應用程式測試或 `dotnet test`，因本批未修改應用程式程式碼。
