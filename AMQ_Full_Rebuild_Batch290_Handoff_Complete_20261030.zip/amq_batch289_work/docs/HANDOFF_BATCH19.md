# Batch 19 交接：曲庫瀏覽 UI

## 現況
- 已建立可操作的曲庫瀏覽介面：搜尋、來源／歌曲類型／作品類型篩選、排序、每頁筆數與分頁。
- `src/ui/catalog-browser.js` 的查詢控制器使用既有 `AMQData.queryIndex`；沒有重寫搜尋或排序規則。
- `src/app.js` 負責模式按鈕、共用 state 與 UI lifecycle；`AMQApp.configureRuntime(runtime)` 可注入已配置的 Runtime Bootstrap。
- 當前開工包未包含正式 `data.js`／`emq-data.js`，也沒有 Source Registry 實際設定，所以重新載入按鈕預設停用；沒有假曲庫。
- 參考 HTML `AMQ382(1).html` 不在本交付 ZIP 中，也不得被修改；保留既有工作副本中記錄的 hash/title 證據。不要搜尋 Candidate302。

## 已驗證
- `node tests/catalog-browser.test.cjs`：6/6 PASS。
- `node tests/core.test.cjs`：67/67 PASS。
- `node tests/data-pipeline.integration.test.cjs`：15/15 PASS。
- `node tests/query-index.test.cjs`：10/10 + 3/3 + 4/4 PASS。
- `node tests/source-mappers.test.cjs`：6/6 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：168 passed、0 failed。
- `node --check` 對 `src`、`tests`、`tools` 全部 JS/CJS 檔案通過。
- 真實瀏覽器 E2E 未執行，先前環境錯誤 `ERR_BLOCKED_BY_ADMINISTRATOR` 仍是已知阻塞。

## 下一批直接工作
1. 盤點正式 AMQ／EMQ 來源檔是否可由使用者提供的資料包取得，核對其 schema 與 `src/data/source-mappers.js`。
2. 以明確 source adapters 建立 `Source Registry`，配置 AMQ／EMQ 的 mode mapping；MIX 只能依已確認規則設定，不能自行推測。
3. 建立 runtime factory／初始化接線，將 runtime 傳入 `AMQApp.configureRuntime(runtime)`，確認重新載入按鈕狀態與載入流程。
4. 加入真實來源 smoke test：筆數、來源分布、重複 ID、dangling work references、代表性搜尋與分頁。
5. 真實來源不可得時，先完成 adapter 配置契約與可測試錯誤狀態，將資料接線標記為阻塞，不用 fixture 冒充正式資料。
6. 更新主清單、工作狀態、manifest 與 ZIP；不推送 GitHub、不覆蓋任何基準。
