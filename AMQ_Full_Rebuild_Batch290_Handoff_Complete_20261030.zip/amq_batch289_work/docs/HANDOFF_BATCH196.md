# Batch196 交接：OSK Mapping Studio 與 schema migration

## 本批完成
- 新增 `src/skins/skin-contract.js`，由文件 manifest 對應產生，`tests/skin-contract-manifest.test.cjs` 會比對 runtime 角色／素材清單，避免兩份規格靜默分歧。
- `src/ui/skin-import-panel.js` 改成按頁面分組的 Mapping Studio。每個角色顯示用途、stable 原生檔名候選、AMQ extension 標記、fallback、預覽與替換控制；支援還原建議映射。
- `src/skins/osk-importer.js` 支援 PNG/JPG/JPEG/WebP/GIF/BMP 及 WAV/MP3/OGG，並保留原始 `skin.ini` 文字與 section/key，包括未知設定。既有 ZIP 安全限制未放寬。
- `src/persistence/skin-theme-store.js` schema 2 支援 roleMappings，接受 schema 1 並遷移 legacy mappings。
- `src/skins/theme-transfer.js` 保留 roleMappings、raw skin.ini、sections，支援圖片／音效資產匯出與匯入。
- `src/index.html` 接入 runtime contract 與 Mapping Studio 結構，`src/styles.css` 新增對應工作區樣式。

## 驗證證據
- `node --test tests/skin-contract-manifest.test.cjs tests/skin-theme-store.test.cjs tests/skin-theme-transfer.test.cjs`：17/17 PASS。
- `node tests/osk-importer.test.cjs`：10/10 PASS。
- `python tests/osk-import-panel.browser.test.py`：12/12 browser assertions PASS（合成 OSK fixture，不是真實使用者 skin）。
- `node tools/check-architecture.cjs`：1,116 PASS／0 FAIL。
- 76/76 Node test files 逐檔 exit 0；`quiz-pool.test.cjs` 單獨跑完 10/10 assertions、約 18.3 秒。合併 `node --test tests/*.test.cjs` 因長時間分布抽樣觸及環境時間限制，逐檔結果保存在 `artifacts/batch196-regression/node-tests.tsv`。

## 重要限制
- Mapping Studio 能映射、預覽與保存 47 個角色，但現有 `theme-adapter.js` 真正套用到正式 DOM 的仍只有 legacy background／selectionFrame／characterOverlay；新角色不能宣稱已套用。
- stable manifest 仍是初步審查子集。沒有真實使用者 `.osk`，目前只用合成 fixture 驗證。
- 正式首頁大餅式導航、選歌頁正式外殼與逐頁功能接線尚未完成；舊白底頁面尚未被替換。
- 工作副本無 `.git`；Candidate302／Candidate382 Stage 0 原始基準缺席，未初始化 Git、未覆蓋曲庫或基準。

## Batch197 下一步
1. 調查 `quiz-pool.test.cjs` 長時間執行原因，避免全量回歸被單一測試拖住；分批執行其餘測試。
2. 將 theme adapter 升級為 role-aware runtime：先為已可映射的角色實作明確 selector/token，未支援角色顯示 unsupported 狀態，不能靜默假套用。
3. 參考 `prototype/ui-v2-osu-select-batch146/`，開始正式首頁大餅式主選單與選歌頁外殼，接入現有 Catalog，不把 mock prototype 當正式整合。
4. 更新頁面 role contract tests，保持 AudioService／Catalog／QuizSession／persistence 單一責任。
