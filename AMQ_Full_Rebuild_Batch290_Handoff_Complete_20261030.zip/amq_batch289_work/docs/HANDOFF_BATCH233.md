# Batch233 交接：首頁選單鍵盤狀態與結果頁 CTA 導航

日期：2026-10-29
工作副本：`/mnt/data/amq_batch232_work/project`
來源交付：`AMQ_Full_Rebuild_Batch232_Route_Scroll_Reset_UI_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch233_Home_Results_Navigation_UI_20261029.zip`

## 開工確認
- 已核對來源 ZIP SHA-256：`81ed52d904879aca9e32b6d9b170e7d173debc6e9b6d287f082903fcd6c75cbe`；ZIP CRC 檢查無錯誤。
- 已讀取 `AGENTS.md`、開工指南、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、Batch232 handoff 與 `docs/NEXT_SESSION_PROMPT.md`。
- 工作副本無 `.git`，未初始化；Candidate302／Candidate382 Stage 0 基準檔缺席，未猜測、覆蓋或升格；AMQ／EMQ 靜態資產維持唯讀。

## 實作
- `src/ui/app-shell.js`：離開首頁時收合主選單並同步 ARIA／文字／CSS 狀態。
- `src/ui/app-shell.js`：首頁主選單開啟時按 Escape 可關閉，焦點返回觸發按鈕。
- `tests/app-shell.browser.test.py`：正式 shell browser checks 擴充至 150 項，涵蓋 Escape、跨頁收合、結果空狀態 CTA、結果 CTA 導向 Quiz 並聚焦實際 setup heading、Alt+Left 返回首頁，以及 Settings 頁內跳轉不重置到頁首。
- `docs/UI_TRACEABILITY.md`：新增首頁、跨頁導航、結果頁與 Settings 頁內跳轉的 UI 行為追蹤契約。

## 驗證
- Chromium formal shell：150/150 PASS，桌面與 390px 手機；無水平溢位、無 uncaught browser exceptions。
- 結果 UI contract + UI CSS contract：7/7 PASS。
- OSK import browser harness：12/12 PASS。
- Architecture Checker：1,172 PASS／0 FAIL。
- 177 個 JavaScript/CJS 檔案 `node --check` PASS。
- `tests/app-shell.browser.test.py` `py_compile` PASS。
- AMQ／EMQ SHA-256 與既有資產基準一致，證據在 `artifacts/batch233-regression/asset-hashes.txt`。
- 81 個非-tooling Node test files 的本批全量重跑被執行環境 60 秒限制中斷；沒有將它標記為通過。聚焦測試 7/7 已通過。

## 未解／阻塞
- HTTP-origin IndexedDB save/reload：Chromium `ERR_BLOCKED_BY_ADMINISTRATOR`。
- 真實 `.osk`、live 曲庫／封面 provider／音訊與實機 UI 未驗收。
- Candidate302／Candidate382 Stage 0 基準檔缺席，未宣稱相容。
- UI 主線仍未結案。

## 下一批：Batch234
1. 依真實資料 owner 核對結果頁 empty／completed／unsaved 狀態與持久化語義；不要把 DOM fixture 當成資料持久化證據。
2. 檢查首頁、Catalog、Quiz、Results、Profile、Learning、Settings 的鍵盤焦點、窄螢幕、錯誤與空狀態，選擇下一個有證據的高影響缺口。
3. 嘗試解除或明確記錄 HTTP-origin IndexedDB 的環境政策阻塞；真實 `.osk`／曲庫／音訊與舊基準相容性依然如實標記。
4. 更新同一份工作狀態、主清單、traceability、handoff、證據、Manifest 與完整 ZIP。
