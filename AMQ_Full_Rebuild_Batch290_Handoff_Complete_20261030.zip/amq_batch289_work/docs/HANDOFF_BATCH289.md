# Batch289 Handoff：Quiz 結果視覺狀態與遊戲區比例

## 本批修改
- 以使用者提供的 AMQ gameplay 原圖重新對照正式 Quiz DOM/CSS。桌面 `.quiz-game-board` 現在有界寬並置中，中央舞台不再額外向右推；左側摘要、中央答題舞台、右側資訊區更接近原圖比例。背景仍不處理。
- `src/ui/quiz-panel.js` 由現有 `session.getState()` 將 phase/result/timer 狀態投影到 DOM attributes；答對、答錯、跳過、未播放跳過、逾時、揭曉及倒數狀態有不同視覺呈現。沒有改動 Quiz session owner、答案判定、計時、得分或題目流程。
- 答案揭曉區增加結果語義 aria-label；未有結果時仍隱藏。
- VNDB 角色欄尺寸調整，設定仍在 Settings，不加角色時不顯示假圖。
- 新增 `tests/quiz-result-visual-states-batch289.contract.test.cjs`，檢查結果映射、答案揭曉、角色欄尺寸與遊戲區禁止 AI 式 meta copy。

## 測試證據
- Focused Node command：31/31 PASS。
- `python tests/batch286-quiz-gameplay-layout.browser.py`：55/55 PASS（1920×1080、1440×900、1024×768、390×844）。
- 最新截圖與原圖對照：`artifacts/batch289-quiz-states/`。
- 這些 browser tests 驗證 production markup/CSS/route geometry，沒有啟動 live quiz session 或外部 provider；不可宣稱 live E2E。

## 未結案
- 人工視覺 gate 仍未通過；新版與原圖仍有差距，尤其背景／玩家 avatar／聊天室資料功能不同。背景按使用者要求暫不處理。
- 真實 VNDB 圖片、外部音訊、HTTP-origin IndexedDB、Windows／手機實機與全量 Node aggregate 未驗收。
- 交付前仍需跑 architecture checker、語法／AST、Manifest 與 ZIP clean-extract tests。

## 下一批建議
- UI 仍是 P0：依 `artifacts/osu-reference/osu-game-modifiers.jpg` 開始對照 Mods 原圖，先確認是否有 canonical registry/state/multiplier/audio owner；如無，先建立唯一規則 owner，再完成整個 Mods/Settings UI slice，不畫裝飾按鈕。
- 同時把 Quiz 的真實 session phase integration 測試擴成答對／答錯／skip／reveal／next transition matrix；不重做本批已通過的四尺寸 geometry。
- 每批先開原圖、檢查正式 DOM/CSS、產生並排圖、掃描玩家 UI 文案，禁止 AI 式註釋混入遊戲畫面。
- `tests/quiz-panel.test.cjs` 也已擴充真實 panel harness assertions：開始回合會把 `playing` phase 與 timer `running` 投影到 UI；正確答案會讓舞台／輸入列變成 `correct` 並更新答案揭曉 aria-label。重新執行的 focused Node suite 仍為 31/31 PASS。
