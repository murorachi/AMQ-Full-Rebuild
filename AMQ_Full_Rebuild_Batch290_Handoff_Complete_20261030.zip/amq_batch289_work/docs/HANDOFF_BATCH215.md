# Batch215 Handoff：學習中心歷史／複習清單與設定快速導覽

日期：2026-10-29

## 工作副本與保護
- 工作副本：`/mnt/data/amq_batch215_work/project`，來源是 Batch214 ZIP 的獨立解壓副本；原始 Batch214 ZIP 未修改。
- 無 `.git`，未初始化 Git。Candidate302／Candidate382 Stage 0 原始基準缺席，不宣稱相容。AMQ／EMQ 資產唯讀。

## 實作
- `src/index.html` 新增學習中心最近答題與到期複習列表，含標題、清單、空／錯誤狀態。
- `src/ui/statistics-dashboard-panel.js` 使用既有 Quiz History Store 最近 8 筆與既有 SRS `chooseSession()`／`snapshot()`，最多呈現 8 筆可複習的到期卡。新卡、暫停卡不列為 due。讀取失敗會清空列表並明示失敗。沒有新增持久化 store。
- 複習卡資料目前只提供 song ID，故 UI 顯示「歌曲記錄 #ID」，不猜測標題；下一批可評估共用 source-aware title/artwork resolver。
- `src/styles/ui-shell.css` 新增列表項目視覺、正誤狀態、響應式排版與設定導覽樣式。
- `src/ui/app-shell.js` 新增設定快速導覽五入口，點擊後捲動並把焦點交給真實區塊標題。
- `src/skins/theme-adapter.js` 接入 `learning.history.item`／`learning.review.item`，manifest／runtime contract 同步，roles 32→34，unsupported 15→13。
- 新增／更新 `tests/statistics-dashboard-panel.test.cjs`、`tests/skin-contract-manifest.test.cjs`、`tests/app-shell.browser.test.py`，測試產物在 `artifacts/batch215-regression/`。

## 驗證
- Node tests：77/77 個 `tests/*.test.cjs` 逐檔 exit 0；`quiz-pool.test.cjs` 單獨重跑 10/10。
- Chromium shell：86/86 PASS；無 uncaught browser exceptions，手機 390px 無水平溢位，學習列表單欄、設定快速導覽兩欄。
- Architecture Checker：1,137 PASS／0 FAIL。
- JS/CJS syntax：172/172 PASS；Python browser tests `py_compile` 2/2 PASS。
- Focused tests：statistics dashboard panel、skin manifest、theme adapter、Catalog integration、Quiz history／session／panel、Profile、Multiplayer panel、Workspace Preferences 均 PASS。
- AMQ／EMQ assets hash 未變，詳見 `artifacts/batch215-regression/asset-hashes.txt`。

## 阻塞與未驗收
- HTTP-origin test 本批嘗試一次後仍遭 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR`；斷言未執行，詳見 `artifacts/batch215-regression/http-origin-blocker.txt`。不要將其標為通過。
- 真實 `.osk`、外部曲庫／封面 API／音訊、Candidate302／Candidate382 Stage 0 相容性及完整實機驗收未完成。
- 全球排行榜仍無可信 backend owner，不生成 PP／排名／PB。
- 複習清單仍以 song ID 識別曲目，待可靠 source-aware resolver 可用時再改善。

## Batch216 下一步
1. 評估共用 source-aware title/artwork resolver；防止重複 provider/cache 與 stale image。
2. 結果頁、Catalog、多人頁繼續正式 UI／互動收尾。
3. HTTP-origin 只在環境改變後重跑。
4. 更新主清單、狀態、traceability、handoff、manifest、測試證據與 ZIP。
