# Batch 23 交接：猜歌 UI／Session 整合

## 已完成
- `src/engine/quiz-pool.js`：AMQ／EMQ 可播放題庫、來源過濾、去重與 no-repeat。MIX 阻擋。
- `src/engine/quiz-clock.js`：唯一倒數 owner，播放後開始、暫停排除時間、恢復及清理。
- `src/engine/quiz-session.js`：整合 evaluator、quiz engine、AudioService、clock 與題庫。
- `src/ui/quiz-panel.js`：主頁猜歌 UI 已接線，支援作品／歌曲／歌手／全部目標、題數、倒數、自動播放、部分答案、提交、播放／恢復、暫停、揭曉、跳過、下一題、結束回合。
- `src/app.js` 掛載面板，`questionStatus` 只作 engine phase 投影；模式切換會 dispose 舊 session。
- 測試：pool 5/5、clock 4/4、session 6/6、panel integration PASS、AudioService 11/11。真實資料 pool：AMQ 37,939、EMQ 16,839。

## 重要限制
- UI 已實作但真實瀏覽器尚未驗收，瀏覽器 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。不能宣稱真實 URL 可播放或音訊可聽。
- 熟悉度／答題歷史／SRS 尚未持久化。
- MIX 規則與 Candidate302／Stage 0 相容性未驗收。不要搜尋或假設 Candidate302 是目前可用基準。

## 下一步
1. 先核對舊版熟悉度／歷史資料的實際儲存規則，再建立持久化 adapter；不要猜 localStorage key。
2. 增加模式切換、dispose、連續開始／結束回合及音訊中途 fallback 的回歸測試。
3. 瀏覽器環境可用後，執行真實音訊與互動 E2E。
