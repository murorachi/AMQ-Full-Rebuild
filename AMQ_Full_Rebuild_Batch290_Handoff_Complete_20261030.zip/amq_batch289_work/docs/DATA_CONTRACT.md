# 曲庫資料契約草案（第一版）

> 狀態：新版內部契約草案。Library 中目前可取得的 `data.js`／`emq-data.js` 已完成結構稽核與有證據範圍的 mapping 驗證；但尚未證明是 Candidate302 配套檔，也未完成舊版行為或音訊驗收。

## 分層

1. **原始來源**：保留原始記錄與來源檔案，不直接交給 UI 或遊戲引擎使用。
2. **正規化記錄**：由單一 adapter 將已確認的來源欄位映射到內部模型；未知欄位不得猜測映射。
3. **驗證結果**：回報有效記錄、拒絕記錄及逐筆原因；不得靜默丟棄資料。
4. **查詢索引**：由正規化記錄衍生，可重建，不作為第二份權威資料。
5. **遊戲狀態**：題目進度、回答及計分與靜態曲庫分離。

## 標準歌曲記錄（待來源盤點確認）

| 欄位 | 暫定型別 | 規則 | 狀態 |
|---|---|---|---|
| `id` | string 或 number | 必須穩定、非空；來源 ID 原樣保留，不以標題代替 | 待確認 |
| `title` | string | 至少一個可顯示標題；不可用空字串冒充缺失資料 | 待確認 |
| `aliases` | string[] | 歌曲標題別名；正規化只處理比對副本，不覆寫來源文字 | EMQ `ta`／`n` 有 V82.x 靜態證據 |
| `artistAliases` | string[] | 歌手別名，不取代主歌手欄位 | EMQ `aa` 有 V82.x 靜態證據 |
| `animeAliases` | string[] | 作品別名／列級作品標題，不取代主作品標題欄位 | EMQ `wa`／`wt`／`wn` 有 V82.x 靜態證據 |
| `animeId` | string 或 number 或 null | 來源若有關聯 ID 才映射 | 待確認 |
| `animeTitle` | string 或 null | 顯示用關聯標題，不作唯一識別依據 | 已映射 AMQ／EMQ 來源作品標題 |
| `animeType` | string 或 null | 只映射來源明確提供的作品類型；未知保持 null | AMQ row[4] 有來源欄位；EMQ 目前 mapping 不提供 |
| `animeYear` | number 或 null | 只映射來源明確提供的作品年份；未知保持 null | AMQ row[5]、EMQ work `y` 已映射 |
| `difficulty` | number 或 null | 來源未提供時保持 null；套用難度篩選時未知值不視為符合 | AMQ row[6] 有來源欄位；EMQ 保持 null |
| `type` | string 或 null | OP/ED/插曲等分類值必須以真實來源盤點為準 | 待確認 |
| `audioCandidates` | AudioCandidate[] | 音源候選的格式與優先序需由舊版流程確認 | 待確認 |
| `source` | string | 記錄來源資料集及匯入版本 | 新版內部欄位建議 |

以上是內部目標草案，不是對舊版欄位的事實描述。不得在來源未到位前將其套用到整份曲庫。

## 資料品質規則

- 保留來源原始值；正規化產生新物件，不就地改寫來源。
- 缺欄位、`null`、空字串、未知值是不同狀態，不得一律轉成看似有效的預設值。
- 重複判定使用來源標籤 + ID 型別 + ID 值；同一來源內不得重複，跨來源相同 ID 合法。標題相同不能直接判定為同一首歌。
- 載入結果至少包含 `status`、`source`、`recordCount`、`validCount`、`rejectedCount` 與錯誤摘要。
- 部分資料失敗時必須明確呈現部分成功，不得回報完全成功。
- 資料載入與驗證不依賴 DOM；UI 僅呈現狀態與錯誤。
- 大型資料集不可在每次渲染時重複正規化；索引必須可由來源資料重建。

## 音源候選契約（待舊流程確認）

候選項目建議具備 `url`、`source`、`priority`；只有在實際來源盤點後才能確定欄位及排序規則。播放服務應回報 `started`、`failed`、`cancelled` 或 `timed-out` 等可區分狀態，不能把 `play()` Promise 成功等同於可聽見音訊。

## 解鎖條件

取得並唯讀檢查真實 `Data.js`、`EmqData.js` 或等效資料來源後，記錄檔案雜湊、頂層結構、記錄數、欄位分布、缺失值與重複 ID，再修訂此契約並建立以真實資料執行的驗證報告。


## 新版內部契約驗證器（2026-10-27 第三批）

`src/data/validate.js` 已實作純邏輯驗證，測試 fixture 是人工構造的最小案例，不是真實曲庫，也不能證明舊版欄位相容。驗證結果狀態為：

- `loaded`：所有輸入記錄均有效。
- `partial`：至少有一筆有效記錄，同時有拒絕記錄。
- `failed`：輸入不是陣列，或非空陣列中沒有任何有效記錄。
- `empty`：輸入是空陣列，與載入失敗分開表示。

`ok` 僅在 `loaded` 或 `empty` 時為 true；呼叫方仍應以 `status` 明確呈現空曲庫，不應把空陣列誤當成真實資料已成功載入。驗證器不對未知欄位作任何推斷，音源候選欄位暫不驗證，等待來源格式被證實後再新增契約。


## 第四批補充：資料載入結果狀態

| 狀態 | 語意 | 錯誤欄位 |
|---|---|---|
| `not-loaded` | 尚未開始或已重置 | `dataError = null` |
| `loading` | 已開始一輪載入 | `dataError = null` |
| `loaded` | 全部輸入記錄通過內部契約 | `dataError = null` |
| `partial` | 有有效記錄，但至少一筆被拒絕 | `DATA_PARTIAL` |
| `empty` | 輸入為空陣列，與載入失敗分開 | `dataError = null` |
| `failed` | 來源錯誤或所有輸入記錄皆無效 | 標準資料錯誤物件 |

狀態與計數器由 `src/data/load-state.js` 寫入共用 state。非同步來源必須保存 `begin()` 回傳的 generation token 並在 `accept()` 傳回；過期 token 的結果不會改寫狀態。這是新版內部狀態契約，尚未連接真實 `Data.js` / `EmqData.js`。


## 第五批補充：來源 Adapter 實作契約（2026-10-27）

`src/data/source-adapter.js` 已建立不綁定特定舊版 schema 的來源邊界：

- 建立時必須注入 `read({ signal })` 及 `mapRecord(raw, index)`，不提供隱含欄位猜測或 fallback mapping。
- `read` 必須回傳陣列；其他頂層結構以 `DATA_SOURCE_SHAPE_INVALID` 拒絕。
- `load({ signal })` 回傳 `{ records, sourceCount }`；Composite Adapter 可額外回傳 `{ sourceCounts }`。Repository 會將 Adapter Promise 與 abort signal 競速，因此取消不依賴注入 Adapter 是否合作；若外部 signal 在 `load()` 呼叫前已 aborted，Repository 不呼叫注入 Adapter，避免 adapter 邊界在自行檢查 signal 前產生副作用。隨後在內部記錄驗證前先驗證此 envelope：`records` 必須是陣列，`sourceCount` 必須是非負安全整數且等於映射後記錄數；若有 `sourceCounts`，其各來源數量、總和與每筆記錄的 `source` 標籤分布必須一致。違反時回報 `DATA_ADAPTER_RESULT_INVALID`，清除 Catalog 並拒絕發布。映射成功本身仍不代表資料契約有效。
- 錯誤碼：`DATA_SOURCE_TIMEOUT`、`DATA_LOAD_CANCELLED`、`DATA_SOURCE_READ_FAILED`、`DATA_SOURCE_SHAPE_INVALID`、`DATA_SOURCE_MAPPING_FAILED`。
- 預設逾時為 15,000 毫秒；可由建立 adapter 時的 `timeoutMs` 設定。設定為 `0` 代表不設內部逾時，但呼叫方仍可使用 `AbortSignal` 取消。
- timeout 與 cancellation 會 abort adapter 傳給 `read` 的內部 signal；來源實作若忽略 signal，adapter 仍會停止等待，但無法強制終止來源內部的非合作工作。

測試使用人工來源物件，僅驗證 adapter 的介面、錯誤及取消行為。取得真實資料前，不得將測試 mapper 當作 Candidate302 的實際欄位映射。


## 第五批補充：Repository 載入流程

`src/data/repository.js` 將 adapter 和載入狀態控制器組合成單一 `load()` 入口。呼叫流程為：

1. 建立新 generation 並將狀態設為 `loading`。
2. 呼叫 Adapter 讀取來源並使用明確注入的 mapping 產生內部記錄。
3. 將記錄及同一 generation 交給 `load-state` 控制器驗證。
4. 將讀取/映射/逾時錯誤交由控制器轉為標準資料錯誤。
5. 若新載入已取代舊載入，舊請求回傳 stale 結果，不得改寫新狀態。
6. 主動取消目前載入時，若該請求仍是當前 generation，狀態重設為 `not-loaded`，不把使用者取消誤報成來源故障。
7. `invalidate()` 用於 mode／source context 改變：先使舊 generation 失效並清除 Catalog／載入狀態；即使舊來源忽略 abort，遲到結果也不得發布。若新 generation 已開始，舊請求的 catch／finally 不得重設新狀態或清除新 active request。
8. 若 `load({ signal })` 收到呼叫前已 aborted 的 signal，Repository 必須在呼叫注入 Adapter 前結束取消，回傳 `cancelled: true`，將當前載入狀態重設為 `not-loaded`，且不得發布 Catalog。

這個 Repository 是新版架構的可測試組裝層。Batch 20 已由 `src/data/source-runtime.js` 注入目前可取得的 AMQ／EMQ Library 來源；此接線只主張與已盤點的 Candidate382 Stage I schema 證據相符，不宣稱 Candidate302 或 Candidate382 Stage 0 相容。


## 第六批補充：已取得來源檔案並完成結構稽核（2026-10-27）

`docs/SOURCE_DATA_AUDIT_20261027.md` 記錄了 Library 中可取得的 `data.js` 與 `emq-data.js` 的實際 SHA-256、大小、陣列結構、ID 唯一性、作品關聯及跨來源碰撞檢查。兩個檔案被 Candidate382 Stage I 參考 HTML 以同名 script 引用，但尚未證明是 Candidate302 的配套版本。

已觀察到 AMQ `anime` 每列 7 欄、`songs` 每列 12 欄；EMQ gzip JSON version 1 含 `songs` 與 `works`。Candidate382 Stage I 對欄位索引的讀取證據已記錄於來源稽核文件。這些證據可用來規劃來源 mapper，但不可直接宣稱 Candidate302 schema 相容。

新增 `tools/audit-source-data.cjs` 可重複執行來源結構與 ID 關聯稽核；新增 `tools/check-architecture.cjs` 可檢查模組載入順序、依賴方向、HTML 引用、重複 ID、語法與部分過期 API。實際結果及範圍限制見 `docs/WORK_STATUS.md`。


## 第七批補充：來源映射與驗證邊界（2026-10-27）

`src/data/source-mappers.js` 目前提供兩個明確映射入口：

- `createAMQSongMapper(animeRows)`：接受 7 欄 AMQ 作品列，建立作品索引；mapper 僅接受 12 欄歌曲列，讀取作品 ID、歌曲 ID、類型、順序、標題、歌手與難度。作品關聯不存在、ID 無效或列長不符時會拒絕該筆，不靜默補值。
- `createEMQSongMapper(worksRows)`：接受 EMQ 作品物件與歌曲物件，以 `i`／`w`／`t`／`a` 等目前資料結構欄位建立 ID、作品關聯、標題及歌手。必要欄位缺失或作品關聯不存在時拒絕該筆。

本批對目前 Library 來源全量執行 mapping，並將結果送進 `validateRecords()`：AMQ 38,821 筆全部通過；EMQ 16,839 筆全部通過。這只證明來源 mapping 結果符合新版內部契約。`sourceSchema` 欄位標記目前 schema 證據來源，並不代表 Candidate302／Candidate382 Stage 0 已相容。音訊欄位刻意不映射為 `audioCandidates`，等待 URL／檔名規則、優先順序與真實可播放性驗證。

## 第九批補充：查詢索引契約（2026-10-27）

`src/data/query-index.js` 以已驗證的內部歌曲記錄建立可重建查詢快照。

- 建立入口：`AMQData.queryIndex.createCatalog(records)`，只接受陣列、物件記錄、有效 `id` 與非空 `title`；同一來源內的複合身份重複時拒絕建立。完整欄位驗證仍由 `validateRecords()` 負責，catalog 的基本檢查不是驗證器替代品。
- 身份範圍：來源標籤、ID 型別及 ID 值共同決定唯一性。數字 `1` 與字串 `"1"` 不混為一談；不同 source 可以安全地擁有同值 ID。
- 搜尋欄位：歌曲 `title`、`artist`、`aliases`、`artistAliases`、`animeAliases`；作品 `animeTitle`、`animeAlternateTitle`（另支援通用 `alternateTitle`）。EMQ `ta`／`n`、`aa`、`wa`／`wt`／`wn` 的別名映射依 Candidate381 V82.x 的唯讀程式碼證據；不宣稱 Candidate302 schema 相容。
- Catalog 查詢索引篩選條件：`source`、`type`、`workKind`、`animeId`。同一欄位的陣列值採 OR，不同欄位採 AND。`animeId` 比對保留 ID 型別。猜歌出題的年份／作品類型／難度／看番狀態另由既有 app settings 與 QuizPanel eligibility 處理，不把 UI 設定誤稱為 query-index 已支援的查詢條件。
- 分頁：`offset` 預設 0，`limit` 預設 100；兩者都必須是整數，offset 不得小於 0，limit 範圍為 0–10000。回傳 `{ total, offset, limit, records }`，total 是分頁前總數，結果保留原輸入順序。
- 正規化：僅對索引副本套用 Unicode NFKC、大小寫折疊及空白合併；顯示文字不被改寫。採子字串搜尋，未提供語意、假名/羅馬字轉換或模糊搜尋。
- 索引與結果陣列為唯讀快照，歌曲物件及 `aliases`／`artistAliases`／`animeAliases` 亦會凍結。來源資料改變時必須重建索引；不在 catalog 內維護第二份可變曲庫狀態。


## 第十批補充：查詢效能基線

`tools/benchmark-catalog.cjs <data.js> <emq-data.js> [iterations=30]` 是唯讀量測工具，接受 5–500 次迭代。它使用目前來源 mapper 與內部 validator 建立 catalog，再量測標題、歌手、作品標題、來源／類型篩選、複合篩選與空查詢首頁。每個案例先暖身一次，回報 min/P50/P95/max/mean。

2026-10-27 當前執行環境以 55,660 筆記錄建置 catalog 約 719.234 ms；標題、歌手、作品標題子字串搜尋 P50 分別約 11.790、10.937、11.362 ms。完整資料分布與所有統計見 `docs/CATALOG_BENCHMARK_20261027.md`／`.json`。以上是 Node 記憶體內觀察值，不是硬性效能保證，也不代表瀏覽器或正式舊版相容性。


## 第十一批補充：明確的查詢排序契約

`queryIndex.search(criteria)` 現在可選擇 `sortBy` 與 `sortDirection`。允許欄位為 `title`、`artist`、`animeTitle`、`type`、`source`、`id`、`number`、`difficulty`；方向為 `asc` 或 `desc`。未指定 `sortBy` 時完全保留輸入順序，`sortDirection` 不可單獨指定。未知排序欄位或方向會明確拋出例外。

文字排序使用與查詢一致的 NFKC／大小寫／空白正規化後字串順序；`number` 與 `difficulty` 優先按數值比較，`id` 的兩個數值 ID 按數值比較。缺值固定排在有效值之後，不因升降冪而改變；同值項目維持原始輸入順序。排序發生於篩選之後、分頁之前。

這是新版查詢層的明確通用契約，不宣稱重現舊版 UI 的排序選項、預設排序或使用者設定；這些仍須等 Candidate302 與實際功能證據到位後對照。


## 第十二批補充：查詢分組與篩選統計契約（2026-10-27）

`queryIndex.groupBy(field, criteria)` 只接受 `source`、`type`、`workKind`、`animeId`、`animeTitle`、`artist`。`criteria` 僅接受 `query`、`source`、`type`、`workKind`、`animeId`；排序及分頁條件會被拒絕，避免產生只計算當頁的錯誤統計。

回傳 `{ total, groups }`。`total` 是符合篩選條件的完整記錄數，與 `search()` 的分頁無關。`groups` 每項包含 `{ value, label, count }`，依 count 降冪，再依正規化標籤排序。缺失的分組值會略過 group，但記錄仍計入 total，因此 groups 計數總和不保證在欄位缺值時等於 total。數字與字串值以型別區分。回傳陣列及項目皆唯讀。

在目前 Library 資料上，來源分組為 AMQ 38,821、EMQ 16,839，共 55,660 筆；作品類型分組為 `anime` 38,821、`visual_novel_game` 16,839。歌曲 type 的數值標籤分布與分組統計量測見 `docs/CATALOG_BENCHMARK_20261027.md`／`.json`。以上仍不構成 Candidate302 資料相容性或舊版 UI 驗收。


## 第十三批：多來源 Catalog 組裝與原子發布（2026-10-27）

- `sourceAdapter.createCompositeAdapter({ sources: [{ name, adapter }, ...] })` 將多個已明確映射的來源 adapter 以 fail-fast 方式組合。來源名稱必須唯一；每筆輸出記錄的 `source` 必須與其來源名稱一致；任何來源失敗都會中止整次組裝，不發布部分混合曲庫。回傳總 `sourceCount` 與唯讀 `sourceCounts`。
- `repository.createRepository()` 會先驗證 Adapter 結果 envelope，再將 `queryIndex.createCatalog()` 注入載入狀態控制器。來源計數與記錄標籤不一致時以 `DATA_ADAPTER_RESULT_INVALID` fail-closed；取消時回報 `DATA_LOAD_CANCELLED`，新載入取代舊載入時舊結果標記 stale 並不發布；資料驗證成功後先建立 Catalog，再更新成功狀態；Catalog 建立失敗時轉為 `DATA_CATALOG_BUILD_FAILED`，不發布已載入狀態。`repository.catalogSnapshot()` 只回傳當前 generation 的 Catalog；開始新載入、失敗或 reset 時會清除舊快照，避免 UI 在新資料尚未驗證時繼續使用舊索引。
- 部分成功狀態只將已驗證記錄放進 Catalog，載入狀態仍保留 `partial` 與 `DATA_PARTIAL`。空來源會建立空 Catalog，狀態維持 `empty`。
- 內部驗證器的重複 ID 規則已與 Catalog 一致：以 `source + ID 型別 + ID 值` 判斷；未提供 source 的記錄屬於同一個預設來源範圍。
- 此批驗證的是新版資料管線組裝契約，不證明 Candidate302 相容性、真實瀏覽器行為或音訊可播放性。


## 第十四批：來源選擇設定契約（2026-10-27）

`AMQData.sourceRegistry.createRegistry({ sources, modeSources })` 集中管理來源 adapter 與模式來源清單。`sources` 的每個值必須是具備 `load()` 的 adapter；`modeSources` 只接受 AMQ／EMQ／MIX key，每個已配置模式至少要有一個存在且不重複的來源名稱。未配置的模式不會自動 fallback。`createAdapterForMode(mode)` 回傳 Composite Adapter，讓 Repository 不需要自行判斷模式如何組裝資料。

目前只驗證這份設定契約可工作。測試 fixture 將 MIX 配置為 AMQ + EMQ，不能解讀為已驗收的舊版 MIX 遊戲規則；真實 runtime source mapping 仍待 Candidate302 及配套資料確認。


## 第十五批：Runtime Bootstrap 契約（2026-10-27）

`AMQData.runtimeBootstrap.createRuntimeBootstrap({ registry, repositoryFactory, stateStore, repositoryDependencies })` 建立單一 Repository。`loadCurrentMode()` 從 `stateStore.getState().mode` 讀取目前模式，並透過注入的 Source Registry 選取來源。Repository 將 mode 傳給 adapter 的 `load({ signal, mode })` 介面；既有單來源 adapter 可忽略 mode。

Bootstrap 會監聽共用 state 的 mode 變化並取消進行中的舊載入；它不會在模式改變後自動重載，避免擅自決定遊戲行為。`dispose()` 解除監聽並取消載入。測試已驗證模式切換會取消舊請求，但真實瀏覽器事件、UI 重置語意及 Candidate302 相容性仍未驗收。

## 第十七批：Lifecycle timer 取消與 dispose 邊界（2026-10-27）

`AMQCore.lifecycle.createScope()` 管理的 timeout／interval 除了清除 host timer，也必須在 callback 執行時檢查該資源是否仍有效，以及 scope 是否已 dispose。`clearTimeout()`／`clearInterval()` 無法保證撤回 host 已排入事件佇列的 callback，因此每個 timer registration 都維護自己的 active guard。個別 cancel 或 scope dispose 後，遲到 callback 不會執行使用者 handler。此契約由 Node fake-timer 回歸驗證，不等於真實瀏覽器整合驗收。

## 第十六批：Composite 取消語意（2026-10-27）

Composite Adapter 的來源可以是任何符合 `load({ signal, mode })` 的注入 adapter，但不得因來源忽略 `AbortSignal` 而延遲取消結果。外部 signal abort 時，Composite 必須立即以 `DATA_LOAD_CANCELLED` 結束自身 Promise、abort 傳入各子來源的 shared signal，且不發布延遲來源後續 resolve 的資料。它會原樣傳遞 `mode`，但不以此推論模式規則。

此契約已由非合作 fixture 驗證，並不代表真實網路、音訊或 Candidate302 資料來源已驗收。


## Batch 20：正式來源接線契約（2026-10-27）

- AMQ 原始資產：`src/data/assets/data.js`，SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`window.DB.anime` 9,516 筆、`window.DB.songs` 38,821 筆。
- EMQ 原始資產：`src/data/assets/emq-data.js`，SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`；gzip/Base64 解碼後 payload 版本 1，`works` 6,645 筆、`songs` 16,839 筆。
- `src/data/source-runtime.js` 只把歌曲欄位映射到已定義的內部契約，不將原始音源欄位推斷為 `audioCandidates`。EMQ 解壓使用 `atob`、`Blob`、`DecompressionStream('gzip')`、`Response`；若瀏覽器缺少這些 API，載入會回報明確錯誤。
- Batch 20 當時 AMQ 與 EMQ 各自單獨載入，MIX 回報 `DATA_MODE_UNCONFIGURED`。此歷史狀態已由 Batch 29 supersede：MIX 現在使用 AMQ + EMQ composite adapter，並按 2:1 source weighting 選題；舊版 AMQ-specific filter suppression 仍未移植。
- 真實資料回歸：`tests/source-runtime.integration.test.cjs` 驗證 AMQ 38,821 筆、EMQ 16,839 筆、模式切換與 MIX 阻擋；`tools/verify-source-mappers.cjs` 驗證 55,660 筆內部 mapping／Catalog。這些結果不代表 Candidate302 相容或音訊可播放。


## Batch 22：有來源證據的 quiz 音源候選（2026-10-27）

使用者提供參考 HTML 的 SHA-256 為 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`。其靜態程式碼可定位到 `audioHosts`（第 673 行）、`mediaFiles(s)`（第 696 行）、`startMediaCandidate()`／`advanceMediaFallback()`（第 700–701 行）及 EMQ `getAudioUrls(id)`（第 6,151 行）。這些行號只對此參考檔有效。

- AMQ quiz 只取來源歌曲列的第 9 欄（0-based `row[9]`）作音訊檔名；舊版會先取 basename，再依序嘗試 `nawdist.animemusicquiz.com`、`naedist.animemusicquiz.com`、`eudist.animemusicquiz.com`。第 10、11 欄在參考 HTML 中是影片音軌，不混入本批 audio-only quiz candidates。
- EMQ 讀取 `v` URL 陣列；若 URL 符合 `/selfhoststorage/catbox/<id>`，先加入 `https://files.catbox.moe/<id>`，再加入原 URL，最後按 URL 去重。
- `src/data/audio-candidates.js` 實作以上明確候選生成；`source-mappers.js` 將候選陣列加入標準歌曲記錄；`validate.js` 驗證候選物件、非空 URL/source、`kind: 'audio'` 與 URL 唯一性。
- 這只證明候選 URL 的構造及順序與參考 HTML 靜態程式碼相符，不代表 URL 仍有效、跨域政策允許、HTTP 回應成功或音訊實際可聽。音訊可播放性仍需瀏覽器測試。


## Batch 24：熟悉度持久化契約（2026-10-27）

舊版參考 HTML 靜態證據：第 403 行 `loadStatus()` 先讀 `aniCollection_v2`，若值為空才讀 `anisongFieldGuide_v1`；第 405 行 `save()` 寫回 `aniCollection_v2` 並派發 `ani-familiarity-updated-v51`；第 870–872 行 `__aniHistoryAPIv51` 提供 `getStatus`／`setStatus`。狀態值以 0–3 表示熟悉度，0 代表沒有明確標記，舊版在設為 0 時刪除該 ID 的 key。

- `src/persistence/familiarity-store.js` 以 `record.source` 和 `record.id` 為輸入，AMQ 讀寫既有 `aniCollection_v2`，並保留 `anisongFieldGuide_v1` 的讀取 fallback。AMQ 寫入後派發舊版事件 `ani-familiarity-updated-v51`。
- EMQ 的 ID 與 AMQ 數字 ID 有重疊風險，不能把 EMQ 熟悉度寫進相同 ID map。新版 EMQ 使用獨立 key `amqLearningFamiliarityV1` 與事件 `amq-learning-familiarity-updated-v1`，避免跨來源互相覆蓋。舊版共用 status map 中無法可靠判別來源的 EMQ 歷史值不會自動猜測／遷移。
- 只有 `anime`／`all` 目標產生非 null familiarity level 時才更新熟悉度；答題、超時及已播放後跳過會依引擎結果更新；手動揭曉與未播放跳過不更新。`keepHigher` 規則由 quiz engine 決定，store 只保存引擎回傳的 0–3 整數。
- 寫入失敗會回報 `persisted:false` 並回滾該次記憶體值，session 會提示未能持久化；不會假裝保存成功。
- 本批沒有寫入 `aniQuizHistory_v1`、`aniQuizHistorySummaryV1` 或 `aniQuizTargetSummaryV1`。這些歷史摘要有獨立去重／壓縮／修復規則，須另行完成 source-aware history adapter 後再接線。


## Batch 25：source-aware 答題歷史契約（2026-10-27）

新版歷史使用獨立 key，不覆寫舊版 `aniQuizHistory_v1`、`aniQuizHistorySummaryV1` 或 `aniQuizTargetSummaryV1`：

- 詳細紀錄：`amqLearningQuizHistoryV1`，保留最近 2,000 筆。
- 長期摘要：`amqLearningQuizHistorySummaryV1`，保存 total/correct/wrong、elapsed 統計、來源、目標、source-aware song key、UTC day 統計、最後一筆及最近 5,000 個 processed IDs。
- Recovery：`amqLearningQuizHistoryRecoveryV1`、`amqLearningQuizHistorySummaryRecoveryV1`。無法先保存損壞原始值時會阻止覆寫原 key。
- 來源與歌曲 key 使用 `AMQ:<songId>`／`EMQ:<songId>`，避免同數字 ID 的來源衝突。
- 普通目標每次計分結果寫一筆；`all` 目標拆成 anime/title/artist 三筆，各自保存正確性。已播放後的作答、超時、跳過會記錄；手動揭曉與未播放跳過不記錄。
- 詳細紀錄每次計分後立即寫入；摘要每累積 20 個目標紀錄或 30 秒寫入，並在 `pagehide`、頁面隱藏及 dispose 時 flush。
- 舊版歷史／摘要只讀，不自動合併進新摘要；UI 顯示舊版摘要或可用明細數量，避免把受 2,000 筆限制的明細誤稱完整累計。


## Batch 25：答題歷史與摘要持久化契約（2026-10-27）

- 舊版參考 HTML 的 `aniQuizHistory_v1`、`aniQuizHistorySummaryV1`、`aniQuizTargetSummaryV1` 為唯讀遷移／對照來源；新版不直接覆寫它們。
- 新版明細與摘要分別保存於 `amqLearningQuizHistoryV1`、`amqLearningQuizHistorySummaryV1`，source 使用 `AMQ`／`EMQ`，歌曲摘要 key 使用 source 與 song ID，避免跨來源 ID 碰撞。
- 新版 `all` 目標每題記錄作品、歌曲、歌手三個獨立結果；其他單一目標每題一筆。只有 engine 標記為 `scored:true` 的結果會寫入；revealed／unplayed skip 不寫。
- 明細最多 2,000 筆；摘要以最多 5,000 個已處理 ID 做有界去重，並分別維護來源、目標、歌曲、日期統計。摘要採每 20 筆或 30 秒批次保存，並在 pagehide／visibility hidden 時 flush。
- 新版 detail／summary 格式無效時先保存 recovery 副本；detail 無法安全隔離時封鎖寫入。摘要損壞會先 quarantine，再依新版 detail 重建。storage 失敗狀態會暴露給 UI，不宣稱永久保存成功。
- 參考依據是 `AMQ382(1).html` 的靜態程式線索；未經瀏覽器操作驗收，不宣稱與正式舊版所有摘要語義完全相容。


## Batch 26：SRS／FSRS 排程契約（2026-10-27）

- 參考 HTML 靜態模組使用 key `aniSrsScheduleV1`，recovery prefix `aniSrsScheduleRecoveryV1_`，演算法版本 `FSRS-6-default+song-learning-steps-v1`。預設 `dailyNew=30`、`batchSize=25`、`desiredRetention=0.9`、learning steps `[1,10]` 分鐘、hard step 5 分鐘、relearn 10 分鐘、easy graduating 4 天、max interval 36,500 天。
- 卡片狀態為 `new`／`learning`／`review`／`suspended`，評級 1–4 是使用者對回憶難度的評估，不能等同猜歌答案正誤或 familiarity level 0–3。
- `src/learning/fsrs-scheduler.js` 只實作計算與狀態轉移；`src/persistence/srs-store.js` 負責相容 schema、讀寫、recovery 與 due-first queue。
- 舊版 schedule 的 key 以 song ID 為主且卡片沒有 source 欄位，所以新版目前明確只允許 AMQ；EMQ 不會寫入同一裸 ID map。
- 損壞排程先保存 recovery 副本；副本寫入失敗時阻止原資料覆寫。Node 測試尚不等同真實瀏覽器驗收。


## Batch 27：FSRS／SRS UI 整合契約（2026-10-27）

參考 HTML 第 2576 行起使用 storage key `aniSrsScheduleV1`，schemaVersion 1，algorithm `FSRS-6-default+song-learning-steps-v1`；第 2583 行附近定義預設 dailyNew 30、batchSize 25、desiredRetention 0.9；第 2648 行起定義 FSRS 記憶模型與 interval 計算；第 2692 行起定義 Again／Hard／Good／Easy 在 new／learning／review／relearning 的轉移；第 2721 行起定義 due/new session queue；第 2753 行起定義評級後顯示的下次間隔。

- `src/learning/fsrs-scheduler.js` 是 DOM-free FSRS-6 default scheduler，保留權重、retrievability、stability／difficulty 更新與 song-learning steps。
- `src/persistence/srs-store.js` 讀寫 `aniSrsScheduleV1`，驗證 schema，損壞資料先保存至 `aniSrsScheduleRecoveryV1_<timestamp>`；無法保存原始內容時阻止寫入。
- 舊版卡片只保存 `songId`，沒有 source 欄位；新版 SRS 暫時限定 AMQ，拒絕 EMQ record，避免把重疊數字 ID 套用到錯誤曲目。這不是聲稱 EMQ SRS 已支援。
- 預設設定：每日新卡 30、每次上限 25、desired retention 0.9、learning steps 1／10 分鐘、hard step 5 分鐘、relearning 10 分鐘、easy graduation 4 天、max interval 36,500 天。
- Quiz panel 支援單曲加入／暫停／恢復、到期複習回合、Again／Hard／Good／Easy 評級、間隔預覽、每日新卡與每次複習上限。已加入 SRS 的已計分題目需先評級或明確略過評級才可下一題。
- 新版尚未接入黑名單資料源；目前 SRS store 提供 `isBlacklisted` 注入點，UI 未假裝已有黑名單整合。


## Batch 28：歌曲黑名單契約（2026-10-27）

- 參考 HTML 靜態證據：`aniBlacklistedSongs_v1` 與 `aniBlacklistedAnime_v1` 分別為歌曲 ID／作品 ID 字串陣列；歌曲變更事件為 `ani-blacklist-changed-v51`，作品 recovery key 為 `aniBlacklistedAnimeRecoveryV825`。
- 新版 `blacklist-store.js` 保持同一 key／陣列格式，並提供 `amq-learning-blacklist-updated-v1` 的內部更新通知。黑名單只適用 AMQ song ID；不將相同裸數字 ID 自動套用到 EMQ。
- 損壞 key 先保存到 `aniBlacklistedSongsRecoveryV1_<timestamp>`，成功後才清除原 key；若 recovery 寫入失敗，保留原始內容並阻止寫入。
- QuizSession eligibility cache 在黑名單變更後刷新；SRS counts／queue 透過 `isBlacklisted` callback 排除歌曲，卡片仍保留。
- Node tests 證明 adapter 與模擬 storage 行為；真實瀏覽器跨頁事件尚未驗收。


## Batch 28：歌曲／作品黑名單契約（2026-10-27）

參考 HTML 確認兩個不同 key，均為 ID array：

- 歌曲黑名單：`aniBlacklistedSongs_v1`；恢復前綴 `aniBlacklistedSongsRecoveryV1_`。同頁變更事件 `ani-blacklist-changed-v51` 的 detail 包含 `songId` 與 `blocked`。
- 作品黑名單：`aniBlacklistedAnime_v1`；恢復 key `aniBlacklistedAnimeRecoveryV825`（若已存在則加時間戳後綴）。同頁變更事件 detail 使用 `animeId`、`blocked`、`scope: 'anime'`。
- `src/persistence/blacklist-store.js` 對兩個 key 分別載入、寫入及 quarantine；無法保存損壞原始值時，阻止該 scope 的後續寫入。
- AMQ 隨機出題與 SRS due queue 都排除歌曲黑名單及作品黑名單。EMQ 不套用這些 source-less legacy ID，避免與 AMQ 重疊 ID 誤判。
- 新 UI 提供當前歌曲／作品黑名單切換；舊版同頁事件與跨頁 `storage` event 都會刷新 eligibility。


## Batch 29：MIX 來源契約（2026-10-27）

- `src/data/source-runtime.js` 的 MIX 使用 composite adapter 並行載入 AMQ／EMQ；標準化 records 保留各自 `source`，不把兩來源的 ID 合併成同一身份。
- `src/engine/quiz-pool.js` 對 MIX 接受 AMQ 與 EMQ 記錄，身份仍為 source + song ID。
- `src/engine/quiz-session.js` 依參考 HTML `chooseQuestion`，當 AMQ 與 EMQ 都有未出題候選時以 2/3 機率選 AMQ、1/3 選 EMQ；任一來源沒有未出題候選時 fallback 到另一來源。SRS 固定題序不受權重影響。
- 目前真實資料驗證：AMQ 38,821、EMQ 16,839、MIX 55,660 標準化 records；可播放 MIX 候選池 54,778。
- Batch80 已接入年份、作品／歌曲類型、難度、看番狀態與個人清單的出題 eligibility，但舊版 AMQ 專屬篩選對 MIX 的 suppression 語義仍未移植；season 因缺少可信來源欄位尚未實作，hard-pool 語義也未驗收。不可宣稱已完整相容舊版所有篩選語義。


## Batch 30：來源感知 SRS 排程（2026-10-27）

- AMQ 繼續使用舊版相容 key `aniSrsScheduleV1` 與 recovery prefix `aniSrsScheduleRecoveryV1_`；舊卡片的裸 song ID 語義不變。新版不把 legacy 卡片搬移至另一 key，也不對舊 key 做雙寫。
- EMQ 使用獨立 key `amqLearningEmqSrsScheduleV1`，recovery prefix `amqLearningEmqSrsRecoveryV1_`。根節點必須包含 `source: "EMQ"`，每張卡亦必須包含 `source: "EMQ"`；卡片 ID 在各來源 key 內局部唯一，不會跨來源合併。
- EMQ schedule 的 source-less、AMQ-tagged 或卡片來源標記不一致的資料，先保存 recovery 副本，再清除該 EMQ key；若 recovery 失敗則封鎖寫入並保留原始 key。這不會觸碰 `aniSrsScheduleV1`。
- Quiz panel 在 AMQ／EMQ 單一模式選用對應 store；MIX 的 SRS queue 暫停使用，避免把來源不同的卡片 ID 注入單一固定 queue。MIX 猜歌本身仍可使用。
- AMQ blacklist 的 ID 沒有來源欄位，仍只套用 AMQ；EMQ SRS 不會錯誤排除與 AMQ 同 ID 的歌曲。
- 此批測試涵蓋模擬 storage、來源隔離、回收備份與 UI integration；不代表瀏覽器 localStorage／跨頁事件已通過真實瀏覽器驗收。


## Batch 32：AudioService 錯誤資訊

AudioService 的結果保留既有 `error` 字串作相容欄位，並新增 `errorInfo`，形狀由 `AMQCore.errors.createError()` 定義，`category` 為 `audio`。主要 code 包含 `AUDIO_ALL_CANDIDATES_FAILED`、`AUDIO_AUTOPLAY_BLOCKED`、`AUDIO_CANDIDATES_INVALID`、`AUDIO_NO_CANDIDATES`、`AUDIO_TIMEOUT_INVALID` 與 `AUDIO_SERVICE_DISPOSED`。`retryable` 表示可否合理重試該類操作，不代表同一 URL 一定能成功；`AUDIO_AUTOPLAY_BLOCKED` 應由使用者手動恢復。這些錯誤契約透過 mock media 測試驗證，真實瀏覽器、跨域與音訊可聽性仍未驗收。


## 第三十三批：正規化、身份與重複資料契約（2026-10-27）

- `src/data/identity.js` 是資料身份規則的唯一實作來源。身份 key 使用 `[source, typedId]` tuple 的 JSON encoding；ID 型別會保留，因此數字 `1` 與字串 `"1"` 不相同。缺少 source 的舊／通用記錄使用空來源範圍。
- `validateRecords()`、`queryIndex.createCatalog()` 與 `quizPool` 共用該 helper，避免各模組對同一資料得出不同去重結果。
- 正規化分成兩種：搜尋文字的 NFKC、大小寫折疊與空白整理只作用於索引副本；來源 ID 與顯示文字保留原值。不得以正規化後的標題替換 ID。
- 重複判定只依來源與 ID 身份。相同／相似標題、歌手或作品名稱僅是搜尋線索，不是可自動合併歌曲的證據；不同 ID 的同標題記錄仍分開保留。
- 新版保留來源提供的 ID，不自行用標題生成 ID。若上游來源在不同版本重新編號，僅靠目前資料無法保證跨版本穩定；需有上游穩定性證據或明確映射表後才可建立跨版本遷移。
- 回歸測試：`node tests/data-identity.test.cjs`；完整 Catalog／quiz pool 測試另見主工作狀態。這些測試不構成 Candidate302 相容性或真實瀏覽器驗收。


## Batch 39：音訊候選 deadline 與 MIX 規則核對

- AMQ quiz candidates 依目前可證實的參考 HTML 靜態線索產生三個 audio host 候選；影片欄位不混入 quiz audio。EMQ Catbox self-host URL 先產生 Catbox mirror，再保留原始 URL，並按 URL 去重。這只定義候選順序，不保證 URL 可播放。
- AudioService 的 `canplay` 只表示 ready。autoplay 請求仍需在 timeout 內收到 `playing`，否則清理目前 media 並進入下一候選；手動播放模式則可停在 ready，使用者恢復時才重新啟動 deadline。明確暫停後的遲到 `playing` 事件不應解除 paused。
- MIX 目前在兩來源皆有可用未出題曲目時按 AMQ 2/3、EMQ 1/3 選題；一方耗盡時使用另一方。source + typed ID 身份隔離不變。
- Batch80 已接入部分對應控制（年份、作品／歌曲類型、難度、看番狀態、個人清單）；舊版 MIX suppression、season 與 hard-pool 語義仍未完成，不能宣稱舊版所有篩選語義相容。

## Batch 41：歷史摘要失敗保護與猜歌設定 schema（2026-10-27）

- 答題歷史摘要讀取例外與無效 JSON 是不同狀態。`getItem(SUMMARY_KEY)` 失敗時，不能把未知摘要當作空資料並覆寫；`summaryWriteBlocked=true`，直到成功重新讀取外部變更後才允許保存。無效 JSON 則先 quarantine 原始 bytes，成功後才從可用明細重建摘要。
- 猜歌設定使用獨立 key `amqLearningAppSettingsV1`，schemaVersion 固定為 `1`，包含 `target`、`questionCount`、`clipSeconds`、`acceptPartial`、`autoPlay`、`customListId`、`srsEnabled`，以及 Batch80 新增的 `yearFrom`／`yearTo`、`includeUnknownYear`、`animeType`、`difficultyMin`／`difficultyMax`、`songType`、`watchStatus`。新增欄位皆對舊 schemaVersion 1 payload 向後相容，缺少時使用明確預設值；年份／難度範圍非法或倒置會使整份 schema 無效。未知欄位不被保存。
- 無效設定先備份至 `amqLearningAppSettingsRecoveryV1`；若備份失敗，原 key 保留且寫入阻塞。Storage 讀取失敗時保留目前記憶體設定並阻止 mutation；寫入失敗不提交候選設定。成功 storage event reload 可恢復讀取阻塞狀態。
- 設定 store 保存目前 UI 已存在的猜歌設定與目前選取的自訂清單 ID；清單成員尚未接入猜歌出題池。深色主題、背景 IndexedDB 與收藏寫入仍未實作。測試為 Node mock storage；瀏覽器 localStorage／跨分頁實測仍 BLOCKED。


## Batch 42：持久化失敗矩陣與快照契約（2026-10-27）

| Store | 讀取例外 | 寫入／備份失敗 | Storage event／清除 | UI／狀態投影 |
|---|---|---|---|---|
| Familiarity | 保留 AMQ／EMQ 各自快照並阻止該來源寫入 | 寫入失敗回滾該筆記憶體變更 | 成功重載後更新來源快照與解除阻塞 | `getPersistenceStatus()` 區分 AMQ／EMQ readBlocked |
| Quiz history detail | 保留最後可讀取明細快照，`detailWriteBlocked` 阻止覆寫 | detail write failure 可查詢；summary 是獨立 key，不具跨 key 原子性 | 成功重載替換快照；確認 key 清除才接受空明細 | `getPersistenceStatus()` 投影 detail／summary 失敗及 legacy read error |
| Quiz history legacy detail | 保留上次唯讀快照並回報 `legacyReadError` | legacy key 不寫入、不做自動修復 | 成功重讀後替換唯讀快照 | UI 顯示部分舊版紀錄暫時不可讀提示 |
| SRS | 外部重讀失敗保留最後 schedule 並阻止寫入 | schedule mutation 不發布候選狀態；recovery 失敗保留原始 key | 成功重載更新快照；key 清除載入空 schedule | `getPersistenceStatus()` 回報 blocked／error |
| Blacklist | 保留該 scope 既有集合並封鎖對應寫入 | 寫入失敗不發布新集合；損壞資料需先 quarantine | 分別重載 song／work key；key 清除視為空集合 | `getStatus()` 區分 song/work error、blocked 與 recovery |
| App settings | 保留目前設定並阻止 mutation | 寫入失敗不提交候選值且通知 subscribers；無效 schema 先 quarantine | `key === null` 或 settings key 事件重新讀取；成功清除載入 defaults | `recoveryNotice` 與 `error` 分開顯示，不能隱藏已隔離資料提示 |

上述為 Node/mock-storage 契約測試。實際瀏覽器 localStorage、跨分頁時序、quota、pagehide 仍未驗收；history detail／summary 跨 key 寫入仍不具原子交易保證。


## Batch 43：部分持久化狀態與訂閱通知（2026-10-27）

- Quiz history `getPersistenceStatus()` 的 `summaryPersisted` 現在要求 `summaryPending === 0`，另提供 `fullyPersisted`；detail 寫入成功但 summary 仍待寫入／寫入失敗時，不能把整體狀態報成完整持久化。`appendEntries()` 保留相容的 `persisted`（代表 detail 已保存），並額外回傳 `detailPersisted`、`summaryPersisted`、`fullyPersisted`、`summaryPending`。
- History detail 與 summary 仍是不同 key，不具跨 key 原子性。summary 寫入失敗後，可由 detail 重新建立統計；`processedIds` 去重使同批 detail 不會重複計入。此為恢復策略，不是原子交易保證。
- SRS 的 schedule write／flush failure 會通知 subscribers，`getPersistenceStatus().persisted` 明確回報狀態。
- Blacklist song／work write failure 會通知 subscribers，並使用獨立 `songWriteError`／`workWriteError`，不再把寫入失敗偽裝成讀取錯誤。UI 分別呈現讀取或保存失敗。
- Familiarity storage event 重讀失敗時，通知事件及 `getLastWrite()` 回報 `persisted: false`，保留快照與來源 read-blocked 狀態。
- 測試涵蓋 storage clear、read recovery、write failure notification、dispose cleanup 與 history partial-success restart recovery。仍需真實瀏覽器跨分頁／quota／pagehide 驗收。


## Batch 46：QuizSession 的部分持久化錯誤傳遞

- `quiz-history-store.appendEntries()` 的 `persisted` 為相容性欄位，代表 detail key 寫入成功；`summaryFailed` 只表示 summary 寫入明確失敗／被阻塞，與正常 debounce pending 分開。
- `QuizSession.persistHistory()` 現在檢查 `summaryFailed`。detail 成功但 summary 明確失敗時，答題結果仍保持已判定，但 session 顯示「部分進度未能持久化」；正常的 debounce pending 不會被誤報成失敗。
- 回歸測試覆蓋部分失敗與正常 pending 兩種不同情境。這仍不能讓 detail／summary 兩個 key 變成原子交易。


## Batch 47：QuizSession store adapter 例外隔離

- familiarity 與 history 寫入是兩個獨立的持久化步驟。任一注入 store 的方法即使意外 throw，QuizSession 仍保留已完成的答題狀態，並繼續嘗試另一個 store；最終狀態會提示部分進度未保存。
- Store 正常實作仍應自行把 storage exception 正規化為結果物件；QuizSession catch 是額外的模組邊界保護，不代表允許 store 忽略持久化契約。


## Batch 48：持久化警告生命週期

- `QuizSession.getState()` 新增 `persistenceWarning`，與 `message`（目前回合／音訊狀態）分開。history round initialization 或進度保存失敗時，警告不會被 `nextQuestion()`、`playing`、pause/resume 等訊息更新覆蓋。
- 下一個新回合會清除上一回合的持久化警告；當前回合的操作訊息仍可正常更新。


## 個人清單作品身份（Batch 52）

自訂清單的新成員身份使用 `{ source: "AMQ" | "EMQ", id: string }`，持久化欄位為 `workRefs`。比較時只使用來源及字串化作品 ID；不得用作品標題或裸 ID 合併 AMQ／EMQ。歷史 `animeIds` 欄位為 source-less 舊資料，保留但不會自動納入新版猜歌池。這是避免 ID collision 的相容策略，不是舊清單資料已完整遷移的聲明。

看番狀態新 API 也以 source-aware work ref 保存於 `aniAnimeWatch_v1` 的獨立 `@work:[source,id]` key。舊裸 ID 狀態維持原樣，不能推斷其 AMQ／EMQ 所屬來源。若未來要做資料遷移，必須有使用者明確選擇或可信映射，不得只按 ID 猜測。


## Batch 56：模式切換與已發布 Catalog 的失效化

- `Repository.cancel()` 保留「取消目前活動請求」語義；沒有活動請求時不改變狀態。
- `Repository.invalidate()` 用於來源／模式上下文已變更的情況：取消活動請求、增加 load-state generation 並同步清除 catalog 與載入狀態。
- Runtime Bootstrap 的 mode subscription 使用 `invalidate()`，避免切換模式後仍把舊來源 catalog 當成新模式資料。此行為不自動觸發重載。
- 測試覆蓋 AMQ 已載入後切換 EMQ：同步狀態應為 `not-loaded`、catalog 應為 `null`，重新載入後只包含 EMQ。這是 Node integration evidence，不是瀏覽器 E2E。


## Batch 59：共享狀態訂閱的重入更新契約（2026-10-27）

- 每次有效 `state.update()` 都提交不可變 snapshot，訂閱通知依提交順序 FIFO 執行。
- 若 listener 在通知途中再次更新 state，巢狀提交排隊等待當前 snapshot 的所有仍有效 listener 完成通知；不得讓後續 listener 只收到重入後的新 snapshot，或重複收到同一新 snapshot。
- subscriber error diagnostic 綁定實際觸發例外的 snapshot；診斷仍是最多 50 筆的記憶體內有界佇列。


## Batch 61：Runtime Bootstrap dispose 的 Catalog 所有權邊界（2026-10-27）

- Runtime Bootstrap 終止時，Repository 的 Catalog 不再屬於可用 runtime；`dispose()` 必須同步失效化並重設共享 `dataStatus`、錯誤與計數，不能只取消活動請求。
- 優先呼叫 Repository `invalidate()`；若注入的相容 Repository 沒有該方法，才退回 `cancel()`。這個 fallback 不宣稱能清除未知 Repository 的 Catalog。
- 正在進行的非合作來源可能在 dispose 後才 resolve，但舊 generation 不得發布資料或覆蓋 `not-loaded`。dispose 是終止操作，不自動重載資料。
- Node integration 已驗證 loaded 與 loading 兩種 dispose 路徑；真實瀏覽器重新掛載驗收仍獨立 BLOCKED。


## Batch 62：App mount 初始化失敗的資源回滾（2026-10-27）

- `AMQApp.mount()` 初始化採資源註冊 rollback：若 runtime、store、catalog browser、quiz panel 或 render subscription 接線途中拋出例外，已加入 lifecycle scope 的資源會清理，`scope` 與模組參照重設，原始例外仍拋出。
- 回滾後再次呼叫 `mount()` 必須可重新初始化；不得因半初始化 scope 仍被視為有效而直接 return，也不得殘留 mode click listener。
- rollback 只負責已註冊到 scope 的資源；某個 `mount()` 在返回 disposer 前自行建立的內部資源，仍由該模組負責自我清理。
- `tests/app-lifecycle.integration.test.cjs` 使用 VM／fake DOM 驗證成功的 mount-dispose-remount 與 catalog browser 初始化拋錯後的 rollback/retry；不是實際瀏覽器 E2E。


## Batch 65：EMQ 音訊候選轉換（依 Candidate381 靜態證據）

- `createEMQAudioCandidates()` 會保留原始候選，並按舊版 V82.54／V82.55 線索建立可去重的備援候選。
- `selfhoststorage/catbox/{filename}`：先加 `https://files.catbox.moe/{filename}`，再保留原始 URL。
- `https://erogemusicquiz.com/selfhoststorage/userup/...`：先把 host 轉成 `asiadist.erogemusicquiz.com`，再保留原始 URL。
- 符合 `/selfhoststorage/userup/weba/{hex-or-hyphen-id}.weba` 的 URL，另建立 `/selfhoststorage/userup/{id}.webm` sibling fallback，順序為 Asia WebA、原始 WebA、Asia WebM、原始 WebM。Query/hash suffix 會保留在 userup 候選中。
- 其他不符合已觀察格式的 URL 不做猜測性 rewrite。候選順序由 `tests/audio-candidates.test.cjs` 固定。
- 目前 `emq-data.js` 的唯讀統計為 16,839 首歌曲、16,877 個非空音訊 URL；其中 13,648 個 URL 使用 `selfhoststorage/userup/`，7,909 個 URL 為 `.weba`，3,208 個 URL 使用 `selfhoststorage/catbox/`，另有 21 個其他格式 URL（URL 數量可能同一歌曲多筆）。這證明轉換規則覆蓋面高，但不證明網址目前可播放。
- Candidate381 參考檔只作靜態行為線索，不宣稱 Candidate302 或 Candidate382 Stage 0 相容。真實瀏覽器音訊驗收仍需使用者回報。


### MediaError 診斷補充（Batch 65）
`AudioService` 讀取 `HTMLMediaElement.error.code`（若瀏覽器有提供）：1 對應媒體中止、2 對應網路錯誤（可能包含網路或跨域限制）、3 對應解碼錯誤、4 對應來源格式不支援。若沒有可用的 MediaError code，保留一般 `media-error`。這是瀏覽器錯誤分類，不代表已確定具體根因；尤其 code 2 不能直接等同 CORS。


## Batch 68：答案建議的舊版行為還原（2026-10-27）

- `src/ui/answer-suggestions.js` 對照 Candidate381 V82.x 的 `mapQuizSuggestionTextV824()`、`quizSuggestionHighlightRangesV824()`、`renderQuizSuggestionLabelV824()` 與 `buildSuggestions()`：保留 NFKC／大小寫／特殊符號分隔、空白 compact 比對、空格／斜線／連字號等價、短標籤優先及穩定排序；候選中實際匹配的原始文字以 `.quiz-suggestion-match` 包住並使用主題強調色及粗體。只在 query 改變時重繪高亮；相同 query 的一般狀態 render 保留 option DOM。
- `src/data/source-mappers.js` 依舊版 EMQ reader 的實際 `ta`／`n`、`aa`、`wa`／`wt`／`wn` 使用方式，保留有來源證據的歌曲、歌手及作品別名；`validate.js` 驗證別名陣列；`query-index.js` 可搜尋並凍結這些陣列。缺少的別名不會被推測補造。
- 舊版繁體中文作品名稱還依賴 `__aniChineseTitleAPIv8237`／`__aniEmqChineseTitleAPIv8259` 及設定開關。新版目前沒有對應 provider／設定接線，因此本批只會顯示記錄中已存在的 `animeChineseTitle`／`animeAliases`；真正中文標題資料服務尚未接回，不能宣稱中文別名完整恢復。
- 舊版參考檔只作靜態行為依據；不覆蓋 Candidate302／Candidate382 Stage 0，不代表真實瀏覽器驗收完成。

## Batch 69：答案建議的字元結構與容錯契約（2026-10-27）

本節是新版答案建議行為規格，優先於 Batch 68 舊版 separatorMatcher 行為描述；它只影響建議搜尋，不修改答案評分器或曲庫資料。

- 查詢與候選文字使用 Unicode NFKC／大小寫正規化，但保留內部空白、標點與特殊 Unicode 字元；不再建立刪除所有空白的 compact key 進行匹配。
- 字元分隔容錯是單向且按字元類型定義：使用者輸入 `/`、`-`、`:`、`;`、`'`、`.`、`,` 或已列入的特殊 Unicode 符號時，該位置可匹配相同字元或一個空白。不同標點之間不互換。
- 使用者輸入空白時，該位置只匹配空白；不會將 `A B` 擴大為 `A-B`、`A/B` 或其他標點結構。
- 使用者輸入 `AB` 時只匹配候選中連續出現的 `AB`，包括完全符合、開頭或中間包含；不會把 `A-B`、`A B`、`A★B` 刪除分隔符後視為 `AB`。
- 排序層級：正規化後完全符合 → 字面開頭符合 → 分隔符容錯開頭符合 → 字面包含符合 → 分隔符容錯包含符合。每層內名稱較短者優先，再依正規化文字及原文穩定排序；結果去重且最多 25 筆。
- 原始顯示標籤不改寫。高亮只依實際匹配區間產生安全 DOM text node／span。這是候選建議規則，不會改變最終答案驗證規則。
- 回歸案例包含：`A-B` 可找到 `A-B`／`A B`，但不能找到 `A/B`／`A:B`；`A B` 只找保留空白結構的結果；`A/B` 可找到 `A/B`／`A B`，但不能找到 `A-B`；`AB` 只找連續 `AB`。


## Batch 80：猜歌出題篩選與資料欄位

- `animeYear` 由 AMQ work row[5] 與 EMQ work `y` 映射；`animeType` 只由已核對 AMQ work row[4] 映射。EMQ 未提供可確認的對應欄位時保持 `null`。
- 猜歌設定仍使用 `amqLearningAppSettingsV1`／schemaVersion 1，新增可選 `yearFrom`、`yearTo`、`includeUnknownYear`、`animeType`、`difficultyMin`、`difficultyMax`、`songType`、`watchStatus`。舊版設定缺少這些欄位時套用預設值；年份／難度範圍錯誤或倒置會被拒絕。
- QuizPanel eligibility 以 AND 關係套用來源模式、AMQ 黑名單、年份／未知年份、作品類型、歌曲類型、難度、看番狀態及個人清單。難度篩選啟用時，缺少難度的記錄不符合條件。
- 季別目前沒有可信來源欄位，不得從年份推算；舊版 MIX 的 AMQ-specific filter suppression 與 hard-pool 規則仍待實作／驗收。


## Batch 82：中文作品標題 Provider 契約（2026-10-27）

- `src/data/chinese-title-provider.js` 提供唯一的 `AMQData.chineseTitleProvider` adapter。資料來源使用舊版靜態參考中已固定版本的 AniList 中文對照 JSON 與 `bangumi-data` JSON；不使用未核實的自造 API endpoint。AniList 對照表以 AniList ID 為 key，需透過 Bangumi `sites` 的 `myanimelist`／`anilist`／`vndb` ID 交叉映射。
- 更正（Batch158）：AMQ anime/work row 的 `row[0]` 是 AMQ 內部 work ID，`row[6]` 是 ANNID（Anime News Network ID），兩者不可混用，也不可將任一欄直接當成 AniList ID。`source-mappers.js` 將 `row[6]` 映射為 `animeAnnId` 與 `artworkRef.annId`；只有透過有明確 ANN↔AniList 關聯的 crosswalk 才能取得 AniList ID。EMQ 仍只透過來源 work row 明確提供的 `vndbId` 對應。沒有明確 ID 對應時不以相似標題猜配。
- Provider 回傳 `getTitle(record)` 與 `getAliases(record)`；原始曲庫 record 不被改寫。中文別名只加入作品答案建議，揭曉時可顯示已對應的中文作品名。曲庫全文搜尋索引尚未動態合併這些遠端別名，另列後續工作。
- `chineseTitlesEnabled` 是既有 `amqLearningAppSettingsV1` schemaVersion 1 的可選相容欄位，預設 `false`。只有使用者啟用後才下載標題資料與按需載入 OpenCC；關閉時不觸發遠端下載。舊設定缺少欄位時不自動開啟。
- Provider 優先使用 IndexedDB 快取（7 天 TTL）；IndexedDB 不可用時仍可即時使用網路資料但不保證跨頁快取。快取寫入失敗不會令有效查詢失敗。逾期快取在遠端來源不可用時可用作 stale fallback。
- 網路請求有 timeout、支援 AbortSignal；若 Bangumi 交叉映射來源不可用且沒有快取，Provider 回報錯誤，不阻擋一般猜歌或既有英文／羅馬字答案。AniList 來源可選，Bangumi 資料成功時允許部分來源模式。OpenCC 轉繁體失敗時保留來源提供的中文標題，不會因轉換服務失敗中斷標題資料。
- 本批 Node 測試驗證 parser、MAL／VNDB ID 對應、別名、轉換注入、IndexedDB-cache adapter 契約、過期快取回退、取消與無效來源拒絕；不代表真實瀏覽器外部網路、CORS、遠端 JSON 目前可用或 OpenCC CDN 已完成實機驗收。


## Batch 84：曲庫更新 envelope

更新包格式、checksum、schema、來源 mapping／關聯驗證、差異摘要、IndexedDB 原子提交及 runtime 消費契約見 `docs/DATABASE_UPDATE_CONTRACT_BATCH84.md`。更新包必須同時包含 AMQ `anime`／`songs` 與 EMQ version 1 `works`／`songs`。匯入前完整驗證所有歌曲記錄；成功資料以一個 IndexedDB active envelope 原子替換，runtime 在下一次頁面載入重新驗證後使用正規化資料。更新失敗不得覆蓋先前 active envelope；移除 override 會回到內建唯讀資產。CLI 只解析來源檔中的 JSON assignment，不執行來源程式碼。


## Batch 85：自由播放歷史與 Dashboard projection

- Playback history key：`amqLearningPlaybackHistoryV1`，schema `{ schemaVersion: 1, entries: [...] }`，上限 1,000。每筆 `id` 唯一，`source` 必須為 `AMQ`／`EMQ`，`songId` 必須非空；可選 `workId`、`title`、`artist`、`workTitle`、`durationSeconds`、`positionSeconds`，`playedAt` 正規化為 ISO timestamp。播放歷史不記錄猜歌答案或答題正誤。
- `recordPlayback()` 成功才更新記憶體快照；讀取／schema 失敗會阻止寫入，寫入失敗保留舊快照並回報 `persisted:false`。同分頁透過 subscribe 通知，跨分頁透過 `storage` event reload；實機事件時序仍待驗收。
- 備份沿用既有 `amq-learning-tool-backup` v1 envelope。新 key 加入 allowlist 與 schema preflight；舊 partial v1 envelope 省略此 key 時不清除使用者現有播放歷史。
- Dashboard API 為純函式 `AMQLearning.statisticsDashboard.buildDashboard({ quizHistory, familiarityAMQ, familiarityEMQ, srsAMQ, srsEMQ, playbackHistory })`。輸出是從傳入快照計算的即時 projection，不寫入 localStorage，也不應由 UI 再保存衍生總數。答題歷史缺少可信 source 或 boolean `correct` 的列不納入摘要；空樣本 accuracy 回傳 `null` 而非 `NaN`。


## Batch 86：自由播放事件與儀表板讀取契約
- 自由播放使用既有 `AudioService` 作為唯一媒體 owner。`getPlaybackMetrics()` 回傳 `available`、`currentTime`、`duration`、`paused`、`ended` 的唯讀快照，不暴露媒體元素。
- Dock 只將 AudioService 實際 `playing` 狀態計入累積播放時間；至少 5 秒才建立一筆 `amqLearningPlaybackHistoryV1` entry。同一 audio sequence 最多一筆，source 與 songId 必須沿用當前播放記錄。未達門檻的短暫試播不記錄。
- QuizSession／QuizPanel 音訊不會寫入自由播放歷史。切歌前先結束前一序列，避免舊播放事件套用到新選曲。
- Dashboard 使用 `quizHistoryStore.getHistory()`、`familiarityStore.getSnapshot(source)`、兩個 SRS store 的 `counts()` 與 playback history `getEntries()`；只計算投影，不保存第二份統計。Store 讀取狀態有錯誤時，不呼叫 projection 並顯示錯誤狀態。


## Batch 87：曲庫瀏覽 filter criteria
- 新增 `animeYearFrom`／`animeYearTo`（有限數字）、`includeUnknownYear`（boolean）、`animeType`、`animeDecade`（十年邊界）、`watchStatus` 與 `familiarityLevel`（整數 0–3）。所有條件在排序與分頁前執行。
- `includeUnknownYear` 只在啟用年份範圍時影響缺失／非數值年份；設為 false 排除未知年份，true 保留未知年份。年代篩選只匹配已知年份的 `floor(year/10)*10`。
- `watchStatus` 來自來源明確的 `{source, id}` work reference；熟悉度由共用 Familiarity Store 取得。瀏覽索引使用複製 record 的衍生欄位，不修改 runtime Catalog／來源資產。
- Facet criteria 排除自身條件但保留其他條件，計數不受當前頁面大小限制。`animeYear` 數值排序中缺失年份升冪／降冪均最後。


## Song tag data (Batch 188)

- User-managed song tags live in `amqSongTagsV1` with `{ version: 1, tags, assignments }`. This data is separate from the read-only AMQ/EMQ catalogue assets.
- Song assignment keys use `AMQData.identity.createIdentity(source, songId)`, preserving source and identifier type. AMQ song ID `1` and EMQ song ID `1` are distinct. Only `AMQ` and `EMQ` assignments are accepted.
- Tag definitions have unique IDs and case-insensitive unique names (1–32 normalized characters). At most 200 tag definitions are accepted. Deleting a tag also deletes all assignments to that tag.
- Bulk assign/remove is one storage commit. A failed write does not publish a partial in-memory assignment update.
- Query-index supports `tagId` as a normal AND-composed filter; multiple supplied IDs use any-match semantics. The tag store remains the single source of truth for assignments; `tagIds` on query-index records are derived snapshots only.
- The backup/restore contract includes `amqSongTagsV1` and validates it with the same tag schema before applying imported data.
