# AMQ Batch111 交接：SQLite 持久化登入 session

日期：2026-10-28

## 本批目標與結果

解決帳號 session 只存在單一 Node process 記憶體、伺服器重啟會使所有使用者登出的問題，同時不將 bearer token 原文存進資料庫。

- `server/database.cjs` 新增 `sessions` table 與 expiry index。
- `server/http-server.cjs` 建立 session 時保存 SHA-256 token hash、user ID、建立時間及 12 小時到期時間；程序內 Map 只是熱快取。
- Session 驗證時重新檢查 expiry 與帳號存在；logout 同時清除記憶體快取及 SQLite row。
- 正常關閉／重啟不再刪除仍有效的 session。建立新 session 時會清理已過期 rows；已過期 session 在被使用時刪除。
- 修正 `server/start.cjs` 初次管理者密碼提示的舊「12 字元」說法，與現行 8–128 政策一致。

## Targeted tests

執行：

```sh
node --test tests/server-auth-srs.integration.test.cjs
```

結果：5/5 PASS。包含 restart survival、hash-only persistence、logout revoke、12 小時 TTL 精確到期邊界及過期 row 清理。

Node 22.16 仍顯示 `node:sqlite` ExperimentalWarning。

## 安全與架構界線

- Cookie 仍為 HttpOnly、SameSite=Strict，TTL 仍為 12 小時。
- 資料庫只存 SHA-256 token hash；不能由 DB row 直接還原 cookie token。
- 此變更不代表多節點水平擴展、分散式 rate limit 或跨節點 room serialization 已完成。
- 不要恢復舊的「server restart 使 session 失效」文件描述。

## 下一步

1. 完成 Batch111 全量自動化測試、架構檢查、語法、來源 audit／mapper／benchmark。
2. 確認唯讀曲庫來源 hash 未變。
3. 重新產生 `MANIFEST.sha256` 與完整 ZIP，驗證 CRC、檔案清單及 hash。
4. 接續處理尚未完成且可獨立驗收的多人 transport／durable room lifecycle、Google 帳號明確 link/unlink（禁止 email 自動合併）、遠端 SRS offline/conflict handling 與外部服務 feature adapters。真實瀏覽器／音訊驗收由使用者最後集中執行；UI／CSS 大重構仍最後做。


## 最終全量驗證與交付包

- 49/49 非-tooling test scripts PASS；tooling 13/13 PASS。
- Architecture 783 passed／0 failed；JS/CJS syntax 117/117 PASS。
- Source audit／mapper／5-run catalog benchmark PASS。
- AMQ readonly source SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`。
- EMQ readonly source SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- ZIP CRC PASS；272 entries（含目錄）、257 files（含 manifest）；256 個受管檔案，missing 0／extra 0／hash mismatch 0；沒有 `.pem` 私鑰。
- Validation logs：`/mnt/data/amq_batch111_validation_logs/`。
