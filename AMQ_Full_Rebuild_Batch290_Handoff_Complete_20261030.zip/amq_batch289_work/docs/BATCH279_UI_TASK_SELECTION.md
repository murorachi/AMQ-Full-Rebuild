# Batch279：從既有待辦選出的 30 項 UI 工作（2026-10-30）

本批回到既有 UI 設計主線，不把 CI／IndexedDB／外部音訊阻塞當作主工作。以下項目均引用原有 `MASTER_CHECKLIST.md`／差距登記中的未結案事項；本表是執行範圍索引，不會把尚未做的事標成完成。

| # | 原清單項目 | 工作範圍 | 狀態 |
|---:|---|---|---|
| 1 | AMQ-278-010 | Home/Catalog 與 osu! Stable 並排視覺 gate | 已建立對照截圖；人工 gate 未通過 |
| 2 | AMQ-277-013 | Home/Catalog Stable 視覺差距 | 進行中：首頁 chrome 已精簡，仍有背景差距 |
| 3 | AMQ-275-014 | Home 主選單構圖與 Stable 人工驗收 | 待人工驗收 |
| 4 | AMQ-273-014 | Home、Catalog、Quiz、Multiplayer 視覺 gate | 待人工驗收 |
| 5 | AMQ-262-030 | Home 空狀態主視覺空間差距 | 完成：空狀態已不佔用首頁底部 |
| 6 | AMQ-262-031 | Catalog 真實封面與列表密度 | 列密度／選取視覺改善；真實資料與封面仍待驗收 |
| 7 | AMQ-261-032 | Home 1920×1080 視覺比對 | 截圖已更新；人工 gate 待驗收 |
| 8 | AMQ-261-033 | Catalog 1920×1080 視覺比對 | Batch283 已產生與 Stable 並排圖及差距表；fixture，人工 gate 未通過 |
| 9 | AMQ-261-034 | 1440×900 Catalog 詳情與 Dock 空間 | Batch283 更新中央作品舞台／右側佇列；四尺寸 geometry 通過，人工驗收待做 |
| 10 | AMQ-261-035 | 1024×768 篩選／列表／詳情互動 | 篩選／作品舞台／佇列三區布局已更新；自動檢查通過，實際操作待驗收 |
| 11 | AMQ-261-036 | 390×844 篩選／詳情／播放控制 | 手機改為篩選→作品→歌曲佇列閱讀順序；真機待驗收 |
| 12 | AMQ-261-039 | Catalog footer/status 垂直空間 | 完成：來源 tabs 移至頂部，模式狀態改為折疊區；Dock 不再預留側欄寬度 |
| 13 | AMQ-261-040 | 播放器展開時避免遮擋曲目操作 | 收合／展開兩態納入四尺寸幾何檢查，分頁不被 Dock 遮擋；人工 gate 待驗收 |
| 14 | AMQ-261-041 | Home 新 artwork targets 的 Skin roles | 核對既有 Skin role；新 recent 元件已有 component IDs |
| 15 | AMQ-261-044 | Home 長標題不破壞網格 | 完成：標題可換行，recent 標題兩行截斷 |
| 16 | AMQ-261-045 | 作品／歌手 metadata 缺失時不顯示 null/undefined | 完成：null／undefined／NaN metadata 正規化 |
| 17 | AMQ-261-047 | Home recent items 鍵盤操作與焦點 | 完成：recent 為語意按鈕並有焦點樣式 |
| 18 | AMQ-261-048 | artwork fallback 不冒充正式作品封面 | 完成：無正式 artwork 時仍明確使用 AMQ fallback，不假造作品封面 |
| 19 | AMQ-261-049 | UI_COPY_POLICY 覆蓋所有新元件 | 部分完成：新增元件遵守文案原則；全域掃描未跑 |
| 20 | AMQ-261-050 | P0 差距關閉後才標記 Home/Catalog 視覺通過 | 規則保留：P0 未關閉前不得結案 |
| 21 | AMQ-262-032 | 動態元件 UI_COPY_POLICY 掃描 | 待執行全域 UI_COPY_POLICY 掃描 |
| 22 | AMQ-262-033 | Home artwork fallback 對比／裁切 | 部分完成：fallback 對比保留；人工封面裁切 gate 待做 |
| 23 | AMQ-262-034 | Home Skin roles 對應新 targets | 部分完成：Home logo 已新增 `app.home.logo` runtime role 並驗證 apply/reset；recent item/artwork 尚未全部加入 resolver registry |
| 24 | AMQ-262-035 | Home store／artwork adapter dispose lifecycle | 既有 dispose 路徑保留；本批未重新驗收 lifecycle |
| 25 | AMQ-260-046 | Catalog 截圖對照 osu! 參考 | Batch283 新增 `catalog-vs-osu-stable-1920x1080.jpg` 與逐項差距表；未通過 gate |
| 26 | AMQ-260-047 | Catalog 中央列表密度與可視列數 | 右側歌曲佇列／中央作品舞台已重新分區；四尺寸可視列幾何通過 |
| 27 | AMQ-260-048 | 播放 Dock 不遮擋列表／篩選 | Dock 實際高度參與列表尺寸計算，展開狀態也驗證分頁位置；真機／人工 gate 待驗收 |
| 28 | AMQ-260-051 | Home/Catalog 1920×1080 差異比對 | 四尺寸截圖更新；人工差異表未關閉 |
| 29 | AMQ-260-052 | 關閉構圖、密度、焦點差異 | 規則保留：未通過視覺 gate 不會標完成 |
| 30 | AMQ-277-015 | 將 provider outcome 納入正式封面成功率報告 | 待 runner／provider report 整合 |

## 本批已開始的 UI 變更
- Home 桌面版將版面高度優先分配給 osu!-style 主視覺與右側六個入口，縮小最近紀錄列的相對比例。
- 空歷史狀態改成緊湊的狀態列，不再讓「尚無學習紀錄」佔據過大的視覺面積。仍顯示誠實空狀態，不造假作品或封面。
- 這項 CSS 改動不代表 live artwork、正式 Catalog、人工 Stable gate 或整體 UI 已驗收。

## Batch280 執行紀錄

- 使用者指出首頁仍過擠：已移除 Home 的全域 header、側邊 route rail 與底部最近學習面板；首頁改為全視窗主視覺＋右側六入口。功能頁保留精簡水平導覽，沒有刪除 router 或重複建立導航 owner。
- Catalog 固定播放器 Dock 左右定位改為 12px，不再為已移除的 78px 側欄保留空間。
- Home 最近紀錄增加 nullish／字串 `null`、`undefined`、`NaN` 清理；標題可換行／兩行截斷；動態項目、封面、標題有穩定 `data-skin-component` IDs；焦點樣式明確。
- 四尺寸 Chromium matrix：102/102 PASS（Home 及 Catalog layout fixture；不代表正式曲庫／封面驗收）。
- 新增 `tests/batch280-home-chrome.contract.test.cjs`：5/5 PASS。既有 focused Node tests：33/33 PASS；Architecture Checker：1351 PASS／0 FAIL；`node --check src/ui/app-shell.js` PASS。
- `tests/app-shell.browser.test.py` 本次逾時，沒有重試，未視為通過。Home／Catalog Stable 人工視覺 gate、live artwork、Windows／實機與 Dock 實際遮擋仍未結案。


## Batch281 更新（音符＋問號品牌圖示）
- 首頁品牌不再顯示「AMQ」三個大字，改用原創音符＋問號圖示；圖示配色以珊瑚紅／深石墨／暖白呈現，不照搬 osu! 配色。
- Home 主視覺圓盤由高飽和粉色改為低對比石墨底與細緻環線，讓圖示成為焦點。
- 新增 `src/assets/amq-note-question.png`，裁切透明邊界並壓縮至 494×512、約 163 KB。
- 新增 Skin runtime role `app.home.logo`，作用於首頁品牌標誌與功能頁返回首頁按鈕；套用、reset 與 fallback 已由 focused Node test 覆蓋。
- 四尺寸 Chromium regression 102/102 PASS；Catalog 仍是 layout fixture，不代表 live 曲庫或封面驗收。
- 原始 Stable 視覺 gate仍未通過；並排差距圖見 `artifacts/batch281-home-catalog/home-vs-osu-stable.jpg`。


## Batch282 連續執行進度
- 原項目 01–04、07–11、25、28：維持「視覺差距已記錄／自動幾何已驗證，人工 Stable gate 未通過」，不因新測試改成結案。
- 原項目 09–13、26–27：已補上 Dock 高度驅動的列表尺寸、分頁與 Dock bounding-box regression；四尺寸 114/114 PASS。正式曲庫／實機驗收仍待完成。
- 原項目 14、23：Catalog song list、pagination 與 player dock 新增穩定 Skin component targets；Home logo role不重做。
- 原項目 19、21、22、24、30：仍需全域文案掃描、fallback 人工裁切、lifecycle 全面驗收與正式 artwork provider report，不假裝完成。
- 額外修正：feature-route 導覽列明確指定 CSS Grid row，避免 auto-placement 把導覽列放到內容後方。這是已發現的可見 UI 缺陷，已納入本批 browser regression。


## Batch283 執行紀錄：Catalog Stable 對照與播放器整合

- 已直接檢視 `artifacts/osu-reference/osu-song-selection.jpg`，並產生 `artifacts/batch283-catalog-stable/catalog-vs-osu-stable-1920x1080.jpg` 與 `docs/OSU_CATALOG_VISUAL_GAP_BATCH283.md`。
- Catalog 桌面構圖更新為左側 AMQ 篩選、中央選取作品舞台、右側歌曲佇列；頂部 AMQ／EMQ／MIX tabs 從高大的狀態面板拆出，狀態資訊折疊收納。
- 加入 provider-success 驅動的背景 artwork layer；只有真實 provider 圖片成功載入才顯示，選取變更清除舊圖，過期請求不得回寫。
- Player Dock 初始收合，展開時以緊湊控制台排列搜尋、目前播放、進度、播放控制、音量／模式與佇列；ResizeObserver 高度會影響 Catalog list 尺寸。
- 新增穩定 Skin component IDs：`catalog.selected-artwork-background`、`catalog.selected-work-stage`、`catalog.selected-work-details`；保留原有 query、selected record、audio 與 router owner。
- 四尺寸 Chromium matrix 148/148 PASS；focused Node 39/39 PASS；Architecture 1,358/0；JS/CJS syntax 205/205；Python AST 37/37。
- 仍未結案：真實曲庫、ANN/VNDB artwork、外部音訊、人工 Stable gate、Windows／真機。並排圖使用明確 fixture，不得當作 live data 證據。
