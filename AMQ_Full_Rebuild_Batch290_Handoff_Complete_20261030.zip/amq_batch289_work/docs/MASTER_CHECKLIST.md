> **接手總覽：** `docs/HANDOFF_MASTER_CURRENT_BATCH290.md`。Batch290 Mods 只有 registry/store，真實音訊、overlay、正式計分與 session transitions 仍未完成；全量 Node aggregate NOT VERIFIED。

# Batch290：Quiz Mods canonical owner 基礎
- [x] AMQ-290-001 `P0` 讀取 Batch289 handoff、最新工作狀態、主清單、Stable fidelity 規格及 `osu-game-modifiers.jpg`。
- [x] AMQ-290-002 `P0` 確認現有 Quiz session／AudioService／score owner；不改 session 狀態與音訊流程，記錄效果層缺口。
- [x] AMQ-290-003 `P0` 建立單一 Mods registry／selection store、倍率規則、互斥來源設定與本機持久化。
- [x] AMQ-290-004 `P0` 加入 registry、倍率、互斥、保存／恢復／reset／dispose contract tests。
- [x] AMQ-290-005 `P1` 更新 production/test script load order 與 Architecture Checker contract。
- [x] AMQ-290-011 `P1` Focused Mods／Quiz panel／Batch289 result-state tests 11/11 PASS；四尺寸 Quiz layout 55/55；Architecture 1,394/0；Python AST 40/40。
- [ ] AMQ-290-012 `P0` 全量 Node suite aggregate（120 秒逾時，無總結 exit code；不得視為通過）與 clean-extract 關鍵測試。
- [ ] AMQ-290-006 `P0` 實際 AudioService effect integration（Reverse／Fade Out／Beat Shuffle）及可測試 fallback。
- [ ] AMQ-290-007 `P0` Mods overlay／Settings 接線、鍵盤／ARIA／Skin role 與四尺寸畫面驗收。
- [ ] AMQ-290-008 `P0` 確認正式 score owner 並將倍率套用到真實分數（若計分仍不存在，記錄產品阻塞，不畫假倍率）。
- [ ] AMQ-290-009 `P0` Quiz session result transitions matrix 與 live session/audio 驗收。
- [ ] AMQ-290-010 `P0` 人工 osu! Stable 視覺 gate、live artwork／VNDB、HTTP-origin IndexedDB、Windows／手機實機驗收。

# Batch288：參考 AMQ 社群腳本修正答案搜尋
- [x] AMQ-288-001 `P0` 讀取使用者提供的 `AMQ-Scripts-master.zip` 並核對原始雜湊與 `amqAutocomplete.user.js` 搜尋行為。
- [x] AMQ-288-002 `P1` 在既有 autocomplete 增加多詞任意順序候選匹配，不覆寫官方／新版 prototype。
- [x] AMQ-288-003 `P1` 加入拉丁重音折疊搜尋，選項保留原始作品文字。
- [x] AMQ-288-004 `P1` 多詞高亮映射回原字串，保留字面匹配優先順序與既有 keyboard/IME 行為。
- [x] AMQ-288-005 `P0` 增加詞序與重音兩項回歸測試。
- [ ] AMQ-288-006 `P0` 真實 AMQ／Windows／手機端輸入體驗人工驗收。
- [ ] AMQ-288-007 `P0` 人工 osu! Stable 視覺 gate與其他 UI 差距繼續追蹤，不因本批功能修正而結案。

# Batch287 VNDB 角色欄與 Quiz UI 工作清單
- [x] AMQ-287-001 `P0` 重新確認使用者提供的 AMQ gameplay 參考圖與現有 Quiz DOM 位置。
- [x] AMQ-287-002 `P0` 擴充 VNDB adapter，新增 character endpoint 與 c-ID 驗證。
- [x] AMQ-287-003 `P0` 將 VNDB 角色設定放入 Settings 分類，不放入 Quiz 編輯表單。
- [x] AMQ-287-004 `P0` 新增 Quiz 底部角色欄，未配置有效圖片時隱藏。
- [x] AMQ-287-005 `P0` 支援新增／移除／去重／最多 8 個角色 ID。
- [x] AMQ-287-006 `P0` 保存角色 ID，並在面板重新掛載後恢復。
- [x] AMQ-287-007 `P0` 請求使用 AbortController 與 generation token，避免舊請求覆蓋新設定。
- [x] AMQ-287-008 `P1` 將角色欄與單一角色項目接入 Skin System；manifest/runtime/visual needs/CSS token 同步。
- [x] AMQ-287-009 `P0` 新增 VNDB adapter contract tests 與四尺寸之外的桌面／手機設定互動測試。
- [x] AMQ-287-010 `P0` 檢查角色欄空狀態，避免 AI 式註釋、假角色、假封面出現在遊戲畫面。
- [ ] AMQ-287-011 `P0` 真實 VNDB API 與人物圖片 HTTP 驗收（目前僅 contract fixture）。
- [ ] AMQ-287-012 `P0` 依原圖完成角色欄人工位置／尺寸驗收。
- [ ] AMQ-287-013 `P1` 完成 Quiz 答對／答錯／跳過／揭曉／下一題狀態與歷史紀錄整合。
- [ ] AMQ-287-014 `P1` 全量 Node 測試取得可追溯的 aggregate exit-code 證據。

---

# Batch285 Quiz UI 與 Route Layout 工作清單
- [x] AMQ-285-001 `P0` 直接開啟 Stable Intro 原圖並產生 AMQ Quiz 並排差距圖。
- [x] AMQ-285-002 `P0` 修正 body grid 自動把 header/main 排入不同欄位的根本問題。
- [x] AMQ-285-003 `P0` 功能頁主工作區全寬呈現，四尺寸驗證無水平溢位。
- [x] AMQ-285-004 `P0` 移除功能頁重複標題列，將 app status 放入 route bar；Home route bar 繼續隱藏。
- [x] AMQ-285-005 `P0` Quiz 設定區預設收合，保留原有設定 ID、資料、事件與持久化 owner。
- [x] AMQ-285-006 `P1` Quiz stage 抽象長條視覺改為低對比同心環／放射視覺，保留 Skin background token。
- [x] AMQ-285-007 `P0` App-shell Alt+Left 不再攔截輸入元件內的編輯操作。
- [x] AMQ-285-008 `P0` Answer suggestions 補 ArrowUp、Escape dismissal persistence、outside-click close tests。
- [x] AMQ-285-009 `P0` 新增四尺寸 route-grid／Quiz／Lobby browser regression，71/71 PASS。
- [x] AMQ-285-010 `P1` 更新原圖差距、UI traceability、工作狀態與交接提示。
- [ ] AMQ-285-011 `P0` 完成全量 Node suite 分組驗證與打包後乾淨目錄重跑。
- [ ] AMQ-285-012 `P0` 人工 osu! Stable visual gate、正式 audio／live data、Windows／真機驗收。
- [ ] AMQ-285-013 `P1` 調查 canonical Mods owner，無 owner 時先建立單一規則／狀態 owner，不得畫假控制。

---

# Batch284 Multiplayer／Quiz UI 工作（2026-10-30）
- [x] AMQ-284-001 `P0` 開啟 Stable Multiplayer Lobby 與 Intro 原圖，檢查正式 AMQ DOM/CSS/state owner
- [x] AMQ-284-002 `P0` 將 Multiplayer Lobby CSS 集中重整為緊湊 game-client 結構，保留原有房間／session owner
- [x] AMQ-284-003 `P0` 修正空房間狀態巨大留白：select 3 rows，單一 placeholder 78px
- [x] AMQ-284-004 `P0` 保留 source tabs、search、in-progress、refresh、join/create 控件與既有 Skin roles
- [x] AMQ-284-005 `P0` 收斂 Quiz stage、answer focus、autocomplete selected state、reduced-motion
- [x] AMQ-284-006 `P0` 修正 Batch272 browser harness 的隱藏導航 click，重新驗證 32/32
- [x] AMQ-284-007 `P0` 新增 Batch284 四尺寸 Quiz／Multiplayer browser regression，43/43 PASS
- [x] AMQ-284-008 `P0` 更新 Lobby visual contract，17/17 focused Node tests PASS
- [x] AMQ-284-009 `P1` 產生 Multiplayer／Quiz 與 Stable 原圖並排圖及差距表
- [x] AMQ-284-010 `P1` 更新 WORK_STATUS、MASTER_CHECKLIST、UI_TRACEABILITY、DESIGN_GAP_REGISTER、AI_START_HERE、README_FIRST、handoff、next prompt
- [ ] AMQ-284-011 `P0` Lobby server-backed room row visual、live server 與 chat/API 能力驗收
- [ ] AMQ-284-012 `P0` Quiz answer suggestion keyboard interactions：ArrowUp/Down、Enter、Escape、錯答後清空、shortcut conflict
- [ ] AMQ-284-013 `P0` Stable 人工視覺 gate、live audio、Windows／真機驗收
- [ ] AMQ-284-014 `P1` 查明 AMQ canonical Mods state/registry/multiplier/audio owner；未找到前不畫假 Mods

---

# Batch281 UI 工作（2026-10-30）
- [x] AMQ-281-001 `P0` 依使用者回饋設計 AMQ 音符＋問號原創品牌圖示，不使用大字 AMQ wordmark。
- [x] AMQ-281-002 `P0` 新增透明裁切圖示資產 `src/assets/amq-note-question.png`，保留合理尺寸與壓縮。
- [x] AMQ-281-003 `P0` 將 Home 初始標誌、空歷史 fallback 與功能頁返回首頁品牌統一改為圖示。
- [x] AMQ-281-004 `P0` 將首頁品牌圓盤背景改為低對比石墨色，避免與珊瑚紅圖示競爭。
- [x] AMQ-281-005 `P0` 新增 Skin runtime role `app.home.logo` 與 CSS consumer。
- [x] AMQ-281-006 `P0` 增加 logo role apply/reset 與 fallback contract tests。
- [x] AMQ-281-007 `P0` 四尺寸 Home/Catalog browser fixture 102/102 PASS。
- [x] AMQ-281-008 `P1` 輸出 Batch281 Home 截圖及 osu! Stable 並排差距圖。
- [x] AMQ-281-009 `P1` 更新 30 項 UI 清單、WORK_STATUS、traceability、gap register、handoff 與下一批提示。
- [ ] AMQ-281-010 `P0` 人工 osu! Stable 視覺 gate與正式作品 artwork 仍待完成。
- [ ] AMQ-281-011 `P0` Catalog Dock 對真實曲目列表的遮擋／可視列數仍待驗收。

---

# Batch280：Home 去除多餘外框與 30 項 UI 待辦追蹤（2026-10-30）

## 最新進度
- Home 已隱藏全域 header、側邊 route rail、底部最近學習面板；主視覺與六個入口使用完整 viewport。其他功能頁保留精簡水平導航。
- Catalog fixed player Dock left offset 已從舊側欄寬度改為 12px。
- Recent history 增加 nullish metadata 清理、長標題處理、鍵盤焦點樣式與穩定 component IDs。
- 驗證：Browser 102/102；focused Node 35/35；Batch280 contract 5/5；Architecture 1351/0；JS syntax PASS。App-shell browser test 逾時，未算 PASS。
- 30 項工作逐項狀態請見 `docs/BATCH279_UI_TASK_SELECTION.md`。只有實際有證據的程式項目標記完成；人工視覺 gate／正式資料／live provider 仍未結案。

## 核心完成規則
Home/Catalog 與 osu! Stable 人工視覺 gate 未通過前，不得標記 UI 結案。Layout fixture 不能代表 live catalog/artwork。不得重複探測已知被政策封鎖的 local HTTP origin。

---

- [x] AMQ-279-001 `P0` 讀取 Batch278 handoff／next prompt／主清單／工作狀態／UI traceability／gap register／Stable fidelity 規格
- [x] AMQ-279-002 `P0` 開啟 `artifacts/osu-reference/osu-main-menu.jpg` 並對照 Home 正式 CSS 與既有四尺寸截圖
- [x] AMQ-279-003 `P0` 從原有待辦挑選 30 項 UI 工作並建立追蹤索引 `docs/BATCH279_UI_TASK_SELECTION.md`
- [x] AMQ-279-004 `P0` Home 桌面入口選單高度上限 690px 並垂直置中，避免按鈕隨超高視窗不合理拉伸
- [x] AMQ-279-005 `P0` 壓縮 Home 空歷史狀態的視覺高度，不建立虛構作品／封面
- [x] AMQ-279-006 `P0` 將重疊的 Home feature CTA 移入 copy 區，確保桌面不遮擋右側六入口並保留導航／Skin ID
- [x] AMQ-279-007 `P0` Home/Catalog browser matrix 輸出路徑獨立至 `artifacts/batch279-home-menu/`
- [x] AMQ-279-008 `P0` 新增桌面 Home 空歷史區高度與 CTA 不重疊契約
- [x] AMQ-279-009 `P0` 四尺寸 Home/Catalog browser regression 90/90 PASS
- [x] AMQ-279-010 `P1` 更新本批 handoff、下一批提示與 UI traceability
- [ ] AMQ-279-011 `P0` 30 項清單中的 Catalog Dock／可視列數正式 UI 收斂
- [ ] AMQ-279-012 `P0` Home recent keyboard/focus 狀態與長標題回歸
- [ ] AMQ-279-013 `P0` Home/Catalog 對照 Stable 參考圖並關閉 P0 構圖／密度差距
- [ ] AMQ-279-014 `P0` 正式曲庫／合法 live artwork 封面驗收
- [ ] AMQ-279-015 `P0` 批准 runner 的 live provider／IndexedDB 結果追蹤
- [ ] AMQ-279-016 `P1` 逐項更新 `docs/BATCH279_UI_TASK_SELECTION.md` 中剩餘 21 項狀態

30 項原有工作完整清單見 `docs/BATCH279_UI_TASK_SELECTION.md`。本批完成 Batch279-001 至 010；後續工作仍由原清單中的 30 項逐步結案，不代表完成原清單所有 30 項。

# Batch278：批准 CI runner 真實 Origin 驗收路徑（2026-10-30）
- [x] AMQ-278-001 `P0` 讀取 Batch277 handoff、最新工作狀態、主清單、traceability、gap register、Stable 規格與 delivery policy
- [x] AMQ-278-002 `P0` 新增 GitHub Actions workflow，使用標準 runner 服務正式 `src/` HTTP origin
- [x] AMQ-278-003 `P0` 新增真實 `skinThemeStore` IndexedDB save/reload/cleanup Playwright acceptance
- [x] AMQ-278-004 `P0` 新增基於正式資料 ANNID 的 live ANN provider／圖片 decode 探測，不以 fixture 假冒 live
- [x] AMQ-278-005 `P0` workflow 無論測試結果都上傳 acceptance report artifact；IndexedDB 未通過則 job 失敗
- [x] AMQ-278-006 `P1` Workflow contract 6/6 PASS，Python AST 新增腳本 PASS
- [ ] AMQ-278-007 `P0` 在可執行 GitHub Actions 的 repository 觸發 workflow 並取得 acceptance-report.json（尚未觸發）
- [ ] AMQ-278-008 `P0` 依 runner 真實結果修正／驗收 IndexedDB save/reload
- [ ] AMQ-278-009 `P0` 依 live provider 結果驗收 ANN response、圖片 load/decode 與 attribution
- [ ] AMQ-278-010 `P0` Home/Catalog 人工 osu! Stable 並排視覺 gate
- [ ] AMQ-278-011 `P0` 外部 AMQ/EMQ 可聽音訊與 Windows／實機鍵盤／觸控驗收

# Batch277：Artwork Provider Diagnostics（2026-10-30）
- [x] AMQ-277-001 `P0` 讀取 Batch276 handoff／next prompt／工作狀態／清單／traceability／差距表／Stable 規格與封裝政策
- [x] AMQ-277-002 `P0` 建立獨立 Batch277 工作副本，不覆寫 Batch275/276 ZIP，不初始化缺失 Git
- [x] AMQ-277-003 `P0` 建立 ANN/AniList/VNDB available/missing/skipped/error diagnostics，保留既有 fallback 順序
- [x] AMQ-277-004 `P0` 診斷事件只記錄穩定錯誤碼與來源／作品類型，不記錄作品標題、外部 ID、URL 或原始錯誤
- [x] AMQ-277-005 `P0` 增加診斷事件上限、getter 與 clear API，避免診斷記錄無限成長
- [x] AMQ-277-006 `P0` 將 provider diagnostics 注入 artwork adapter；對外 getter 只輸出白名單欄位
- [x] AMQ-277-007 `P0` 新增 diagnostics 隱私、上限、成功與失敗回歸測試，Focused Node 19/19 PASS
- [x] AMQ-277-008 `P0` 新增正式 AMQ/EMQ source data artwork ID coverage audit 工具與 fixture test；結果報告保留在 artifacts
- [x] AMQ-277-009 `P1` 全量 Node 99 files 分 20 組，35/35 exit 0、310/310 subtests PASS
- [x] AMQ-277-010 `P1` Architecture 1,344 PASS／0 FAIL、JS/CJS 194/194、Python AST 34/34
- [ ] AMQ-277-011 `P0` 批准 browser/CI runner 上的 live ANN/VNDB/AniList response、圖片 decode 與 attribution acceptance
- [ ] AMQ-277-012 `P0` 在允許的正式 app origin 驗證 IndexedDB save/reload（目前瀏覽器在 document load 前封鎖）
- [ ] AMQ-277-013 `P0` Home/Catalog 人工 osu! Stable 並排視覺 gate；自動幾何測試不能替代
- [ ] AMQ-277-014 `P0` 外部 AMQ/EMQ 實際可聽音訊與 Windows／實機鍵盤／觸控驗收
- [ ] AMQ-277-015 `P1` 將 provider diagnostic outcome 與正式作品封面成功率報告接入批准 runner 的 E2E 報告

# Batch276 工作項目（Artwork provider wiring + Catalog load lifecycle）

- [x] AMQ-276-001 `P0` 讀取 Batch275 handoff、next prompt、WORK_STATUS、MASTER_CHECKLIST、UI traceability、gap register、delivery policy 與來源檔
- [x] AMQ-276-002 `P0` 確認 Batch275 Home/Catalog 改動與最新測試證據，保留單一 artwork/cache/history owner
- [x] AMQ-276-003 `P0` 修正 Catalog artwork：圖片 load 前維持 `loading`、保留可讀標題 fallback，只有 `load` 後才設 `available`
- [x] AMQ-276-004 `P0` 圖片 `error` 時恢復 fallback 並移除過期 source attribution link；source link 只接受 HTTPS
- [x] AMQ-276-005 `P0` 新增／更新 Catalog integration 與 CSS contracts，驗證 loading → available → error 狀態和 attribution lifecycle
- [x] AMQ-276-006 `P0` 將 AniList feature adapter 與 external-service client 真正接入 artwork provider factory；ANN 仍是首選，AniList 僅在無 ANN 圖且有明確 crosswalk 時 fallback
- [x] AMQ-276-007 `P0` 將 crosswalk/chinese-title provider 由 artwork composition boundary 建立並共享給 Catalog，避免 app.js 直接讀取 `AMQData`、避免重複實例與錯誤 dispose
- [x] AMQ-276-008 `P0` AniList adapter 設為可選依賴；缺失時不應讓 ANN/VNDB artwork 整條管線失效
- [x] AMQ-276-009 `P0` 新增 provider factory auto-crosswalk lifecycle test、app composition lifecycle test 與 shared-provider Catalog ownership test
- [x] AMQ-276-010 `P1` 全量 Node 98 files 分 20 組，35/35 exit 0、306/306 subtests PASS
- [x] AMQ-276-011 `P1` Architecture 1,335 PASS／0 FAIL、JS/CJS syntax 192/192、Python AST 36/36
- [ ] AMQ-276-012 `P0` Live ANN/VNDB/AniList external network、實際作品封面與正式曲庫驗收；測試目前只證明 mock/factory contract
- [ ] AMQ-276-013 `P0` IndexedDB real app-origin save/reload；local HTTP/HTTPS app navigation 仍遭 `ERR_BLOCKED_BY_ADMINISTRATOR`
- [ ] AMQ-276-014 `P0` 人工 osu! Stable visual gate、外部 AMQ/EMQ 可聽音訊、Windows／實機驗收

# Batch275 工作項目（Home Stable 構圖、Artwork fallback／Skin role 接線）

- [x] AMQ-275-001 `P0` 讀取規範、Batch274 交接、主清單、traceability、gap register 與 Stable fidelity 規格；確認來源 ZIP 與工作副本獨立
- [x] AMQ-275-002 `P0` 開啟 `artifacts/osu-reference/osu-main-menu.jpg` 並對照正式 `src/ui/app-shell.js`、`src/styles/ui-design-landing.css`
- [x] AMQ-275-003 `P0` 將 Home 主視覺改為大型圓形 AMQ 品牌層與右側斜切選單重疊構圖，保留真實 artwork 優先邏輯
- [x] AMQ-275-004 `P0` 無 playback history 時使用明確品牌 fallback，不虛構作品封面／播放紀錄
- [x] AMQ-275-005 `P0` 為 Home artwork、brand mark、feature action 與六個 menu targets 加入穩定 `data-skin-component` IDs
- [x] AMQ-275-006 `P0` 將 `app.home.primary-action` Skin role 接到 CTA 與六個正式選單按鈕；`app.home.welcome-visual` 接到圓形 artwork surface
- [x] AMQ-275-007 `P0` 修正 artwork fallback 清除已失效的 provider／attribution／source URL metadata
- [x] AMQ-275-008 `P0` 新增 Home artwork 瀏覽器契約，驗證歷史資料、真實 provider metadata、壞圖 fallback 與 metadata 清理；14/14 PASS
- [x] AMQ-275-009 `P0` Home/Catalog 四尺寸 Chromium 回歸更新至 85/85 PASS，最新 JPEG 截圖位於 `artifacts/batch275-home-menu/`
- [x] AMQ-275-010 `P0` Skin theme adapter tests 21/21 PASS，確認 Home welcome／primary roles target 與 reset
- [x] AMQ-275-011 `P1` focused artwork/Catalog/Skin/CSS tests 51/51 PASS
- [x] AMQ-275-012 `P1` 更新本批差距／traceability／工作狀態與交接，保留來源和測試限制
- [x] AMQ-275-017 `P0` 全量 Node 98 files 分 20 組，35/35 exit 0、305/305 subtests PASS；Architecture 1,335/0、JS/CJS 192/192、Python AST 36/36
- [x] AMQ-275-018 `P0` Catalog artwork 狀態修正：圖片成功 `load` 前維持 loading 並保留可讀 fallback；只有 load 後才標記 available／顯示來源連結，error 時移除過期來源連結；integration + CSS contract PASS
- [ ] AMQ-275-013 `P0` Live ANN/VNDB 封面與正式 Home/Catalog 曲庫驗收；外部 provider response／正式 runtime 證據仍不足
- [ ] AMQ-275-014 `P0` 人工 osu! Stable visual gate；自動布局通過不等於人工像素驗收
- [ ] AMQ-275-015 `P0` IndexedDB browser persistence；HTTPS localhost 導航亦遭 `ERR_BLOCKED_BY_ADMINISTRATOR`，不再重試／繞過政策
- [ ] AMQ-275-016 `P0` 外部 AMQ/EMQ audio 可聽播放、Windows／實機與正式多瀏覽器驗收

# Batch273 工作項目（Skin component mapping + Multiplayer route apply/fallback/reset + AMQ 社群腳本考證）

- [x] AMQ-273-001 `P0` 讀取專案規範、工作狀態、主清單、最新交接、next prompt、UI traceability、設計差距與 osu! 忠實重建規格
- [x] AMQ-273-002 `P0` 確認 Batch272 ZIP SHA-256、674 entries、CRC 與無 Git 工作環境；不覆寫來源
- [x] AMQ-273-003 `P0` UI 工作前開啟 osu! Stable Main Menu 與 Multiplayer Lobby 參考圖並對照既有正式 DOM／CSS owner
- [x] AMQ-273-004 `P0` 修正三個 Multiplayer Lobby roles 改用穩定 `data-skin-component` selector
- [x] AMQ-273-005 `P0` 為多人玩家列表、動態 player row 與 ready-state 建立明確 component ID，維持唯一 room/session state owner
- [x] AMQ-273-006 `P0` 新增 Skin component mapping contract test（2/2）
- [x] AMQ-273-007 `P0` 新增 Quiz route Multiplayer Skin apply／missing fallback／reset／scope browser matrix（5 roles）
- [x] AMQ-273-008 `P0` 執行 focused Node contracts 38/38 PASS
- [x] AMQ-273-009 `P0` 執行 Multiplayer 四尺寸 Chromium geometry 32/32 PASS
- [x] AMQ-273-010 `P1` 核對使用者提供的 AMQ Scripts ZIP 完整性、SHA-256 並保留原始 archive
- [x] AMQ-273-011 `P1` 定向稽核答案時間、玩家答案顯示、autocomplete、dropdown 與背景腳本，記錄禁止直接移植的內部耦合
- [x] AMQ-273-018 `P0` 依 osu! Stable Main Menu 參考圖實作斜切紫色主選單按鈕、右側圖示與 reduced-motion fallback
- [x] AMQ-273-019 `P0` 新增 Home/Catalog 四尺寸 browser matrix，81/81 PASS；截圖與差距表保存於 `artifacts/batch273-home-menu/`
- [x] AMQ-273-012 `P1` 更新 WORK_STATUS、MASTER_CHECKLIST、UI_TRACEABILITY、DESIGN_GAP_REGISTER、handoff、next prompt、AI_START_HERE、README_FIRST
- [ ] AMQ-273-013 `P0` Home/Catalog 正式曲庫與真實 artwork／provider 實機驗收（外部環境未提供可驗證結果）
- [ ] AMQ-273-014 `P0` Home、Catalog、Quiz、Multiplayer 人工 Stable 視覺 gate
- [ ] AMQ-273-015 `P0` HTTP-origin IndexedDB；目前環境 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重複同一探測
- [ ] AMQ-273-016 `P0` Live audio／multiplayer E2E；全量 `node --test tests/*.test.cjs` 已嘗試但逾時，aggregate 未驗證
- [ ] AMQ-273-017 `P1` Windows／實機鍵盤、觸控及多瀏覽器驗收

# Batch272 工作項目（Multiplayer Lobby 正式 UI 切片）

- [x] AMQ-272-001 `P0` 閱讀 AGENTS、AI_START_HERE、README_FIRST、WORK_STATUS、MASTER_CHECKLIST、UI_TRACEABILITY、DESIGN_GAP_REGISTER、UI_COPY_POLICY、Stable fidelity prompt 與 Batch271 handoff
- [x] AMQ-272-002 `P0` 檢查 Stable multiplayer 參考圖與原有 DOM/CSS/handlers/server room state owner
- [x] AMQ-272-003 `P0` 將多人 UI 改為標題／狀態、來源 tabs、搜尋／進行中篩選、房間清單、加入與建立房間的完整工作區
- [x] AMQ-272-004 `P0` 保留唯一 `client.listRooms()` 與 room session/server snapshot owner，不插入假房間資料
- [x] AMQ-272-005 `P0` 實作 All/AMQ/EMQ/MIX 本地來源篩選並同步 `aria-pressed`
- [x] AMQ-272-006 `P1` 實作房間搜尋與 server `phase === round` 進行中篩選
- [x] AMQ-272-007 `P1` 顯示真實房間 ID、來源、人數、phase；不虛構玩家頭像、曲目封面或分數
- [x] AMQ-272-008 `P0` 新增三個穩定 Skin component roles 與 runtime token consumer
- [x] AMQ-272-009 `P0` 同步更新 role manifest 與 `skin-contract.js` embedded contract
- [x] AMQ-272-010 `P1` 替換原 Multiplayer CSS 區塊為集中式 Lobby 樣式並加入響應式堆疊
- [x] AMQ-272-011 `P0` 新增 Multiplayer Lobby visual contract tests
- [x] AMQ-272-012 `P0` 新增四尺寸 Chromium geometry harness 與最新截圖
- [x] AMQ-272-013 `P0` 四尺寸 browser geometry 32/32 PASS，無水平溢位／page errors
- [x] AMQ-272-014 `P0` focused Node contracts 67/67 PASS
- [x] AMQ-272-015 `P0` 建立 Stable 參考區域對照與未完成差距表
- [x] AMQ-272-016 `P1` 盤點 Mod owner：未找到 canonical state/multiplier/audio transformation owner，記錄阻塞且不虛構 overlay
- [x] AMQ-272-017 `P1` 記錄聊天區、玩家槽位／頭像、歌曲縮圖與 Stable 底部操作列的資料／功能缺口
- [ ] AMQ-272-018 `P0` 登入狀態下 live multiplayer API／room lifecycle E2E，當前環境未執行
- [ ] AMQ-272-019 `P0` multiplayer chat owner 與 server protocol/API 是否擴充的產品決策
- [ ] AMQ-272-020 `P0` Home 真實 artwork／Catalog 正式資料與人工 Stable 視覺 gate
- [x] AMQ-272-021 `P1` 新 Skin roles 的實際 OSK apply/fallback/reset 瀏覽器驗收（Batch273 5 個多人 roles apply/fallback/reset 5/5；其餘角色依 route coverage 持續驗收）
- [ ] AMQ-272-022 `P1` AMQ Mod registry/state/multiplier/audio owner 設計與單元測試
- [x] AMQ-272-023 `P0` 更新 WORK_STATUS、UI_TRACEABILITY、DESIGN_GAP_REGISTER、AI_START_HERE、README_FIRST、NEXT_SESSION_PROMPT 與 handoff
- [x] AMQ-272-024 `P0` 重建完整 MANIFEST.sha256、交付 ZIP 與 SHA-256 sidecar
- [x] AMQ-272-025 `P0` 封裝前執行 ZIP integrity、manifest verify 與源資料 SHA 校驗
- [x] AMQ-272-026 `P0` Architecture checker 1,328/0；JS/CJS syntax 200/200；Python AST 30/30
- [x] AMQ-272-027 `P1` 記錄全量 Node suite 超出時間窗口，未取得 aggregate，不宣稱通過

# Batch271 工作項目（osu! 原始碼研究＋忠實重建規格）

- [x] AMQ-271-001 `P0` 閱讀 AGENTS、AI_START_HERE、README_FIRST、WORK_STATUS、MASTER_CHECKLIST、UI traceability、設計流程／差距、UI copy policy 與 Batch270 handoff
- [x] AMQ-271-002 `P0` 確認使用者上傳 `/mnt/data/osu-master.zip` 存在且可讀取
- [x] AMQ-271-003 `P0` 記錄來源 ZIP SHA-256、項目數及 commit hash 不可驗證限制
- [x] AMQ-271-004 `P0` 定向檢查 MainMenu、MainMenuButton、SongSelect、Carousel、SkinManager、DefaultLegacySkin、LegacySkin、LegacySkinDecoder、ModSelectOverlay
- [x] AMQ-271-005 `P1` 確認上游 ZIP 不可被視為完整 osu!stable 原始碼／預設 Skin 可匯出包
- [x] AMQ-271-006 `P0` 建立 `docs/OSU_SOURCE_RESEARCH_BATCH271.md`，記錄檔案、行為發現與證據限制
- [x] AMQ-271-007 `P0` 建立 `docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`，涵蓋五張圖逐頁結構與 OSK 元件契約
- [x] AMQ-271-008 `P0` 更新本清單、WORK_STATUS、UI_TRACEABILITY、DESIGN_GAP_REGISTER、NEXT_SESSION_PROMPT、handoff、AI_START_HERE、README_FIRST、AGENTS
- [ ] AMQ-271-009 `P0` Batch272 依提示詞實作 Multiplayer Lobby 的正式 DOM／CSS 切片，保留單一 server/state owner
- [ ] AMQ-271-010 `P0` Batch272 逐項映射 Multiplayer 參考圖的標題、模式列、搜尋、房間列、玩家槽位、底部操作區、聊天區
- [ ] AMQ-271-011 `P0` Batch272 產生 1920×1080、1440×900、1024×768、390×844 對照截圖與差距表
- [ ] AMQ-271-012 `P1` 盤點 AMQ Mod owner、規則、互斥與 multiplier；未有 owner 時記錄阻塞，不虛構倍率
- [x] AMQ-271-013 `P0` 檢查 Skin Registry／OSK mapper 對應穩定 componentId，而不是只綁 CSS class（Batch273 完成 Multiplayer roles／player list 的穩定 component ID；全域 mapper audit 仍持續進行）
- [ ] AMQ-271-014 `P0` 確認 OSK parser 的路徑穿越、資源耗盡、重複路徑與損壞圖片測試覆蓋
- [ ] AMQ-271-015 `P0` 保留 Home/Catalog 真實 artwork、正式曲庫、人工 Stable 視覺 gate 未通過狀態
- [ ] AMQ-271-016 `P1` 執行 Batch272 focused tests、JS/CJS/Python syntax 與可用架構檢查，記錄未跑測試
- [x] AMQ-271-017 `P0` 更新同一份工作清單與狀態文件，封裝新 ZIP／SHA-256
- [x] AMQ-271-018 `P1` 將使用者提供的官方 `osu-master.zip` 原封不動保留於 `references/`，以供後續 AI 持續研究

# Batch270 工作項目（持續主清單）

- [x] AMQ-270-001 `P0` 閱讀 AGENTS、AI_START_HERE、README_FIRST、WORK_STATUS、MASTER_CHECKLIST、traceability、設計流程／差距與 UI_COPY_POLICY
- [x] AMQ-270-002 `P0` 檢查 Batch269 handoff、現有 Home/Catalog DOM owner、CSS 及相關測試契約
- [x] AMQ-270-003 `P0` 將使用者提供的五張 osu! 官方 Wiki 介面參考圖加入封包
- [x] AMQ-270-004 `P1` 建立官方參考圖到 AMQ Home/Catalog/Multiplayer/Mods 的對應文件
- [x] AMQ-270-005 `P0` Home 桌面布局改成左主視覺、右側縱向功能入口、下方近期學習
- [x] AMQ-270-006 `P1` Home 900px 以下改為堆疊式布局，手機主要入口兩欄
- [x] AMQ-270-007 `P0` playback-history API 缺失時仍由原 render owner 顯示空狀態
- [x] AMQ-270-008 `P0` 更新 Home CSS contract，移除過時的一列入口布局假設
- [x] AMQ-270-009 `P0` 新增 Batch270 四尺寸 Home/Catalog browser regression
- [x] AMQ-270-010 `P0` 四尺寸 Home/Catalog 77/77 PASS
- [x] AMQ-270-011 `P1` 保留 Catalog 既有 query/data/audio owner、封面與選取狀態
- [x] AMQ-270-012 `P1` 產生 Home/Catalog/error fixture 最新四尺寸截圖並轉為 JPEG
- [x] AMQ-270-013 `P1` 將舊 Batch269 截圖由最新交付包移除，保留最新證據與官方參考圖
- [x] AMQ-270-014 `P1` 更新 WORK_STATUS、MASTER_CHECKLIST、UI_TRACEABILITY、DESIGN_GAP_REGISTER、handoff、next prompt、AI_START_HERE、README_FIRST
- [x] AMQ-270-021 `P0` Architecture Checker 1,321 PASS／0 FAIL
- [x] AMQ-270-022 `P1` Catalog unit 6/6、Catalog integration、source-runtime integration、navigation 2/2、Quiz UI state 5/5
- [ ] AMQ-270-015 `P0` Home 真實 playback history artwork 的人工視覺 gate仍未通過
- [ ] AMQ-270-016 `P0` Catalog 正式 25／50 首、live artwork、詳情與 Dock 未驗收
- [ ] AMQ-270-017 `P0` Multiplayer Lobby 視覺切片待處理
- [ ] AMQ-270-018 `P1` AMQ Mod／遊戲條件 UI owner 與倍率規則待盤點
- [ ] AMQ-270-019 `P0` HTTP-origin IndexedDB 仍受環境政策阻擋，不重複探測
- [ ] AMQ-270-020 `P0` 全量 Node suite、live audio/provider、Windows／實機與人工 osu! 視覺 gate未驗收

# Batch267 工作項目（持續主清單）

- [x] AMQ-267-001 `P0` 從 Batch266 工作副本接手，不覆寫來源 ZIP、不初始化 Git
- [x] AMQ-267-002 `P0` 閱讀規範、最新狀態、主清單、traceability、設計差距、文案政策與 Batch266 handoff
- [x] AMQ-267-003 `P1` 檢查 Batch263 Home/Catalog 四尺寸基準截圖與差距表
- [x] AMQ-267-004 `P1` 將 Batch261–263 重複 Home/Catalog CSS 區段替換為單一維護區段
- [x] AMQ-267-005 `P1` Home 主要入口由六張高卡片改為桌面單列緊湊操作列
- [x] AMQ-267-006 `P1` Home 主視覺縮短，避免無歷史時只留下巨型抽象圖形
- [x] AMQ-267-007 `P1` Home 平板三欄兩列與手機兩欄三列入口布局
- [x] AMQ-267-008 `P1` 保留最近學習唯一 playback-history owner 與誠實空狀態
- [x] AMQ-267-009 `P1` Catalog 正式三欄 owner 與既有 Skin／query/data/audio 接線保持不變
- [x] AMQ-267-010 `P1` Catalog 曲目列與封面縮圖密度收斂
- [x] AMQ-267-011 `P1` 保留桌面底部播放 Dock、平板兩欄、手機單欄
- [x] AMQ-267-012 `P0` 新增四尺寸 Home/Catalog browser layout harness
- [x] AMQ-267-013 `P0` 四尺寸 Home/Catalog layout assertions 63/63 PASS
- [x] AMQ-267-014 `P1` 產生四尺寸 Home 截圖與 Catalog fixture／opaque-origin error 截圖
- [x] AMQ-267-015 `P1` 更新 UI shell CSS contract 以保護新的 Home/Catalog 版面
- [x] AMQ-267-016 `P1` Settings、Results、Quiz focused contracts 回歸
- [x] AMQ-267-017 `P1` JavaScript syntax 與 Python AST compile
- [x] AMQ-267-018 `P1` 更新 WORK_STATUS、UI_TRACEABILITY、DESIGN_GAP_REGISTER、handoff、next prompt 與 AI start
- [x] AMQ-267-023 `P1` App Shell browser regression 輸出 144/144 PASS（wrapper 在摘要後清理階段超時，無殘留程序）
- [ ] AMQ-267-019 `P0` 全量 Node suite aggregate，本批未執行
- [ ] AMQ-267-020 `P0` HTTP-origin IndexedDB／正式 Catalog runtime／live artwork 仍受環境或外部 gate 限制
- [ ] AMQ-267-021 `P0` Home/Catalog 人工 osu! 視覺 gate 未通過
- [ ] AMQ-267-022 `P1` Windows／實機觸控與鍵盤驗收

# Batch266 工作項目（持續主清單）

- [x] AMQ-266-001 `P0` 以 Batch265 ZIP 建立獨立工作副本，不覆寫來源
- [x] AMQ-266-002 `P0` 閱讀 AGENTS、AI_START_HERE、WORK_STATUS、MASTER_CHECKLIST、UI traceability、design flow/gap、copy policy 與 Batch265 handoff
- [x] AMQ-266-003 `P1` 盤點 Settings 原有五個面板及狀態 owner
- [x] AMQ-266-004 `P1` 建立 Settings 分類 tablist 與內容框架
- [x] AMQ-266-005 `P1` 保留 workspace preferences 原 ID／Store 與快捷鍵控制
- [x] AMQ-266-006 `P1` 保留帳號 panel 與其原狀態 owner
- [x] AMQ-266-007 `P1` 保留 Backup/Restore panel 與 fail-closed 流程
- [x] AMQ-266-008 `P1` 保留 Database Update panel 與原操作
- [x] AMQ-266-009 `P1` 保留 OSK import／Skin Mapping Studio panel
- [x] AMQ-266-010 `P1` 新增 tab ARIA roles、selected state 與 panel linkage
- [x] AMQ-266-011 `P1` 新增方向鍵、Home、End 分類鍵盤導覽
- [x] AMQ-266-012 `P1` 桌面固定 Settings 外框，內容區內部捲動
- [x] AMQ-266-013 `P1` 手機分類導覽改為兩欄並保留內部捲動
- [x] AMQ-266-014 `P1` 移除 Results 裝飾性英文序號 pseudo-element，而非以 CSS 隱藏
- [x] AMQ-266-015 `P1` Multiplayer panel 恢復可讀 Skin gradient overlay
- [x] AMQ-266-016 `P1` 新增 Settings workspace contract 3/3
- [x] AMQ-266-017 `P1` 新增 Settings/Results/Multiplayer 四尺寸 browser matrix 58/58
- [x] AMQ-266-018 `P1` 產生 16 張正式 DOM/CSS fixture／empty-state 截圖
- [x] AMQ-266-019 `P1` App Shell browser regression 144/144
- [x] AMQ-266-020 `P1` Quiz visual regression 38/38
- [x] AMQ-266-021 `P1` Results contract 7/7、Quiz UI state 5/5、UI shell CSS 8/8
- [x] AMQ-266-022 `P1` Batch265 visual structure contract 擴充後 6/6
- [x] AMQ-266-023 `P1` JS syntax 與 Python AST compile
- [x] AMQ-266-024 `P1` 修正 App Shell regression 中的 CSS grid track 計數器，避免把 `minmax()` 內空格誤算為多欄
- [x] AMQ-266-025 `P1` 更新 WORK_STATUS、UI_TRACEABILITY、DESIGN_GAP_REGISTER、DESIGN_LANDING_FLOW
- [x] AMQ-266-026 `P1` 更新 handoff、next prompt、AI_START_HERE 與 Manifest
- [ ] AMQ-266-027 `P0` 全量 Node suite aggregate，尚未執行
- [ ] AMQ-266-028 `P0` HTTP-origin IndexedDB／正式曲庫驗收，環境 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞
- [ ] AMQ-266-029 `P0` live artwork／audio／multiplayer E2E
- [ ] AMQ-266-030 `P0` Home/Catalog P0 視覺差距關閉與人工 osu! 參考圖 gate
- [ ] AMQ-266-031 `P1` Settings 真實設定保存、OSK 匯入、備份還原的瀏覽器端到端流程
- [ ] AMQ-266-032 `P1` Windows／實機觸控與鍵盤驗收
- [ ] AMQ-266-033 `P1` Results 已保存回合資料的正式截圖／人工對照

## Batch265 工作項目

- [x] AMQ-265-001 `P0` 從提供的 Batch264 ZIP 建立獨立 Batch265 副本
- [x] AMQ-265-002 `P0` 閱讀 AGENTS、AI start、README、工作狀態、主清單與 UI 設計文件
- [x] AMQ-265-003 `P0` 保留正式 DOM 與狀態 owner，不建立重複多人／結果狀態
- [x] AMQ-265-004 `P1` 收斂 Quiz 設定區控制密度與間距
- [x] AMQ-265-005 `P1` 保留 advanced filter 的 details disclosure 行為
- [x] AMQ-265-006 `P1` 以獨立視覺表面區分 Multiplayer panel
- [x] AMQ-265-007 `P1` 將 Results 空狀態／結果列表改為緊湊舞台層級
- [x] AMQ-265-008 `P1` 保留 Results 空狀態誠實文案與原本導回 Quiz 操作
- [x] AMQ-265-009 `P2` 收斂 Learning statistics summary spacing，不製造虛構統計
- [x] AMQ-265-010 `P0` 新增視覺結構 contract test
- [x] AMQ-265-011 `P1` 執行 Results UI contract 7/7
- [x] AMQ-265-012 `P1` 執行 Quiz UI state contract 5/5
- [x] AMQ-265-013 `P1` 執行 Quiz 四尺寸 browser regression 38/38
- [x] AMQ-265-014 `P1` 執行 JS syntax 與 Python AST compile
- [ ] AMQ-265-015 `P0` App Shell browser regression 完成；本次執行超時，需在可用窗口重跑
- [ ] AMQ-265-016 `P0` 全量 Node suite aggregate
- [ ] AMQ-265-017 `P0` HTTP-origin Catalog／IndexedDB 真實環境驗收
- [ ] AMQ-265-018 `P0` live artwork／audio／multiplayer E2E
- [ ] AMQ-265-019 `P1` Results／Multiplayer 正式四尺寸截圖與人工參考對照
- [ ] AMQ-265-020 `P1` Settings 工作區正式分區設計與實作
- [ ] AMQ-265-021 `P0` Home／Catalog／Quiz／Results／Settings 人工 osu! 視覺 gate


## Batch264 工作項目

> `[x]` 表示本批有實際證據；`[ ]` 為未完成／外部環境或後續工作。

- [x] AMQ-264-001 `P0` 從 Batch263 建立獨立 Batch264 工作副本並保留原 ZIP
- [x] AMQ-264-002 `P0` 閱讀規範、狀態、主清單、traceability、設計流程與最新交接
- [x] AMQ-264-003 `P0` 確認工作副本沒有 Git，不初始化 Git
- [x] AMQ-264-004 `P0` 盤點正式 Quiz DOM 與既有 JS 狀態 owner
- [x] AMQ-264-005 `P0` 確認 Quiz 問題、音訊、答案、操作與設定的 DOM ID 未重複
- [x] AMQ-264-006 `P0` 將 Quiz live round 置於設定區之前顯示
- [x] AMQ-264-007 `P0` 保留單人 Quiz 正式題目舞台與答案表單
- [x] AMQ-264-008 `P0` 保留 AMQ／EMQ／MIX 模式與既有狀態 owner
- [x] AMQ-264-009 `P0` 保留本輪摘要與音訊狀態標籤
- [x] AMQ-264-010 `P0` 強化題目舞台在桌面上的視覺優先級
- [x] AMQ-264-011 `P1` 縮減本輪摘要的卡片化與間距
- [x] AMQ-264-012 `P1` 強化答案輸入欄位的視覺辨識與觸控尺寸
- [x] AMQ-264-013 `P1` 收斂 Quiz 控制列視覺與主要操作層級
- [x] AMQ-264-014 `P1` 手機 Quiz 控制按鈕最小高度提高至 46px
- [x] AMQ-264-015 `P1` 手機答案輸入與提交按鈕改為垂直堆疊
- [x] AMQ-264-016 `P1` 桌面本輪摘要維持四欄布局
- [x] AMQ-264-017 `P1` 手機本輪摘要維持兩欄布局
- [x] AMQ-264-018 `P1` 移除題目舞台裝飾性同心圓
- [x] AMQ-264-019 `P1` 移除 Quiz 區段裝飾數字
- [x] AMQ-264-020 `P1` 移除 QUESTION POOL 英文裝飾眉標
- [x] AMQ-264-021 `P1` 移除產品 UI 內工程驗收註記
- [x] AMQ-264-022 `P1` 保留必要的錯誤、狀態與可存取性文案
- [x] AMQ-264-023 `P1` 維持 Skin quiz background role 的實際作用範圍
- [x] AMQ-264-024 `P1` 維持 Reduced motion 全域規則
- [x] AMQ-264-025 `P0` 新增正式 Quiz 四尺寸 browser visual harness
- [x] AMQ-264-026 `P0` 驗證 1920×1080 Quiz route 與主要 DOM owner
- [x] AMQ-264-027 `P0` 驗證 1440×900 Quiz route 與主要 DOM owner
- [x] AMQ-264-028 `P1` 驗證 1024×768 Quiz 響應式布局
- [x] AMQ-264-029 `P1` 驗證 390×844 Quiz 響應式布局
- [x] AMQ-264-030 `P0` 四尺寸檢查無水平溢位
- [x] AMQ-264-031 `P0` 四尺寸檢查題目舞台內容不溢位
- [x] AMQ-264-032 `P1` 四尺寸檢查遊玩區顯示在設定區之前
- [x] AMQ-264-033 `P1` 四尺寸檢查答案與提交控制可見
- [x] AMQ-264-034 `P1` 四尺寸檢查音訊狀態 owner 可見
- [x] AMQ-264-035 `P1` 四尺寸截圖明確使用 UI fixture 命名
- [x] AMQ-264-036 `P1` 文件明確聲明 fixture 不代表 live audio/data 成功
- [x] AMQ-264-037 `P0` 執行 Quiz visual browser harness 並修正首次失敗
- [x] AMQ-264-038 `P0` 執行 App Shell browser regression 至 144/144
- [x] AMQ-264-039 `P1` 更新 App Shell 舊圓角契約至新 UI 表面
- [x] AMQ-264-040 `P1` 確認手機 Quiz 控制觸控高度契約通過
- [x] AMQ-264-041 `P1` 執行 Quiz clock tests
- [x] AMQ-264-042 `P1` 執行 Quiz engine tests
- [x] AMQ-264-043 `P1` 執行 Quiz panel integration tests
- [x] AMQ-264-044 `P1` 執行 Quiz pool tests
- [x] AMQ-264-045 `P1` 執行 Quiz session tests
- [x] AMQ-264-046 `P1` 執行 Quiz UI state contract
- [x] AMQ-264-047 `P1` 執行 navigation contract
- [x] AMQ-264-048 `P1` 執行 Skin adapter tests
- [x] AMQ-264-049 `P1` 執行 Catalog focused tests
- [x] AMQ-264-050 `P1` 執行 Architecture Checker
- [x] AMQ-264-051 `P1` 執行 JavaScript 語法檢查與 Python AST compile
- [x] AMQ-264-052 `P0` 保留全量 Node suite 未執行的限制，不宣稱全量通過
- [x] AMQ-264-053 `P0` 保留 HTTP-origin IndexedDB 與 live provider 未驗收狀態
- [x] AMQ-264-054 `P0` 將 Quiz 最終 osu! 視覺驗收保持未通過
- [x] AMQ-264-055 `P1` 更新 WORK_STATUS、UI_TRACEABILITY 與 DESIGN_GAP_REGISTER
- [x] AMQ-264-056 `P1` 更新 HANDOFF、NEXT_SESSION_PROMPT 與 AI_START_HERE
- [x] AMQ-264-057 `P1` 更新 MANIFEST.sha256 並逐項驗證封包內容
- [x] AMQ-264-058 `P1` 建立 Batch264 ZIP 與 SHA-256 sidecar
- [x] AMQ-264-059 `P1` 驗證 ZIP CRC、外部 SHA-256 與 Manifest
- [ ] AMQ-264-060 `P0` 在可用 HTTP-origin 環境驗證正式 Catalog／IndexedDB
- [ ] AMQ-264-061 `P0` 驗證真實音訊播放、計時與音源失敗備援
- [ ] AMQ-264-062 `P1` 人工比對 Quiz 參考畫面並關閉 P0 視覺差異
- [ ] AMQ-264-063 `P1` 繼續收斂 Quiz 設定與篩選區密度
- [ ] AMQ-264-064 `P1` 將 Multiplayer 區域視覺分區並做四尺寸檢查
- [ ] AMQ-264-065 `P1` 進行 Results 正式 UI 視覺落地
- [ ] AMQ-264-066 `P1` 進行 Settings 正式 UI 視覺落地
- [ ] AMQ-264-067 `P0` 取得真實近期作品封面並驗證 Home 主視覺
- [ ] AMQ-264-068 `P0` 取得正常 HTTP-origin Catalog 截圖
- [ ] AMQ-264-069 `P0` 完成 Home/Catalog/Quiz 人工視覺 gate


## Batch263 工作項目

- [x] AMQ-263-001 `P0` 以 Batch262 副本建立獨立 Batch263 工作目錄，不覆蓋交付 ZIP
- [x] AMQ-263-002 `P0` 讀取專案規範、工作狀態、主清單、UI traceability、設計流程、差距表、文案政策與交接文件
- [x] AMQ-263-003 `P0` 將 Home 主視覺 art 區改成完整 feature surface
- [x] AMQ-263-004 `P0` 將 Home 標題與主要操作疊至主視覺底部，不新增裝飾性文案
- [x] AMQ-263-005 `P0` 調整 Home 主視覺與最近學習區的比例
- [x] AMQ-263-006 `P0` 降低 Home 空播放紀錄時的無效高度
- [x] AMQ-263-007 `P0` 建立獨立 Batch263 Home/Catalog browser harness
- [x] AMQ-263-008 `P0` 將 opaque-origin Catalog error screenshots 以明確名稱保存
- [x] AMQ-263-009 `P0` 建立六筆 Catalog data fixture 與測試 artwork screenshot
- [x] AMQ-263-010 `P0` fixture 畫面不得被標記成正式 HTTP-origin 或 live Catalog 驗收
- [x] AMQ-263-011 `P1` 四尺寸檢查 Home/Catalog DOM owners 與 overflow
- [x] AMQ-263-012 `P1` 四尺寸檢查首頁六個主要入口可見
- [x] AMQ-263-013 `P1` 四尺寸檢查 Catalog 左篩選／中央列表／右詳情 DOM 結構
- [x] AMQ-263-014 `P1` 驗證 Home artwork fixture 仍能渲染 feature 與 recent images
- [x] AMQ-263-015 `P1` 驗證 App Shell browser regression
- [x] AMQ-263-016 `P1` 驗證 navigation contract
- [x] AMQ-263-017 `P1` 驗證 Skin adapter contract
- [x] AMQ-263-018 `P1` 驗證 Catalog unit tests
- [x] AMQ-263-019 `P1` 驗證 UI shell CSS contract
- [x] AMQ-263-020 `P1` 執行 Architecture Checker
- [x] AMQ-263-021 `P1` 編譯新增 Python browser harness
- [x] AMQ-263-022 `P0` 保留 HTTP-origin IndexedDB blocker，不重試沒有環境變化的同一探測
- [ ] AMQ-263-023 `P0` 在允許 HTTP-origin 的執行環境驗證正式 Catalog IndexedDB
- [ ] AMQ-263-024 `P0` 在允許外部請求的環境驗證 ANN live artwork
- [ ] AMQ-263-025 `P0` 在允許外部請求的環境驗證 VNDB live artwork
- [ ] AMQ-263-026 `P0` 驗證 image load failure 後 feature/recent row fallback
- [ ] AMQ-263-027 `P0` 驗證沒有 workId mapping 時不會猜測封面 URL
- [ ] AMQ-263-028 `P0` 驗證 live Catalog data 的 row selection 與 details
- [ ] AMQ-263-029 `P1` 核對 artwork source attribution 與使用條件
- [ ] AMQ-263-030 `P0` 完成 Home 1920×1080 對照參考的人工視覺驗收
- [ ] AMQ-263-031 `P0` 完成 Home 1440×900 對照參考的人工視覺驗收
- [ ] AMQ-263-032 `P1` 完成 Home 1024×768 的密度／可用性人工驗收
- [ ] AMQ-263-033 `P1` 完成 Home 390×844 的視覺／觸控人工驗收
- [ ] AMQ-263-034 `P0` 完成 Catalog 1920×1080 對照參考的人工視覺驗收
- [ ] AMQ-263-035 `P1` 完成 Catalog 1440×900 對照參考的人工視覺驗收
- [ ] AMQ-263-036 `P1` 完成 Catalog 1024×768 篩選／詳情排版人工驗收
- [ ] AMQ-263-037 `P1` 完成 Catalog 390×844 抽屜／堆疊操作人工驗收
- [ ] AMQ-263-038 `P0` 不得把 fixture screenshots 當成正式資料成功證據
- [ ] AMQ-263-039 `P0` 保持 UI_COPY_POLICY 不加入 eyebrow／工程註釋
- [ ] AMQ-263-040 `P1` 清點 Home 最新 CSS 是否仍存在重複覆寫
- [ ] AMQ-263-041 `P1` 檢查 Skin roles 對新 Home art surface 的覆蓋範圍
- [ ] AMQ-263-042 `P1` 為 Home 主視覺圖片裁切／焦點增加回歸檢查
- [ ] AMQ-263-043 `P1` 檢查 Home recent artwork 的窄視窗裁切
- [ ] AMQ-263-044 `P1` 檢查 Home empty/loading/error 三狀態視覺一致性
- [ ] AMQ-263-045 `P1` 將正式 Catalog error screenshots 與 fixture 證據寫入 handoff
- [ ] AMQ-263-046 `P1` 更新 WORK_STATUS、traceability 與 design gap register
- [ ] AMQ-263-047 `P1` 更新 AI_START_HERE 與下一批 prompt
- [ ] AMQ-263-048 `P1` 重建 MANIFEST.sha256 並驗證全部項目
- [ ] AMQ-263-049 `P1` 產生獨立 Batch263 ZIP 與 SHA-256 sidecar
- [ ] AMQ-263-050 `P1` 驗證 ZIP CRC、sidecar hash 與 ZIP 內 manifest
- [ ] AMQ-263-051 `P0` 將最終 osu! 視覺驗收保留為未完成



# Batch259 設計落地 P0/P1 待辦（持續清單）

> 狀態標記：`[x]` 已完成、`[~]` 進行中、`[ ]` 待處理。已完成僅代表本批實際證據支持的工作，不代表整體視覺驗收通過。

- [x] AMQ-259-001 `P0` 凍結 Batch258 ZIP 與 SHA-256，不覆寫原基準
- [x] AMQ-259-002 `P0` 確認正式 UI 入口為 src/index.html
- [x] AMQ-259-003 `P0` 確認正式導航 owner 為 src/ui/app-shell.js
- [x] AMQ-259-004 `P0` 標記 prototype 與 production 尚未整合的事實
- [x] AMQ-259-005 `P0` 維護 DESIGN_LANDING_FLOW.md 的 Gate 0–6
- [x] AMQ-259-006 `P0` 維護 DESIGN_GAP_REGISTER.md 的差異與證據
- [~] AMQ-259-007 `P0` 建立官方 osu! Client Interface 參考截圖索引
- [~] AMQ-259-008 `P0` 建立官方 osu! Skinning Interface 元件映射索引
- [~] AMQ-259-009 `P0` 定義首頁 1920×1080 構圖規格
- [~] AMQ-259-010 `P0` 定義選歌頁 1920×1080 構圖規格
- [ ] AMQ-259-011 `P0` 定義猜歌頁 1920×1080 構圖規格
- [ ] AMQ-259-012 `P0` 定義設定頁 1920×1080 構圖規格
- [ ] AMQ-259-013 `P0` 定義結果頁 1920×1080 構圖規格
- [~] AMQ-259-014 `P0` 建立每頁參考截圖／正式截圖／差異表格式
- [~] AMQ-259-015 `P0` 首頁主要功能入口不應依賴隱藏式圓盤互動才可見
- [~] AMQ-259-016 `P0` 首頁展示作品視覺或真實近期學習／播放區
- [~] AMQ-259-017 `P0` 首頁減少無功能用途的大面積空白
- [~] AMQ-259-018 `P0` 首頁保留 AMQ 特有的學習入口
- [x] AMQ-259-019 `P0` 正式版左側導航在所有 route 常駐
- [x] AMQ-259-020 `P0` 正式版 route active state 同步 aria-current
- [x] AMQ-259-021 `P0` 正式版全域導航桌面觸控目標至少 44px
- [x] AMQ-259-022 `P0` 正式版全域導航手機觸控目標至少 44px
- [~] AMQ-259-023 `P0` 選歌頁左側提供主要搜尋與篩選區
- [~] AMQ-259-024 `P0` 選歌頁中央提供密集曲目列表
- [~] AMQ-259-025 `P0` 選歌列表項目提供作品封面／可辨識視覺
- [~] AMQ-259-026 `P0` 選中曲目在列表內有明確狀態
- [~] AMQ-259-027 `P0` 選歌頁右側提供選中作品詳情
- [~] AMQ-259-028 `P0` 選歌頁底部提供持續播放控制 Dock
- [~] AMQ-259-029 `P0` 選歌搜尋使用正式 Catalog 狀態 owner
- [~] AMQ-259-030 `P0` 選歌篩選使用正式 Catalog 狀態 owner
- [~] AMQ-259-031 `P0` 選歌排序使用正式 Catalog 狀態 owner
- [~] AMQ-259-032 `P0` 選歌點選與詳情更新不建立第二份曲目狀態
- [~] AMQ-259-033 `P0` 正式版整合 prototype 前盤點所有 mock-data 依賴
- [~] AMQ-259-034 `P0` 正式版不得把原型 mock songs 當成真實曲庫
- [~] AMQ-259-035 `P0` 封面來源遵守合法使用依據並記錄 provider
- [ ] AMQ-259-036 `P1` 封面載入失敗提供作品名稱衍生 fallback
- [ ] AMQ-259-037 `P1` 選歌 loading 狀態具可見回饋
- [ ] AMQ-259-038 `P1` 選歌 error 狀態具重試操作
- [ ] AMQ-259-039 `P1` 篩選無結果與曲庫空狀態明確區分
- [ ] AMQ-259-040 `P1` 桌面主要 frame 不產生整頁垂直捲動
- [~] AMQ-259-041 `P1` 選歌內容可在明確的內容容器內捲動
- [~] AMQ-259-042 `P1` 1024×768 下右側詳情可合理折疊
- [~] AMQ-259-043 `P1` 390×844 下篩選可收納為抽屜
- [~] AMQ-259-044 `P1` 390×844 下沒有水平溢位
- [~] AMQ-259-045 `P1` Reduced motion 偏好仍生效
- [~] AMQ-259-046 `P1` 所有 route 的焦點進入目的頁標題或主要控制
- [~] AMQ-259-047 `P1` 所有 route 的返回首頁操作可鍵盤操作
- [ ] AMQ-259-048 `P1` 猜歌頁以題目與音訊為第一視覺焦點
- [ ] AMQ-259-049 `P1` 猜歌頁區分單人設定與多人房間
- [ ] AMQ-259-050 `P1` 猜歌答題輸入保持既有 ID 與事件 owner
- [ ] AMQ-259-051 `P1` 猜歌播放／暫停／揭曉操作具清楚階層
- [ ] AMQ-259-052 `P1` 設定頁分組與快速導覽不堆疊成無差別卡片
- [ ] AMQ-259-053 `P1` 設定頁快捷鍵錄製維持衝突檢查
- [ ] AMQ-259-054 `P1` 設定頁 OSK 匯入保留正式 parser
- [ ] AMQ-259-055 `P1` 結果頁只顯示可確認保存的回合資料
- [ ] AMQ-259-056 `P1` 學習中心不得合成不存在的統計值
- [ ] AMQ-259-057 `P1` 個人檔案不得偽造全域排名或 PP
- [ ] AMQ-259-058 `P1` 每個 Skin role 指向正式 DOM owner
- [ ] AMQ-259-059 `P1` 每個 Skin role 有明確 CSS token consumer
- [ ] AMQ-259-060 `P1` 未支援 Skin role 在報告中明確標示
- [ ] AMQ-259-061 `P1` skin apply 不遮蔽按鈕或降低可讀性
- [ ] AMQ-259-062 `P1` missing asset fallback 不破壞元件尺寸
- [ ] AMQ-259-063 `P1` skin reset 後清除 blob URL 與臨時狀態
- [ ] AMQ-259-064 `P1` 對照截圖使用一致 viewport 與瀏覽器環境
- [ ] AMQ-259-065 `P1` 每頁完成 default／hover／selected 截圖
- [ ] AMQ-259-066 `P1` 每頁完成 loading／empty／error 截圖
- [ ] AMQ-259-067 `P1` 關閉所有阻礙一眼辨識的 P0 差異
- [x] AMQ-259-068 `P1` 執行 app-shell.browser.test.py 回歸
- [x] AMQ-259-069 `P1` 執行 batch259-design-landing.browser.py 回歸
- [~] AMQ-259-070 `P1` 執行所有受影響的 Catalog browser tests
- [~] AMQ-259-071 `P1` 執行受影響 Node test files 並記錄每檔 exit
- [~] AMQ-259-072 `P1` 執行 Architecture Checker 並保存輸出
- [~] AMQ-259-073 `P1` 執行 JS/CJS 語法檢查
- [~] AMQ-259-074 `P1` 執行 Python AST compile 檢查
- [~] AMQ-259-075 `P1` 更新 UI_TRACEABILITY 的視覺與 Skin 對照
- [~] AMQ-259-076 `P1` 更新 WORK_STATUS 的實作／測試／視覺驗收分離狀態
- [~] AMQ-259-077 `P1` 更新 Handoff 與 Next Session Prompt
- [~] AMQ-259-078 `P1` 更新 AI_START_HERE 的最新 P0 指示
- [~] AMQ-259-079 `P1` 重新生成 MANIFEST.sha256
- [~] AMQ-259-080 `P1` 重新打包完整專案 ZIP 與 SHA-256 sidecar
- [ ] AMQ-259-081 `P1` 交付前驗證 ZIP 可讀且 SHA-256 一致

## 本批驗證證據
- `python tests/app-shell.browser.test.py`: 150/150 PASS。
- `python tests/batch259-design-landing.browser.py`: 17/17 PASS。
- 視覺驗收：未通過／未結案；首頁仍保留大型圓盤，Catalog prototype 尚未接入正式 src。

## Batch258：Settings／Learning／Multiplayer 可見狀態矩陣（2026-10-29）
- [x] AMQ-25801 確認 Batch257 ZIP SHA-256 與 sidecar，建立獨立工作副本；確認無 `.git`，未初始化 Git。
- [x] AMQ-25802 讀取 AGENTS、AI_START_HERE、工作狀態、主清單、roadmap、traceability、handoff 與 next prompt。
- [x] AMQ-25803 新增 `tests/batch258-route-skin-visible.browser.py`，擴充正式 route-aware Skin matrix 至 Home、Catalog、Quiz、Results、Learning、Settings。
- [x] AMQ-25804 48 個可見 role-route 配對逐一驗證 apply、missing-asset fallback、reset 與 token scope。
- [x] AMQ-25805 驗證六個 route 的 390px overflow、`aria-current`、reduced-motion 與 0 uncaught Chromium page errors。
- [x] AMQ-25806 增加 Learning dashboard/history/review/status、Settings toggles/dropdowns/backup controls、Multiplayer panel status/source/message/error owner 的實際 DOM 契約檢查。
- [x] AMQ-25807 Focused Node 四檔 exit 0；Architecture Checker 1,293/0；JS/CJS 195/195；Python AST 18/18。
- [x] AMQ-25808 確認 AMQ／EMQ 原始資料 SHA-256 不變；更新 regression evidence 與 traceability。
- [~] AMQ-25809 全量 Node 92 檔執行遭工具時間上限中止，未取得完整 summary；不得標為通過，需後續分組執行。
- [~] AMQ-25810 Multiplayer live server E2E、HTTP-origin IndexedDB、live providers/audio、Windows／實機仍需外部環境。
- [ ] AMQ-25811 Batch259：增加可觸發 Multiplayer error/recovery 與 Learning empty/error-state 互動測試，修正可重現缺陷。

> **新版獨立基準決策（Batch255，優先於歷史批次中的舊紀錄）：** Candidate302／Candidate382 不再是必要參考或驗收 gate。舊批次中提及它們的項目保留作歷史紀錄，但不得當成新版目前待辦或阻塞條件。

## Batch255：Unsupported Skin 角色語義審查（2026-10-29）
- [x] AMQ-25501 以 Batch254 ZIP 建立獨立工作副本，確認無 `.git`，未初始化 Git。
- [x] AMQ-25502 逐項審查 13 unsupported roles 的 manifest 語義、fallback 與風險，記錄於 `docs/BATCH255_UNSUPPORTED_ROLE_AUDIT.md`。
- [x] AMQ-25503 將 `catalog.filter.background`、`catalog.action.random`、`settings.slider` 分類為可接線候選，但不在 selector 邊界未確認前硬接線。
- [x] AMQ-25504 確認作品封面不得使用隨機 OSK 圖、正誤回饋不得使用 osu! grade、AMQ 難度／結果評級不得假定等同 osu! 星級／ranking。
- [x] AMQ-25505 執行 Chromium 跨頁 harness：45/45 PASS，覆蓋 Home、Catalog、Quiz、Results、Learning、Settings、鍵盤導航、ARIA、query state、390px overflow、44px 控制項及 0 page errors。
- [x] AMQ-25506 執行 visual-role audit、theme adapter、navigation contract、skin contract manifest 四個 focused Node 測試檔，全部 exit 0。
- [x] AMQ-25507 將本批靜態角色報告輸出至 `artifacts/batch255-regression/visual-role-audit/`，不覆蓋歷史報告。
- [x] AMQ-25508 確認 AMQ／EMQ raw-data hashes 未變。
- [x] AMQ-25509 更新 WORK_STATUS、主清單、roadmap、UI traceability、handoff、next prompt、AI start、README、回歸證據與 manifest。
- [x] AMQ-25510 移除 Candidate302／Candidate382 作為新版必要基準或阻塞條件的要求；新版按自身需求與驗收證據推進。
- [~] AMQ-25511 3 個候選角色仍需精確 target／CSS consumer／fallback/reset 實作與測試。
- [~] AMQ-25512 35 wired roles 逐頁可見狀態／互動視覺矩陣仍未完成。
- [ ] AMQ-25513 HTTP-origin IndexedDB、live providers/audio、Windows／實機等環境 gate 尚未驗收；不與舊版基準綁定。

---

## Batch251：跨頁端到端、鍵盤焦點與觸控尺寸（2026-10-29）

- [x] AMQ-24532 **P0／完成**：核對 Batch250 ZIP SHA-256／sidecar、manifest 與 AMQ／EMQ raw-data hashes；建立獨立工作副本，不初始化 Git。
- [x] AMQ-24533 **P1／完成**：閱讀 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、工作狀態、主清單、Batch250 handoff／next prompt、roadmap 與 UI traceability。
- [x] AMQ-24534 **P1／完成**：以 Chromium 從 Home 經鍵盤 Enter 開啟主選單並進入 Catalog；確認離開 Home 後 `aria-expanded` 與 hidden state 同步。
- [x] AMQ-24535 **P1／完成**：發現一般 route heading 缺 `tabindex` 導致 `focus()` 無效；`src/ui/app-shell.js` 為非原生可聚焦的目的頁標題補 `tabIndex=-1`。
- [x] AMQ-24536 **P1／完成**：新增 `tests/app-shell-navigation.contract.test.cjs`，保護 destination focus、`aria-current`、scroll reset 與 Quiz 專用 setup focus。
- [x] AMQ-24537 **P1／完成**：新增 `tests/batch251-cross-page.browser.py`，驗證 Quiz／Results／Learning／Settings／Catalog route、ARIA、目的頁焦點與跨頁 scroll reset。
- [x] AMQ-24538 **P1／完成**：驗證 Catalog 搜尋 query 在 Catalog → Quiz → Catalog 後保留，且 Catalog 模組只有一個 instance。
- [x] AMQ-24539 **P1／完成**：驗證 Settings quick-nav 使用鍵盤 Enter 後聚焦 Skin import／Mapping Studio 區塊，並保留頁內捲動語義。
- [x] AMQ-24540 **P1／完成**：驗證 Quiz audio 與 Skin import status 的 ARIA status/live semantics，且 CSS 含 reduced-motion handling。
- [x] AMQ-24541 **P1／完成**：Chromium 390px 驗證 Home、Catalog、Quiz、Results、Learning、Settings 均無頁面水平溢位。
- [x] AMQ-24542 **P1／完成**：Chromium 發現 Settings 38 個可見主要控制中 24 個低於 44px；定位統計排序、快捷鍵、reset 與 Mapping reset 控制。
- [x] AMQ-24543 **P1／完成**：`src/styles/ui-shell.css` 將上述 Settings 控制項的最小高度設為 44px，保留既有視覺與互動行為。
- [x] AMQ-24544 **P1／完成**：`tests/ui-shell-css.contract.test.cjs` 新增 Settings shortcut/order/reset/Mapping reset 44px contract。
- [x] AMQ-24545 **P1／完成**：跨頁 Chromium 45/45；formal app-shell 150/150；Home/Catalog 22/22；Quiz/Results 19/19；Backup/Restore 8/8。
- [x] AMQ-24546 **P1／完成**：全量 Node 91/91 test files 最終逐檔 exit 0；保留每檔 log 與 TSV。
- [x] AMQ-24547 **P1／完成**：Architecture Checker 1,286 PASS／0 FAIL；JS/CJS syntax 194/194；Python compile 14/14。
- [x] AMQ-24548 **P0／完成**：AMQ／EMQ raw data SHA-256 與 Batch250 一致；沒有修改曲庫資產。
- [x] AMQ-24549 **P0／完成**：更新 WORK_STATUS、MASTER_CHECKLIST、roadmap、UI traceability、handoff、next prompt、README／AI start、browser/node evidence、manifest 與 ZIP。
- [ ] AMQ-24550 **P1／阻塞**：HTTP-origin IndexedDB save/reload；既有 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 未有環境條件變化，需政策／origin 可用後再驗。
- [~] AMQ-24551 **P1／進行中**：35 個 wired Skin roles 尚未逐一完成 browser apply/fallback/reset；本批只完成跨頁代表性回歸。
- [~] AMQ-24552 **P1／進行中**：13 個 unsupported Skin roles 維持 unsupported，待語義 target、CSS consumer、fallback/reset 具證據後再接線。
- [ ] AMQ-24553 **P1／待處理**：live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0 與原生 osu!stable fidelity 外部驗收。
- [x] AMQ-24554 **P1／完成**：擴大到 `#page-settings button` 的實際瀏覽器量測後，另發現五個 Settings quick-nav buttons 只有 38px；補 `.settings-quick-nav button{min-height:44px}` 並以 43 個可見 Settings／nav buttons 驗證 0 個低於 44px。

---

## Batch250：持久化 gate 與備份／還原閉環（2026-10-29）

- [x] AMQ-24507 **P0／完成**：核對 Batch249 ZIP 與 sidecar SHA-256，建立獨立工作副本；未初始化 Git。
- [x] AMQ-24508 **P1／完成**：閱讀既有 HTTP-origin IndexedDB blocker 證據；確認環境條件沒有變化，不重複相同 probe。
- [x] AMQ-24509 **P1／完成**：檢查 backup export 的 key allowlist、schema validation、checksum 與讀取失敗路徑。
- [x] AMQ-24510 **P1／完成**：檢查 restore preflight 在任何寫入前驗證 checksum／schema／key allowlist。
- [x] AMQ-24511 **P1／完成**：檢查 restore commit 失敗的回滾範圍與 rollback failure 警告。
- [x] AMQ-24512 **P1／完成**：檢查 stale preflight、檔案選擇與 restore busy lock 的 race protections。
- [x] AMQ-24513 **P1／完成**：確認取消 restore 不寫入、preflight 失敗不修改資料、成功提示要求 reload。
- [x] AMQ-24514 **P1／完成**：新增 Settings backup／restore CSS 44px touch target contract。
- [x] AMQ-24515 **P1／完成**：將 Settings backup/restore、database update、Skin import buttons min-height 40px 改為 44px。
- [x] AMQ-24516 **P1／完成**：新增 `tests/batch250-backup-restore.browser.py`。
- [x] AMQ-24517 **P1／完成**：Chromium 驗證 backup export／preflight／restore computed min-height 與實際 rect 均至少 44px。
- [x] AMQ-24518 **P1／完成**：Chromium 驗證 Settings 桌面與 390px 無水平溢位、無 uncaught browser errors。
- [x] AMQ-24519 **P1／完成**：Focused backup/restore／panel／multiplayer backup／private server backup／CSS Node tests 12/12。
- [x] AMQ-24520 **P1／完成**：新 Backup/Restore Chromium 8/8。
- [x] AMQ-24521 **P1／完成**：全量 Node 90/90 test files 最終逐檔 exit 0；記錄 audio-service parallel timing flake 並單檔重跑。
- [x] AMQ-24522 **P1／完成**：Architecture Checker 1,279 PASS／0 FAIL。
- [x] AMQ-24523 **P1／完成**：JS/CJS syntax 193/193、Python compile 13/13。
- [x] AMQ-24524 **P0／完成**：核對 AMQ／EMQ raw data hashes 未變。
- [x] AMQ-24525 **P0／完成**：更新 WORK_STATUS、MASTER_CHECKLIST、roadmap、traceability、handoff、next prompt、README／AI start。
- [ ] AMQ-24526 **P1／阻塞**：真實 HTTP-origin IndexedDB save/reload；Chromium policy 未變，需環境條件改變後再驗。
- [~] AMQ-24527 **P1／進行中**：Settings backup/restore browser test 使用 Storage fixture，尚非真實 origin／IndexedDB 持久化驗收。
- [~] AMQ-24528 **P1／進行中**：跨頁全流程、鍵盤 only、ARIA、reduced-motion 與 390px 組合回歸。
- [~] AMQ-24529 **P1／進行中**：35 wired Skin roles 的逐角色 browser apply/fallback/reset。
- [~] AMQ-24530 **P1／進行中**：13 unsupported Skin roles 需真實語義 target／CSS consumer／fallback/reset 後才接線。
- [ ] AMQ-24531 **P1／待處理**：live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0 相容性驗收。

---

## Batch249：Settings／Learning Center／Multiplayer 狀態閉環（2026-10-29）

- [x] AMQ-24481 **P0／完成**：確認唯讀 Batch248 ZIP hash、獨立工作副本與無 Git 狀態。
- [x] AMQ-24482 **P1／完成**：追蹤 Learning Center dashboard 對 Quiz History、Familiarity、AMQ／EMQ SRS、Playback History 的狀態 owner。
- [x] AMQ-24483 **P1／完成**：補上 SRS `error`、`recoveryAvailable`、`persisted === false` 的 dashboard fail-closed 判定。
- [x] AMQ-24484 **P1／完成**：補上 Playback History `persisted === false` 的 dashboard fail-closed 判定。
- [x] AMQ-24485 **P1／完成**：新增 dashboard regression，確認 SRS write error 不會呈現成「統計已更新」。
- [x] AMQ-24486 **P1／完成**：新增 recovery-state regression，確認 SRS quarantine recovery 未解除時不輸出正常統計。
- [x] AMQ-24487 **P1／完成**：SRS valid replacement schedule 成功持久化後清除記憶體中的 recovery warning。
- [x] AMQ-24488 **P1／完成**：SRS `flush()` 成功時同樣清除記憶體中的 recovery warning。
- [x] AMQ-24489 **P0／完成**：驗證 recovery warning 清除不會刪除原始 quarantine recovery bytes。
- [x] AMQ-24490 **P1／完成**：更新 `tests/srs-store.test.cjs`；修正前 19/20，修正後 35/35。
- [x] AMQ-24491 **P1／完成**：`tests/statistics-dashboard-panel.test.cjs` write error／recovery state regression 通過。
- [x] AMQ-24492 **P1／完成**：Settings store、workspace preferences、Multiplayer UI/room state 相關 focused tests 通過；未找到支持重寫既有流程的具體缺口。
- [x] AMQ-24493 **P1／完成**：90/90 Node test files 最終逐檔 exit 0。
- [x] AMQ-24494 **P1／完成**：Architecture Checker 1,279 PASS／0 FAIL。
- [x] AMQ-24495 **P1／完成**：JS/CJS syntax 193/193、Python compile 12/12。
- [x] AMQ-24496 **P1／完成**：formal app-shell Chromium 150/150，兩個既有 harness 均通過。
- [x] AMQ-24497 **P1／完成**：重新執行 visual role coverage audit，48 roles、35 wired／13 unsupported。
- [x] AMQ-24498 **P0／完成**：確認 AMQ／EMQ raw data hashes 未變。
- [x] AMQ-24499 **P0／完成**：更新 WORK_STATUS、MASTER_CHECKLIST、roadmap、traceability、handoff、next prompt、README／AI start。
- [ ] AMQ-24500 **P1／阻塞**：HTTP-origin IndexedDB 真實 save/reload；Chromium 管理政策阻擋，只有在 origin／政策條件改變後重驗。
- [~] AMQ-24501 **P1／進行中**：Settings 匯入／匯出／backup-restore 全流程需額外 browser evidence。
- [~] AMQ-24502 **P1／進行中**：Learning Center 所有 store failure／partial persistence 組合仍需逐項 browser verification；本批完成 SRS error/recovery。
- [~] AMQ-24503 **P1／進行中**：Multiplayer pending/rejected command、focus restore 與 mobile room phase 仍需完整多 client E2E。
- [~] AMQ-24504 **P1／進行中**：35 wired Skin roles 的逐角色 browser apply/fallback/reset。
- [~] AMQ-24505 **P1／進行中**：13 unsupported Skin roles 保持 unsupported，待真實語義 target 與 fallback/reset 完整後才接線。
- [ ] AMQ-24506 **P1／待處理**：live catalog／artwork／audio、Windows／實機及 Candidate302／Candidate382 Stage 0 相容性驗收。

---

## Batch248：Quiz Arena 與 Results UI 收尾（2026-10-29）

- [x] AMQ-24455 **P0／完成**：核對實際 Batch247 ZIP 與 sidecar SHA-256，獨立解壓；未初始化 Git。
- [x] AMQ-24456 **P1／完成**：追蹤 `quiz-history-store` 的 completed-result pointer clear、`QuizSession.startRound()` 與 Results projection。
- [x] AMQ-24457 **P1／完成**：`beginRound()` 回傳前一輪 pointer 清除結果與穩定 warning code。
- [x] AMQ-24458 **P1／完成**：新增 storage remove/write failure regression，確認失敗不被冒充成功。
- [x] AMQ-24459 **P1／完成**：QuizSession 在 pointer clear failure 時保留新回合可玩性並設 persistence warning。
- [x] AMQ-24460 **P1／完成**：新增 QuizSession integration regression，確認 roundId 更新且 warning 不丟失。
- [x] AMQ-24461 **P1／完成**：Results note 對上一輪 pointer clear failure 顯示專用警告。
- [x] AMQ-24462 **P1／完成**：Results regression 確認舊回合不得被描述成當前回合成績。
- [x] AMQ-24463 **P1／完成**：確認逐題結果仍以 `entry.roundId === resultState.roundId` 限定，不合併其他回合。
- [x] AMQ-24464 **P1／完成**：QuizHistoryStore 27/27、QuizSession 41/41、Results contract 9/9。
- [x] AMQ-24465 **P1／完成**：正式 app-shell Chromium 150/150。
- [x] AMQ-24466 **P1／完成**：Home/Catalog Chromium 22/22。
- [x] AMQ-24467 **P1／完成**：Quiz/Results Chromium 19/19，桌面／390px 無水平溢位、空狀態無假結果、長標題換行。
- [x] AMQ-24468 **P1／完成**：OSK／Mapping Studio browser harness 成功。
- [x] AMQ-24469 **P1／完成**：Architecture Checker 1,279 PASS／0 FAIL。
- [x] AMQ-24470 **P1／完成**：90/90 Node test files 最終逐檔 exit 0；保留每檔 log 與 TSV。
- [x] AMQ-24471 **P1／完成**：JS/CJS syntax 193/193、Python compile 12/12。
- [x] AMQ-24472 **P0／完成**：核對 AMQ／EMQ raw data SHA-256 未變。
- [x] AMQ-24473 **P0／完成**：更新唯一 master checklist、WORK_STATUS、roadmap、traceability、handoff、next prompt、README／AI start。
- [ ] AMQ-24474 **P1／阻塞**：HTTP-origin IndexedDB save/reload；Chromium 管理政策阻擋，須 origin／政策可用性改變後再驗。
- [~] AMQ-24475 **P1／進行中**：setup／playing／answered／timeout／audio error／empty pool／cancelled／unsaved result 的完整 UI state matrix，需進一步逐狀態 browser owner 驗收。
- [~] AMQ-24476 **P1／進行中**：35 個 wired Skin roles 的逐角色 apply/fallback/reset browser evidence。
- [~] AMQ-24477 **P1／進行中**：13 個 unsupported Skin roles，只有在真實語義 target／CSS consumer／fallback/reset 齊備後才接線。
- [ ] AMQ-24478 **P1／待處理**：真實音訊／外部曲庫／artwork provider 驗收。
- [ ] AMQ-24479 **P1／待處理**：乾淨 Windows／實機觸控驗收。
- [ ] AMQ-24480 **P1／待處理**：取得並核對 Candidate302／Candidate382 Stage 0 原始基準後才評估相容性。

---

## Batch246：Mapping Studio 操作閉環（2026-10-29）

- [x] AMQ-24432 **P0／完成**：確認唯讀 Batch245 ZIP hash、Manifest／資料基準與獨立工作副本；不初始化 Git、不覆蓋 ZIP。
- [x] AMQ-24433 **P1／完成**：盤點 state-pair 選取、預覽、套用、fallback、reset、portable transfer 與 schema v4 store 的資料流。
- [x] AMQ-24434 **P1／完成**：修正 theme store 超過 500 個 role mappings 時靜默截斷；改為拒絕不完整資料。
- [x] AMQ-24435 **P1／完成**：修正 portable transfer 超過 500 個 role mappings 時靜默截斷；回傳穩定 `THEME_TRANSFER_INVALID_SCHEMA`。
- [x] AMQ-24436 **P1／完成**：修正 store 超過 100 個 roleStateMappings 時靜默截斷；改為拒絕不完整資料。
- [x] AMQ-24437 **P1／完成**：修正 portable transfer 超過 100 個 roleStateMappings 時靜默截斷；回傳穩定 `THEME_TRANSFER_INVALID_SCHEMA`。
- [x] AMQ-24438 **P1／完成**：新增 store／transfer 超限資料保留回歸，確認不再靜默丟棄映射。
- [x] AMQ-24439 **P1／完成**：Mapping Studio apply 加入單次執行 guard、disabled／`aria-busy`、例外回報與 finally 清理。
- [x] AMQ-24440 **P1／完成**：apply 完成後在控制項仍可用時恢復原焦點，避免鍵盤操作中斷。
- [x] AMQ-24441 **P1／完成**：修正實際生效的 Mapping Studio select min-height 至 44px，處理 CSS specificity 覆蓋。
- [x] AMQ-24442 **P1／完成**：新增 UI contract 測試，保護 touch target、busy/error/focus lifecycle。
- [x] AMQ-24443 **P1／完成**：Chromium 驗證 @2x logical size、Normal/Hover pair、fit／position、焦點、實際套用 CSS token 與 reset 清除。
- [x] AMQ-24444 **P1／完成**：Chromium 驗證 390px Mapping Studio 單欄重排與狀態 pair controls 可操作。
- [x] AMQ-24445 **P1／完成**：保留 portable theme format v1，驗證匯入／匯出及 legacy mapping 行為。
- [x] AMQ-24446 **P1／完成**：全量 Node 90/90 files、275 cases；逐檔 TAP 證據 `artifacts/batch246-regression/node-tests/`。
- [x] AMQ-24447 **P1／完成**：Architecture Checker 1,279 PASS／0 FAIL；JS/CJS syntax 197/197；Python compile 13/13。
- [x] AMQ-24448 **P1／完成**：Chromium formal shell 150/150、Home/Catalog 19/19、Quiz/Results 19/19、Canvas 15/15、Mapping Studio harness 成功。
- [x] AMQ-24449 **P0／完成**：核對 AMQ／EMQ 原始資料 SHA-256 與 Batch245 一致。
- [x] AMQ-24450 **P0／完成**：更新 WORK_STATUS、MASTER_CHECKLIST、traceability、roadmap、handoff、next prompt、AI_START_HERE、README_FIRST。
- [x] AMQ-24451 **P0／完成**：重新產生並驗證 MANIFEST 與完整 ZIP，確認 ZIP CRC。
- [!] AMQ-24452 **P1／阻塞**：HTTP-origin IndexedDB 真實 save/reload 仍受 Chromium policy 阻擋；需政策／可用 origin 改變才重測。
- [~] AMQ-24453 **P1／進行中**：35 個 wired roles 的逐角色 apply/fallback/reset browser evidence 尚未全部完成；本批先完成代表性 state-pair 端到端閉環。
- [~] AMQ-24454 **P1／進行中**：13 個 unsupported roles 保持 unsupported；需各自補齊真實語義 DOM、CSS consumer、狀態／幾何、fallback/reset 才能接線。

---

## Batch245：Visual-role 自動稽核（2026-10-29）

- [x] AMQ-24375 **P1／完成**：盤點 48 個 role manifest 項目的 selector；報告 `artifacts/batch245-regression/visual-role-audit.json`。
- [x] AMQ-24376 **P1／完成**：檢查 35 個 runtime token 對應的 CSS consumer，掃描 `src/styles/**/*.css`。
- [x] AMQ-24377 **P1／完成**：將 selector、fallback、全域 reset/revoke 機制、測試檔線索分欄記錄；靜態證據與 browser evidence 分開。
- [x] AMQ-24378 **P1／完成**：13 個 unsupported roles 均輸出具體缺口，未假裝完整接線。
- [x] AMQ-24379 **P1／完成**：新增自動 audit，將 visual needs 與 runtime role manifest 交叉關聯。
- [x] AMQ-24380 **P1／完成**：測試確認缺 selector 的已知角色不會被標成 supported。
- [x] AMQ-24381 **P1／完成**：測試確認 CSS consumer 與 selector 宣告分開判定。
- [~] AMQ-24382 **P1／進行中**：已確認 adapter apply 路徑與既有回歸，但未逐一為 35 個 role 建立獨立 browser apply 證據。
- [~] AMQ-24383 **P1／進行中**：fallback contract 由 manifest/audit 列出，逐角色瀏覽器 fallback 尚待 Batch246+。
- [~] AMQ-24384 **P1／進行中**：adapter 全域 reset/restore/revoke 已被靜態稽核，但逐角色 reset 行為仍需補驗。
- [x] AMQ-24426 **P0／完成**：確認唯讀 Batch244 ZIP SHA-256、CRC 與獨立工作副本；不初始化 Git。
- [x] AMQ-24427 **P1／完成**：新增 `tools/audit-visual-role-coverage.cjs` 與 `tests/visual-role-audit.test.cjs`。
- [x] AMQ-24428 **P1／完成**：產生 48 role JSON／Markdown 缺口報告，標示 35 wired、13 unsupported。
- [x] AMQ-24429 **P1／完成**：全量 Node 90/90 files、271 cases；Architecture 1,279/0；核心 Chromium suites 全部通過。
- [x] AMQ-24430 **P0／完成**：更新狀態、清單、traceability、handoff、next prompt、README／AI start、manifest 與 ZIP。
- [!] AMQ-24431 **P1／阻塞**：HTTP-origin IndexedDB、真實音訊／live artwork／Windows／基準相容性仍待外部環境與素材。


## 後續批次路線圖與新增追蹤項目（Batch244–253）

詳細批次目標與結案條件見 `docs/BATCH_ROADMAP.md`。以下是本次建立的可追蹤項目；各項完成前不得因批次結束而自動勾選。

- [x] AMQ-24362 **P0／完成**：核對 Batch243 唯讀 ZIP SHA-256 與 Manifest。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24363 **P0／完成**：建立獨立 Batch244 工作副本且不初始化 Git。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24364 **P0／完成**：驗證 AMQ／EMQ raw data hashes。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24365 **P1／完成**：補 safe-integer 尺寸邊界測試。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24366 **P1／完成**：補 32-bit 幾何上限測試。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24367 **P1／完成**：補 TypedArray 長度與乘法溢位測試。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24368 **P1／完成**：補負數／零／小數幾何拒絕測試。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24369 **P1／完成**：補 Blob decode reject 清理測試。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24370 **P1／完成**：補 canvas factory throw 測試。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24371 **P1／完成**：補 readback/writeback exception cleanup 測試。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24372 **P1／完成**：確認所有失敗路徑都關閉 ImageBitmap。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24373 **P1／完成**：完成 Batch244 renderer Chromium 回歸。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24374 **P1／完成**：完成 Batch244 全量 Node 與 Architecture 回歸。驗收證據見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。
- [x] AMQ-24375 **P1／完成**：盤點每個 visual need 的真實 DOM selector。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24376 **P1／完成**：盤點每個 visual need 的 CSS consumer。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24377 **P1／完成**：盤點 state／geometry／fallback／reset。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24378 **P1／完成**：建立未支援角色原因與解除條件。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24379 **P1／完成**：核對 runtime inventory 與 traceability 一致。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24380 **P1／完成**：檢查不存在 selector 的角色不會被標成 supported。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24381 **P1／完成**：檢查無 CSS consumer 的角色不會被標成 supported。驗收證據須記錄於本批 artifacts 與 handoff。
- [~] AMQ-24382 **P1／進行中**：檢查所有 runtime role 的 apply 路徑。驗收證據須記錄於本批 artifacts 與 handoff。
- [~] AMQ-24383 **P1／進行中**：檢查所有 runtime role 的 fallback 路徑。驗收證據須記錄於本批 artifacts 與 handoff。
- [~] AMQ-24384 **P1／進行中**：檢查所有 runtime role 的 reset 路徑。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24385 **P1／待處理**：Mapping Studio state-pair 完整流程。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24386 **P1／待處理**：Mapping Studio @2x logical geometry。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24387 **P1／待處理**：Mapping Studio fit／position 保存與預覽。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24388 **P1／待處理**：Mapping Studio invalid path 與 error feedback。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24389 **P1／待處理**：Mapping Studio keyboard focus 與 busy state。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24390 **P1／待處理**：Mapping Studio 390px layout／touch targets。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24391 **P1／待處理**：Catalog loading／empty／error／retry 狀態。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24392 **P1／待處理**：Catalog 搜尋／篩選／排序／鍵盤選取回歸。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24393 **P1／待處理**：Catalog artwork 真來源與 fallback 語義。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24394 **P1／待處理**：Catalog 不使用 OSK 圖冒充作品封面。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24395 **P1／待處理**：Catalog 桌面／390px／reduced-motion 驗證。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24396 **P1／待處理**：Quiz setup／playing／answered／timeout 狀態。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24397 **P1／待處理**：Quiz 音訊失敗與空題庫狀態。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24398 **P1／待處理**：Results saved／unsaved／partial 狀態。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24399 **P1／待處理**：Results 不生成假成績與錯誤 owner regression。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24400 **P1／待處理**：Quiz／Results 鍵盤／觸控／焦點回歸。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24401 **P1／待處理**：Settings 區塊導覽與手機排版。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24402 **P1／待處理**：Settings persistence error／recovery 狀態。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24403 **P1／待處理**：Learning Center 真實資料來源與空狀態。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24404 **P1／待處理**：Learning Center persistence failure UI。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24405 **P1／待處理**：Multiplayer busy／rejected command focus restore。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24406 **P1／待處理**：Multiplayer room phase／mobile layout regression。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24407 **P1／待處理**：共用錯誤／通知／ARIA／reduced-motion 盤點。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24408 **P1／待處理**：清理已確認可移除的舊 CSS 實作。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24409 **P1／待處理**：HTTP-origin 條件變更前不重複已阻擋探測。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24410 **P1／待處理**：若 origin 可用，驗收 IndexedDB state-pair save/reload。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24411 **P1／待處理**：IndexedDB 若仍阻塞，更新可重現證據與解除條件。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24412 **P1／待處理**：核對 skin.ini version 與 @2x 行為的規格證據。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24413 **P1／待處理**：核對 animation family 與 state pair 的支援界線。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24414 **P1／待處理**：核對 tint/blend 與 edge-repeat 的 native fidelity flags。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24415 **P2／待處理**：真實 .osk 只在可取得合法樣本時稽核。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24416 **P1／待處理**：建立跨頁端到端路由／焦點／捲動回歸。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24417 **P1／待處理**：鍵盤 only／ARIA／reduced-motion 最終驗證。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24418 **P1／待處理**：乾淨 Windows／真實音訊列為外部驗收 gate。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24419 **P1／待處理**：Candidate302／Candidate382 Stage 0 缺件狀態保持明確。驗收證據須記錄於本批 artifacts 與 handoff。
- [ ] AMQ-24420 **P1／待處理**：每批重新計算剩餘必要項目與批次估算。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24421 **P0／完成**：更新唯一 MASTER_CHECKLIST 與 WORK_STATUS。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24422 **P0／完成**：更新 traceability、handoff、next prompt、README、AI start。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24423 **P0／完成**：重建並驗證 MANIFEST file set 與 hashes。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24424 **P0／完成**：重建 ZIP 並執行 unzip -t。驗收證據須記錄於本批 artifacts 與 handoff。
- [x] AMQ-24425 **P0／完成**：在最終報告區分已驗收／未驗收／阻塞。驗收證據須記錄於本批 artifacts 與 handoff。


## Batch244：Renderer 幾何邊界與資源生命週期（2026-10-29）

| 任務 | 狀態 | 證據 |
|---|---|---|
| AMQ-24362 核對 Batch243 唯讀 ZIP SHA-256 與 Manifest | 完成 | handoff 記錄 baseline SHA-256；工作副本 Manifest 5,794 項已於規劃包核驗 |
| AMQ-24363 確認獨立工作副本、Git 狀態 | 完成 | `/mnt/data/AMQ_Full_Rebuild_Batch244`；無 Git repository，未初始化 |
| AMQ-24364 AMQ／EMQ 原始資料 hash | 完成 | `data.js` 692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3；`emq-data.js` 88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc |
| AMQ-24365～24368 safe integer／32-bit／溢位／非法幾何回歸 | 完成 | `tests/skin-edge-repeat.test.cjs`、`tests/skin-canvas-renderer.test.cjs` |
| AMQ-24369 decode reject／close failure 清理 | 完成 | Node tests 與 Chromium synthetic PNG |
| AMQ-24370 Canvas factory throw | 完成 | stable `SKIN_CANVAS_CREATE_FAILED` 與 cause 保留 |
| AMQ-24371 readback/writeback exception | 完成 | `SKIN_CANVAS_READ_FAILED`／`SKIN_CANVAS_WRITE_FAILED` 回歸 |
| AMQ-24372 ImageBitmap cleanup | 完成 | decode 超限關閉；render 例外 finally close；close 本身拋錯不遮蔽原始拒絕原因 |
| AMQ-24373 Canvas Chromium 回歸 | 完成 | 15/15 PASS，`artifacts/batch244-regression/canvas-browser.log` |
| AMQ-24374 全量 Node／Architecture | 完成 | 89/89 files、269 cases PASS；Architecture 1,270/0 |
| AMQ-24375～24384 visual-role selector／consumer／apply/fallback/reset 稽核 | 部分完成 | 延續 traceability 審核；本批沒有角色達到完整語義接線條件，故未強行接線；下一批要建立自動一致性盤點 |
| AMQ-24385～24420 後續 UI／持久化／fidelity／端到端工作 | 待處理 | 依 `docs/BATCH_ROADMAP.md` 分批推進 |
| AMQ-24421～24425 本批文件、manifest、ZIP 與交付 | 進行中 | 交付前驗證後更新 |

驗證細節見 `artifacts/batch244-regression/` 與 `docs/HANDOFF_BATCH244.md`。

## Batch243：Canvas Alpha／幾何安全與工具測試修復（2026-10-29）

| 任務 | 狀態 |
|---|---|
| AMQ-24301 讀取 AGENTS、AI_START_HERE、README_FIRST、WORK_STATUS、MASTER_CHECKLIST、Batch242 handoff | 完成 |
| AMQ-24302 核對 Batch242 ZIP SHA-256 與唯讀基準 | 完成 |
| AMQ-24303 驗證 Batch242 ZIP CRC | 完成 |
| AMQ-24304 建立獨立 Batch243 工作副本 | 完成 |
| AMQ-24305 確認 Git repository 不存在且不初始化 .git | 完成 |
| AMQ-24306 核對 AMQ 原始資料 hash 未變 | 完成 |
| AMQ-24307 核對 EMQ 原始資料 hash 未變 | 完成 |
| AMQ-24308 盤點現有 Node／Chromium／Python 工具 | 完成 |
| AMQ-24309 盤點 Canvas renderer 的 readback／transform／writeback 路徑 | 完成 |
| AMQ-24310 重查未支援 visual roles 的語義 target 與 CSS consumer | 完成：無角色符合完整接線條件 |
| AMQ-24311 edge-repeat helper 驗證 source／target 安全整數 | 完成 |
| AMQ-24312 edge-repeat helper 新增預設 16 MP 輸出 pixel budget | 完成 |
| AMQ-24313 edge-repeat helper 支援呼叫端較低 pixel budget | 完成 |
| AMQ-24314 edge-repeat helper 在配置 TypedArray 前拒絕超限輸出 | 完成 |
| AMQ-24315 Canvas createCanvas 在 factory 呼叫前檢查幾何 | 完成 |
| AMQ-24316 Canvas createCanvas 檢查安全整數與 byte-length overflow | 完成 |
| AMQ-24317 renderToCanvas 驗證 repeat target width | 完成 |
| AMQ-24318 renderToCanvas 驗證 targetWidth × height pixel budget | 完成 |
| AMQ-24319 超限輸出回傳 SKIN_IMAGE_PIXEL_LIMIT_EXCEEDED | 完成 |
| AMQ-24320 確保超限時不配置 output Canvas | 完成 |
| AMQ-24321 保留既有 source readback pixel budget | 完成 |
| AMQ-24322 新增 Canvas output pixel budget Node regression | 完成 |
| AMQ-24323 新增 edge-repeat direct allocation budget regression | 完成 |
| AMQ-24324 新增 3×2 synthetic PNG alpha fixtures | 完成 |
| AMQ-24325 Chromium 驗證 opaque alpha readback | 完成 |
| AMQ-24326 Chromium 驗證 partial alpha readback | 完成 |
| AMQ-24327 Chromium 驗證 fully-transparent pixel 行為 | 完成 |
| AMQ-24328 Chromium 驗證 tint/writeback alpha 保留 | 完成 |
| AMQ-24329 Chromium 記錄 premultiplied-alpha RGB quantization | 完成 |
| AMQ-24330 Chromium 驗證多欄 edge-repeat source 順序 | 完成 |
| AMQ-24331 Chromium 驗證 edge-repeat 不跨越 row boundary | 完成 |
| AMQ-24332 Chromium 驗證 malformed Blob 具名錯誤 | 完成 |
| AMQ-24333 Chromium 驗證 Blob byte limit | 完成 |
| AMQ-24334 Chromium 驗證 edge geometry fail-closed | 完成 |
| AMQ-24335 Chromium 驗證 output pixel budget 先於 output Canvas allocation | 完成 |
| AMQ-24336 Chromium 驗證 decode 超 pixel limit 時 close ImageBitmap | 完成 |
| AMQ-24337 Chromium 驗證 render 例外時 finally close ImageBitmap | 完成 |
| AMQ-24338 Chromium 驗證 renderer 不宣稱 native stable fidelity | 完成 |
| AMQ-24339 修正 tooling test 子程序 stdout pipe deadlock | 完成 |
| AMQ-24340 並行 Architecture Checker 測試消耗 stdout | 完成 |
| AMQ-24341 tooling.test.cjs 全部 13 cases 通過 | 完成 |
| AMQ-24342 全量 Node test files 逐檔執行 | 完成：89/89 |
| AMQ-24343 全量 Node test cases 零失敗 | 完成：261 cases |
| AMQ-24344 Focused Skin／renderer／manifest regression | 完成：32/32 |
| AMQ-24345 Home／Catalog Chromium regression | 完成：19/19 |
| AMQ-24346 Quiz／Results Chromium regression | 完成：19/19 |
| AMQ-24347 Mapping Studio Chromium regression | 完成：30/30 |
| AMQ-24348 正式 app-shell Chromium regression | 完成：150/150 |
| AMQ-24349 Architecture Checker | 完成：1,270/0 |
| AMQ-24350 JavaScript／CJS syntax check | 完成：182/182 |
| AMQ-24351 Python browser harness py_compile | 完成：7/7 |
| AMQ-24352 探測 loopback HTTP origin | 阻塞：ERR_BLOCKED_BY_ADMINISTRATOR |
| AMQ-24353 探測一次非 loopback container HTTP origin | 阻塞：ERR_BLOCKED_BY_ADMINISTRATOR |
| AMQ-24354 記錄 HTTP-origin save/reload 未執行 | 完成：已保存阻塞證據 |
| AMQ-24355 更新 Skin framework contract | 完成 |
| AMQ-24356 更新四頁 visual traceability 補充 | 完成 |
| AMQ-24357 更新 WORK_STATUS 與 MASTER_CHECKLIST | 完成 |
| AMQ-24358 新增 Batch243 handoff 與 next-session prompt | 完成 |
| AMQ-24359 更新 AI_START_HERE 與 README_FIRST | 完成 |
| AMQ-24360 更新 Manifest 並逐項驗證 | 待交付前執行 |
| AMQ-24361 產生 Batch243 完整 ZIP 並驗證 CRC | 待交付前執行 |
| AMQ-24362 保留 Batch242 ZIP 原始檔不變 | 完成 |

---

## Batch242：Canvas Pixel Pipeline Integration 與角色語義核對（2026-10-29）

| 任務 | 狀態 |
|---|---|
| AMQ-24201 讀取 AGENTS.md、AI_START_HERE.md、README_FIRST.md 與最新交接 | 完成 |
| AMQ-24202 核對 Batch241 ZIP SHA-256 與唯讀基準 | 完成 |
| AMQ-24203 解壓至獨立 Batch242 工作副本 | 完成 |
| AMQ-24204 核對 Batch241 Manifest 基準檔案 | 完成 |
| AMQ-24205 確認工作副本沒有 Git repository，不初始化 .git | 完成 |
| AMQ-24206 確認 AMQ／EMQ 原始資料不可修改 | 完成 |
| AMQ-24207 盤點 skin renderer、pixel helpers 與正式 script order | 完成 |
| AMQ-24208 盤點既有 Node、Chromium、Python 測試工具 | 完成 |
| AMQ-24209 新增 Canvas renderer 獨立模組 | 完成 |
| AMQ-24210 實作 Blob image decode 入口 | 完成 |
| AMQ-24211 設定 Blob 預設大小上限 | 完成 |
| AMQ-24212 設定解碼後圖片像素上限 | 完成 |
| AMQ-24213 拒絕空 Blob 與非 Blob 輸入 | 完成 |
| AMQ-24214 將原生 decode 例外轉換為穩定錯誤碼 | 完成 |
| AMQ-24215 驗證解碼圖片的寬高為有效正整數 | 完成 |
| AMQ-24216 建立可注入 canvas factory 的測試接縫 | 完成 |
| AMQ-24217 拒絕不存在的 Canvas API | 完成 |
| AMQ-24218 拒絕無法取得 2D context 的情況 | 完成 |
| AMQ-24219 實作 Canvas drawImage 與 RGBA readback | 完成 |
| AMQ-24220 包裝 Canvas readback 的安全錯誤 | 完成 |
| AMQ-24221 接入既有 RGBA multiply contract | 完成 |
| AMQ-24222 接入既有明確 edge-repeat contract | 完成 |
| AMQ-24223 驗證無效 tint 通道拒絕套用 | 完成 |
| AMQ-24224 驗證無效 edge geometry fail closed | 完成 |
| AMQ-24225 輸出尺寸依 repeat target width 更新 | 完成 |
| AMQ-24226 輸出 ImageData 並寫入新 Canvas | 完成 |
| AMQ-24227 封裝 Blob decode-to-canvas 生命週期 | 完成 |
| AMQ-24228 確保 ImageBitmap 在封裝流程 finally 關閉 | 完成 |
| AMQ-24229 新增 Canvas integration capability contract | 完成 |
| AMQ-24230 明確 Canvas integration 不代表 native stable fidelity | 完成 |
| AMQ-24231 將 Canvas module 加入正式 HTML 載入順序 | 完成 |
| AMQ-24232 確保 Canvas module 先於 shared renderer 載入 | 完成 |
| AMQ-24233 shared renderer 暴露 decode/read/render API | 完成 |
| AMQ-24234 新增 skin-canvas-renderer Node unit tests | 完成 |
| AMQ-24235 新增 Canvas script-order／capability manifest tests | 完成 |
| AMQ-24236 新增真實 Chromium PNG Blob integration harness | 完成 |
| AMQ-24237 使用合成 RGBA pixels，避免第三方圖片授權問題 | 完成 |
| AMQ-24238 驗證 PNG 解碼 intrinsic dimensions | 完成 |
| AMQ-24239 驗證 Canvas source RGBA readback | 完成 |
| AMQ-24240 驗證 tint + edge repeat 實際輸出像素 | 完成 |
| AMQ-24241 驗證錯誤 Blob 回傳具名 decode error | 完成 |
| AMQ-24242 驗證 oversized Blob 在 decode 前被拒絕 | 完成 |
| AMQ-24243 驗證非法 edge geometry 被拒絕 | 完成 |
| AMQ-24244 驗證瀏覽器無 uncaught exception | 完成 |
| AMQ-24245 保存 Canvas integration JSON evidence | 完成 |
| AMQ-24246 保存 Canvas integration screenshot | 完成 |
| AMQ-24247 重新審查 catalog.song-artwork 的語義限制 | 完成：保持 unsupported |
| AMQ-24248 重新審查 catalog.action.random 的 runtime target | 完成：保持 unsupported |
| AMQ-24249 重新審查 catalog.filter.background 的 CSS consumer | 完成：保持 unsupported |
| AMQ-24250 重新審查 quiz correct/incorrect feedback roles | 完成：保持 unsupported |
| AMQ-24251 重新審查 results.grade 的語義與資料 owner | 完成：保持 unsupported |
| AMQ-24252 重新審查 settings.entry／app.navigation.options | 完成：保持 unsupported |
| AMQ-24253 不把相近 DOM 當作任意 OSK 素材套用依據 | 完成 |
| AMQ-24254 全量執行 89 個 Node test files | 完成 |
| AMQ-24255 全量 Node suite 259 cases 無失敗 | 完成 |
| AMQ-24256 Focused Skin／renderer／manifest 30/30 | 完成 |
| AMQ-24257 Mapping Studio Chromium 30/30 | 完成 |
| AMQ-24258 Home/Catalog Chromium 19/19 | 完成 |
| AMQ-24259 Quiz/Results Chromium 19/19 | 完成 |
| AMQ-24260 Formal app-shell Chromium 150/150 | 完成 |
| AMQ-24261 Architecture Checker 1,270/0 | 完成 |
| AMQ-24262 重新嘗試 HTTP-origin IndexedDB harness | 阻塞：ERR_BLOCKED_BY_ADMINISTRATOR |
| AMQ-24263 未將 opaque-origin 當成 HTTP persistence 證據 | 完成 |
| AMQ-24264 記錄所有 Node 測試逐檔 log 與摘要 | 完成 |
| AMQ-24265 更新 Skin framework contract | 完成 |
| AMQ-24266 新增 Batch242 traceability 補充 | 完成 |
| AMQ-24267 更新 WORK_STATUS／MASTER_CHECKLIST／handoff／next prompt | 完成 |
| AMQ-24268 更新 AI_START_HERE 與 README_FIRST 最新入口 | 完成 |
| AMQ-24269 更新並驗證 MANIFEST.sha256 | 完成 |
| AMQ-24270 建立 Batch242 完整 ZIP 並驗證 CRC | 完成 |
| AMQ-24271 保留 Batch241 ZIP 原始檔不變 | 完成 |
| AMQ-24272 下一批驗收真實 HTTP-origin state-pair persistence | 待處理／環境阻塞 |
| AMQ-24273 下一批補 Canvas transparent alpha／multi-row geometry tests | 待處理 |
| AMQ-24274 下一批只將具完整語義消費端的角色接入 runtime | 待處理 |

---

## Batch241：可測試 Skin Pixel Contracts 與原生支援界線（2026-10-29）

| 任務 | 狀態 |
|---|---|
| AMQ-24101 讀取 AGENTS／AI start／最新狀態與 Batch240 handoff | 完成 |
| AMQ-24102 核對 Batch240 ZIP SHA-256 | 完成 |
| AMQ-24103 建立獨立 Batch241 工作副本 | 完成 |
| AMQ-24104 確認沒有 Git repository 並保持未初始化 | 完成 |
| AMQ-24105 確認 Candidate302／Candidate382 Stage 0 原始基準缺席，不猜版本 | 完成 |
| AMQ-24106 驗證 AMQ 原始 data.js hash 未變 | 完成 |
| AMQ-24107 驗證 EMQ 原始 emq-data.js hash 未變 | 完成 |
| AMQ-24108 新增獨立 skin-blend pixel primitive 模組 | 完成 |
| AMQ-24109 定義 RGB 乘色公式及 rounding | 完成 |
| AMQ-24110 保留 source alpha 並覆蓋透明像素測試 | 完成 |
| AMQ-24111 驗證非法 RGBA buffer 幾何 fail closed | 完成 |
| AMQ-24112 新增獨立 skin-edge-repeat pixel primitive 模組 | 完成 |
| AMQ-24113 明確要求呼叫者提供 edge width | 完成 |
| AMQ-24114 驗證單欄邊緣延伸 | 完成 |
| AMQ-24115 驗證多欄 edge segment 順序重複 | 完成 |
| AMQ-24116 驗證窄 target crop 行為 | 完成 |
| AMQ-24117 驗證非法 dimensions／edge width 拒絕 | 完成 |
| AMQ-24118 將 pixel helper scripts 接入正式 HTML | 完成 |
| AMQ-24119 驗證 helpers 在 skin-renderer 前載入 | 完成 |
| AMQ-24120 將 pixel contracts 暴露給 shared renderer | 完成 |
| AMQ-24121 明確 nativeStableFidelity multiplicativeTint 保持 false | 完成 |
| AMQ-24122 明確 nativeStableFidelity songselectTopEdgeRepeat 保持 false | 完成 |
| AMQ-24123 更新 skin-renderer unit tests | 完成 |
| AMQ-24124 新增 skin-blend unit tests | 完成 |
| AMQ-24125 新增 skin-edge-repeat unit tests | 完成 |
| AMQ-24126 更新 script-order／capability contract tests | 完成 |
| AMQ-24127 測試只使用合成 RGBA fixtures，不複製第三方素材 | 完成 |
| AMQ-24128 更新 Skin framework contract | 完成 |
| AMQ-24129 更新四頁 visual traceability 的 renderer 限制 | 完成 |
| AMQ-24130 focused Skin／renderer 41/41 | 完成 |
| AMQ-24131 全部 Node test files 88/88 | 完成 |
| AMQ-24132 全部 Node test cases 253/253 | 完成 |
| AMQ-24133 Mapping Studio Chromium 30/30 | 完成 |
| AMQ-24134 Home/Catalog Chromium 19/19 | 完成 |
| AMQ-24135 Quiz/Results Chromium 19/19 | 完成 |
| AMQ-24136 Formal app-shell Chromium 150/150 | 完成 |
| AMQ-24137 Architecture Checker 1,256/0 | 完成 |
| AMQ-24138 JS/CJS syntax 180/180 | 完成 |
| AMQ-24139 Python browser harness compile 5/5 | 完成 |
| AMQ-24140 重新嘗試 HTTP-origin IndexedDB harness | 阻塞：Chromium ERR_BLOCKED_BY_ADMINISTRATOR |
| AMQ-24141 明確未將 opaque origin 當成真實持久化驗收 | 完成 |
| AMQ-24142 剩餘角色沒有真實語義 target 時維持 unsupported | 完成 |
| AMQ-24143 記錄 pixel contracts 尚非完整 native compositor | 完成 |
| AMQ-24144 更新逐檔 Node 測試證據及摘要 | 完成 |
| AMQ-24145 更新 WORK_STATUS／MASTER_CHECKLIST／handoff／next prompt | 完成 |
| AMQ-24146 更新 AI_START_HERE 與 README_FIRST 的最新入口 | 完成 |
| AMQ-24147 重新生成與驗證 MANIFEST.sha256（5,579 files，0 failures） | 完成 |
| AMQ-24148 建立完整 Batch241 ZIP 並驗證 CRC | 完成 |
| AMQ-24149 Batch242：在可用 origin 驗收 state-pair persistence | 待處理／環境阻塞 |
| AMQ-24150 Batch242：Canvas/image decode integration seam | 待處理 |
| AMQ-24151 Batch242：剩餘 visual roles 逐項語義審查 | 待處理 |

---

## Batch240：Renderer 接線、State Pair 持久化與四頁 Traceability（2026-10-29）

| 任務 | 狀態 |
|---|---|
| 以 Batch239 ZIP 作唯讀基準並核對 SHA-256 | 完成 |
| 建立獨立 Batch240 工作副本 | 完成 |
| 確認工作目錄無 Git 並維持未初始化 | 完成 |
| 保護來源 ZIP 與 AMQ／EMQ 原始資料 | 完成 |
| Mapping Studio 預覽實際呼叫 skinRenderer.fitStyle | 完成 |
| Mapping Studio 預覽實際呼叫 skinRenderer.logicalSize | 完成 |
| 顯示 raster intrinsic dimensions | 完成 |
| 顯示 @2x logical dimensions | 完成 |
| 新增 @2x fixture browser assertion | 完成 |
| 對 state-pair 角色顯示 Normal 預覽 | 完成 |
| 對 state-pair 角色顯示 Hover 預覽 | 完成 |
| 缺少 Normal 時顯示 AMQ fallback | 完成 |
| 缺少 Hover 時顯示 AMQ fallback | 完成 |
| 禁止自動借用其他角色素材填補 state pair | 完成 |
| 新增明確 Normal 素材選擇器 | 完成 |
| 新增明確 Hover 素材選擇器 | 完成 |
| 新增 fit mode 控制 | 完成 |
| 新增 image position 控制 | 完成 |
| 將 state pair 接入 app.navigation.back 正式 runtime | 完成 |
| Normal token 套用至正式返回按鈕 | 完成 |
| Hover token 套用至 hover 狀態 | 完成 |
| Hover token 套用至 focus-visible 狀態 | 完成 |
| reset 清除 normal／hover／fit／position tokens | 完成 |
| state pair 缺件時 adapter 不套用半套素材 | 完成 |
| state pair 兩張圖片都執行解碼驗證 | 完成 |
| state pair 套用保留既有 runtime role owner | 完成 |
| IndexedDB theme schema 升級至 v4 | 完成 |
| v1 theme migration 保留舊有 mappings | 完成 |
| v2 theme migration 保留舊有 roleMappings | 完成 |
| v3 theme migration 保留舊有角色映射 | 完成 |
| v4 roleStateMappings 正規化 | 完成 |
| 拒絕指向不存在素材的 state pair | 完成 |
| state pair IndexedDB save/reload round-trip | 完成（store test） |
| portable bundle 保持 format v1 向後相容 | 完成 |
| portable export 包含 roleStateMappings | 完成 |
| portable import 還原 Normal／Hover 路徑 | 完成 |
| portable import 驗證兩個素材路徑 | 完成 |
| portable import 缺件路徑拒絕測試 | 完成 |
| Mapping Studio 桌面 state-pair 版面 | 完成 |
| Mapping Studio 手機 state-pair 版面 | 完成 |
| 新增四頁 Visual Needs traceability matrix | 完成 |
| Traceability 記錄真實 runtime selector | 完成 |
| Traceability 記錄 CSS token consumer | 完成 |
| Traceability 記錄 geometry／state 行為 | 完成 |
| Traceability 記錄明確 fallback | 完成 |
| Traceability 區分 AMQ runtime slot 與 native stable fidelity | 完成 |
| 將 runtime role inventory 文件與測試更新為 35 | 完成 |
| 新增 Skin renderer unit test | 完成 |
| 新增 state pair store migration tests | 完成 |
| 新增 portable state pair round-trip test | 完成 |
| 新增 adapter pair apply/reset test | 完成 |
| 新增 adapter incomplete pair fallback test | 完成 |
| Chromium Mapping Studio 測試 @2x logical size | 完成 |
| Chromium Mapping Studio 測試完整 state pair | 完成 |
| Chromium Mapping Studio 測試缺件 fallback | 完成 |
| Chromium Mapping Studio 桌面／手機 layout | 完成 |
| Chromium Mapping Studio import/apply/export 流程 | 完成 |
| Chromium Mapping Studio 30/30 assertions | 完成 |
| Batch238 Home/Catalog regression 19/19 | 完成 |
| Batch239 Quiz/Results regression 19/19 | 完成 |
| 全部 86 個 Node test files 個別執行成功 | 完成 |
| 全部 245 個 Node test cases 0 failures | 完成 |
| Focused Skin／visual contract 58/58 | 完成 |
| Architecture Checker 1,228/0 | 完成 |
| JS/CJS syntax 185 個檔案 | 完成 |
| Python browser harness py_compile 5 個檔案 | 完成 |
| AMQ／EMQ 原始資料 SHA-256 未變 | 完成 |
| HTTP-origin IndexedDB 透過 loopback 驗收 | 阻塞：Chromium ERR_BLOCKED_BY_ADMINISTRATOR |
| 修正答案欄背景／文字 palette 與 4px 圓角 | 完成 |
| 更新 history/SRS 圓角及結果／答題舞台高度契約 | 完成 |
| formal app-shell Chromium harness 150/150 | 完成 |
| Native multiplicative tint/blend renderer | 待處理 |
| songselect-top 原生 edge-repeat renderer | 待處理 |
| Skin animation sequence renderer | 待處理 |
| app.navigation.options／settings.entry runtime state pair | 待處理：尚無核實 runtime target |
| live catalog／artwork／audio HTTP-origin 驗收 | 阻塞：origin policy／環境 |
| Candidate302／Candidate382 Stage 0 相容性 | 阻塞：原始基準不在專案包 |
| 更新 WORK_STATUS／handoff／next prompt／AI_START_HERE | 完成 |
| 更新 MANIFEST.sha256 並驗證 5,478 個檔案 | 完成 |
| 建立 Batch240 完整 ZIP 並驗證 CRC | 完成 |

---

## Batch239：Quiz Arena、Results 與 Skin renderer primitives（2026-10-29）

| 任務 | 狀態 |
|---|---|
| 核對 Batch238 ZIP SHA-256 與獨立工作副本 | 完成 |
| 確認沒有 Git repository，且未初始化 `.git` | 完成 |
| 保護來源 ZIP、AMQ／EMQ 原始資料與既有 state owner | 完成 |
| 建立 Quiz Arena 正式面板層級 | 完成 |
| 保留回合設定與題庫篩選控制 | 完成 |
| 建立桌面四格回合狀態摘要 | 完成 |
| 建立高層級答題舞台與題目資訊層級 | 完成 |
| 保留既有 QuizSession／AudioService 與計時規則 | 完成 |
| 答案輸入／提交操作具足夠高度與焦點狀態 | 完成 |
| 主要猜歌操作具桌面清楚分組與手機兩欄佈局 | 完成 |
| 揭曉答案區分作品／歌曲／歌手欄位 | 完成 |
| 歷史與 SRS 保留獨立資訊分區 | 完成 |
| Results 空狀態具產品層級與明確下一步 | 完成 |
| Results 僅顯示既有已保存計分資料 | 完成 |
| 結果 CTA 導回猜歌設定 | 完成 |
| 結果長標題／來源／metadata 安全換行 | 完成 |
| 新增 `skin-renderer.js` 純 renderer primitives | 完成 |
| `@2x` 圖片邏輯尺寸換算 | 完成 |
| 非法 intrinsic 尺寸安全拒絕 | 完成 |
| contain／cover fit 語義與 anchor 測試 | 完成 |
| normal／hover 顯式檔名配對與缺件 fallback | 完成 |
| 明確不宣稱 native tint／edge-repeat 支援 | 完成 |
| 新增 renderer unit tests | 完成 |
| 新增 Quiz／Results desktop Chromium harness | 完成 |
| 新增 Quiz／Results 390px mobile Chromium harness | 完成 |
| 驗證 Quiz navigation heading focus | 完成 |
| 驗證主要操作控制各存在一次 | 完成 |
| 驗證 desktop 摘要四欄 | 完成 |
| 驗證 mobile 摘要兩欄 | 完成 |
| 驗證 mobile answer form 堆疊 | 完成 |
| 驗證 mobile action grid 兩欄 | 完成 |
| 驗證 Results empty state 無假結果 | 完成 |
| 驗證 Results CTA 返回 Quiz | 完成 |
| 驗證超長標題與 metadata 不造成溢位 | 完成 |
| 驗證 browser page errors 為 0 | 完成 |
| 驗證 Quiz／Results 桌面與手機頁面無水平溢位 | 完成 |
| 重跑 Batch238 Home／Catalog Chromium regression | 完成 |
| 建立 Home／Catalog／Quiz／Results selector-to-consumer matrix | 完成 |
| 新增 results.primary-action runtime role | 完成 |
| 更新 runtime role inventory 測試預期 | 完成 |
| Focused Node tests 35/35 | 完成 |
| 全部 86 個 Node test files 個別執行 exit 0 | 完成 |
| Architecture Checker 1,228/0 | 完成 |
| 全部 176 個 JS/CJS syntax check | 完成 |
| 4 個 Python browser harness compile | 完成 |
| AMQ／EMQ 原始資料 SHA-256 保持不變 | 完成 |
| MANIFEST.sha256 5,374 個檔案全量驗證 | 完成 |
| ZIP CRC／解壓完整性 | 完成 |
| 產出 Batch239 完整專案 ZIP | 完成 |
| HTTP-origin IndexedDB save/reload | 阻塞／未驗收 |
| Native tint/blend、edge-repeat、動畫 renderer | 待處理 |
| Skin Override Editor 完整 round-trip | 待處理 |
| Candidate302／Candidate382 Stage 0 相容性 | 阻塞：原始基準不在專案包 |
| 更新 WORK_STATUS／handoff／next prompt／manifest | 完成 |

---

## Batch238：首頁與選歌第一輪正式視覺框架

| 任務 | 狀態 |
|---|---|
| 核對 Batch237 SHA-256 與來源基準 | 完成 |
| 保留來源 ZIP、AMQ／EMQ 資產與既有基準 | 完成 |
| 首頁 hero 字級、行距、寬度與層級 | 完成 |
| 首頁背景光暈與軌道層不遮擋互動元件 | 完成 |
| 首頁中心主動作 surface／對比 | 完成 |
| 五個首頁入口的語義色標與 hover surface | 完成 |
| 首頁保留原本預設收合行為 | 完成 |
| 首頁桌面入口不重疊 | 完成 |
| 首頁手機入口不重疊 | 完成 |
| 首頁手機寬度無水平溢位 | 完成 |
| 首頁尊重 prefers-reduced-motion | 完成 |
| 選歌頁主面板視覺層級與邊界 | 完成 |
| 選歌頁標題列／狀態／重新載入控制 | 完成 |
| 選歌頁桌面三欄框架 | 完成 |
| 選歌頁中尺寸兩欄框架 | 完成 |
| 選歌頁手機單欄框架 | 完成 |
| 搜尋與主要篩選區 surface 層級 | 完成 |
| 進階篩選與管理 disclosure surface | 完成 |
| 歌曲列高度支援作品封面 | 完成 |
| 桌面作品封面槽位增至 48×64px | 完成 |
| 手機作品封面槽位設為 42×56px | 完成 |
| 選取列與鍵盤 focus-visible 對比 | 完成 |
| 選取歌曲詳情面板框架 | 完成 |
| 保留真實 artwork adapter 與 attribution 行為 | 完成 |
| 缺少封面時維持來源感知 fallback | 完成 |
| 不使用 OSK 素材冒充作品封面 | 完成 |
| 手機隱藏次要欄位但保留歌曲／作品／選取資訊 | 完成 |
| 新增 Batch238 CSS contract assertions | 完成 |
| 新增獨立 Chromium home/catalog harness | 完成 |
| 桌面首頁／選歌視覺幾何驗證 | 完成 |
| 手機首頁／選歌視覺幾何驗證 | 完成 |
| 瀏覽器 uncaught exceptions 檢查 | 完成 |
| Browser evidence 不覆寫舊批次產物 | 完成 |
| 全量 Node suite | 待處理 |
| 全套 app-shell browser harness | 待處理 |
| Quiz Arena 正式 UI 視覺替換 | 待處理 |
| Results 正式 UI 視覺替換 | 待處理 |
| 真實 HTTP-origin 曲庫／封面驗收 | 阻塞 |
| 完整 Skin selector/CSS consumer traceability | 進行中 |
| `@2x` 邏輯尺寸 renderer | 待處理 |
| normal/hover state-pair renderer | 待處理 |
| songselect-top edge-repeat renderer | 待處理 |
| stable tint/blend renderer | 待處理 |
| Skin Override Editor round-trip | 待處理 |
| 更新工作狀態／handoff／next prompt | 完成 |
| 重建並驗證 MANIFEST.sha256（5,362 個檔案） | 完成 |
| 產出 Batch238 完整專案 ZIP | 完成 |

---

## Batch237：需求優先的 AMQ 視覺槽位與映射工作區

| 任務 | 狀態 |
|---|---|
| 完成 AMQ 視覺需求初版 JSON manifest（30 個槽位） | 完成 |
| 建立 requirements-first runtime registry | 完成 |
| Mapping Studio 顯示 AMQ 視覺需求基準板 | 完成 |
| 顯示每個需求的素材指定覆蓋率 | 完成 |
| 顯示每個需求的 runtime support 覆蓋率 | 完成 |
| 建立 AMQ visual needs traceability matrix | 完成 |
| 為 catalog filter 建立獨立 AMQ 角色 | 完成 |
| 同步 runtime role contract 與文件 manifest | 完成 |
| 加入 visual needs manifest 交叉引用測試 | 完成 |
| 加入官方 stable asset 語義禁區測試 | 完成 |
| 更新 Chromium Skin mapping harness 以載入 needs registry | 完成 |
| 驗證需求板先於 role selectors 顯示 | 完成 |
| 驗證桌面需求板三欄 | 完成 |
| 驗證窄螢幕需求板單欄 | 完成 |
| 核對全部 30 個槽位與真實 DOM target | 待處理 |
| 核對全部 30 個槽位與 CSS consumer | 待處理 |
| 為首頁背景建立可測試的 cover/crop renderer | 進行中 |
| 為選歌上框架建立 edge-repeat renderer | 待處理 |
| 為選歌下框架建立獨立 stretch renderer | 待處理 |
| 為選曲列建立 normal/hover/selected 狀態 renderer | 待處理 |
| 為素材建立 intrinsic dimensions cache | 待處理 |
| 為 @2x 素材建立邏輯尺寸換算 | 待處理 |
| 為 normal/hover 檔案建立狀態配對器 | 待處理 |
| 為動畫序列建立 frame inventory | 待處理 |
| 為 stable blend/tint 行為建立可驗收規格 | 待處理 |
| 建立歌曲封面槽位與真實作品封面來源的隔離測試 | 待處理 |
| 確認 OSK 圖片不得自動填入歌曲封面 | 完成 |
| 確認 songselect-bottom 不映射播放器底座 | 完成 |
| 確認 ranking grade 不映射答題正誤 | 完成 |
| 建立 Skin Override Editor 表單結構 | 待處理 |
| 將 Override Editor 接入 resolver allowlist | 待處理 |
| 讓 Override Editor 即時預覽 region overrides | 待處理 |
| 讓 Override Editor 即時預覽 component overrides | 待處理 |
| 讓 Override Editor 使用既有 IndexedDB store | 待處理 |
| 驗證 Override Editor reload round-trip | 待處理 |
| 驗證 Override Editor export/import round-trip | 待處理 |
| 驗證 Override reset 恢復原始 inline styles | 待處理 |
| 以真實 aristia hima.osk 回歸需求板呈現 | 待處理 |
| 驗證缺件 Skin 不會讓必要 UI 槽位消失 | 完成 |
| 建立完整 Skin fixture 的授權來源檢查 | 待處理 |
| 分批執行全量 Node 測試第 1 組 | 待處理 |
| 分批執行全量 Node 測試第 2 組 | 待處理 |
| 分批執行全量 Node 測試第 3 組 | 待處理 |
| 定位 formal app-shell browser harness timeout | 待處理 |
| 重新驗證 HTTP-origin IndexedDB save/reload | 阻塞 |
| 驗證 Candidate302 相容性 | 待處理 |
| 驗證 Candidate382 Stage 0 CSS 比較 | 待處理 |
| 更新官方 Wiki traceability 引用 | 完成 |
| 更新 SKIN_FRAMEWORK_CONTRACT | 完成 |
| 更新 WORK_STATUS 與 handoff | 完成 |
| 重建並驗證 MANIFEST.sha256（5,362 個檔案） | 完成 |
| 產出 Batch237 完整 ZIP | 進行中 |

## Batch236：真實部分 OSK 檢查與幾何感知映射預覽（2026-10-29）
- [x] AMQ-2461 以真實使用者提供的 `aristia hima.osk` 驗證 parser；只保存 metadata/count audit，不將 Skin 圖片複製進專案。
- [x] AMQ-2462 保留重複 `[Mania]` section blocks，維持舊 `sections` 相容視圖，避免不同 key mode 的 skin.ini 區塊被靜默合併。
- [x] AMQ-2460 新增 Mania 圖片參照缺件 audit，忽略 `_blank`／顏色數值，缺件只警告、不拒絕部分 OSK。
- [x] AMQ-2461 修正 `selection-mode.png` 正式檔名辨識，保留 `selection-mode-osu.png` 相容。
- [x] AMQ-2462 新增 role-specific geometry preview rules：cover、repeat-x、stretch-x、stateful panel、intrinsic/semantic extension。
- [x] AMQ-2460 Mapping Studio 顯示幾何說明與對應預覽；缺件 Skin 顯示 `skin.ini` 參照警告。
- [x] AMQ-2461 Focused Node 49/49、Chromium OSK 21/21、Architecture 1,200/0。
- [x] AMQ-2462 真實 `aristia hima.osk` Chromium 匯入面板 5/5 檢查通過；IndexedDB 保存失敗被 UI 如實揭露。
- [!] AMQ-2460 Formal app-shell browser harness 超過 200 秒工具限制；本批全量 Node suite 未執行，不標記通過。
- [~] AMQ-2461 尚未實作原生 nine-slice／邊緣像素重複／blend tint／hover state pair／@2x 比例 renderer。
- [~] AMQ-2462 Skin Override Editor、47-role traceability matrix、真實 origin save/reload 與完整 UI 驗收仍待處理。

## Batch235：Skin 語義映射、覆寫持久化與映射工作區視覺（2026-10-29）
- [x] AMQ-2439 重新閱讀官方 Interface skinning 與 skin.ini 規格，核對背景 cover、選歌按鈕用途、上下框架伸縮、hover／動畫狀態、版本與 @2x 語義。
- [x] AMQ-2440 新增 `docs/SKIN_FRAMEWORK_CONTRACT.md`，定義資產語義、AMQ role、映射 studio、resolver、persistence、transfer 與 runtime 的責任邊界。
- [x] AMQ-2441 IndexedDB theme record 升級至 schema v3，向前遷移 schema v1/v2，保留素材、legacy mappings、roleMappings、skin.ini 與既有選擇。
- [x] AMQ-2442 使用同一份 `skin-resolver` 驗證並正規化 persistence overrides，拒絕無效結構並丟棄 allowlist 以外的樣式屬性。
- [x] AMQ-2443 portable theme format v1 增加可選 overrides 的 export/import round-trip，保留舊檔案無 overrides 時的匯入相容性。
- [x] AMQ-2444 修正 adapter 在 Catalog target 不存在但 region override 有效時的提前退出問題。
- [x] AMQ-2445 adapter DOM tests 覆蓋 region/component override、inline 原值恢復、reset 與 missing-target warnings。
- [x] AMQ-2446 Skin mapping studio 按頁面全寬分組，桌面三欄／平板兩欄／手機一欄；預覽保留比例並使用透明圖 checkerboard。
- [x] AMQ-2447 更新 Chromium OSK harness，實際檢查 desktop/mobile computed grid；OSK import + Skin layout 15/15 assertions PASS。
- [x] AMQ-2448 Skin focused tests 35/35 PASS；formal app shell 150/150 PASS；Architecture Checker 1,186/0；158 JS/CJS syntax 與 2 Python compile PASS。
- [!] AMQ-2449 全量 Node tests 序列與並行執行均超過命令時間限制，沒有宣稱全量通過。
- [!] AMQ-2450 完整 override 編輯器、真實 `.osk` 多版本驗收、HTTP-origin IndexedDB、live artwork/audio 與 Candidate302/Candidate382 Stage 0 仍未驗收。
- [~] AMQ-2463 Batch237：建立正式 override 編輯器及逐角色 DOM/CSS/fit/crop/anchor/state traceability，核對真正能對上的 osu! 原生素材。

## Batch234：Skin System First 起始垂直切片（2026-10-29）
- [x] AMQ-2430 核對 Batch233 基線 SHA-256 與 ZIP CRC，保留來源包並建立獨立工作副本。
- [x] AMQ-2431 參考官方 osu! Skinning 文件，確認 OSK 元素必須經 AMQ 語義角色映射，不能視為整個網站 UI。
- [x] AMQ-2432 新增 `src/skins/skin-resolver.js`，定義 defaults → selected Skin → region override → component override 的固定優先順序。
- [x] AMQ-2433 resolver 只接受明確 allowlist 樣式屬性，驗證型別、範圍、枚舉與色彩格式；拒絕任意 CSS 與危險 URL。
- [x] AMQ-2434 `theme-adapter.js` 接入區域／元件覆寫並在 reset 清理受控樣式；未知區域／角色明確 warning。
- [x] AMQ-2435 新增 resolver 測試 3/3 PASS；resolver／adapter／transfer／store focused tests 26/26 PASS。
- [~] AMQ-2436 覆寫尚未接入 IndexedDB schema migration 與 portable theme transfer，下一批優先完成並保護舊格式遷移。
- [~] AMQ-2437 Skin 管理 UI、真實 OSK 匯入後覆寫保存／重載、Chromium 視覺驗收及整站元件覆蓋率仍未完成。
- [!] AMQ-2438 真實 `.osk`、HTTP-origin IndexedDB、live 曲庫／封面／音訊與 Candidate302／Candidate382 Stage 0 仍未驗收；不得宣稱 Skin System 或 UI 完成。

## Batch232：跨頁導覽重置捲動位置（2026-10-29）
- [x] AMQ-2134 從 Batch231 工作副本接續；檢查路由 owner，確認 `app-shell.js` 是正式跨頁導航唯一 owner，設定快速跳轉由獨立 handler 處理。
- [x] AMQ-2135 `src/ui/app-shell.js` 在跨頁導航後將 scroll position 重置至頁首，使用 auto behavior，保留 focus restoration 與 Quiz setup heading focus。
- [x] AMQ-2136 保留 Settings `data-settings-jump` 頁內跳轉，不把區塊導覽誤改為頁首跳轉。
- [x] AMQ-2137 Chromium mobile regression 先把 Catalog 捲至 520px，再切換 Quiz，驗證 `scrollY === 0` 且目的頁 heading 可見。
- [x] AMQ-2138 Chromium formal shell 141/141；Catalog/UI CSS focused tests 3/3；OSK browser 12/12；Architecture 1,172/0。
- [x] AMQ-2139 延續 Batch231 的 81/81 非-tooling Node tests、11/11 tooling focused subset；181 JS/CJS syntax 與 2 Python compile PASS；AMQ／EMQ assets SHA 未變。
- [x] AMQ-2140 更新 WORK_STATUS、MASTER_CHECKLIST、AI start、README、traceability、handoff、next prompt、evidence、Manifest 與完整 ZIP。
- [!] AMQ-2141 HTTP-origin IndexedDB、真實 `.osk`／live artwork／音訊與 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- [ ] AMQ-2142 Batch233：完成首頁／結果頁可驗證的空狀態、CTA、焦點與手機 UI 改善。

## Batch227：真正移除 Quiz question-card 全域舊 CSS（2026-10-29）
- [x] AMQ-2412 開工前讀取規範、工作狀態、主清單、Batch226 handoff／提示、架構、traceability、OSK audit 與 leaderboard trust contract；確認無 `.git`，未初始化；正式基準原始檔缺席。
- [x] AMQ-2413 核對 `.quiz-question-card` 僅出現在 Quiz 與 Multiplayer 正式頁；確認 quiz panel 已有專屬 answer-stage styles，multiplayer card 需要明確 shell layout。
- [x] AMQ-2414 從 `src/styles.css` 移除全域白底／12px 圓角 `.quiz-question-card` 舊規則與 `.quiz-question-card .notice` 舊 margin。
- [x] AMQ-2415 在 `src/styles/ui-shell.css` 明確接管 multiplayer question card 的 padding／border／radius／dark surface／shadow。
- [x] AMQ-2416 移除 question-card／history／SRS／learning metrics legacy override group 的不必要 `!important`，保留新 shell 與 skin background layering。
- [x] AMQ-2417 擴充 `quiz-ui-state.contract.test.cjs`，驗證 global legacy selector 已不存在且 shell replacement 存在。
- [x] AMQ-2418 Chromium formal shell 119/119 PASS；multiplayer card layout、history／SRS／learning metrics 暗色樣式在移除 `!important` 後仍正常。
- [x] AMQ-2419 全量 81 個 Node test files 逐檔 exit 0。
- [x] AMQ-2420 Architecture 1,165 PASS／0 FAIL；167 JS/CJS syntax PASS；3 Python `py_compile` PASS；AMQ／EMQ asset hash 未變。
- [x] AMQ-2421 更新 WORK_STATUS、MASTER_CHECKLIST、handoff、next prompt、AI start docs、README、traceability、OSK audit、regression evidence、manifest 與完整 ZIP。
- [!] AMQ-2422 HTTP-origin IndexedDB save/reload 仍因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 未驗收。
- [~] AMQ-2423 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。

## Batch227 下一批優先
1. 盤點 quiz answer form input 的 legacy global `!important` palette 依賴，確認 Settings／Catalog／Multiplayer 使用範圍。
2. 在正式 shell 明確接管必要 input surface 後，才移除可安全替換的舊樣式與 `!important`。
3. 繼續保護桌面／390px browser UI、完整 Node suite、資產 hash 與正式基準邊界。

## Batch226：多人回合狀態與結果明細手機 UI（2026-10-29）
- [x] AMQ-2399 開工前讀取規範、工作狀態、主清單、Batch225 handoff／提示、架構、traceability、OSK audit 與 leaderboard trust contract；確認無 `.git`，未初始化；正式基準原始檔缺席。
- [x] AMQ-2400 多人 error alert 初始 hidden；有訊息時顯示並提供 `data-error-state`／`data-error-code`，成功恢復時清除空 banner。
- [x] AMQ-2401 多人 round status 區分 active／submitted／expired；本機玩家提交狀態從伺服器答案快照判斷，期限到達只提示等待伺服器結算。
- [x] AMQ-2402 多人音訊狀態以 `data-audio-state` 投影 waiting／loading／playing／paused／failed／ended／cancelled 等狀態，保留既有 AudioService／playback lease owner。
- [x] AMQ-2403 結果明細 summary／title／metadata／note 加入安全換行與手機樣式。
- [x] AMQ-2404 擴充 `multiplayer-panel.integration.test.cjs`，驗證 error hidden／visible／cleared、round active／submitted 與 audio failed state。
- [x] AMQ-2405 新增 `multiplayer-ui-state.contract.test.cjs`，驗證 error／round／audio state 語義與結果 metadata wrapping。
- [x] AMQ-2406 Chromium formal shell 118/118 PASS；桌面／390px 手機多人狀態視覺與超長結果明細 fixture 無溢位。
- [x] AMQ-2407 全量 81 個 Node test files 逐檔 exit 0。
- [x] AMQ-2408 Architecture 1,165 PASS／0 FAIL；167 JS/CJS syntax PASS；3 Python `py_compile` PASS；AMQ／EMQ asset hash 未變。
- [x] AMQ-2409 更新 WORK_STATUS、MASTER_CHECKLIST、handoff、next prompt、AI start docs、README、traceability、OSK audit、regression evidence、manifest 與完整 ZIP。
- [!] AMQ-2410 HTTP-origin IndexedDB save/reload 仍因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 未驗收。
- [~] AMQ-2411 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。

## Batch226 下一批優先
1. 逐頁找出猜歌答題舞台／結果頁／多人面板尚存的舊 CSS islands，確認要真正替換而不是只覆蓋。
2. 完成各頁 hover／focus／busy／disabled／empty／error／touch 狀態。
3. OSK role 只有 DOM target 與 CSS consumer 都存在才接線。

## Batch225：猜歌音訊狀態／錯誤 banner 與觸控 UI（2026-10-29）
- [x] AMQ-2386 開工前讀取規範、工作狀態、主清單、Batch224 handoff／提示、架構、traceability、OSK audit 與 leaderboard trust contract；確認無 `.git`，未初始化；正式基準原始檔缺席。
- [x] AMQ-2387 猜歌音訊 badge 加入 live status 語義與 `data-audio-state`，loading／ready／playing／paused／blocked／failed 具不同視覺狀態。
- [x] AMQ-2388 `#quiz-error` 空內容時隱藏；真實錯誤才呈現 alert banner、`data-error-state` 與 `data-error-code`。
- [x] AMQ-2389 修正 stale audio error：state 保留舊 audioError 但 audio status 已恢復 playing 時不再顯示上一題錯誤。
- [x] AMQ-2390 答題操作按鈕至少 44px、手機 46px；答案建議項目至少 44px；加入 hover／disabled 狀態。
- [x] AMQ-2391 擴充 `quiz-panel.test.cjs`，驗證初始 alert 隱藏、音訊狀態 token、真實 audio failure 顯示與新回合恢復後錯誤清除。
- [x] AMQ-2392 新增 `quiz-ui-state.contract.test.cjs`，驗證 live status、錯誤狀態、觸控尺寸與響應式規則。
- [x] AMQ-2393 Chromium formal shell 108/108 PASS；桌面／390px 手機音訊狀態視覺與答題 touch target 通過，無水平溢位／uncaught exceptions。
- [x] AMQ-2394 全量 80 個 Node test files 逐檔 exit 0。
- [x] AMQ-2395 Architecture 1,158 PASS／0 FAIL；166 JS/CJS syntax PASS；3 Python `py_compile` PASS；AMQ／EMQ asset hash 未變。
- [x] AMQ-2396 更新 WORK_STATUS、MASTER_CHECKLIST、handoff、next prompt、AI start docs、README、traceability、OSK audit、regression evidence、manifest 與完整 ZIP。
- [!] AMQ-2397 HTTP-origin IndexedDB save/reload 仍因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 未驗收。
- [~] AMQ-2398 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。

## Batch225 下一批優先
1. 多人回合進行中／逾時／提交答案／音訊失敗狀態 UI。
2. 結果明細長標題、來源、尚未保存標記與 390px 換行。
3. 保持 server-authoritative room state、QuizSession／AudioService 單一 owner，不以 fake browser 資料宣稱 live audio 通過。

## Batch224：結果頁主要操作與多人焦點／觸控 UI（2026-10-29）
- [x] AMQ-2373 開工前讀取規範、工作狀態、主清單、Batch223 handoff／提示、架構、traceability、OSK audit 與 leaderboard trust contract；確認無 `.git`，未初始化；正式基準原始檔缺席。
- [x] AMQ-2374 結果頁空狀態新增「前往猜歌設定」主要操作；只導覽、不自動開始遊戲、不製造成績。
- [x] AMQ-2375 已完成結果區新增「返回猜歌設定」操作，保留 round-scoped persisted result owner 與未保存明細警告。
- [x] AMQ-2376 修正 `app-shell.js` 導覽至 quiz 時錯誤聚焦隱藏 Catalog 的 `[data-mode="AMQ"]`；改聚焦可見的 `#quiz-setup-heading`。
- [x] AMQ-2377 `multiplayer-panel.js` action busy lifecycle 保存焦點，操作完成／拒絕後恢復到可用控制項；若控制項變 disabled／hidden，焦點移到狀態提示。
- [x] AMQ-2378 結果主要操作與多人房間按鈕具備 hover／focus-visible／active、44px 最小觸控高度與手機版換行／重排。
- [x] AMQ-2379 新增 `results-ui.contract.test.cjs` 五項契約；多人 integration 驗證 pending command 與 server rejection 後的焦點恢復。
- [x] AMQ-2380 Chromium formal shell 104/104 PASS；結果頁 CTA 導覽焦點正確、多人 touch target 合格、390px 無水平溢位、無 uncaught exceptions。
- [x] AMQ-2381 全量 79 個 Node test files 逐檔 exit 0；`results-ui.contract.test.cjs` 5/5 PASS。
- [x] AMQ-2382 Architecture 1,151 PASS／0 FAIL；165 JS/CJS syntax PASS；3 Python `py_compile` PASS；AMQ／EMQ asset hash 未變。
- [x] AMQ-2383 更新 WORK_STATUS、MASTER_CHECKLIST、handoff、next prompt、AI start docs、README、traceability、OSK audit、regression evidence、manifest 與完整 ZIP。
- [!] AMQ-2384 HTTP-origin IndexedDB save/reload 仍因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 未驗收。
- [~] AMQ-2385 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。

## Batch224 下一批優先
1. 繼續猜歌答題舞台、多人回合狀態與結果明細的正式 UI 層級／錯誤狀態。
2. 逐頁驗證 hover／focus／disabled／busy／empty／error 與手機操作，不只做底層測試。
3. 保持真實資料與單一 state owner，不造排行榜；不重複建立既有狀態／取消機制。

## Batch223：Catalog 錯誤細節／重試 UI 與鍵盤焦點（2026-10-29）
- [x] AMQ-2361 開工前讀取規範、工作狀態、主清單、Batch222 handoff／提示、架構、traceability、OSK audit 與 leaderboard trust contract；確認無 `.git`，未初始化；正式基準原始檔缺席。
- [x] AMQ-2362 檢查 repository／runtime bootstrap 已有單一 AbortController、active load、mode invalidation 與 stale-response protection；不新增重複 request owner。
- [x] AMQ-2363 Catalog partial error 顯示輸入／可用／拒絕筆數；一般失敗顯示 code／message／reason／cause 與 retryable 提示，僅以 `textContent` 顯示。
- [x] AMQ-2364 Catalog root `aria-busy`、reload 動態文案／aria-label／error description，成功或失敗後恢復鍵盤焦點。
- [x] AMQ-2365 擴充隔離 Catalog mode-switch integration：partial details、failed、retry failure 保留原因、retry success 清錯、busy lifecycle 與 focus restoration PASS。
- [x] AMQ-2366 Catalog error banner／partial state／retry touch affordance／520px 以下 layout CSS；長錯誤訊息可換行。
- [x] AMQ-2367 Chromium formal shell 96/96 PASS；desktop error styling、390px 手機無水平溢位、無 uncaught exceptions。
- [x] AMQ-2368 全量 78 個 Node test files 逐檔 exit 0；`quiz-pool.test.cjs` 10/10；`source-runtime.integration.test.cjs` 真實 AMQ／EMQ／MIX 資產整合 assertions PASS。
- [x] AMQ-2369 Architecture 1,144 PASS／0 FAIL；164 JS/CJS syntax PASS；3 Python `py_compile` PASS；AMQ／EMQ asset hash 未變。
- [x] AMQ-2370 更新 WORK_STATUS、MASTER_CHECKLIST、handoff、next prompt、AI start docs、README、traceability、OSK audit、regression evidence、manifest 與完整 ZIP。
- [!] AMQ-2371 HTTP-origin IndexedDB save/reload 仍因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 未驗收；不把 inline Chromium 測試冒充 HTTP-origin。
- [~] AMQ-2372 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。

## Batch223 下一批優先
1. 真正繼續 UI：結果頁、多人頁與 Catalog 的 hover／focus／disabled／error／touch 狀態，補實作與 browser regression。
2. 逐頁檢查舊 UI／CSS 是否被真正替換，避免只隱藏舊實作。
3. HTTP-origin 測試只在 Chromium policy／origin 條件改變後重跑；不重做已存在的 repository cancellation。

## Batch222：Catalog 狀態矩陣與錯誤復原（2026-10-29）
- [x] AMQ-2352 擴充隔離 `catalog-mode-switch.integration.test.cjs`，涵蓋 `partial` 狀態、錯誤清除、filtered-empty、清除 filter 後回 loaded。
- [x] AMQ-2353 驗證 source-empty 與 filtered-empty 分離：真正空 snapshot 為 `data-catalog-state="empty"`；有資料但搜尋零匹配為 `filtered-empty`，文案／data attribute 各自正確。
- [x] AMQ-2354 驗證 source load failed 後透過 reload 成功恢復，舊 error 清除、正確 source rows 恢復。
- [x] AMQ-2355 Catalog mode-switch integration PASS，涵蓋 AMQ／EMQ／MIX、stale load、focus、partial、failed、retry、empty、filtered-empty。
- [x] AMQ-2356 Chromium formal shell 92/92 PASS；Architecture 1,144 PASS／0 FAIL；173 JS/CJS syntax PASS；3 Python browser tests `py_compile` PASS。
- [x] AMQ-2357 Batch221 全量 Node suite 78/78 PASS；Batch222 只擴充既有隔離 integration test，該測試個別重跑 PASS，未重跑完整 78 檔。
- [!] AMQ-2358 HTTP-origin persistence test 因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變而未重試；真實 save/reload assertions 未執行。
- [~] AMQ-2359 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。
- [x] AMQ-2360 更新主清單、工作狀態、traceability、handoff、下一批提示與 regression evidence；交付前重建 manifest／ZIP 並驗證完整性。

## Batch222 下一批優先
1. Catalog source load partial／failed 的 error detail 與重試次數、stale load cancellation 的 UI contract。
2. Multiplayer network／command error recovery 保持；production source 有變更時跑完整 Node suite。
3. 剩餘 13 個 OSK roles 只有在真實語義 DOM／CSS consumer 存在後才解除 unsupported。
4. HTTP-origin test 只在 browser policy／origin 改變後重跑。

## Batch221：隔離 Catalog mode-switch 整合測試與空曲庫狀態修正（2026-10-29）
- [x] AMQ-2341 新增獨立 `tests/catalog-mode-switch.integration.test.cjs`，不與既有多 mount 共用 DOM 的 Catalog fixture 混用 state／elements。
- [x] AMQ-2342 測試 AMQ→EMQ、AMQ→MIX mode switch：loading 期間清除舊 row／選取詳情，焦點回搜尋欄；成功載入後只顯示新 snapshot 的 source-aware records。
- [x] AMQ-2343 驗證較舊 AMQ load response 不會覆蓋後續 MIX load；載入失敗清除舊 rows/details 並顯示 failed/error 狀態。
- [x] AMQ-2344 發現並修正 `src/ui/catalog-browser.js` 的空資料狀態優先序：`dataStatus="empty"` 且 catalog snapshot 存在（但 size=0）時，原本錯誤顯示 `filtered-empty`。現在 source-empty 優先於 filtered-empty，兩者語義分離。
- [x] AMQ-2345 隔離 mode-switch 測試覆蓋真正 empty catalog，確認 `data-catalog-state="empty"`，不誤報「沒有符合條件的歌曲」。
- [x] AMQ-2346 全量 Node suite 78/78 PASS；平行測試時 `database-update-panel.test.cjs` 曾因執行時序出現一次暫時失敗，個別重跑通過，最終 78 個 test files 均有 PASS 狀態與 log。
- [x] AMQ-2347 Chromium formal shell 92/92 PASS；Architecture 1,144 PASS／0 FAIL；173 JS/CJS syntax PASS；3 Python browser tests `py_compile` PASS。
- [x] AMQ-2348 AMQ／EMQ 靜態資產 hash 未變，證據 `artifacts/batch221-regression/asset-hashes.txt`。
- [!] AMQ-2349 HTTP-origin persistence test 因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變而未重試；真實 save/reload assertions 未執行。
- [~] AMQ-2350 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。
- [x] AMQ-2351 更新主清單、工作狀態、traceability、handoff、下一批提示與 regression evidence；交付前重建 manifest／ZIP 並驗證完整性。

## Batch221 下一批優先
1. Catalog failed／partial／empty／filtered-empty 與 mode switch 的正式狀態矩陣、錯誤復原與 focus regression。
2. Multiplayer network／command error recovery 保持，production source 有變更時跑完整 Node suite。
3. 剩餘 13 個 OSK roles 只有在真實語義 DOM／CSS consumer 存在後才解除 unsupported。
4. HTTP-origin test 只在 browser policy／origin 改變後重跑。

## Batch220：多人命令網路失敗與連線恢復回歸（2026-10-29）
- [x] AMQ-2332 `tests/multiplayer-panel.integration.test.cjs` 注入 ready command 的網路失敗，確認 command error 不會被 connected rerender 清除，且 `aria-busy` 會在 finally 清除。
- [x] AMQ-2333 同一整合測試將 session 從 offline 拉回 connected，驗證暫時性 `MULTIPLAYER_NETWORK_ERROR` 在成功恢復後清除，ready state 仍以 server snapshot 為準。
- [x] AMQ-2334 Multiplayer panel integration PASS；Catalog focus/pagination integration PASS；QuizPanel fresh-mount result restore 與 Quiz History persistence focused tests維持 Batch219 PASS。
- [x] AMQ-2335 Chromium formal shell 92/92 PASS；Architecture 1,137 PASS／0 FAIL；172 JS/CJS syntax PASS；3 Python browser tests `py_compile` PASS。
- [x] AMQ-2336 Batch219 全量 Node suite 77/77 PASS；本批只擴充一個 integration test、不改 production source，該測試個別重跑 PASS，未重跑完整 77 檔。
- [!] AMQ-2337 HTTP-origin persistence test 因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變而未重試；真實 save/reload assertions 未執行。
- [~] AMQ-2338 Catalog mode-switch loading/focus 的專用隔離測試仍待建立；現有 catalog integration fixture 同時掛載多個 browser consumers 共用同一組 DOM，不能把該 fixture 當成獨立 mode-switch 驗收。未宣稱此項通過。
- [~] AMQ-2339 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。
- [x] AMQ-2340 更新主清單、工作狀態、traceability、handoff、下一批提示與 regression evidence；交付前重建 manifest／ZIP 並驗證完整性。

## Batch220 下一批優先
1. 建立隔離的 Catalog mode-switch integration fixture，驗證 AMQ／EMQ／MIX loading／failed／empty 與 focus／selection 清理，不共用多個 mount 的 DOM。
2. Multiplayer network error recovery 與 command rejection 測試維持；若 production source 有變更，重新跑完整 Node suite。
3. 剩餘 13 個 OSK roles 只有在真實語義 DOM／CSS consumer 存在後才解除 unsupported。
4. HTTP-origin test 只在 browser policy／origin 改變後重跑。

## Batch219：多人命令錯誤保持與可重試恢復（2026-10-29）
- [x] AMQ-2321 `src/ui/multiplayer-panel.js` 修正 command rejection 被 connected snapshot render 立即清掉的問題；`commandError` 由 command lifecycle 管理，成功操作清除，server rejection 保留至下一次操作。
- [x] AMQ-2322 仍維持 server-authoritative state：錯誤訊息只是 client command 結果，不會自行改寫 room snapshot／player ready state。
- [x] AMQ-2323 `tests/multiplayer-panel.integration.test.cjs` 加入 HTTP 409 `ROOM_COMMAND_REJECTED` 注入；驗證錯誤在 rerender 後仍可見、busy flag 清除、重試成功後錯誤清空並由 server snapshot 更新狀態。
- [x] AMQ-2324 `tests/catalog-browser.integration.test.cjs` 保留分頁焦點回退／篩選焦點恢復回歸；PASS。
- [x] AMQ-2325 `tests/quiz-panel.test.cjs` fresh-mount completed result restore 與 round-scoped row 測試 PASS；`quiz-history-store.test.cjs` persistence／round isolation PASS。
- [x] AMQ-2326 全量 Node suite 77/77 PASS；證據 `artifacts/batch219-regression/node-tests/summary.tsv`。
- [x] AMQ-2327 Chromium formal shell 92/92 PASS；Architecture 1,137 PASS／0 FAIL；172 JS/CJS syntax PASS；3 Python browser tests `py_compile` PASS。
- [x] AMQ-2328 AMQ／EMQ 靜態資產 hash 未變；證據 `artifacts/batch219-regression/asset-hashes.txt`。
- [!] AMQ-2329 HTTP-origin persistence test 因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變而未重試；真實 save/reload assertions 未執行。
- [~] AMQ-2330 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。
- [x] AMQ-2331 更新主清單、工作狀態、traceability、handoff、下一批提示與 regression evidence；交付前重建 manifest／ZIP 並驗證完整性。

## Batch219 下一批優先
1. Catalog AMQ／EMQ／MIX mode switch 與 loading／failed／empty／filtered-empty 的整合焦點／選取回歸。
2. 多人 network error 後 session 從 offline 到 connected 的 busy／command error lifecycle；保留可重試性。
3. 若修改 production source，重新跑完整 Node suite、Chromium、architecture、syntax。
4. 剩餘 13 個 OSK roles 只有在語義正確 DOM／CSS consumer 存在後才解除 unsupported。
5. HTTP-origin test 只在 browser policy／origin 改變後重跑。

## Batch218：結果頁重掛載／Catalog 分頁焦點／多人延遲命令（2026-10-29）
- [x] AMQ-2311 `tests/quiz-panel.test.cjs` 驗證 QuizPanel dispose 後重新 mount 會由既有 completed-round marker 恢復結果頁，並只顯示 matching roundId 的明細。
- [x] AMQ-2312 `tests/catalog-browser.integration.test.cjs` 驗證翻頁使 focused row 消失時，焦點回到搜尋輸入；不把焦點留在 detached row。
- [x] AMQ-2313 `tests/multiplayer-panel.integration.test.cjs` 注入可控延遲 server command，驗證 pending 時 `aria-busy=true`、重複 ready 操作 disabled、status 顯示操作中；命令完成後清除 busy 並以 server snapshot 更新狀態。
- [x] AMQ-2314 `tests/quiz-history-store.test.cjs` 重跑，確認 completed marker persistence／round ID isolation 契約仍通過。
- [x] AMQ-2315 Chromium formal shell 92/92 PASS；無 uncaught browser exceptions。
- [x] AMQ-2316 Architecture 1,137 PASS／0 FAIL；172 JS/CJS syntax PASS；3 Python browser tests `py_compile` PASS。
- [x] AMQ-2317 Batch217 全量 Node suite 77/77 PASS；Batch218 改動的 Catalog／QuizPanel／Multiplayer／History 四個測試檔個別重跑 PASS。由於本批只擴充測試、沒有改 production source，未重跑全部 77 檔。
- [!] AMQ-2318 HTTP-origin persistence test 因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變而未重試；真實 save/reload assertions 未執行。
- [~] AMQ-2319 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。
- [x] AMQ-2320 更新主清單、工作狀態、traceability、handoff、下一批提示與 regression evidence；交付前重建 manifest／ZIP 並驗證完整性。

## Batch218 下一批優先
1. 若有 production source 變更，先跑全量 77 Node test files，再跑 browser／architecture／syntax。
2. Catalog mode switch、loading／failed／empty 與 keyboard focus 整合回歸。
3. 多人 command 拒絕／網路失敗時 busy 清除與可重試狀態。
4. 剩餘 13 個 OSK roles 只有在真實語義 DOM／CSS consumer 存在後才解除 unsupported。
5. HTTP-origin test 只在 browser policy／origin 改變後重跑。

## Batch217：Catalog 鍵盤焦點／觸控與多人忙碌狀態（2026-10-29）
- [x] AMQ-2297 從 Batch216 工作樹延續，保留 Batch216 已交付 ZIP 不變；確認仍無 `.git`，不初始化；Candidate302／Candidate382 Stage 0 原始檔仍缺席。
- [x] AMQ-2298 `src/ui/catalog-browser.js` 在列表重繪時保留 focused source-aware row identity；row 仍可見時恢復焦點，row 被篩選掉時將焦點送回搜尋欄，避免焦點遺失。
- [x] AMQ-2299 Catalog 歌曲列加入 44px 觸控最小高度，長文字仍可換行增高；不改既有 row selection／播放 owner。
- [x] AMQ-2300 `src/ui/multiplayer-panel.js` 加入根節點 `aria-busy`、操作中 status 與離線錯誤恢復視覺；多人狀態仍以 server snapshot 為準。
- [x] AMQ-2301 `tests/catalog-browser.integration.test.cjs` 驗證 row 保留焦點與 row 被篩選掉時焦點回到搜尋欄；PASS。
- [x] AMQ-2302 `tests/catalog-filter-layout.contract.test.cjs`：12/12 PASS，涵蓋 44px touch target 與焦點恢復 contract。
- [x] AMQ-2303 `tests/multiplayer-panel.integration.test.cjs` 驗證 busy flag、離線 live error 與成功恢復後清錯；`quiz-panel.test.cjs`、`quiz-history-store.test.cjs` focused regression PASS。
- [x] AMQ-2304 Chromium formal shell 92/92 PASS；含 Catalog row 觸控高度、桌面／390px 手機響應式、無水平溢位與無 uncaught browser exceptions。
- [x] AMQ-2305 全量 77 個 Node test files 逐檔 exit 0；兩個較慢測試於整體命令時間上限後個別重跑，最終 77/77 PASS。證據 `artifacts/batch217-regression/node-tests/`。
- [x] AMQ-2306 Architecture 1,137 PASS／0 FAIL；172 JS/CJS syntax PASS；3 Python browser tests `py_compile` PASS。
- [x] AMQ-2307 AMQ／EMQ 靜態資料資產 hash 維持 Batch216 值，見 `artifacts/batch217-regression/asset-hashes.txt`。
- [!] AMQ-2308 HTTP-origin persistence test 因環境未變而未重試；`ERR_BLOCKED_BY_ADMINISTRATOR` 仍是已知阻塞，真實 save/reload assertions 未執行。
- [~] AMQ-2309 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收未完成；UI 主線未結案。
- [x] AMQ-2310 更新同一份主清單／狀態／traceability／handoff／下一批提示／證據；交付前重建 manifest 與 ZIP 並驗證完整性。

## Batch217 下一批優先
1. 結果頁 persisted round marker／round-scoped records 重載與保存失敗整合回歸。
2. Catalog 焦點在分頁、排序、模式切換、loading／failed 時的回歸；確認手機觸控布局。
3. 多人命令延遲期間的 disabled／aria-busy 與成功／失敗恢復測試。
4. 剩餘 13 個 OSK roles 只有具備真實語義 target／CSS consumer 後才解除 unsupported。
5. HTTP-origin test 僅在 browser policy／origin 改變後重跑。

## Batch216：學習清單作品識別／封面與跨頁 UI 狀態（2026-10-29）
- [x] AMQ-2283 核對 Batch215 來源 ZIP SHA-256、CRC 與 ZIP 內 manifest：3,583 entries 零 hash mismatch／missing；獨立解壓到 Batch216 workspace。無 `.git`，未初始化；Candidate302／Candidate382 Stage 0 原始檔缺席。
- [x] AMQ-2284 `src/ui/statistics-dashboard-panel.js` 從既有 runtime `catalogSnapshot()` 建立唯讀 source + song ID 索引；跨來源相同 song ID 不互相命中，未載入來源保留已保存名稱／明確 ID fallback。
- [x] AMQ-2285 學習歷史與 SRS 複習列重用 app 注入的 `artworkAdapter`；只對精確對應且有 `artworkRef` 的 record 請求，不建立第二 provider/cache。封面缺失／失敗有明確 fallback。
- [x] AMQ-2286 封面非同步結果以 render generation／dispose guard 保護；舊 render Promise 與 dispose 後 late completion 不會更新目前列表。
- [x] AMQ-2287 `src/app.js` 注入既有 runtime／artwork adapter／state store；未新增資料 owner。`ui-shell.css` 補學習列封面 slot、桌面／手機布局、hover／focus-visible／disabled／error 狀態。
- [x] AMQ-2288 `tests/statistics-dashboard-panel.test.cjs` 覆蓋精確 source-scoped record identity、跨來源重複 ID、作品名稱補全、封面非同步更新與 dispose 後 late completion。
- [x] AMQ-2289 `tests/app-shell.browser.test.py` 91/91 PASS；結果頁空狀態、多人 disabled style、學習列表手機封面欄與既有頁面響應式／無 uncaught exceptions 有檢查。
- [x] AMQ-2290 全量 Node tests：77/77 個 `tests/*.test.cjs` 逐檔 exit 0；`quiz-pool.test.cjs` 單獨執行 10/10；log 與 summary 在 `artifacts/batch216-regression/node-tests/`。
- [x] AMQ-2291 Architecture Checker 1,137 PASS／0 FAIL；172 JS/CJS syntax 與三個 Python browser tests `py_compile` 已執行，最終證據在 Batch216 regression artifacts。
- [x] AMQ-2292 AMQ／EMQ 靜態資料資產唯讀，hash 維持 Batch215 值；證據 `artifacts/batch216-regression/asset-hashes.txt`。
- [!] AMQ-2293 HTTP-origin storage／reload 本批未重試；同環境 Chromium loopback policy 仍為 `ERR_BLOCKED_BY_ADMINISTRATOR`，環境條件未變，真實 persistence assertions 未執行。
- [~] AMQ-2294 Catalog snapshot 只代表當前載入模式；跨模式無法對應的學習卡保留明確 ID／既有保存名稱，不啟動第二份曲庫載入流程。
- [~] AMQ-2295 真實外部 artwork API／音訊／`.osk`、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收仍未完成；UI 主線未結案。
- [x] AMQ-2296 更新同一份主清單、工作狀態、traceability、OSK gap audit、handoff、下一批提示與 Batch216 regression evidence；交付前重建 manifest／ZIP 並驗證完整性。

## Batch216 下一批優先
1. 完成 Catalog 鍵盤選取／觸控操作、loading／failed／filtered-empty 互動回歸。
2. 用真實已保存 round 驗證結果頁恢復、空／錯誤／新回合清除狀態。
3. 收尾多人頁 focus order、busy／offline／error 狀態及 server snapshot 變更回歸。
4. 剩餘 13 個 OSK roles 只有在有真實語義 DOM／CSS consumer 時才接線；不以增加數量為目的。
5. HTTP-origin test 僅在瀏覽器環境或 origin 改變時重跑；維持 manifest／handoff／ZIP 同步。

## Batch215：學習中心歷史／複習清單與設定快速導覽（2026-10-29）
- [x] AMQ-2264 從 Batch214 ZIP 建立獨立 Batch215 工作副本；確認無 `.git`，不初始化 Git；Candidate302／Candidate382 Stage 0 原始基準缺席，AMQ／EMQ 資產唯讀。
- [x] AMQ-2265 學習中心新增真實「最近答題紀錄」列表，資料只取既有 Quiz History Store 最近 8 筆，顯示歌曲、來源／作品、目標、結果與時間。
- [x] AMQ-2266 學習中心新增「到期複習清單」，使用既有 SRS `chooseSession()` due IDs 與 `snapshot()`，不把新卡或暫停卡當成到期卡。
- [x] AMQ-2267 學習資料讀取失敗會清空列表並顯示錯誤狀態，不把錯誤顯示成空成功或零到期。
- [x] AMQ-2268 不新增重複 persistence stores；學習列表只由原 Quiz History／SRS stores 投影。SRS 只有 song ID 時如實顯示 ID，不捏造歌曲標題。
- [x] AMQ-2269 新增歷史／複習項目深色視覺、正誤 badge、響應式排列與空／錯誤狀態。
- [x] AMQ-2270 `learning.history.item` 與 `learning.review.item` 接入真實 list container selector 及 CSS consumer；runtime roles 32→34，unsupported roles 15→13。
- [x] AMQ-2271 設定頁新增工作區／快捷鍵、帳號、備份／還原、曲庫更新、OSK 外觀五個快速入口；點擊後捲動並將焦點交給對應標題。
- [x] AMQ-2272 `tests/statistics-dashboard-panel.test.cjs` 驗證歷史項目、due SRS item、新卡排除與讀取失敗清理；PASS。
- [x] AMQ-2273 `tests/skin-contract-manifest.test.cjs`：9/9 PASS；`tests/skin-theme-adapter.test.cjs` PASS；確認 manifest／runtime contract 一致。
- [x] AMQ-2274 Chromium formal shell：86/86 PASS；含兩個新 role、設定導覽 focus、390px 手機單欄／無溢位與無 uncaught browser exceptions。
- [x] AMQ-2275 全量 Node test files：77/77 個逐檔 exit 0；`quiz-pool.test.cjs` 單獨重跑 10/10 PASS；日誌與 summary 位於 `artifacts/batch215-regression/node-tests/`。
- [x] AMQ-2276 Architecture Checker：1,137 PASS／0 FAIL；172 JS/CJS syntax PASS；2 Python browser test `py_compile` PASS。
- [x] AMQ-2277 AMQ／EMQ 靜態資產 SHA-256 維持既有值；證據 `artifacts/batch215-regression/asset-hashes.txt`。
- [!] AMQ-2278 HTTP-origin Playwright 再次被 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；本批只嘗試一次，真實保存／reload assertions 未執行，見 `artifacts/batch215-regression/http-origin-blocker.txt`。
- [~] AMQ-2279 複習列目前顯示 SRS 卡片的 song ID，待有可靠 source-aware title resolver 時再接標題／封面，不自行推測。
- [~] AMQ-2280 真實 `.osk`、曲庫／封面 API／音訊、Candidate302／Candidate382 Stage 0 相容性與完整桌面／手機實機驗收仍未完成；UI 主線未結案。
- [x] AMQ-2281 更新同一份 `MASTER_CHECKLIST.md`／`WORK_STATUS.md`、Wiki traceability、OSK role gap audit、AI start docs、next prompt、handoff、測試證據與 manifest。
- [x] AMQ-2282 交付前驗證 Batch215 ZIP CRC；直接讀取 ZIP 內 3,583 個 manifest entries 驗 hash，零 mismatch／missing；ZIP SHA-256 與 handoff 相符。

## Batch215 下一批優先
1. 評估可共用的 source-aware artwork/title resolver，將真實作品標題／封面安全接入學習歷史與複習清單；不得重複外部請求或將過期圖片掛到錯誤列。
2. 繼續結果頁、Catalog 與多人頁的 focus／hover／disabled／error／鍵盤／觸控 UI 回歸。
3. HTTP-origin 測試只有在瀏覽器環境或 origin 條件改變時重跑。
4. 更新主清單、工作狀態、traceability、handoff、manifest、測試證據與 ZIP；UI 主線未完成不得結案。

## Batch214：結果持久化生命週期與多人準備狀態 UI（2026-10-29）
- [x] AMQ-2247 開工前讀取 `AGENTS.md`、`AI_START_HERE.md`、工作狀態、主清單、Batch213 handoff、OSK gap audit 與排行榜契約；確認工作副本無 `.git`，不初始化；Candidate302／Candidate382 Stage 0 原始檔缺席，AMQ／EMQ 資產唯讀。
- [x] AMQ-2248 `src/persistence/quiz-history-store.js` 新增 `completeRound(roundId)`、`getLastCompletedRoundId()`、`clearLastCompletedRound()`，以獨立版本化 localStorage key 記錄最近完成回合；拒絕不匹配的 round ID，保存失敗明確回報。
- [x] AMQ-2249 新回合開始前清除上一輪完成指標；歷史明細仍以明確 roundId 隔離，不刪除跨回合答題歷史，也不把舊紀錄合併成新結果。
- [x] AMQ-2250 `src/engine/quiz-session.js` 在手動結束、題數完成及 pool exhaustion 結束路徑保存完成標記；保存失敗時留下警告，不回滾答題進度。
- [x] AMQ-2251 `src/ui/quiz-panel.js` 在 session idle 時可恢復最近已保存回合結果；開始新回合後回到空狀態。結果明細仍只查同一 history store 的 round-scoped records，不建立第二份 owner。
- [x] AMQ-2252 `tests/quiz-history-store.test.cjs`：26/26 PASS，新增 reload marker、new-round clear、round ID mismatch 與 marker write failure。
- [x] AMQ-2253 `tests/quiz-session.test.cjs`：40/40 PASS，覆蓋手動結束、題數完成與 pool exhaustion 的完成標記。
- [x] AMQ-2254 `tests/quiz-panel.test.cjs` PASS；eligibility matrix 768/768；驗證 session 回到 idle 後恢復已保存結果、開始新回合隱藏上一輪結果。
- [x] AMQ-2255 `src/ui/multiplayer-panel.js` 將玩家名稱與準備狀態拆成語義 DOM；準備 badge 有可見文字、`data-ready` 與 `aria-label`，資料仍由伺服器 snapshot 決定。
- [x] AMQ-2256 `multiplayer.ready-state` 正式接入 `theme-adapter.js`、`ui-shell.css` 與兩份 skin manifest；runtime roles 31→32，只有準備 badge 消費專屬 token，剩餘 15 個 roles 維持 unsupported。
- [x] AMQ-2257 `tests/multiplayer-panel.integration.test.cjs` PASS；驗證 server snapshot 更新後 readiness DOM／ARIA 同步，不宣稱真實多客戶端驗收。
- [x] AMQ-2258 Chromium formal shell：77/77 PASS；桌面／390px 手機主要頁面無水平溢位，首頁入口無重疊，32 roles 都有 selector／CSS consumer，無 uncaught browser exceptions。證據 `artifacts/batch214-regression/`。
- [x] AMQ-2259 全部 77 個 `tests/*.test.cjs` 檔案逐檔 exit 0；summary 與逐檔 log 在 `artifacts/batch214-regression/node-tests/`。
- [x] AMQ-2260 `node tools/check-architecture.cjs`：1,137 PASS／0 FAIL；172 個 JS/CJS `node --check` PASS；兩個 Python browser test `py_compile` PASS。
- [!] AMQ-2261 HTTP-origin Playwright integration 已嘗試，但 Chromium 對 loopback 導航回報 `ERR_BLOCKED_BY_ADMINISTRATOR`；`artifacts/batch214-regression/http-origin-blocker.txt` 已記錄。真實 HTTP-origin reload 斷言沒有執行，不能標為通過。
- [~] AMQ-2262 真實 `.osk`、正式曲庫／封面 API／音訊、HTTP-origin 儲存 reload、Candidate302／Candidate382 Stage 0 相容性及完整使用者驗收仍未完成；UI 主線未結案。
- [x] AMQ-2263 交付封包 `AMQ_Full_Rebuild_Batch214_Results_Persistence_Multiplayer_UI_20261029.zip`：manifest 3,469 entries 全部相符；ZIP 3,470 entries，`unzip -tq` 通過，ZIP 內 3,469 個 manifest entries 零缺漏／雜湊錯誤。

## Batch214 下一批優先
1. 在不受 Chromium loopback policy 阻擋的真實 HTTP-origin 環境重跑 `tests/app-shell.http-origin.test.py`，驗證保存、重載、新回合清空。
2. 繼續正式 UI：學習歷史／複習項目若要接 OSK role，先建立真實語義 DOM；接不上的角色保持 unsupported。
3. 繼續 Catalog、學習中心、設定與多人頁的桌面／手機視覺與操作收尾；不新增重複資料 owner。
4. 每批更新同一份工作清單、狀態、traceability、handoff、測試證據、manifest 與 ZIP。

## Batch213：獨立成績結果頁（2026-10-29）
- [x] AMQ-2241 `#quiz-round-results` 移至獨立 `#results-workspace`，新增真實初始空狀態。
- [x] AMQ-2242 `app-shell.js` 增加成績結果導航／intro；首頁五個入口保持不變。
- [x] AMQ-2243 QuizPanel 仍使用既有 QuizSession 與 history store，沒有重複建立資料 owner。
- [x] AMQ-2244 Chromium shell 75/75 PASS；結果頁手機 390px 無水平溢位。
- [~] AMQ-2245 結果保存／重載當時尚未驗收；由 Batch214 新增持久化完成指標與恢復 UI，HTTP-origin 實測仍受 Chromium policy 阻擋。
- [!] AMQ-2246 真實 HTTP-origin／曲庫／封面 API／音訊／`.osk` 與 Candidate302／Candidate382 Stage 0 仍未驗收。

## Batch212：Artwork lifecycle 與結算面板 Skin role（2026-10-29）
- [x] AMQ-2230 Catalog artwork stale-response／filter rerender／dispose 後 late Promise regression。
- [x] AMQ-2231 `results.panel` 接到 `#quiz-round-results`，加入專屬 CSS token consumer。
- [x] AMQ-2232 skin role runtime 30→31，manifest／CSS consumer／Chromium contract 同步。
- [x] AMQ-2233 `docs/OSK_ROLE_GAP_AUDIT_BATCH212.md` 明確記錄 unsupported roles 與解除條件。
- [x] AMQ-2234 skin contract 9/9、theme adapter 13/13；全量證據見 `docs/HANDOFF_BATCH212.md` 與 `artifacts/batch212-regression/`。

## Batch211：回合生命週期與 Catalog 封面 fallback（2026-10-29）
- [x] AMQ-2216–2220 回合手動結束／pool exhaustion／all-target／reveal／unplayed skip 與保存失敗回歸；不捏造未計分紀錄。
- [x] AMQ-2221–2225 Catalog 列與詳情維持作品封面 slot；provider throw／no-result／無 adapter／無 artworkRef／圖片 load error 都退回可讀作品標題 fallback。
- [x] AMQ-2226 建立可信排行榜資料契約草案；沒有正式 backend owner 前不造 PP／排名／PB。
- [x] AMQ-2227–2228 全量測試／syntax／Architecture 與資產唯讀證據見 `docs/HANDOFF_BATCH211.md`。
- [~] AMQ-2229 HTTP-origin、真實曲庫／封面 API／音訊／`.osk` 與 UI 全面驗收仍待完成。

## Batch210：共用學習統計資料的個人檔案頁（2026-10-29）
- [x] AMQ-2200 以 Batch209 工作副本為來源繼續開發；保留 `artifacts/batch209-regression/` 原始證據，Batch210 新測試與截圖另存 `artifacts/batch210-regression/`。
- [x] AMQ-2201 `src/ui/statistics-dashboard-panel.js` 將既有統計投影提供為 `getSnapshot()`／`subscribe()`，讀取錯誤與真實報表都由同一資料 owner 發布，不另建一組 History／Familiarity／SRS／Playback stores。
- [x] AMQ-2202 `src/ui/profile-panel.js` 新增本機個人進度面板，訂閱共用統計 snapshot；呈現計分目標紀錄、目標正確率、有答題紀錄的作品、SRS 到期卡片、明確熟悉度分級、自由播放紀錄、來源／目標表現與前六部作品進度。
- [x] AMQ-2203 個人檔案讀取失敗時所有數字顯示「暫不可用」而非 0；空資料顯示真實空狀態；沒有建立假帳號身分、PP、PB 或全球排名。
- [x] AMQ-2204 `src/index.html` 新增 `#profile-panel` 正式區塊及語義化指標／作品列表；`src/app.js` 在既有 statistics dashboard owner 建立後注入該 panel，使用同一份資料投影。
- [x] AMQ-2205 `src/ui/app-shell.js` 將個人檔案加入正式導航與首頁圓形選單；新增 profile page intro 與頁面狀態文案，保留既有首頁、選歌、猜歌、學習中心、設定頁。
- [x] AMQ-2206 `src/styles/ui-shell.css` 新增個人檔案的桌面三欄指標、作品進度、讀取錯誤與無資料視覺，以及手機單欄斷點；首頁五個入口經幾何檢查無重疊。
- [x] AMQ-2207 `tests/profile-panel.test.cjs` 新增 19 個 assertion，覆蓋讀取失敗、真實數據投影、空狀態、作品列表與 dispose/unsubscribe。
- [x] AMQ-2208 `tests/statistics-dashboard-panel.test.cjs` 驗證共享 snapshot、訂閱更新、讀取錯誤傳播與取消訂閱，不額外建立持久化 store。
- [x] AMQ-2209 Chromium formal shell 72/72 PASS；驗證五個首頁入口不重疊、個人檔案路由／六個指標、全球排名防造假文案、390px 手機無水平溢位與單欄指標。
- [x] AMQ-2210 77 個 `tests/*.test.cjs` 檔案全部逐檔 exit 0；Architecture Checker 1,137 PASS／0 FAIL；172 個 JS/CJS 檔案 `node --check` PASS；Python browser test `py_compile` PASS。
- [x] AMQ-2211 AMQ／EMQ 資產唯讀；其 SHA-256 維持 Batch208／209 相同值。Batch210 證據位於 `artifacts/batch210-regression/`。
- [~] AMQ-2212 個人檔案真實資料投影已實作，但目前 inline opaque-origin fixture 的本機儲存讀取失敗，因此畫面正確顯示「暫不可用」；必須在 HTTP-origin 真實資料環境驗收非空統計。
- [~] AMQ-2213 全球排行榜仍無可信伺服器資料 owner；本批只做本機個人進度，不建立排名／PP／PB。
- [!] AMQ-2214 Candidate302／Candidate382 Stage 0 原始基準仍缺席；工作副本無 `.git`，未初始化 Git，也未宣稱與正式基準相容。
- [~] AMQ-2215 UI 主線仍未結案；首頁、選歌、猜歌、遊戲設定、結果、個人檔案、排行榜、學習中心、設定仍需逐頁實作與真實環境驗收。

## Batch210 下一批優先
1. 補齊本輪結果面板在手動結束、題庫耗盡、all-target、reveal／unplayed skip、儲存失敗與重新開局時的完整狀態回歸。
2. 核實 Catalog 封面 provider fallback、沒有 `artworkRef`／API 失敗的視覺降級；保證歌曲列不會變成沒有意義的純文字占位。
3. 盤點排行榜需要的可信伺服器契約；沒有資料 owner 前只完成明確的未接入狀態，不造全球排名、PP 或 PB。
4. 更新同一份主清單、工作狀態、traceability、handoff、證據與完整 ZIP；真實 HTTP-origin／音訊驗收仍需明確標示。

## Batch209：資料驅動的本輪結果 UI 與 Catalog 狀態驗收（2026-10-29）
- [x] AMQ-2185 核對重傳 ZIP SHA-256：`7f66b7eee2ddbf2a315bd26294c393dbe3fa8960d7f35f09467892fe5664f844`；獨立解壓至 `/mnt/data/amq_batch209_work/project`，原始 ZIP 保持唯讀。
- [x] AMQ-2186 `quiz-history-store` 新增 `getRoundHistory(roundId)`，只查詢明確帶有該 round ID 的新版明細，不將 legacy／跨回合歷史混進單輪結果。
- [x] AMQ-2187 `getRoundHistory()` 以唯讀投影標示 detail row 是否已持久化；未保存列可見但明確標示，不將暫存在記憶體的紀錄計入已保存正確率。
- [x] AMQ-2188 QuizSession 將 history store 回傳的 round ID 加入狀態快照；新回合開始前先清空舊 ID，reset 時清空，避免新回合初始化失敗後重用舊結果。
- [x] AMQ-2189 猜歌頁新增獨立「本輪結果」區塊；只有回合進入 finished 才顯示，內容使用 round-scoped real records，不用跨回合摘要冒充單輪結算。
- [x] AMQ-2190 結果明細標示來源／目標／答題結果／已保存答題時間；僅依已保存計分目標計算正確率，揭曉與未播放跳過維持不寫入歷史的既有規則。
- [x] AMQ-2191 新增 round history 隔離與 detail persistence regression；`quiz-history-store` 23/23、`quiz-session` 37/37、Quiz Panel integration PASS（eligibility matrix 768/768）。
- [x] AMQ-2192 Chromium formal shell 65/65 PASS；結果區塊結構／初始隱藏、390px 手機無水平溢位、Catalog loading／failed／loaded 及 source-empty／filtered-empty 視覺狀態有明確斷言；無 uncaught browser exceptions。
- [x] AMQ-2193 全部 76 個 `tests/*.test.cjs` 檔案逐檔 exit 0；Architecture Checker 1,123 PASS／0 FAIL；170 個 JS/CJS 檔案 `node --check` PASS；Python browser test `py_compile` PASS。
- [x] AMQ-2194 `tests/app-shell.browser.test.py` 測試產物改寫至 `artifacts/batch209-regression/`；由原始 Batch208 ZIP 還原 `artifacts/batch208-regression/` 證據，避免覆寫前一批截圖／日誌。
- [x] AMQ-2195 AMQ／EMQ 資產 hash 維持不變，見 `artifacts/batch209-regression/asset-hashes.txt`；未修改曲庫資料。
- [~] AMQ-2196 本輪結果仍是猜歌頁內的結果區塊，尚未獨立成為全域導航頁；完整結果頁視覺與真實資料下的互動仍待使用者環境驗收。
- [!] AMQ-2197 真實 HTTP-origin IndexedDB／曲庫／音訊、真實 `.osk`、Candidate302／Candidate382 Stage 0 相容性仍未驗收；原始基準不在封包內。
- [~] AMQ-2198 個人檔案／排行榜的正式資料 owner 尚未核實；不建立假 PP、全球排名或 PB。
- [~] AMQ-2199 UI 主線未結案：首頁、選歌、猜歌、遊戲設定、結果、個人檔案、排行榜、學習中心、設定仍需逐頁完成。

## Batch209 下一批優先
1. 將結果區塊與完整回合流程接合：驗證正常完成、手動結束、題庫耗盡、儲存失敗、all-target 三目標與 reveal/unplayed skip 的顯示差異；結果資料不可超出已保存的真實契約。
2. 盤點學習中心／熟悉度 store 可支持的個人檔案內容；先做本機個人進度頁，只有資料 owner 足夠時才呈現指標。
3. 繼續選歌 UI 的封面 fallback、錯誤／空狀態、鍵盤與手機互動；真實曲庫／ANN／VNDB 不可用時清楚顯示未提供，不用假數據。
4. 更新同一份清單、工作狀態、traceability、handoff、證據與完整 ZIP；UI 未完成不得結案。

## Batch208：猜歌回合設定與答題舞台正式 UI 分區（2026-10-29）
- [x] AMQ-2173 先讀取開工規範、Batch207 handoff、同一份工作清單與 Wiki traceability；確認工作副本無 `.git`，Candidate302／Candidate382 Stage 0 原始檔不在封包中，不猜測基準、不初始化 Git。
- [x] AMQ-2174 `src/index.html` 將猜歌回合設定、即時回合舞台拆成具名語義 section；保留所有既有控制項 ID、QuizSession／QuizPanel 狀態 owner、答題歷史與 SRS 原位置。
- [x] AMQ-2175 設定區加入清楚的回合設定與出題篩選層級；即時回合區加入獨立狀態標題，答題歷史明確標示為本機答題紀錄；未新增虛構結果／PP／排名／PB。
- [x] AMQ-2176 `src/styles/ui-shell.css` 建立設定／即時回合的正式分區樣式、篩選 disclosure summary、鍵盤 focus-visible 與桌面／窄手機斷點；實際替換既有區塊層級，非僅隱藏舊 UI。
- [x] AMQ-2177 `tests/app-shell.browser.test.py` 新增 setup／round／filter／history 結構、原控制項保留、桌面三欄及 390px 單欄檢查；回歸證據 `artifacts/batch208-regression/`。
- [x] AMQ-2178 formal shell Chromium：61/61 PASS；`tests/quiz-panel.test.cjs` PASS（eligibility matrix 768/768）；`tests/catalog-browser.integration.test.cjs` PASS；Architecture Checker 1,123 PASS／0 FAIL。
- [x] AMQ-2179 `node --check src/ui/quiz-panel.js`、`node --check src/ui/app-shell.js`、`python -m py_compile tests/app-shell.browser.test.py` PASS；瀏覽器無 uncaught exceptions；桌面／390px 無水平溢位。
- [x] AMQ-2180 AMQ／EMQ 資產 SHA-256 維持既有值，未修改曲庫：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- [~] AMQ-2181 猜歌設定與回合舞台已有明確資訊層級，但真實音訊、真實曲庫載入及 HTTP-origin 持久化未驗收；inline Chromium fixture 不可替代。
- [~] AMQ-2182 真正的單輪結果頁仍未建立：目前可見的 `quiz-history` 是跨回合答題歷史，不應冒充單輪結果；需先確認 QuizSession/history 可提供的 round boundary／per-round detail，再建立真實資料驅動的結果頁。
- [!] AMQ-2183 Candidate302／Candidate382 Stage 0 原始基準缺席；工作副本無 `.git`，未初始化、未覆蓋基準或曲庫。
- [~] AMQ-2184 UI 主線未結案：首頁、選歌、猜歌、遊戲設定、結果、個人檔案、排行榜、學習中心、設定仍需持續逐頁實作／替換／驗收。

## Batch208 下一批優先
1. 檢查 QuizSession／quiz-history store 實際資料契約，若能可靠辨識每輪邊界，建立真實資料驅動的結果頁；否則記錄缺口，不以跨回合歷史偽裝單輪結果。
2. 評估個人檔案／排行榜所需資料是否已有正式 owner；只呈現真實存在的本機歷史／熟悉度資料，禁止合成 PP、全域排名或 PB。
3. 持續完成 Catalog 真實 loading／empty／failed 與封面 fallback 的視覺狀態；保留 HTTP-origin、真實曲庫／音訊驗收阻塞。
4. 每批更新本清單、工作狀態、handoff、traceability、測試證據及 ZIP；UI 未完成不得結案。

## Batch207：Catalog 選取回歸與 Quiz 狀態語義（2026-10-29）
- [x] AMQ-2164 Catalog integration 測試補上點擊／鍵盤選取後的詳情同步與 Enter 不播放音訊斷言。
- [x] AMQ-2165 新增篩選使目前選取記錄離開結果集時的回歸：詳情清空、空提示恢復、個人清單不再引用隱藏記錄；恢復篩選後可重新選取。
- [x] AMQ-2166 `tests/catalog-browser.integration.test.cjs` PASS；確認既有 `catalog-browser.js` 已正確清除失效 selection，因此不需改動 production logic。
- [x] AMQ-2167 擴充 `docs/OSU_STABLE_WIKI_TRACEABILITY_BATCH206.md`，明確記錄 Catalog 鍵盤行為、Quiz phase、Learning／Settings extension slots 與驗收邊界。
- [x] AMQ-2168 `tests/quiz-panel.test.cjs` PASS，涵蓋回合 phase、答題、下一題／finished、來源失敗、SRS 與模式切換；不把 osu! ranking 素材當 AMQ 正誤語義。
- [x] AMQ-2169 Architecture Checker 1,123 PASS／0 FAIL；formal shell 54/54、OSK panel 12/12、focused skin／Learning／Settings tests 23/23 subtests PASS。
- [~] AMQ-2170 Learning／Settings 空／錯誤狀態與鍵盤操作已有模組測試，但尚未完成真實瀏覽器逐頁互動／手機觸控驗收。
- [!] AMQ-2171 真實 `.osk`、HTTP-origin IndexedDB reload、真實曲庫／封面／音訊與 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- [~] AMQ-2172 正式 UI 尚未結案；首頁、選歌、遊戲設定、猜歌、結果、個人檔案、排行榜、學習中心、設定仍須持續逐頁設計／替換／驗收，不能因 Batch207 完成而結案。

## Batch206：逐頁 Wiki 追溯與首頁／導覽語義修正（2026-10-29）
- [x] AMQ-2157 首頁明確標示 AMQ adaptation，說明圓形主選單不是 osu!stable 原生元件。
- [x] AMQ-2158 導覽 `aria-current` 僅在作用中頁面設定 `page`；非作用中按鈕移除屬性。
- [x] AMQ-2159 建立五頁 Wiki traceability 矩陣，列出 stable 語義、AMQ DOM、extension slots、取捨與驗收邊界。
- [x] AMQ-2160 Chromium shell 回歸 54/54 PASS。
- [x] AMQ-2161 Skin／Catalog／Player focused suite 35/35 PASS；Architecture Checker 1,123 PASS／0 FAIL。
- [~] AMQ-2162 Catalog 鍵盤選取／篩選後 selection 清理仍待獨立互動測試，排入 Batch207。
- [!] AMQ-2163 真實 `.osk`、HTTP-origin IndexedDB reload、真實曲庫／封面／音訊與 Candidate302／Candidate382 Stage 0 相容性仍未驗收。

## Batch205：Wiki 語義追溯與 Skin mapping 防誤用
- [x] AMQ-2150 建立官方 Wiki 到 AMQ 正式 UI 的 traceability 文件，列出元件語義、落點、取捨與未驗收範圍。
- [x] AMQ-2151 修正 `menu-button-background.png` 的角色範圍，限制為 Catalog 歌曲列／選取狀態，不再把它當通用面板素材。
- [x] AMQ-2152 修正 `songselect-bottom.png` 的角色範圍，限制為選曲頁底框，不再自動套用到播放器底座。
- [x] AMQ-2153 同步更新文件 manifest 與 runtime skin contract，避免自動候選 UI 與 runtime 契約不一致。
- [x] AMQ-2154 新增語義防回歸測試，保護歌曲詳情、播放器、多人、學習、設定面板的 AMQ extension slot。
- [ ] AMQ-2155 完成首頁／選曲／猜歌／學習／設定逐頁 Wiki traceability 與實際 UI 驗收；本批尚未結案。
- [ ] AMQ-2156 以真實 `.osk` 與非 opaque HTTP-origin 驗收素材匹配、持久化重載及實際頁面視覺。

## Batch204：OSK runtime 跨頁套用修正
- [x] AMQ-2150 移除 role-aware mapping 對 `#catalog-browser` 的不必要硬依賴；legacy catalog slots 仍保留原 target 邊界。
- [x] AMQ-2151 新增 regression：Catalog target 不存在時，首頁 role target 仍可套用，reset 可清理 token。
- [x] AMQ-2152 驗證 theme adapter focused suite：13/13 PASS。
- [x] AMQ-2153 OSK import panel Chromium fixture：12/12 assertions PASS。
- [x] AMQ-2154 Architecture Checker：1,123 PASS／0 FAIL；本批 JS/CJS syntax checks PASS。
- [~] AMQ-2155 逐頁確認正式 DOM role target 與 stable 元件語義；本批只修跨頁套用阻塞，未宣稱 UI 完成。
- [!] AMQ-2156 真實 `.osk`、HTTP-origin IndexedDB reload、正式曲庫／音訊與真實瀏覽器視覺仍未驗收。


# Batch203（2026-10-28）OSK 人工覆寫候選治理
- [x] AMQ-2144 角色選單預設只列出 stable 檔名契約命中的候選；無關圖片不再自動出現在每個角色選單。
- [x] AMQ-2145 人工覆寫候選改為主動展開，並明示沒有 stable 檔名依據、不是自動建議。
- [x] AMQ-2146 已保存的人工覆寫在該角色保持可見，避免保存映射後無法重新選取。
- [x] AMQ-2147 Chromium fixture 驗證人工候選 opt-in、缺件 fallback、apply/reset、主題匯入／匯出；12/12 assertions PASS。
- [~] AMQ-2148 正式 UI 各頁與 stable 資產語意／DOM 落點逐頁整合；仍未結案。
- [!] AMQ-2149 真實 `.osk`、HTTP-origin IndexedDB reload 與正式曲庫／音訊 E2E 尚未驗收。

---

# Batch202（2026-10-28）OSK 契約真實性修正
- [x] AMQ-2137 Mapping Studio 只在本次 OSK 確實命中 stable 檔名時才顯示匹配狀態。
- [x] AMQ-2138 缺失 stable 素材明確顯示 fallback，不把其他圖片自動當成替代品。
- [x] AMQ-2139 人工覆寫候選與自動建議分開標示，說明正式 runtime target／未接線狀態。
- [x] AMQ-2140 Chromium OSK fixture 12/12 assertions PASS；包含缺件狀態回歸。
- [~] AMQ-2141 依 stable 頁面結構逐頁完成正式 UI 與 Skin runtime 的實質整合；本批未結案。
- [~] AMQ-2142 完成手動覆寫流程、Mapping Studio apply/reset/import/export/reload 與持久化整合驗收。
- [!] AMQ-2143 真實 `.osk` 與 HTTP-origin IndexedDB 端到端驗收仍受環境限制，尚未完成。

---

# Batch201（2026-10-28）正式 UI 第二輪：猜歌舞台、學習中心、設定與 OSK runtime
- [x] AMQ-2123 猜歌正式 UI：設定分組、回合資訊卡、答題舞台、輸入／提交、操作列、揭曉、歷史與 SRS 視覺分層。
- [x] AMQ-2124 學習中心七項既有統計改為四欄桌面／單欄手機布局，不生成假數據。
- [x] AMQ-2125 設定頁偏好／排序雙欄、快捷鍵桌面三欄／手機單欄，帳號／備份／更新／OSK 保持可見。
- [x] AMQ-2126 修正設定／OSK 舊版白底提示，改善錯誤與警告提示的深色視覺。
- [x] AMQ-2127 OSK runtime role 由 21 擴充至 30，新增 9 個有真實 DOM target 與 CSS token consumer 的角色。
- [x] AMQ-2128 Chromium formal shell 50/50 PASS，含 30 個 runtime role selector 與 CSS consumer contract。
- [x] AMQ-2129 9 個 focused Node test files 38/38 PASS；Architecture 1,123/0；src／tests JS/CJS syntax PASS。
- [~] AMQ-2130 Catalog ArrowUp／ArrowDown／Enter、篩選後清空選取的互動 E2E 仍待完成。
- [~] AMQ-2131 Mapping Studio reset／匯入匯出／重載仍待 fixture 與真實 `.osk` 分層驗收。
- [~] AMQ-2132 其餘 17 個 Skin contract roles 需逐一核對是否有語義正確的正式 UI target；不可硬接到不相關元件。
- [!] AMQ-2133 真實曲庫／封面／音訊、HTTP-origin IndexedDB、真實 `.osk` E2E 受目前瀏覽器環境限制，尚未驗收。
- [ ] AMQ-2134 Batch202：逐角色處理未支援的 OSK contract，並補 Mapping Studio 行為回歸。
- [ ] AMQ-2135 Batch202：逐頁完成 focus／hover／disabled／error 與手機操作的 UI 收尾。
- [ ] AMQ-2136 Batch202：產生新截圖、更新同一份工作清單／handoff／manifest／ZIP；UI 未驗收項目不可結案。

# Batch200（2026-10-28）正式 UI 視覺一致性第一輪
- [x] AMQ-2113 猜歌／學習中心／設定新增正式頁面標題區與用途描述，不注入 mock data 或虛構統計。
- [x] AMQ-2114 猜歌頁將單人猜歌置於多人房間之前，降低首屏被登入／網路狀態佔據的比例。
- [x] AMQ-2115 統一首頁主選單、全域導覽、頁面標題區與主要面板的深色 osu!stable-inspired 視覺及鍵盤 focus 樣式。
- [x] AMQ-2116 修正猜歌問題區／答題歷史／SRS 與學習統計卡片殘留白底的視覺回歸。
- [x] AMQ-2117 Chromium formal shell 37/37 PASS；桌面／手機五頁無水平溢位檢查與各頁截圖已產生，證據 `artifacts/batch200-regression/`。
- [x] AMQ-2118 Architecture Checker 1,123/0；174 個 JS/CJS 語法檢查 PASS。
- [~] AMQ-2111 Catalog ArrowUp／ArrowDown／Enter、選取詳情與篩選後清空選取仍需互動 E2E；本批沒有宣稱完成。
- [~] AMQ-2112 Mapping Studio apply/reset/import/export/reload 仍需一般 HTTP-origin／真實 `.osk` 驗收；此環境的 localhost Chromium 導覽受政策阻擋。
- [x] AMQ-2119 Batch201：對照 `prototype/ui-v2-osu-select-batch146` 完成猜歌正式 UI 分組與答題舞台視覺；保留既有功能與單一狀態 owner。
- [x] AMQ-2120 Batch201：學習中心統計摘要／作品進度／來源表現／熟悉度／SRS／自由播放／每日紀錄重排成可掃讀層級，空狀態不可虛構數據。
- [x] AMQ-2121 Batch201：設定頁桌面與手機分區、長表單密度、OSK Mapping Studio 角色支援狀態視覺整理。
- [x] AMQ-2122 Batch201：逐頁盤點可套用 OSK role 的 selector／CSS consumer／fallback/reset，僅將實際接線角色標為 supported。
- [!] AMQ-2110 真實曲庫／封面／音訊、HTTP-origin IndexedDB 與真實 `.osk` E2E 未驗收；不得以 inline fixture 代替。

---

# AMQ 全新架構重建主工作清單

> 本檔是唯一主清單。每次交付更新此檔，不另開互相矛盾的清單。
> 狀態：`[ ]` 待處理、`[~]` 進行中、`[x]` 已完成且有證據、`[!]` 阻塞、`[-]` 不適用（附理由）。

## 工作原則
- 一次處理完整模組與相關測試，不逐個小項目停下。
- 遇阻塞記錄原因、影響與解除條件，繼續其他工作。
- 沒有測試證據不可標記完成。
- 缺少舊原始碼時可完成框架與規格，但不得假裝完成遷移。


### Batch199（2026-10-28）Catalog 狀態與可存取性
- [x] AMQ-2104 Catalog 狀態由既有 app state／query snapshot 衍生，明確區分 loading／failed／empty／loaded／filtered-empty 等狀態；不建立重複狀態來源。
- [x] AMQ-2105 Catalog status、empty-state、selection detail 加入 live-region 語意及狀態屬性。
- [x] AMQ-2106 狀態視覺區分載入、失敗、來源無資料、篩選無結果與正常載入。
- [x] AMQ-2107 新增 Catalog state／keyboard／checkbox contract tests；12 個 focused test files 47/47 PASS。
- [x] AMQ-2108 Chromium app-shell 31/31 PASS；Architecture 1,123/0；174 個 JS/CJS syntax checks PASS。
- [!] AMQ-2109 HTTP-origin Chromium 導覽被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；curl 可取 HTTP 200。解除條件：允許本機 HTTP 導覽的瀏覽器環境。
- [!] AMQ-2110 真實曲庫／封面／音訊、HTTP-origin IndexedDB 與真實 `.osk` E2E 未驗收；不可由 inline fixture 代替。
- [ ] AMQ-2111 Batch200：以注入 fixture 完成 Catalog ArrowUp／ArrowDown／Enter、詳情更新、checkbox 不冒泡與篩選後清空選取的瀏覽器互動測試。
- [ ] AMQ-2112 Batch200：Mapping Studio 套用／reset／換頁／theme transfer／reload 的瀏覽器回歸。
- [ ] AMQ-2113 Batch200：播放器展開／收合、頁面切換、捲動及鍵盤焦點回歸；維持單一 AudioService owner。

## 當前執行路線（2026-10-28 使用者重新確認 UI 優先級）

> **正式 UI 架構與 OSK 相容契約升為目前優先工作。** 過去「UI 大重構放最後」的排序已被實際成果證明不符合產品交付需求，不再作為下一批工作指示。底層已驗證成果予以保留，不再無限制擴張低優先級核心工作。

1. **階段 A：OSK 契約與功能頁面映射**：以 stable skinning 官方規格建立 asset manifest、AMQ role manifest，將既有功能映射到首頁、猜歌、選歌、學習中心、設定及共用元件。
2. **階段 B：Skin runtime／Mapping Studio**：讓使用者能按元件角色預覽、套用、替換、還原、保存與匯出素材，不再靠猜檔名手動塞圖。
3. **階段 C：正式 UI 外殼與共用元件**：依 OSK 元件契約建立真正的頁面、狀態、導航、SkinButton／Panel／Tab 等共用元件；不能只隱藏舊 UI 或疊加 CSS。
4. **階段 D：逐頁接入既有功能**：首頁、選歌、猜歌（單／多人）、學習中心、設定；保持 Catalog、AudioService、QuizSession 與 persistence 單一責任。
5. **階段 E：整合回歸與實際驗收**：測試頁面流程、Skin mapping、持久化、響應式與鍵盤操作；真實瀏覽器／真實 OSK 未驗證時明確記錄阻塞。

核心安全／資料問題若有已確認的 P0/P1 可重現缺陷仍需處理，但不得再以常規底層測試工作為由，把正式 UI 重建一律推遲到最後。

### 本次路線調整紀錄
- [x] AMQ-436 使用者確認 UI 大規模重構延後至核心與必要功能穩定後。
- [x] AMQ-437 定義核心優先的五階段執行順序，並寫入專案規範、開工指引及交接文件。
- [x] AMQ-438 明確區分 UI 功能性修正與 UI 視覺重構，避免前期改版造成重工。
- [x] AMQ-439 指定下一批先處理 normalized error projection 與整合回歸，不進行視覺改版。
- [x] AMQ-440（Batch 37）完成 app／catalog browser／quiz panel 的錯誤投影檢查與缺欄位／特殊字元回歸；使用共用 normalized error API，DOM 顯示維持 textContent。
- [x] AMQ-441 核對猜歌引擎與 Session 的狀態責任、開始／暫停／揭曉／下一題流程；確認 Engine 管相位與結果、Session 協調音訊／計時／持久化、Clock 是唯一倒數擁有者、AudioService 的 `playing` 才啟動計時。
- [x] AMQ-442 核對 AMQ／EMQ／MIX 已實作規則及舊版差異；MIX 2:1 權重／來源耗盡 fallback 有測試與靜態線索，AMQ-specific filter suppression 因新版無對應篩選控制而列為明確延後。
- [x] AMQ-443 核對音訊候選、備援、逾時、取消與計時起點；Batch 39 修正 canplay 後 autoplay stall 未 fallback 及 pause 後遲到 playing 事件競態，新增回歸測試。
- [x] AMQ-444 Batch 40–48 已核對 familiarity/history/SRS/blacklist/settings 的保存／恢復／來源隔離，並增加跨模組 persistence failure tests。
- [x] AMQ-445 `FUNCTION_INVENTORY.md` 已分類 P0/P1/P2、已實作待驗收、未實作、延後與阻塞。
- [x] AMQ-446 Batch 44–48 已補必要核心跨模組 Node integration 與全量回歸；真實瀏覽器阻塞獨立記錄。
- [ ] AMQ-447 進入 UI 階段前，建立已認可畫面清單、可用視覺基準與逐項替換驗收計畫。

## A. 基準、規格與盤點

[x] AMQ-001 確認工作目錄、版本控制狀態及目前分支
[x] AMQ-002 列出所有可用來源檔案及大小
[-] AMQ-003 依使用者後續明確指示，不再搜尋／索取 Candidate302；舊版參考改以已上傳 `AMQ382(1).html` 做有證據範圍內的唯讀對照
[-] AMQ-004 不再搜尋缺失的 Candidate382 Stage 0；目前只保留使用者提供的 `AMQ382(1).html` 作唯讀參考，不宣稱 Stage 0 相容性
[x] AMQ-005 確認舊版正式基準與 CSS 比較基準沒有混淆
[x] AMQ-006 已找到 README／BASELINE 相关文件、历史验收、批次 handoff 与工作状态；本轮接手入口见 AGENTS.md／AI_START_HERE.md。
[x] AMQ-007 找到 Library 中的 `data.js`、`emq-data.js`；已確認配對於 Candidate382 Stage I 參考檔名，Candidate302 配套關係仍待核對
[x] AMQ-008 記錄缺失檔案及其對功能驗收的影響
[x] AMQ-009 建立功能真相表並標記證據來源
[x] AMQ-010 `FUNCTION_INVENTORY.md` 已分类 P0/P1/P2、已实作待验收、未实作、延后及阻塞。
[x] AMQ-011 已知 Bug、技术债、外部阻塞与解除条件持续记录于主清单／WORK_STATUS／handoff。
[x] AMQ-012 每批 handoff 与测试日志记录已验收成果，避免重复调查。

## B. 架構與工程基礎

[x] AMQ-013 確認最小可啟動入口
[x] AMQ-014 定義模組責任與依賴方向
[x] AMQ-015 `src/core/errors.js` normalized error contract 已接入 data、audio 与 UI projection，并有回归测试；store 各自提供 persistence status。
[x] AMQ-016 定義單一狀態來源規則（資料載入狀態與統計寫入共用 state store）
[x] AMQ-017 定義初始化與銷毀生命週期（`src/core/lifecycle.js`；20 項 Node 測試含 mount/dispose 整合斷言）
[x] AMQ-018 定義事件訂閱與取消契約
[x] AMQ-019 定義網路請求逾時與取消策略（Source Adapter timeout + AbortSignal；非合作來源的 Promise 取消由 Batch 16 覆蓋）
[~] AMQ-020 定義日誌及診斷方式（state subscriber 例外有界收集 API 已建立；全域診斷／日誌策略仍待定）
[x] AMQ-021 shared state、engine、settings、catalog 与 persistence store 已分离；依赖与状态责任由架构检查覆盖。
[x] AMQ-022 確認外部服務失敗不會阻止應用啟動（mount 不同步呼叫外部服務；資料來源失敗走明確狀態）
[x] AMQ-023 建立可重現的本機啟動步驟
[x] AMQ-024 README_FIRST／AI_START_HERE／tooling tests 与每批 logs 记录启动、测试、验收指令。

## C. 資料契約與曲庫

[x] AMQ-025 完成可取得 AMQ／EMQ 來源的列長、欄位聯集與欄位讀取證據盤點；Candidate302 相容性未驗證
[x] AMQ-026 新版 canonical song schema 已由 source mappers／validator／DATA_CONTRACT 定义；旧版配套相容性另列阻塞。
[x] AMQ-027 核心必填欄位、型別与 record validation 已实现并由全量 source mapper 验证；未证实的旧版 optional 欄位不猜测。
[x] AMQ-028 null／缺失／未知欄位由 mapper、validator 与 UI safe fallback 处理并有测试。
[x] AMQ-029 明确 AMQ／EMQ mapper 与 55,660 records 全量验证已完成；Candidate302／Stage0 compatibility 仍单独阻塞。
[x] AMQ-030 建立資料正規化規則（Batch 33：`src/data/identity.js` 集中身份正規化；搜尋文字 NFKC／大小寫／空白整理只作用於索引副本，不改寫原始顯示值）
[x] AMQ-031 建立新版內部契約驗證器（人工 fixture 測試；不代表舊版資料已驗證）
[x] AMQ-032 建立重複歌曲辨識策略（Batch 33：只以 source + ID 型別 + ID 值判定重複；標題相同／相似不自動合併，新增跨模組回歸測試）
[x] AMQ-033 定義歌曲 ID 的穩定性要求（Batch 33：保留來源 ID 與型別，不以標題生成 ID；穩定性依賴上游 ID 本身，未宣稱上游跨版本永不變更）
[x] AMQ-034 建立資料載入失敗的明確狀態（`src/data/load-state.js` 區分 loading/loaded/partial/empty/failed/not-loaded）
[x] AMQ-035 新版 UI 透過 Catalog／query index 使用正規化記錄，不直接掃描原始來源；`catalog-browser.js`、architecture checks PASS。
[x] AMQ-036 raw source、canonical records、query index 与 quiz state 分离；`identity.js` 与 mapper contract 有测试。
[x] AMQ-037 source audit／ID／关联与 55,660 records mapping 内部契约已通过；上游跨版本 ID 与 Candidate302 配套相容不在本项保证范围。
[x] AMQ-038 已建立 `tools/benchmark-catalog.cjs`；每批 5 次 benchmark PASS，數據與日誌保留。

## D. AMQ / EMQ / MIX 遊戲引擎

- [x] AMQ-039 已定義並測試新版 AMQ 出題／可播放候選／no-repeat 內部規則；舊版完整篩選相容另列阻塞。
- [x] AMQ-040 已定義並測試新版 EMQ 來源隔離／可播放候選規則；真實 EMQ 音源可播性仍待驗收。
- [x] AMQ-041 已依可證實靜態線索實作 MIX 2:1 source weighting 與來源耗盡 fallback；舊版 AMQ-specific filter suppression 未移植。
- [x] AMQ-042 新版共享猜歌／音訊／計時／答案／持久化責任已由 Engine／Session／Clock／AudioService 分層與測試定義。
- [x] AMQ-043 新版 AMQ／EMQ／MIX 來源邊界已定義；未證實的舊版專屬篩選規則明確保留為差異。
- [x] AMQ-044 `QuizEngine` phase transitions 與非法轉移、重複提交、timeout 有 Node 回歸。
- [x] AMQ-045 `QuizSession` start／pause／resume／submit／next／end／reset 及 deadline race 已測試；真實背景分頁行為仍待瀏覽器驗收。
- [x] AMQ-046 no-repeat、finite round、unplayed skip／reveal、pool exhausted 與固定 SRS queue 已測試。
- [x] AMQ-047 `answer-evaluator.js` 的 NFKC／大小寫／空白／控制字元正規化有測試；不自動移除標點。
- [x] AMQ-048 答案精確比對、aliases、all-target、partial answer 門檻與 Unicode fixtures 已有 Node 測試；舊版完整別名資料仍有限。
- [x] AMQ-049 `QuizClock` 是唯一倒數 owner；AudioService `playing` 是計時起點，已有 AudioService + QuizSession integration。
- [x] AMQ-050 Engine 擁有計分與完成題數，Session 協調副作用；核心回歸已覆蓋。
- [x] AMQ-051 模式切換會 dispose 舊 session、取消舊資料載入並按新模式重建；整合測試覆蓋。
[x] AMQ-052 AMQ core／session／panel 的 Node 測試已建立；Candidate302 完整相容不在此勾選範圍。
[x] AMQ-053 EMQ source-aware session、SRS key 隔離與 UI mode switching 有測試；真實音源未驗收。
[x] AMQ-054 MIX 2:1 source weighting、單源 fallback、source-aware identity 有測試。
[x] AMQ-055 建立跨模式切換回歸測試（Batch 31：AMQ → MIX 載入失敗／成功 → EMQ → AMQ，`tests/quiz-panel.test.cjs`）
- [x] AMQ-056 架構檢查與責任邊界測試確認 mode／source selection 不由音訊層自行猜測。

## E. 音訊與外部來源

- [x] AMQ-057 `audioCandidates` 有明確 `{url, source, kind}` schema 與 mapper／candidate tests。
- [x] AMQ-058 `AudioService` 是單一播放請求入口；QuizSession 只注入／呼叫該服務。
- [x] AMQ-059 候選順序由 `audio-candidates.js` 明確生成，AudioService 不猜來源順序；mock fallback 有測試。
- [x] AMQ-060 媒體 error、play rejection、timeout、autoplay blocked 與 normalized audio errors 有測試。
- [x] AMQ-061 AudioService 有明確 timeout 與單次候選推進；候選失敗後備援有測試。
- [x] AMQ-062 新請求／stop／cancel／dispose 會終止舊請求；AbortSignal 與非合作請求有測試。
- [x] AMQ-063 request sequence／active request guard 防止舊播放狀態覆蓋新請求；有競態回歸。
- [x] AMQ-064 候選 fallback、timeout 與 pause 後遲到 playing 回呼有回歸測試。
- [x] AMQ-065 stop／cancel／dispose 的差異及清理行為已實作並測試。
- [x] AMQ-066 契約已明確區分候選存在、ready、playing 與真實可聽；最後一項仍待真實瀏覽器驗收。
[x] AMQ-067 建立可控的音訊服務模擬測試（Batch 22 已有 mock media 覆蓋；Batch 32 增加統一錯誤契約斷言）
- [!] AMQ-068 真實瀏覽器音訊驗收受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞；解除條件是可用瀏覽器／測試環境，不可用 mock 代替。
- [x] AMQ-069 資料／音訊錯誤有 normalized category／code／retryable contract 與 UI 投影測試。

## F. 搜尋、篩選、選取與鍵盤

- [x] AMQ-070 搜尋支援標題、歌手、作品標題／別名與歌曲 aliases，見 query-index tests。
- [x] AMQ-071 query index aliases 搜尋與 answer evaluator aliases 比對分開定義並有測試。
- [x] AMQ-072 來源、歌曲類型、作品類型、query 條件由共用 query index 組合。
- [x] AMQ-073 查詢狀態由 catalog browser controller 單一管理，UI 不另建搜尋規則。
- [x] AMQ-074 未載入／載入中／空／失敗狀態有獨立投影與 integration test。
- [x] AMQ-075 query index 定義篩選→穩定排序→分頁，缺值固定最後；有測試。
- [-] AMQ-076 目前以每頁 1–200 筆的分頁策略限制 DOM 列數；未有證據顯示需要虛擬化，故本階段不適用。
- [~] AMQ-077 已從 Candidate381 靜態參考第 8184 行核實舊 Song Select 的方向鍵行為；新版曲庫列選取尚未實作，且該參考不代表 Candidate382 Stage 0／Candidate302 相容。
- [~] AMQ-078 靜態參考顯示 Enter 呼叫 canonical choose-song owner；新版曲庫尚無播放 owner，需先實作單一選取／播放事件介面。
- [!] AMQ-079 新版鍵盤選取／鍵鼠事件去重仍未實作；舊版靜態契約已取得，待新版列選取／播放 owner 接線後一併測試。
- [~] AMQ-080 現有語意化標籤與 focus-visible 樣式有部分基礎，但鍵盤流程、窄螢幕及真實瀏覽器可存取性仍待階段 5。
- [-] AMQ-081 目前 query index 是同步本機查詢，沒有獨立非同步查詢請求可取消；若未來加入非同步索引再補此契約。
- [~] AMQ-082 模式切換有回歸測試，但搜尋篩選在 AMQ／EMQ 間是否應保留尚無可讀舊版證據，列為未驗收差異。

## Batch198 UI 實作追蹤（2026-10-28）
- [x] AMQ-2089 正式 Catalog DOM 改為左側篩選／中間密集列表／右側詳情三欄，且保留既有 ID、controller、stores 與查詢狀態；證據 `src/ui/catalog-browser.js`、`tests/catalog-filter-layout.contract.test.cjs`。
- [x] AMQ-2090 將 AMQ／EMQ／MIX 模式面板移入 Catalog 側欄，避免額外全寬面板推擠選曲列表；Chromium 31/31。
- [x] AMQ-2091 篩選預設、歌曲標籤、批次操作、個人作品清單移入四個原生 disclosure，降低常用選曲操作的視覺負擔。
- [x] AMQ-2092 正式 Free Player Dock 預設收合為固定底部精簡 dock；展開仍使用原 AudioService 與播放佇列；`tests/free-player-dock.test.cjs` PASS。
- [x] AMQ-2093 Skin runtime role 擴充至 20 個明確 selector/token；`getRoleSupport()` 能回報實際 DOM target count。
- [x] AMQ-2094 新增多 target role 套用與 reset 清理；設定頁 checkbox 角色會套用到所有符合 selector 的目標。
- [x] AMQ-2095 Mapping Studio 每個 role 顯示 runtime supported／unsupported，不再把保存成功當成畫面已套用。
- [x] AMQ-2096 建立 runtime role token 必須有 CSS consumer 的契約測試；`tests/skin-theme-adapter.test.cjs` PASS。
- [x] AMQ-2097 Chromium 桌面／手機驗證 Catalog 三欄與手機單欄，31/31 assertions PASS；手機 dock 不遮擋內容；截圖 `artifacts/batch198-regression/`。
- [x] AMQ-2098 重點 Node regression 10/10 檔案 PASS；Architecture 1123/0；`src/` JS/CJS syntax PASS。
- [!] AMQ-2099 完整 76-file Node regression 本批觸及工具時間限制，沒有全量通過證據；不得沿用 Batch197 76/76 作為本批結果。解除條件：在可用的較長執行環境完成逐檔測試並保留每檔 exit status。
- [!] AMQ-2100 真實 HTTP-origin IndexedDB／曲庫／音訊驗收仍阻塞於 inline `set_content()` opaque origin 與 localhost 導覽限制；解除條件：可用一般本機 HTTP 瀏覽器環境。
- [ ] AMQ-2101 正常資料載入狀態下的正式曲目列／封面／詳情視覺尚未由真實曲庫驗收；不得用示意資料冒充。
- [ ] AMQ-2102 Mapping Studio 真實 `.osk` 套用、reset、匯出／匯入與重新載入需在一般 HTTP-origin 進行 E2E。
- [ ] AMQ-2103 底部播放器展開時的捲動／焦點回復與不同 viewport 行為需進一步驗收。

## G. UI、CSS、OSK 契約與正式頁面架構（目前優先）

> 本節仍是有效待辦，但純視覺與 CSS 重構不得搶在核心功能整合前執行。只有阻礙功能／測試的 UI Bug 可提前修正。進入階段 5 前先完成本清單中的視覺基準與替換計畫任務。

- [ ] AMQ-083 盤點已認可的舊版畫面與操作
- [ ] AMQ-084 記錄必要畫面截圖或視覺基準
- [ ] AMQ-085 建立設計 Token：色彩、字體、間距、圓角與層級
- [ ] AMQ-086 定義 CSS 分層及命名規則
- [ ] AMQ-087 檢查重複選擇器及互相覆蓋
- [ ] AMQ-088 避免把所有樣式塞進單一巨大區塊
- [ ] AMQ-089 定義元件樣式與功能樣式邊界
- [ ] AMQ-090 將舊 UI 逐功能替換為新元件
- [ ] AMQ-091 替換完成後移除舊 UI 與舊樣式
- [ ] AMQ-092 禁止只用 display:none 隱藏淘汰 UI
- [ ] AMQ-093 保留已認可的視覺與操作體驗
- [ ] AMQ-094 建立主要視窗與窄螢幕測試
- [ ] AMQ-095 檢查鍵盤焦點及基本無障礙
- [ ] AMQ-096 檢查 UI 不直接修改核心狀態

## H. 設定、歷史與持久化

- [x] AMQ-097 持久化資料盤點已記錄在 DATA_CONTRACT／FUNCTION_INVENTORY；大型曲庫不放進同步 storage。
- [x] AMQ-098 猜歌設定有版本化 schema；history／SRS／familiarity／blacklist 各有獨立契約。
- [x] AMQ-099 settings／history／SRS／blacklist／familiarity 讀取失敗有安全狀態與快照保留測試。
- [x] AMQ-100 legacy keys 只讀／保護，source-less SRS 不猜測遷移；相容性界線已記錄。
- [x] AMQ-101 寫入失敗、讀取失敗、恢復、通知及 status projection 有 mock storage 回歸。
- [x] AMQ-102 曲庫只載入／映射到 Catalog，不持久化整份曲庫至 localStorage。
- [x] AMQ-103 答題歷史模型已完成；Batch 50 建立自訂清單／看番狀態 persistence API，Batch 51 已接上 UI；收藏身份仍未證實。
- [x] AMQ-104 settings／history／SRS／blacklist 的損壞資料隔離與 recovery 有測試。

## I. 多人與外部整合

- [x] AMQ-105 多人功能已明確列為 P2 延後，不屬目前單機核心結案範圍。
- [x] AMQ-106 外部 API／服務線索與缺少 credentials／protocol 的阻塞已列入功能真相表。
- [-] AMQ-107 多人／外部匯入 adapter 不在目前單機核心範圍；若需求重開，需先取得 API／認證契約。
- [-] AMQ-108 外部多人服務尚未納入本次單機核心；沒有可驗證服務協定／測試環境。
- [-] AMQ-109 外部多人整合未納入目前範圍；核心不依賴外部服務的規則已由架構／啟動測試覆蓋。
- [-] AMQ-110 外部服務版本不相容處理屬延後的 P2 整合範圍。
- [x] AMQ-111 瀏覽器政策、參考檔缺失、無服務端協定與無 Git metadata 均已明確記錄。

## J. 自動化測試與品質防護

[x] AMQ-112 確認可用的測試執行方式
[x] AMQ-113 建立核心純邏輯測試
[x] AMQ-114 建立資料模型與驗證測試（人工 fixture；不代表真實曲庫驗收）
[x] AMQ-115 建立事件取消及生命週期測試（scope 清理、listener、timer、observer、錯誤收集；`node tests/core.test.cjs`）
[x] AMQ-116 建立狀態單一來源測試（含資料載入狀態、錯誤契約與過期結果保護）
- [x] AMQ-117 mode switching／stale load cancellation 有 data pipeline、source runtime 與 quiz panel integration tests。
- [x] AMQ-118 AudioService ordered fallback、timeout、autoplay blocked、late event 有 mock media tests。
- [x] AMQ-119 搜尋／篩選／分頁已有 controller／UI integration；Batch 51 已建立安全的鍵盤列選取，Enter 不播放；瀏覽器驗收仍 BLOCKED。
- [x] AMQ-120 app settings write failure／subscriber notification／recovery notice 有測試。
- [x] AMQ-121 `tools/check-architecture.cjs` 持續執行並通過。
- [x] AMQ-122 架構／tooling 檢查與全量 JS/CJS syntax 每批執行；無已知淘汰 API 阻塞。
- [x] AMQ-123 架構檢查、lifecycle subscription／dispose 與重複回呼測試持續執行。
- [!] AMQ-124 瀏覽器控制台錯誤驗收被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞；Node／static checks 不能替代。
- [x] AMQ-125 每批回歸命令、handoff 與 logs 位置已寫入工作狀態／交接文件。
- [x] AMQ-126 未執行／blocked 項目在 ACCEPTANCE、WORK_STATUS 與批次 handoff 分開記錄。

## K. 結構性技術債清理

- [x] AMQ-127 新架構功能真相表與模組清單已識別新舊資料 key；舊 UI 未混入新應用。
- [x] AMQ-128 shared state 白名單、single catalog/runtime、QuizSession phase projection 與 store ownership 有架構測試。
- [~] AMQ-129 architecture checker 可檢查既定結構規則，但全專案死碼／重複行為的人工審計尚未完成；UI 清理排階段 5。
- [x] AMQ-130 lifecycle scope、listener、observer、timer、AbortSignal 清理有 Node tests。
- [ ] AMQ-131 找出不再使用的 UI 元件
- [ ] AMQ-132 找出不再使用的 CSS 區塊
- [x] AMQ-133 architecture checker 對模組依賴方向有持續驗證。
- [x] AMQ-134 架構檢查與模組公開 API 約束已建立；沒有新增跨模組內部狀態依賴。
- [~] AMQ-135 已稽核核心 persistence／runtime error paths，但尚未完成所有模組的人工吞錯審查。
- [~] AMQ-136 新版未載入舊版 UI 實作；只移除已證實廢棄內容，完整 UI／CSS 清理仍排階段 5。
- [x] AMQ-137 每批修改均執行對應測試並在交付前執行全量回歸。
- [x] AMQ-138 未刪除／未驗收／阻塞項目與解除條件已記錄。

## L. 整合、效能與交付

- [!] AMQ-139 目前環境未提供可執行 Windows .bat 與真實瀏覽器 E2E 的乾淨 Windows 桌面；Node tests 通過不等於乾淨環境啟動驗收。
- [x] AMQ-140 啟動方式與環境依賴有記錄；不依賴未記錄的本機狀態。
- [x] AMQ-141 QuizSession、quiz panel、source runtime 與 data pipeline 的主要流程可重複執行並有整合測試。
- [x] AMQ-142 資料載入、曲庫瀏覽、音訊與 persistence errors 有 normalized status／UI 提示測試。
- [x] AMQ-143 資料來源失敗／取消不會凍結 UI，會清除舊 Catalog 並呈現錯誤狀態。
- [x] AMQ-144 55,660 筆 Catalog 的 5 次 benchmark 每批 PASS；詳見 batch logs。
- [x] AMQ-145 listener／observer／timer／AbortSignal／session／store dispose 有回歸測試。
- [x] AMQ-146 全量 24 Node test scripts、tooling、architecture、source audit、mapper、benchmark、syntax 每批交付前通過。
- [!] AMQ-147 目前來源資料內部 audit／mapping 通過，但 Candidate302 配套關係與真實部署相容性未證實；解除條件為取得可核對配套基準／資料證據。
- [!] AMQ-148 真實音訊播放／實際可聽性尚未驗收；瀏覽器 E2E 受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞。
- [x] AMQ-149 manifest 與完整 ZIP 每批重建並驗證逐項 SHA-256。
- [x] AMQ-150 每批交接包含變更、測試、阻塞、下一步與完整 ZIP，便於回復／接手。
[x] AMQ-151 更新同一份主工作清單
[x] AMQ-152 更新 WORK_STATUS.md
[x] AMQ-153 產出下一批可直接執行任務
[x] AMQ-154 確認沒有覆蓋正式舊版基準
- [x] AMQ-155 每批都產出 handoff／提示詞／主清單／完整 ZIP。
- [x] AMQ-156 結案條件已在 ACCEPTANCE 定義；最終產品結案仍取決於明確阻塞／必要功能，不以低影響美化延長。


## 2026-10-27 第一批執行紀錄

- [x] 解壓並核對開工包 17 個檔案及 `MANIFEST.sha256`；原始 ZIP 未修改。
- [x] 檢查上傳 Candidate382 Stage I HTML SHA-256：`e4c497b72f3803f538fc9900f33ed2ffa6f1cb65c68774a8631b545290ac6747`。此檔不是 Candidate382 Stage 0 基準。
- [x] GitHub `murorachi/Amq-` 可讀，預設分支 `main`；根目錄 README 指向 V82.64 engineering checkpoint archive，根目錄另有 V82.85.30 HTML。遞迴 Git tree 顯示 main 分支只有 11 個項目（`truncated=false`），未包含 `BASELINE.md`、`Data.js`、`EmqData.js`、Candidate302 或 Candidate382 Stage 0。預設分支內容不能自動視為正式基準。
- [x] 新增 `docs/DATA_CONTRACT.md`、`docs/FUNCTION_INVENTORY.md` 及 Node 核心測試；`node tests/core.test.cjs` 實際結果 11/11 PASS。
- [x] 將功能盤點模板改為指向唯一的 `FUNCTION_INVENTORY.md`，避免產生兩份真相表。
- [x] 更新架構文件及狀態紀錄。
- [x] `node --check` 對 `src/app.js`、`src/core/state.js`、`src/core/event-bus.js`、`tests/core.test.cjs` 均成功。
- [x] 重新產生 `MANIFEST.sha256`，納入新增與修改後的全部檔案（不含 manifest 自身）。
- [ ] Candidate302 與 Candidate382 Stage 0 真實檔案取得及雜湊驗證（阻塞）。
- [ ] 真實 Data.js / EmqData.js 欄位盤點、資料驗證與 AMQ/EMQ/MIX 真實規則驗收（阻塞）。


## 2026-10-27 第二批執行紀錄

- [x] 新增 `src/core/lifecycle.js`：scope 統一管理事件監聽、timeout、interval、Observer 與自訂 cleanup；清理採後進先出、可重複 dispose、可回報 cleanup errors。
- [x] 將 `src/app.js` 改為以 lifecycle scope 管理模式按鈕事件及 state subscription，提供 `window.AMQApp.mount()` / `dispose()`，避免重新掛載重複綁定。
- [x] `src/index.html` 載入順序加入 `core/lifecycle.js`；瀏覽器自我測試頁增加 lifecycle 測試。
- [x] 新增 `docs/CANDIDATE382_STAGEI_STATIC_AUDIT.md`，記錄 Stage I HTML 結構指標、資料入口、模式切換、音源備援、observer/timer/listener 證據與限制；未修改參考 HTML。
- [x] 在 GitHub 發現歷史分支 `amq-candidate302-stage3-emq-loader-validation-20261025`，但該分支文件將 Candidate295 標為正式基準，與新版重建規範不同；其記錄中的 Candidate302 HTML 本體及 `data.js` / `emq-data.js` 仍無法從該分支取回。該分支只作歷史線索，不改變 Candidate302 專案基準規則。
- [x] `node tests/core.test.cjs`：35/35 PASS。
- [x] `node --check` 對所有核心與測試 JavaScript 執行（詳見 `docs/WORK_STATUS.md`）。
- [ ] 真實瀏覽器 UI/操作驗收仍未執行；Chromium headless 兩次嘗試未產生 DOM 輸出，記錄為環境阻塞；真實曲庫、正式基準與 Stage 0 仍阻塞。


## 2026-10-27 第三批執行紀錄

- [x] 新增 `src/core/errors.js`，統一錯誤碼、分類、訊息、可重試旗標、details 與安全化 cause；不綁定 DOM 或 console。
- [x] 新增 `src/data/validate.js`，驗證新版內部歌曲記錄契約，回報 loaded/partial/failed/empty、有效/拒絕數量與逐筆欄位錯誤；保留來源物件，不做舊版欄位映射。
- [x] 將錯誤與驗證器腳本納入 `src/index.html`，更新 `tests/tests.html` 的瀏覽器測試案例。
- [x] 新增 13 個錯誤契約/資料驗證測試；`node tests/core.test.cjs` 共 35/35 PASS。測試資料是人工最小 fixture，不是真實曲庫。
- [x] `node --check` 對 `src/app.js`、`src/core/state.js`、`src/core/event-bus.js`、`src/core/lifecycle.js`、`src/core/errors.js`、`src/data/validate.js`、`tests/core.test.cjs` 全部通過。
- [ ] 真實曲庫 schema、Candidate302、Candidate382 Stage 0 與瀏覽器 E2E 仍未驗收；不得把新版契約測試當作來源相容性證據。


## 2026-10-27 第四批執行紀錄

- [x] 新增 `src/data/load-state.js`，以依賴注入方式協調資料驗證、共享 state 與標準錯誤契約；支援 begin/accept/fail/reset，並保護過期成功/失敗結果。
- [x] 資料載入狀態明確區分 `not-loaded`、`loading`、`loaded`、`partial`、`empty`、`failed`，並保存輸入/有效/拒絕數量與標準錯誤。
- [x] 加入 generation token，避免較舊的非同步載入結果覆蓋新載入、reset 或 fail 後的狀態。
- [x] 強化 `src/core/state.js`，拒絕未知資料狀態及格式錯誤的 dataError，確保錯誤更新不會先污染共享狀態。
- [x] `src/app.js` 將資料狀態映射為明確繁中標籤；存在 dataError 時顯示錯誤碼及訊息。
- [x] Node 核心測試新增 10 項資料載入/狀態測試，總計 43/43 PASS；8 個 JavaScript 檔案 `node --check` 通過。
- [ ] 真實瀏覽器執行 `tests/tests.html` 尚未完成，保留環境阻塞；新增瀏覽器測試案例僅代表測試已寫入，不代表已通過。
- [ ] 真實曲庫與來源 adapter 仍阻塞；本批沒有新增任何猜測式舊版欄位映射。


## 2026-10-27 第五批執行紀錄

[x] AMQ-157 建立資料來源 Adapter 介面（`src/data/source-adapter.js`；讀取與 mapping 必須明確注入，不猜測舊版欄位）
[x] AMQ-158 建立來源逾時、取消、讀取失敗、格式錯誤及 mapping 失敗測試（Node 非同步測試）
[x] AMQ-159 建立 AMQ/EMQ/MIX 合法模式選擇契約測試；只驗證單一狀態來源，不推測尚未盤點的模式切換重置規則
[x] AMQ-160 修正 app 狀態訊息引用與錯誤清除時的過期訊息問題，增加回歸斷言
[x] AMQ-161 讓瀏覽器測試頁依序等待非同步測試，並加入 adapter/repository happy-path 案例
[-] AMQ-162 取得 Candidate302／Candidate382 Stage 0 的歷史建議已由使用者後續指示取代；不得再搜尋這些檔案。舊版相容性維持未驗收，不用推測補足
[!] AMQ-163 執行真實瀏覽器 UI/E2E（系統 Chromium 既有啟動阻塞尚未解除；本批未宣稱通過）
[x] AMQ-164 建立 Repository 組裝層，串接來源 Adapter、generation token、資料驗證與共用狀態
[x] AMQ-165 測試 Repository 的來源失敗、主動取消、過期請求及新請求取代舊請求

第五批測試證據：`node tests/core.test.cjs` 56/56 PASS，包含 source adapter 非同步讀取、mapping、錯誤、timeout、AbortSignal cancellation 及模式選擇契約。完整語法、HTML 引用、manifest 與 ZIP 驗證結果記錄於 `docs/WORK_STATUS.md`。真實舊版資料相容性及真實瀏覽器驗收仍為 BLOCKED。


## 2026-10-27 第六批執行紀錄

[x] AMQ-166 新增 `tools/check-architecture.cjs`，可重複檢查 HTML 本地引用、重複 ID、script 載入順序、JS 語法、指定過期 API、模組依賴方向與重複函式宣告
[x] AMQ-167 修正 `src/index.html` 與 `tests/tests.html` 的載入順序，讓 `load-state.js` 先於 `repository.js` 載入
[x] AMQ-168 新增 `tools/audit-source-data.cjs`，支援 AMQ DB JSON literal 及 EMQ gzip/Base64 JSON 的唯讀稽核
[x] AMQ-169 對 Library 中實際 `data.js`、`emq-data.js` 執行 SHA-256、列長、ID 唯一性、作品關聯及跨來源 ID 碰撞檢查
[x] AMQ-170 建立 `docs/SOURCE_DATA_AUDIT_20261027.md`，記錄實際數據、雜湊、欄位證據及來源相容性限制
[x] AMQ-171 新增 `tests/tooling.test.cjs`，涵蓋架構檢查成功、來源稽核成功、重複 ID、跨來源碰撞及無效作品關聯
[!] AMQ-172 Candidate302 本體與來源配套版本核對仍阻塞；Library 資料檔已找到但只能確認被 Candidate382 Stage I 參考 HTML 以同名 script 引用
[!] AMQ-173 真實瀏覽器 E2E 與音源可播放性驗收仍阻塞，未用靜態檢查取代

第六批歷史測試證據：`node tests/core.test.cjs` 56/56 PASS；`node --test tests/tooling.test.cjs` 5/5 PASS；當時 `node tools/check-architecture.cjs` 輸出記錄有 79/97 數字不一致，後續以實際記錄為準並在第七批重新驗證；`node tools/audit-source-data.cjs /mnt/data/files/data.js /mnt/data/files/emq-data.js` 成功。完整來源統計與 SHA-256 見 `docs/SOURCE_DATA_AUDIT_20261027.md`。


## 2026-10-27 第七批執行紀錄

[x] AMQ-174 新增 `src/data/source-mappers.js`，將已盤點的 AMQ 12 欄歌曲列／7 欄作品列及 EMQ 歌曲／作品物件明確映射為新版內部歌曲記錄；來源標籤明確標記為目前 Library／Candidate382 Stage I schema evidence，不宣稱 Candidate302 相容。
[x] AMQ-175 建立 mapper fixture 測試，涵蓋 AMQ／EMQ 正常映射、列長錯誤、重複作品 ID、缺失必要欄位及無效作品關聯。
[x] AMQ-176 新增 `tools/verify-source-mappers.cjs`，對實際 `data.js`、`emq-data.js` 全量映射並交由內部驗證器檢查。
[x] AMQ-177 將 mapper 載入至 runtime HTML 與瀏覽器測試頁，並納入架構載入順序檢查。
[x] AMQ-178 重新檢查 GitHub Candidate302 歷史分支完整 tree（615 項，truncated=false）：未包含 Candidate302 HTML 本體或 Candidate382 Stage 0；只有 Candidate302 歷史報告及舊基準文件。歷史文件標示 Candidate295 為正式基準，與本新版專案已指定 Candidate302 的規則衝突，因此只作歷史證據，不更動本專案基準。
[x] AMQ-179 修正歷史架構檢查結果在本清單中 79/97 的數字不一致問題：本批重新執行，結果 114 passed、0 failed。
[!] AMQ-180 Candidate302 本體與 Candidate382 Stage 0 仍未取得；不得將本批 mapping 驗證視為正式基準相容性驗收。
[!] AMQ-181 新版已由 `audio-candidates.js` 生成候选且有 mock tests；真实 HTTP、跨域、媒体事件与可听性仍未验收，浏览器 E2E 阻塞。

第七批驗證證據：`node tests/core.test.cjs` 56/56 PASS；`node --test tests/tooling.test.cjs` 5/5 PASS；`node tests/source-mappers.test.cjs` 7/7 PASS；`node tools/check-architecture.cjs` 114 PASS、0 FAIL；`node tools/verify-source-mappers.cjs /mnt/data/files/data.js /mnt/data/files/emq-data.js` PASS：AMQ 38,821／38,821 筆與 EMQ 16,839／16,839 筆全部映射並通過新版內部資料契約驗證。以上僅驗證目前 Library 資料與已盤點 schema，不證明 Candidate302 相容或音訊可播放。

第七批交付封包：`/mnt/data/AMQ_Full_Rebuild_Batch7_20261027.zip`；包含 36 個檔案（35 個 manifest 條目 + manifest），ZIP 結構檢查通過，35/35 雜湊一致。大型來源資料未納入封包，無遠端推送。


## 2026-10-27 第八批執行紀錄

[x] AMQ-182 新增 `tests/data-pipeline.integration.test.cjs`，覆蓋 AMQ／EMQ mapper 到 Adapter、Repository、validator、共享 state 的端到端資料管線（Node 整合層）
[x] AMQ-183 驗證空來源會進入 `empty` 而非 `failed` 狀態
[x] AMQ-184 驗證 mapping 失敗與來源讀取例外會轉成標準錯誤並更新共享載入狀態
[x] AMQ-185 驗證外部取消會結束載入，且舊的非協作請求無法覆蓋較新的成功結果
[x] AMQ-186 重新驗證核心、tooling、mapper、整合測試、架構檢查及真實資料全量 mapping
[!] AMQ-187 嘗試以 Playwright 驅動系統 Chromium：瀏覽器程序可被啟動，但 `file://` 與 `127.0.0.1` 頁面導覽皆回報 `ERR_BLOCKED_BY_ADMINISTRATOR`；真實瀏覽器測試仍未執行成功
[!] AMQ-188 Candidate302 與 Candidate382 Stage 0 實體檔案仍未取得；目前 GitHub 可讀範圍及 Library 資料不能證明基準相容性

第八批驗證證據與限制詳見 `docs/WORK_STATUS.md`。Node 整合測試 7/7 PASS；瀏覽器導覽受到環境管理政策阻擋，沒有宣稱 E2E 通過。


## 2026-10-27 第九批執行紀錄

[x] AMQ-189 新增 `src/data/query-index.js`，建立可重建、唯讀的歌曲查詢快照，來源與 ID 型別共同形成身份範圍。
[x] AMQ-190 支援歌曲標題、歌手、作品標題、作品別名與 aliases 子字串搜尋；索引使用 NFKC、大小寫與空白正規化，不改寫顯示文字。
[x] AMQ-191 支援 source/type/workKind/animeId 組合篩選、穩定排序與 offset/limit 分頁，未知條件與無效參數明確報錯。
[x] AMQ-192 新增 `tests/query-index.test.cjs`，10/10 PASS，覆蓋正規化、跨來源相同 ID、重複複合身份、不可變快照、篩選、分頁與錯誤參數。
[x] AMQ-193 擴充資料管線整合測試，確認 AMQ／EMQ mapper 輸出可直接建立 catalog 並按歌曲、歌手、作品別名搜尋，8/8 PASS。
[x] AMQ-194 擴充真實資料驗證工具，對 55,660 筆 AMQ／EMQ 映射記錄建立 catalog，並對兩來源執行搜尋探針，均成功。
[x] AMQ-195 更新 runtime HTML、瀏覽器測試頁、架構檢查器及資料契約文件；`node tools/check-architecture.cjs` 第九批為 136 passed、0 failed；第十一批重新驗證為 138 passed、0 failed。
[!] AMQ-196 重新確認遠端 Candidate302 歷史分支 tree（615 項、未截斷）仍無 Candidate302 本體或 Candidate382 Stage 0；其中 V82_85_30 等檔案不等於已指定基準，不能替代。
[x] AMQ-197 query index 已于 Batch 19 接入 catalog browser；真浏览器 E2E、真实音讯与旧版相容性仍由其他阻塞项追踪。

第九批範圍：資料查詢／索引層與測試。沒有實作 UI、遊戲出題規則、音源候選順序或模式切換重置規則。完整結果及交付封包見 `docs/WORK_STATUS.md`。


## 2026-10-27 第十批執行紀錄（睡前批次）

[x] AMQ-198 新增 `tools/benchmark-catalog.cjs`，可用真實 AMQ／EMQ 來源重建 catalog，量測建置耗時及 6 類查詢案例的 min/P50/P95/max/mean。
[x] AMQ-199 新增 `docs/CATALOG_BENCHMARK_20261027.json` 與 `.md`，記錄 55,660 筆曲庫的觀察性查詢基線與分組統計。
[x] AMQ-200 為效能工具加入 tooling 回歸測試：有效 fixture 產生 6 個案例、迭代數正確；非法迭代數會明確拒絕。
[x] AMQ-201 更新架構、資料契約、README 與唯一工作狀態，說明量測範圍、重現指令及限制。
[!] AMQ-202 追查 GitHub `ui-stage03-song-select-02` branch tree（7 項、未截斷），未找到 Candidate302、Candidate382 Stage 0 或基準 HTML；不能升格其他候選檔。
[!] AMQ-203 真實瀏覽器 E2E、正式基準相容性、音訊可播放性仍阻塞；本批不重複已證實會被管理政策阻擋的瀏覽器導覽。

第十批效能量測結果：catalog 建置 719.234 ms；30 次樣本中標題子字串搜尋 P50 11.790 ms、歌手搜尋 P50 10.937 ms、作品標題搜尋 P50 11.362 ms、來源＋類型篩選 P50 1.281 ms、複合篩選 P50 9.546 ms、空查詢首頁 P50 1.456 ms。這些是當前 Node 執行環境的觀察數值，不是效能保證；完整統計見 `docs/CATALOG_BENCHMARK_20261027.md`／`.json`。


## 2026-10-27 第十一批執行紀錄（睡前批次續作）

[x] AMQ-204 在 `queryIndex.search()` 增加明確的 `sortBy`／`sortDirection` 契約，未指定排序時保留輸入順序。
[x] AMQ-205 實作文字／數值排序、缺值固定排最後及同值穩定排序。
[x] AMQ-206 新增排序回歸測試，涵蓋 asc/desc、數值比較、缺值、穩定性與非法參數。
[x] AMQ-207 更新瀏覽器自我測試頁的排序案例；案例已寫入，但真實瀏覽器執行仍受環境阻擋。
[x] AMQ-208 更新架構、資料契約、README 與交接狀態，明確區分新版內部排序 API 與尚未核實的舊版 UI 排序規則。
[!] AMQ-209 Candidate302／Candidate382 Stage 0 實體仍未取得，不能宣稱舊版排序選項、預設排序或設定相容。

第十一批測試新增 3 個排序案例，`tests/query-index.test.cjs` 目前 13/13 PASS（前 10 個查詢案例加 3 個排序案例）。


## 2026-10-27 第十二批執行紀錄：分組統計與組合查詢

[x] AMQ-210 將查詢層共用篩選流程抽成單一內部路徑，避免 search 與分組統計的篩選語意分岔。
[x] AMQ-211 新增 `queryIndex.groupBy()`，支援 source/type/workKind/animeId/animeTitle/artist 六種分組欄位。
[x] AMQ-212 明確定義 groupBy 的 total、缺值、typed value、排序及不可變回傳契約；拒絕排序／分頁條件，避免只計算當頁。
[x] AMQ-213 新增 4 項 query regression：篩選→排序→分頁、超過 10,000 筆仍完整分組、數字與字串 ID 區分、非法欄位／條件拒絕。
[x] AMQ-214 擴充真實曲庫驗證器，核對 55,660 筆 catalog 的來源分組總數與 AMQ／EMQ 筆數，並驗證真實資料排序／分頁探針。
[x] AMQ-215 擴充 benchmark，新增來源分組及 AMQ 來源下的歌曲類型分組兩類量測；更新 JSON／Markdown 實測報告。
[x] AMQ-216 更新瀏覽器測試頁，加入分組計數與組合查詢案例；實際瀏覽器執行仍受環境政策阻擋。
[x] AMQ-217 更新架構、資料契約、README、工作狀態及 manifest。
[x] AMQ-218 執行 Node 查詢／tooling 回歸及真實來源 mapper/catalog 驗證。
[!] AMQ-219 Candidate302／Candidate382 Stage 0 本體、真實瀏覽器 E2E、舊版相容性及音訊可播放性仍未驗收；不以新版內部契約測試替代。

第十二批結果：query index 10/10 基礎案例、3/3 排序案例、4/4 組合查詢／分組案例 PASS；tooling 7/7 PASS。真實資料 55,660 筆建 catalog PASS，來源分組 AMQ 38,821、EMQ 16,839；真實資料標題排序／offset 10／limit 20 探針 PASS。完整測試與交付證據見 `docs/WORK_STATUS.md`。


## 2026-10-27 第十三批執行紀錄：多來源資料管線與 Catalog 原子發布

[x] AMQ-220 新增 `createCompositeAdapter()`，以唯一來源名稱組合多個已映射 adapter；任一來源失敗時整體失敗，不發布不完整混合資料。
[x] AMQ-221 Composite adapter 驗證來源結果結構、來源名稱與每筆記錄的 `source` 一致，回傳總筆數及唯讀各來源筆數。
[x] AMQ-222 將 `queryIndex.createCatalog()` 注入 Repository 建立的載入控制器，讓驗證與 Catalog 建立先於成功狀態發布。
[x] AMQ-223 新增 `repository.catalogSnapshot()`，並在新載入開始、失敗及 reset 時清除舊快照，避免 UI 取得過期 Catalog。
[x] AMQ-224 將 Catalog 建立例外轉成 `DATA_CATALOG_BUILD_FAILED`，避免共享狀態宣稱 loaded 但查詢索引實際不存在。
[x] AMQ-225 修正 validator 的 ID 唯一性範圍，改為 source + ID 型別 + ID 值；跨來源同 ID 合法，同來源重複仍拒絕。
[x] AMQ-226 增加多來源、相同跨來源 ID、Catalog 失敗、partial Catalog、新載入失效舊快照及來源名稱不一致等回歸測試。
[x] AMQ-227 更新 runtime／瀏覽器測試頁載入順序，讓 query index 在 repository 建立前載入；更新架構檢查器的預期順序。
[x] AMQ-228 執行核心、查詢、資料管線、mapper、tooling 與架構全套回歸；真實 55,660 筆曲庫全量 mapping／Catalog 驗證通過。
[x] AMQ-229 新增 Batch 13 真實曲庫效能 JSON／Markdown 報告（30 次量測，含 6 類搜尋／篩選及 2 類分組統計）。
[!] AMQ-230 Candidate302、Candidate382 Stage 0、真實瀏覽器 E2E、音訊播放及舊版相容性仍未驗收；沒有用新版內部契約取代這些驗收。

第十三批測試證據：核心測試 60/60 PASS；資料管線整合 12/12 PASS；查詢 10/10 + 排序 3/3 + 組合／分組 4/4 PASS；tooling 7/7 PASS；mapper 7/7 PASS；架構檢查 138 PASS、0 FAIL；真實來源 55,660 筆映射／Catalog 驗證 PASS。瀏覽器 E2E 仍是先前已證實的 `ERR_BLOCKED_BY_ADMINISTRATOR` 環境阻塞，未重複嘗試。


## 2026-10-27 第十四批執行紀錄：集中化來源選擇設定

[x] AMQ-231 新增 `src/data/source-registry.js`，以注入式 `sources` 與 `modeSources` 集中管理 adapter 與模式來源集合。
[x] AMQ-232 新增 `sourceNamesForMode()` 與 `createAdapterForMode()`，把模式選擇和 Composite Adapter 組裝集中在資料層。
[x] AMQ-233 對未知模式、未配置模式、未知來源、重複來源、空來源集合及無效 adapter 增加明確拒絕。
[x] AMQ-234 新增核心測試，確認 registry 只依注入設定選來源、不提供隱含 fallback。
[x] AMQ-235 新增整合測試，驗證 registry → composite adapter → repository → 單一 catalog 的整條流程。
[x] AMQ-236 更新 runtime／瀏覽器測試頁 script 載入順序、架構檢查器、資料契約、架構文件與 README。
[x] AMQ-237 重新執行完整 Node 回歸與架構檢查。
[x] AMQ-238 MIX 2:1 source weighting 与单源耗尽 fallback 已依静态证据实现并测试；AMQ-specific filter suppression 单独列为未实作差异。
[!] AMQ-239 Candidate302／Candidate382 Stage 0、瀏覽器 E2E 與音訊播放仍阻塞。

第十四批測試證據：核心 62/62 PASS；資料管線整合 13/13 PASS；查詢 10/10 + 排序 3/3 + 組合／分組 4/4 PASS；tooling 7/7 PASS；mapper 7/7 PASS；架構檢查 146 PASS、0 FAIL；全部 JS/CJS 語法檢查 PASS。


## 2026-10-27 第十五批執行紀錄：Runtime Bootstrap 與模式切換競態

[x] AMQ-240 新增 `src/data/runtime-bootstrap.js`，以單一 Repository 提供 `loadCurrentMode()`、cancel、snapshot、catalogSnapshot 與 dispose。
[x] AMQ-241 從共享 state 讀取目前 mode，將 mode 明確傳到 Repository adapter 邊界，再由 Source Registry 選取來源。
[x] AMQ-242 在共享 state 的 mode 變更時取消進行中的載入，避免舊模式的延遲結果發布到新模式。
[x] AMQ-243 新增 dispose 與已 dispose 不可重新載入的生命週期契約。
[x] AMQ-244 新增核心測試，驗證 bootstrap 依目前共享模式選擇來源、可 dispose 且不使用隱含 fallback。
[x] AMQ-245 新增整合測試，驗證模式切換取消舊來源載入、清除舊 Catalog，再載入新模式資料。
[x] AMQ-246 更新 runtime／瀏覽器測試頁與架構檢查器的 script 載入順序。
[x] AMQ-247 更新架構、資料契約、README、工作狀態與唯一主清單。
[x] AMQ-248 執行完整 Node 回歸與靜態架構檢查。
[x] AMQ-249 Runtime／Catalog／QuizPanel 已接入实际模式 state；模式切换取消旧请求、dispose 旧 session 并隔离来源有整合测试。旧版所有细节仍未宣称相容。
[!] AMQ-250 Candidate302／Candidate382 Stage 0、真實瀏覽器 E2E、音訊播放與正式來源配套仍未驗收。

第十五批測試證據：核心 63/63 PASS；資料管線整合 14/14 PASS；查詢 10/10 + 排序 3/3 + 組合／分組 4/4 PASS；tooling 7/7 PASS；mapper 7/7 PASS；架構檢查 154 PASS、0 FAIL。


## 2026-10-27 第十六批執行紀錄：非合作來源取消

[x] AMQ-251 修正 Composite Adapter 的取消競態：外部取消現在會立即拒絕載入並 abort 所有子來源，不等待忽略 AbortSignal 的來源自行完成。
[x] AMQ-252 將 `mode` 呼叫脈絡傳遞至 Composite 的各來源 adapter；不新增或推測模式產品規則。
[x] AMQ-253 新增核心回歸：直接取消 non-cooperative adapter 時立即收到 `DATA_LOAD_CANCELLED`，且子來源 signal 已 abort。
[x] AMQ-254 新增整合回歸：模式切換取消 non-cooperative adapter 時，Runtime state 立即回到 `not-loaded`。
[x] AMQ-255 更新資料契約、架構、README、唯一工作清單與交接狀態，並重新執行完整 Node 回歸。
[!] AMQ-256 Candidate302／Candidate382 Stage 0、真實瀏覽器 E2E、音訊播放與正式來源配套仍未驗收；本批只修正可注入資料管線的取消契約。

第十六批驗收條件：直接取消與模式切換在非合作來源下不會卡住 `loading`，且舊結果不會發布。測試證據與交付資訊見 `docs/WORK_STATUS.md`。


## 2026-10-27 第十七批執行紀錄：核心狀態與生命週期收尾

[x] AMQ-257 共用 state store 加入欄位白名單，拼錯或未登記的狀態欄位會在提交前拒絕，避免狀態樹悄悄長出第二套來源。
[x] AMQ-258 對資料筆數統計加上非負安全整數驗證；無效 patch 不會部分修改現有狀態。
[x] AMQ-259 隔離 state subscriber 例外：狀態先完成提交，再通知訂閱者；單一壞 listener 不會阻止其他 listener，錯誤以最多 50 筆有界佇列提供查閱／清除 API。
[x] AMQ-260 Lifecycle scope 提供穩定的 `signal`；dispose 時先 abort 作用域請求，再按 LIFO 清理 listener、timer、observer 與自訂資源。
[x] AMQ-261 新增狀態欄位、統計值原子拒絕、subscriber 失敗隔離及 lifecycle signal 取消的回歸測試。
[x] AMQ-262 更新架構與啟動文件，明確界定本批核心基礎設施的完成範圍。
[x] AMQ-263 更新本主清單、WORK_STATUS 與 manifest；正式舊版基準未修改，沒有推送 GitHub。
[!] AMQ-264 真實瀏覽器 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；Candidate302／Candidate382 Stage 0 與正式產品行為相容性仍未驗收。

第十七批核心測試新增 3 項回歸，`node tests/core.test.cjs` 由 64/64 增至 67/67 PASS。這表示核心狀態／生命週期框架的 Node 契約更完整，不代表 AMQ／EMQ 遊戲引擎、UI 或音訊功能已完成。


## 2026-10-27 第十八批：參考檔核對與產品核心契約

[x] AMQ-265 核對 Batch 17 ZIP 結構、48 個 manifest 條目及 SHA-256；49/49 一致，ZIP CRC 檢查通過。
[x] AMQ-266 在目前工作副本重跑核心、資料管線、查詢、mapper、tooling 及架構檢查，確認接手環境未退化。
[x] AMQ-267 計算使用者上傳 `AMQ382(1).html` 的 SHA-256、大小及 title；記錄實際檔案證據，不擅自改寫其版本標籤。
[x] AMQ-268 遵照使用者指示，不再搜尋 Candidate302；不覆蓋或修改上傳參考 HTML。
[x] AMQ-269 擴充 `docs/FUNCTION_INVENTORY.md`，將可證實的靜態功能線索整理成 12 個產品切片。
[x] AMQ-270 新增 `docs/PRODUCT_CORE_CONTRACT.md`，定義載入、曲庫搜尋、篩選排序、模式邊界、猜歌回合、答案、音訊、持久化與 UI 的最低驗收契約。
[x] AMQ-271 定義下一批產品優先順序為 PC-01 至 PC-03 曲庫瀏覽切片，重用既有 query index，不新增通用抽象層。
[x] AMQ-272 更新交接、工作狀態與本主清單，區分 Node 驗證、靜態參考證據及真實瀏覽器驗收。
[!] AMQ-274 真實瀏覽器 E2E 仍受既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；本批不重試相同導覽。
[x] AMQ-275 Batch 17 ZIP 當時未包含曲庫來源；Batch 20 已將已核對的 AMQ／EMQ 來源副本放入 `src/data/assets/`，目前 source audit／mapping PASS。Candidate302 配套相容仍未證實。
[x] AMQ-276 已記錄參考 HTML 實際 title 為 Candidate381 且含 Stage I 線索；依使用者指定用途保留唯讀參考，但不宣稱它是 Stage 0。

本批沒有新增底層架構抽象、沒有推送 GitHub、沒有修改正式基準。

## 2026-10-27 第十九批：曲庫瀏覽 UI

[x] AMQ-273 將既有 query index 接入曲庫瀏覽 UI，提供搜尋、來源／歌曲類型／作品類型篩選、排序、每頁筆數及分頁。
[x] AMQ-277 新增 `src/ui/catalog-browser.js`，提供純控制器測試介面，UI 不自行實作曲庫掃描／排序／分頁規則。
[x] AMQ-278 以 query-index 的 `groupBy()` 提供 facet 計數，且 facet 選項不會被自身目前選取條件錯誤縮減。
[x] AMQ-279 新增未載入、載入中、空曲庫、無搜尋結果及錯誤訊息；重新載入或狀態失效時清除舊畫面 Catalog。
[x] AMQ-280 將 UI 模組納入 `src/index.html` 與瀏覽器測試頁，並更新 architecture checker 的 script 順序契約。
[x] AMQ-281 新增 `tests/catalog-browser.test.cjs`，7/7 控制器測試通過。
[x] AMQ-282 更新核心測試中已淘汰的 app 佔位文案斷言。
[x] AMQ-283 更新產品契約與工作狀態，清楚區分 UI 實作、正式資料接線與瀏覽器驗收。
[x] AMQ-284 執行完整最終回歸、manifest／ZIP 驗證並生成 Batch 19 交付包；結果見 WORK_STATUS 最終交付驗證。
[x] AMQ-285（Batch 20 已解除）正式 AMQ／EMQ 來源檔已納入 `src/data/assets/` 並接入 Runtime；仍不代表 Candidate302 配套相容。
[!] AMQ-286 真實瀏覽器 E2E／視覺驗收仍受既有環境阻擋，Node 測試不能替代瀏覽器驗收。


## 2026-10-27 第二十批：真實曲庫來源接線

[x] AMQ-287 從已找到的 Library 檔案複製 `data.js`／`emq-data.js` 到 `src/data/assets/`，並逐一核對 SHA-256，來源內容不改寫。
[x] AMQ-288 新增 `src/data/source-runtime.js`，將 AMQ／EMQ 原始資料接入既有 source adapter、registry、repository、runtime bootstrap 與共享載入狀態。
[x] AMQ-289 以瀏覽器原生 gzip 解壓 API 讀取 EMQ gzip/Base64 payload，驗證 payload 版本及必要陣列結構，對缺少 API／壞資料提供明確錯誤。
[x] AMQ-290 將正式來源副本接入 `src/index.html`，初次啟動載入 AMQ，EMQ 模式切換會取消舊載入並載入 EMQ，重新載入按鈕可呼叫 runtime。
[x] AMQ-291 新增 `src/app-runtime.js` 作應用層組裝邊界，避免 `src/app.js` 直接存取資料層全域。
[x] AMQ-292（歷史項目，已由 Batch 29 supersede）曾將 MIX 設為未配置來源 adapter；Batch 29 依參考 HTML 的 2:1 source weighting 與 fallback 規則改為正式 composite adapter。
[x] AMQ-293 新增 `tests/source-runtime.integration.test.cjs`，以實際來源資產驗證 AMQ 38,821 筆、EMQ 16,839 筆、模式切換及 MIX 阻擋。
[x] AMQ-294 更新 `tools/check-architecture.cjs`，檢查資料資產、source runtime、app runtime 與 UI 的載入順序及模組依賴。
[x] AMQ-295 更新 README、資料契約、產品核心契約、來源稽核、AI 開工指引、WORK_STATUS 與本主清單。
[!] AMQ-296 真實瀏覽器視覺／互動 E2E 尚未完成；此環境的 Chromium headless 即使執行簡單 data URL 也無法在 15 秒內正常退出，不能將此嘗試視為通過。
[x] AMQ-297 MIX 2:1 weighting 与 source exhaustion fallback 已按静态证据实现并测试；缺少 UI 控制的 AMQ-specific filter suppression 仍单独阻塞。
[!] AMQ-298 Candidate302／Candidate382 Stage 0 相容性及音訊可播放性仍未驗收；新版內部資料契約通過不等於舊版相容或音訊可用。

本批真實來源資料：AMQ 作品 9,516／歌曲 38,821；EMQ 作品 6,645／歌曲 16,839；合計 55,660 首。全量 mapper／Catalog 驗證已重跑通過，來源 SHA-256 與 `docs/SOURCE_DATA_AUDIT_20261027.md` 一致。


## 2026-10-27 第二十一批：猜歌答案規則與核心狀態機

[x] AMQ-299 從使用者提供的 `AMQ382(1).html` 靜態證據核對答案正規化、精確比對、可選部分比對、AMQ 同歌名／歌手跨作品接受、EMQ 不自動跨作品接受、播放後計時及熟悉度更新線索；未修改參考 HTML。
[x] AMQ-300 新增 `src/engine/answer-evaluator.js`，提供 NFKC／小寫／空白與控制字元正規化、作品／歌曲／歌手 aliases、部分比對開關、AMQ related-work rule 與 all-target 結果。
[x] AMQ-301 新增 `src/engine/quiz-engine.js`，實作 idle／ready／playing／paused／answered／timed-out／revealed／finished 狀態及明確轉移。
[x] AMQ-302 將播放成功設為計時／提交門檻；空答案、暫停提交、非法相位與重複提交不改變回合狀態。
[x] AMQ-303 實作暫停時間排除、超時、未播放跳過、播放後跳過、手動揭曉不計分、有限題數結束與 reset。
[x] AMQ-304 回傳依耗時計算的熟悉度建議，支援 `keepHigher` 與注入式既有熟悉度讀取；引擎不直接寫持久化。
[x] AMQ-305 新增答案比對 6 項與回合引擎 10 項 Node 測試。
[x] AMQ-306 將引擎模組納入主頁／測試頁載入順序，並擴充架構檢查禁止 engine 依賴 DOM／UI。
[x] AMQ-307 更新 README、架構、產品核心契約、主清單、工作狀態及交接文件。
[x] AMQ-308（Batch 23 已解除）猜歌 UI 已接上 quiz session／engine，仍待真實瀏覽器驗收。
[x] AMQ-309（Batch 22 已解除）AudioService 已實作；`markAudioStarted()` 由 session 依真實媒體 `playing` 狀態呼叫，timeout 由單一 quiz clock 驅動。
[!] AMQ-310 現有來源 mapper 尚未帶入舊版完整中文別名／歷史 aliases；引擎只使用明確傳入的 aliases，不虛構缺失資料。
[!] AMQ-311 真實瀏覽器 E2E、Candidate302／Stage 0 相容性及音訊可播放性仍未驗收。


## 2026-10-27 第二十二批：音源候選解析與 AudioService

[x] AMQ-312 從使用者提供的參考 HTML 靜態核對 AMQ 音訊 host 順序、歌曲列 row[9] 音訊檔名及 EMQ Catbox URL 轉換規則；不修改參考 HTML。
[x] AMQ-313 新增 `src/data/audio-candidates.js`，AMQ 依三個已觀察鏡像主機生成候選；EMQ 依 `v` URL 順序生成候選，Catbox mirror 優先於原 URL並去重。
[x] AMQ-314 將 `audioCandidates` 接入 AMQ／EMQ mapper，並在 `validate.js` 驗證候選物件、URL/source 與 audio kind 及重複 URL。
[x] AMQ-315 新增 `src/audio/audio-service.js`，提供有序候選播放、12 秒載入逾時、媒體錯誤／play rejection fallback、NotAllowedError 手動恢復、AbortSignal、替代請求取消、stop 及 dispose。
[x] AMQ-316 明確區分 ready 與 playing；只有實際 `playing` 事件才代表播放開始，`play()` Promise resolve 不當成播放成功。
[x] AMQ-317 新增音源候選／驗證 5 項測試與 AudioService 11 項 mock media 測試。
[x] AMQ-318 擴充真實來源整合測試，核對 AMQ 37,939 首有音源候選、882 首缺少音訊檔名，以及 EMQ Catbox mirror／原 URL 順序。
[x] AMQ-319 更新 source mapper verifier，回報實際候選筆數及總 URL 數。
[x] AMQ-320 更新 HTML 載入順序、架構檢查、資料契約、來源稽核、README、工作狀態及交接文件。
[!] AMQ-321 候選 URL 尚未在真實瀏覽器發出請求或確認可聽性；mock media 測試不代表真實音訊播放通過。
[x] AMQ-322（Batch 23 已解除）AudioService 與 quiz engine 已接入最小可操作猜歌 UI；真實音訊可播放性仍未驗收。
[!] AMQ-323 真實瀏覽器 E2E、Candidate302／Stage 0 相容性及 MIX 規則仍未驗收。

全量候選統計：AMQ 38,821 首中 37,939 首有音訊候選，共 113,817 個鏡像 URL；EMQ 16,839 首全部有候選，共 20,085 個 URL。


## 2026-10-27 第二十三批：猜歌 UI 與單一狀態接線

[x] AMQ-324 新增 `src/engine/quiz-pool.js`，只從當前 AMQ／EMQ 模式挑選有作品、歌手、音訊候選的歌曲，去重並提供可注入隨機來源的 no-repeat 選題。
[x] AMQ-325 新增 `src/engine/quiz-clock.js`，提供倒數、暫停／恢復、停止與單一 timeout callback；只由 session 在 AudioService `playing` 狀態後啟動。
[x] AMQ-326 新增 `src/engine/quiz-session.js`，整合 quiz engine、answer evaluator、audio service、clock 與 no-repeat pool；UI 不持有第二份題目／phase 狀態。
[x] AMQ-327 擴充 AudioService pause／resume，保留同一媒體請求並支援實際播放恢復；修正候選 fallback 後播放狀態重置。
[x] AMQ-328 新增 `src/ui/quiz-panel.js` 及 HTML／CSS，提供目標選擇（作品／歌曲／歌手／全部）、題數、倒數、自動播放／部分答案設定、提交、暫停、手動播放、揭曉、跳過、下一題與結束回合。
[x] AMQ-329 接入 `src/app.js` 與共享狀態；`questionStatus` 是 engine phase 的投影，UI 不另建 phase source；模式切換時釋放舊 session／audio service。
[x] AMQ-330 新增 quiz pool 5 項、quiz clock 4 項、quiz session 6 項、quiz panel integration 1 組測試；真實來源整合測試核對 AMQ 37,939 與 EMQ 16,839 筆可播放 pool。
[x] AMQ-331 驗證題目 no-repeat、播放開始才計時、暫停時間不計入倒數、手動播放、超時、未播放跳過不計分、MIX 阻擋及元件生命週期清理。
[x] AMQ-332 更新架構／工作清單／交接文件；保留音訊 URL 可播放性與真實瀏覽器 E2E 為未驗收事項。
[!] AMQ-333 瀏覽器 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 環境阻擋；未驗證真實媒體 URL、跨域／自動播放政策或視覺互動。
[x] AMQ-334（Batch 24 已解除）作品熟悉度已由 persistence store 持久化；Batch 25 另完成 source-aware 答題歷史與摘要。
[!] AMQ-335 MIX weighting／fallback 已实现并测试；旧版完整筛选语义与 Candidate382 Stage 0 CSS／行为相容仍未验收，基准／浏览器阻塞另有记录。


## 2026-10-27 第二十四批：熟悉度持久化

[x] AMQ-336 依參考 HTML 第 403、405、870–872 行確認 AMQ 熟悉度 key、fallback、事件及 0–3 level 語義。
[x] AMQ-337 新增 `src/persistence/familiarity-store.js`，封裝 AMQ legacy key 的讀寫、舊 key fallback、0 值刪除、storage event 與 dispose。
[x] AMQ-338 新增 source-aware EMQ key `amqLearningFamiliarityV1`，避免 AMQ／EMQ 相同數字 ID 覆寫。
[x] AMQ-339 QuizSession 以 store 提供 engine `keepHigher` 讀取，並在可計分作答、超時、已播放後跳過時持久化；揭曉與未播放跳過不寫入。
[x] AMQ-340 寫入失敗回報 `persisted:false` 並顯示提示，不宣稱保存成功。
[x] AMQ-341 新增 familiarity store 6 項測試，涵蓋舊 key、level 正規化、來源碰撞、無效輸入、儲存失敗及 storage event。
[x] AMQ-342 更新資料契約、來源稽核、架構與工作清單。
[x] AMQ-343（Batch 25 已解除）新版 source-aware detail／summary adapter 已完成；舊版 history keys 僅讀不寫，source-aware song keys 避免 ID 衝突。
[x] AMQ-344（Batch 26／27 已解除）FSRS scheduler、AMQ SRS store 與猜歌 UI 評級流程已接線；黑名單整合與 EMQ SRS 仍待處理。


## 2026-10-27 第二十五批：來源感知答題歷史與摘要

[x] AMQ-345 新增 `src/persistence/quiz-history-store.js`，新版明細與長期摘要分別寫入 `amqLearningQuizHistoryV1`／`amqLearningQuizHistorySummaryV1`，保留舊版 `aniQuizHistory_v1`、`aniQuizHistorySummaryV1`、`aniQuizTargetSummaryV1` 唯讀。
[x] AMQ-346 新版歷史以 AMQ／EMQ source、song ID 與 target 維持可區分的記錄，避免相同 ID 跨來源合併摘要；全部目標作答拆成作品／歌曲／歌手三筆。
[x] AMQ-347 將 QuizSession 作答、超時、播放後跳過接入歷史 adapter；揭曉及未播放跳過不記錄，保留原本 familiarity 寫入條件。
[x] AMQ-348 實作 2,000 筆明細上限、來源／目標／歌曲／日期摘要、5,000 筆去重窗口與批次／延遲摘要保存。
[x] AMQ-349 舊版 detail 與 summary 以唯讀方式呈現，不直接遷移或覆寫舊 key；新版 summary 以新版記錄為準。
[x] AMQ-350 損壞新版 detail／summary 在覆寫前先寫 recovery 副本；若 detail 無法安全隔離則封鎖寫入並保留原始內容。
[x] AMQ-351 接入答題紀錄摘要 UI，顯示新／舊紀錄數、最近五筆及儲存異常提示。
[x] AMQ-352 新增 `tests/quiz-history-store.test.cjs` 9 項測試，覆蓋 summary、target totals、legacy read-only、上限、source collision、去重、recovery 與儲存失敗。
[x] AMQ-353 擴充 QuizSession 測試至 10/10，覆蓋答題／超時寫入、全部目標分開記錄，以及揭曉／未播放跳過不寫歷史。
[x] AMQ-354 更新架構／資料契約／開工指引／主清單與交接文件。
[x] AMQ-355（Batch 26／27 已解除）FSRS／SRS 排程、評級與既有 QuizSession UI 已接線；真實瀏覽器 E2E 仍受既有環境阻擋。

第二十五批測試證據：history store 9/9、quiz session 10/10、quiz panel integration PASS、完整 Node 測試與 source audit／mapper verifier PASS；架構檢查 353 passed、0 failed；所有 JS/CJS 語法檢查 PASS。瀏覽器 E2E 未執行，不列為通過。


## 2026-10-27 第二十六批：FSRS-6 排程核心與 SRS 儲存

[x] AMQ-356 依參考 HTML 中 `aniSrsScheduleV1`、FSRS 版本、權重、卡片狀態與設定範圍建立靜態契約；不修改參考 HTML。
[x] AMQ-357 新增 DOM-free `src/learning/fsrs-scheduler.js`，實作 FSRS-6 stability／difficulty 更新、interval 計算、new／learning／review／suspended 轉移與最多 20 筆 review log。
[x] AMQ-358 新增 `src/persistence/srs-store.js`，相容既有 `aniSrsScheduleV1` schema，支援 enrollment、暫停／恢復、評級、預覽、到期佇列、每日新歌上限與 batch size。
[x] AMQ-359 保留既有 SRS key 的相容性；損壞資料先寫 recovery 副本，recovery 失敗時封鎖寫入。儲存失敗不發布新 schedule。
[x] AMQ-360 依參考 schema 明確限制目前 SRS 為 AMQ-only；EMQ 不寫入沒有 source 欄位的舊版卡片格式，避免來源 ID 歧義。
[x] AMQ-361 將 scheduler／store 納入主頁與測試頁載入順序，架構檢查保護 learning 與 persistence 依賴邊界。
[x] AMQ-362 新增 SRS store 13 項測試，覆蓋預設值、FSRS grade、relearning、preview、queue、suspend/resume、legacy key、AMQ-only、recovery、儲存失敗與設定限制。
[x] AMQ-363 更新資料／架構契約、開工指引、主清單及交接文件。
[x] AMQ-364（Batch 27 已解除）SRS UI 已接入歌曲加入／暫停／恢復、到期複習、grade 1–4 評級、間隔預覽與下一題評級門檻。真實瀏覽器 E2E 仍受環境阻擋。

第二十六批核心驗證：`tests/srs-store.test.cjs` 13/13 PASS；`tools/check-architecture.cjs` 385 passed、0 failed；完整 Node 回歸與所有 JS/CJS 語法檢查另於交付前重跑。


## 2026-10-27 第二十七批：SRS UI 與既有猜歌 session 整合

[x] AMQ-365 將 SRS store 接入 `quiz-panel.js`，以 AMQ playable ID resolver 過濾不可播放／不存在的卡片。
[x] AMQ-366 新增目前歌曲加入、暫停、恢復 SRS 卡片的 UI 操作。
[x] AMQ-367 新增 due-first SRS session，將排程 ID 注入既有 QuizSession，不複製 engine／AudioService／timer。
[x] AMQ-368 新增 Again／Hard／Good／Easy 評級、下次間隔預覽與成功保存後才允許下一題；儲存失敗時可結束回合，未成功保存的卡片排程不變。
[x] AMQ-369 新增每日新卡／每次上限設定與到期／新卡／學習中／複習中／暫停統計。
[x] AMQ-370 擴充 quiz panel 整合測試，驗證加入卡片、評級門檻、due session 與模式切換清理。
[x] AMQ-371（Batch 28 已解除）核對並接入 `aniBlacklistedSongs_v1` 與 `ani-blacklist-changed-v51`；SRS queue／一般 AMQ 抽題都排除黑名單歌曲。
[x] AMQ-372 EMQ 已有 source-aware SRS key、store 与 quiz panel integration tests；legacy source-less key 不自动迁移至 EMQ。
[!] AMQ-373 真實瀏覽器音訊／UI E2E 仍受環境 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。


## 2026-10-27 第二十八批：歌曲／作品黑名單整合

[x] AMQ-374 新增 legacy-compatible blacklist store，讀寫 `aniBlacklistedSongs_v1` 與 `aniBlacklistedAnime_v1`。
[x] AMQ-375 保留 `ani-blacklist-changed-v51` 事件 detail；song 與 anime scope 分別 reload。
[x] AMQ-376 損壞 blacklist array 先 quarantine；recovery 失敗時保護原始資料並阻止該 scope 寫入。
[x] AMQ-377 Quiz panel 增加歌曲／作品黑名單控制，並刷新 QuizSession eligibility。
[x] AMQ-378 一般 AMQ 抽題與 SRS due queue 共用歌曲／作品排除 predicate。
[x] AMQ-379 新增 blacklist store 9 項測試與 work blacklist UI integration coverage。
[x] AMQ-380 EMQ SRS 已由独立 source-aware schedule 支持；AMQ legacy cards 与 EMQ 不共享无来源 ID。
[!] AMQ-381 真實瀏覽器音訊／UI E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。
[x] AMQ-382 更新持續工作清單、交接文件與資料契約；黑名單 store 9/9、完整 Node 回歸 PASS、架構檢查 400/0。


## 2026-10-27 第二十九批：MIX 正式來源規則與猜歌接線

[x] AMQ-383 依 `AMQ382(1).html` 靜態 `combinePool`／`chooseQuestion` 證據核對 MIX：AMQ 與 EMQ 都有符合條件的候選時，以 2/3 機率選 AMQ、1/3 選 EMQ；任一來源沒有候選時退回可用來源。
[x] AMQ-384 將 `src/data/source-runtime.js` 的 MIX mode mapping 改為 composite adapter `AMQ + EMQ`，不再固定回報 `DATA_MODE_UNCONFIGURED`。
[x] AMQ-385 `src/engine/quiz-pool.js` 支援 MIX，保留來源感知身份，避免 AMQ／EMQ 同 ID 互相去重。
[x] AMQ-386 `src/engine/quiz-session.js` 在 MIX 模式按 2:1 source weight 抽取尚未出題候選；若某來源已無未出題候選則退回另一來源。固定 SRS question queue 不受 source weighting 影響。
[x] AMQ-387 `src/ui/quiz-panel.js` 在 MIX 模式載入 AMQ／EMQ 聯合 catalog，啟用猜歌；SRS 仍維持 AMQ-only，黑名單仍只套用 AMQ。
[x] AMQ-388 真實來源整合測試驗證 MIX 載入 55,660 筆標準化記錄，source facet 為 AMQ 38,821／EMQ 16,839，可播放候選池 54,778 首。
[x] AMQ-389 新增／更新測試驗證 MIX 來源權重、EMQ 分支與單一來源 fallback；quiz pool 保留跨來源相同 ID。
[x] AMQ-390 更新架構／資料契約／開工指引／主清單與 Batch 29 交接文件。
[!] AMQ-391 舊版 MIX 在 AMQ 專屬篩選（觀看狀態、季節、作品類型、難度或 hard pool）啟用時會抑制 EMQ，除非有明確 EMQ 自訂清單範圍；新版目前沒有這些專屬篩選控制，未實作該條件分支。真實瀏覽器 E2E 仍受環境阻擋。

第二十九批實際最終驗證：所有 Node 測試 PASS；core 67/67、data pipeline 15/15、blacklist 9/9、catalog browser 7/7、familiarity 7/7、FSRS scheduler 7/7、quiz history 9/9、quiz pool 5/5、quiz session 13/13、SRS store 13/13、source mapper 7/7、tooling 8/8；architecture 400/0；source audit／mapper verifier／JS-CJS syntax PASS。真實瀏覽器 E2E 未執行。


## 2026-10-27 第三十批：EMQ SRS 來源隔離

[x] AMQ-392 將 `src/persistence/srs-store.js` 擴充為可依來源建立 store；AMQ 預設仍使用舊版 `aniSrsScheduleV1`。
[x] AMQ-393 新增 EMQ 專屬 `amqLearningEmqSrsScheduleV1`／recovery prefix；根 schedule 與每張 card 均驗證 `source: "EMQ"`。
[x] AMQ-394 EMQ source-less／來源錯置排程先 quarantine；recovery 失敗會封鎖寫入，不讀取、不覆寫 AMQ legacy key。
[x] AMQ-395 Quiz panel 在 AMQ／EMQ 模式按歌曲來源選用對應 SRS store，接入加入／暫停／恢復、評級、預覽與到期 queue；MIX SRS 明確停用，避免來源 ID 碰撞。
[x] AMQ-396 新增 EMQ store schema／AMQ legacy 保護測試，並擴充 quiz panel integration 覆蓋 EMQ 加卡與評級。
[x] AMQ-397 更新 `README_FIRST.md`、`AI_START_HERE.md`、`docs/DATA_CONTRACT.md`、`docs/ARCHITECTURE.md`、工作狀態與交接文件。
[!] AMQ-398 真實瀏覽器 localStorage／UI／音訊 E2E 仍未驗收；不得以 Node integration 代替。
[!] AMQ-399 Chromium headless smoke 在 25 秒後逾時且沒有 DOM dump；記錄 DBus／zygote 錯誤於 `/mnt/data/amq_batch30_chromium_smoke.log`，本環境無法完成真實瀏覽器驗收，未重試。
[~] AMQ-400 MIX legacy AMQ-specific filter suppression 仍待處理；新版目前沒有 watchlist／season／difficulty／hard-pool 等相應篩選控制，不新增虛構 UI，待相關篩選功能有明確需求時再實作相容分支。


## 2026-10-27 第三十一批：跨模式生命週期回歸保護

[x] AMQ-401 擴充 `tests/quiz-panel.test.cjs`，驗證 AMQ → MIX（來源載入失敗／成功）→ EMQ → AMQ 的模式切換，檢查舊 session dispose、phase projection reset、曲庫來源隔離與 AMQ blacklist 不洩漏到 EMQ。
[x] AMQ-402 驗證從 EMQ 返回 AMQ 時不會抽到 EMQ 記錄，EMQ SRS 卡仍保存在獨立 store，不污染 AMQ schedule。
[!] AMQ-403 真實瀏覽器 UI／音訊 E2E 仍受目前 Chromium smoke 逾時阻塞；Node integration 不視為瀏覽器驗收。


## 2026-10-27 第三十二批：音訊錯誤契約與 MIX 狀態訊息一致性

[x] AMQ-404 AudioService 對播放失敗、候選格式錯誤、無候選、逾時設定錯誤及自動播放阻擋新增共享 `AMQError` 格式的 `errorInfo`，保留既有 `error` 字串作相容介面。
[x] AMQ-405 所有候選失敗會在結果與 service state 提供 `AUDIO_ALL_CANDIDATES_FAILED`、`audio` 分類、retryable 與候選失敗摘要。
[x] AMQ-406 更新 AudioService 測試，驗證錯誤 code/category/retryable 與既有字串相容性；仍是 mock media，不宣稱真實音訊播放通過。
[x] AMQ-407 修正 quiz panel 與初始 HTML 中已過期的 MIX「尚未配置」提示，改為描述目前 2:1 source weighting 與 SRS 單一來源限制。
[x] AMQ-408 更新產品核心契約，移除已被 Batch 29 取代的 MIX `DATA_MODE_UNCONFIGURED` 現況描述。
[!] AMQ-409 真實瀏覽器 UI／音訊 E2E 仍受既有環境導覽阻擋；本批未重試同一 Chromium 啟動方式。


## 2026-10-27 第三十三批：共用資料身份契約與去重規則

[x] AMQ-410 新增 `src/data/identity.js`，集中 identifier 型別驗證、typed ID key、source-scoped identity 與相同身份判斷；使用 JSON tuple encoding，避免來源字串含分隔符時發生 key collision。
[x] AMQ-411 `src/data/validate.js` 與 `src/data/query-index.js` 共用身份 helper，維持 `source + ID 型別 + ID 值` 唯一性；驗證器與 Catalog 對重複身份採一致規則。
[x] AMQ-412 `src/engine/quiz-pool.js` 改用同一身份 helper，不再把數字 ID 與同值字串 ID 合併；AMQ／EMQ 相同 ID 仍可共存。
[x] AMQ-413 新增 `tests/data-identity.test.cjs` 6 項回歸，覆蓋來源／型別隔離、分隔符 collision、非法 ID、validator/catalog 一致性、quiz pool 身份與同標題不同 ID 不自動合併。
[x] AMQ-414 更新 HTML 載入順序、測試載入順序、架構檢查與資料／架構契約。
[!] AMQ-415 上游資料提供者未提供跨版本 ID 穩定性保證；新版保留並使用上游 ID，但不能宣稱未來資料版本 ID 永不變更。
[!] AMQ-416 真實瀏覽器 UI／音訊 E2E 仍受環境頁面導覽政策阻擋；本批不以 Node 測試代替。


## 2026-10-27 第三十四批：Repository 契約與取消邊界防護

[x] AMQ-417 Repository 在資料驗證前驗證 Adapter result shape：`records` 必須是陣列，`sourceCount` 為非負安全整數且與映射記錄數相等。
[x] AMQ-418 Composite `sourceCounts` 必須為非空來源計數物件，各值為非負安全整數，總和與 `sourceCount` 相等。
[x] AMQ-419 有 `sourceCounts` 時，逐筆 `record.source` 必須是已宣告來源，實際分組數必須與計數一致。
[x] AMQ-420 契約違反時以 `DATA_ADAPTER_RESULT_INVALID` 進入 failed，確保不建立／發布 Catalog，且不保留有效筆數。
[x] AMQ-421 新增 Repository malformed envelope 與有效來源計數整合回歸測試。
[!] AMQ-422 真實瀏覽器 UI／音訊 E2E 仍受環境頁面導覽政策阻擋；本批不重試同一導覽方式。
[x] AMQ-423 Repository 將 Adapter load Promise 與 abort signal 競速，取消不再依賴注入 Adapter 是否遵守 AbortSignal。
[x] AMQ-424 新載入取代舊載入時，舊請求立即以 stale 結束，延遲來源結果不能覆蓋新 Catalog／state。
[x] AMQ-425 新增不合作 Adapter 的直接取消與 supersede 回歸測試。

第三十四批驗證證據與封包位置記錄於 `docs/WORK_STATUS.md` 及 `docs/HANDOFF_BATCH34.md`。


## 2026-10-27 第三十五批：Repository 失敗原子性回歸

[x] AMQ-426 驗證 Repository 首次載入成功後，第二次 source failure 會清除舊 Catalog snapshot，狀態為 failed 且有效／輸入／拒絕計數歸零。
[x] AMQ-427 驗證 Repository 首次載入成功後，第二次 validator 丟出例外時正規化為 `DATA_VALIDATION_FAILED`，清除舊 Catalog snapshot 與計數。
[x] AMQ-428 驗證 Repository 首次載入成功後，第二次 Catalog factory 失敗時正規化為 `DATA_CATALOG_BUILD_FAILED`，清除舊 Catalog snapshot 與計數。
[x] AMQ-429 將三種二次載入失敗情境加入 `tests/core.test.cjs`，防止先前成功資料殘留於共享狀態。
[!] AMQ-430 真實瀏覽器 UI／音訊 E2E 仍受既有頁面導覽政策阻擋；不重試同一方式。

Batch 35 驗證證據、完整回歸結果與 ZIP 封包記錄於 `docs/WORK_STATUS.md` 及 `docs/HANDOFF_BATCH35.md`。


## 2026-10-27 第三十六批：錯誤診斷快照與可變資料隔離

[x] AMQ-431 `src/core/errors.js` 對 `details` 建立有界快照，避免錯誤契約保留呼叫端可變物件參照。
[x] AMQ-432 錯誤 details 遞迴凍結；限制巢狀深度與每層集合大小，對非 plain object 做字串化處理。
[x] AMQ-433 `cause.name` 與 `cause.message` 限長並凍結，避免診斷欄位無界增長。
[x] AMQ-434 `tests/core.test.cjs` 新增可變 details 隔離、遞迴凍結、深度上限及 cause 長度回歸。
[!] AMQ-435 真實瀏覽器 UI／音訊 E2E 仍因頁面導覽遭環境政策阻擋，未宣稱通過。

Batch 36：core 76/76；21/21 個 `tests/*.test.cjs` 腳本退出碼 0；tooling 8/8；architecture 415/0；source audit、mapper verifier、5 次 benchmark、JS/CJS syntax PASS。詳細證據在 `/mnt/data/amq_batch36_logs/` 及 `docs/HANDOFF_BATCH36.md`。


## 2026-10-27 第三十七批：Normalized error projection 與 UI 整合回歸

[x] AMQ-448 `src/core/errors.js` 新增 `normalize(error, defaults)`，為不完整的外部錯誤補齊穩定欄位，並把診斷 details 轉成受控快照。
[x] AMQ-449 `src/app.js`、`src/ui/catalog-browser.js`、`src/ui/quiz-panel.js` 在 UI 投影前正規化共享資料錯誤與捕獲例外；不直接把原始 exception 物件當作 UI 契約。
[x] AMQ-450 新增缺少 code／message、可選 details、特殊字元及 HTML-like 字串回歸；錯誤文字以 `textContent` 呈現，不解析成 HTML。
[x] AMQ-451 完成全量 Node 測試、tooling、架構檢查、來源稽核、真實資料 mapper 驗證、catalog benchmark 與 JS/CJS syntax 檢查。
[!] AMQ-452 真實瀏覽器 UI／音訊 E2E 仍因環境頁面導覽政策阻擋；本批未以 Node 測試取代。

Batch 37 驗證摘要：`tests/*.test.cjs` 21/21 scripts exit 0；`tests/core.test.cjs` 77/77；`node --test tests/tooling.test.cjs` 8/8；architecture 415/0；source audit、mapper verification（AMQ 38,821／EMQ 16,839／Catalog 55,660）、5 次 catalog benchmark、全量 JS/CJS syntax PASS。詳細日誌位於 `/mnt/data/amq_batch37_logs/`。


## 2026-10-27 第三十八批：猜歌狀態／計時生命週期整合

[x] AMQ-453 修正 `QuizSession.pause()` 的 deadline race：先暫停／檢查 Clock，再轉 Engine phase；若 deadline 已過，Clock 在 Engine 仍為 `playing` 時結算 timeout，Session 不會進入無法恢復的 `paused`。
[x] AMQ-454 在 `tests/quiz-session.test.cjs` 加入 fake scheduler 的 `jump()`，模擬背景分頁／延遲 interval 回呼；驗證逾時只結算一次、完成題數正確、resume 被拒絕。
[x] AMQ-455 核對 Engine／Session／Clock／AudioService／QuizPanel 的責任邊界及開始、暫停、恢復、作答、揭曉、跳過、下一題、結束與 dispose 的既有測試覆蓋；未發現足以支持擴大重寫的證據，保留既有模組分工。
[!] AMQ-456 真實瀏覽器 UI／音訊 E2E 仍受既有頁面導覽政策阻擋；本批沒有重試同一方式。

Batch 38 最終驗證：`tests/*.test.cjs` 21/21 scripts exit 0；`tests/quiz-session.test.cjs` 14/14；`node --test tests/tooling.test.cjs` 8/8；`tools/check-architecture.cjs` 415 passed／0 failed；source audit 無重複 ID／dangling references；mapper verifier PASS（AMQ 38,821、EMQ 16,839、Catalog 55,660）；5 次 catalog benchmark PASS；`src/`、`tests/`、`tools/` 全部 JS/CJS syntax PASS。來源資產 SHA-256 與先前紀錄一致，未修改。日誌位於 `/mnt/data/amq_batch38_logs/`。


## 2026-10-27 第三十九批：MIX 規則與音訊生命週期

[x] AMQ-457 核對 AMQ／EMQ／MIX 來源選池、source-aware identity、MIX 2:1 權重與單來源耗盡 fallback；保留已存在的測試證據，不宣稱所有舊版篩選語義相容。
[x] AMQ-458 修正 AudioService `canplay` 事件提前清除 autoplay deadline 的問題；未在期限內收到真實 `playing` 時會進入候選失敗／備援，而非永久停在 ready。
[x] AMQ-459 修正 AudioService 暫停後遲到的 `playing` 事件覆寫 paused 狀態；resume 重新啟動候選 deadline 並等待新的實際播放事件。
[x] AMQ-460 在 `tests/audio-service.test.cjs` 新增 canplay-stall fallback 與 late-playing-after-pause 回歸。
[x] AMQ-461 完成 21/21 Node 測試腳本、tooling 8/8、architecture 415/0、source audit、mapper verifier、5 次 benchmark 及全量 JS/CJS syntax 驗證。
[!] AMQ-462 真實瀏覽器 UI／音訊 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 頁面導覽政策阻擋；本批未重試同一方式。
[!] AMQ-463 AMQ-specific MIX filter suppression 仍待未來對應篩選控制確立後實作；目前新版無相應控制，不新增猜測性 UI。

Batch 39 測試日誌位於 `/mnt/data/amq_batch39_logs/`；來源資產雜湊不變。下一批轉向必要功能真相表與持久化／來源隔離回歸，UI／CSS 大重構維持階段 5。


## 2026-10-27 第四十批：必要功能真相表與熟悉度讀取失敗保護

[x] AMQ-464 依 `FUNCTION_INVENTORY.md`、`ACCEPTANCE.md` 與實際模組／測試證據建立必要功能真相表，區分已實作待驗收、未實作、延後與阻塞。
[x] AMQ-465 核對熟悉度、答題歷史、SRS、黑名單的來源隔離、舊 key 保護、失敗原子性與外部 storage event 行為；設定版本化 store、收藏 CRUD、多人／外部匯入列為未完成或延後，不假稱完成。
[x] AMQ-466 修正 familiarity store 將 storage 讀取例外靜默當成空 map 的資料風險：讀取失敗時保留現有記憶體快照、阻止該來源寫入並暴露讀取阻塞狀態；讀取恢復後由 storage event 重新載入。
[x] AMQ-467 在 `tests/familiarity-store.test.cjs` 新增讀取失敗不覆寫既有原始資料、恢復後重載並可正常寫入的回歸測試。
[x] AMQ-468 完成全量 Node／tooling／architecture／source audit／mapper／benchmark／syntax 驗證；manifest／ZIP 驗證於交付前完成並記錄。
[!] AMQ-469 真實瀏覽器 E2E 與真實音源仍未驗證；既有頁面導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，本批不重試同一方式。

Batch 40 新增 `getPersistenceStatus()`，可分別查看 AMQ／EMQ familiarity read-blocked 狀態。下一批優先追查答題歷史明細／摘要寫入部分失敗時的恢復契約、設定持久化缺口及跨模組必要功能回歸；UI／CSS 大重構仍在階段 5。


## 2026-10-27 第四十一批：歷史摘要安全與猜歌設定持久化

[x] AMQ-470 將答題歷史摘要 storage read exception 與 JSON parse failure 分開；未知摘要無法讀取時保留原始 bytes 並阻止摘要寫入。
[x] AMQ-471 新增 `quiz-history-store.test.cjs` 回歸：摘要讀取失敗後 append／flush 不覆寫原始摘要，storage event 成功讀取後重新建立摘要並解除阻塞。
[x] AMQ-472 新增 `src/persistence/app-settings-store.js`，建立 schemaVersion 1 的版本化猜歌設定 store，欄位與範圍有明確驗證。
[x] AMQ-473 設定 store 對 read failure、invalid schema quarantine、recovery write failure、setItem failure 採安全降級，不在寫入失敗時提交記憶體候選狀態。
[x] AMQ-474 新增 `tests/app-settings-store.test.cjs`，涵蓋設定保存／恢復、無效 schema、備份失敗、讀取阻塞及寫入失敗。
[x] AMQ-475 將設定 store 接線到 `quiz-panel.js` 現有設定控制項；mount 恢復、change 保存、外部 storage event 更新未聚焦控制項、dispose 釋放 store。
[x] AMQ-476 更新 `src/index.html`、`tests/tests.html`、quiz panel 測試與架構檢查，確保載入順序和 UI 設定持久化接線有測試。
[x] AMQ-477 完成 22/22 `tests/*.test.cjs` 腳本、tooling 8/8、architecture 430/0、source audit、mapper verifier、5 次 benchmark 及全量 JS/CJS syntax 驗證。
[x] AMQ-478 更新架構、資料契約、功能真相表與交接文件，區分已實作猜歌設定與仍未實作的深色主題／背景設定。
[x] AMQ-481 重新產生 `MANIFEST.sha256` 並建立 Batch 41 完整 ZIP；封包 CRC 與 manifest 逐項 SHA-256 核對均通過。
[!] AMQ-479 真實瀏覽器、跨分頁 localStorage 及真實音源 E2E 仍 BLOCKED／未驗證；不以 Node mock 測試替代。
[!] AMQ-480 答題歷史明細與摘要仍為不同 key，跨 key 寫入不是原子交易；本批補上摘要讀取失敗防覆寫，後續仍須測試跨模組恢復與瀏覽器實際行為。

Batch 41 詳細結果見 `docs/HANDOFF_BATCH41.md` 與 `/mnt/data/amq_batch41_logs/`。


## 2026-10-27 第四十二批：持久化失敗恢復與狀態投影

[x] AMQ-482 建立 familiarity／quiz history／SRS／blacklist／app settings 的 storage failure matrix，明確記錄讀取、寫入、恢復、storage clear 與 UI 狀態契約。
[x] AMQ-483 修正 SRS 外部 storage event 讀取失敗時把最後已知 schedule 替換成空 schedule 的問題；保留快照並阻止寫入，成功重讀後才替換。
[x] AMQ-484 新增 SRS 外部重讀失敗／恢復回歸，確認讀取失敗不清除卡片、阻塞期間不變更快照，成功重讀後更新為外部資料。
[x] AMQ-485 修正新版答題歷史外部 detail 讀取失敗時將記憶體歷史清空的問題；保留最後已知快照並封鎖寫入。
[x] AMQ-486 修正 legacy history 讀取例外被靜默當成空陣列的問題；保留唯讀快照並暴露 `legacyReadError`。
[x] AMQ-487 新增新版 detail 與 legacy detail 讀取失敗、成功恢復及快照替換回歸。
[x] AMQ-488 設定 store 寫入失敗時通知 subscribers；無效 schema 隔離後透過 `recoveryNotice` 投影到 quiz UI，避免隱藏恢復提示。
[x] AMQ-489 新增設定 storage clear、外部更新、dispose listener cleanup、寫入失敗通知及 UI 聚焦控制項保護回歸。
[x] AMQ-490 更新 architecture／data contract／function inventory，加入跨 store storage failure matrix 與驗收限制。
[x] AMQ-491 完成全量 Node、tooling、architecture、source audit、mapper verifier、5 次 benchmark、syntax、manifest 與 ZIP 驗證。
[!] AMQ-492 真實瀏覽器跨分頁 localStorage／quota／pagehide／音訊 E2E 仍未驗收；既有頁面導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，本批不重試相同方式。
[!] AMQ-493 答題歷史明細與摘要仍是不同 key，跨 key 原子性未保證；本批只修復讀取失敗快照保護與狀態投影。

Batch 42 詳細證據見 `docs/HANDOFF_BATCH42.md` 與 `/mnt/data/amq_batch42_logs/`。


## 2026-10-27 Batch 43：持久化 API 契約與部分成功恢復

[x] AMQ-494 稽核各 store 寫入失敗通知與狀態 API；補上 SRS persist／flush failure subscriber 通知，且 `persisted` 狀態可查。
[x] AMQ-495 修正 quiz history `summaryPersisted` 忽略 debounce pending 的狀態誤報；新增 `fullyPersisted`，並保留 `persisted` 作為 detail 保存結果的相容欄位。
[x] AMQ-496 新增 detail 成功、summary 失敗、重新建立 store 後由 detail 恢復摘要、再成功保存且統計不重複的回歸測試。
[x] AMQ-497 修正 blacklist song／work 寫入失敗時通知 subscribers，並分離 `songWriteError`／`workWriteError`，不把寫入錯誤當作讀取錯誤。
[x] AMQ-498 更新 quiz UI 黑名單錯誤提示，區分讀取失敗與保存失敗。
[x] AMQ-499 修正 familiarity storage event 的讀取失敗不再向訂閱者及 `getLastWrite()` 回報持久化成功。
[x] AMQ-500 新增 familiarity／blacklist／SRS storage clear、read recovery、write failure notification 與 dispose 相關回歸。
[x] AMQ-501 更新 `DATA_CONTRACT.md`、`ARCHITECTURE.md`、`FUNCTION_INVENTORY.md`，記錄部分持久化契約與跨 key 限制。
[x] AMQ-502 完成所有 Node test scripts、tooling、architecture、source audit、mapper verification、benchmark、syntax 驗證。
[x] AMQ-503 更新 `WORK_STATUS.md`、`AI_START_HERE.md`、`NEXT_SESSION_PROMPT.md` 與新增 Batch 43 handoff。
[x] AMQ-504 重新產生 manifest，封裝完整 ZIP 並驗證 CRC／逐項 SHA-256。
[!] AMQ-505 真實瀏覽器跨分頁 localStorage／quota／pagehide／音訊驗收仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞；不得以 Node/mock 測試替代。

下一批 Batch 44：以 `docs/FUNCTION_INVENTORY.md` 與 `docs/ACCEPTANCE.md` 為依據，整理必要功能的跨模組驗收矩陣；優先補足目前已接線但未有端到端 Node 整合證據的核心流程，確認搜尋／篩選、模式切換、開始／暫停／答題／超時／下一題／結束，以及持久化回報。不得開始 UI／CSS 大重構，直到必要功能回歸完成。


## 2026-10-27 Batch 44：必要功能跨模組驗收矩陣

[x] AMQ-506 依 `FUNCTION_INVENTORY.md`、`ACCEPTANCE.md`、`PRODUCT_CORE_CONTRACT.md` 更新必要功能現況，修正資料來源已存在、查詢／SRS／QuizSession 已實作但待驗收的舊描述。
[x] AMQ-507 盤點 AMQ／EMQ／MIX 載入取消、query index、catalog browser、quiz session、audio service、history／familiarity／SRS／blacklist 的現有整合測試證據與缺口。
[x] AMQ-508 新增 `tests/audio-session.integration.test.cjs`，使用真實 AudioService 與 QuizSession 模組搭配 mock media，驗證 canplay 不啟動計時、playing 才啟動、pause 凍結時間、resume 延續 deadline 及 dispose 清理 timer。
[x] AMQ-509 將新增整合測試加入 Node 測試套件執行範圍，並完成全量回歸。
[x] AMQ-510 更新功能真相表、主清單、工作狀態、開工指引、下一輪提示詞及新增 Batch 44 handoff。
[x] AMQ-511 重新產生 manifest、完整 ZIP 並驗證 CRC 與逐項 SHA-256。
[!] AMQ-512 真實瀏覽器與真實音訊仍因頁面導覽政策阻塞／尚未驗收；mock media 整合測試不代表實際音源可播放。

下一批 Batch 45：從必要功能缺口中選擇可安全完成且有明確契約的項目，優先檢查曲庫瀏覽 UI 與查詢狀態整合、主要空／錯誤／分頁狀態，補充可執行的 controller/UI integration 測試；不開始 CSS 大重構，不虛構 Candidate302 相容性。


## 2026-10-27 Batch 45：曲庫瀏覽狀態與查詢整合

[x] AMQ-513 檢查 `catalog-browser.js` 的 shared data status、query controller、篩選／排序／分頁與 UI 狀態投影。
[x] AMQ-514 修正空來源與搜尋無結果的提示混淆，讓 `dataStatus=empty` 顯示來源無可用歌曲，而非要求使用者調整篩選。
[x] AMQ-515 修正載入失敗時空狀態文案仍顯示「曲庫尚未載入」的誤導，保留獨立錯誤訊息。
[x] AMQ-516 將篩選後結果數標示為「符合條件」，避免與整份曲庫總量混淆。
[x] AMQ-517 新增 `tests/catalog-browser.integration.test.cjs`，驗證 loading／loaded／pagination／no matches／empty source／failed／dispose 狀態。
[x] AMQ-518 完成全量 Node、tooling、architecture、source audit、mapper、benchmark、syntax 驗證。
[x] AMQ-519 更新功能真相表、主清單、工作狀態、開工指引、下一輪提示詞與 Batch 45 handoff。
[x] AMQ-520 更新 manifest、完整 ZIP 並驗證 CRC 與逐項 SHA-256。
[!] AMQ-521 真實瀏覽器布局／鍵盤／responsive／真實曲庫互動仍未驗收；既有頁面導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重試同一方式。

下一批 Batch 46：依 `ACCEPTANCE.md` 與 `PRODUCT_CORE_CONTRACT.md` 檢查必要功能仍未完成的缺口，優先盤點自訂清單／收藏／看番狀態 CRUD 是否屬於核心結案必要範圍，以及可否以既有舊版靜態證據建立最小資料契約；未證實的舊版行為不可猜測實作。若缺少足夠契約，先做其他可驗證的核心缺口。


## 2026-10-27 Batch 46：持久化結果跨模組錯誤傳遞

[x] AMQ-522 追蹤 history store 的 `persisted`、`summaryPersisted`、`summaryPending` 與 QuizSession `persistHistory()` 間的契約。
[x] AMQ-523 修正 `quiz-history-store.appendEntries()` 額外回傳 `summaryFailed`，區分明確 summary failure 與正常 debounce pending。
[x] AMQ-524 修正 `QuizSession.persistHistory()`，明確 summary failure 會觸發部分持久化警告，正常 pending 不會被誤報。
[x] AMQ-525 在 `tests/quiz-session.test.cjs` 新增 partial failure 與 normal pending 對照回歸。
[x] AMQ-526 更新 `DATA_CONTRACT.md`、`ARCHITECTURE.md`、`FUNCTION_INVENTORY.md`，記錄跨模組錯誤契約。
[x] AMQ-527 完成全量 Node、tooling、architecture、source audit、mapper、benchmark、syntax 驗證。
[x] AMQ-528 更新工作狀態、開工指引、下一輪提示詞、handoff、manifest 與 ZIP。
[x] AMQ-529（Batch 50–52 完成可執行範圍）Candidate381 靜態參考已用於清單契約；store、UI CRUD、鍵盤選取及 source-aware QuizPool 已完成 Node 驗證。真實瀏覽器、收藏身份及正式基準相容性仍由獨立阻塞項追蹤，不宣稱 Candidate382 Stage 0／Candidate302 相容。

下一批 Batch 47：繼續處理有明確契約且可測試的核心缺口；優先檢查 QuizSession 其他 persistence error path、mode-switch lifecycle 與 query controller 邊界。自訂清單 CRUD 在解除資料契約阻塞前不聲稱已完成。


## 2026-10-27 Batch 47：QuizSession 持久化 adapter 例外隔離

[x] AMQ-530 稽核 QuizSession familiarity／history persistence call path，確認一個注入 store throw 時目前會中止整個答題 handler 並跳過另一個 store。
[x] AMQ-531 修正 familiarity 與 history 寫入各自捕捉 adapter 例外，讓已提交的答題結果仍可正常回傳，並繼續嘗試另一個持久化步驟。
[x] AMQ-532 新增 `tests/quiz-session.test.cjs` 回歸：familiarity adapter throw 不阻止 history 寫入；history adapter throw 不阻止 familiarity 寫入；兩者均顯示部分持久化警告。
[x] AMQ-533 更新 `ARCHITECTURE.md`、`DATA_CONTRACT.md`、主清單、工作狀態、開工指引、下一輪提示詞與 Batch 47 handoff。
[x] AMQ-534 完成全量 Node、tooling、architecture、source audit、mapper、benchmark、syntax 驗證。
[x] AMQ-535 更新 manifest、完整 ZIP 並驗證 CRC／逐項 SHA-256。
[x] AMQ-536（Batch 50–53 完成可執行範圍）自訂清單／看番狀態 store、UI、source-aware 成員與保存失敗提示已接線；收藏身份及真實瀏覽器驗收另列阻塞。
[!] AMQ-537 真實瀏覽器／音源 E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞／未驗收。

下一批 Batch 48：檢查剩餘必要功能與錯誤／生命週期契約，優先追查 session startRound 的歷史初始化失敗是否會被後續音訊載入訊息覆蓋，以及跨模式切換時的狀態通知順序。只修正有回歸證據的缺陷。


## 2026-10-27 Batch 48：QuizSession 持久化警告生命週期

[x] AMQ-538 重現 `historyStore.beginRound()` throw 後警告被 `nextQuestion()` 音訊載入訊息覆蓋的問題。
[x] AMQ-539 在 QuizSession 新增獨立 `persistenceWarning` 狀態欄位，與回合／音訊 `message` 分離；新回合重設上一回合警告。
[x] AMQ-540 更新 quiz panel，將 persistence warning 與設定警告一併投影到操作訊息，不被 `playing` 等事件覆蓋。
[x] AMQ-541 新增 quiz-session 與 quiz-panel integration 回歸，確認 history 初始化失敗在音訊播放後仍可見。
[x] AMQ-542 核對 mode-switch lifecycle：現有 source-runtime／data-pipeline integration 覆蓋舊請求取消與新請求優先，quiz-panel integration 覆蓋 session dispose、失敗狀態與 AMQ／EMQ 隔離；未發現可證實的額外競態，未擴大重寫。
[x] AMQ-543 完成全量 Node、tooling、architecture、source audit、mapper、benchmark、syntax 驗證。
[x] AMQ-544 更新清單、狀態、handoff、manifest 與完整 ZIP。
[x] AMQ-545（Batch 50–53 完成可執行範圍）自訂清單／看番狀態 store、UI、出題池過濾及 persistence warning 已完成 Node 驗證；收藏身份、舊版完整相容與瀏覽器驗收另列阻塞。
[!] AMQ-546 真實瀏覽器 E2E／音源仍未驗收，頁面導覽受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞。

下一批 Batch 49：盤點剩餘必要功能與最終核心結案條件；避免持續擴張小修小補，優先決定哪些工作能在現有證據下結案、哪些因外部環境或缺失參考檔明確阻塞，再執行最後一批可驗證修正。


## 2026-10-27 Batch 49：核心結案盤點與主清單校正

[x] AMQ-547 將早期已完成但仍留在待處理狀態的核心任務（資料 mapping、出題規則、音訊服務、查詢／分頁、持久化、回歸）依目前測試證據校正狀態。
[x] AMQ-548 修正過時阻塞描述：資料來源已進入工作包、query UI 已接線、EMQ SRS 已 source-aware；保留真實瀏覽器／舊版相容的實際阻塞。
[x] AMQ-549 清除主清單重複 task ID，確保 546 個既有 task ID 各自唯一。
[x] AMQ-550 更新 `PRODUCT_CORE_CONTRACT.md`、`FUNCTION_INVENTORY.md`，明確標記 PC-01 至 PC-09 的新版實作、舊版相容與瀏覽器驗收界線。
[x] AMQ-551 新增 `docs/FINAL_GAP_ASSESSMENT_BATCH49.md`，集中記錄已完成核心、最近完整測試證據、未實作功能、外部阻塞與解除條件。
[x] AMQ-552 更新 WORK_STATUS、開工指引、下一輪提示詞與 Batch 49 handoff，避免下一個 AI 重複審計或無限重構。
[x] AMQ-553 完成最後一輪全量 Node、tooling、architecture、source audit、mapper、benchmark、syntax、manifest／ZIP 驗證。
[x] AMQ-554（Batch 51 更新）Candidate381 靜態線索已轉成新版清單／看番狀態 UI 與鍵盤列選取安全子集；收藏身份未證實，真實瀏覽器驗收仍受環境阻擋。
[!] AMQ-555 真實瀏覽器／音源／乾淨 Windows 啟動驗收仍受環境限制；不得以 Node／mock 測試代替。

**下一步不是自動開新重構批次。** 先取得可讀參考檔或明確批准新版獨立 CRUD／鍵盤操作契約，並提供可用的瀏覽器驗收環境；否則保留阻塞，避免猜測相容性。


## 2026-10-27 Batch 50：參考檔解讀與個人清單持久化契約

[x] AMQ-556 唯讀核對使用者新上傳的 `AMQ382(2).html`：1,611,096 bytes，SHA-256 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`；title／`data-amq-candidate` 顯示 Candidate381，未升格為 Candidate382 Stage 0。
[x] AMQ-557 盤點自訂清單 key／payload／CRUD：`aniCustomPracticeListsV1`、`aniCustomPracticeListsRecoveryV825`、作品 ID 字串化與去重、80 字元名稱、重複名稱拒絕、刪除清單不刪作品／學習資料。
[x] AMQ-558 盤點看番狀態 key／狀態：`aniAnimeWatch_v1`，`current`／`completed`／`paused`／`dropped`／`planning`／`repeating`，`none` 代表移除。
[x] AMQ-559 新增 `src/persistence/personal-library-store.js`，實作清單 create／rename／delete／membership 與看番狀態 persistence API、錯誤狀態、損壞資料隔離、跨分頁 storage event、訂閱與 dispose。
[x] AMQ-560 新增 `tests/personal-library-store.test.cjs`，9/9 個測試情境 PASS，涵蓋 legacy payload、CRUD、去重、失敗原子性、隔離與外部更新。
[x] AMQ-561 將 persistence 模組加入 `src/index.html`、`tests/tests.html` 與架構載入順序檢查。
[x] AMQ-562 新增 `docs/PERSONAL_LIBRARY_CONTRACT_BATCH50.md`，記錄靜態證據、資料契約與不確定範圍。
[x] AMQ-563（由 Batch 51 完成 UI 接線）新版 UI 已接線清單／看番狀態 CRUD；`aniFavorites_v1` 身份仍不明，維持不寫入。
[x] AMQ-564（由 Batch 51 完成安全子集）新版曲庫已有單一列選取 owner；Enter 僅選取，因無 canonical playback owner 不執行播放。真實瀏覽器驗收仍 BLOCKED。
[!] AMQ-565 真實瀏覽器、responsive、鍵盤與真實音訊驗收仍 BLOCKED（既有 `ERR_BLOCKED_BY_ADMINISTRATOR`）；不重試同一導覽方式。
[x] AMQ-566 完成 Batch 50 全量 Node 回歸：25/25 test scripts exit 0；tooling 8/8 PASS。
[x] AMQ-567 完成 Batch 50 architecture／source audit／mapper／benchmark／syntax：459/0、來源稽核 PASS、55,660 筆 mapper PASS、5 次 benchmark PASS、全部 JS/CJS syntax PASS。
[x] AMQ-568 更新工作狀態、契約、handoff、下一輪提示詞，並完成 MANIFEST／ZIP 驗證（結果見 Batch 50 交付回報）。

Batch 51 已完成；其時規劃的 Batch 52 已由後續紀錄完成。Batch 52 交付見本清單末端。Batch 53 也已完成 persistence failure UI 投影；最新交付見本清單末端。下一批 Batch 54：依必要功能真相表核對 P1，並加強 AudioService／QuizSession／mode-switch 跨模組回歸。


## 2026-10-27 Batch 51：個人清單 UI 與曲庫列選取

[x] AMQ-569 將 `personal-library-store.js` 接入曲庫瀏覽 UI，實作建立／改名／刪除自訂清單、作品成員新增／移除與看番狀態修改。
[x] AMQ-570 擴充 app settings schemaVersion 1 的 `customListId`，舊設定讀取相容並驗證新欄位型別。
[x] AMQ-571 刪除目前選取清單時清理新版設定的清單 ID；跨 key 寫入失敗時回報部分成功，保留作品及學習資料。
[x] AMQ-572 為曲庫列建立單一選取 owner，點擊與 Enter 僅選取、方向鍵移動可見結果列；無 playback owner 時不假裝播放。
[x] AMQ-573 加入鍵盤列焦點的 interactive target 排除邏輯，避免輸入／textarea／select／button／contenteditable 被列快捷鍵攔截。
[x] AMQ-574 擴充 `tests/catalog-browser.integration.test.cjs`，驗證清單 CRUD、成員新增移除、看番狀態、刪除清單後設定參照清理、鍵盤選取與 Enter 語義。
[x] AMQ-575 更新 `tests/app-settings-store.test.cjs`，驗證 `customListId` 保存、恢復及非法型別拒絕。
[x] AMQ-576 更新 `src/index.html`、`tests/tests.html` 與 `src/styles.css`，加入功能性個人清單操作區與選取列 focus/selected 狀態，未進行整體視覺重構。
[x] AMQ-577 更新架構、產品核心契約、功能真相表、驗收規則與工作狀態，明確區分清單管理與出題池整合。
[x] AMQ-578 所有 `tests/*.test.cjs` 腳本退出碼 0；tooling 8/8 PASS。
[x] AMQ-579 Architecture／source audit／mapper／benchmark／syntax／manifest／ZIP 已在 Batch 51 最終驗證完成，結果見 `docs/HANDOFF_BATCH51.md`。
[!] AMQ-580 真實瀏覽器 UI／響應式／鍵盤與真實音訊仍 BLOCKED／未驗收；既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一方式。
[x] AMQ-581（Batch 52 完成）清單已使用 source-aware workRefs 接入猜歌出題池；AMQ／EMQ 同數字作品 ID 不跨來源匹配。

上述 Batch 52 規劃已完成；Batch 53 persistence write failure／recovery UI 也已由後續交付紀錄完成。下一批 Batch 54：依必要功能真相表處理 P1 並補音訊／session 回歸；不得宣稱 Candidate302／Candidate382 Stage 0 相容。


## 2026-10-27 Batch 52：來源明確清單與猜歌出題池整合

[x] AMQ-582 為個人清單增加 source-aware `workRefs` schema，保留 legacy `animeIds` 並拒絕非法 source/id。
[x] AMQ-583 新增 `setWorkMembership`／`hasWorkMembership`／`getWorkRefs`，確保 AMQ 與 EMQ 相同作品 ID 可分開保存。
[x] AMQ-584 新增 source-aware 看番狀態 API，舊 source-less watch entries 不會被自動合併至 AMQ／EMQ。
[x] AMQ-585 將曲庫 UI 的加入／移除清單及看番狀態操作切換到 source-aware work ref。
[x] AMQ-586 更新清單 UI 成員數與狀態，清楚呈現未標記來源的 legacy 成員，不宣稱它們已遷移。
[x] AMQ-587 在 app lifecycle 共享個人清單與猜歌設定 store，避免同一分頁內不同 UI 各自持有不一致快照；dispose 後可重新 mount。
[x] AMQ-588 將 `customListId` 接入 QuizPanel eligibility predicate，依 `record.source + record.animeId` 過濾 AMQ／EMQ／MIX 題目池。
[x] AMQ-589 清單成員更新時刷新 session eligible pool，並對空清單與未解析 legacy membership 顯示可理解的錯誤提示。
[x] AMQ-590 新增 store 測試，驗證相同數字 work ID 在 AMQ／EMQ 中分離，membership 與 watch status 不互相覆蓋。
[x] AMQ-591 擴充 quiz panel integration，驗證選取清單、動態 membership、MIX source identity 及 legacy source-less 成員排除。
[x] AMQ-592 更新 DATA_CONTRACT、PERSONAL_LIBRARY_CONTRACT、ARCHITECTURE、PRODUCT_CORE_CONTRACT 與 FUNCTION_INVENTORY。
[x] AMQ-593 全量 Node test scripts：25/25 scripts exit 0；tooling 8/8 PASS。
[x] AMQ-594 Architecture 459 passed／0 failed；source audit、mapper verification、5 次 catalog benchmark 與所有 JS/CJS syntax check PASS。
[x] AMQ-595 更新 WORK_STATUS、開工提示詞、NEXT_SESSION_PROMPT 與 Batch 52 handoff；重建並驗證 MANIFEST／完整 ZIP。
[!] AMQ-596 真實瀏覽器、響應式、跨分頁 localStorage、真實音訊、乾淨 Windows 啟動與正式舊版相容性仍未驗收；保留環境阻塞。
[!] AMQ-597 `aniFavorites_v1` 的 ID 身份仍未證實，不實作收藏寫入。
[!] AMQ-598 舊 `animeIds` 缺少來源，不自動遷移；需要使用者明確確認或可信映射才能轉換。

[x] AMQ-599 個人清單 UI 顯示未標記來源的 legacy watch status 警告，不將它自動套用到 AMQ／EMQ 作品。
[x] AMQ-600 個人清單 UI 顯示看番狀態 persistence 的 read/write blocked 與 recovery 狀態，保留當次操作失敗訊息優先權。


## 2026-10-27 Batch 53：持久化錯誤 UI 投影與失敗文案回歸

[x] AMQ-601 修正個人清單 UI 的 `showLibraryResult`，保存失敗不再使用成功文案。
[x] AMQ-602 保留跨 store 部分成功的明確訊息：清單已建立但設定未保存、清單已刪除但設定參照未清除，都以 failureMessage 表示，不混入成功分支。
[x] AMQ-603 新增看番狀態寫入失敗 integration test，確認舊狀態保留且 UI 不顯示「已更新」。
[x] AMQ-604 QuizPanel 投影 familiarity AMQ／EMQ read-blocked 狀態，即使尚未提交答案也可見。
[x] AMQ-605 修正 SRS persistence warning 優先級，blocked／error／recoveryAvailable／persisted=false 時不再被舊的成功操作訊息遮蔽。
[x] AMQ-606 將 AMQ 黑名單 read/write/recovery 警告提升到一般猜歌狀態訊息，MIX 模式也能看到 AMQ 黑名單儲存問題。
[x] AMQ-607 擴充 QuizPanel integration，驗證 familiarity read failure、SRS 外部讀取失敗覆蓋舊成功文案及 MIX 黑名單讀取失敗提示。
[x] AMQ-608 全量 Node、tooling、architecture、source audit、mapper、benchmark、syntax、manifest／ZIP 驗證完成，詳見 Batch 53 handoff。
[!] AMQ-609 真實瀏覽器、跨分頁 localStorage、真實音訊與乾淨 Windows 啟動仍未驗收；既有瀏覽器導覽 `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試。

下一批 Batch 54：依必要功能真相表盤點尚可安全驗證的 P1 缺口，並強化 AudioService／QuizSession／mode-switch 的取消、fallback、pause/resume、計時起點與 dispose 回歸。


## 2026-10-27 Batch 54：必要功能真相表校正與音訊／Session 回歸

[x] AMQ-610 修正 `syncAppState()` 在 dataStatus 非 loaded 時重複呼叫 `disposeSession()` 的冗餘分支，保留單次 dispose owner。
[x] AMQ-611 擴充 AudioService + QuizSession integration：primary play rejection 後釋放舊媒體，backup 真正進入 playing 後才啟動單一倒數。
[x] AMQ-612 擴充 integration：canplay 後未進入 playing 時不啟動計時，dispose 後遲到 playing 事件不能發布舊 session 狀態。
[x] AMQ-613 擴充 QuizPanel mode-switch integration：切換模式後舊 AudioService 的遲到事件不能改寫新模式 questionStatus。
[x] AMQ-614 更新功能真相表與 PC-08 契約，清除「清單尚未接入出題池」「設定尚未持久化」「SRS UI 未接線」等已過時摘要。
[x] AMQ-615 全量 Node、tooling、architecture、source audit、mapper、benchmark、syntax 驗證完成。
[x] AMQ-616 更新 handoff、開工提示詞、工作狀態與 manifest／ZIP，確保下一批可直接接手。
[!] AMQ-617 真實瀏覽器、真實音訊、跨分頁 storage、乾淨 Windows 啟動與舊版相容性仍未驗收；既有瀏覽器導覽阻塞不重試。

下一批 Batch 55：完成剩餘核心契約盤點，優先釐清必要功能中仍有明確證據的未完成項；若只剩真實瀏覽器／基準檔案阻塞，記錄為 BLOCKED，不以猜測補功能，也不提前進行 UI／CSS 全面重構。


## 2026-10-27 Batch 55：剩餘核心契約與阻塞邊界盤點

[x] AMQ-618 核對 PC-01 至 PC-07：新版資料管線、曲庫查詢、模式、QuizEngine／QuizSession／AnswerEvaluator 與 AudioService 有 Node／integration evidence；真實瀏覽器與舊版完整規則另列未驗收。
[x] AMQ-619 校正 `FUNCTION_INVENTORY.md` 中 PC-03／PC-05／PC-06 的過時「尚未實作／規則未盤點」摘要，改以目前測試證據描述。
[x] AMQ-620 校正 `PRODUCT_CORE_CONTRACT.md`／`FUNCTION_INVENTORY.md` 對 PC-08／PC-09／PC-10 的狀態，清單、設定、SRS UI 已接線不再被描述為未實作。
[x] AMQ-621 將先前批次的可執行範圍標記為完成，將真實瀏覽器、收藏身份與舊版相容限制分開追蹤。
[x] AMQ-622 明確列出剩餘核心阻塞：瀏覽器 E2E、真實音訊可聽性、Candidate302／Candidate382 Stage 0 相容性、legacy source-less IDs 與 `aniFavorites_v1` 身份。
[x] AMQ-623 確認目前沒有可在缺少證據下安全新增的 P0/P1 產品功能；深色主題／背景 IndexedDB／多人／外部匯入仍屬 P2 或待確認，不擅自擴大範圍。
[x] AMQ-624 更新下一批提示詞、handoff、主清單與工作狀態；完整測試證據沿用 Batch 54 的最終執行結果，文件變更後重建／驗證 manifest／ZIP。
[!] AMQ-625 真實瀏覽器、真實音訊、正式基準相容性及乾淨 Windows 啟動仍需解除環境或檔案阻塞；不可用靜態／Node 測試取代。

Batch 55 結論：目前可在現有檔案與環境中安全完成的 P0/P1 核心程式工作已實作並通過 Node／整合驗證。下一步若沒有新的可操作瀏覽器環境或正式基準檔案，應優先處理可獨立驗收的剩餘核心回歸／文件一致性；不為了增加進度數字而猜測功能或提前做 UI／CSS 大重構。


## 2026-10-27 Batch 56：模式切換後舊 Catalog 失效化

[x] AMQ-626 檢查現有瀏覽器／基準證據與執行環境；未取得新可用瀏覽器驗收通道或正式 Candidate302／Candidate382 Stage 0 檔案，不重試已被阻擋的頁面導覽，也不搜尋 Candidate302。
[x] AMQ-627 重現並修正已載入後切換模式、但沒有活動請求時舊 catalog 仍殘留的 P1 狀態錯誤。
[x] AMQ-628 新增 Repository `invalidate()`，與只取消活動請求的 `cancel()` 分離；失效化時同步 reset generation、catalog 與 data status。
[x] AMQ-629 Runtime Bootstrap 在共享 state 的 mode 改變時呼叫 `invalidate()`，不自動重載，也不改變猜歌／音訊 owner。
[x] AMQ-630 新增 `tests/data-pipeline.integration.test.cjs` 回歸：AMQ 載入完成後切換 EMQ，舊 catalog 同步清除，EMQ 重載只包含 EMQ 記錄。
[x] AMQ-631 完成全量 Node scripts、tooling、architecture、source audit、mapper、benchmark、syntax 檢查；最終證據見 `docs/HANDOFF_BATCH56.md`。
[x] AMQ-632 更新架構／資料契約、工作狀態、開工提示詞、下一輪提示詞與本批 handoff。
[x] AMQ-633 重建 `MANIFEST.sha256` 與完整 ZIP，驗證 CRC、每個 manifest hash 與無額外檔案。
[!] AMQ-634 真實瀏覽器、真實音訊、跨分頁 storage、乾淨 Windows 啟動與正式舊版相容性仍未驗收；保留既有阻塞。


## 2026-10-27 Batch 57：Repository invalidate 與新一代載入競態回歸

[x] AMQ-635 檢查 Batch 56 後的主清單、handoff、Repository／load-state／runtime bootstrap 與現有 integration coverage；未取得新的正式基準證據。
[x] AMQ-636 新增回歸：mode switch invalidate 舊 AMQ 請求後立即啟動 EMQ 新請求，舊來源忽略 abort 並遲到完成時不得清除 EMQ 的 loaded 狀態或 Catalog。
[x] AMQ-637 驗證舊請求 cancellation 與新 generation 的 state／active request 隔離，保持 `cancel()`、`invalidate()` 的不同責任，不擴大實作範圍。
[x] AMQ-638 更新 Architecture／Data Contract，明確記錄 invalidate 後新一代載入的 stale completion／finally 清理邊界。
[x] AMQ-639 完成全量 Node scripts、tooling、architecture、source audit、mapper、benchmark 與 syntax 驗證，結果記於 `docs/HANDOFF_BATCH57.md`。
[x] AMQ-640 以 Chromium CLI 嘗試獨立真實瀏覽器驗收；程序未能在 25 秒內產生 DOM 輸出，stderr 顯示 DBus／zygote 問題，標記 BLOCKED，不宣稱 E2E 通過。
[x] AMQ-641 更新唯一主清單、WORK_STATUS、AI_START_HERE、NEXT_SESSION_PROMPT、handoff、manifest 與完整 ZIP。
[!] AMQ-642 真實瀏覽器、真實音訊、跨分頁 storage、乾淨 Windows 啟動與正式舊版相容性仍未驗收；Candidate302／Candidate382 Stage 0 與收藏／legacy ID 身份限制維持不變。

Batch 57 的狀態轉換回歸已由 Node integration 驗證。下一步先檢查是否有真正可用的新瀏覽器執行環境或正式基準檔；若沒有，避免重試已失敗的相同通道，不猜測收藏身份與 source-less IDs，也不提前進行 UI／CSS 大重構。

Batch 56 修正後，若新模式切換發生在載入完成之後，舊來源 Catalog 不會繼續留在共享資料狀態。下一批應優先檢查可驗證的核心狀態轉換與載入錯誤契約；不得把此修正擴大成自動重載或 UI 大改版。


## 2026-10-27 Batch 58：Repository 預先取消的 Adapter 邊界

[x] AMQ-643 新增回歸測試：外部 `AbortSignal` 在 `repository.load()` 呼叫前已 aborted 時，注入 Adapter 不得被呼叫，載入狀態回復 `not-loaded`，Catalog 保持空值。
[x] AMQ-644 修正 `src/data/repository.js`：在啟動注入 Adapter 前先處理已取消的 signal，避免不遵守 signal 的注入 Adapter 在取消後仍啟動副作用。
[x] AMQ-645 更新 Architecture／Data Contract，明確定義 pre-aborted signal 的 Repository 邊界與取消結果。
[x] AMQ-646 完成全量 Node scripts、tooling、architecture、source audit、mapper、benchmark、syntax 檢查；最終數字見 `docs/HANDOFF_BATCH58.md`。
[x] AMQ-647 更新唯一主清單、WORK_STATUS、開工提示詞、下一輪提示詞、README 與 handoff；重建並驗證 MANIFEST／完整 ZIP。
[!] AMQ-648 真實瀏覽器、真實音訊、跨分頁 storage、乾淨 Windows 啟動與正式舊版相容性仍未驗收；瀏覽器執行環境未出現新通道，不重試已失敗的相同啟動方式。

Batch 58 的取消契約由 Node integration 驗證。下一批先檢查是否有新的真實驗收環境／正式基準證據；若沒有，繼續有明確契約、尚未覆蓋的核心回歸，不猜測收藏身份或 source-less IDs，不提前進行 UI／CSS 大重構。


## 2026-10-27 Batch 59：共享 State 重入通知順序

[x] AMQ-649 新增核心回歸：listener 在收到 state snapshot 時同步呼叫 `update()`，驗證其他 listener 仍依提交順序收到原 snapshot 與後續 snapshot。
[x] AMQ-650 修正 `src/core/state.js`：使用 FIFO notification queue 序列化重入更新；每輪 listener 使用當輪不可變 snapshot，subscriber error diagnostic 也保存該 snapshot。
[x] AMQ-651 更新 `docs/ARCHITECTURE.md` 與 `docs/DATA_CONTRACT.md`，記錄 state reentrancy、FIFO 通知及診斷快照契約。
[x] AMQ-652 執行全部 `tests/*.test.cjs`，25/25 scripts exit 0；`tests/core.test.cjs` 78/78 PASS。
[x] AMQ-653 執行 `node --test tests/tooling.test.cjs` 8/8 PASS；`node tools/check-architecture.cjs` 459 passed／0 failed。
[x] AMQ-654 執行 source audit、全量 mapper、5 次 catalog benchmark 與 63 個 JS/CJS 語法檢查，全部 PASS；來源雜湊保持不變。
[x] AMQ-655 更新唯一主清單、WORK_STATUS、handoff、AI_START_HERE、NEXT_SESSION_PROMPT、README；重建並驗證 MANIFEST／完整 ZIP。
[!] AMQ-656 真實瀏覽器 UI／響應式／鍵盤／跨分頁 storage、真實音訊、乾淨 Windows 啟動及正式舊版相容性仍未驗收；本批未重試已知失敗的相同 Chromium 導覽方式。

Batch 59 修正的是共享 State 通知中的重入順序錯誤，不涉及產品規則或視覺重構。Node 回歸證明內部訂閱者會依提交順序收到各自 snapshot；真實瀏覽器與產品驗收限制維持原狀。下一批優先繼續檢查有明確契約且可用測試驗證的核心整合缺口。


## 2026-10-27 Batch 60：Lifecycle timer 取消與 dispose 競態

[x] AMQ-657 新增回歸：scope dispose 後，即使 interval callback 已被 host 排入佇列，也不得執行 handler。
[x] AMQ-658 新增回歸：個別取消 timeout／interval 後，已排入佇列的遲到 callback 不得執行 handler。
[x] AMQ-659 修正 `src/core/lifecycle.js`：timeout／interval 各自維護 active guard，並同時檢查 scope disposal；清除 timer 不再是唯一保護。
[x] AMQ-660 更新 Architecture／Data Contract，明確記錄 timer callback invocation-time cancellation contract。
[x] AMQ-661 完成全量 Node test scripts、tooling、architecture、source audit、mapper、benchmark 與 syntax 驗證；結果見 `docs/HANDOFF_BATCH60.md`。
[x] AMQ-662 核對 AMQ／EMQ 來源 SHA-256，維持資料資產未修改。
[x] AMQ-663 更新唯一主清單、WORK_STATUS、handoff、AI_START_HERE、NEXT_SESSION_PROMPT、README；重建並逐項驗證 MANIFEST／完整 ZIP。
[!] AMQ-664 真實瀏覽器 UI／響應式／鍵盤／跨分頁 storage、真實音訊、乾淨 Windows 啟動及正式舊版相容性仍未驗收；沒有新的驗收環境，不重試既有失敗的 Chromium 導覽方式。

Batch 60 的新增回歸先在舊實作上重現兩項取消失效（核心測試 79/81），修正後核心測試 81/81 PASS。下一批 Batch 61 優先檢查仍有明確契約的 lifecycle／runtime 跨模組邊界；如果沒有新瀏覽器或正式基準證據，不猜測收藏身份、legacy source-less IDs 或 P2 行為，UI／CSS 大重構仍排最後。


## 2026-10-27 Batch 61：Runtime dispose 同步失效化

[x] AMQ-665 新增整合回歸：已載入 Catalog 後 dispose runtime，驗證共享 `dataStatus` 同步回到 `not-loaded`、Catalog 變成 `null`。
[x] AMQ-666 新增整合回歸：載入進行中 dispose runtime，驗證 Promise 尚未 settle 前就清除 loading 狀態，且非合作來源遲到完成不能重新發布。
[x] AMQ-667 修正 `src/data/runtime-bootstrap.js`：dispose 優先呼叫 `repository.invalidate()`，僅在缺少此 API 時退回 `cancel()`。
[x] AMQ-668 更新 Architecture／Data Contract，定義 runtime dispose 的 Catalog 所有權、同步狀態重設與遲到來源保護。
[x] AMQ-669 完成全部 `tests/*.test.cjs`（25/25 scripts exit 0）、data-pipeline integration（35/35）、tooling（8/8）、architecture（459/0）、source audit、mapper、5 次 benchmark 與 63 個 JS/CJS 語法檢查；證據見 `docs/HANDOFF_BATCH61.md`。
[x] AMQ-670 核對 `data.js` 與 `emq-data.js` SHA-256 未變，正式基準與來源資料未修改。
[x] AMQ-671 更新唯一主清單、WORK_STATUS、handoff、AI_START_HERE、NEXT_SESSION_PROMPT、README；重建並逐項驗證 Manifest 與完整 ZIP。
[!] AMQ-672 真實瀏覽器重新掛載、音訊、跨分頁 storage、乾淨 Windows 啟動與正式舊版相容性仍未驗收；無新環境時不重試已知失敗的 Chromium 導覽方式。

Batch 61 先在舊實作上重現兩個 dispose 狀態錯誤（data-pipeline integration 18/20），修正後 35/35 PASS。下一批 Batch 62 優先檢查重新掛載／runtime 組裝中有明確契約的跨模組缺口；不猜測收藏身份、legacy source-less IDs 或 P2 行為，UI／CSS 大重構仍排最後。


## 2026-10-27 Batch 62：App mount 失敗回滾與重試

[x] AMQ-673 新增 `tests/app-lifecycle.integration.test.cjs`：驗證正常 mount／dispose／remount 不重複註冊 mode click handlers，且各資源被釋放。
[x] AMQ-674 新增回歸：Catalog Browser mount 拋錯時，驗證舊實作會殘留 3 個 mode listener，並阻止後續 mount 重試。
[x] AMQ-675 修正 `src/app.js`：mount 初始化包在 rollback 邊界內；例外時 dispose 已註冊 scope 資源、清除 scope／模組參照，保留原始錯誤向外拋出。
[x] AMQ-676 更新 Architecture／Data Contract，記錄已註冊資源 rollback、可重試語義及模組自有未註冊資源的責任。
[x] AMQ-677 完成全部 `tests/*.test.cjs`（26/26 scripts exit 0）、app lifecycle integration（2/2）、data-pipeline integration（35/35）、tooling（8/8）、architecture（466/0）、source audit、mapper、5 次 benchmark 與 64 個 JS/CJS 語法檢查；詳見 `docs/HANDOFF_BATCH62.md`。
[x] AMQ-678 核對來源資料 SHA-256 未變，正式基準與資料資產未修改。
[x] AMQ-679 更新唯一主清單、WORK_STATUS、handoff、AI_START_HERE、NEXT_SESSION_PROMPT、README；重建並逐項驗證 Manifest／完整 ZIP。
[!] AMQ-680 真實瀏覽器 mount／dispose／remount、音訊、跨分頁 storage、乾淨 Windows 啟動與正式舊版相容性仍未驗收；VM/fake DOM 測試不取代瀏覽器驗收。

Batch 62 先以 VM／fake DOM 測試重現 app mount 部分失敗後 listener 殘留（新測試失敗：3 個 click listener 未清除），修正後兩個 lifecycle integration 案例 PASS。下一批 Batch 63 先盤點目前尚可在現有環境可靠驗證的 P0/P1 缺口；若沒有新證據，不為了增加批次而重構穩定模組，並評估核心階段可否明確結案、把環境阻塞移交 UI／最終驗收階段。


## 2026-10-27 Batch 63：核心工程範圍結案評估與阻塞分類校正

[x] AMQ-681 依最新主清單、`PRODUCT_CORE_CONTRACT.md`、程式碼與 Batch 56–62 測試證據重新盤點可執行 P0/P1；沒有發現另一項有充分證據且不依賴瀏覽器／缺失基準／未知資料身份的核心程式缺陷。
[x] AMQ-682 更新 `docs/FUNCTION_INVENTORY.md`，修正 FUNC-001 至 FUNC-010 對已實作模式、曲庫、搜尋、鍵盤選取、清單／看番、SRS 與猜歌核心的過時狀態，保留舊版相容與瀏覽器驗收限制。
[x] AMQ-683 更新 `docs/FINAL_GAP_ASSESSMENT_BATCH49.md`，以 Batch 62 最新測試證據覆蓋舊數字，修正早期「清單／鍵盤未實作」描述，分開記錄核心程式完成度與產品最終驗收。
[x] AMQ-684 明確記錄核心工程可執行範圍暫時結案；後續只有新證據指出具體 P0/P1 缺陷才繼續核心改碼，不為增加批次反覆重構穩定模組。
[x] AMQ-685 分類剩餘阻塞：真實瀏覽器／音訊／Windows、Candidate302／Candidate382 Stage 0、收藏身份／source-less IDs，以及階段 5 UI／CSS 視覺驗收；P2 主題／多人／外部匯入維持延後。
[x] AMQ-686 核對最新自動化證據沿用 Batch 62：26/26 Node scripts、app lifecycle integration 2/2、data pipeline 35/35、tooling 8/8、architecture 466/0、source audit／mapper／benchmark／64 個 JS/CJS syntax PASS。
[x] AMQ-687 更新唯一主清單、WORK_STATUS、handoff、AI_START_HERE、NEXT_SESSION_PROMPT、README；重建並逐項驗證 Manifest 與完整 ZIP。
[!] AMQ-688 整個產品仍未最終驗收：真實瀏覽器／音訊／Windows／正式舊版相容性與核准視覺基準尚未具備，需新的執行環境或可靠參考證據才能解除。

Batch 63 結論：目前可在現有環境中可靠實作與驗證的核心工程範圍暫時結案，但整個 AMQ 產品重建並未結案。下一步不再無目標擴張核心重構；先取得可用的真實瀏覽器驗收通道與階段 5 所需視覺基準，再進行 UI／CSS 重構及最終驗收。


## 2026-10-27 Batch 64：使用者實機驗收與必要功能回歸確認

[x] AMQ-689 記錄使用者實機回報：啟動、畫面、AMQ／EMQ／MIX、模式切換、答題／下一題、搜尋／篩選／排序及測試資料保存均回報可用；此為使用者手動回報，不冒充 AI 自行重現。
[x] AMQ-690 將部分曲目播放失敗與 `AUDIO_ALL_CANDIDATES_FAILED` 記錄為真實音訊待診斷，不直接歸因於來源失效；下一批需收集失敗曲目／候選來源／播放錯誤證據。
[x] AMQ-691 核對目前猜歌 UI，確認缺少答案建議 dropdown/listbox、建議生成與鍵盤選項導覽接線；既有 Candidate381 靜態參考含 `quizSuggestions`、`buildSuggestions()`、方向鍵／Enter／Escape 與 IME 防護線索。
[x] AMQ-692 Batch 65 已恢復猜歌答案建議下拉選單與鍵盤互動；8/8 module tests、QuizPanel integration PASS.
[!] AMQ-693 收藏操作 UI 目前不可見／未提供；`aniFavorites_v1` 身份和資料 ID 語義仍未知，禁止猜測舊 key 寫入或自動遷移。
[x] AMQ-694 Batch 65 已補上音訊失敗診斷與使用者回報資訊：MediaError code 可用時區分媒體中止、network（可能含網路／跨域限制）、decode、unsupported source，並保留 play-rejected／timeout／未分類 media-error；真實根因仍需實機驗收。
[~] AMQ-695 答案 dropdown 鍵盤／IME 功能與測試已補齊；使用者仍未重新驗收真實瀏覽器鍵盤行為、響應式尺寸與真實音訊根因。
[x] AMQ-696 更新 WORK_STATUS、AI_START_HERE、NEXT_SESSION_PROMPT、README 與本批 handoff；本批不改程式碼，沒有把使用者回報標記成自動化測試。
[!] AMQ-697 產品整體仍未最終驗收；正式 Candidate302／Candidate382 Stage 0 相容性、舊收藏身份、source-less IDs、完整響應式與階段 5 UI／CSS 視覺驗收仍待解除阻塞。

Batch 64 使用者實機回報確認基本啟動與主要猜歌流程可用，但發現答案建議下拉選單這項重要互動缺失。Batch 65 優先恢復該功能及鍵盤行為測試；音訊部分失敗另做診斷，不猜收藏資料身份，也不提前進行全面 UI／CSS 改版。


## Batch 65：恢復答案建議與 EMQ 音源候選（2026-10-27）

[x] AMQ-698 依使用者提供的 Candidate381 靜態參考，核對 V82.54／V82.55 音訊邏輯：Catbox direct mirror、Asia CDN 優先、WebA 同 UUID WebM sibling fallback；不升格為正式基準。
[x] AMQ-699 更新 `src/data/audio-candidates.js`，以固定順序建立去重 EMQ candidates，保留原始 URL 並只對已觀察格式轉換。
[x] AMQ-700 新增 EMQ userup／WebA／WebM 與 Catbox 回歸測試；`tests/audio-candidates.test.cjs` 7/7 PASS。
[x] AMQ-701 新增 `src/ui/answer-suggestions.js`，實作可存取 combobox/listbox、最多 25 個建議、穩定排序、NFKC／大小寫／空白／特殊分隔符搜尋、點選及鍵盤選取。
[x] AMQ-702 恢復答案建議 ArrowUp／ArrowDown、Enter 選取而不提交、Escape 關閉與 IME composition 防護；`tests/answer-suggestions.test.cjs` 8/8 PASS。
[x] AMQ-703 將建議 UI 接入 `src/index.html`、`src/ui/quiz-panel.js`、`src/styles.css`；`tests/quiz-panel.test.cjs` 驗證 Catalog 建議、Enter 不提交與 controller lifecycle。
[x] AMQ-704 將 `QuizSession` 的候選失敗摘要與錯誤資訊暴露為唯讀 state，AudioService 依 `HTMLMediaElement.error.code` 區分網路、解碼、不支援格式及中止；QuizPanel 以歌曲來源／ID、候選來源／失敗類型呈現 `AUDIO_ALL_CANDIDATES_FAILED` 詳情，不將 media error 武斷標為 CORS。
[x] AMQ-705 唯讀統計 EMQ 音源：16,839 首歌曲、16,877 個非空 URL、13,648 個 userup URL、7,909 個 WebA URL、3,208 個 Catbox URL、21 個其他 URL；來源資產未修改。
[x] AMQ-706 執行全部 `tests/*.test.cjs` 27/27 scripts exit 0；`node --test tests/tooling.test.cjs` 8/8 PASS。
[x] AMQ-707 執行 `node tools/check-architecture.cjs`：480 passed／0 failed；source audit、mapper verifier、5 次 catalog benchmark 與 src/tests/tools JS/CJS syntax 全部 PASS。
[!] AMQ-708 真實瀏覽器與實際音訊可聽性仍 BLOCKED；目前證據只證明候選轉換與錯誤投影的內部契約，不代表所有 EMQ 歌曲已可播放。
[~] AMQ-709 請使用者重新驗收 EMQ 音訊及答案下拉選單：優先抽測 EMQ userup `.weba`、Catbox、答案建議鍵盤與中文輸入法；若音訊仍失敗，回報曲目／來源與畫面顯示的候選失敗詳情。
[!] AMQ-710 收藏 UI 仍未提供；`aniFavorites_v1` 身份與 source-less legacy IDs 仍未知，未猜測或遷移。

Batch 65 完成必要功能修復與 Node 回歸，但沒有新的真實瀏覽器通道，未宣稱產品端到端驗收完成。下一步以使用者實機重新驗收為主；若仍有 EMQ 失敗，利用顯示的來源／失敗類型定位，不重複泛化猜測。


## 2026-10-27 Batch 66：使用者回報失敗後的定點 UI 修正與音訊根因界線

[x] AMQ-711 記錄使用者實機驗收：Batch 65 的答案下拉選單仍不可用；EMQ 音訊仍失敗。不得把 Batch 65 的 Node/fake DOM PASS 當成實機驗收通過。
[x] AMQ-712 分析音訊控制台證據：原始 `erogemusicquiz.com` userup MP3 回應 HTTP 500；`.weba` 出現 OpaqueResponseBlocking。此證據支持原始來源回應／瀏覽器阻擋問題，但不能單獨證明 CORS，也不能證明新增獨立代理是必要解法。
[x] AMQ-713 核對音訊候選責任邊界：目前實作是依 Candidate381 靜態線索轉換 CDN／Catbox URL，不是自建伺服器代理；補上 userup MP3 Asia CDN 優先順序回歸測試，未盲目增加候選規則。
[x] AMQ-714 修正 `src/ui/quiz-panel.js`：由同一個 `answer-suggestions` controller 模組分別管理單一答案欄位與「全部三項」的作品／歌手／歌曲名稱欄位，按目標類型取得 Catalog 建議，並在有題目的 ready／playing／paused 狀態啟用，不再錯誤要求音訊已開始播放。
[x] AMQ-715 修正 `src/index.html`：為「全部三項」的三個輸入欄位提供各自 listbox，沿用同一套 controller，不複製搜尋／鍵盤邏輯。
[x] AMQ-716 修正 `src/styles.css`：明確讓 `#quiz-single-answer-label[hidden]` 使用 `display:none`，避免 ID selector 的 `display:grid` 覆蓋瀏覽器的 hidden 呈現；未使用 `!important`。
[x] AMQ-717 更新 `tests/quiz-panel.test.cjs`：覆蓋全部三項模式三個欄位的建議接線與單一答案 wrapper hidden 狀態；更新 `tests/audio-candidates.test.cjs`，覆蓋 userup MP3 的 Asia CDN 候選先於原始 URL。
[x] AMQ-718 完成全部 `tests/*.test.cjs` 27/27 scripts exit 0；答案建議 8/8、QuizPanel integration PASS、音訊候選 8/8、AudioService 13 個情境 PASS、tooling 8/8、architecture 480/0、source audit／mapper／benchmark PASS。
[x] AMQ-719 更新工作狀態、唯一主清單、handoff、開工提示詞及下一工作提示；重建 Manifest／ZIP 並驗證完整性與所有檔案雜湊。
[!] AMQ-720 真實瀏覽器中答案建議是否恢復、EMQ CDN 是否可實際播放仍待使用者驗收；HTTP 500／ORB 的具體伺服器端原因仍未知。不得新增無證據的 proxy server，不得宣稱本批已通過實機驗收。

Batch 66 僅修正可從程式碼證據確認的 UI／接線缺口，沒有加入全域事件攔截、函式覆寫或 CSS `!important` 補丁。下一批先以本批 ZIP 的使用者實機回報為準；音訊若仍失敗，使用 QuizPanel 顯示的候選 source／reason 確認 Asia CDN 是否實際被嘗試，再決定是否需要基於證據調整。

## 2026-10-27 Batch 67：答案建議互動穩定性、換題清空與音訊診斷粒度

[x] AMQ-721 使用者實機回報確認下拉選單已出現，但方向鍵選取會回到第一項、滑鼠點選不能一次完成；答案欄閃爍且換題後可能殘留錯誤答案。將這些記錄為產品功能缺陷，非純視覺問題。
[x] AMQ-722 修正 `src/ui/answer-suggestions.js`：一般 `render()` 呼叫不再重建未變更的 listbox DOM；保留方向鍵索引及 option 節點，避免定時器／音訊狀態更新重設選項、滑鼠 pointerdown 到 click 期間目標被替換。
[x] AMQ-723 修正 autocomplete refresh 契約：只有輸入內容改變／IME composition 結束才強制重算；一般 render 不會重開已由 Escape、點選或選取關閉的建議清單，避免選單與答案欄高頻閃動。
[x] AMQ-724 修正 `src/ui/quiz-panel.js`：新題目物件首次進入 UI 時清空單一答案與「全部三項」的四個答案輸入欄，並關閉舊題建議；不在同一題每次 render 時清空正在輸入的答案。
[x] AMQ-725 新增 autocomplete regression：連續多次 render 後 ArrowDown 仍逐項移動、option DOM identity 保持、滑鼠單擊即選取且不需再按 Enter、清單關閉後一般 render 不重新開啟；`tests/answer-suggestions.test.cjs` 9/9 PASS。
[x] AMQ-726 新增 QuizPanel 換題回歸：模擬錯誤答案及舊答案殘留，換到新題時單一欄與三個 all-target 欄皆清空；`tests/quiz-panel.test.cjs` PASS。
[x] AMQ-727 唯讀核對 EMQ 歌曲 ID `2000042847`：曲名 `Karera Rashisa`，原始資料只有一個 userup WebA URL；現有候選 resolver 對該 URL 產生 4 個候選（Asia WebA、原始 WebA、Asia WebM、原始 WebM）。這是程式候選建構證據，不是網路可達性／真實播放證據。
[x] AMQ-728 擴充音訊失敗資料：`AudioService` 每個候選失敗項目加入檔案副檔名（不暴露含 query token 的完整 URL），QuizPanel 顯示候選索引、來源、格式與失敗原因；避免 Asia/original WebA/WebM 同 host 時只看來源無法辨認候選。
[x] AMQ-729 `tests/audio-candidates.test.cjs` 9/9、`tests/audio-service.test.cjs` 13 個情境 PASS、`tests/quiz-panel.test.cjs` PASS；全部 `tests/*.test.cjs` 已執行完畢且皆 exit 0；`node --test tests/tooling.test.cjs` 8/8 PASS；`node tools/check-architecture.cjs` 480 passed／0 failed；source audit／mapper verification PASS；修改檔案 `node --check` PASS。
[!] AMQ-730 5 次 Catalog benchmark 在本批全量命令執行期間超出工具執行時限，未取得新結果；來源資料與 benchmark 工具未修改，沿用 Batch 66 的 benchmark 結果，不宣稱本批重新通過。
[!] AMQ-731 真實瀏覽器中鍵盤／滑鼠／閃爍是否已完全改善，仍待使用者驗收；Node fake DOM 不是瀏覽器 E2E。
[!] AMQ-732 EMQ 真實音訊仍未修復／驗收。使用者錯誤只列出 `erogemusicquiz.com：播放請求遭拒`，但 ID `2000042847` 的目前程式候選 resolver 應建立 4 個候選；新版診斷將顯示索引與格式，以確認實際執行候選數量及 Asia CDN 是否真的被嘗試。HTTP 500／ORB 不能單獨證明 CORS 或代理服務必要性。

Batch 67 聚焦修正 autocomplete 狀態更新方式、換題答案生命週期與音訊診斷可辨識性；沒有新增 `!important`、全域事件攔截、重複覆寫函式或無證據音源 URL。下一步先由使用者驗收本批 ZIP；音訊依新顯示的候選索引／格式／失敗原因追查，不得將候選建構測試當作真實播放成功。


## 2026-10-27 Batch 68：恢復舊版答案建議匹配高亮與 EMQ 別名

[x] AMQ-733 以唯讀 `AMQ382(2).html`（Candidate381／V82.x）為參考，核對 `mapQuizSuggestionTextV824()`、`quizSuggestionHighlightRangesV824()`、`renderQuizSuggestionLabelV824()`、`buildSuggestions()` 的正規化、匹配區段與排序行為；未繼續搜尋 V48 或 Candidate302。
[x] AMQ-734 重整 `src/ui/answer-suggestions.js`：將候選匹配拆成可測試的 `buildMatchEntries()` 與相容的 `buildMatches()`；映射正規化字元至原始標籤區段，支援 raw／compact／separator match 高亮，使用安全 DOM text node／span，不把來源標籤當 HTML。
[x] AMQ-735 恢復已輸入匹配片段的視覺辨識：`.quiz-suggestion-match` 使用既有 accent 色及粗體；query 改變時即使候選集合相同也會刷新高亮，普通定時 render 不會重建 option DOM／重設鍵盤索引。
[x] AMQ-736 對照舊版 EMQ reader，`src/data/source-mappers.js` 從已存在的 `ta`／`n`、`aa`、`wa`／`wt`／`wn` 保留歌曲、歌手及作品別名；沒有來源資料的別名不推測生成。
[x] AMQ-737 更新 `src/data/validate.js` 與 `src/data/query-index.js`，驗證、索引搜尋及凍結 `artistAliases`／`animeAliases`，維持別名資料的唯讀快照契約。
[x] AMQ-738 新增／更新 `tests/answer-suggestions.test.cjs`、`tests/quiz-panel.test.cjs`、`tests/source-mappers.test.cjs`、`tests/query-index.test.cjs`，覆蓋高亮區間、選項文字安全、來源別名映射、別名搜尋及 all-target 建議來源。
[!] AMQ-739 舊版繁體中文名稱建議依賴專屬 Chinese Title API 與設定開關；新版目前未接入該 provider，本批不虛構資料或假裝已恢復完整中文別名。後續需取得／重建明確資料契約後再接入。
[!] AMQ-740 真實瀏覽器中的高亮顏色、IME、方向鍵／滑鼠與答案欄閃爍仍需使用者驗收；Node／fake DOM 僅為自動化證據。
[!] AMQ-741 真實音訊可聽性與候選失敗定位不在本批變更範圍，仍沿用 Batch 67 未驗收狀態。

Batch 68 不修改來源資產、正式基準或舊版 HTML；沒有增加 `!important`、全域事件攔截、重複覆寫函式或無證據代理／URL。

## 2026-10-27 Batch 69：答案建議匹配結構與相關度排序修正

[x] AMQ-742 確認 Batch 68 ZIP 實際存在且 SHA-256 為 `ca66c640257395cf5e24ae63e625bdd7c1347173d04fb574bdf30b38cd9fa376`；解壓至獨立 Batch 69 工作副本，未覆蓋既有 ZIP／正式基準。
[x] AMQ-743 重新讀取 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`PROJECT_RULES.md`、`WORK_STATUS.md`、`MASTER_CHECKLIST.md`、`ARCHITECTURE.md`、`ACCEPTANCE.md`、Batch 68 handoff 與下一工作提示。
[x] AMQ-744 以唯讀 Candidate381／V82.x `AMQ382(2).html` 確認舊版實際把空白、`/`、`-` 合併成 ` [\s/-]+ `，證實舊版這部分也有過度寬鬆行為；依使用者新確認的明確規格修正，不照搬該缺陷。
[x] AMQ-745 重寫 `src/ui/answer-suggestions.js` 的 query matcher：NFKC／大小寫正規化保留空白及標點原始結構，不再以 compact key 移除空白，不再將 `/`、`-`、`: ; ' . ,` 或特殊 Unicode 互相替換。
[x] AMQ-746 實作單向分隔符容錯：使用者輸入特定標點／特殊 Unicode 時，只允許該字元本身或一個空白作為對應位置；使用者輸入空白時只匹配空白，不把空白反向擴大成任意標點。
[x] AMQ-747 確保輸入 `A-B` 不會匹配 `A/B`／`A:B`；輸入 `A/B` 不會匹配 `A-B`；輸入 `A B` 不會匹配 `A-B`、`A/B`；輸入 `AB` 只匹配連續 `AB`，不移除候選中的空白或符號。
[x] AMQ-748 更新候選排序：原始正規化完全符合 → 字面開頭符合 → 分隔符容錯開頭符合 → 字面包含符合 → 分隔符容錯包含符合；各層內短名稱優先，再依正規化文字及原文穩定排序，最多 25 筆且去重。
[x] AMQ-749 保留原始標籤映射與安全 DOM 高亮；高亮範圍按實際匹配結果計算，保留候選原始顯示字串。
[x] AMQ-750 擴充 `tests/answer-suggestions.test.cjs`，新增標點各自空白容錯、標點互斥、空白不反向替換、連續 AB、不移除 Unicode、前綴／包含排序與分季名稱排序回歸。
[x] AMQ-751 答案建議測試 15 個情境 PASS；全部 27 個 `tests/*.test.cjs` 腳本 exit 0。
[x] AMQ-752 `node --test tests/tooling.test.cjs` 8/8 PASS；`node tools/check-architecture.cjs` 480 passed／0 failed。
[x] AMQ-753 source audit 與全量 mapper verification PASS：AMQ 38,821、EMQ 16,839、Catalog 55,660；5 次 benchmark PASS（本機 Node Catalog build 約 1,189.675 ms）。
[x] AMQ-754 `src/`、`tests/`、`tools/` 全部 JS/CJS 語法檢查 PASS；來源資產 SHA-256 維持 AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`、EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
[x] AMQ-755 更新本清單、WORK_STATUS、HANDOFF_BATCH69、AI_START_HERE、NEXT_SESSION_PROMPT、DATA_CONTRACT 與 FUNCTION_INVENTORY；重建 MANIFEST 並驗證完整 ZIP。
[!] AMQ-756 真實瀏覽器的候選顯示／高亮／IME／鍵盤操作仍待使用者驗收；Node／fake DOM PASS 不等於 E2E。真實音訊未改動且仍待獨立驗收。

Batch 69 對使用者明確指出的搜尋規格優先於舊版 V82.x 已確認的 separatorMatcher 缺陷。這次沒有修改曲庫來源、答案評分器、音訊候選或 CSS 大重構。


## 2026-10-27 Batch 70：舊版與新版功能差異盤點

> 本批完成的是差異盤點，不代表表內所有舊功能都必須復刻。每項舊版證據均為 Candidate381／V82.x 靜態線索；功能狀態與建議優先級見 `docs/FUNCTION_PARITY_AUDIT_BATCH70.md`。

[x] AMQ-757 完成差異盤點：舊版首頁／工作區導航。靜態證據已列於 GAP-023；新版入口範圍較窄。
[x] AMQ-758 完成差異盤點：探索新歌／未探索歌曲抽選。GAP-024：新版未實作。
[x] AMQ-759 完成差異盤點：弱點補強練習流程。GAP-025：只有 history/SRS 基礎，缺等價流程。
[x] AMQ-760 完成差異盤點：統計儀表板／學習進度。GAP-026：新版未實作儀表板。
[x] AMQ-761 完成差異盤點：作品圖鑑網格／列表／詳情。GAP-027：新版只有歌曲清單。
[x] AMQ-762 完成差異盤點：歌手圖鑑。GAP-028：新版未實作獨立頁。
[x] AMQ-763 完成差異盤點：年代／作品類型／收藏進度篩選。GAP-029：新版部分實作。
[x] AMQ-764 完成差異盤點：熟悉度／收藏進度 Catalog 篩選。GAP-030：新版 UI 不完整。
[x] AMQ-765 完成差異盤點：批次選取／批次套用。GAP-031：新版未實作。
[x] AMQ-766 完成差異盤點：自由聽歌播放器 Dock。GAP-032：新版未實作。
[x] AMQ-767 完成差異盤點：自由聽歌佇列與播放控制。GAP-033：新版未實作。
[x] AMQ-768 完成差異盤點：獨立播放器播放模式。GAP-034：新版未實作。
[x] AMQ-769 完成差異盤點：一般播放歷史。GAP-035：不得與答題歷史混為一談。
[x] AMQ-770 完成差異盤點：完整備份匯出／匯入還原。GAP-036：新版未實作。
[x] AMQ-771 完成差異盤點：資料庫更新／曲庫檔案匯入。GAP-037：只有 reload，不等於 update。
[x] AMQ-772 完成差異盤點：深色主題切換。GAP-038：新版未實作，延後至 UI 階段。
[x] AMQ-773 完成差異盤點：場景背景設定／IndexedDB。GAP-039：新版未實作，待確認。
[x] AMQ-774 完成差異盤點：AniList 匯入／授權。GAP-040：新版未實作／外部阻塞。
[x] AMQ-775 完成差異盤點：MAL 匯入／移除。GAP-040：新版未實作／外部阻塞。
[x] AMQ-776 完成差異盤點：VNDB 角色篩選。GAP-041：新版未實作。
[x] AMQ-777 完成差異盤點：VN 專用清單。GAP-041：只有通用 workKind 支援。
[x] AMQ-778 完成差異盤點：多人模式服務端。GAP-042：新版未實作／外部阻塞。
[x] AMQ-779 完成差異盤點：封面載入與快取。GAP-043：新版未實作。
[x] AMQ-780 完成差異盤點：播放器視覺化。GAP-044：新版未實作。
[x] AMQ-781 完成差異盤點：個人 profile／頭像。GAP-046：新版未實作。
[x] AMQ-782 完成差異盤點：使用者可編輯作品別名。GAP-045：僅有來源 mapper aliases。
[x] AMQ-783 完成差異盤點：集中設定搜尋。GAP-047：新版只提供部分猜歌設定。
[x] AMQ-784 完成差異盤點：獨立播放音訊診斷。GAP-048：猜歌 AudioService 有診斷，播放器缺失。
[x] AMQ-785 完成差異盤點：響應式與鍵盤操作真實驗收。GAP-049：仍待瀏覽器。
[x] AMQ-786 完成差異盤點：完整備份涵蓋全部新版 stores。GAP-050：待設計契約。
[x] AMQ-787 完成差異盤點：猜歌隨機 Sample。GAP-006：新版未實作。
[x] AMQ-788 完成差異盤點：猜歌片段起始位置。GAP-006：新版未實作。
[x] AMQ-789 完成差異盤點：季別篩選。GAP-007：新版未實作等價控制。
[x] AMQ-790 完成差異盤點：年份範圍／未知年份。GAP-007：新版未實作等價控制。
[x] AMQ-791 完成差異盤點：難度範圍。GAP-007：新版未實作等價控制。
[x] AMQ-792 完成差異盤點：看番狀態出題篩選。GAP-008：新版未實作等價控制。
[x] AMQ-793 完成差異盤點：只從看番清單出題。GAP-008：新版未實作等價控制。
[x] AMQ-794 完成差異盤點：歌曲標籤 CRUD。GAP-009／022：新版未實作。
[x] AMQ-795 完成差異盤點：中文作品標題 provider。GAP-011：新版未接入等價 provider。
[x] AMQ-796 完成差異盤點：答案別名 tooltip。GAP-012：新版未實作等價 UI。
[x] AMQ-797 完成差異盤點：完整題目資訊面板。GAP-012／014：新版僅部分 meta。
[x] AMQ-798 完成差異盤點：自動下一題延遲。GAP-013：需與自動播放分開核對。
[x] AMQ-799 完成差異盤點：收藏 UI。GAP-021：新版未實作。
[x] AMQ-800 完成差異盤點：舊收藏 ID／key 身份。GAP-021：阻塞，不得猜測遷移。
[x] AMQ-801 完成差異盤點：作品層級收藏／熟悉度進度。GAP-026／030：新版未實作等價呈現。
[x] AMQ-802 完成差異盤點：播放佇列持久化。GAP-033：新版未實作。
[x] AMQ-803 完成差異盤點：播放器音量／靜音／收合。GAP-032：新版未實作獨立 Dock。
[x] AMQ-804 完成差異盤點：匯入／還原 schema 版本驗證。GAP-036：實作前需定義。
[x] AMQ-805 完成差異盤點：曲庫更新版本／完整性檢查。GAP-037：實作前需定義。
[x] AMQ-806 完成差異盤點：外部服務權限／配額／錯誤契約。GAP-040／042：外部整合前置條件。
[x] AMQ-807 完成差異盤點：P0/P1/P2 範圍與 UI 延後原則。本批已分類；詳細證據見 parity audit。

### 本批結論
- [x] AMQ-808 已將差異分為新版已有、部分實作、未實作、阻塞、待驗收及 P2 延後。
- [x] AMQ-809 明確拆分收藏 UI 缺失與 `aniFavorites_v1` 身份未知，禁止猜測遷移。
- [x] AMQ-810 明確拆分自由聽歌播放歷史／佇列與猜歌答題歷史／question queue。
- [x] AMQ-811 確認差異盤點可結案，但必要功能完整性與真實產品驗收尚不可整體結案。
- [ ] AMQ-812 依 P0/P1 清單決定並補齊必要功能差異；不得自動把全部 P2 舊功能納入。
- [ ] AMQ-813 取得可用真實瀏覽器／音訊驗收通道，完成核心流程及答案建議實機回歸。
- [ ] AMQ-814 進入 UI 階段前整理已認可視覺基準與逐項替換驗收表。


## 2026-10-27 Batch 71：產品範圍與全域 SRS 設計

[x] AMQ-815 記錄使用者明確指定的新版功能納入／排除範圍，優先於 Batch 70 的待決定建議（`docs/PRODUCT_SCOPE_DECISIONS_BATCH71.md`）。
[x] AMQ-816 排除收藏功能與 `aniFavorites_v1` 遷移；不得再把收藏列為待實作需求。
[x] AMQ-817 將動畫作品圖鑑標為暫不做，保留類似 osu! 的歌曲選曲／曲庫列表。
[x] AMQ-818 排除歌手圖鑑。
[x] AMQ-819 排除獨立探索新歌模式；一般出題仍可抽取新歌曲。
[x] AMQ-820 排除獨立弱點補強模式，弱點分析併入全域 SRS。
[x] AMQ-821 排除歌曲標籤管理及其篩選／播放模式。
[x] AMQ-822 排除自由播放器待聽佇列，明確區分 QuizSession 題目佇列。
[x] AMQ-823 決定直接採用深色背景，不新增亮／暗主題切換。
[x] AMQ-824 明確規定 Batch 70 除上述排除項目外的其他差異均保留為待實作需求，依依賴／風險排序。
[x] AMQ-825 定義 SRS 是跨 AMQ／EMQ／MIX 及一般練習流程的共用能力，不再限定於獨立 SRS／弱點入口。
[x] AMQ-826 定義全域 SRS 開關啟用時的統計、排程、到期出題及自動評估行為。
[x] AMQ-827 定義 SRS 關閉時不參與選題、不更新 SRS 統計／排程，且保留既有 SRS 資料。
[x] AMQ-828 定義一般猜歌、熟悉度與答題歷史在 SRS 關閉時仍正常運作。
[x] AMQ-829 定義自動評估必須依可觀測答題訊號並產生可解釋的評級建議，不得把答對直接等同完全熟悉。
[x] AMQ-830 定義手動評級可以覆寫自動建議，且需記錄評級來源與覆寫原因。
[x] AMQ-831 定義自動評估規則必須版本化、deterministic、可獨立單元測試。
[x] AMQ-832 定義音訊失敗、回合取消、計時／資料錯誤不得當成使用者不熟悉的自動評級依據。
[x] AMQ-833 定義未知的提示／重播訊號不得假定為未使用，避免虛構 telemetry。
[x] AMQ-834 定義 SRS 出題必須先套用來源、模式、季別、年份、難度、看番、個人清單與黑名單等 eligibility filters。
[x] AMQ-835 定義 SRS 到期題、新題比例、近期表現、回合去重與有界 fallback 的選題需求。
[x] AMQ-836 定義 AMQ／EMQ source-aware SRS identity 不得因相同數字 ID 碰撞，MIX 不得建立第三份排程。
[x] AMQ-837 定義 SRS 統計由排程／歷史單一資料來源計算，不另維護互相矛盾的計數器。
[x] AMQ-838 定義資料備份／還原應涵蓋 SRS 開關、排程、評級來源與規則版本。
[x] AMQ-839 核對現有 FSRS scheduler、SRS store、手動評級 UI 與設定 store API，確認擴充點。
[x] AMQ-840 定義並測試 automatic assessment 初版評級決策表與時間門檻，先確認現有 scheduler rating 語義。
[x] AMQ-841 新增純函式 AssessmentEngine，不把評級門檻放在 UI handler。
[x] AMQ-842 將全域 SRS 開關接入既有 versioned settings store，避免建立第二個設定真相來源。
[x] AMQ-843 將自動評級、手動覆寫、來源／原因／規則版本持久化至既有 SRS store。
[x] AMQ-844 將全域 SRS selector 接入 AMQ／EMQ／MIX 與一般出題流程，保留既有 source weighting。
[x] AMQ-845 實作 SRS 關閉時的非 SRS fallback，驗證關閉不會清除排程資料。
[x] AMQ-846 實作 SRS 統計 projection，開啟時顯示、關閉時停止更新／隱藏。
[x] AMQ-847 補齊 automatic assessment、manual override、toggle、selector、identity、storage 失敗的單元與整合測試。
[x] AMQ-848 更新備份／還原 schema，覆蓋 SRS toggle、排程、assessment provenance 及規則版本。
[~] AMQ-849 依使用者已驗收的 P0 結果結案；不得僅因 AI 無法重跑真實瀏覽器而將整個 P0 保持阻塞。具體新發現的缺陷獨立追蹤。
[x] AMQ-850 以本批規格為依據進入下一個完整實作批次；先核對現有程式 API，再實作猜歌篩選／出題範圍與全域 SRS 的可測試切片。

歷史註記已由 Batch72–75 的實作與測試取代：AMQ-839 至 AMQ-848 已完成；後續 AMQ-901 至 AMQ-917 提供具體實作與回歸證據。


## Batch 72：作品標題四級自動評估
[x] AMQ-851 核對現有 FSRS 原生四級語義，確認保留 scheduler 公式，不新增第五級。
[x] AMQ-852 新增 DOM-free `assessment-engine.js`，評級門檻集中於純函式模組。
[x] AMQ-853 定案錯答／超時作品標題為 grade 1。
[x] AMQ-854 定案作品標題答對 0–10 秒（含 10 秒）為 grade 4。
[x] AMQ-855 定案作品標題答對超過 10 至 15 秒（含 15 秒）為 grade 3。
[x] AMQ-856 定案作品標題答對超過 15 秒為 grade 2。
[x] AMQ-857 確認歌名 `title` 不產生 SRS 評級。
[x] AMQ-858 確認歌手 `artist` 不產生 SRS 評級。
[x] AMQ-859 確認 `all` 目標只讀作品標題的 `correctByTarget.anime`。
[x] AMQ-860 缺少可靠計時資料時不猜測速度評級。
[x] AMQ-861 未作答揭曉／未播放跳過不自動評級。
[x] AMQ-862 自動評級規則使用版本號 `work-title-latency-v1`。
[x] AMQ-863 自動評級寫入既有 SRS store 的來源、規則版本與原因碼。
[x] AMQ-864 SRS 複習回合答題後自動套用四級評級。
[x] AMQ-865 加入同步 store subscriber 重入保護，避免自動評級重複執行。
[x] AMQ-866 手動覆寫自動評級時以原始卡片狀態重算，不重複增加 reps。
[x] AMQ-867 新增自動評估邊界與目標排除測試。
[x] AMQ-868 新增 SRS automatic/manual provenance 與覆寫不重複計數測試。
[x] AMQ-869 將全域 SRS 開關加入既有版本化設定 store。
[x] AMQ-870 全域開關關閉時阻止一般練習寫入 SRS 排程。
[x] AMQ-871 全域開關開啟時將一般 AMQ 練習接入自動評估。
[x] AMQ-872 全域開關開啟時將一般 EMQ 練習接入自動評估。
[x] AMQ-873 全域開關開啟時將 MIX 的來源感知評估接回 AMQ／EMQ schedule。
[x] AMQ-874 全域開關持久化後 reload 可還原設定。
[x] AMQ-875 全域開關關閉不刪除既有 SRS 資料。
[x] AMQ-876 全域開關關閉不影響一般猜歌、熟悉度及答題歷史。
[x] AMQ-877 SRS disabled 時不更新 SRS 統計與排程。
[x] AMQ-878 統計投影由現有 schedule/history 派生，不新增計數器真相。
[x] AMQ-879 自動評級 UI 顯示本題評級與可讀原因。
[x] AMQ-880 手動覆寫 UI 清楚標記手動來源並保留自動評級歷史所需證據。
[x] AMQ-881 音訊失敗時不產生自動評級。
[x] AMQ-882 回合取消時不產生自動評級。
[x] AMQ-883 計時器異常時不產生自動評級。
[x] AMQ-884 AMQ／EMQ 相同數字 ID 仍維持不同排程身份。
[x] AMQ-885 MIX 不建立第三份 SRS schedule。
[x] AMQ-886 selector 先套用黑名單與 eligibility 再抽樣。
[x] AMQ-887 selector 對到期題與新題比例加入可測試策略。
[x] AMQ-888 selector 避免同回合重複出題。
[x] AMQ-889 selector 保留 MIX 現有 2:1 source weighting。
[x] AMQ-890 selector 在 due pool 不足時採有界 fallback。
[x] AMQ-891 新增 SRS toggle 開／關／reload 測試。
[x] AMQ-892 新增一般練習自動評級整合測試。
[x] AMQ-893 新增 AMQ／EMQ／MIX source-aware selector 整合測試。
[x] AMQ-894 新增評級保存失敗時 UI 狀態測試。
[x] AMQ-895 新增損壞 SRS 資料及 recovery 測試。
[x] AMQ-896 新增跨分頁 SRS 更新測試。
[x] AMQ-897 更新備份／還原 schema 以包含評級 provenance。
[x] AMQ-898 完成全域 SRS 功能的統計與操作 UI 接線。
[~] AMQ-899 依使用者已驗收證據保留 P0 結案狀態，不以缺少 AI 瀏覽器通道推翻。
[~] AMQ-900 完成全域 SRS 的完整回歸後，才將相關整合標記為驗收。


## Batch 73+：全域 SRS 整合、抽樣策略與交付驗證
[x] AMQ-901 沿用既有 appSettingsStore 新增全域 SRS 開關，舊 schema 缺少 srsEnabled 時套用預設值，reload／storage event 可還原設定；設定測試已涵蓋。
[x] AMQ-902 以 QuizPanel integration 驗證全域 SRS 關閉時 AMQ／EMQ schedule snapshot 均不變，普通答題歷史仍持續新增；完整統計 projection／跨分頁場景仍由 AMQ-916 追蹤。
[x] AMQ-903 已以 QuizPanel integration 覆蓋 AMQ／EMQ／MIX 在 SRS 關閉時的一般出題、歷史持續寫入及 AMQ／EMQ schedule 不變；仍未涵蓋真實瀏覽器 storage event。
[x] AMQ-904 一般 AMQ 有效作品標題答題已接既有 AssessmentEngine，可靠計時不足時不虛構評級；Batch 73 integration regression PASS。
[x] AMQ-905 一般 EMQ 評估接入既有 AssessmentEngine 與獨立 EMQ SRS store；source-aware ID regression PASS。
[x] AMQ-906 MIX 答題依題目 source 寫回 AMQ／EMQ store，不建立 MIX schedule；既有 QuizPanel source identity integration PASS。
[x] AMQ-907 Batch128 新增明確 audioStatus=failed gate；即使音訊曾開始且有 latency，所有候選失敗後提交答案也不會自動建立／評級 SRS 卡片；取消／跳過／揭曉／缺少計時仍由 AssessmentEngine 排除。
[x] AMQ-908 enroll／rate 保存失敗會顯示明確未保存訊息，未宣稱排程已更新；保留既有 persistence regression。
[x] AMQ-909 SRS counts 仍由既有 SRS store schedule 投影提供，未新增獨立計數器；完整統計面板尚可擴充。
[x] AMQ-910 備份／還原 API 已保存全域 SRS toggle、AMQ／EMQ schedule 與評級 provenance 原始資料；舊 settings schema、version-1 envelope、partial keys、explicit null、JSON string、格式／schema／checksum／raw value／未知 key 拒絕矩陣已由 Batch129 Node regression 覆蓋。真實瀏覽器下載／選檔／storage quota 仍由 AMQ-916 等項目追蹤。
[x] AMQ-911 QuizSession 僅把 eligibility 過濾後的 unseen pool 傳給 selector，並驗證 selector 無法越過黑名單／清單候選邊界。
[x] AMQ-912 新增 due／overdue 程度、lastRating 與 new/future 狀態的相對動態權重，不使用固定每 N 題比例。
[x] AMQ-913 已新增固定種子的 40,000 次 new/future/due/weak-overdue 分布模擬，以及 30,000 次 MIX 來源權重模擬；驗證 weak-overdue > due > new > future，且 AMQ 來源比例維持約 2/3。
[x] AMQ-914 新題保護採相對權重；QuizSession 維持 source-aware seen set 去重；due/future pool 不足時在有限 eligible pool 內選取，不重試迴圈。
[x] AMQ-915 dueAt 僅用於到期／逾期權重、沒有改寫 FSRS 排程；MIX 先按既有 2:1 source roll 再做來源內加權。
[~] AMQ-916 settings reload／storage、SRS recovery、source-aware identity、SRS-off 三模式整合及 selector 分布模擬已覆蓋；真實瀏覽器跨分頁、storage quota／損壞恢復實機矩陣仍待驗收。
[x] AMQ-917 Batch 76 最終驗證已完成：29/29 Node scripts、tooling 8/8、architecture 510/0、source audit／mapper／5 次 benchmark／JS-CJS syntax PASS；163 筆 Manifest 驗證與 ZIP integrity 均 PASS。
[x] AMQ-918 已在持續 WORK_STATUS／ACCEPTANCE 中將 Node／fake DOM 測試與真實瀏覽器／音訊阻塞分開記錄；不以自動測試取代實機驗收。

## Batch 75：SRS selector 分布模擬與三模式關閉保護（2026-10-27）
[x] AMQ-919 新增固定種子的 40,000 次選題模擬，覆蓋新題、未到期、一般到期及 grade-1 嚴重逾期卡片，驗證抽樣占比符合權重順序。
[x] AMQ-920 新增固定種子的 30,000 次 MIX 抽樣模擬，在 AMQ pool 較大且卡片較弱、EMQ pool 較小且為新卡的偏斜分布下驗證來源比例仍接近 2:1。
[x] AMQ-921 擴充 QuizPanel integration，確認 SRS 關閉時 AMQ／EMQ／MIX 都能正常開始與答題，兩份來源排程保持不變，普通答題歷史仍持續新增。
[x] AMQ-922 更新工作狀態、主清單、交接文件及下一工作階段提示；未變更正式基準、曲庫資產、FSRS scheduler 或 UI／CSS 視覺。
[x] AMQ-923 已盤點 15 個 active／legacy data keys 的 schema、公開 API 與 recovery 邊界，定義版本化 envelope、SHA-256 checksum、匯入預檢及多 key rollback 契約；見 `docs/BACKUP_RESTORE_CONTRACT_BATCH76.md`。
[x] AMQ-924 新增 `src/persistence/backup-restore.js`，實作 export、preflight、restore 與失敗回滾；7 組專用測試覆蓋 legacy settings／list、checksum／損壞匯入、既有資料不變、SRS provenance、rollback 成功與失敗回報、partial backup。API 已完成，UI 尚未接線。
[ ] AMQ-925 完成真實瀏覽器 storage event／跨分頁驗收；不得用 VM 測試替代。



## Batch 76：版本化全量備份／還原 persistence API（2026-10-27）
[x] AMQ-926 盤點 settings、AMQ／EMQ SRS、history、familiarity、blacklist、personal library 與 legacy read-only keys，明確排除 recovery/quarantine blobs。
[x] AMQ-927 新增版本化 backup envelope 與 SHA-256 checksum，並以穩定序列化避免物件 key 順序影響 checksum。
[x] AMQ-928 新增完整 preflight：格式／版本／key allowlist／checksum／JSON／各 store schema 驗證，任何失敗都在寫入前拒絕。
[x] AMQ-929 新增多 key restore snapshot 與失敗 rollback，結果明確回報 rollback 是否完整及 rollback errors。
[x] AMQ-930 新增 7 組專用測試：匯出／匯入、舊 settings schema、舊 personal-list array、損壞／竄改匯入不覆蓋現有資料、SRS provenance、部分寫入失敗回滾、rollback 持續失敗回報、未知格式拒絕與 partial v1 omitted-key 保留。
[~] AMQ-931 API 已由 `src/index.html` 載入，但尚未接 UI／下載檔案流程；實機 storage quota、跨分頁 storage event 與 rollback 寫入持續失敗仍待瀏覽器驗收。
[x] AMQ-932 已測舊 settings schema、舊 personal-list array、SRS provenance、partial v1 backup 的 omitted-key 保留及未知 formatVersion 拒絕；未定義過的 v0 envelope 明確拒絕。

## Batch 77：備份／還原使用者流程（2026-10-27）
[x] AMQ-933 新增 `src/ui/backup-restore-panel.js`，透過既有 persistence backup API 建立獨立 UI 控制器，未把匯入／還原邏輯塞進 app mount handler。
[x] AMQ-934 在 `src/index.html` 新增資料備份與還原區塊，保留原有頁面層級與樣式系統，不啟動大規模 UI／CSS 重構。
[x] AMQ-935 完成完整 JSON 備份下載，檔名包含建立時間，匯出錯誤以可讀狀態顯示。
[x] AMQ-936 完成檔案讀取與匯入預檢；預檢失敗時保持還原按鈕停用，明確顯示未修改資料。
[x] AMQ-937 預覽通過預檢的資料 key 範圍，並說明 partial backup 不會更動未包含 key。
[x] AMQ-938 還原前要求明確確認；取消確認不呼叫 restore API；成功後提示重新載入以更新各 Store 快照。
[x] AMQ-939 區分還原成功、預檢失敗、commit 失敗且已回滾、回滾不完整等狀態；回滾不完整顯示嚴重資料完整性警告及失敗 key。
[x] AMQ-940 新增 `tests/backup-restore-panel.test.cjs`，涵蓋初始化／匯出錯誤、JSON 下載、預檢後取消不寫入、成功還原、失敗預檢保護與 rollback 不完整警告。
[~] AMQ-941 真實瀏覽器下載／檔案選取／localStorage quota／跨分頁 storage event 與實際頁面 reload 尚未驗收；Node 假 DOM 測試不代表瀏覽器驗收。

## Batch 78：備份匯入非同步選檔競態防護（2026-10-27）
[x] AMQ-942 修正備份檔案讀取與預檢的 stale async result：選擇新檔或 dispose 後，舊請求不能再覆寫目前狀態、預覽或還原按鈕狀態。
[x] AMQ-943 新增延遲預檢競態回歸測試，重現備份 A 預檢未完成時切換到備份 B，確認 A 的結果不能解鎖還原。
[x] AMQ-944 完成 30/30 Node test scripts、tooling 8/8、architecture 524/0、source audit、mapper verification、5 次 benchmark 與 JS/CJS syntax 檢查。
[~] AMQ-945 真實瀏覽器下載／選檔／預檢／還原／reload、storage quota、跨分頁 storage event 仍未驗收；已知 Chromium 頁面導覽受政策阻擋，不重試同一方法。


## Batch 79：備份／還原操作期間的互斥保護（2026-10-27）
[x] AMQ-946 檢查備份／還原控制器在還原 Promise pending 期間的操作互斥；確認選檔與預檢仍可被事件觸發，可能在第一筆還原尚未完成時解鎖第二筆還原。
[x] AMQ-947 還原開始後鎖定檔案選擇、預檢與還原操作；控制器拒絕還原進行中重入，避免 UI 狀態被另一個預檢改寫。
[x] AMQ-948 新增並通過競態回歸測試：第一筆還原 pending 時模擬改選／預檢／再次還原，確認不會啟動第二筆寫入，且完成後正確解除操作鎖。
[x] AMQ-949 完成 30/30 Node test scripts、tooling 8/8、architecture 524/0、source audit、mapper verification、5 次 benchmark 與 72 個 JS/CJS syntax checks。
[~] AMQ-950 真實瀏覽器下載／選檔／還原／reload、localStorage quota/security、跨分頁 storage event 仍待在可允許頁面導覽的瀏覽器驗收；Node 測試不是 E2E 證據。

## Batch 80：猜歌出題篩選第一批實作（2026-10-27）
[x] AMQ-951 將已驗證來源資料中的作品年份與 AMQ 作品類型映射到正規化歌曲記錄；EMQ 未提供的作品類型保留為未知，不推測補值。
[x] AMQ-952 擴充既有 `appSettingsStore`，版本化持久化年份起迄、未知年份開關、作品類型、歌曲類型、難度起迄及看番狀態；舊版 settings 缺欄位時安全套用預設值。
[x] AMQ-953 新增猜歌年份起迄與未知年份控制，範圍驗證拒絕倒置或非法年份。
[x] AMQ-954 新增作品類型、歌曲類型、難度範圍篩選；啟用難度篩選時，沒有可信難度資料的曲目會被排除。
[x] AMQ-955 將看番狀態篩選接入 source-aware work reference；與既有模式來源、黑名單及個人清單篩選以 AND 關係共同限制出題池。
[x] AMQ-956 新增設定驗證、QuizPanel eligibility integration 及備份／還原 round-trip regression，確認篩選設定能跨 reload／備份還原保存。
[~] AMQ-957 季別篩選仍阻塞：目前已核對的 AMQ／EMQ 來源 schema 沒有可確認的 season 欄位；不得只從年份推算季別。
[x] AMQ-958 完成 Random Sample、片段起始位置及自動下一題延遲；完整設計與測試證據見 Batch 81。
[~] AMQ-959 真實瀏覽器篩選互動、跨分頁設定更新與音訊回合尚未驗收；已知 Chromium 導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重試同一路徑。

## 後續必要產品功能追蹤（狀態以實作證據更新）
[~] AMQ-960 資料庫更新／匯入：Batch 84 已完成版本化 JSON、完整驗證、更新預覽、IndexedDB 原子替換與 runtime override；真實瀏覽器 quota／transaction／reload 驗收仍阻塞。
[~] AMQ-961 中文標題 Provider：Batch 82–84 已接入固定版本來源、設定、快取／取消／失敗回退、答案建議、揭曉與曲庫搜尋；外部 JSON／CORS／OpenCC 實機驗收仍待處理。
[~] AMQ-962 自由播放歷史：Batch 86 已由獨立 Dock 接入真實 AudioService playing 狀態；實際播放累積達 5 秒才記錄一次，與猜歌音訊隔離。Node 回歸通過，真實瀏覽器／持久化仍待驗收。
[~] AMQ-963 統計儀表板：Batch 86 已將既有純函式 projection 接入最小 UI，讀取答題歷史、熟悉度、AMQ／EMQ SRS 與自由播放歷史；讀取失敗時暫停顯示統計，避免將錯誤當成零。真實瀏覽器驗收仍待處理。
[~] AMQ-964 自由播放欄／播放器 Dock：Batch 86 已完成獨立搜尋、選曲、播放／恢復、暫停、停止、隨機播放及狀態顯示；不建立待聽佇列。真實瀏覽器與音訊可聽性仍待驗收。
[~] AMQ-965 外部服務整合：Batch89 已建立通用 client boundary、認證政策、rate limit／取消／錯誤處理；AniList／MAL／VNDB service-specific feature adapter、OAuth flow 與真實 API 尚未接線。
[~] AMQ-966 多人模式：Batch89 已定義 client-side protocol v1 envelope／payload／version／sequence contract；transport、server、房間生命週期、權限與真實互通尚未實作。
[~] AMQ-967 出題篩選：Batch130 將 query-index 的 10 個條件維度與獨立 includeUnknownYear 組成 2,048 種交叉矩陣；Batch131 再以獨立參考 predicate 覆蓋 personal list、AMQ blacklist、source-aware watch status、year／unknown year、anime type、difficulty、song type、AMQ／EMQ／MIX 與 SRS toggle，共 768 組。Node selector/filter 交叉矩陣已完成；Candidate302 舊版規則相容仍因正式基準不可用而未證明。
[~] AMQ-968 曲庫瀏覽已新增年份範圍／未知年份、年代、作品細分類、看番狀態、熟悉度篩選與作品年份排序；Batch130 的 Node matrix 驗證 2,048 種 filter 組合、分頁前計數、未知年份、年份排序與 facet 交集。真實瀏覽器與跨分頁狀態仍待驗收。

## Batch 81：Random Sample、片段定位與自動下一題（2026-10-27）
[x] AMQ-969 在既有 `appSettingsStore` 增加 `randomSample`、`clipStartSeconds`、`autoNextDelaySeconds`，保留舊 schema 缺欄位相容性及備份／還原原始設定契約。
[x] AMQ-970 新增隨機片段與固定起始秒數控制；隨機模式啟用時固定起始控制停用，避免使用者誤以為兩者同時生效。
[x] AMQ-971 AudioService 等待 `loadedmetadata` 後才定位隨機片段，依曲目長度及猜歌倒數秒數限制起始位置，不讓片段超出可用音訊長度。
[x] AMQ-972 AudioService 支援固定起始秒數並將位置限制在 `duration - clipSeconds` 範圍；起始秒數為 0 時維持原有直接播放路徑。
[x] AMQ-973 QuizSession 將片段設定交給唯一 AudioService；QuizClock 仍只在真實 `playing` 狀態後啟動，不由 UI 或 seek 事件啟動計時。
[x] AMQ-974 新增 0–30 秒自動下一題延遲；0 秒維持手動下一題，非零時在答題、逾時、揭曉及已播放後跳過時排程。
[x] AMQ-975 自動下一題 timer 由 QuizSession 擁有，手動下一題、結束、重設與 dispose 會取消，並以 token 阻擋已排入事件佇列的過期 callback。
[x] AMQ-976 未播放就跳過不會自動前進，避免無意間連續跳過；音訊失敗／等待播放不會自動跳題；SRS 專用回合強制關閉自動下一題，以免跳過必要的手動評級。
[x] AMQ-977 新增 AudioService 固定／隨機 seek、片段邊界限制、非法片段設定不會中斷既有播放，以及 QuizSession 設定轉交／自動下一題取消測試。
[x] AMQ-978 新增 UI 設定持久化與 backup/restore round-trip assertions。
[x] AMQ-979 完成全套 Node 測試、tooling、架構、來源資料／mapper、benchmark 與語法驗證；結果詳見 `docs/HANDOFF_BATCH81.md` 與 `docs/WORK_STATUS.md`。
[~] AMQ-980 真實瀏覽器的 `HTMLAudioElement` seek／loadedmetadata／播放片段聽感、手動播放模式及自動下一題實際互動仍待實機驗收；Node FakeMedia 不等於瀏覽器 E2E。
[~] AMQ-981 中文標題 Provider：已接入固定版本資料來源、設定開關、cache／取消／失敗回退、答案建議與揭曉資訊；真實瀏覽器外部資料下載與完整曲庫搜尋仍待驗收。
[~] AMQ-982 資料庫更新／匯入：Batch 84 已實作版本化 JSON、SHA-256、完整 mapper／validator 預檢、作品／歌曲新增修改移除差異、單筆 IndexedDB 原子替換、active override runtime 消費、匯出／匯入 UI 與恢復內建曲庫。真實瀏覽器 IndexedDB quota／transaction／reload E2E 仍待驗收。


## Batch 82：中文作品標題 Provider 第一版接線（2026-10-27）
[x] AMQ-983 核實 Candidate381 靜態參考中的固定版本 AniList Chinese、Bangumi-data 與 OpenCC 資料來源；不虛構 API endpoint。
[x] AMQ-984 新增純資料層 `src/data/chinese-title-provider.js`，驗證資料格式並以 Bangumi site IDs 對應 MAL／AniList／VNDB，不依相似標題猜測身份。
[x] AMQ-985 新增 IndexedDB 7 天 cache、過期 cache fallback、timeout、AbortSignal 取消與部分來源可用處理；cache 失敗不阻擋有效網路結果。
[x] AMQ-986 在既有 `appSettingsStore` 新增 `chineseTitlesEnabled`，預設關閉；只有啟用時才下載遠端標題資料與按需載入 OpenCC。
[x] AMQ-987 EMQ mapper 將來源明確提供的 `vndbId` 映射為 `animeVndbId`；AMQ work ID 依已核實資料契約透過 MAL ID 對應。
[x] AMQ-988 將中文別名接入作品答案建議，答案揭曉時顯示可對應的中文作品名；新增 provider parser、ID crosswalk、cache、stale fallback、取消與失敗測試。
[~] AMQ-989 真實瀏覽器的外部 JSON 下載、CORS／CDN、OpenCC 載入與使用者操作尚未驗收；Node 測試不視為外部服務 E2E。
[x] AMQ-990 中文別名已接入曲庫全文搜尋索引；Batch 84 新增 Provider 成功命中、關閉恢復原始索引、Provider 失敗不影響一般搜尋、延遲回應不覆蓋關閉狀態的 integration regression。真實外部 JSON／CORS／OpenCC 驗收另由 AMQ-989 追蹤。


## Batch 83：中文標題索引接入曲庫搜尋（2026-10-27）
[x] AMQ-990 將 Provider 別名加入曲庫全文搜尋索引；啟用設定後非同步載入 Provider，從當前 catalog 以分頁讀取 records，建立複製後的 animeAliases 索引快照，保留原始 catalog／source record。設定關閉時還原原始 catalog；請求序號避免切換關閉／dispose 後的延遲結果覆蓋目前索引。Batch 84 已補齊成功／失敗／關閉／延遲回應 regression；外部服務 E2E 另追蹤 AMQ-989。
[~] AMQ-982（Batch 83 當時狀態，已由 Batch 84 取代）：安全資料庫更新／匯入已實作 API、UI 與 runtime override；真實瀏覽器 IndexedDB／quota／reload E2E 仍待驗收。
[x] Batch 84 已補齊 Provider 載入成功／失敗、關閉後還原、延遲請求取消的 catalog-browser integration regression；真實瀏覽器外部 JSON／CORS／OpenCC 仍由 AMQ-989 追蹤。


## Batch 84：安全曲庫更新／匯入與中文搜尋回歸（2026-10-27）
[x] AMQ-982-1 建立 `amq-learning-database-update` format v1、payload schema v1、AMQ／EMQ 固定 source schema 與 canonical SHA-256 checksum。
[x] AMQ-982-2 完整 preflight 使用現有 source mappers 與 `validateRecords()`；損壞 checksum、未知 schema、重複 ID、懸空 work reference 及非法 record 在寫入前拒絕。
[x] AMQ-982-3 產生 AMQ／EMQ works／songs 新增、修改、移除差異摘要；預檢不寫入。
[x] AMQ-982-4 使用 IndexedDB 單一 `active` envelope 的 readwrite transaction 原子替換，失敗保留既有 envelope；不使用 localStorage 存大型曲庫。
[x] AMQ-982-5 source runtime 會讀取並重新驗證 active override，將正規化記錄送入既有 Adapter／Repository／Validator／Catalog；清除 override 後回到內建唯讀曲庫。
[x] AMQ-982-6 新增匯出、選檔、預檢、差異預覽、確認套用與恢復內建曲庫 UI；成功後明確要求 reload。
[x] AMQ-982-7 新增 `tools/create-database-update.cjs`，只解析來源檔 JSON assignment，不執行匯入來源 JavaScript；輸出使用 `wx` 防止覆蓋。
[x] AMQ-982-8 新增資料更新 API、runtime integration、UI panel 與 tooling 測試。
[x] AMQ-982-10 使用真實內建曲庫來源產生完整 update package，並以應用層 preflight 驗證 AMQ 38,821／EMQ 16,839 筆記錄全數通過。
[x] AMQ-990-1 新增 catalog-browser integration 回歸：中文別名命中、關閉後索引還原、Provider 失敗保留一般搜尋、延遲回應無法覆蓋關閉狀態。
[~] AMQ-982-9 真實瀏覽器 IndexedDB transaction／quota／跨分頁／reload E2E 尚未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一路徑。
[~] AMQ-989 外部 JSON／CORS／OpenCC CDN 的真實瀏覽器驗收仍未完成。
[ ] NEXT-84-1 後續：自由播放歷史、統計儀表板、播放器 Dock、外部服務與多人模式依功能清單排序；本批不提前進行 UI／CSS 大重構。


## Batch 85：自由播放歷史資料層與統計投影（2026-10-27）
[~] AMQ-991 新增獨立 `playbackHistoryStore`，持久化自由播放事件，與猜歌答題歷史分離；採 source-aware AMQ／EMQ 身份、時間排序、1,000 筆上限、重複事件 ID 去重、讀取／寫入失敗保護及跨分頁 storage-event refresh。
[~] AMQ-992 將播放歷史 key 納入既有 version 1 備份／還原 allowlist 與 schema preflight；舊版部分備份缺少該 key 時維持 omitted-key 相容行為。
[~] AMQ-993 新增純函式 `statisticsDashboard.buildDashboard()`，從既有 quiz history、familiarity、SRS counts 與 playback history snapshots 推導摘要；不新增重複統計持久化或第二套狀態來源。尚未建立 dashboard UI。
[x] AMQ-994 新增 playback history 5 個測試情境與 dashboard aggregation 測試；完整 Node 測試 37/37 scripts、tooling 9/9、architecture 614/0、source audit／mapper／5 次 benchmark PASS。
[~] AMQ-995 播放器 Dock 尚未實作，因此目前 playback history API 未由實際音訊播放事件呼叫；待 Dock 批次接線後再驗收播放事件的時機與重複觸發。真實瀏覽器 localStorage quota／跨分頁仍未驗收。


## Batch 86：自由播放 Dock 與統計儀表板 UI（2026-10-27）
[x] AMQ-996 新增 `src/ui/free-player-dock.js`，以既有 runtime catalog 搜尋可播放曲目，提供搜尋、選曲、播放／恢復、暫停、停止與隨機播放；不依賴 QuizSession、不建立待聽佇列。
[x] AMQ-997 將自由播放音訊限定在唯一 AudioService；新增 `getPlaybackMetrics()`，供 Dock 讀取目前媒體位置／長度，不把 media element 暴露給 UI。
[x] AMQ-998 只有 AudioService 實際進入 `playing` 後才累積播放時間；累積達 5 秒才記錄一筆播放歷史，同一 audio sequence 去重；猜歌音訊不會呼叫自由播放 Store。
[x] AMQ-999 新增 `src/ui/statistics-dashboard-panel.js`，將既有答題歷史、熟悉度、AMQ／EMQ SRS 與播放歷史快照接到 dashboard projection，無第二份統計持久化。
[x] AMQ-1000 儀表板檢查各 Store 的讀取／持久化狀態；若資料讀取不可靠，顯示錯誤並停止投影，避免把 storage failure 偽裝成零統計。
[x] AMQ-1001 `src/app.js` 透過 lifecycle scope 管理 Dock 與 Dashboard mount／dispose；`src/index.html`、`tests/tests.html` 與架構載入順序同步更新。
[x] AMQ-1002 新增 Dock 回歸，驗證只列出有音訊候選的曲目、搜尋、5 秒記錄門檻、來源／歌曲身份、單序列去重、切歌身份及 dispose 清理。
[x] AMQ-1003 新增 Dashboard UI 回歸，驗證既有 projection 接線、摘要顯示、播放歷史顯示與讀取失敗時不呼叫 projection。
[x] AMQ-1004 AudioService 新增 playback metrics contract regression；完成 39/39 Node test scripts（逐檔執行）、tooling 9/9、architecture 642/0、89/89 JS/CJS syntax、source audit／mapper verification／5 次 benchmark。
[~] AMQ-1005 自由播放真實 HTMLAudioElement 可聽性、播放 5 秒門檻的真實時間、localStorage quota／跨分頁、Dashboard reload／錯誤投影尚未瀏覽器驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一路徑。


## Batch 87：曲庫瀏覽 facet 與出題篩選回歸（2026-10-27）
[x] AMQ-1006 擴充 `query-index.js`，支援作品年份起迄、未知年份是否保留、作品細分類、作品年代、看番狀態與熟悉度等組合條件；所有條件在排序／分頁前套用。
[x] AMQ-1007 擴充 query-index facets：作品細分類與年代 facet 會依其他篩選條件重新計數，年代 label 使用「YYYY 年代」；新增作品年份數值排序並維持未知值最後。
[x] AMQ-1008 曲庫 UI 新增年份範圍、未知年份開關、作品細分類、年代、看番狀態與熟悉度控制；source／song type／work kind 原有 facet 保留。
[x] AMQ-1009 曲庫索引以複製 record 補上 `animeDecade`、source-aware `watchStatus`、Familiarity Store `familiarityLevel`，不修改 runtime 原始曲庫記錄。
[x] AMQ-1010 App 將單一 Familiarity Store 共用給 Catalog Browser 與 QuizPanel；Store 變更後刷新瀏覽索引，避免同頁兩份熟悉度快照互相過期。
[x] AMQ-1011 修正設定訂閱：只有 `chineseTitlesEnabled` 開關真正改變時才重建中文標題索引，避免每次一般猜歌設定變更都重新掃描整個曲庫。
[x] AMQ-1012 擴充 query-index／catalog-browser 測試，覆蓋年份、未知年份、年代、作品細分類、看番狀態、熟悉度、組合條件、年份排序與缺值排序。
[x] AMQ-1013 擴充 QuizPanel integration，驗證 MIX 未知年份 include/exclude、EMQ 缺少作品細分類／難度時不推測補值，以及 AMQ／EMQ／MIX 在相同完整篩選下的 eligibility 結果。
[~] AMQ-1014 真實瀏覽器的 facet 操作、跨分頁看番／熟悉度變更與大量曲庫重建效能尚未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一路徑。
[x] AMQ-1015 Batch87 最終驗證：39/39 Node test scripts 逐檔 PASS；tooling 9/9；architecture 642/0；89/89 JS/CJS syntax；source audit、mapper verification 與 5 次 benchmark PASS；來源資產 SHA-256 未變。


## Batch 88：篩選組合矩陣與 Facet 回歸加固（2026-10-27）
[x] AMQ-1016 新增 `tests/filter-matrix.test.cjs`，以獨立參考 predicate 覆蓋來源、歌曲類型、作品類型、年份範圍／未知年份、作品細分類、年代、看番狀態及熟悉度 8 個維度，共 256 組條件組合。
[x] AMQ-1017 驗證所有 filter 先於排序／分頁執行，未知年份只依啟用中的年份範圍與開關處理，年份降冪仍將未知值固定排最後。
[x] AMQ-1018 擴充 `tests/catalog-browser.test.cjs`，驗證 anime-type／decade facet 忽略自身已選條件、但保留其他條件的計數語義。
[x] AMQ-1019 完成全套 40 個 Node test scripts（39 個逐檔 PASS，tooling 9/9 獨立 PASS）、architecture 649/0、90/90 JS/CJS syntax、source audit／mapper／5 次 benchmark；曲庫資產 hash 不變。
[~] AMQ-1020 真實瀏覽器 facet／跨分頁／storage failure／大曲庫索引效能仍未驗收；Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試相同路徑。
[x] AMQ-1021 定義外部服務 adapter 契約（認證／配額／取消／錯誤隔離），不得讓外部 API 阻斷單機啟動；Batch89 已建立並由 Batch90 加固認證 header／redirect／cookie 邊界。
[x] AMQ-1022 定義多人房間／同步／協定版本契約的第一層 wire boundary；Batch90 已讓已驗證 payload 脫離 caller-owned input 並深度凍結。Room state machine／server authority 仍待後續實作。

## Batch 89：外部服務與多人協定隔離契約（2026-10-27）
[x] AMQ-1023 建立可選外部服務 client boundary；只有明確呼叫 request() 才發出請求，不參與單機啟動。
[x] AMQ-1024 外部服務 host／HTTPS allowlist、注入式 credential provider、auth policy、timeout、AbortSignal、dispose 與標準錯誤碼已有 contract tests。
[x] AMQ-1025 對 HTTP 401／403、429／Retry-After、5xx、invalid JSON、network、timeout／cancel 分別分類；配額讀 response headers，不把動態限額硬編碼。
[~] AMQ-1026 AniList／MAL／VNDB 的正式 feature endpoint、OAuth callback／refresh、服務資料映射與實際 API 呼叫尚未接線；MAL quota 與具體操作仍需官方文件核實。
[x] AMQ-1027 定義 multiplayer protocol v1 envelope、message type／payload 驗證、payload size limit、版本協商與 per-peer sequence guard。
[~] AMQ-1028 多人 transport／server／room lifecycle／auth／reconnect／anti-cheat／實機互通尚未實作；client validator 不是 server 安全邊界。
[x] AMQ-1029 新增外部服務與多人契約測試，並更新 HTML script order、架構檢查、驗收條件與交接文件。


## Batch 90：外部請求與多人 payload 安全加固（2026-10-27）
[x] AMQ-1030 外部服務 adapter 拒絕呼叫端直接注入 `Authorization` header，憑證只能由明確配置的 credential provider 注入；拒絕時不建立 active request／timeout。
[x] AMQ-1031 外部 fetch 明確設定 `credentials: "omit"` 與 `redirect: "error"`，防止意外 cookie 與 redirect 跨越已驗證的 host 邊界；專項 regression PASS。
[x] AMQ-1032 Multiplayer protocol 將 payload JSON serialize／parse 成獨立副本，依實際 UTF-8 bytes 限制大小，再重新驗證 schema，避免驗證後由原始呼叫端修改。
[x] AMQ-1033 Multiplayer protocol 遞迴 freeze payload 的巢狀物件／陣列，並拒絕 circular／BigInt 等非 JSON payload；專項 regression PASS。
[x] AMQ-1034 全量驗證：42 個 Node test scripts 均有獨立成功證據（41 個非-tooling 逐檔 PASS、tooling 9/9）；architecture 677/0、94/94 JS/CJS syntax、source audit／mapper／5 次 benchmark PASS；Manifest 207 項無缺漏／雜湊差異／多餘檔案，來源資產 SHA-256 未變。
[~] AMQ-1035 外部服務 OAuth／service-specific endpoints／MAL quota 與真實 API E2E 仍未完成；Batch90 只加固通用請求邊界。
[~] AMQ-1036 Multiplayer transport／server authority／room state machine／reconnect-resync／scoring-timing 與 anti-cheat 尚未實作；client-side validation 不可視為 server security。
[~] AMQ-1037 真實瀏覽器、外部服務與多人互通驗收仍受可用環境限制；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試相同導覽路徑。


## Batch 91：多人房間純邏輯狀態機與答案快照隔離（2026-10-27）
[x] AMQ-1038 新增 `src/multiplayer/room-state-machine.js`，以純邏輯 state transition 管理 room membership、capacity、host transfer、ready、round lifecycle 與 close；不接入單機啟動。
[x] AMQ-1039 加入 revision／expectedRevision 衝突檢查、不可重用 round ID、host-only 操作、每位玩家每 round 一次答題、round ID／deadline 驗證及 server clock receipt time。
[x] AMQ-1040 新增 revision-based snapshot/resync；active round 隱藏其他玩家答案文字，closed round 才公開答案；snapshot detached／deep-frozen。authenticated viewer ID 必須由 server 可信連線提供。
[x] AMQ-1041 新增 `tests/multiplayer-room-state-machine.test.cjs`，覆蓋 membership、host authority／transfer、ready、revision conflict、round lifecycle、duplicate／late／wrong-round answer、snapshot privacy、resync 與 close。
[x] AMQ-1042 將 room state machine 加入 `src/index.html`、`tests/tests.html` 及 `tools/check-architecture.cjs` 載入／架構檢查；模組未被 app 啟動流程依賴。
[~] AMQ-1043 真實 server authentication、rate limiting、transport／WebSocket、reconnect delta log、authoritative scoring／anti-cheat 與多 client E2E 尚未實作；本批只完成純邏輯 boundary。
[~] AMQ-1044 真實瀏覽器／音訊／storage／外部 API／多人互通仍待可用環境驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試相同導覽路徑。
[x] AMQ-1045 Batch92 已依既有 title-only 評估規格建立 server-owned answer assessment boundary；拒絕 client-provided correctness／score／timestamp，不另造或偏離既有評分規則。
[x] AMQ-1046 Batch91 全量驗證與獨立交付包：43 個 Node test scripts 均有獨立成功證據（42 個非-tooling 逐檔 PASS、tooling 9/9）、architecture 691/0、96/96 JS/CJS syntax、source audit／mapper／5 次 benchmark PASS；最終 Manifest／ZIP CRC 與逐項雜湊終驗完成後交付。


## Batch 92：多人服務端作品標題評級 boundary（2026-10-27）
[x] AMQ-1047 新增 `src/multiplayer/server-answer-assessment.js`，以可信 question records 呼叫既有 answer evaluator 與 `work-title-latency-v1` assessment engine；不建立第二份評級規則／FSRS scheduler。
[x] AMQ-1048 評級忽略 client-provided correctness／correctByTarget／grade／score／elapsedSeconds；latency 由 trusted server timestamps 計算，非法或逆序時間拒絕。
[x] AMQ-1049 `acceptPartial` 改由 server assessor 建立設定持有，單次 client submission 無法開啟 partial matching；未知 question ID 與重複 trusted question IDs 拒絕。
[x] AMQ-1050 新增 `tests/multiplayer-server-answer-assessment.test.cjs`，驗證作品標題 4 級門檻、all target 只看作品標題、timeout／revealed／unplayed skip、歌名／歌手不評級、latency 缺失、client spoof resistance 與無效輸入。
[~] AMQ-1051 真正 server authentication／transport／單次提交 authority／SRS store 寫入／多 client E2E 未實作；本批只建立可獨立測試的 assessment boundary。
[x] AMQ-1052 Batch92 全量終驗：44 個 Node test scripts 均有獨立成功證據（43 個非-tooling 腳本逐檔 PASS、tooling 9/9）；architecture 705/0、98/98 JS/CJS syntax、source audit／mapper／5 次 benchmark PASS；來源資產 hash 未變，Manifest／ZIP integrity 終驗另記交付回報。
[x] AMQ-1053 assessment adapter 將 submission 與 trusted server context 分開，target 固定在 server-owned question set；client target／outcome／timestamps 不會覆寫可信 context。


## Batch 93：多人房間命令 orchestration（2026-10-27）
[x] AMQ-1054 新增 `src/multiplayer/room-command-service.js`，以可信 auth context／server question selector／round ID factory／server clock／server duration 組合 room state machine 與 assessment adapter。
[x] AMQ-1055 client command allowlist 不暴露 `round.timeout`；忽略 client actorId、round questionId／roundId／duration、target／outcome／correctness／grade／score／timestamps，expectedRevision 只作 concurrency token。
[x] AMQ-1056 `answer.submit` 先通過 room membership／active round／round ID／deadline／duplicate validation，再執行 title-only assessment，assessment 成功後才 commit 新 state。
[x] AMQ-1057 `expireRound()` 只由 trusted server caller 呼叫；deadline 未到拒絕，對未答成員產生 timeout assessment，已答成員不重複評級，並關閉 round。
[x] AMQ-1058 新增 `tests/multiplayer-room-command-service.test.cjs`，覆蓋未認證、偽造 actor、未授權 start、revision conflict、server-selected question／round／duration、spoofed answer metadata、duplicate submit、snapshot membership、early timeout 與 timeout idempotence。
[~] AMQ-1059 真實 transport／auth provider／command concurrency control／rate limit／reconnect／SRS persistence／multi-client E2E 尚未實作；不得宣稱已具備可上線多人伺服器。
[x] AMQ-1060 Batch93 全量終驗：45 個 Node test scripts 均有獨立成功證據（44 個非-tooling 逐檔 PASS、tooling 9/9）、architecture 719/0、100/100 JS/CJS syntax、source audit／mapper／5 次 benchmark PASS；來源資產 hash 未變，最終 Manifest／ZIP 完整性已驗證。
[x] AMQ-1061 產品決策已於 Batch105 確定：採私人自架、管理者邀請制與 server-side per-user SRS；後端實作與前端接線分別由 AMQ-1132 至 AMQ-1138 追蹤。

## Batch 94：多人命令重試安全與有界冪等快取（2026-10-27）
[x] AMQ-1062 `room-command-service.js` 支援可選穩定 `requestId`，以可信 player ID + requestId 分隔冪等命名空間；相同命令重放回傳原結果，不重複執行狀態轉移／評級。
[x] AMQ-1063 相同玩家重用 requestId 但 payload 不同時回傳 `ROOM_REQUEST_ID_REUSED`；命令以排序 JSON key 建立 fingerprint，屬性順序不影響等價性，循環參照／非 JSON 值拒絕。
[x] AMQ-1064 冪等快取採可配置 FIFO 上限，預設 256 筆，允許 0–10,000；不合法容量在 service 建立時 fail fast，快取不會無界增長。
[x] AMQ-1065 擴充 `tests/multiplayer-room-command-service.test.cjs`，覆蓋成功命令重放、重放不增加 revision、答案評級不重複、同 ID 不同 payload 拒絕、跨玩家隔離、FIFO 淘汰與錯誤容量。
[~] AMQ-1066 requestId 冪等性目前只在單一 service instance 記憶體生命週期內有效；正式 transport/server 仍需 durable idempotency、per-room command serialization、authentication provider、rate limiting、reconnect 與 multi-client E2E。
[x] AMQ-1067 產品決策已確定為私人自架、邀請制與 per-user server persistence；前端尚未接線，不得將多人評級寫入共享 localStorage。
[~] AMQ-1068 真實瀏覽器／音訊／storage／外部 API／多人互通仍未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一導覽路徑。
[x] AMQ-1069 `room-command-service.js` 加入每個 authenticated player 的 sliding-window rate limit，預設 60 commands／10 秒，提供可信設定注入與 `ROOM_RATE_LIMITED`／`retryAfterMs` 拒絕語義。
[x] AMQ-1070 冪等重放不消耗 rate-limit 額度；窗口過期後恢復接受新命令，過期 player 時間戳清理；rate limit 配置範圍經驗證。
[x] AMQ-1071 專項 regression 驗證 rate-limit 超限、retryAfterMs、冪等重放 bypass、窗口過期恢復與非法設定；request ID key 使用 tuple JSON 編碼避免分隔符碰撞。
[~] AMQ-1072 單一 instance 的記憶體 rate limit 不能取代 transport／IP／帳號層限流、監控或跨節點配額；真實 server／transport／multi-client E2E 未實作。

## Batch 95：多人房間初始狀態驗證與 ownership（2026-10-27）
[x] AMQ-1073 `room-state-machine.js` 新增 `normalizeState()`，把輸入轉成 detached／deep-frozen state；拒絕循環參照、非 JSON 值、非 plain object、symbol／accessor 與非有限數字。
[x] AMQ-1074 驗證 schemaVersion、phase、revision、capacity、host／member uniqueness 與 role consistency、used round IDs、round phase／status／duration／deadline consistency、答案唯一性與可信時間範圍。
[x] AMQ-1075 `room-command-service.js` 建立時強制呼叫 `normalizeState()`，不再直接持有呼叫端提供的 mutable initial state；非法 state 以 `ROOM_STATE_INVALID` fail fast。
[x] AMQ-1076 狀態機與命令服務 regression 覆蓋 detached ownership、deep freeze、偽造 state、錯誤 phase、循環參照、object／array getter 不執行及非法狀態拒絕。
[~] AMQ-1077 正式 server 的 durable room state、跨節點 concurrency、transport／auth provider／rate limit 外層防護、reconnect 與 multi-client E2E 仍未實作。
[x] AMQ-1078 已存在 requestId 的 payload mismatch 嘗試先套用 rate limit 再拒絕，避免衝突 ID 重放繞過限流；專項測試驗證限流中的 mismatch 回報 `ROOM_RATE_LIMITED`。
[x] AMQ-1079 `multiplayer-room-state-machine.test.cjs` 加入 deterministic mutation matrix：驗證 8 類 invalid room state（revision、capacity、phase/currentRound、host role、duplicate player、duplicate round ID、active/closed mismatch、duplicate answer）皆被 normalizeState 拒絕，並確認合法狀態可 round-trip normalize。


## Batch 96：多人命令 canonicalization 與 transition regression（2026-10-27）
[x] AMQ-1080 強化 `room-command-service.js` canonical JSON command boundary：讀取任何欄位前先建立 detached JSON 副本，拒絕非有限數字、循環參照、symbol、accessor、稀疏／額外屬性陣列與非 plain object，避免有無 requestId 都執行 getter。
[x] AMQ-1081 保留跨 VM／realm plain object 相容性；`requestId` trim 正規化後才計算 fingerprint，避免相同標準化 ID 因空白差異被當成不同命令。
[x] AMQ-1082 `room-state-machine.applyCommand()` 在 revision 到達 `Number.MAX_SAFE_INTEGER` 時回報 `ROOM_REVISION_EXHAUSTED`，防止發布不安全 revision。
[x] AMQ-1083 擴充狀態機 regression：6 類 timestamp／answer boundary mutation、revision exhaustion 與 24 次 deterministic round trace；驗證唯一 round ID、revision 增量、normalize round-trip 與 snapshot privacy。
[x] AMQ-1084 擴充 command-service regression：拒絕稀疏陣列、NaN 與 accessor payload，並證明 getter 未執行。
[~] AMQ-1085 durable idempotency、per-room concurrency／cross-node state、真正 auth／transport／reconnect／multi-client E2E 仍未實作；process-local cache／rate limit 不可當成正式 server 保證。
[x] AMQ-1086 產品決策已於 Batch105 確定為私人自架 per-user persistence；多人評級仍不得寫入沒有 user identity 的共享 localStorage key，前端接線另追蹤 AMQ-1138。
[~] AMQ-1087 真實瀏覽器／音訊／storage／外部 API／多人互通未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一路徑。
[x] AMQ-1088 command getter regression 涵蓋 `requestId` getter 與無 requestId 的其他欄位 getter，均拒絕且 getter 呼叫次數維持 0。
[x] AMQ-1089 requestId 正規化回歸：`" padded-id "` 與 `"padded-id"` 在相同命令下正確命中冪等重放。


## Batch 97：多人服務時鐘單調性與失敗原子性（2026-10-27）
[x] AMQ-1090 `room-command-service.js` 以 service-lifetime monotonic server time guard 拒絕回退時鐘，回報 `ROOM_SERVER_TIME_REGRESSION`，避免滑動視窗 cleanup／retryAfter 計算失去時間排序假設。
[x] AMQ-1091 新增 clock rollback regression：回退時間被拒絕且 room revision 不變；時鐘恢復至最後觀測時間後服務可繼續。
[x] AMQ-1092 新增 assessment throw failure-atomicity regression：tentative answer transition 不會提前 commit；assessment 失敗不增加 revision、不寫入 answer、不寫入 idempotency cache。
[x] AMQ-1093 驗證同一 requestId 在前次評級失敗後可重試；成功時只提交一次 answer、revision 只增加一次。
[x] AMQ-1094 完成全量 Node tests、tooling、architecture、syntax、source audit／mapper／benchmark 與來源資產 hash 核對；詳見 `docs/HANDOFF_BATCH97.md` 及 `docs/WORK_STATUS.md` 最末 Batch97 終驗。
[~] AMQ-1095 真正 server clock／distributed idempotency／per-room serialization／transport auth／reconnect／multi-client E2E 仍未實作；本批單調時鐘 guard 只保護單一 service instance。
[x] AMQ-1096 產品決策已確定為 private self-hosted per-user persistence；保護共用 localStorage 的規則仍有效，前端整合另列 AMQ-1138。


## Batch 98：多人 timeout 失敗原子性與 round-start 副作用順序（2026-10-27）
[x] AMQ-1097 新增 `expireRound()` 多玩家 timeout assessment 中途拋錯 regression，驗證 room revision／active round 不變，重試可完整產生所有未答玩家的 timeout assessment 並只關閉回合一次。
[x] AMQ-1098 `round.start` 在呼叫 question selector／round ID factory 前先拒絕玩家不足與非 host 玩家尚未 ready 的狀態，避免可預見失敗消耗外部注入資源；state machine 仍是最終狀態轉移權威。
[x] AMQ-1099 新增 selector／round ID factory 呼叫次數測試，確認 `ROOM_NEEDS_PLAYERS`／`ROOM_PLAYERS_NOT_READY` 路徑兩者皆不呼叫。
[x] AMQ-1100 完成修改後全量回歸：44/44 非-tooling tests、tooling 9/9、architecture 719/0、syntax 100/100、source audit／mapper／5 次 benchmark PASS。
[~] AMQ-1101 外部副作用若未來加入 assessor／question selector／round ID factory，需定義明確的純函式契約或交易／outbox／重試語義；目前仍是單一 instance 純邏輯服務。


## Batch 99：多人命令單一時間戳與限流截止邊界（2026-10-27）
[x] AMQ-1102 `room-command-service.js` 每個新命令只讀取一次 server clock，並將同一可信 timestamp 同時用於 rate-limit quota 與 room state transition，避免單一命令跨越兩個時間觀測值。
[x] AMQ-1103 新增 injected ticking clock regression，確認新命令只讀一次時鐘，狀態事件使用該時間；成功冪等重放不重新讀取時鐘。
[x] AMQ-1104 新增 sliding-window 精確 cutoff regression：窗口內超限回報精確 `retryAfterMs`，到達 cutoff 時最舊 timestamp 退出窗口並接受新命令。
[x] AMQ-1105 Batch99 完整回歸：44/44 非-tooling Node scripts、tooling 9/9、architecture 719/0、syntax 100/100、source audit／mapper／5 次 benchmark PASS；詳見 `docs/HANDOFF_BATCH99.md`。
[~] AMQ-1106 單一時間戳只保證此純邏輯 service 的 command accounting 一致；正式 transport／跨節點限流、durable idempotency、per-room serialization、auth provider、reconnect 與 multi-client E2E 仍未實作。
[x] AMQ-1107 產品決策已確定；目前僅後端 API 實作完成，產品 UI／SRS bridge 尚未驗收。


## Batch 100：房間關閉命令冪等重試契約（2026-10-27）
[x] AMQ-1108 新增 `round.close` 成功重放測試：同一 authenticated player／requestId／payload 回傳原始 event 與時間，不再次增加 revision。
[x] AMQ-1109 新增 `room.close` 失敗後重試測試：回合進行中拒絕關房不提交 state、不污染 requestId cache；回合關閉後以相同 requestId 重試可成功。
[x] AMQ-1110 新增 `room.close` 成功重放測試，確認 room 已 closed 時同一 requestId 回傳原始成功結果且 revision 不增加。
[x] AMQ-1111 Batch100 targeted regression 通過；完整回歸與最終 ZIP／Manifest 驗證詳見 `docs/HANDOFF_BATCH100.md`。
[~] AMQ-1112 close retry 契約仍只在單一 service instance 記憶體快取中有效；durable idempotency、transport/auth、跨節點一致性與 multi-client E2E 尚未實作。


## Batch 101：離房回應原子性與房主轉移重試（2026-10-27）
[x] AMQ-1113 修正 `room-command-service.js` 的 `player.leave` 成功回應：離房者已被移出 membership，因此不能再以其身份請求結果快照；離房命令改用非 viewer-scoped snapshot，避免狀態已提交卻回報 `ROOM_PLAYER_NOT_MEMBER`。
[x] AMQ-1114 新增房主離房 regression：驗證房主轉移後的 event／snapshot／revision 正確，原 requestId 重放回傳原結果且不重複轉移；舊房主不能再執行需 membership／host 權限的命令。
[x] AMQ-1115 修正房主候選同 `joinedAt` 時的 tie-break：改用明確的字串 code-unit 比較，不依賴 `localeCompare()` 的執行環境 locale。
[x] AMQ-1116 新增同時間加入、大小寫 ID tie-break 與最後一位房主離房關閉房間的 regression。
[x] AMQ-1117 Batch101 驗證：44/44 非-tooling Node test scripts 逐檔 PASS、tooling 9/9、architecture 719/0、JS/CJS syntax 100/100、source audit／mapper／5 次 benchmark PASS；詳見 `docs/HANDOFF_BATCH101.md`。
[~] AMQ-1118 真實 transport/auth、durable idempotency、跨節點序列化、reconnect 與 multi-client E2E 仍未實作；Batch101 只修復純邏輯 service 契約，不代表正式多人伺服器已驗收。


## Batch 102：加入重試與 FIFO 快取順序（2026-10-27）
[x] AMQ-1119 新增 `player.join` 成功重放 regression，確認同一 authenticated player／requestId／payload 回傳原始 event，不重複加入成員或增加 revision。
[x] AMQ-1120 新增 capacity=2 的 FIFO idempotency regression：重放命中不刷新 insertion order；新增第三筆後淘汰最早插入項目，而非採 LRU。
[x] AMQ-1121 驗證被 FIFO 淘汰的 requestId 再次使用時會重新執行命令，且 no-op 不會錯誤增加 revision。
[~] AMQ-1122 Batch102 只補測試，不修改 production code；完整回歸與最新 ZIP／Manifest 驗證記錄於 `docs/HANDOFF_BATCH102.md`。


## Batch 103：冪等重放快照新鮮度與 membership 權限（2026-10-27）
[x] AMQ-1123 修正成功冪等重放：若 authenticated caller 仍是 room member，保留原 event／assessment，但回傳目前 revision 的 viewer-scoped snapshot，避免延遲重試把 client 狀態回退至舊 revision。
[x] AMQ-1124 保護離房者重放邊界：已離房的 authenticated player 重放原 `player.leave` 時仍取得原始結果，不因 requestId 命中而得到新的 membership-authorized room snapshot。
[x] AMQ-1125 新增延遲 answer replay regression：回合已 timeout／關閉後重放原答題命令，event／assessment 仍是原始物件，snapshot 則反映目前 closed round 與最新 revision；不重複評級或提交。
[~] AMQ-1126 Batch103 完整回歸、架構／語法／資料稽核／mapper／benchmark 與封包驗證詳見 `docs/HANDOFF_BATCH103.md`。


## Batch 104：snapshot revision 與 closed-room 邊界（2026-10-27）
[x] AMQ-1127 新增 `getSnapshot(sinceRevision)` future-revision regression：若 client 提供大於目前 revision 的值，回傳完整權威 snapshot，而非 `unchanged` 或偽造未來狀態。
[x] AMQ-1128 新增 closed room snapshot regression：保留 membership 的成員可取得 closed-room snapshot，並能以相同 revision 取得 unchanged response。
[x] AMQ-1129 新增空 closed room regression：最後一位玩家離開後，可信 state-machine caller 仍可取得空房間 snapshot，revision polling 也可回報 unchanged。
[~] AMQ-1130 Batch104 只補 state-machine tests，不修改 production code；完整驗證與交付詳見 `docs/HANDOFF_BATCH104.md`。


## Batch 105：私人自架帳號與每人 SRS 後端基礎（2026-10-28）
[x] AMQ-1131 已確定多人 SRS 產品方向：方案 A，私人自架、只供本人與朋友使用；管理者建立單次邀請碼，不開放陌生人自由註冊。
[x] AMQ-1132 新增 `server/database.cjs`：SQLite schema 包含 users、single-use invitations、per-user/per-source SRS schedule，啟用 foreign keys、WAL 與 busy timeout。
[x] AMQ-1133 新增 `server/account-service.cjs`：一次性管理者初始化、username 唯一性、scrypt password hash、邀請碼 hash／expiry／single-use、帳號驗證與管理者 member listing。
[x] AMQ-1134 新增 `server/srs-repository.cjs`：user identity 只從已驗證 session 傳入；AMQ／EMQ source isolation、既有 FSRS schema validation、revision compare-and-swap 與 conflict 409。
[x] AMQ-1135 新增 `server/http-server.cjs`、`server/start.cjs`：登入 session、HttpOnly/SameSite cookie、Origin 檢查、登入失敗限流、request body size limit、API auth 與靜態路徑限制。
[x] AMQ-1136 新增 `tests/server-auth-srs.integration.test.cjs`，實際 HTTP 驗證 bootstrap、invite-only signup、session、admin permissions、per-user/source isolation、revision conflict、cross-origin rejection、rate limit 與 restart persistence。
[x] AMQ-1137 新增 `docs/PRIVATE_SERVER.md` 並更新架構、驗收與 README，記錄 Node 22.5+、SQLite、API 契約、安全限制及未完成範圍。
[x] AMQ-1138 Batch106 已接入前端 setup/login/register/logout/invitation UI 與遠端 SRS bridge；未登入仍用本機 SRS，登入後載入 session 對應的伺服器排程。
[~] AMQ-1139 已加入 revision conflict／網路錯誤 fail-closed 與明確重新載入操作（重新載入會捨棄未同步變更）；離線佇列、自動重送與多端合併仍未實作。
[~] AMQ-1140 真實多人 transport、WebSocket、跨程序 room state／durable command idempotency、多 client E2E 與 HTTPS 公網部署尚未實作。
[x] AMQ-1141 Batch105 最終回歸：45/45 非-tooling tests、tooling 9/9、architecture 726/0、syntax 106/106、source audit／mapper／5-run benchmark PASS。
[x] AMQ-1142 Batch105 交付包驗證：Manifest 238 項，ZIP CRC PASS，解壓後缺檔 0／額外檔 0／hash mismatch 0。


## Batch 106：私人帳號 UI 與遠端 SRS 接線（2026-10-28）
[x] AMQ-1143 新增 `src/persistence/remote-srs-bridge.js`：以 memory-only storage 讀取 session 對應的 AMQ／EMQ 排程，序列化遠端 PUT 並逐次更新 revision；不讀寫 browser localStorage。
[x] AMQ-1144 `src/ui/quiz-panel.js` 新增 `configureSrsStores()`，支援本機／遠端／隔離空排程切換；遠端讀取失敗時不回退到共用本機 SRS，登出後恢復原本本機 store。
[x] AMQ-1145 新增 `src/ui/account-panel.js` 與 `src/index.html` 帳號區塊：首次 admin setup、登入、邀請碼註冊、admin 建立邀請、登出、SRS sync/conflict 狀態與重新載入操作。
[x] AMQ-1146 更新 `src/app.js` 生命周期接線與 `START_LOCAL.bat`，Node.js 22.5+ 時啟動私人 API，等 server listening 後再開瀏覽器；不符合時保留 static-only fallback 並明確提示帳號功能不可用。
[x] AMQ-1147 新增 `tests/remote-srs-bridge.test.cjs` 與 `tests/account-panel.integration.test.cjs`，驗證遠端 revision queue、conflict/network failure fail-closed、setup/invite/login/logout 與失敗時隔離本機排程。
[~] AMQ-1148 多裝置 conflict merge、離線佇列、自動重試、真實瀏覽器／多裝置 E2E 尚未完成；不可將模擬 DOM 測試當作瀏覽器驗收。
[x] AMQ-1149 Batch106 最終回歸：47/47 非-tooling tests、tooling 9/9、architecture 755/0、syntax 110/110、source audit／mapper／5-run benchmark PASS。
[x] AMQ-1150 Batch106 交付包驗證：Manifest 243 項、ZIP CRC PASS、解壓後缺檔 0／額外檔 0／hash mismatch 0。
[x] AMQ-1151 `server/start.cjs` 實際啟動 smoke test 通過：health API、`/src/` HTML、account-panel script 均可由 server 提供；測試資料庫使用暫存目錄並清理。


## Batch 107：取消邀請制、開放註冊與 Google OIDC（2026-10-28）
[x] AMQ-1152 產品決策更新：完成首次管理者 bootstrap 後開放一般帳密註冊；邀請碼不再是註冊前置條件。
[x] AMQ-1153 移除 account UI 中邀請碼輸入、管理者建立邀請按鈕與邀請結果區。
[x] AMQ-1154 移除活躍邀請建立 API 與邀請驗證註冊邏輯；舊 SQLite invitations table 僅為向後相容保留，不再由 API 使用。
[x] AMQ-1155 保護 bootstrap 邊界：第一位管理者建立前，拒絕一般註冊與 Google 首次登入，避免公開註冊搶先取得第一個帳號／管理者建立時機。
[x] AMQ-1156 新增 `server/google-oidc.cjs`：Google Authorization Code Flow、PKCE S256、一次性 state／nonce、JWKS RSA 簽章、issuer/audience/expiry/iat/nonce/azp 驗證。
[x] AMQ-1157 新增 Google OAuth 狀態 API 與 callback/session 接線；使用短效 HttpOnly SameSite=Lax state cookie，secret 只從環境變數取得。
[x] AMQ-1158 新增 Google 身分資料欄位與非破壞式 SQLite migration；以唯一 `sub` 關聯 Google 帳號，不請求 email 權限、不自動按 email 合併。
[x] AMQ-1159 Google OAuth 設定為選配；未設定時隱藏 Google 登入按鈕，帳密登入／註冊仍可用。
[x] AMQ-1160 新增 `tests/google-oidc.test.cjs`，覆蓋最小 scopes、Authorization Code + PKCE、JWT signature、issuer/audience/expiry/nonce、錯誤 claim 與未設定 OAuth。
[x] AMQ-1161 新增 `tests/database-google-migration.test.cjs`，覆蓋 Batch106 舊 SQLite schema migration、既有使用者保留與 Google sub 唯一性。
[x] AMQ-1162 更新 server auth integration，覆蓋開放註冊、bootstrap gate、mock Google callback、state 綁定、Google sub 重複登入解析同一使用者、個人 SRS session 隔離及邀請 API 移除。
[x] AMQ-1163 更新 `tests/account-panel.integration.test.cjs`，覆蓋 Google 配置狀態、登入方式顯示、一般帳號註冊與既有 remote SRS lifecycle。
[x] AMQ-1164 更新 `docs/PRIVATE_SERVER.md`、`docs/ARCHITECTURE.md`、`docs/ACCEPTANCE.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md` 與 `AI_START_HERE.md`，明確記錄公開註冊、OAuth 設定與限制。
[~] AMQ-1165 真實 Google OAuth client 設定與使用者瀏覽器登入尚未驗收；需由自架者在 Google Cloud Console 建立自己的 Client ID/Secret，不能在交付包中假造憑證。
[~] AMQ-1166 Google 帳號與一般帳密帳號尚無顯式 link/unlink 流程；禁止以 email 自動合併，兩種登入若分別註冊會有獨立 SRS。
[~] AMQ-1167 HTTPS 公網部署、反向代理、正式安全審查、離線佇列與多裝置合併仍未實作／驗收；不得把 mock OAuth tests 當成真實 Google E2E。
[x] AMQ-1168 新建 SQLite 不再建立废弃的 invitations table／expiry index，既有数据库不执行破坏性 DROP；清除已无对应 UI 的邀请结果 CSS。
[x] AMQ-1169 补充 account panel 的 Google OAuth 未配置情境测试，确认 Google 按钮隐藏且一般帐密注册仍可用。
[~] AMQ-1170 完成 Batch107 最终全量回归与 package audit；需以本批最后一次实际执行结果更新，不可引用中间或旧批次数据。
[~] AMQ-1171 生成 Batch107 ZIP 与 MANIFEST 后执行 CRC、文件清单、hash mismatch 及来源资产 hash 验证；完成后再将此项标为已完成。


## Batch 108：密碼門檻與曲庫來源可發現性（2026-10-28）
[x] AMQ-1172 將伺服器一般帳號密碼最短長度從 12 降至 8 字元；保留 128 字元上限、scrypt 參數與登入失敗限制。
[x] AMQ-1173 將首次管理者設定及一般註冊 UI 的文案／HTML `minlength` 同步至 8；登入表單不限制舊密碼長度。
[x] AMQ-1174 新增整合回歸：7 字元註冊回應 `AUTH_PASSWORD_INVALID`，8 字元註冊成功。
[x] AMQ-1175 更新帳號面板測試，確認前端最短長度與伺服器政策一致。
[x] AMQ-1176 曲庫更新面板增加 AMQ／EMQ 上游服務與 EMQ 上游 GitHub 專案連結，並標明它們不是可直接匯入的更新包。
[x] AMQ-1177 明確記錄內建曲庫為隨版本附帶的唯讀快照，更新套用仍須通過既有 checksum／schema／關聯／記錄驗證與 IndexedDB 原子提交。
[~] AMQ-1178 一鍵自動更新待建立可信任 AMQ＋EMQ bundle hosting、版本 manifest、checksum／簽章與相容性發布流程；目前無已驗證的固定更新端點，不得盲目從任意 URL 套用。
[~] AMQ-1179 真實瀏覽器表單互動、曲庫外部來源及一鍵更新 E2E 未驗收；Node 整合測試不等於瀏覽器驗收。
[x] AMQ-1180 Batch108 驗證：49/49 非-tooling test scripts PASS；tooling 9/9 PASS；architecture 769 passed／0 failed；全量 JS/CJS syntax PASS；source audit、mapper、5-run benchmark PASS。
[x] AMQ-1181 重新產生 Batch108 `MANIFEST.sha256`，並驗證 ZIP CRC、檔案清單、雜湊及唯讀來源資產 hash。


## Batch 109：曲庫遠端發布／下載流程（2026-10-28）
[x] AMQ-1182 新增 release bundle 產生工具，產生版本化 JSON 更新包及 latest.json manifest。
[x] AMQ-1183 Manifest 記錄 release version、格式相容範圍、bundle byte length／SHA-256、payload checksum 與來源數量。
[x] AMQ-1184 發布工具拒絕覆蓋既有版本化 bundle 或 latest.json，避免無聲改寫已發布產物。
[x] AMQ-1185 新增可選 manifest URL 設定檔，預設空字串，不假造公共發布端點。
[x] AMQ-1186 更新 UI 可檢查 manifest、下載同來源 bundle，限制 HTTPS／localhost、無 cookie、拒絕 redirect 與 100 MB 上限。
[x] AMQ-1187 下載後驗證 manifest 相容性、byte length、bundle SHA-256、payload checksum、schema、mapping 及作品關聯。
[x] AMQ-1188 遠端下載後顯示現有差異預覽，必須明確確認後才走既有 IndexedDB 原子套用。
[x] AMQ-1189 新增 release generator tooling regression 與遠端更新面板 mock-fetch regression。
[x] AMQ-1190 更新發布契約、架構／驗收、工作狀態、AI 開工指引及交接文件。
[~] AMQ-1191 公開固定 hosting／manifest URL 未指定；須決定可信任發布位置並部署後才能啟用公開預設一鍵更新。
[~] AMQ-1192 Ed25519 發布簽章／獨立公鑰驗證尚未實作；同源 SHA-256 不防止發布主機與 manifest 同時被竄改。
[~] AMQ-1193 真實瀏覽器／HTTPS hosting／CORS／IndexedDB transaction 與 reload E2E 尚待實機驗收。
[x] AMQ-1194 Batch109 驗證：49/49 non-tooling scripts、tooling 10/10、architecture 779/0、syntax 115/115、source audit／mapper／5-run benchmark PASS；最終 ZIP CRC PASS，Manifest 252 項，缺檔 0、額外檔 0、hash mismatch 0。


## Batch 110：Ed25519 曲庫發布簽章（2026-10-28）
[x] AMQ-1195 發布工具要求私鑰路徑並驗證 Ed25519 key type；無效 key 不應留下 bundle。
[x] AMQ-1196 Release manifest 以 canonical JSON 產生 Ed25519 簽章，包含 key ID 與 Base64 signature。
[x] AMQ-1197 前端先以固定 SPKI 公鑰驗證 manifest，簽章無效／缺失／key ID 不符時 fail closed。
[x] AMQ-1198 新增工具測試：產生的 manifest signature 可由配對公鑰驗證，發布既有檔案仍拒絕覆蓋。
[x] AMQ-1199 新增 UI regression：修改已簽署 manifest 的 releaseVersion 後簽章驗證失敗，bundle 不會被下載且不能套用。
[x] AMQ-1200 更新發布契約、架構、驗收、工作狀態與交接文件，說明自架金鑰設定與私鑰不得公開。
[~] AMQ-1201 官方固定 HTTPS hosting／manifest URL 尚未指定，未部署；不影響簽章驗證與自架發布工具。
[~] AMQ-1202 真實瀏覽器／HTTPS hosting／IndexedDB reload 驗收留待使用者最後集中測試。
[x] AMQ-1203 Batch110 全量自動化回歸：49/49 非-tooling scripts、tooling 13/13、architecture 783/0、syntax 117/117、source audit／mapper／5-run benchmark PASS。
[x] AMQ-1204 以正式來源產生本機簽章 release preview，並以 pinned public key 驗證 Ed25519 signature；不公開發布。
[x] AMQ-1205 核對 AMQ／EMQ 唯讀來源 SHA-256，與既有紀錄一致。
[x] AMQ-1206 重新產生 MANIFEST.sha256、完整 ZIP 並執行解壓／CRC／檔案清單／hash 驗證；私鑰不納入 ZIP。
[x] AMQ-1207 新增自架 Ed25519 keygen 工具，私鑰檔以 owner-only 權限建立並拒絕覆蓋既有 key。
[x] AMQ-1208 新增離線 release verifier，檢查 manifest 簽章、key ID、bundle byte length／SHA-256 與 payload checksum。
[x] AMQ-1209 新增 tooling regressions，驗證 keygen 權限／拒絕覆蓋、release verifier 成功與 bundle tampering 拒絕。


## Batch 111：SQLite 持久化登入 session（2026-10-28）
[x] AMQ-1210 新增 SQLite `sessions` table，以 token SHA-256 hash 為主鍵，記錄 user ID、建立時間與到期時間，並加上 expiry index。
[x] AMQ-1211 建立 session 時將隨機 bearer token 原文只交給 HttpOnly cookie；資料庫只寫入 SHA-256 hash。
[x] AMQ-1212 `currentUser()` 支援程序內快取與 SQLite 查找，並在每次授權時重新檢查到期時間及帳號存在。
[x] AMQ-1213 登出同時撤銷程序內快取與 SQLite session row；伺服器關閉不再刪除仍有效的 session。
[x] AMQ-1214 新增 HTTP integration regression：有效 session 在 server restart 後仍可使用，且不影響個人 SRS 隔離。
[x] AMQ-1215 新增 hash-only persistence regression，確認 cookie token 原文不存在 SQLite session row。
[x] AMQ-1216 新增精確 TTL 邊界 regression：12 小時到期前有效、到期時失效並刪除 session row。
[x] AMQ-1217 更新私人伺服器、架構、驗收、啟動器、README、AI 開工指南與下一階段提示；同步修正過期的密碼長度／session 記憶體說明。
[x] AMQ-1218 Batch111 最終驗證：49/49 非-tooling test scripts PASS、tooling 13/13、architecture 783/0、syntax 117/117、source audit／mapper／5-run benchmark PASS；唯讀來源 hash unchanged；最終 ZIP CRC PASS，Manifest 256 項、missing 0／extra 0／hash mismatch 0，且無 `.pem` 私鑰。

[x] AMQ-1219 Batch111 交付包 `AMQ_Full_Rebuild_Batch111_Handoff_20261028.zip` 已完成 ZIP CRC、Manifest、解壓檔案集合與 SHA-256 驗證。


## Batch 112：私人伺服器一致性備份與離線驗證（2026-10-28）
[x] AMQ-1220 新增 `tools/backup-private-server.cjs`，使用 SQLite `VACUUM INTO` 建立一致性 snapshot，避免盲目複製 live database 檔案。
[x] AMQ-1221 備份工具拒絕 source/output 相同、拒絕覆蓋既有目的檔，並以 exclusive/atomic 建立處理 race。
[x] AMQ-1222 備份後驗證 SQLite integrity check、foreign key check 與 users／sessions／srs_schedules schema。
[x] AMQ-1223 新增 `tools/verify-private-server-backup.cjs`，支援離線驗證並輸出 SHA-256／bytes／表筆數。
[x] AMQ-1224 POSIX 備份檔採 0600 權限；文件明確提醒備份含帳號、SRS 與有效 session token hash，需保密。
[x] AMQ-1225 新增 `tests/private-server-backup.test.cjs`，覆蓋一致性 snapshot、資料筆數、離線驗證、拒絕覆蓋、同路徑與損壞來源。
[x] AMQ-1226 Batch112 全量驗證：50/50 非-tooling scripts PASS、tooling 13/13、architecture 794/0、syntax 120/120、source audit／mapper／5-run benchmark PASS；唯讀來源 hash unchanged；ZIP／Manifest 驗證見交付紀錄。

[x] AMQ-1227 Batch112 交付包已完成 CRC、Manifest 檔案集合及 SHA-256 驗證；沒有缺檔、額外檔、hash mismatch 或 `.pem` 私鑰。


## Batch 113：Google 帳號明確連結／解除（2026-10-28）
[x] AMQ-1228 SQLite `users.password_enabled` migration 區分一般密碼登入與 Google-only 帳號；既有 Google-bound 帳號不會被錯標為有已知密碼。
[x] AMQ-1229 新增 `accountService.linkGoogleIdentity()`，以 Google `sub` 唯一約束連結目前已登入 AMQ user，拒絕連結到另一個 user。
[x] AMQ-1230 `/api/auth/google/link` flow 綁定 user ID；callback 要求同一個 session 仍有效，不能用另一個帳號完成原流程。
[x] AMQ-1231 新增 Google unlink API；只有保留 password login 的帳號可以解除 Google，避免 Google-only 使用者鎖在帳號外。
[x] AMQ-1232 新增已登入的 password setup/change API；已有密碼者必須驗證 current password，Google-only 使用者可設定新密碼。
[x] AMQ-1233 帳號 UI 新增連結／解除／設定密碼流程；顯示 Google-generated username，讓設定密碼後仍知道一般登入帳號。
[x] AMQ-1234 新增 server integration／migration／account-panel regressions，覆蓋 session binding、sub uniqueness、unlink precondition、password confirmation 與 legacy Google-only migration。
[~] AMQ-1235 Batch113 全量 regression、architecture／syntax、source audit／mapper／benchmark 與 ZIP／Manifest 完整性待本批最終驗證。


## Batch 114：AniList／MAL／VNDB feature adapters（2026-10-28）
[x] AMQ-1236 新增 AniList GraphQL adapter：media search、viewer profile、user media lists 與 SaveMediaListEntry mutation。
[x] AMQ-1237 AniList adapter 驗證 query inputs、page/perPage、media IDs、status／score／progress 與 GraphQL response/errors。
[x] AMQ-1238 新增 MAL v2 adapter：anime search、`/users/@me/animelist` 與 my-list-status update。
[x] AMQ-1239 MAL update 使用 application/x-www-form-urlencoded，並驗證 status、score、episode count 與 paging inputs。
[x] AMQ-1240 新增 VNDB Kana adapter：visual novel search 與 ID lookup，固定 API endpoint，驗證 `v<number>` IDs 與 response schema。
[x] AMQ-1241 三個 service-specific adapter 接入 index 載入順序，沿用通用 HTTPS/auth/rate-limit/abort/error boundary，不自行接觸 OAuth secret。
[x] AMQ-1242 新增 `tests/external-service-feature-adapters.test.cjs`，覆蓋 normalize、固定 endpoint、輸入驗證、認證 policy 與 payload contracts。
[~] AMQ-1243 OAuth authorization/token refresh、使用者操作 UI、服務資料映射回 AMQ personal library／watch status 與真實 API E2E 仍未完成；需服務憑證／產品操作接線，不以 mock tests 假稱完成。
[~] AMQ-1244 Batch114 全量 regression、architecture／syntax、source audit／mapper／benchmark 與 ZIP／Manifest 完整性待本批最終驗證。


## Batch 115：持久化多人房間 HTTP transport（2026-10-28）
[x] AMQ-1245 新增 `server/multiplayer-runtime.cjs`，隔離載入 bundled AMQ／EMQ data、mappers、answer evaluator、assessment engine 與 room service，建立可信 server-owned question pool。
[x] AMQ-1246 新增 `multiplayer_rooms`／`multiplayer_commands` SQLite tables，保存 authoritative room state、used question IDs、timeout assessments 與 durable idempotency result。
[x] AMQ-1247 新增 `server/multiplayer-host.cjs`，提供 create/list/join/dispatch/snapshot、per-room serialization、requestId fingerprint/replay 與 5,000-command per-room retention。
[x] AMQ-1248 新增 authenticated HTTP endpoints：room list/create/join/snapshot polling/commands；身份由登入 session 推導。
[x] AMQ-1249 Round start 的 question ID、round ID、duration 全由 server 產生；忽略 client correctness／grade／latency，使用 bundled question record 的 work-title assessor。
[x] AMQ-1250 Active-round snapshot 對其他玩家答案做 redaction；server timer 到 deadline 自動 close round，timeout assessment 僅回給對應玩家。
[x] AMQ-1251 新增 `exportState()` server persistence hook，回傳 detached/frozen authoritative state，並以 regression 保護。
[x] AMQ-1252 新增 `tests/multiplayer-http.integration.test.cjs` 與 `tests/multiplayer-host.integration.test.cjs`，驗證 authenticated room flow、server-owned round/grade、答案遮蔽、join/command replay、restart persistence、timeout 與 non-member rejection。
[~] AMQ-1253 多人前端 UI、既有 AudioService 整合、音訊同步、多人 SRS 自動寫入、WebSocket／多節點與真實 multi-client E2E 尚未完成。
[x] AMQ-1254 Batch115 全量 regression、architecture／syntax、source audit／mapper／benchmark 均通過；最終 ZIP／Manifest 驗證記錄於 `docs/HANDOFF_BATCH115.md`。

[x] AMQ-1255 Batch115 最終 ZIP CRC、Manifest 檔案集合及 SHA-256 驗證通過；無缺檔、額外檔、hash mismatch、私鑰或 `.git` metadata。


## Batch 116：Remote SRS 安全重試（2026-10-28）
[x] AMQ-1256 `remote-srs-bridge` 新增只針對 network error 的 `retryPending(source?)`，不會自動重試 revision conflict。
[x] AMQ-1257 重試前 GET 最新 server revision；只有 revision 與最後確認值一致時才重送本次登入工作階段內最新排程。
[x] AMQ-1258 revision 已變更時回報 `SRS_REVISION_CONFLICT`、不執行 PUT，並維持 fail-closed。
[x] AMQ-1259 帳號同步面板新增「重試未同步的 SRS 保存」按鈕；只在存在可重試的 network error 時顯示。
[x] AMQ-1260 新增 bridge tests：network recovery safe retry、remote revision drift no-write、conflict keeps writes blocked。
[x] AMQ-1261 新增 account-panel integration regression，驗證錯誤狀態顯示 retry action、重試成功後狀態恢復 synced。
[~] AMQ-1262 Durable offline queue across reload、multi-device merge 與 reliable unload flush 仍未完成；本批只保留 memory-only pending snapshot，避免未經身份／衝突確認寫入共享 storage。
[x] AMQ-1263 Batch116 全量 regression 54/54 scripts、tooling 13/13、architecture 836/0、syntax 128/128、source audit／mapper／5-run benchmark 全部通過。
[x] AMQ-1264 Batch116 最終 ZIP CRC、Manifest 檔案集合及 SHA-256 驗證通過；無缺檔、額外檔、hash mismatch、私鑰或 `.git` metadata。


## Batch 117：多人 HTTP client 基礎（2026-10-28）
[x] AMQ-1265 新增 `src/multiplayer/http-client.js`，統一 authenticated same-origin room list/create/join/snapshot/command API。
[x] AMQ-1266 command helper 自動產生 requestId，並允許明確傳入既有 requestId 以支援冪等重試。
[x] AMQ-1267 HTTP client 在發送前驗證 room ID、ready 與 answer 型別，避免無效輸入觸網。
[x] AMQ-1268 server error code/status/details 原樣保留，尤其不吞掉 `ROOM_REVISION_CONFLICT`；網路錯誤與 AbortError 分流。
[x] AMQ-1269 新增 `tests/multiplayer-http-client.test.cjs`，5/5 PASS，覆蓋 route、credentials、request body、validation、conflict、network 與 abort。
[x] AMQ-1270 將 client 加入 `src/index.html` 載入順序及 architecture checker 的順序契約。
[~] AMQ-1271 多人 UI、單一 AudioService/Clock 協調、重連 polling lifecycle、多人 SRS 與實機多客戶端驗收尚未完成。
[x] AMQ-1272 Batch117 regression：55 個 test scripts 逐檔驗證；client 5/5、tooling 13/13、architecture 850/0、syntax 130/130、source audit／mapper／benchmark PASS。部分重型測試需較長 timeout；並行時兩個測試曾短暫失敗，單獨重跑均通過。
[x] AMQ-1273 Batch117 最終 ZIP CRC、Manifest 檔案集合及 SHA-256 驗證通過；交付包不含 `.git` metadata。


## Batch 118：多人房間 Session／Controller（2026-10-28）
[x] AMQ-1274 新增 `src/multiplayer/room-session.js`，以單一 session owner 管理 room ID、snapshot/revision、timeout assessment 與連線狀態。
[x] AMQ-1275 使用非重疊 recursive timeout polling；`stop()`／`dispose()` 清理 timer、abort in-flight request，並以 generation guard 阻止遲到結果發布。
[x] AMQ-1276 Snapshot revision 僅允許單調前進；unchanged、較舊 revision 與同 revision 不同 payload 不覆蓋目前權威狀態。
[x] AMQ-1277 網路失敗採有上限的退避重試，恢復後回到正常輪詢間隔。
[x] AMQ-1278 命令網路錯誤保留原 requestId／payload／expectedRevision，即使輪詢已觀察到較新 revision，重試仍維持原冪等命令語義。
[x] AMQ-1279 新增 `tests/multiplayer-room-session.test.cjs`，7/7 PASS，覆蓋 polling lifecycle、abort／stale response、restart generation race、revision、network recovery、command retry/conflict 與 dispose。
[x] AMQ-1280 將 room session 接入 `src/index.html` script order，並更新 architecture checker。
[~] AMQ-1281 多人 UI 尚未接入；AudioService／QuizSession／QuizClock 播放 owner 交接、多人音訊同步、多人 SRS 與真實 multi-client E2E 仍未完成。
[x] AMQ-1282 本批 56/56 test scripts 逐檔 exit 0；controller 7/7、tooling 13/13、architecture 864/0；source audit／mapper／5-run benchmark PASS，AMQ／EMQ 唯讀來源 hash 與既有紀錄一致。
[x] AMQ-1283 Manifest 276 entries、missing 0／hash mismatch 0／extra work files 0；ZIP CRC PASS，277 files，ZIP missing 0／extra 0。最終文件更新後重新產生封包並重驗通過。


## Batch 119：單一播放權協調（2026-10-28）
[x] AMQ-1284 新增 `src/audio/playback-coordinator.js`，提供獨占 owner lease、同 owner idempotent acquire、撤銷回呼、release/dispose 與錯誤隔離。
[x] AMQ-1285 `src/app.js` 建立 app-scoped playback coordinator，確保 quiz panel 先 dispose 再 dispose coordinator。
[x] AMQ-1286 `src/ui/quiz-panel.js` 將共用 coordinator 注入既有 QuizSession，未建立第二套 AudioService／QuizClock。
[x] AMQ-1287 `src/engine/quiz-session.js` 在回合取得 lease；owner 被取代時停止音訊／clock、取消 auto-next、結束回合並清除計時；正常 end/reset/dispose 釋放 lease。
[x] AMQ-1288 新增 `tests/playback-coordinator.test.cjs`，5/5 PASS；擴充 `tests/quiz-session.test.cjs`，23/23 PASS，覆蓋 owner transfer、stop audio/clock、release 與 dispose。
[x] AMQ-1289 更新 `src/index.html`、`tests/tests.html` 與 architecture checker 的載入順序。
[~] AMQ-1290 多人 UI 已在 Batch120 接入房間流程與 coordinator lease；真正多人音訊播放／同步、多人 SRS、WebSocket／多節點及真實多客戶端驗收仍未完成。
[x] AMQ-1291 Batch119 修改後 58/58 test scripts 逐檔 exit 0；architecture 879/0、tooling 13/13、source audit／mapper／5-run benchmark PASS。
[x] AMQ-1292 最終 Manifest 279 entries、missing 0／hash mismatch 0／extra work files 0；ZIP CRC PASS，280 files，ZIP missing 0／extra 0。

[x] AMQ-1293 新增 `docs/HANDOFF_BATCH119.md` 作為本次完整交接入口，保留 Batch118 原始交接文件作為歷史紀錄。


## Batch 120：多人房間最小 UI 接線（2026-10-28）
[x] AMQ-1294 新增 `src/ui/multiplayer-panel.js`，使用既有 HTTP client／RoomSession 提供建立房間、大廳列表、加入房間、準備、房主開始、提交答案、離開與關閉房間操作。
[x] AMQ-1295 UI 只呈現 RoomSession 的權威快照與伺服器 revision；房間命令沿用 session 的 requestId／expectedRevision／重試契約，不在 UI 自行生成題目或評級。
[x] AMQ-1296 使用 `/api/auth/me` 取得目前登入者 ID，以伺服器 hostId／player ID 判斷房主操作與準備狀態；未登入或身份無法確認時不啟用需要身份的控制。
[x] AMQ-1297 多人回合啟用共用 playback coordinator lease；owner 被取代時不會反覆搶回 lease，離開／關閉／回合結束時釋放。
[x] AMQ-1298 新增 `tests/multiplayer-panel.integration.test.cjs`，驗證大廳、建立、準備、開始回合、提交答案與 dispose。
[~] AMQ-1299 多人 UI 明確揭露音訊題目投影尚未接線；目前不是可完整遊玩的多人猜歌模式。AudioService／QuizClock 同步、回合倒數 UI、多人 SRS、WebSocket／多節點與真實 browser multi-client E2E 尚未完成。
[x] AMQ-1300 Batch120 最終驗證：58/58 非-tooling `tests/*.test.cjs` 逐檔 exit 0；`node --test tests/tooling.test.cjs` 13/13；architecture 893/0；source audit／full mapper／5-run benchmark PASS；唯讀來源 SHA-256 unchanged。最終 ZIP／Manifest 驗證記錄於 `docs/HANDOFF_BATCH120.md`。

## Batch 121：多人安全題目投影（2026-10-28）
[x] AMQ-1301 server runtime 僅以可信 question map 產生玩家可見題目投影，不暴露作品／歌名／歌手／別名／完整 record。
[x] AMQ-1302 host 將安全投影附加於 active-round snapshot，涵蓋命令、polling 與 idempotent replay。
[x] AMQ-1303 HTTP multiplayer integration test 驗證投影 identity、音源 URL protocol 與答案資料不外洩。
[x] AMQ-1304 Batch122 將多人音訊接入 app-scoped 共用 AudioService；lease revoke／離房／非 active round／dispose 取消播放並清理資源。
[x] AMQ-1305 server snapshot 提供 serverNow anchor；多人 UI 使用既有 QuizClock 顯示 deadline 倒數，timeout 不由 client 判分；真實多客戶端驗收仍阻塞。
[x] AMQ-1306 Batch122 全量非-tooling tests 58/58、tooling 13/13、architecture 893/0、source audit／full mapper／5-run benchmark 通過；Manifest／ZIP 由本批最終交付流程驗證。


## Batch 122：多人音訊與倒數生命週期整合（2026-10-28）
[x] AMQ-1307 app 建立單一 AudioService，注入單人與多人面板；QuizSession 對注入服務保留外部所有權，不會在單次 session dispose 時釋放 app service。
[x] AMQ-1308 MultiplayerPanel 僅使用 server projection 的 roundId/questionId/audioCandidates，驗證身份匹配與 HTTP(S) URL 後呼叫既有 AudioService。
[x] AMQ-1309 多人音訊新增播放／停止控制、播放狀態顯示與全候選失敗訊息。
[x] AMQ-1310 playback lease revoke 時取消共用 AudioService、禁止再次搶權；離房／非 active round／dispose 清理音訊、Clock、listener 與 lease。
[x] AMQ-1311 server projected snapshot 提供 serverNow，UI 以 serverNow 與 deadlineAt 錨定既有 QuizClock；client 倒數只呈現，不負責判分或 timeout authoritative decision。
[x] AMQ-1312 MultiplayerPanel integration 覆蓋投影候選傳遞、倒數顯示、全候選失敗、lease revoke、離房與 dispose。
[x] AMQ-1313 Host integration 覆蓋 active snapshot serverNow 與安全音源投影。
[x] AMQ-1314 58/58 非-tooling test scripts、tooling 13/13、architecture 893/0、source audit、full mapper、5-run benchmark 全部 PASS。
[~] AMQ-1315 真實瀏覽器／多 client E2E 仍因既有瀏覽器執行路徑 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞；取得可用瀏覽器環境後再驗收。
[x] AMQ-1316 Batch123 覆蓋 questionId／roundId mismatch、不安全 URL、空候選不可播放，以及 polling offline→connected 後保留權威 active round。
[x] AMQ-1317 Batch124 將 server assessment → source-aware SRS write 實作為同一 SQLite transaction，具 event idempotency／conflict protection。
[ ] AMQ-1318 追查真實音源失敗診斷、搜尋建議鍵盤操作與舊版資料相容性。
[x] AMQ-1319 QuizSession 在 playback lease 被撤銷後忽略共享 AudioService 後續事件；23/23 QuizSession tests 通過。


## Batch 123：多人投影失效／重連回歸（2026-10-28）
[x] AMQ-1320 收緊 safe projection：roundId/questionId 必須一致、候選非空、URL 限 HTTP(S)、kind 只允許 audio 或未提供。
[x] AMQ-1321 播放事件重新驗證 projection 與候選，不只依賴 disabled button。
[x] AMQ-1322 integration test 覆蓋 questionId mismatch、roundId mismatch、unsafe URL、empty candidates 及有效新投影恢復播放。
[x] AMQ-1323 integration test 覆蓋 polling network failure 後恢復連線且不丟失 authoritative active round。
[x] AMQ-1324 server round closed 後停止本地音訊／clock 並停用播放按鈕。
[x] AMQ-1325 非-tooling 57 個 test scripts 皆有逐檔成功證據；其中 54 個於長批次通過，尾段 3 個分開重跑成功；修改後 multiplayer panel test 再次通過。
[x] AMQ-1326 tooling 13/13、architecture 893/0、source audit／full mapper／5-run benchmark PASS。
[~] AMQ-1327 真實瀏覽器／多 client E2E 仍受已知瀏覽器執行政策阻擋。
[x] AMQ-1328 Batch124 完成多人 SRS server-side write，驗證 AMQ／EMQ source isolation、事件冪等、衝突拒絕、transaction rollback 與 timeout write。


## Batch 124：多人 SRS 原子寫入（2026-10-28）
[x] AMQ-1329 新增 `srs_assessment_events` SQLite table，以 user/event 唯一鍵持久化事件指紋與結果。
[x] AMQ-1330 SRS repository 新增 transaction-scoped assessment write，重複相同事件回放不重複更新 schedule；不同 payload 以 conflict 拒絕。
[x] AMQ-1331 只更新已入庫且未暫停的 SRS 卡片；不自動 enroll，不修改 suspended card。
[x] AMQ-1332 server host 只使用可信 round questionId／playerId／assessment 建立 SRS event；MIX 按實際歌曲來源寫入 AMQ 或 EMQ。
[x] AMQ-1333 room state、command idempotency record、SRS schedule 與 assessment event 同一 SQLite transaction；SRS failure 時整個 command rollback。
[x] AMQ-1334 answer submission 與 server timeout assessment 自動寫入；同一回合同一玩家至多一個事件。
[x] AMQ-1335 HTTP integration 覆蓋 server grade、SRS revision／card update、timeout、source isolation、event replay／conflict、restart replay 與 transaction rollback。
[x] AMQ-1336 58/58 非-tooling scripts、tooling 13/13、architecture 893/0、source audit／full mapper／5-run benchmark 全部通過；ZIP／Manifest 於交付步驟驗證。
[x] AMQ-1337 Batch125 遮罩音訊錯誤來源中的 URL path/query/userinfo；確認答案建議已接線，15 項鍵盤／IME／pointer 測試既有且通過。


## Batch 125：音訊診斷與答案建議驗收（2026-10-28）
[x] AMQ-1338 `quiz-panel` 新增安全音訊來源標籤；HTTP(S) source 只顯示 host，其他來源移除控制字元與 query／fragment 並限制長度。
[x] AMQ-1339 QuizPanel integration 驗證診斷保留來源 host／format／失敗原因，且不洩漏完整 URL path 或 query token。
[x] AMQ-1340 答案建議功能盤點確認已支援單答案與全答案欄位、ArrowDown／ArrowUp、Enter 選取不提交、Escape、IME composition、pointerdown 與 dispose；既有 15 項 tests PASS，無重複實作。
[x] AMQ-1341 非-tooling 58/58、tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
[~] AMQ-1342 真實瀏覽器音訊／CORS／multi-client E2E 仍阻塞。
[~] AMQ-1343 Batch126 已修正 PUT response 遺失後的安全重試；跨 reload durable queue 仍未實作，需 user-ID-bound IndexedDB／pending event contract 與可用瀏覽器驗收。


## Batch 126：Remote SRS response-lost reconciliation（2026-10-28）
[x] AMQ-1344 增加 stable JSON schedule equality，比對時不受 object key order 影響。
[x] AMQ-1345 PUT 可能已在 server commit 但 response 遺失時，若 GET schedule 與 pending payload 完全一致，安全認定已提交並不重送 PUT。
[x] AMQ-1346 若 server revision 改變且 schedule 不同，仍 fail-closed 並拒絕覆蓋。
[x] AMQ-1347 Remote SRS tests 覆蓋 committed-but-response-lost、普通 network retry、revision conflict 與後續寫入恢復。
[x] AMQ-1348 非-tooling 58/58、tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
[x] AMQ-1349 Batch127 實作 user-ID-bound IndexedDB pending queue、ordered full-schedule writes、response-lost reconciliation、明確 discard 與持久化失敗 fail-closed；真實瀏覽器 E2E 仍阻塞。


## Batch 127：Remote SRS durable queue（2026-10-28）
[x] AMQ-1350 新增內建 IndexedDB pending-store adapter，key 依 userId/source 隔離，不讀寫共用 localStorage。
[x] AMQ-1351 AccountPanel 將 authenticated user ID 傳給 bridge；不支援 IndexedDB 時明確顯示 memory-only warning。
[x] AMQ-1352 保存 base revision／base schedule／in-flight／latest payload；同一時間多個完整 schedule 更新可合併並維持 revision 順序。
[x] AMQ-1353 Bridge recreation 後恢復 pending schedule；server commit + lost response 可辨識已提交，不重複 PUT。
[x] AMQ-1354 user isolation、revision conflict、explicit discard、queue delete failure fail-closed 有 regression tests。
[x] AMQ-1355 58/58 非-tooling scripts、tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
[~] AMQ-1356 真實瀏覽器 IndexedDB transaction／quota／reload／tab-close E2E 尚未驗收；fake IndexedDB 測試不等於 browser acceptance。


## Batch 129：備份／還原舊 envelope 相容矩陣（2026-10-28）
[x] AMQ-1357 擴充 `tests/backup-restore.test.cjs`，涵蓋錯誤 format、formatVersion 0／未來版本／小數／字串、缺少 payload.values、未知 payload schema、未知 storage key、非字串 raw value 與 checksum mismatch。
[x] AMQ-1358 覆蓋 malformed JSON envelope 與 checksum 正確但已知 key 內容為無效 JSON 的分層拒絕理由。
[x] AMQ-1359 驗證 version-1 JSON 字串匯入、explicit null 只刪除列入備份的 key、未列入的既有 key 保持不變。
[x] AMQ-1360 保留舊 settings schema、AMQ／EMQ SRS provenance、播放歷史、partial envelope 與 rollback failure 的既有回歸測試。
[x] AMQ-1361 備份／還原 targeted regression：10/10 scenarios PASS；全量 57 個非-tooling scripts 逐檔 exit 0（第一輪到達工具時限前 53 個通過，剩餘 4 個分開重跑成功）；tooling 13/13、architecture 893/0、source audit／full mapper／5-run benchmark PASS。
[~] AMQ-1362 真實瀏覽器檔案下載／選取、storage quota、跨分頁與 reload E2E 仍未驗收；Node 測試不得替代實機驗收。


## Batch 130：查詢篩選交叉矩陣擴充（2026-10-28）
[x] AMQ-1363 `tests/filter-matrix.test.cjs` 將 `includeUnknownYear` 從原本與 dimension mask 綁定的條件拆開，確保它獨立於其餘 filter 維度組合。
[x] AMQ-1364 將 query 與 source-aware `animeId` 納入參考 predicate 與交叉測試；十個條件維度 × includeUnknownYear true/false 共 2,048 組，比對 production catalog 與獨立 expected predicate。
[x] AMQ-1365 增加多值 source/type 篩選回歸，驗證單一 facet 內 OR、不同 facet 間 AND，保留原始順序。
[x] AMQ-1366 保留並重跑年份上下界／未知年份、分頁前總數、降冪年份排序的 missing-last 行為與 facet 忽略自身條件但保留其他條件的既有檢查。
[x] AMQ-1367 `node tests/filter-matrix.test.cjs`：2,048/2,048 交叉組合 PASS，其他 filter／facet assertion PASS；backup restore matrix 10/10 PASS。
[~] AMQ-1368 本批修改均為 Node 測試覆蓋；真實瀏覽器篩選互動、跨分頁狀態與大量曲庫 UI 效能仍未驗收。
[x] AMQ-1369 Batch130 Manifest 292 entries；缺少／額外／雜湊不符均為 0。ZIP 293 files，CRC PASS，ZIP missing／extra 0，未包含 `.pem`／`.key` 私鑰檔。


## Batch 131：出題池跨模組 eligibility 矩陣（2026-10-28）
[x] AMQ-1370 `tests/quiz-panel.test.cjs` 新增獨立參考 predicate，不呼叫 QuizPanel 的 production eligibility closure 產生預期值。
[x] AMQ-1371 覆蓋 8 個設定維度（year range、includeUnknownYear、animeType、difficulty bounds、songType、watchStatus、source-aware custom list、SRS enabled）× AMQ／EMQ／MIX 三模式，共 768 組 pool eligibility assertion。
[x] AMQ-1372 Matrix 明確驗證 AMQ song/work blacklist 不錯誤套用到 EMQ；同數字 anime/work ID 仍按 source 隔離；缺失 EMQ metadata 不會被猜測補值。
[x] AMQ-1373 驗證 SRS 開關只改變 selection weighting，不改變 eligible pool；既有 quiz-pool tests 的弱逾期／due／new／future 權重順序與 MIX 約 2:1 source weighting 仍通過。
[x] AMQ-1374 Targeted：quiz panel integration PASS、quiz-pool 10/10、quiz-session 23/23、personal library store 10/10、SRS store 19/19。
[x] AMQ-1375 Full regression：58/58 非-tooling test scripts 逐檔 exit 0（分三組與 source-runtime 單獨執行）；tooling 13/13、architecture 893/0、source audit／full mapper／5-run benchmark PASS。
[~] AMQ-1376 真實瀏覽器篩選互動、跨分頁更新、音訊可聽性及 Candidate302 舊規則相容仍未驗收；Node matrix 不代表 browser E2E。

[x] AMQ-1377 Batch131 Manifest／ZIP 驗證：最終 Manifest entries 與工作檔案集合一致；ZIP CRC、檔案集合及 SHA-256 於交付流程重新驗證，未包含私鑰檔。


## Batch 132：Remote SRS 帳號切換 stale callback 防護（2026-10-28）
[x] AMQ-1378 `src/ui/account-panel.js` 新增 auth generation guard；過期的 `/api/auth/me`、bootstrap refresh 或 user-scoped bridge connect 不得覆蓋較新的帳號狀態。
[x] AMQ-1379 `activateUser()` 在 connect 成功與失敗路徑都核對 generation、disposed 與目前 user ID；stale bridge 立即 close，不 attach 到 QuizPanel。
[x] AMQ-1380 `refreshRemoteSchedules()` 在 flush／discard／connect 邊界驗證 generation 與 expected user ID，避免過期 reload 更新新帳號狀態。
[x] AMQ-1381 AccountPanel dispose 後，`render()`／message／error helper 不再更新 DOM；已移除使用者時才 detach 舊 bridge，初始 guest boot 不再多發一次 null SRS configuration。
[x] AMQ-1382 `tests/account-panel.integration.test.cjs` 新增兩個 deferred-response regression：舊 `/api/auth/me` 遲到，以及舊 user bridge connect 遲到；兩者均不得取代當前帳號或重複 attach bridge。
[x] AMQ-1383 `account-panel.integration.test.cjs` PASS；`remote-srs-bridge.test.cjs` 12/12 PASS；全量 58/58 非-tooling scripts、tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
[~] AMQ-1384 真實瀏覽器多分頁、IndexedDB quota／reload／tab-close E2E 仍未驗收；本批 deferred tests 僅證明非同步競態契約。

[x] AMQ-1385 Batch132 Manifest／ZIP 驗證：最終 Manifest 294 entries，缺少／stale／hash mismatch 皆為 0；ZIP 295 files、CRC PASS、缺少／額外 0，未包含 `.pem`／`.key` 私鑰檔。


## Batch 133：多人 deadline／timeout／SRS event race 回歸（2026-10-28）
[x] AMQ-1386 移除 `server/multiplayer-host.cjs` 中重複且完全相同的 `requireMember()` guard；保留單一權限檢查，不改變行為。
[x] AMQ-1387 `tests/multiplayer-http.integration.test.cjs` 在 server clock 精確到達 deadline 時，並行提交玩家答案與兩個 snapshot 請求。
[x] AMQ-1388 驗證 deadline 後的 answer 不得成功；逾時後所有 snapshot 看到相同 lobby phase，只有該玩家本人可取得自己的 timeout assessment。
[x] AMQ-1389 查詢 `srs_assessment_events`，驗證同一 room／round／player timeout 只持久化一個事件，SRS revision 僅增加一次。
[x] AMQ-1390 `multiplayer-http.integration.test.cjs` 與 `multiplayer-host.integration.test.cjs`：2/2 PASS；server／test syntax check PASS。全量其餘 55 scripts 依 Batch132 證據通過，修改後的兩個多人整合腳本重新執行通過。
[~] AMQ-1391 真實多 client／跨程序併發 E2E 仍未驗收；本批是同一 server instance 的 HTTP／SQLite 整合測試，不能宣稱多節點驗收。


## Batch 134：多人 HTTP 安全邊界回歸（2026-10-28）
[x] AMQ-1392 新增 `server-auth-srs.integration.test.cjs` 的多人 API boundary integration：未登入無法列出 lobby 或讀取 room snapshot。
[x] AMQ-1393 驗證 state-changing multiplayer room create 遇到異 origin 回傳 403／`REQUEST_ORIGIN_INVALID`，且不建立房間。
[x] AMQ-1394 驗證 malformed JSON 回傳 400／`REQUEST_JSON_INVALID`，超過 `BODY_LIMIT_BYTES` 的 body 回傳 413／`REQUEST_BODY_TOO_LARGE`。
[x] AMQ-1395 稽核既有 server guards：所有 mutation 共用 same-origin 檢查；room routes 要求登入；host/runtime 驗證 source、capacity、member、host privilege、requestId、expectedRevision、server deadline；room command service 已有每 player 60 commands／10s rate limit。
[x] AMQ-1396 `server-auth-srs.integration.test.cjs` 7/7 PASS；58/58 非-tooling scripts、tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
[~] AMQ-1397 Room creation 本身沒有獨立的 per-user/IP rate limit／全域 active-room cap；login／registration attempt maps 也需評估 expired-key cleanup。屬資源保護設計風險，現有產品沒有明確 limit policy，本批不臆定破壞性上限；後續以可設定的 conservative defaults／cleanup 設計處理。


## Batch 135：有界 auth attempt tracking 與房間建立資源限制（2026-10-28）
[x] AMQ-1398 `server/http-server.cjs` 的 login／registration attempt maps 新增週期清理與硬容量；預設每張 map 最多 4,096 IP entries，每 60 秒最多觸發一次掃描，依各自 15 分鐘／1 小時 window 清除過期項目。
[x] AMQ-1399 新增 `pruneAttemptEntries()`／`setBoundedAttemptEntry()`，保證新 IP 進入時 map 不會超過設定容量；可由 `authAttemptMapMaxEntries`、`authAttemptCleanupIntervalMs` 設定，並驗證 option 範圍。
[x] AMQ-1400 `server/multiplayer-host.cjs` 新增 per-owner active-room cap（預設 10）與建立頻率限制（預設 10 次／60 秒），owner timestamp map 有界（預設 10,000 owners）並清理過期窗口。
[x] AMQ-1401 `server/http-server.cjs` 將房間限制設定傳給 host；可透過 `multiplayerMaxActiveRoomsPerOwner`、`multiplayerMaxRoomCreationsPerWindow`、`multiplayerRoomCreationWindowMs`、`multiplayerMaxRoomCreationOwners` 調整。
[x] AMQ-1402 超過 active-room cap 回傳 409／`ROOM_OWNER_ACTIVE_LIMIT`；超過建立頻率回傳 429／`ROOM_CREATE_RATE_LIMITED`，若有 `retryAfterMs`，HTTP 會附標準 `Retry-After` header。
[x] AMQ-1403 回歸覆蓋 expired map cleanup／容量、active cap、close 後釋放、rate window reset、既有 snapshot／room.close 不受建立限制影響；server-auth 8/8、multiplayer HTTP 2/2 PASS。
[x] AMQ-1404 全量 58/58 非-tooling scripts、tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
[x] AMQ-1405 Closed room retention 安全盤點：member-authorized snapshot、requestId replay 與 SRS event 仍依賴歷史資料；決定不刪 SQLite rows，改以熱快取淘汰降低常駐記憶體。持久化 retention policy 仍未實作。


## Batch 136：Closed room 熱快取淘汰與重啟惰性載入（2026-10-28）
[x] AMQ-1406 啟動載入改為只建立非 closed room 的 hot service；SQLite 有效 `phase=closed` rows 不會被載入常駐 `rooms` Map，無效 JSON 仍保留既有錯誤路徑。
[x] AMQ-1407 `roomEntry()` 新增 SQLite lazy load；closed room 只供當次授權 snapshot／command replay 使用，不重新進入 hot cache。
[x] AMQ-1408 room phase 成功轉為 closed 後清除 timer 並立即淘汰 hot entry；active rooms 仍可在 restart 後恢復。
[x] AMQ-1409 `runSerialized()` 在最後一個排隊 operation 完成後刪除該 room queue tail，避免歷史 room 的 Promise 永久留在 Map。
[x] AMQ-1410 新增 `tests/multiplayer-host-retention.test.cjs`，覆蓋 closed row／command record 保留、重啟 snapshot、非成員拒絕、close command replay 與 active room recovery。
[x] AMQ-1411 Targeted retention／host／HTTP tests 4/4 PASS；全量 58/58 非-tooling scripts、tooling 13/13、architecture 900/0、source audit／mapper／5-run benchmark PASS。
[!] AMQ-1412 Durable closed-room deletion／retention policy 仍阻塞於未定義的歷史查閱與 request replay 保證期限；未經證據不刪 room／command／SRS rows。137 個 JS/CJS syntax checks PASS；最終 Manifest／ZIP 核對見 Batch136 handoff。


## Batch 137：唯讀 SQLite 完整性診斷與歷史表覆蓋（2026-10-28）
[x] AMQ-1413 盤點 `account-service.cjs`，確認目前沒有帳號刪除 API；不新增未經產品決策的 user deletion／cascade 行為。
[x] AMQ-1414 新增 `server/database-integrity.cjs`，共用 `integrity_check`、`foreign_key_check`、必要表檢查與核心／SRS／multiplayer table counts。
[x] AMQ-1415 `backup-private-server.cjs`／`verify-private-server-backup.cjs` 使用共用檢查器，且對舊資料庫缺少 optional history tables 保持相容。
[x] AMQ-1416 新增唯讀 `tools/inspect-private-server-database.cjs`，不建立資料庫、不執行 migration、不寫入資料；回報表清單、筆數、檔案大小與 SHA-256。
[x] AMQ-1417 `tests/database-integrity.test.cjs` 覆蓋 read-only byte equality、多人／SRS history counts、孤兒 command foreign-key violation、缺檔與損壞 DB。
[x] AMQ-1418 `tests/private-server-backup.test.cjs` 確認 backup／verify 都報告 multiplayer room／command 與 SRS event counts；targeted tests 5/5 PASS。
[x] AMQ-1419 全量 71/71 非-tooling scripts、tooling 13/13、architecture 909/0、source audit／mapper／5-run benchmark 與 140 個 JS/CJS syntax checks PASS。
[!] AMQ-1420 歷史 room／command／SRS rows 的自動刪除仍阻塞於未定義的查閱與 replay 保證期限；只提供診斷，不做資料清理。


## Batch 138：多人歷史資料唯讀保留量報告（2026-10-28）
[x] AMQ-1421 新增 `tools/report-multiplayer-retention.cjs`，read-only 統計 active／closed／unknown phase rooms、room update 時間範圍、command replay 數量與每房最大值、SRS assessment event 數量／時間範圍。
[x] AMQ-1422 報告不輸出 room ID、玩家名稱、答案、request ID 或 fingerprint；缺少 optional tables 時回報 tablePresent=false，不執行 migration／資料寫入。
[x] AMQ-1423 新增 `tests/multiplayer-retention-report.test.cjs`，覆蓋有效／closed／invalid JSON rooms、command／SRS history、敏感欄位不外洩、唯讀 byte equality、舊 schema 與 missing path；targeted 2/2 PASS。
[x] AMQ-1424 最終全量驗證於 Batch139 完成：61/61 非-tooling scripts、tooling 13/13、architecture 925/0、source audit／mapper／5-run benchmark、143 個 JS/CJS syntax checks PASS。
[!] AMQ-1425 不自動清除 closed room／command／SRS history；retention window 與 command replay 保證期限仍未定義。


## Batch 139：備份後多人歷史語義保留驗證（2026-10-28）
[x] AMQ-1426 新增 `tests/multiplayer-backup-semantics.test.cjs`，以真實 temporary SQLite fixture 建立 closed room、room.close idempotency record、timeout assessment 與 SRS event。
[x] AMQ-1427 透過正式 backup／verify tools 後逐欄比較 room state、used-question IDs、timeout assessment、command fingerprint/result/timestamp 與 SRS event identity/status/revision/result。
[x] AMQ-1428 對備份檔以 read-only connection 建立 host，確認 closed snapshot／player timeout assessment／room.close requestId replay 仍有效；targeted 1/1 PASS。
[x] AMQ-1429 最終 61/61 非-tooling scripts、tooling 13/13、architecture 925/0、source audit／mapper／5-run benchmark、143 個 JS/CJS syntax checks PASS；Manifest／ZIP CRC／檔案集合與雜湊核對通過。


## Batch 140：舊 schema 可見性與 optional table inventory（2026-10-28）
[x] AMQ-1430 核對 `srs-repository.cjs` 既有 event ID／fingerprint idempotency；相同事件 replay 不增加 revision，不同評級 payload 回傳 conflict，既有 HTTP regression 有證據，未重寫穩定邏輯。
[x] AMQ-1431 `server/database-integrity.cjs` 回傳 `missingOptionalTables`，明確揭露缺少的 SRS assessment／multiplayer room／command tables。
[x] AMQ-1432 read-only inspector、backup、verify outputs 均輸出 optional history table 缺漏，核心 integrity PASS 不再隱去 schema capability 差異。
[x] AMQ-1433 `tests/database-integrity.test.cjs` 新增 legacy schema regression，確認舊 schema 不被自動 migration，缺少的 optional tables 被明確列出。
[~] AMQ-1434 Batch140 修改後全量 61 個非-tooling scripts、tooling、architecture、source audit／mapper／benchmark、syntax 與 ZIP 待收尾。


## Batch 141：跨工具 SQLite diagnostics 一致性（2026-10-28）
[x] AMQ-1435 `tests/database-integrity.test.cjs` 使用同一 temporary DB fixture 建立 active／closed rooms、command replay 與 SRS assessment event。
[x] AMQ-1436 交叉執行 inspector／retention report／backup／verify，確認 room、command、SRS event counts 一致且 `missingOptionalTables` 為空。
[x] AMQ-1437 驗證 retention report 將 active／closed／unknown phase 分類為 1／1／0；targeted database integrity tests 5/5 PASS。
[~] AMQ-1438 Batch141 後完整 61 個非-tooling scripts、tooling、architecture、source audit／mapper／benchmark、syntax 與 ZIP 待收尾。


## Batch 142：SQLite integrity diagnostics 有界記憶體（2026-10-28）
[x] AMQ-1439 `server/database-integrity.cjs` 將 `PRAGMA foreign_key_check` 從 `.all()` 改為 iterator，保留完整 violation count 與最多 5 個 sample。
[x] AMQ-1440 `PRAGMA integrity_check` 改為 iterator；錯誤診斷最多保留 5 個 sample，仍要求唯一結果為 `ok` 才通過。
[x] AMQ-1441 `tests/database-integrity.test.cjs` 新增 250 筆 orphan command fixture，驗證 count=250 且 sample 長度=5；targeted tests 6/6 PASS。
[~] AMQ-1442 Batch142 後完整 61 個非-tooling scripts、tooling、architecture、source audit／mapper／benchmark、syntax 與 ZIP 待收尾。


## Batch 143：Invalid JSON／unknown phase 分類契約（2026-10-28）
[x] AMQ-1443 `tests/multiplayer-retention-report.test.cjs` 同時覆蓋 active、closed、invalid JSON 與未知 phase；unknownPhase 計數為 2，不誤歸 active／closed。
[x] AMQ-1444 與 database integrity tests 合跑 8/8 PASS，涵蓋 read-only、legacy schema、跨工具 counts、250 筆 FK violations bounded sample 與 invalid state JSON。
[x] AMQ-1445 未發現可重現的 production aggregate query 缺陷；不修改穩定 SQL，只增加分類回歸證據。
[~] AMQ-1446 最終 61 個非-tooling scripts、tooling、architecture、source audit／mapper／benchmark、syntax 與 ZIP 待收尾。


## Batch 144：唯讀 diagnostics CLI 路徑與錯誤輸出邊界（2026-10-28）
[x] AMQ-1447 `tests/database-integrity.test.cjs` 使用含空白／方括號／單引號的 DB path，確認 inspector／retention report 成功且 input bytes 不變。
[x] AMQ-1448 對含 sentinel payload 的 malformed DB 執行 inspector／retention／verify，確認失敗但不輸出 DB bytes；backup 失敗不留下 destination。
[x] AMQ-1449 確認 inspector／retention／verify 對 directory path 明確拒絕；targeted database-integrity tests 7/7 PASS。
[~] AMQ-1450 Batch144 後完整 61 個非-tooling scripts、tooling、architecture、source audit／mapper／benchmark、syntax 與 ZIP 待收尾。


## Batch 145：獨立 UI 原型工作軌（不代表正式產品 UI 重構已開始）

> 本工作軌依使用者明確要求，先在 `prototype/ui-v1/` 建立獨立可操作原型。正式 `src/` 與核心 UI 接線仍按既有核心優先路線管理；原型驗證不等於正式產品驗收。

[x] AMQ-1451 開工前閱讀 `AGENTS.md`、`AI_START_HERE.md`、主清單、工作狀態、下一步提示詞及 Batch144 handoff。
[x] AMQ-1452 確認工作目錄無 `.git` metadata；不初始化 Git，不覆蓋 Candidate302／Candidate382 Stage 0／AMQ／EMQ assets。
[x] AMQ-1453 建立獨立 `prototype/ui-v1/`，不將 mock UI 混入正式 `src/`。
[x] AMQ-1454 建立分層 `tokens.css`、`layout.css`、`components.css`。
[x] AMQ-1455 以 1920 × 1080 建立首頁候選布局與最近練習／收藏入口。
[x] AMQ-1456 實作「沿用上次未完成練習」與「開始新練習」入口。
[x] AMQ-1457 實作選曲搜尋，支援歌曲標題、作品、歌手等欄位。
[x] AMQ-1458 實作歌曲列表、目前選取狀態與右側歌曲資訊面板。
[x] AMQ-1459 實作收藏切換與收藏分類。
[x] AMQ-1460 實作最近練習／不熟悉分類。
[x] AMQ-1461 實作來源、熟悉度與歌曲類型篩選，以及排序。
[x] AMQ-1462 實作 AMQ／EMQ／MIX、題數、歌曲範圍及進階設定展開／收合。
[x] AMQ-1463 實作答題輸入、提交／揭曉／跳過、正誤回饋與題目進度。
[x] AMQ-1464 實作示範播放／暫停狀態及離開／切題時清理示範播放 timer；不接真實音源。
[x] AMQ-1465 實作錯題集合與錯題複習入口，僅將已記錄錯題放入錯題回合。
[x] AMQ-1466 實作未完成練習接續與最近答題紀錄。
[x] AMQ-1467 實作歌曲資訊、收藏狀態、熟悉度與最近練習資訊。
[x] AMQ-1468 實作鍵盤操作：Ctrl／⌘+K、上下選曲、Enter 查看資訊、F 收藏、Esc 關閉／離開。
[x] AMQ-1469 實作 1024 寬度篩選抽屜與手機底部導覽；手機不縮放桌面欄位。
[x] AMQ-1470 將主要 app shell 固定在可視區；選曲列表、側欄及必要的工作區內容在內部捲動。
[x] AMQ-1471 瀏覽器 smoke test 覆蓋搜尋、收藏、模式、進階設定、答題、錯題、接續、歷史與歌曲資訊。
[x] AMQ-1472 Chromium／Playwright smoke test 43/43 PASS；未發生 page errors。
[x] AMQ-1473 驗證 1440 × 900、1024 × 768、390 × 844 無頁面層級水平／垂直溢位。
[x] AMQ-1474 對 1920 × 1080 首頁／選曲／設定／答題／歌曲資訊，以及響應式尺寸產生視覺截圖。
[x] AMQ-1475 建立 `prototype/ui-v1/README.md`，說明執行方式、Token、互動範圍與已知限制。
[x] AMQ-1476 更新工作狀態、handoff、主清單、開工指引與下一步提示詞。
[!] AMQ-1477 使用者電腦直接開啟 `file://` 原型的驗證：本執行環境的瀏覽器導覽被管理政策阻擋；解除條件為在一般本機瀏覽器開啟並確認相對 CSS／JS 載入。
[!] AMQ-1478 真實音源／正式曲庫／QuizSession／SRS／正式 persistence／多人功能接線：本批為獨立 mock 原型，刻意未接入。
[ ] AMQ-1479 依使用者對原型的實際回饋校準候選視覺 Token 與資訊層級。
[ ] AMQ-1480 原型設計決策穩定後，制定逐模組正式 UI 替換／接線計畫，保留單一狀態來源與核心模組所有權。
[ ] AMQ-1481 Batch140–144 待收尾的正式產品全量回歸證據與封包核對。
[ ] AMQ-1482 回到 `FUNCTION_INVENTORY.md` 與 `PRODUCT_CORE_CONTRACT.md`，選擇下一個可安全實作的高優先級必要功能缺口。


## Batch 146：osu!stable Song Select 視覺方向 v2（獨立原型）
[x] AMQ-1483 保留 `prototype/ui-v1/` 作為先前候選，不覆蓋；新增 `prototype/ui-v2-osu-select-batch146/` 作為獨立視覺分支。
[x] AMQ-1484 開工前確認 `AGENTS.md`、`AI_START_HERE.md`、工作狀態、主清單、下一步提示詞、Batch145 handoff、專案規範與無 Git metadata 狀態。
[x] AMQ-1485 依使用者明確選擇 ABCD + AC，將 osu!stable 的版面、操作密度、鍵盤操作、歌曲資訊與背景呈現作整體參考，同時保留 AMQ 操作習慣。
[x] AMQ-1486 新增獨立 `styles/osu-select.css`，降低圓角、漸層、卡片化與裝飾性元素；選曲頁改為左側分類、中央密集曲目列、右側選取資訊及底部播放列。
[x] AMQ-1487 保留既有 mock data 與行為控制器，避免重寫已可測的搜尋、收藏、篩選、排序、模式、答題及歷史功能。
[x] AMQ-1488 將原型頁面標題更新為 Song Select Prototype v2，更新瀏覽器測試載入新的 CSS 層。
[x] AMQ-1489 重新執行 Chromium／Playwright smoke test：43/43 PASS，page errors 0。
[x] AMQ-1490 驗證 1440×900、1024×768、390×844 無頁面層級水平／垂直溢位；測試重新產生相應截圖。
[x] AMQ-1491 更新 v2 README，說明設計方向、執行方式、驗證與限制。
[~] AMQ-1492 1920×1080 選曲版面視覺已產生截圖，但尚未由使用者驗收；目前 mock 封面仍是色塊，不代表最終視覺素材策略。
[ ] AMQ-1493 若選曲主方向獲接受，將同一視覺語言延伸到首頁、練習設定、答題、歌曲資訊與學習紀錄，再做跨頁驗收。
[ ] AMQ-1494 在沒有實際音源／封面資料的情況下，決定正式產品背景圖與封面缺失的 fallback 規則；不得以隨機漸層取代正式素材策略。
[ ] AMQ-1495 對 v2 執行 1920×1080、1440×900、1024×768、390×844 截圖人工視覺檢查，確認常用操作、列表密度與詳情可讀性。
[ ] AMQ-1496 確認 v2 方向後，制定正式 UI 對接計畫；原型不直接接管正式 Catalog／AudioService／QuizSession／SRS。
[ ] AMQ-1497 Batch140–144 的正式產品完整回歸與最終封包仍按原路線追蹤，不得被 UI 原型工作替代。


## Batch147 UI 原型與素材授權
- [x] AMQ-1485 修正 Playwright 原型測試的相對封面載入方式，避免 `set_content()` 下的破圖假象。
- [x] AMQ-1486 加入歌曲列封面與選中歌曲資訊封面載入斷言。
- [x] AMQ-1487 重產主要響應式截圖並驗證桌面封面顯示。
- [x] AMQ-1488 盤點 Project Minimalist 與 Neon 的 README 授權聲明，記錄直接移植風險。
- [ ] AMQ-1489 尋找可合法重用的真實動畫／遊戲封面素材，建立逐檔來源、授權、署名及替代素材清單。
- [ ] AMQ-1490 以授權清楚的真實封面替換原創示意圖，保留載入失敗 fallback 與 reduced-motion 支援。
- [ ] AMQ-1491 由使用者驗收 osu!stable 方向的選曲畫面，再決定是否延伸其他頁面。

## Batch148：osu 選曲卡片主視覺
- [x] AMQ-1498 將選曲清單改為封面主導的多欄卡片，提升封面尺寸與視覺權重。
- [x] AMQ-1499 加強 hover、selected 邊框、選取標記與收藏操作回饋。
- [x] AMQ-1500 保留歌曲搜尋、作品搜尋、篩選、收藏、鍵盤上下選取／Enter/F 操作及歌曲詳情。
- [x] AMQ-1501 手機版採單欄橫向封面卡片，避免桌面卡片縮小至不可讀。
- [x] AMQ-1502 執行原型 smoke test：45/45 PASS，未捕捉 browser errors 0。
- [ ] AMQ-1503 人工檢查新卡片中標題、作品名、熟悉度和操作是否完整可見，修正可能的裁切／間距問題。
- [ ] AMQ-1504 尋找逐檔授權明確的真實動畫／遊戲封面，取代目前原創 SVG 示意圖。
- [ ] AMQ-1505 使用者確認卡片主軸後，再決定是否延伸此視覺方向至其他頁面。

## Batch149：osu! Skin（.osk）讀取能力第一階段
- [x] AMQ-1506 查閱 osu! 官方 Skin 說明與 `skin.ini` 格式文件，確認 `.osk` 是 Skin 素材封裝，不能直接視為完整網站 UI。
- [x] AMQ-1507 新增 `src/skins/osk-importer.js`：解析 ZIP 中央目錄，支援 Stored／Deflate、`skin.ini` metadata、顏色解析與常見選曲素材映射。
- [x] AMQ-1508 對封裝大小、解壓總大小、單檔大小、項目數、ZIP64／多磁碟、加密項目、無效標頭與路徑穿越採 fail-closed／忽略策略，不將封裝路徑寫入檔案系統。
- [x] AMQ-1509 新增正式 UI `.osk` 檔案選取、素材畫廊與背景／右下角色／選曲框架角色映射預覽。
- [x] AMQ-1510 將匯入器與面板接入正式 `src/index.html`／`src/app.js` 生命週期；不更改 Candidate302、Candidate382 Stage 0 或 AMQ／EMQ 曲庫資料。
- [x] AMQ-1511 新增 `tests/osk-importer.test.cjs`，6/6 PASS，涵蓋 Deflate／Stored、skin.ini、素材映射、路徑穿越與無效封裝。
- [x] AMQ-1512 新增 `tests/osk-import-panel.browser.test.py`，使用系統 Chromium 對真實 file input 流程執行 9 項瀏覽器斷言，9/9 PASS。
- [x] AMQ-1513 `node tools/check-architecture.cjs`：946 PASS、0 FAIL；相關 JS syntax checks PASS。
- [~] AMQ-1514 完整 `node --test tests/*.test.cjs` 在 120 秒工作上限內未結束，未取得總結，不能宣稱全量回歸通過；需分批執行並記錄各批結果。
- [x] AMQ-1515 新增 `src/persistence/skin-theme-store.js`，將 Skin 圖片 Blob 與角色映射保存到 IndexedDB；以新 store instance 讀回及刪除測試驗證 schema／保存契約。實際瀏覽器持久化仍待非 opaque origin 的本機伺服器環境驗證。
- [ ] AMQ-1516 擴充 osu!stable selection-bar、menu-background、songselect 元素與 AMQ 自訂卡片／場景的映射驗收，對不匹配素材提供手動角色指定與 fallback。
- [ ] AMQ-1517 下載並檢查至少一個可取得的 `.osk` 真實範例，驗證實際 skin.ini 編碼、Deflate 變體、檔案數量與素材命名；目前自動測試使用人工產生的 ZIP fixture。
- [ ] AMQ-1518 建立主題匯出／匯入設定、素材使用者告知與資產來源紀錄；不得把外部 Skin 內的第三方圖像授權視為已獲確認。


## Batch150：OSK Skin Theme 持久化與回歸收尾（2026-10-28）
- [x] AMQ-1519 新增版本化 `SkinTheme` schema v1：metadata、background、selectionFrame、characterOverlay、accentColors、motionPreference、asset Blob 與 updatedAt。
- [x] AMQ-1520 新增 IndexedDB 單一 persistence owner `src/persistence/skin-theme-store.js`，提供 load/save/clear/dispose；不將二進位素材寫入 localStorage。
- [x] AMQ-1521 加入單檔 24 MiB、總素材 120 MiB、最多 5,000 項、唯一路徑、有效 role mapping、版本與 accent color 驗證。
- [x] AMQ-1522 匯入後保存素材與 metadata；套用時保存角色映射與 enabled 狀態；重新載入時嘗試恢復並重建 Object URL；清除按鈕移除持久化記錄及目前預覽。
- [x] AMQ-1523 將 persistence 模組接入 `src/index.html`、`tests/tests.html` 與 architecture load-order check。
- [x] AMQ-1524 新增 `tests/skin-theme-store.test.cjs`，4/4 PASS：schema normalization、跨 store instance restore、mapping／size limits、IndexedDB unavailable fail-closed。
- [x] AMQ-1525 OSK importer 6/6、Chromium panel 9/9、core／lifecycle／app settings／theme store 五檔組合測試 PASS；source/data/audio/quiz/tooling 六檔組合測試 18/18 PASS。
- [x] AMQ-1526 `node tools/check-architecture.cjs`：961 PASS／0 FAIL。
- [!] AMQ-1527 真實瀏覽器持久化仍未完成實機驗收：Playwright `set_content()` 使用 opaque origin，Chromium 明確拒絕 IndexedDB；需在正常 `http://localhost` origin 驗證。此環境既有本機 HTTP 導覽政策阻擋，未將 fake-IDB Node 測試冒充真實瀏覽器驗收。
- [!] AMQ-1528 真實 `.osk` 下載：對既有 KaKKeY release URL 執行 curl，DNS 回報 `Could not resolve host: github.com`；沒有下載檔案，未進行真實 Skin 驗證。
- [x] AMQ-1529 已將 `tests/` 內全部 64 個 `*.test.cjs` 檔案分組執行，每組皆 exit 0、0 FAIL；各批命令與摘要記錄在 `docs/WORK_STATUS.md`。這不是單一 `node --test tests/*.test.cjs` 全包程序，但 64/64 測試檔均已被實際執行。
- [ ] AMQ-1530 在非 opaque origin 的正式本機啟動方式下驗證 IndexedDB save/reload/clear，並確認瀏覽器 storage quota／Private mode 錯誤訊息。
- [ ] AMQ-1531 取得真實 `.osk`，檢查實際 skin.ini 編碼、檔案命名、Deflate 變體與素材總量，再依結果補 importer fixtures。
- [ ] AMQ-1532 將 theme role adapter 連接到正式 osu-style 選曲卡片／背景／角色 UI；目前持久化與原有預覽已接線，完整 Song Select 對接尚未完成。
- [x] AMQ-1533 完成剩餘 6 組 Node 測試分組，核對 64/64 個 `*.test.cjs` 檔案都曾在成功批次中執行；不把分組測試說成單一全量指令。

## Batch151：OSK Theme Adapter
- [x] AMQ-1534 新增 `src/skins/theme-adapter.js`，將 background／selectionFrame／characterOverlay／accent 套用集中為單一責任模組。
- [x] AMQ-1535 Adapter 管理 Object URL 生命週期，reset／dispose 時回收 URL 並清除 CSS／角色節點。
- [x] AMQ-1536 圖片解碼失敗、缺失映射、停用主題時使用預設外觀並回報 warnings。
- [x] AMQ-1537 支援 `motionPreference=reduce` 與系統 `prefers-reduced-motion`，避免角色裝飾動效。
- [x] AMQ-1538 匯入面板委派 Adapter，不再自行持有背景／框架／角色渲染責任。
- [x] AMQ-1539 修正套用與 IndexedDB 保存錯誤訊息，避免保存錯誤掩蓋實際套用狀態。
- [x] AMQ-1540 更新正式頁面與 browser test 頁的 script load order、架構檢查。
- [x] AMQ-1541 新增 `tests/skin-theme-adapter.test.cjs`，覆蓋 mapping、apply/reset、解碼失敗、reduced-motion 與 fallback。
- [x] AMQ-1542 更新 OSK panel Chromium test 使用有效 PNG fixture 並等待套用結果；9/9 assertions PASS。
- [x] AMQ-1543 受影響測試分組 11/11 top-level PASS；architecture 977 PASS／0 FAIL。
- [ ] AMQ-1544 `skin.ini` UTF-8 BOM／UTF-16 BOM／Windows-1252 fallback 與相應 importer fixtures。
- [x] AMQ-1545 將 osu! 選曲素材 filename mapping 集中成 `assetRoleCatalog`／`candidatesForRole()`，importer 與 UI 共用；role catalog fixture PASS。
- [ ] AMQ-1546 主題匯出／匯入設定、素材來源紀錄與授權提醒；匯出必須由使用者明確觸發。
- [!] AMQ-1547 非 opaque origin 的 IndexedDB save/reload/clear 真實瀏覽器驗收，需可用 HTTP origin。
- [!] AMQ-1548 真實 `.osk` 兼容性測試，需取得真實檔案；DNS 阻擋期間先以 fixture 推進可完成項目。
- [ ] AMQ-1549 將 Adapter 與正式 osu-style Song Select 卡片／場景接線完成；不得把獨立原型等同正式產品 UI。


## Batch152：Skin Theme 可攜式匯出／匯入
- [x] AMQ-1550 新增 `src/skins/theme-transfer.js`，定義版本化 `amq-skin-theme` JSON bundle，獨立於 `.osk` 原始封裝與 IndexedDB schema。
- [x] AMQ-1551 使用者明確點擊後才匯出；以 Blob 下載至本機，不自動上傳、不將素材送往外部服務。
- [x] AMQ-1552 匯入時驗證 bundle 格式／版本、素材副檔名、Base64 格式、唯一且安全的相對路徑、角色映射、色彩及 motion preference。
- [x] AMQ-1553 匯入限制最多 5,000 個素材、單檔 24 MiB、總素材 120 MiB；UI 設定檔封裝限制 170 MiB，超限明確拒絕。
- [x] AMQ-1554 加入素材來源／著作權提醒，明確說明技術匯入不代表取得第三方素材使用權。
- [x] AMQ-1555 將匯出／匯入接到正式 Skin 面板；匯入後先保存為停用主題，需使用者明確套用才啟用。
- [x] AMQ-1556 新增 `tests/skin-theme-transfer.test.cjs`，涵蓋 binary round-trip、未知版本、路徑穿越、dangling mapping、非法 Base64、超額素材及不支援副檔名。
- [x] AMQ-1557 擴充 `tests/osk-import-panel.browser.test.py`，驗證匯入設定、下載匯出及 UI 回饋；12/12 assertions PASS。
- [x] AMQ-1558 更新正式頁面、browser test 頁面載入順序與 `tools/check-architecture.cjs`。
- [ ] AMQ-1559 真實 HTTP origin 下 IndexedDB save/reload/clear 驗收；目前 browser `set_content()` 為 opaque origin，不能作為持久化驗收證據。
- [ ] AMQ-1560 取得真實 `.osk` 檔案做實際 Skin 相容性檢查；網路下載仍待驗證。
- [ ] AMQ-1561 由使用者檢視正式 osu-style Song Select 視覺整合；目前完整選曲版面仍未完成正式整合。


## Batch153 Skin-to-Catalog 整合
- [x] AMQ-1562 `themeAdapter` 背景／選曲框架／accent 套用目標改為正式 `#catalog-browser`，保留可注入 targetSelector 與 root fallback。
- [x] AMQ-1563 Skin CSS 由全域頁面效果縮小至正式 Catalog，避免改動 quiz、account 及其他區域。
- [x] AMQ-1564 reset 清除 Catalog 的 Skin properties／data attributes，並回收 Object URLs。
- [x] AMQ-1565 Adapter Node integration test 驗證套用、作用域隔離與 reset。
- [x] AMQ-1566 Chromium panel test 改為真實 Catalog target fixture，12/12 assertions PASS。
- [x] AMQ-1567 受影響 Node 測試組合 15/15 top-level PASS；架構檢查 991/0。
- [!] AMQ-1568 在獨立 HTTP origin 驗證 IndexedDB save/reload/clear；獨立 subprocess 建立 localhost HTTP server 後，Chromium 導覽回報 `net::ERR_BLOCKED_BY_ADMINISTRATOR`。解除條件：提供允許 localhost HTTP 導覽的瀏覽器／測試環境。
- [ ] AMQ-1569 取得真實 `.osk` 並驗證非 fixture 的實際封裝。
- [ ] AMQ-1570 正式 osu!stable Song Select 視覺框架完整整合與使用者視覺驗收。


## Batch154：Catalog Skin selection frame 與回歸收尾
- [x] AMQ-1571 修正 Skin selectionFrame 的 Catalog 選取列渲染：不再依賴 `<tr>` 上不可靠的 `border-image`，改用整列背景紋理及遮罩。
- [x] AMQ-1572 限定 frame 規則於 `#catalog-browser[data-amq-skin-frame="true"] #catalog-rows tr[aria-selected="true"]`，避免影響 quiz 或其他表格。
- [x] AMQ-1573 新增 CSS 契約測試，確認 frame 背景紋理與透明 cell 規則，並禁止回歸至 table-row border-image。
- [x] AMQ-1574 Skin adapter/store/transfer/importer 測試組合 16/16 top-level PASS，OSK importer 內部 10/10。
- [x] AMQ-1575 Chromium OSK panel 12/12 assertions PASS。
- [x] AMQ-1576 Architecture check 991 PASS／0 FAIL；相關 JS syntax checks PASS。
- [x] AMQ-1577 將 `tests/` 內 66 個 Node test files 全部在成功的分組命令中執行；前 56 個分 7 組成功，最後 10 個分 2 組成功。未宣稱單一全量命令通過。
- [!] AMQ-1578 非 opaque HTTP origin IndexedDB save/reload/clear 仍阻塞：已知 Chromium 回報 `net::ERR_BLOCKED_BY_ADMINISTRATOR`，解除條件是可用且允許 localhost 導覽的瀏覽器環境。
- [!] AMQ-1579 真實 `.osk` 相容性仍阻塞：尚未取得真實檔案，需網路／檔案來源可用後補測。
- [ ] AMQ-1580 盤點正式 Catalog 的 ANN／VNDB artwork linking／cache 既有能力，定義獨立 artwork adapter 及失敗 fallback。
- [ ] AMQ-1581 完成正式 osu!stable Song Select UI 分層整合，保留搜尋、篩選、排序、分頁、鍵盤導覽、個人清單及學習狀態；需後續視覺驗收。

## Batch155：Skin lifecycle 與 Artwork adapter 基礎
- [x] AMQ-1582 Skin Adapter 找不到 `#catalog-browser` 時 fail-closed，不再把新 Skin 視覺套到全域 document root。
- [x] AMQ-1583 Skin Adapter dispose 冪等，dispose 後拒絕後續 apply，並清理 Object URL／CSS／角色節點。
- [x] AMQ-1584 新增 delayed decode/reset race regression，證明過期 async 操作不能在 reset 後重新套用 Skin。
- [x] AMQ-1585 新增 `src/integrations/artwork-adapter.js`，由 caller 注入 provider，不自行執行網路請求。
- [x] AMQ-1586 Artwork adapter 支援 AniList `coverUrl`、MAL／VNDB `imageUrl`、通用 `url`，並驗證 HTTPS scheme／拒絕 credentials。
- [x] AMQ-1587 Artwork adapter 支援 source/id cache key、in-flight dedupe、有界 LRU、invalidate、AbortController cancellation、stale completion guard 與 dispose。
- [x] AMQ-1588 更新正式 HTML／browser test HTML 載入順序及 architecture checks。
- [x] AMQ-1589 Skin Adapter／Artwork adapter 單元測試 15/15 PASS；受影響 Catalog／external adapter／skin／lifecycle 組合 14/14 top-level groups PASS。
- [x] AMQ-1590 Chromium OSK panel 12/12 assertions PASS；architecture 1007 PASS／0 FAIL。
- [x] AMQ-1591 `tests/` 內 67 個 Node test files 分 12 組執行，12/12 組 exit 0；各組日誌及 summary 位於 `artifacts/batch155-regression/`。
- [ ] AMQ-1592 定義 AMQ／EMQ song record 到 anime/game work artwork reference 的明確 linking contract，不得把 song ID 當作 work ID 猜測。
- [~] AMQ-1593 Catalog 已支援注入 artwork adapter 並實作縮圖／fallback；正式 app 尚未提供可靠的 AniList／MAL／VNDB provider factory，不能視為真實封面供應完成。
- [ ] AMQ-1594 實作可靠的 ANN／AniList／MAL／VNDB work-linking provider；現有 adapters 的 normalize image fields 不等同 linking 已完成。
- [!] AMQ-1596 在允許 localhost HTTP navigation 的瀏覽器環境驗證 IndexedDB save/reload/clear；先前 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR`，本批未重複嘗試。


## Batch156：作品封面身份契約與 Catalog 縮圖接線（2026-10-28）
- [x] AMQ-1592 定義 `artworkRef` 為作品層級契約，欄位包含 `kind`、`source`、`id`；EMQ 可附帶明確 `vndbId`。song `id` 與作品 `animeId` 分離，不再以歌曲 ID 推斷作品封面。
- [x] AMQ-1598 AMQ／EMQ source mappers 將作品層級 `artworkRef` 附加到歌曲記錄，且 work ref 為 frozen object；原有 song ID、音訊候選及來源 schema 不變。
- [x] AMQ-1599 Artwork adapter 優先採用 `record.artworkRef` 作 cache/provider identity，同一作品的多首歌曲共用 in-flight lookup 與 cache。
- [x] AMQ-1600 Catalog 支援注入 artwork adapter，在首欄呈現縮圖與標題；缺圖、provider 失敗或不安全 URL 保留 fallback，不把未驗證 URL 寫入 `img.src`。
- [x] AMQ-1601 Catalog artwork 非同步結果加 render-generation／DOM 連結檢查，避免舊渲染結果覆寫新列表；Catalog dispose 後不再更新 DOM。
- [x] AMQ-1602 新增 artwork work-reference cache 測試，驗證不同 song ID 指向同一作品時只呼叫一次 provider。
- [x] AMQ-1603 擴充 Catalog integration regression，驗證安全 HTTPS 封面呈現、不安全 URL fallback、搜尋／分頁／鍵盤／個人清單既有流程及重新渲染 cache reuse。
- [x] AMQ-1604 更新 architecture contract checks，要求明確 work reference identity 與 Catalog 僅使用 adapter normalized results。
- [x] AMQ-1605 受影響 Node 測試 4 個檔案／9 個 top-level tests PASS；source mapper 自有 7/7、Catalog integration PASS、Catalog controller 6/6、artwork adapter 6/6。
- [x] AMQ-1606 `node tools/check-architecture.cjs`：1009 PASS／0 FAIL；Chromium OSK panel 12/12 PASS。
- [x] AMQ-1607 `tests/` 內 67 個 Node test files 分組回歸：group 01–09 PASS、group 10 的 6 個檔案拆開執行後 6/6 PASS、group 11–12 PASS；共 67/67 檔案均有成功執行證據。group 10 原始批次在整體 120 秒工作上限內未結束，因此不宣稱該批次命令本身通過。
- [~] AMQ-1593 Catalog 已支援注入 artwork adapter 並實作縮圖／fallback，但正式 app 尚未提供可靠的 AniList／VNDB provider factory；未把空 provider 假裝成封面已正式供應。
- [!] AMQ-1595 取得真實 `.osk` 驗證 ZIP／skin.ini／素材命名；仍受先前網路 DNS 阻擋影響。


## Batch157：保守型 artwork provider 與 app lifecycle 接線（2026-10-28）
- [x] AMQ-1608 新增 `src/integrations/artwork-provider-factory.js`，只接受明確外部 work ID；不把 AMQ／EMQ source-local ID 當成 AniList／VNDB ID。
- [x] AMQ-1609 EMQ 只在 `artworkRef.vndbId` 有效時使用 VNDB `getVisualNovel`；缺少外部 ID 時明確回傳 missing，不按標題搜尋。
- [x] AMQ-1610 AniList adapter 新增精確 `getMediaById`，不使用 search result 作為自動封面匹配。
- [x] AMQ-1611 AniList／VNDB 精確讀取方法支援 `AbortSignal`，取消沿既有 external-service client 傳遞。
- [x] AMQ-1612 Provider 回傳 provider／attribution／source URL，Artwork adapter 仍負責 HTTPS 驗證及 cache。
- [x] AMQ-1613 `src/app.js` 建立 artwork service/client/provider/adapter，注入 Catalog 並註冊 app scope 清理。
- [x] AMQ-1614 更新 `src/index.html`、`tests/tests.html` script order 與 architecture load-order/static checks。
- [x] AMQ-1615 新增 `tests/artwork-provider-factory.test.cjs`，驗證 exact IDs、拒絕模糊匹配、attribution、取消與 dispose。
- [x] AMQ-1616 受影響 7 個 Node test files：14/14 top-level tests PASS；`node tools/check-architecture.cjs` 1023 PASS／0 FAIL；Chromium OSK panel 12/12 PASS。
- [~] AMQ-1617 正式 provider 已接線，但只有資料中帶有明確 VNDB ID 的 EMQ works 可取得真實封面；AMQ 缺少可靠 AniList crosswalk，必須維持 fallback。未做真實外部網路 API 測試。
- [x] AMQ-1618 唯讀統計 EMQ `vndbId` 覆蓋率：6,570/6,645 works 有格式有效 ID（98.87%），75 個缺失／無效；16,839 songs，原始資產未修改。
- [ ] AMQ-1619 尋找可驗證 AMQ work→AniList ID crosswalk；找不到可靠來源就記錄覆蓋限制，不使用標題猜測。
- [x] AMQ-1620（Batch165）補 app mount/dispose integration test，驗證 artwork adapter/provider/client lifecycle、注入 Catalog、失敗回滾與重新 mount。
- [ ] AMQ-1621 進行正式 osu!stable Song Select 分層替換，保留搜尋、篩選、排序、分頁、鍵盤、個人清單與學習狀態。
- [!] AMQ-1622 真實 `.osk` 相容性驗收，仍需取得真實檔案。
- [!] AMQ-1623 IndexedDB save/reload/clear 真實瀏覽器驗收，仍需允許 localhost HTTP 導覽的環境。


## Batch158：ANNID 資料契約修正（2026-10-28）
- [x] AMQ-1624 核對 `data.js` work row schema，確認 `row[6]` 是 ANNID；保留 `row[0]` 作為獨立 AMQ work ID。
- [x] AMQ-1625 `source-mappers.js` 暴露 `animeAnnId` 與 `artworkRef.annId`，不將 ANNID 命名為 AniList ID；新增回歸測試。
- [x] AMQ-1626 `chinese-title-provider.js` 支援 Bangumi ANN site ID crosswalk、ANNID 標題映射及明確 `getAniListId(record)`。
- [x] AMQ-1627 修正 `DATA_CONTRACT.md` 與 Batch82 contract 的錯誤說法，明確記錄 AMQ work ID 不等於 MAL ID。
- [x] AMQ-1628 來源 mapper 測試 8/8 PASS；Chinese title provider 測試 6/6 PASS；兩個修改 JS 語法檢查 PASS。
- [ ] AMQ-1629 將 ANNID→AniList crosswalk resolver 接入 artwork provider factory 與 app lifecycle，並測試缺失／失敗 fallback。
- [ ] AMQ-1630 使用真實 pinned Bangumi dataset 驗證 ANN site identifier 與 crosswalk 覆蓋率；目前僅 fixture 驗證。

## Batch159：ANNID 直連動畫封面（2026-10-28）
- [x] AMQ-1624 新增 ANN artwork adapter，以曲庫既有 ANNID 查詢 ANN Encyclopedia XML，不把 AMQ work ID 當外部 ID。
- [x] AMQ-1625 解析 ANN Picture `src`，驗證圖片 URL 必須是 ANN 官方 HTTPS host，並產生 ANN attribution 與百科頁連結。
- [x] AMQ-1626 ANN adapter 加入 ID 驗證、結果快取、取消支援及預設每秒一個不同 ID 查詢的序列化節流。
- [x] AMQ-1627 Artwork provider 改為 AMQ 動畫 ANN 優先，只有 ANN 缺圖才考慮明確 AniList crosswalk；不執行模糊標題搜尋。
- [x] AMQ-1628 將 ANN adapter 接入 app lifecycle，dispose 時清除資源。
- [x] AMQ-1629 新增 ANN adapter 測試，涵蓋 XML 圖片解析、錯誤 ID、錯誤主機、快取、來源連結與缺圖。
- [x] AMQ-1630 擴充 provider factory 測試，驗證 ANN 優先與明確 AniList 備援。
- [x] AMQ-1631 更新正式頁面、測試頁載入順序及架構檢查。
- [x] AMQ-1632 受影響測試組 16/16 PASS，architecture 1,037 PASS／0 FAIL。
- [~] AMQ-1633 真實 ANN API、CORS 與圖片實際載入驗收；Node fixture 通過，尚無線上瀏覽器證據。
- [x] AMQ-1634 ANN API 非取消類錯誤時逐來源 fallback 至明確 AniList crosswalk；AbortError／signal aborted 直接傳遞，並補上回歸測試。
- [x] AMQ-1637 補足 ANN 429／HTTP 500／timeout 等不同錯誤類型的明確測試案例（由 Batch160 完成）。
- [x] AMQ-1635 將 ANN attribution 與作品百科連結顯示於 Catalog 封面列的可存取 UI，避免只有資料物件帶有 attribution（由 Batch160 完成）。
- [ ] AMQ-1636 繼續正式 osu!stable Song Select UI 分層替換，保留 Catalog 互動與 Skin lifecycle。


## Batch160：ANN 封面錯誤處理與來源可存取性（2026-10-28）
- [x] AMQ-1648 將 ANN 429、HTTP 500、network error、response-body error、timeout 與 caller abort 分別測試；錯誤分類保留給 provider fallback 決策使用。
- [x] AMQ-1649 ANN adapter 新增有界請求 timeout，將 fetch／response body 的 network failure 正規化，並區分 timeout 與使用者／生命週期取消。
- [x] AMQ-1650 Catalog 封面有來源 attribution 與作品頁 URL 時，新增可見的「來源：ANN／AniList／VNDB」連結；連結使用新分頁與 `noopener noreferrer`，並提供可存取名稱。
- [x] AMQ-1651 Catalog row keyboard handler 將來源 anchor 視為互動元素，避免按 Enter 開啟來源連結時意外觸發歌曲選取邏輯。
- [x] AMQ-1652 擴充 ANN adapter 與 Catalog integration tests，覆蓋 HTTP 429／500、network／body failure、timeout／abort、attribution link、source URL 與 rel 屬性。
- [x] AMQ-1653 受影響 Node 測試：7 個主要 test files 共 23 個 top-level tests PASS；App lifecycle regression 組合 22/22 PASS。
- [x] AMQ-1654 `node tools/check-architecture.cjs`：1037 PASS／0 FAIL；Chromium OSK panel 12/12 assertions PASS。
- [x] AMQ-1655 `tests/` 下 69 個 `*.test.cjs` 均有成功執行證據：前 56 個分 7 組成功，後 13 個逐檔成功；初始 orchestration 在 120 秒上限中斷，未宣稱原始 orchestration 命令成功。日誌及 `summary.json` 位於 `artifacts/batch160-regression/`。
- [ ] AMQ-1656 在可用的真實瀏覽器網路環境驗證 ANN API、CORS、圖片載入及 attribution UI；目前只有 fixture／fake DOM 證據。
- [ ] AMQ-1657 正式 osu!stable Song Select 視圖分層替換，保留既有 Catalog 查詢、分頁、鍵盤、個人清單、看番狀態及 Skin lifecycle。
- [!] AMQ-1658 真實 `.osk` 相容性仍需真實 Skin 檔案；IndexedDB HTTP-origin save/reload/clear 仍需允許 localhost 導覽的瀏覽器環境。


## Batch161：正式 Catalog 選取資訊面板第一階段（2026-10-28）
- [x] AMQ-1659 在正式 `src/index.html` 將選曲列表與選取資訊區拆為明確的 `catalog-select-layout`，不引入 prototype mock data。
- [x] AMQ-1660 在 `catalog-browser.js` 新增 selected-song detail view model/render function，顯示歌曲、作品、歌手、類型、年份與來源。
- [x] AMQ-1661 詳情面板使用既有 Artwork Adapter 取得封面與來源 attribution，不新增直接網路請求或第二套 cache。
- [x] AMQ-1662 加入 selection generation guard，避免快速切換選取項目時舊封面結果覆蓋新作品資訊。
- [x] AMQ-1663 在 `styles.css` 新增桌面雙欄、窄螢幕堆疊的選曲列表／詳情版面，保留既有列表與 Skin 選取框架 selector。
- [x] AMQ-1664 擴充 Catalog integration test，驗證選取歌曲後詳情面板更新、作品資訊及封面區存在。
- [x] AMQ-1665 Catalog／ANN／Artwork／App lifecycle 相關 Node 測試 22/22 PASS；架構檢查 1037/0。
- [ ] AMQ-1666 以真實 Chromium 截圖／互動驗收正式 Catalog 詳情面板於桌面、平板及手機的視覺與焦點順序；目前只做 Fake DOM integration 和 CSS responsive rules 檢查。
- [ ] AMQ-1667 繼續把已認可 osu!stable Song Select 的篩選區、選曲列表及底部播放／選取狀態分層整合進正式產品，保留所有既有資料及學習功能。


## Batch162：正式 Catalog 常用／進階篩選分層（2026-10-28）
- [x] AMQ-1668 檢查 `prototype/ui-v2-osu-select-batch146/` 的 osu!stable 篩選側欄視覺方向，採用主控件精簡、低頻選項收納的原則，不複製 prototype mock UI。
- [x] AMQ-1669 正式 Catalog 常用區保留搜尋、來源、歌曲類型、看番狀態、排序依據與方向。
- [x] AMQ-1670 以原生 `<details>/<summary>` 建立進階篩選，收納作品類型、作品細分類、年代、年份起迄、未知年份選項及熟悉度。
- [x] AMQ-1671 保留所有既有 filter DOM IDs 與 `catalog-browser.js` 事件接線，不重寫 query-index、controller 或個人清單狀態。
- [x] AMQ-1672 新增 `tests/catalog-filter-layout.contract.test.cjs`，檢查常用／進階欄位分組、原生 disclosure、鍵盤焦點及 responsive CSS contract。
- [x] AMQ-1673 Catalog layout／controller／App lifecycle／ANN／Artwork 相關測試 25/25 PASS。
- [x] AMQ-1674 `node tools/check-architecture.cjs`：1044 PASS／0 FAIL；`python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- [ ] AMQ-1675 在真實 Chromium viewport 驗收桌面／平板／手機的視覺層級、overflow 與鍵盤焦點；目前頁面導覽政策仍阻擋，Node／CSS contract 不等於視覺驗收。
- [ ] AMQ-1676 繼續正式 Song Select 列表密度、選取資訊與播放狀態的分層整合，保持封面真實圖片與 attribution，不以色塊替代封面。


## Batch163（正式 Catalog 版面與可存取性）
- [x] AMQ-1677 將桌面常用篩選控制區改為搜尋＋來源／歌曲類型／看番狀態／排序依據／排序方向六欄明確配置。
- [x] AMQ-1678 常用篩選在 1100px 以下改為三欄並讓搜尋跨列，600px 以下改為單欄。
- [x] AMQ-1679 進階篩選原生 summary 加入 hover、focus-visible、open 狀態及最小觸控高度。
- [x] AMQ-1680 調整選取詳情面板寬度與封面可用空間，820px 以下改為上下堆疊。
- [x] AMQ-1681 擴充 Catalog filter layout contract，驗證桌面欄數、展開狀態、焦點樣式及詳情 breakpoint。
- [x] AMQ-1682 受影響 Catalog／Artwork／ANN／Skin／App lifecycle 測試 43/43 PASS。
- [x] AMQ-1683 架構檢查 1044 PASS／0 FAIL，OSK panel 12/12 assertions PASS。
- [x] AMQ-1684 `tests/` 下 70 個 Node test files 均有成功執行證據；group-08 合併命令中斷後 8 檔逐檔通過，已明確區分命令狀態。
- [ ] AMQ-1685 以真實 Chromium viewport 驗收桌面／平板／手機的實際尺寸、overflow 與鍵盤焦點；尚未取得可用導覽環境。
- [ ] AMQ-1686 盤點 Catalog selection 與 Free Player playback state 的責任邊界，整合既有播放狀態而不新增 owner。
- [ ] AMQ-1687 完成正式 Song Select 列表密度、詳情面板及播放狀態整合，保留個人清單／學習狀態／Skin／Artwork 功能。

## Batch164：Catalog 窄螢幕表格與播放狀態責任（2026-10-28）
- [x] AMQ-1688 正式 Catalog 表格容器新增 accessible region 名稱與鍵盤焦點，支援水平捲動。
- [x] AMQ-1689 新增隱藏 table caption，說明歌曲列方向鍵與 Enter 選取操作。
- [x] AMQ-1690 Catalog 表格設定 620px 最小寬度與較緊湊的欄位間距；窄螢幕水平捲動，不擠壓欄位。
- [x] AMQ-1691 保留 820px 以下列表／詳情上下堆疊與詳情面板正常文件流。
- [x] AMQ-1692 新增 layout contract tests，覆蓋可存取捲動區、caption、focus-visible、min-width 及 breakpoint。
- [x] AMQ-1693 靜態契約驗證 Catalog selection 與 Free Player AudioService 狀態分離；Catalog Enter 不播放，沒有新增第二個播放 owner。
- [x] AMQ-1694 受影響測試 8/8 top-level PASS；architecture 1044 PASS／0 FAIL；OSK panel 12/12；三個 JS 語法檢查 PASS。
- [ ] AMQ-1695 在允許的真實 Chromium viewport 驗收桌面／平板／手機的實際 overflow 與焦點操作；目前仍受頁面導覽政策阻擋。
- [ ] AMQ-1696 以真實瀏覽器確認 ANN API／CORS／圖片載入；Node fixture 不視為線上驗收。
- [!] AMQ-1697 取得真實 `.osk` 與允許 HTTP origin 的瀏覽器環境後，完成 Skin 相容性及 IndexedDB save/reload/clear 驗收。


## Batch165：Artwork lifecycle 原子清理與全量 Node 回歸（2026-10-28）
- [x] AMQ-1698 修正 `src/app.js` 資源生命週期註冊順序：個人清單、設定、熟悉度 store 在建立後立即註冊 cleanup，避免 runtime 初始化失敗時洩漏。
- [x] AMQ-1699 Artwork service client、provider bundle 與 artwork adapter 在各自建立後立即註冊 cleanup；provider factory 中途拋錯時先前取得的 client／ANN adapter 能回收。
- [x] AMQ-1700 新增 `tests/app-artwork-lifecycle.integration.test.cjs`，覆蓋 Catalog 共用 adapter 注入、mount/dispose/remount 資源一次性釋放、provider 建立失敗回滾與 retry、runtime 建立失敗 store cleanup。
- [x] AMQ-1701 相關測試組 8/8 top-level tests PASS；新增 artwork lifecycle test 3 組案例均 PASS。
- [x] AMQ-1702 `node tools/check-architecture.cjs`：1,051 PASS／0 FAIL；`python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS；`src/app.js` 與新測試語法檢查 PASS。
- [x] AMQ-1703 `tests/` 內 71 個 `*.test.cjs` 分 9 組執行，164/164 tests PASS、0 failures；所有 9 組命令 exit 0。分組日誌與 `summary.json` 位於 `artifacts/batch165-regression/`。
- [ ] AMQ-1704 取得可執行真實瀏覽器導覽的環境後，驗收 Catalog 1440／1024／820／390 viewport、焦點順序、水平捲動及詳情面板。
- [ ] AMQ-1705 在真實瀏覽器網路環境驗證 ANN API／CORS／實際圖片載入；Node fixture 不算線上驗收。
- [!] AMQ-1706 真實 `.osk` 相容性及非 opaque HTTP origin 的 IndexedDB save/reload/clear 仍受環境限制，需真實檔案與允許的瀏覽器環境。


## Batch166：Catalog 封面／長標題／來源資訊排版（2026-10-28）
- [x] AMQ-1707 檢查 Batch165 交接、正式基準、工作副本與測試工具；確認無 `.git` metadata，不初始化 Git。
- [x] AMQ-1708 正式 Catalog 有 artwork 的標題欄加上專用 layout class，讓封面／標題／來源資訊使用明確 grid 結構。
- [x] AMQ-1709 封面維持 42px 固定縮圖欄，標題使用 `minmax(0, 1fr)`，避免長標題把表格推寬。
- [x] AMQ-1710 attribution 連結限制於文字欄寬、可換行並保留鍵盤 focus-visible。
- [x] AMQ-1711 新增 Catalog layout contract test，驗證 grid、長標題、來源連結換行及焦點樣式。
- [x] AMQ-1712 受影響測試 10/10 top-level PASS；architecture 1051 PASS／0 FAIL；OSK panel 12/12 assertions PASS。
- [x] AMQ-1713 `src`／`tests`／`tools`／`server` 共 160 個 JS/CJS 檔案語法檢查通過。
- [x] AMQ-1714 `tests/` 的 71 個 Node test files 分 9 組執行，165/165 tests PASS、0 failures；所有組別 exit code 0，日誌位於 `artifacts/batch166-regression/`。
- [ ] AMQ-1715 在允許的真實瀏覽器環境驗收 1440／1024／820／390 viewport、水平捲動、焦點順序及 Skin selection frame；目前環境限制未解除。
- [ ] AMQ-1716 真實 ANN API／CORS／圖片載入驗收；Node fixture 不視為線上驗收。
- [!] AMQ-1717 真實 `.osk` 相容性及非 opaque HTTP origin IndexedDB save/reload/clear 仍受環境限制。


## Batch167：面板建構失敗回滾（2026-10-28）
- [x] AMQ-1718 Statistics Dashboard 先驗證必要 projection dependency，再建立持久化 stores，避免 constructor 早期失敗留下未釋放資源。
- [x] AMQ-1719 新增 Statistics Dashboard regression，projection 缺失時 store factory 呼叫數為 0。
- [x] AMQ-1720 Free Player 在 history store 建立失敗時釋放已建立且由自身擁有的 AudioService，保留原始錯誤。
- [x] AMQ-1721 新增 Free Player regression，history factory 失敗時 AudioService dispose 恰好一次。
- [x] AMQ-1722 受影響測試 4/4 top-level PASS；architecture 1051 PASS／0 FAIL。
- [x] AMQ-1723 `src`／`tests`／`tools`／`server` 共 160 個 JS/CJS 檔案語法檢查通過。
- [x] AMQ-1724 71 個 Node test files 分 9 組執行，165/165 tests PASS、0 failures；所有組別 exit code 0。
- [ ] AMQ-1725 檢查 Catalog mount 是否在建立自有 stores/provider 前驗證必要 DOM／依賴，並對已證實的 failure path 加 regression。
- [ ] AMQ-1726 檢查其他 panel 多資源初始化的 rollback 完整性，只修可重現缺口。
- [!] AMQ-1727 真實 Chromium viewport、ANN API／CORS／圖片、`.osk` 與 HTTP-origin IndexedDB 仍受環境限制。


## Batch168：Catalog 前置驗證與 Quiz Panel 資源回滾（2026-10-28）
- [x] AMQ-1728 Catalog mount 在建立任何自有 Store／Chinese Title Provider 前先驗證必要 root DOM 存在。
- [x] AMQ-1729 新增 Catalog root validation contract，防止未來將資源取得移回 DOM 驗證之前。
- [x] AMQ-1730 Quiz Panel 對初始取得的自有 Blacklist／AMQ SRS／EMQ SRS／Familiarity／Quiz History／App Settings／Personal Library Store 建立回滾追蹤。
- [x] AMQ-1731 若後續 Store 建構或 Personal Library refresh 拋錯，已取得的自有資源按反向取得順序 dispose，保留原始錯誤並附上 cleanup errors。
- [x] AMQ-1732 新增 Quiz Panel acquisition rollback contract，驗證資源取得區塊具有單一 rollback boundary。
- [x] AMQ-1733 受影響 Catalog／Quiz Panel／App Lifecycle 測試 12/12 top-level suites PASS。
- [x] AMQ-1734 架構檢查 1,051 PASS／0 FAIL；OSK import panel 12/12 assertions PASS；src/tests/tools/server 160 個 JS/CJS 語法檢查 PASS。
- [x] AMQ-1735 71 個 Node test files 分 9 個完成組執行，167/167 tests PASS、0 FAIL；初始總控命令超過外層工具時間限制後，剩餘檔案改以較小組別執行，僅將 exit 0 的完成組列為通過。證據位於 `artifacts/batch168-regression/`。
- [ ] AMQ-1736 在可執行真實瀏覽器導覽的環境驗收 Catalog 與 Quiz Panel；本批只做 Node／契約驗證，沒有宣稱真實 UI 驗收。
- [ ] AMQ-1737 真實 ANN API／CORS／圖片、`.osk` 相容性與非 opaque HTTP origin IndexedDB save/reload/clear 仍待可用環境。
- [ ] AMQ-1738 繼續追查 Quiz Panel 在 Store 建立後、Chinese Title Provider／其他後續初始化失敗時的完整 mount rollback，並補實際 failure-injection regression；本批只涵蓋初始 Store acquisition 與 refresh 範圍。


## Batch169：Quiz Provider 回滾與四級作品熟悉度
- [x] AMQ-1739 Chinese Title Provider 建構失敗納入 Quiz Panel 自有資源反向回滾流程。
- [x] AMQ-1740 作品熟悉度規則落實為答錯／超時 1、答對 >15 秒 2、11–15 秒 3、0–10 秒 4。
- [x] AMQ-1741 `all` 模式熟悉度只看作品標題欄位正確性，歌名／歌手答對不能提高作品熟悉度。
- [x] AMQ-1742 標題／歌手單項練習不更新作品熟悉度；`keepHigher` 上限擴為 4。
- [x] AMQ-1743 熟悉度 Store 接受 0–4 並保留舊 0–3 資料相容性。
- [x] AMQ-1744 Query Index 與 Catalog filter 支援 level 4，UI 明確標示五種值（0 未標記、1–4 熟悉度）。
- [x] AMQ-1745 Statistics Dashboard 支援 level4 計數。
- [x] AMQ-1746 Backup/restore preflight 接受 level 4，並以 level-4 fixture 驗證。
- [x] AMQ-1747 Quiz engine 10s／11–15s／>15s 時間邊界及 all-target 作品標題唯一評級測試通過。
- [x] AMQ-1748 受影響測試 15/15 top-level files PASS；架構 1051/0；OSK panel 12/12；160 個 JS/CJS 語法檢查 PASS。
- [x] AMQ-1749 71 個 Node test files 分 9 組完成，168/168 tests PASS、0 FAIL；日誌位於 `artifacts/batch169-regression/`。
- [x] AMQ-1750（Batch170）建立可注入的 Quiz Panel mount failure harness；runtime 注入事件接線失敗，驗證 provider 釋放、History subscription 解除、原始錯誤保留及外部 store 不誤釋放。
- [x] AMQ-1751（Batch170 程式盤點）確認正式 Engine／Session／Clock／AudioService／Quiz Panel 已連接單人 start／播放／暫停／提交／揭曉／下一題／結束與 AMQ／EMQ／MIX 模式切換，Node integration 覆蓋主流程；真實瀏覽器音訊驗收另列阻塞，未宣稱實機里程碑完成。
- [!] AMQ-1752 真實瀏覽器 viewport、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB save/reload/clear 仍受環境限制。

## Batch170：Quiz Panel 執行期失敗注入與清理韌性

- [x] AMQ-1753 為 Quiz Panel 增加 `factories.createChineseTitleProvider`、`factories.createQuizSession` 與 `addEventListener` injection seam；預設正式路徑仍使用原始 API。
- [x] AMQ-1754 新增 runtime failure injection：Chinese Title Provider 已取得後，事件接線拋出指定錯誤；驗證原始錯誤物件保留、provider 恰好 dispose 一次、History subscription 解除，外部注入 stores 不被 dispose。
- [x] AMQ-1755 Quiz Session 建構失敗時，釋放該次 session 專用 AudioService，避免 audio factory 成功而 session factory 失敗造成洩漏。
- [x] AMQ-1756 強化 `disposeSession()`：先清空 session／unsubscribe 引用，再各自 best-effort 清理；其中一項拋錯不阻止另一項執行。
- [x] AMQ-1757 強化 Quiz Panel `dispose()`：逐項嘗試取消訂閱、停止 session、釋放 owned stores／provider、移除 listeners；清理全部嘗試後才回報 AggregateError。
- [x] AMQ-1758 更新 `tests/quiz-panel.test.cjs`，新增 provider/wiring 與 session-construction runtime failure injection，並更新 `tests/catalog-filter-layout.contract.test.cjs` 以匹配新的正式 factory seam。
- [x] AMQ-1759 `node tests/quiz-panel.test.cjs` PASS；兩個注入路徑實際執行。
- [x] AMQ-1760 `node tools/check-architecture.cjs`：1,051 PASS／0 FAIL。
- [x] AMQ-1761 `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- [x] AMQ-1762 `src`／`tests`／`tools`／`server` 共 160 個 JS/CJS 檔案 `node --check` 通過。
- [x] AMQ-1763 `tests/` 下 71 個 `*.test.cjs` 分 9 組執行，9/9 組 exit 0；日誌與 summary 位於 `artifacts/batch170-regression/`。
- [x] AMQ-1764 已追蹤現有單人回合主流程及三模式切換，確認核心責任已由既有 Engine／Session／Clock／AudioService／Panel 承擔；未另建平行狀態機。
- [!] AMQ-1765 真實瀏覽器播放、ANN API／CORS／封面、`.osk` 真實匯入與 HTTP-origin IndexedDB save/reload/clear 仍未驗收。
- [!] AMQ-1766 本工作副本無 `.git`；Candidate302 與 Candidate382 Stage 0 原始檔未包含於交接 ZIP。僅依既有規範確認其基準身份，不聲稱已對缺失原檔執行 hash 比對。


## Batch171：AudioService 部分事件接線失敗回滾（2026-10-28）
- [x] AMQ-1767 以可重現故障注入確認 `media.addEventListener()` 可能在部分 listener 已註冊後拋錯；原始路徑未進入候選 fallback，可能留下 active request。
- [x] AMQ-1768 `src/audio/audio-service.js` 將 listener wiring 例外正規化為候選失敗 `media-listener-failed`，沿用既有 failCandidate／fallback／cleanup 路徑。
- [x] AMQ-1769 清理部分註冊的 handlers、暫停 media 並清除 source；備援候選可進入真實 mock `playing` 事件，維持單一 AudioService owner。
- [x] AMQ-1770 `tests/audio-service.test.cjs` 新增 runtime failure injection，驗證 failure reason/message、primary cleanup、listener detach 與 backup playing。
- [x] AMQ-1771 AudioService 受影響測試 18/18 assertions PASS。
- [x] AMQ-1772 71 個 Node test files 分 9 組逐檔執行，9/9 組 exit 0；完整輸出與 `summary.json` 位於 `artifacts/batch171-regression/`。初始總控觸及外層時間限制，之後分組完成，未把中斷命令當成成功。
- [x] AMQ-1773 架構檢查 1,051 PASS／0 FAIL；OSK import panel 12/12；`src/tests/tools/server` 160 個 JS/CJS `node --check` PASS。
- [!] AMQ-1774 真實瀏覽器音訊、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB 及 viewport 仍待環境驗收；Node／mock media 測試不代表實際可聽。
- [x] AMQ-1775（由 Batch172 完成）檢查 AudioService cancel／fallback／pause 交錯；重入 cancel 缺口已由後續同編號項目修正並回歸。
- [x] AMQ-1776（由 Batch173 完成）補查答題結果 persistence failure 與下一題／回合結束矩陣；四級熟悉度時間邊界與 all 模式標題限定規則未變。


## Batch172：AudioService loading subscriber 重入取消（2026-10-28）
- [x] AMQ-1775 Batch172 以 runtime failure injection 檢查 AudioService cancel/fallback 交錯，證明 `loading` subscriber 同步 cancel 時舊流程仍會在請求終止後建立媒體。
- [x] AMQ-1776 `src/audio/audio-service.js` 在 loading 通知後重查 active request／terminal；取消後不再取得媒體、接線或啟動播放。保留下一批持久化 failure matrix 為待辦。
- [x] AMQ-1777 `tests/audio-service.test.cjs` 新增重入取消 regression；修正前可重現失敗，修正後結果 cancelled 且 mediaFactory 呼叫數為 0。
- [x] AMQ-1778 AudioService 19 個場景全部 PASS。
- [x] AMQ-1779 `tests/` 71 個 Node 測試檔逐檔分 9 組執行，9/9 組 exit 0；證據在 `artifacts/batch172-regression/`。
- [x] AMQ-1780 架構檢查 1,051 PASS／0 FAIL；OSK panel harness 12/12；160 個 JS/CJS `node --check` PASS。
- [!] AMQ-1781 真實瀏覽器音訊、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收；mock／Node 測試不代表實機驗收。
- [!] AMQ-1782 Candidate302 與 Candidate382 Stage 0 原始檔不在工作副本；未 hash 比對、未覆蓋原始基準。
- [x] AMQ-1783（由 Batch173 完成）以可重現測試檢查 pause/resume、晚到 play Promise rejection 與 playback coordinator revoke；timeout stale callback 延續至 Batch174 修正。
- [x] AMQ-1784（由 Batch173 完成）補齊 submit／timeout／skip／auto-next／next-question／round-end 的 persistence failure matrix，保留四級熟悉度規則。


## Batch173：AudioService 晚到 Promise 與結果持久化失敗矩陣（2026-10-28）
- [x] AMQ-1785 新增 pause/resume 後延遲 `play()` Promise rejection 的回歸測試，修正前實際失敗並證明舊 rejection 會把 paused 狀態覆蓋成 loading。
- [x] AMQ-1786 `src/audio/audio-service.js` 以 request-local `playAttemptId` 區分每次播放呼叫；pause 使舊 attempt 失效。
- [x] AMQ-1787 `handlePlayError()` 忽略已終止／已替換 candidate／非最新 attempt／已暫停或已開始播放的舊 rejection，防止錯誤 fallback。
- [x] AMQ-1788 `tests/audio-service.test.cjs` 驗證 resume 已建立新 attempt 後，舊 Promise rejection 不覆寫 playing 狀態、不建立備援 media；AudioService 35/35 PASS。
- [x] AMQ-1789 `tests/quiz-session.test.cjs` 加入 playback lease revoke 後的 late Promise completion regression；既有 `playbackEpoch` guard 正確保留 finished／stopped projection，未新增平行狀態機。
- [x] AMQ-1790 新增 persistence failure matrix：熟悉度與 History adapter 同時失敗時，scored skip／timeout 結果仍提交、完成題數不回滾，且 warning 保留。
- [x] AMQ-1791 驗證 auto-next 不因 persistence failure 被阻斷，下一題可開始且有限回合可正常進入 finished；QuizSession 25/25 PASS。
- [x] AMQ-1792 71 個 Node `*.test.cjs` 檔案分 9 組逐檔執行，9/9 組 exit 0；第 2、8 組於最後測試變更後重跑，日誌在 `artifacts/batch173-regression/`。
- [x] AMQ-1793 架構檢查 1,051 PASS／0 FAIL；OSK panel harness 12/12；160 個 JS/CJS `node --check` PASS。
- [!] AMQ-1794 真實瀏覽器音訊、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收；Candidate302／Candidate382 Stage 0 原始檔不在工作副本，無法 hash 比對。
- [x] AMQ-1795 Batch174 以 fake timer 重現 timeout callback 已排隊、`playing` 先發生的競態；修正前 fallback 建立第二個 media，修正後 stale timeout 不再改寫 playing 狀態。
- [x] AMQ-1796 Batch174 以 20 筆 batch threshold 重現 detail write 失敗但 summary 成功的資料一致性缺口；summary 現在等待 detail 持久化成功後才提交。


## Batch174：AudioService timeout 與 History Store 部分持久化一致性（2026-10-28）
- [x] AMQ-1797 `src/audio/audio-service.js` 抽出 `scheduleCandidateTimeout(request, index)`，統一初始播放與 resume timeout 的候選身分及狀態 guard。
- [x] AMQ-1798 timeout callback 執行時驗證 request 仍 active、候選 index 仍一致、尚未播放、未 blocked／paused；防止已排隊的 stale callback 在 `playing` 後啟動 fallback。
- [x] AMQ-1799 `tests/audio-service.test.cjs` 加入 fake timer race；修正前實際失敗（建立 backup media），修正後 AudioService 21/21 scenarios PASS。
- [x] AMQ-1800 `src/persistence/quiz-history-store.js` 禁止 detail write/read blocked 時持久化包含未提交 entry 的 aggregate summary，保留 pending 與 failure status。
- [x] AMQ-1801 `tests/quiz-history-store.test.cjs` 新增 20 筆 batch summary threshold + detail write failure regression；修正前 summary total 會超前 detail history，修正後原 summary bytes 保持不變。
- [x] AMQ-1802 驗證 detail write 恢復後 `flush()` 可依序持久化 detail 與 summary，20 筆不重複計數；Quiz History Store 14/14 PASS。
- [x] AMQ-1803 QuizSession 25/25 PASS；未更動其 production code 或四級熟悉度規則。
- [x] AMQ-1804 71 個 Node test files 分 9 組執行，9/9 exit 0；完整日誌位於 `artifacts/batch174-regression/`。
- [x] AMQ-1805 Architecture Checker 1,051 PASS／0 FAIL；OSK harness 12/12；160 個 JS/CJS syntax checks PASS。
- [!] AMQ-1806 真實瀏覽器音訊、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收；基準原始檔不在副本，未做 hash 比對。
- [x] AMQ-1807（Batch175 完成）檢查播放開始後 `error` 事件、舊 listener／candidate fallback 的事件競態；既有 candidate index guard／listener detach 通過事件順序回歸。
- [x] AMQ-1808（Batch175 完成）使用 fake timer 檢查 summary debounce callback 在 flush／dispose 後的 stale callback 與重複寫入；generation guard 已修正。

## Batch175：History debounce 生命週期與音訊錯誤事件順序（2026-10-28）
- [x] AMQ-1807 `tests/audio-service.test.cjs` 覆蓋 playing 後 `error` 與舊 candidate handler 晚到呼叫；確認 fallback 僅一次，舊 handler 不改寫 backup 狀態。既有 guard 足夠，未修改 AudioService production code。
- [x] AMQ-1808 `src/persistence/quiz-history-store.js` 新增 `summaryTimerGeneration`／`cancelSummaryTimer()`；flush、summary persist、dispose 使 stale debounce callback 失效。
- [x] AMQ-1809 `tests/quiz-history-store.test.cjs` 新增 flush 後 stale callback regression；修正前額外寫一次 summary，修正後寫入次數不再增加。
- [x] AMQ-1810 新增 dispose 後 stale callback regression；修正前 dispose 後仍額外寫入 summary，修正後 callback 被 generation／disposed guard 忽略。
- [x] AMQ-1811 Quiz History Store 16/16 PASS；包含既有 detail-first partial-write recovery 與新 timer lifecycle 測試。
- [x] AMQ-1812 AudioService 22/22 scenarios PASS；post-playing error 只觸發一次 fallback，舊 candidate listener 無法覆蓋目前候選。
- [x] AMQ-1813 QuizSession 25/25 PASS；本批未改 QuizSession production code 或熟悉度規則。
- [x] AMQ-1814 71 個 Node `*.test.cjs` 分 9 組全數 exit 0；最初總控觸及外層時間限制，最後一組獨立重跑 7/7 通過。證據在 `artifacts/batch175-regression/group-01.log` 至 `group-09.log`。
- [x] AMQ-1815 Architecture Checker 1,051 PASS／0 FAIL；OSK harness 12/12；160 個 JS/CJS `node --check` PASS。
- [!] AMQ-1816 真實瀏覽器音訊、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。
- [!] AMQ-1817 Candidate302／Candidate382 Stage 0 原始檔不在工作副本，無法 hash 比對；原始基準與曲庫資產未覆蓋。
- [x] AMQ-1818 Batch176 已實際重現並修正 detail persistence retry 與外部 storage event 交錯時的本地 pending row 遺失；見 Batch176 區塊與回歸證據。
- [x] AMQ-1819 Batch176 針對可在現有 Node/storage harness 驗證的 History 跨分頁一致性完成 targeted P0/P1 audit，找到兩項可重現問題並修正；其他真實瀏覽器驗收仍阻塞。



## Batch176：跨分頁 History 保存與摘要一致性（2026-10-28）
- [x] AMQ-1818 以 storage event + detail write failure injection 重現：本地紀錄寫入失敗後，外部快照成功刷新會直接覆蓋記憶體，遺失尚未保存的答題列；修正前測試失敗證據位於 `artifacts/batch176-regression/history-cross-tab-before-fix.log`。
- [x] AMQ-1820 `src/persistence/quiz-history-store.js` 新增 `pendingDetailIds`，只追蹤因 detail 寫入失敗而未持久化的本地 entry ID；detail 寫入成功後清空 pending 集合。
- [x] AMQ-1821 外部 storage event 讀取成功時，將外部 detail 快照與本地 pending rows 合併並去重；只合併確定未保存的 rows，不把完整舊 snapshot 重新塞回去。
- [x] AMQ-1822 合併寫入失敗時保留 pending 狀態；後續 storage event 重試成功後，detail 先保存，summary 再依合併後 detail 同步。
- [x] AMQ-1823 新增回歸測試覆蓋：local detail write failure、external row 到達、merge write 再失敗、恢復後重試，最後同時保存 external row 與 local pending row。
- [x] AMQ-1824 以第二項 regression 重現外部 detail snapshot 替換後 summary 只增不減的錯誤：detail 只剩一筆，但 summary total 由 1 增至 2；修正前證據位於 `artifacts/batch176-regression/history-summary-rebuild-before-fix.log`。
- [x] AMQ-1825 當 detail 快照完整且既有 summary 未標記截斷時，外部 detail event 觸發 summary 重建，移除已不在 authoritative detail snapshot 的舊計數。
- [x] AMQ-1826 保留 `baseline.mayBeTruncated` 的保守策略；detail 可能被 2,000 筆上限截斷時不從局部 detail 重建累積 summary，避免低估總歷史。
- [x] AMQ-1827 Quiz History Store 18/18 PASS；包含兩個修正前會失敗的 regression 與既有 debounce/detail-first tests。
- [x] AMQ-1828 AudioService 22 個情境 PASS；QuizSession 25/25 PASS。
- [x] AMQ-1829 71 個 Node `*.test.cjs` 分 9 組全數 exit 0；證據在 `artifacts/batch176-regression/group-01.log` 至 `group-09.log`。總控分組執行曾觸及外層時間限制，之後逐組補完，沒有把逾時命令計為通過。
- [x] AMQ-1830 Architecture Checker 1,051 PASS／0 FAIL；OSK harness 12/12；160 個 JS/CJS `node --check` PASS。
- [!] AMQ-1831 真實瀏覽器音訊、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。
- [!] AMQ-1832 Candidate302／Candidate382 Stage 0 原始檔不在工作副本，無法進行原始檔 hash／相容性比對；原始基準與曲庫資產未覆蓋。
- [x] AMQ-1833 Batch177 新增 summary storage event 先於 detail event 的 controlled regression；外部已提交紀錄不會重複計數，現有實作通過。
- [x] AMQ-1834 Batch177 新增截斷摘要跨分頁 append 與 partial detail replacement regression；累積 total 與 `mayBeTruncated` 保持正確，未發現需改 production code 的可重現 P0/P1。


## Batch177：跨分頁 summary event 順序與截斷摘要邊界（2026-10-28）
- [x] AMQ-1833 summary storage event 先於 detail event 的 regression：事件通知順序不會令同一筆外部紀錄重複計數。
- [x] AMQ-1834 覆蓋 `baseline.mayBeTruncated=true` 的跨分頁追加與 partial detail snapshot replacement；不從不完整 detail 重建摘要，不抹除累積歷史 total。
- [x] AMQ-1835 `tests/quiz-history-store.test.cjs` 新增 3 個跨分頁／截斷邊界 regression；History Store 21/21 PASS。
- [x] AMQ-1836 AudioService 22 個情境 PASS；QuizSession 25/25 PASS。
- [x] AMQ-1837 全部 71 個 Node `*.test.cjs` 檔案逐檔 exit 0；全量 orchestration 的外層逾時未計為成功，後續直接補跑第 59–71 檔並確認 exit 0。
- [x] AMQ-1838 Architecture Checker 1,051 PASS／0 FAIL；OSK harness 12/12；160 個 JS/CJS syntax checks PASS。
- [x] AMQ-1839 確認 `data.js`／`emq-data.js` SHA-256 與 Batch176 ZIP 內資產一致；曲庫未修改。
- [x] AMQ-1840 本批沒有可重現的新增 P0/P1 production defect；只增加 regression，未作假設式 production 修改。
- [!] AMQ-1841 真實瀏覽器跨分頁、音訊、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。
- [!] AMQ-1842 Candidate302／Candidate382 Stage 0 原始檔不在副本，無法做原始基準 hash／相容性驗收。
- [x] AMQ-1843 Batch178 稽核 backup/restore 失敗回滾、schema version、重複匯入、未知 extension 欄位與 source-aware SRS identity；現有契約通過，無需 production 改動。


## Batch178：Backup/restore 與 SRS 相容性邊界（2026-10-28）
- [x] AMQ-1844 新增 backup 重複匯入 idempotency regression，兩次 restore 最終 raw value 相同。
- [x] AMQ-1845 新增 custom-list 未知 extension metadata 與 SRS 未知頂層／card extension 欄位保留 regression；Backup/restore 11/11、SRS Store 35/35。
- [x] AMQ-1846 Backup/restore panel 8/8、Remote SRS Bridge 12/12、71 個 Node tests 全數通過。
- [x] AMQ-1847 Architecture 1,051/0、OSK 12/12、160 syntax checks PASS；資產 hash 與 Batch176 一致。

## Batch179：曲庫更新 active dataset stale-read 競態（2026-10-28）
- [x] AMQ-1848 新增 controlled async regression，重現舊 envelope validation 未完成時 apply 新 envelope 先提交、舊 `getActiveDataset()` 隨後仍回傳過期 snapshot；修正前失敗證據 `artifacts/batch179-regression/database-update-active-read-before-fix.log`。
- [x] AMQ-1849 `src/data/database-update.js` 將 `getActiveDataset()` 與 `apply()`／`clearActive()` 共用 operation queue，移除已冗餘的 `activeValidationPromise`。
- [x] AMQ-1850 新增 active read vs apply／clear 兩項 race regression；Database Update 8 scenarios PASS。
- [x] AMQ-1851 71 個 Node tests 全數通過；database update runtime/source/panel PASS；Architecture 1,051/0、OSK 12/12、160 syntax checks PASS。
- [!] AMQ-1852 真實瀏覽器跨分頁、HTTP-origin IndexedDB、音訊、ANN API／CORS／封面、真實 OSK、viewport／鍵盤與正式基準相容性仍未驗收。
- [x] AMQ-1853 Batch180 以 controlled async regression 驗證 active-dataset read 遇 AMQ→EMQ 模式切換時，舊請求被取消且不發布過期 catalog；現有 runtime／repository 防護通過。


## Batch180：active dataset 讀取期間的模式切換（2026-10-28）
- [x] AMQ-1854 `tests/database-update-runtime.integration.test.cjs` 新增 delayed storage read + AMQ→EMQ mode switch regression。
- [x] AMQ-1855 驗證舊 AMQ request 取消後不發布 catalog；解除 active read gate 後，EMQ catalog 僅包含 EMQ 記錄。
- [x] AMQ-1856 Batch179 的 database update read/apply/clear operation queue 修正通過新整合測試；本批沒有新增可重現 P0/P1 production defect，未改 `src/`。
- [x] AMQ-1857 全部 71 個 Node tests 通過；Database Update Runtime Integration 3 scenarios；architecture 1,051/0、OSK 12/12、160 syntax checks PASS。
- [!] AMQ-1858 真實瀏覽器跨分頁、HTTP-origin IndexedDB、音訊、ANN API／CORS／封面、真實 OSK、viewport／鍵盤與正式基準相容性仍未驗收。
- [x] AMQ-1859 Batch181 稽核 Playback Coordinator reentrant revoke callback；修正修正前可重現的 lease orphaning bug。


## Batch181：Playback Coordinator 重入撤銷競態（2026-10-28）
- [x] AMQ-1860 新增 `onRevoke` 同步重入 `acquire()` regression；修正前失敗，證明內層 lease 可被外層 acquisition 靜默覆寫。
- [x] AMQ-1861 增加 `revoking` guard；撤銷 callback 執行期間拒絕重入 acquisition，回報 `PLAYBACK_COORDINATOR_REVOKING`。
- [x] AMQ-1862 `dispose()` 先標記 disposed 再 revoke，新增 dispose callback acquisition regression，避免幽靈 lease。
- [x] AMQ-1863 Playback Coordinator 7/7、QuizSession 25/25；全量 71 Node tests 通過。
- [x] AMQ-1864 Architecture 1,051/0、OSK 12/12、160 syntax checks PASS；曲庫資產與熟悉度規則未修改。
- [!] AMQ-1865 真實瀏覽器多分頁音訊、HTTP-origin IndexedDB、ANN API／CORS／封面、真實 OSK、viewport／鍵盤與正式基準相容性仍未驗收。
- [x] AMQ-1866 Batch182 修正 revoke callback listener 重入 startRound 抹除已計分進度，以及 dispose 後 late scoring／auto-next 的生命週期漏洞。


## Batch182：QuizSession 撤銷重入與 dispose 後遲到操作（2026-10-28）
- [x] AMQ-1867 新增 revoke callback 期間 engine listener 重入 `startRound()` regression；修正前會將 completedCount 從 1 重設為 0。
- [x] AMQ-1868 新增 disposed session 的 late answer／skip regression；修正前仍接受答案並呼叫持久化 adapter。
- [x] AMQ-1869 新增 dispose 後 stale auto-next callback regression；不能推進下一題或重複寫入。
- [x] AMQ-1870 `src/engine/quiz-session.js` 新增 `revokingPlayback` guard，並讓公開 mutation methods、clock callbacks、audio listener 尊重 disposed 狀態。
- [x] AMQ-1871 QuizSession 28/28、Playback Coordinator 7/7；全量 71 Node tests、architecture 1,051/0、OSK 12/12、160 syntax checks PASS。
- [!] AMQ-1872 真實瀏覽器多分頁音訊、HTTP-origin IndexedDB、ANN API／CORS／封面、真實 OSK、viewport／鍵盤及正式基準相容性仍未驗收。
- [ ] AMQ-1873 Batch183 檢查 revoke callback 中同步 listener 重入 dispose/reset/endRound 與 lease reacquisition policy。


## Batch183：撤銷回呼重入與播放權重新取得政策（2026-10-28）
- [x] AMQ-1873 檢查 revoke callback 中同步 listener 重入 `dispose()`、`reset()`、`endRound()`；`revokingPlayback` guard 防止 reset/endRound 清除已計分狀態，dispose reentry 清理 session 且不會清除新 owner lease。
- [x] AMQ-1874 強化 `tests/quiz-session.test.cjs`：撤銷後 stale auto-next callback、被動 `nextQuestion()`、`resumeAudio()` 不會搶回 lease；明確 `startRound()` 才能透過 coordinator 重新取得播放權。
- [x] AMQ-1875 QuizSession 31/31 PASS；Playback Coordinator 7/7 PASS。
- [x] AMQ-1876 全部 71 個 Node `*.test.cjs` 檔案 71/71 exit 0；首輪 61 個 PASS 後觸及外層執行限制，其餘 10 個獨立重跑成功；`artifacts/batch183-regression/node-tests.tsv` 71 PASS／0 FAIL。
- [x] AMQ-1877 Architecture Checker 1,051 PASS／0 FAIL；OSK harness 12/12；專案內 164 個 JS/CJS `node --check` PASS。
- [x] AMQ-1878 驗證 `src/data/assets/data.js` 與 `emq-data.js` SHA-256 與 Batch182 ZIP 內資產一致；曲庫未修改。
- [x] AMQ-1879 本批沒有發現可重現的新 P0/P1 production defect，因此未修改 `src/`；測試補強與證據已交付。
- [!] AMQ-1880 真實瀏覽器音訊、多分頁 IndexedDB、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤與正式基準相容性仍未驗收。
- [→] AMQ-1881 原定 Batch184 的 engine listener／persistence adapter 重入與 `playbackEpoch`／`playAttemptId` 稽核順延至 Batch185；見 AMQ-1904。


## Batch184：可自訂鍵盤快捷鍵與工作區偏好（2026-10-28）
- [x] AMQ-1882 重新讀取開工規範、工作狀態、主清單、Batch183 handoff／next prompt；確認工作副本無 `.git`，未初始化；Candidate302／Candidate382 Stage 0 原始檔缺席。
- [x] AMQ-1883 新增 `src/persistence/workspace-preferences-store.js`，使用獨立 storage key，不更動既有 App Settings schema。
- [x] AMQ-1884 保存快捷鍵設定、工作區可見性、預設入口與統計順序；含 schema validation、壞資料隔離、跨分頁 storage refresh、dispose 與失敗寫入不提交。
- [x] AMQ-1885 建立 12 個可自訂快捷鍵操作：聚焦答案、開始回合、播放／暫停、揭曉、跳過、下一題、曲庫搜尋、自由播放搜尋、前往設定、隨機播放、前往統計。
- [x] AMQ-1886 預設組合需 Ctrl／Alt／Meta；拒絕重複組合與不支援按鍵；錄製期間 Escape 可取消。
- [x] AMQ-1887 快捷鍵執行忽略文字輸入、textarea、select、contenteditable、textbox、IME composition、AltGraph 與重複 keydown，避免答案輸入時誤觸。
- [x] AMQ-1888 新增 9 個工作區區塊顯示選項，隱藏僅影響呈現，不 dispose 面板或改動答題／播放資料。
- [x] AMQ-1889 新增預設進入功能選項；預設為保留首頁位置，關閉目標區塊時自動取消該區塊的預設入口。
- [x] AMQ-1890 統計儀表板六項資訊支援上移／下移與保存。
- [x] AMQ-1891 將偏好 store／panel 接入 `src/app.js` scope，測試正常 dispose/remount 與 mount failure rollback。
- [x] AMQ-1892 新增 `tests/workspace-preferences-store.test.cjs`，6 組測試涵蓋保存還原、衝突、無效設定、壞資料、storage event、dispose 與寫入失敗。
- [x] AMQ-1893 新增 `tests/workspace-preferences-panel.contract.test.cjs`，32 項靜態契約 assertions PASS。
- [x] AMQ-1894 更新 `tests/app-lifecycle.integration.test.cjs`，驗證新 store／panel 不重複掛載且失敗時回滾。
- [x] AMQ-1895 73 個 Node `*.test.cjs` 檔案逐檔 exit 0；日誌與狀態表位於 `artifacts/batch184-workspace-shortcuts/node-tests/`、`node-tests.tsv`。
- [x] AMQ-1896 Architecture Checker 1,080 PASS／0 FAIL；證據 `artifacts/batch184-workspace-shortcuts/architecture.log`。
- [x] AMQ-1897 OSK import panel harness 12/12 assertions PASS；證據 `artifacts/batch184-workspace-shortcuts/osk-panel.log`。
- [x] AMQ-1898 專案 `src/`、`tests/`、`tools/`、`server/`、`prototype/` 共 168 個 JS/CJS `node --check` PASS。
- [x] AMQ-1899 AMQ／EMQ 資料資產 SHA-256 與 Batch183 相同，未修改曲庫。
- [x] AMQ-1900 修正 `src/index.html` 原有重複 footer 尾碼；Architecture HTML duplicate-ID／local-ref／script-order checks PASS。
- [!] AMQ-1901 Chromium headless 18 秒 timeout、DOM 0 bytes，DBus／zygote 錯誤；真實 UI、快捷鍵錄製、焦點與 viewport 仍未驗收，詳見 `artifacts/batch184-workspace-shortcuts/browser-attempt.txt`。
- [ ] AMQ-1902 具名的多組曲庫篩選預設管理尚未實作；既有猜歌篩選仍沿用 App Settings Store，避免本批複製篩選狀態。
- [!] AMQ-1903 Candidate302／Candidate382 Stage 0 原始檔缺席，無法做 hash／相容性驗收；工作副本無 `.git`，未初始化。
- [ ] AMQ-1904 Batch185 執行 QuizSession listener／persistence adapter reentrancy 與 `playbackEpoch`／`playAttemptId` 跨 explicit restart 的 stale callback 稽核。


## Batch185：QuizSession 同步重入與舊回合遲到回呼（2026-10-28）
- [x] AMQ-1905 重新讀取規範、工作狀態、主清單、Batch184 handoff／next prompt；確認無 `.git`，未初始化，正式基準原始檔缺席。
- [x] AMQ-1906 `src/engine/quiz-session.js` 新增 `mutateEngine()`，抑制 engine publish 在 Session transition 中直接通知外部 subscribers，避免 callback 重入外層操作。
- [x] AMQ-1907 `persistProgress()` 以同步提交 guard 包覆 familiarity／history adapters；adapter 重入 Session mutation 回傳 `persistence-in-progress`，確保另一個 adapter 仍會被呼叫。
- [x] AMQ-1908 新增 listener reentry regression：答題狀態通知後 listener 可執行 reset，但兩個 store 已各自恰好寫入一次，最終 reset 狀態不被外層答題操作覆蓋。
- [x] AMQ-1909 新增 persistence adapter reentry regression：adapter callback 內 reset 被拒絕，history 寫入不遺失、不重複。
- [x] AMQ-1910 新增 explicit restart stale Promise regression：前一回合舊音訊 Promise 在同一歌曲重新開始後完成，不得覆寫新回合狀態。
- [x] AMQ-1911 QuizSession 34/34 PASS；全量 73 個 Node test files 73/73 exit 0；詳見 `artifacts/batch185-regression/`。
- [x] AMQ-1912 Architecture Checker 1,080 PASS／0 FAIL；OSK harness 12/12；168 個 JS/CJS 語法檢查 PASS。
- [x] AMQ-1913 確認 AMQ／EMQ 資產 SHA-256 與 Batch184 ZIP 相同；未修改曲庫、熟悉度規則、`playAttemptId`／`playbackEpoch` 契約或單一 playback owner。
- [!] AMQ-1914 真實瀏覽器、音訊可聽性、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤及正式基準相容性尚未驗收。
- [ ] AMQ-1915 Batch186：測試非計分操作與 AudioService stop 通知交錯的同步 listener reentry；只修可重現 P0/P1。
- [ ] AMQ-1916 評估具名多組曲庫篩選預設的最小安全設計，沿用既有 App Settings 狀態來源，避免雙重保存與模式間污染。


## Batch186：AudioService callback 重入保護（2026-10-28）
- [x] AMQ-1917 檢查 `nextQuestion()`、`skip()`、`pause()`、`reset()`、`endRound()` 的同步 AudioService event callback 邊界。
- [x] AMQ-1918 `src/engine/quiz-session.js` 新增 `sessionTransitionInProgress`，同步轉移期間忽略 AudioService 的中間 Session notification，並拒絕重入 mutation。
- [x] AMQ-1919 新增 nextQuestion stop callback regression：callback 重入 reset 回傳 `session-transitioning`，下一題仍正常播放。
- [x] AMQ-1920 新增 reset／endRound stop callback regression：callback 重入 startRound 被拒絕，外層指定操作完整結束。
- [x] AMQ-1921 新增未播放 skip stop callback regression：callback 重入 startRound 被拒絕，未播放跳過不計分且完成數維持 0。
- [x] AMQ-1922 QuizSession 37/37 PASS；全量 73 個 Node test files 73/73 exit 0。
- [x] AMQ-1923 Architecture Checker 1,080 PASS／0 FAIL；OSK harness 12/12；168 個 JS/CJS 語法檢查 PASS。
- [x] AMQ-1924 確認 AMQ／EMQ 資產 hash 未變；未更動熟悉度、all-target、`playAttemptId`／`playbackEpoch` 契約。
- [!] AMQ-1925 真實瀏覽器／音訊、外部 API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤及正式基準相容性仍未驗收。
- [x] AMQ-1926 Batch187：盤點具名多組曲庫篩選預設的 schema／UI／storage contract，沿用既有設定狀態，禁止建立第二個 filter source of truth；完成實作與回歸。
- [~] AMQ-1927 產品功能優先批次期間暫緩無新增證據的 Session／AudioService callback audit；若有可重現 P0/P1 再插隊處理。


## Batch187：具名曲庫篩選預設與進階篩選盤點（2026-10-28）

- [x] AMQ-1928 在既有 `amqLearningAppSettingsV1` 增加可選 `catalogFilterPresets`，沿用 schemaVersion 1 的向後相容 extension，不建立第二個設定 key。
- [x] AMQ-1929 新增預設資料驗證：最多 30 組、名稱 1–40 字且不分大小寫不可重複、ID 唯一、欄位白名單、年份／年代／熟悉度／看番狀態／排序／每頁筆數範圍驗證。
- [x] AMQ-1930 `getSettings()` 深拷貝具名預設的巢狀 filter snapshot，避免外部呼叫者修改內部狀態。
- [x] AMQ-1931 Catalog UI 新增預設選擇、命名、保存／同名更新、套用、刪除與狀態訊息；套用涵蓋全部目前 filter、sort field/direction 及 page size。
- [x] AMQ-1932 預設只保存 controller snapshot；活動篩選仍以 Catalog controller 為唯一來源，沒有另建即時 filter store。
- [x] AMQ-1933 新增 App Settings Store preset schema／legacy／reload／巢狀隔離測試與 Catalog Browser 整合測試。
- [x] AMQ-1934 猜歌進階篩選盤點：年份起迄、未知年份、作品類型、難度上下界、歌曲類型、看番狀態已有實作及回歸；季別欄位沒有可信來源，不猜測新增。
- [x] AMQ-1935 修正篩選契約文件中過時的熟悉度 0–3 描述，明確記錄目前 UI 支援 0–4。
- [x] AMQ-1936 更新 `docs/PRODUCT_SCOPE_DECISIONS_BATCH187.md`，明確排除探索新歌、歌手圖鑑、答案別名提示，並保留使用者最新的功能範圍。
- [x] AMQ-1937 Backup/restore 11/11、QuizPanel filter matrix 768/768、filter composition matrix 2048/2048、Catalog controller 6/6、Catalog integration PASS。
- [x] AMQ-1938 全量 73 個 Node test files 73/73 exit 0；逐檔日誌與狀態見 `artifacts/batch187-regression/node-tests/`、`node-tests.tsv`。
- [x] AMQ-1939 Architecture Checker 1,080 PASS／0 FAIL；OSK harness 12/12；168 個 JS/CJS `node --check` PASS。
- [x] AMQ-1940 AMQ／EMQ 資產 SHA-256 與 Batch186 ZIP 相同；未修改資料資產。
- [!] AMQ-1941 真實瀏覽器視覺／互動、HTTP-origin storage 與正式 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- [x] AMQ-1942 Batch188：核對 Catalog record identity／既有 schema；確認沒有既有 tag store，新增單一 source-aware Song Tags Store 契約。
- [ ] AMQ-1943 Batch189：補完 Free Player Dock 音量／靜音／收合、佇列／播放模式及播放歷史端到端接線。
- [x] AMQ-1944 Batch190：備份／還原 UI 完整流程與作品層級學習進度整合。
- [x] AMQ-1945 Batch191：播放器視覺化與既有 Free Player 狀態／AudioService 連接。
- [~] AMQ-1946 Batch192：完成 provider 安全邊界與取消／逾時契約；OAuth lifecycle、MAL quota、VNDB private list 與 live API E2E 仍待處理。
- [ ] AMQ-1947 Batch193：多人猜歌完整流程缺口，檢查既有 HTTP transport、room state、權限及音訊同步後分批實作。
- [ ] AMQ-1948 最後階段：依 osu!stable／OSK 既定方向真正替換舊 UI／CSS，保留可直接讀取的皮膚素材，對無法映射部分建立替代元件。


## Batch188：曲庫批次操作與歌曲標籤（2026-10-28）

- [x] AMQ-1949 新增 `src/persistence/song-tags-store.js`，提供標籤 CRUD、來源明確的歌曲標籤關聯、跨分頁 refresh、損壞資料隔離與寫入失敗不提交。
- [x] AMQ-1950 標籤名稱驗證：最多 200 個標籤，名稱正規化、1–32 字、不分大小寫唯一；tag ID 唯一。
- [x] AMQ-1951 標籤 assignment 使用 `AMQData.identity.createIdentity(source, id)`；AMQ／EMQ 同數字 ID 與 number/string ID 分開。
- [x] AMQ-1952 新增原子 `setSongTagForMany()`，批次套用／移除標籤以單次 storage commit 完成；失敗不更新記憶體 state。
- [x] AMQ-1953 `src/data/query-index.js` 新增 `tagId` filter，支援 AND composition 與多標籤 any-match，並將衍生 `tagIds` 凍結於 snapshot。
- [x] AMQ-1954 Catalog UI 新增標籤建立／改名／刪除、標籤篩選、每列多選、選取本頁、清除選取、批次加入自訂清單、批次套用／移除標籤。
- [x] AMQ-1955 批次選取使用 source-aware identity，保留跨分頁選取，切換 AMQ／EMQ／MIX 時清空。
- [x] AMQ-1956 刪除活動標籤會清除無效 filter 並移除所有關聯；tag CRUD 更新後重建 Catalog query-index。
- [x] AMQ-1957 `amqSongTagsV1` 加入既有 backup/restore key 清單與 schema preflight；舊備份省略此 key 時不會刪除目前標籤。
- [x] AMQ-1958 新增 `tests/song-tags-store.test.cjs`：8/8 PASS，覆蓋 CRUD、重複名稱、source identity、批次操作、刪除關聯、reload、寫入失敗、損壞資料與 storage event。
- [x] AMQ-1959 Query-index tag filter、Catalog controller、Catalog Browser integration、Backup/restore、App lifecycle tests PASS；backup/restore 11/11。
- [x] AMQ-1960 全量 74 個 Node test files 74/74 exit 0；逐檔 log／status 在 `artifacts/batch188-regression/`。首輪 orchestrator 觸及外層工具時間限制時尚缺 `quiz-pool.test.cjs`；該檔已獨立重跑 10/10 PASS。
- [x] AMQ-1961 Architecture Checker 1,095 PASS／0 FAIL；OSK harness 12/12；170 個 JS/CJS syntax checks PASS。
- [x] AMQ-1962 更新 `DATA_CONTRACT.md`、`BACKUP_RESTORE_CONTRACT_BATCH76.md`、`SONG_TAGS_CONTRACT_BATCH188.md`、`tests/tests.html`、工作狀態與交接。
- [!] AMQ-1963 真實瀏覽器視覺／多選操作、HTTP-origin storage 及正式 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- [x] AMQ-1964 Batch189：完成 Free Player Dock 音量／靜音／收合、進度 seek 與播放控制；沿用 AudioService 單一播放 owner。
- [x] AMQ-1965 Batch189：新增自由播放佇列、播放佇列項目、移除／清空與順序／循環／隨機模式，定義重複曲目與目前項目刪除行為。
- [x] AMQ-1966 Batch189：自然 ended event 自動推進佇列；播放歷史保留 5 秒門檻並使用跨 Dock lifetime 唯一 ID。
- [x] AMQ-1967 Batch190：完成備份／還原 UI 全流程，涵蓋預檢、確認、錯誤／回滾及標籤資料。
- [x] AMQ-1968 Batch190：作品層級學習進度接入現有資料層與統計 UI。
- [x] AMQ-1969 Batch191：播放器視覺化接線至既有播放狀態與時間進度。
- [~] AMQ-1970 Batch192：adapter 資料映射與失敗恢復已補強；實際 OAuth／帳號同步仍未完成。
- [ ] AMQ-1971 Batch193：多人猜歌完整流程，包括音訊同步、正式傳輸、伺服器權限及多客戶端。
- [ ] AMQ-1972 最後階段：依 osu!stable／OSK 方向真正替換舊 UI／CSS，優先重用可讀取的 OSK 素材。


## Batch189：自由播放 Dock、佇列與播放歷史（2026-10-28）

- [x] AMQ-1973 AudioService 新增安全 `setVolume()`／`setMuted()`／`seek()` API，設定套用至目前媒體及後續 fallback candidate；音量限制 0–1，seek 限制於媒體 duration。
- [x] AMQ-1974 AudioService 接入原生 `ended` 事件，發布 `ended` 狀態並釋放 active media；保留舊 request stale callback guard。
- [x] AMQ-1975 Free Player Dock 新增音量滑桿、靜音切換、進度顯示／seek 與收合控制；播放進度隨既有 tick 更新。
- [x] AMQ-1976 新增 source-aware 播放佇列、加入所選歌曲、播放佇列項目、移除項目、清空佇列、上一首／下一首。
- [x] AMQ-1977 新增順序／循環／隨機播放模式，包含自然結束自動推進、順序模式到尾停止、循環模式回到首項及 shuffle 不立即重複目前項（多項佇列）。
- [x] AMQ-1978 定義移除目前播放項會停止該項並清除 current record；移除其他項會修正目前 index；清空佇列會停止播放並清空 queue history。
- [x] AMQ-1979 播放歷史仍只在實際播放累積至少 5 秒後寫入；同一 sequence 不重複記錄，Dock remount 使用獨立 history ID。
- [x] AMQ-1980 新增 AudioService tests：音量／靜音／seek、active media 更新、natural ended state、舊音訊候選回歸均 PASS。
- [x] AMQ-1981 Free Player Dock tests 覆蓋 queue dedupe、loop／shuffle／sequential、previous／next、自然結束推進、volume／mute／seek／collapse、移除／清空佇列與 remount history ID。
- [x] AMQ-1982 AMQ／EMQ 曲庫資產唯讀；沒有建立第二個 AudioService owner，Free Player Dock 仍使用獨立 AudioService instance，不與 QuizSession 共享播放狀態。
- [!] AMQ-1983 真實 HTMLAudioElement ended／seek／音量、瀏覽器背景播放、viewport／Dock 實際固定效果仍待使用者瀏覽器驗收。
- [x] AMQ-1984 Batch190：完成備份／還原 UI 全流程（預檢、確認、錯誤與回滾）及標籤資料流程。
- [x] AMQ-1985 Batch190：整合作品層級學習進度與現有資料層／統計 UI。
- [x] AMQ-1986 Batch191：播放器視覺化接線至 AudioService 狀態與進度。
- [~] AMQ-1987 Batch192：adapter 取消／逾時與錯誤契約已補強；憑證設定與 live acceptance 仍阻塞。
- [ ] AMQ-1988 Batch193：多人猜歌 UI、正式傳輸、音訊同步、伺服器權限與多客戶端流程。
- [ ] AMQ-1989 最後階段：依 osu!stable／OSK 路線真正替換舊 UI／CSS，優先重用可讀取素材。

- [x] AMQ-1990 Batch189 全量 74 個 Node test files 74/74 exit 0；`artifacts/batch189-regression/node-tests.json`。
- [x] AMQ-1991 Architecture Checker 1,095 PASS／0 FAIL；OSK harness 12/12；170 個 JS/CJS syntax checks PASS。
- [x] AMQ-1992 確認 AMQ／EMQ data assets SHA-256 與 Batch188 相同，未修改唯讀曲庫。


## Batch190：備份／還原流程與作品學習進度（2026-10-28）
- [x] AMQ-1993 核對備份／還原 panel、service、schema preflight 與既有流程測試；未另造平行備份寫入路徑。
- [x] AMQ-1994 備份內容標籤補上 `amqSongTagsV1` 使用者可讀名稱，更新 UI 說明列出歌曲標籤與看番狀態。
- [x] AMQ-1995 保留選檔／讀檔、預檢、使用者確認、取消、下載、提交錯誤與 rollback failure 狀態處理；既有 checksum／schema validation 與 preflight no-write 規則未改。
- [x] AMQ-1996 `src/learning/statistics-dashboard.js` 新增作品層級衍生進度：依 source + work kind + animeId 分組，舊資料才 fallback 至作品標題；提供答題數、正確率、唯一歌曲數與最近作答時間。
- [x] AMQ-1997 作品進度為純衍生統計，不新增持久化 key，不混用歌曲熟悉度與作品進度；AMQ／EMQ 相同作品數字 ID 維持來源隔離。
- [x] AMQ-1998 `src/index.html`／`src/ui/statistics-dashboard-panel.js` 新增作品學習進度區塊，空資料時顯示明確說明。
- [x] AMQ-1999 更新統計投影與 UI 測試，覆蓋作品聚合、跨來源隔離、唯一歌曲數、正確率及 UI 顯示。
- [x] AMQ-2000 targeted tests：Statistics dashboard PASS；Statistics dashboard panel PASS；Backup/restore panel 8/8；Backup/restore service 11/11。
- [x] AMQ-2001 全量 74 個 Node test files 74/74 exit 0；Architecture 1,095/0；OSK harness 12/12；170 個 JS/CJS syntax checks PASS，證據在 `artifacts/batch190-regression/`。
- [!] AMQ-2002 真實瀏覽器下載／選檔／作品進度 UI、HTTP-origin storage、音訊、外部 API／CORS、真實 OSK、viewport／鍵盤及 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- [x] AMQ-2003 Batch191：播放器視覺化接線至既有 AudioService 狀態與播放進度，不建立第二個播放狀態來源。
- [~] AMQ-2004 Batch192：完成不需使用者憑證的安全修正；OAuth、MAL quota 與外部帳號 E2E 未完成。
- [ ] AMQ-2005 Batch193：多人猜歌完整流程，先核對既有 HTTP transport、room state、權限與音訊同步。
- [ ] AMQ-2006 最後階段才真正替換舊 UI／CSS，沿用 osu!stable／OSK 方向及已接受的視覺成果。


## Batch191：Free Player Dock 播放狀態視覺化（2026-10-28）
- [x] AMQ-2007 進度滑桿以 AudioService metrics 更新 CSS 進度比例，時間資訊加上 `aria-valuetext`，seek 仍透過 AudioService API。
- [x] AMQ-2008 新增 playing、loading／ready、paused／stopped／ended、failed／blocked 的 CSS 狀態差異與 range track 樣式，保留現有 Dock／佇列／音量／模式互動。
- [x] AMQ-2009 更新 Free Player Dock 回歸測試，覆蓋狀態投影、pause、失敗、恢復播放、時間輔助文字與既有自然 ended／佇列流程。
- [x] AMQ-2010 新增 `tests/free-player-visual-contract.test.cjs`，21 項契約 assertions PASS。
- [x] AMQ-2011 75/75 Node test files exit 0；逐檔證據見 `artifacts/batch191-regression/node-tests.tsv`。
- [x] AMQ-2012 Architecture Checker 1,102 PASS／0 FAIL；OSK harness 12/12；172 JS/CJS syntax checks PASS。
- [x] AMQ-2013 AMQ／EMQ 資產 SHA-256 未變，見 `artifacts/batch191-regression/asset-sha256.txt`。
- [!] AMQ-2014 真實瀏覽器檢查被執行環境阻擋：Chromium 對 file 與本機 HTTP 頁面皆回報 `ERR_BLOCKED_BY_ADMINISTRATOR`；viewport、computed style 與真實音訊未驗收。
- [x] AMQ-2015 Batch192：盤點 AniList／MAL／VNDB provider、授權、資料映射與失敗恢復；完成不需使用者憑證的安全修正，詳見 `docs/HANDOFF_BATCH192.md`。


## Batch192：AniList／MAL／VNDB provider 安全與取消契約（2026-10-28）

- [x] AMQ-2015 完成三家 provider／授權／資料映射／失敗恢復盤點，新增 `docs/EXTERNAL_PROVIDER_AUDIT_BATCH192.md`。
- [x] AMQ-2016 MAL public read 與 private OAuth 分流：public read 使用顯式 `clientIdProvider`／`X-MAL-CLIENT-ID`，private read／mutation 使用 OAuth2 Bearer token。
- [x] AMQ-2017 禁止呼叫端自行注入 Authorization 或覆寫 MAL client ID header；缺少／無效憑證 fail closed。
- [x] AMQ-2018 AniList／MAL／VNDB feature methods 全面傳遞 `AbortSignal` 與 `timeoutMs`，含搜尋、清單、精確查詢及 mutation。
- [x] AMQ-2019 MAL malformed rows／paging 與 AniList malformed list／entry 有防禦性正規化回歸。
- [x] AMQ-2020 VNDB timeout 預設 2.5 秒、上限 2.8 秒；保留取消、429、timeout 與 dispose 的既有錯誤契約，沒有盲目自動重試。
- [x] AMQ-2021 更新 `tests/external-service-adapter.test.cjs`、`tests/external-service-feature-adapters.test.cjs`；focused tests PASS。
- [x] AMQ-2022 全量 75 個 Node test files 75/75 exit 0；證據在 `artifacts/batch192-regression/node-tests.tsv` 與 `node-tests/`。
- [x] AMQ-2023 Architecture Checker 1,102 PASS／0 FAIL；OSK harness 12/12；172 JS/CJS syntax checks PASS。
- [x] AMQ-2024 AMQ／EMQ 資產 SHA-256 與 Batch191 一致，沒有修改唯讀曲庫。
- [!] AMQ-2025 AniList／MAL OAuth callback、token lifecycle、安全儲存與帳號同步 UI 尚未實作；解除條件為確認 OAuth grant／redirect 與安全 token storage 設計。
- [!] AMQ-2026 MAL quota 未核實；正式啟用前需重新確認目前官方 reference，不硬編碼請求配額。
- [!] AMQ-2027 Live API／OAuth／CORS／外部帳號 E2E 未執行；Node mocks 不視為 live acceptance。
- [!] AMQ-2028 Candidate302／Candidate382 Stage 0 原始基準缺席；無 `.git`，未初始化，未覆蓋原始基準。
- [~] AMQ-2029 Batch193–194：多人 HTTP transport／room state／權限／冪等與 server-authoritative scoring 的核心檢查持續進行；Batch193 已修正逾時持久化失敗的零延遲重試，音訊同步／投影威脅模型留 Batch194。
- [ ] AMQ-2030 最後階段才進行全面 UI／CSS 替換與真實瀏覽器驗收。


## Batch194：多人題目投影與輪詢一致性契約（2026-10-28）
- [x] AMQ-2049 定義目前多人題目投影威脅模型，區分一般資料遮蔽與抵抗惡意客戶端的強反作弊；記錄 `questionId`／音訊 URL 的可觀察性與未來 opaque identity 的完整遷移要求，見 `docs/MULTIPLAYER_THREAT_MODEL_BATCH194.md`。
- [x] AMQ-2050 `tests/multiplayer-room-session.test.cjs` 新增 controlled regression：較舊的 polling response 在較新的 command snapshot 套用後才完成，不能回滾 revision 或向 subscribers 發布過期 revision。
- [x] AMQ-2051 重新執行多人 host integration 與 panel integration，確認 projection 與既有 UI 契約未被破壞。
- [x] AMQ-2052 全量 Node tests 75/75、Architecture Checker 1,102/0、OSK harness 12/12、172 JS/CJS syntax checks 與 AMQ／EMQ asset hashes 全部通過；真實多客戶端瀏覽器／音訊仍需可用瀏覽器環境。
- [!] AMQ-2053 opaque public round identity／移除公開 `questionId`：需要同時變更 snapshot DTO、UI round matching 與測試，且要先確認產品接受度；本批只記錄威脅，不做不完整的單欄位遮蔽。
- [!] AMQ-2054 真實多客戶端音訊同步驗收：目前瀏覽器導覽有 `ERR_BLOCKED_BY_ADMINISTRATOR`；解除條件為可用的真實瀏覽器測試環境。

## Batch193：多人房間逾時持久化退避（2026-10-28）
- [x] AMQ-2031 讀取多人服務契約、Batch115 handoff、host／room state／command service／HTTP transport／UI panel 與相關測試；確認無 `.git`，未初始化，正式基準原始檔缺席且未覆蓋。
- [x] AMQ-2032 找出逾時結算持久化失敗後，已過期回合會重排 `setTimeout(0)` 的高頻重試缺陷。
- [x] AMQ-2033 `server/multiplayer-host.cjs` 注入 timer seams，新增可設定 timeout retry backoff，預設 1000ms、允許 100–60000ms；過期回合恢復時不再零延遲忙等。
- [x] AMQ-2034 `tests/multiplayer-host-retention.test.cjs` 新增 SQLite failure-injection，覆蓋 timer 與 GET snapshot 兩種 timeout persistence failure 路徑，並確認資料庫恢復後可完成 timeout。
- [x] AMQ-2035 保存修正前失敗證據 `artifacts/batch193-regression/timeout-backoff-before-fix.log`；修正前預期 1200ms 卻實際排程 0ms。
- [x] AMQ-2036 修正後 host retention 2/2 PASS；最終程式碼上 13 個多人／server auth test files 13/13 PASS。
- [x] AMQ-2037 全量 75 個 Node test files 75/75 exit 0；外層 runner 在 59 個檔案後觸及時間限制，剩餘 16 個分批補跑；證據 `artifacts/batch193-regression/`。
- [x] AMQ-2038 Architecture Checker 1,102 PASS／0 FAIL；OSK import panel harness 12/12；172 個 JS/CJS syntax checks PASS。
- [x] AMQ-2039 AMQ／EMQ 資產 SHA-256 與 Batch192 一致，未修改唯讀曲庫。
- [!] AMQ-2040 多人真實瀏覽器／多客戶端音訊同步未驗收；HTTP polling 不是 WebSocket，部署仍限單一 server process／SQLite。
- [!] AMQ-2041 題目投影的 questionId／audio URL 可能被可檢查本機曲庫的客戶端關聯答案；目前答案遮蔽不應被宣稱為強反作弊。需先定義威脅模型，再選擇 opaque round identity／audio proxy 等方案。
- [!] AMQ-2042 Candidate302／Candidate382 Stage 0 原始檔缺席，無法驗收基準相容性；無 `.git`，未初始化。
- [x] AMQ-2043 Batch194：定義多人題目投影與音訊同步威脅模型，補 stale polling 契約測試並記錄多客戶端驗收阻塞；詳見 Batch194 區段。
- [ ] AMQ-2044 最後階段才進行全面 UI／CSS 替換與真實瀏覽器視覺驗收。


## Batch195：OSK 解讀與正式 UI 契約

- [x] AMQ-447 重新確認正式 UI 不可再無限延後；主工作路線已更新為 OSK 契約 → Mapping Studio → 正式 UI 外殼 → 逐頁接功能 → 實際驗收。
- [x] AMQ-448 盤點官方 stable skinning 的主選單、選曲、面板、遊戲中 HUD、結算、`skin.ini` 與音效分類；新增 `docs/OSK_SKINNING_CATALOG_AND_AMQ_UI_CONTRACT_BATCH195.md`。
- [x] AMQ-449 核實 `ppy/osu` 是 osu!lazer 公開原始碼，不能當作 osu!stable 原始碼；以官方 Wiki 的 stable 檔名／用途規格作為第一版契約來源。
- [x] AMQ-450 對照目前 importer／panel／store，確認目前只映射少量素材角色，`skin.ini` 解析不完整；將此落差明確記錄，沒有把「可讀取 OSK」誤記成「可完整套用 OSK」。
- [~] AMQ-451 建立版本化 stable asset manifest（檔名、用途、skin version、尺寸／動畫／tint／fallback）；目前仍是已審查子集，不是完整目錄。
- [x] AMQ-452 建立 AMQ UI role manifest，並以 runtime contract 與 JSON manifest equality tests 確保角色 ID／用途同步；新角色的正式視覺套用仍部分未完成。
- [~] AMQ-453 OSK importer 已支援圖片與 WAV／MP3／OGG，保存 raw skin.ini 與未知 section/key；完整 stable 檔案目錄仍待核對。
- [x] AMQ-454 建立角色分組 Mapping Studio，按頁面顯示用途、stable 候選、AMQ extension、fallback 與圖片預覽；真實正式 UI 的全部 role runtime 套用仍待接線。
- [x] AMQ-455 theme store schema 2 支援任意 roleMappings，schema 1 自動遷移並保留 legacy mappings／raw skin.ini；unsupported runtime role 尚以映射資料保存，尚未全部視覺套用。
- [ ] AMQ-456 建立正式 UI 共用 Skin 元件與 token runtime；頁面不得直接自行挑任意 OSK 路徑。
- [ ] AMQ-457 先重建首頁大餅式導覽與選歌頁，接入既有功能而非 mock-only 原型。
- [ ] AMQ-458 接入猜歌單人／多人、學習中心與設定頁，遊戲房間設定仍留在遊戲流程。
- [~] AMQ-459 已測試 manifest ID、引用、fallback、runtime manifest 同步；尚需在正式頁面整合後補每頁的實際 computed-style／fallback browser tests。
- [!] AMQ-460 真實 `.osk` 與完整瀏覽器 E2E 尚未驗收；解除條件為取得可用測試樣本及可執行的真實瀏覽器環境。

## Batch196：OSK Mapping Studio 與 schema migration（2026-10-28）
- [x] AMQ-2060 建立 `src/skins/skin-contract.js` runtime contract，並用測試確保與文件 JSON manifest 一致。
- [x] AMQ-2061 Mapping Studio 依首頁／選歌／猜歌／多人／結算／學習中心／設定／共用播放器／共用元件分組顯示角色。
- [x] AMQ-2062 每個 role 顯示人類可讀用途、stable 原生檔名候選、AMQ extension 標記、fallback、圖片預覽與可手動替換／清除。
- [x] AMQ-2063 新增按 stable 檔名推導建議映射與「還原建議映射」操作；不把任意角色圖自動當歌曲封面。
- [x] AMQ-2064 OSK importer 讀取圖片與 WAV／MP3／OGG，保存 raw skin.ini 與未知 section/key；ZIP path traversal／大小限制保持原狀。
- [x] AMQ-2065 Theme store schema 2 支援任意 roleMappings，schema 1 migration 保留 legacy 三角色映射與素材。
- [x] AMQ-2066 Portable theme transfer 保留 roleMappings／skin.ini，支援圖片與音效二進位素材；不將 skin.ini 當圖片打包。
- [x] AMQ-2067 manifest／store／transfer 17/17 focused tests PASS；OSK importer 10/10 PASS。
- [x] AMQ-2068 真實 Chromium panel integration 12/12 assertions PASS；Mapping Studio 角色生成、skin.ini、套用／清除與匯出均有實際瀏覽器證據。
- [x] AMQ-2069 Architecture Checker 1,116 PASS／0 FAIL。
- [x] AMQ-2070 76/76 Node test files 逐檔 exit 0；`quiz-pool.test.cjs` 單獨執行 10/10 assertions、約 18.3 秒。合併 `node --test` runner 會因該測試的長時間分布抽樣觸及環境時間限制，逐檔證據在 `artifacts/batch196-regression/node-tests.tsv`。
- [~] AMQ-2071 新角色映射已能預覽／保存，但正式 adapter 尚只套用舊 background／selectionFrame／characterOverlay 三角色；不可把所有 role 說成已套用。
- [ ] AMQ-2072 正式首頁大餅導覽與 osu!stable 模板式選歌頁外殼尚未開始實際替換舊頁面；下一批優先進行。
- [!] AMQ-2073 真實使用者 `.osk`、完整 stable 素材清單、Candidate302／Candidate382 Stage 0 相容性尚未驗收；原始基準缺席且無 `.git`。

## Batch197：正式 UI 外殼與 role-aware Skin runtime（2026-10-28）

- [x] AMQ-2074 新增 `src/ui/app-shell.js`，建立首頁／選歌／猜歌／學習中心／設定五個正式頁面容器，既有功能模組按責任移入對應頁面，維持既有 DOM ID 供模組接線。
- [x] AMQ-2075 首頁新增可展開的大餅式主選單，四個入口為選歌、猜歌（單人／多人）、學習中心與設定；返回首頁與頁面導覽同步更新標題及 aria-current。
- [x] AMQ-2076 新增 `src/styles/ui-shell.css`，將正式外殼從白底面板改為深色、低圓角、粉色強調的 osu!stable-inspired 視覺；新增桌面／390px 手機樣式及 reduced-motion 規則。
- [x] AMQ-2077 將曲庫與播放器放在選歌頁；單人／多人面板放在猜歌頁；統計放在學習中心；OSK、備份／還原、曲庫更新、帳號與工作區偏好放在設定頁。
- [x] AMQ-2078 `src/skins/theme-adapter.js` 新增 role-aware runtime，為 11 個具備實際 DOM selector／CSS token 的角色提供明確套用目標；未知或未接線角色回報 `unsupported-role`，不再靜默假套用。
- [x] AMQ-2079 新增 CSS token 接線：首頁背景／大餅、選曲列／選取列／懸停、猜歌背景、多人面板、播放器底座、學習進度面板、設定面板及導覽分頁；reset 會移除對應 token 與 Object URL。
- [x] AMQ-2080 修正主題匯出下載的 Object URL 過早撤銷問題；下載完成後延遲移除 anchor 並撤銷 URL。`tests/osk-import-panel.browser.test.py` 原本在 `expect_download` 超時，修正後 12/12 assertions PASS。
- [x] AMQ-2081 新增 `tests/app-shell.browser.test.py`，使用 Chromium 載入完整正式 HTML（內嵌本機 CSS／JS，以避開此環境對 localhost 導覽的限制），驗證首頁、四入口、五頁路由、既有模組 ID、Skin role 實際 token 套用、unsupported role 回報及 390px 無水平溢位：18/18 PASS。
- [x] AMQ-2082 76 個 Node test files 逐檔執行全部 exit 0；逐檔日誌 `artifacts/batch197-regression/*.test.log`，彙總 `node-tests.tsv`。`quiz-pool.test.cjs` 10/10，約 18 秒；不以 aggregate runner 超時代表測試失敗或通過。
- [x] AMQ-2083 Architecture Checker 1,123 PASS／0 FAIL；174 個 JS/CJS 語法檢查 PASS；OSK import panel Chromium fixture 12/12 PASS；manifest／adapter／store／transfer focused tests 28/28 PASS。
- [x] AMQ-2084 AMQ／EMQ 資產 SHA-256 與既有基準一致：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- [~] AMQ-2085 已建立正式頁面外殼，但選歌內部仍沿用既有 Catalog 表單／表格；尚未完整轉成原型的左側篩選、中央密集歌曲列、右側歌曲詳情及 OSK 模板式版面。不能宣稱選歌頁 UI 已完成。
- [~] AMQ-2086 11 個 role 有 runtime 套用目標；其餘 manifest roles 仍保留映射／保存能力，但明確報 unsupported，需依每頁實際 DOM 與可套用語意逐批接線。
- [!] AMQ-2087 完整正式頁面在此執行環境只能以 inline assets 的 Chromium `set_content` 測試；IndexedDB 在 opaque origin 被瀏覽器拒絕，因此曲庫狀態顯示 `DATA_SOURCE_READ_FAILED`／`storage-unavailable`。這不是正式 HTTP-origin 驗收，需在一般本機瀏覽器／HTTP origin 確認持久化與真實曲庫載入。
- [!] AMQ-2088 Candidate302／Candidate382 Stage 0 原始基準仍缺席；工作副本無 `.git`，未初始化、未覆蓋正式基準或曲庫。

## Batch199 下一批優先
1. 在不猜測基準的前提下，嘗試 HTTP-origin browser 驗收；若環境封鎖 localhost，保留錯誤證據後繼續其他工作。
2. 完成 Catalog loaded／loading／empty／failed 的視覺與互動驗收，測試真實曲目列表、封面 fallback、來源歸屬及右側詳情；不使用示意資料宣稱真實曲庫通過。
3. 驗證方向鍵、Enter、checkbox、點擊選取與右側詳情更新，避免重複事件並保持單一 selection state。
4. 測試 Mapping Studio role supported／unsupported、實際套用、reset、匯入／匯出與重新載入；只有 selector 與 CSS consumer 都存在時才標記 supported。
5. 驗證底部播放器收合／展開、捲動、窄螢幕與鍵盤焦點，不建立第二個 AudioService。
6. 完成後更新同一份工作狀態、主清單、handoff、提示詞與測試證據。


## Batch228：表單控制項色板舊規則替換（2026-10-29）
- [x] AMQ-2089 核對正式工作副本、Batch227 handoff／next prompt、`AGENTS.md`／開工指南；確認無 `.git`，不初始化。
- [x] AMQ-2090 盤點 shell 全域 `input,select` `!important` palette 與 Settings／Catalog／Quiz／Multiplayer／Free Player 的真實 consumer。
- [x] AMQ-2091 將全域控制項 palette 改為 `.app-page`／Free Player Dock 範圍的非 `!important` 規則，明確排除 checkbox、radio、range、file。
- [x] AMQ-2092 移除 quiz answer／all-answer fields 的重複 palette 覆寫與 answer input `!important`，保留單人答案欄位專屬尺寸／border／radius。
- [x] AMQ-2093 新增 quiz UI contract，防止舊全域 palette 與 quiz answer `!important` 回歸。
- [x] AMQ-2094 Chromium computed-style 覆蓋 Catalog、Free Player、Quiz、Multiplayer、Settings 表單；127/127 PASS，桌面／390px 手機無水平溢位、無 uncaught browser exception。
- [x] AMQ-2095 OSK import panel Chromium harness 12/12；Architecture Checker 1,165 PASS／0 FAIL；176 JS/CJS syntax checks、2 Python `py_compile` PASS。
- [x] AMQ-2096 AMQ／EMQ 靜態資產 SHA-256 與 Batch227 相同，未修改唯讀曲庫。
- [~] AMQ-2097 Node test files 80/81 PASS；`tests/tooling.test.cjs` 全檔受並行 Architecture Checker 子程序耗時限制，非 architecture 子集 11/11 PASS。不得宣稱完整 suite 81/81。
- [!] AMQ-2098 HTTP-origin IndexedDB、真實 `.osk`／live 曲庫／音訊與 Candidate302／Candidate382 Stage 0 仍未驗收；原始正式基準檔缺席且未覆蓋。
- [ ] AMQ-2099 Batch229：逐頁替換剩餘 settings file input／toggle／range／dropdown skin／notice/error 的 `!important` islands，先證明真實 consumer 與替代 owner。
- [ ] AMQ-2100 持續逐頁完成首頁、選歌、猜歌、結果、個人檔案、排行榜、學習中心、設定的實際 UI 與互動驗收；不可用底層測試代替產品 UI 結案。


## Batch229：表單／Skin 狀態 CSS islands 替換（2026-10-29）
- [x] AMQ-2101 盤點 shell 剩餘 `!important` islands 與真實 DOM consumer，確認 `[hidden]`、reduced-motion、visually-hidden 等規則具語義必要性而保留。
- [x] AMQ-2102 移除 Catalog row checkbox 的尺寸／padding `!important`，保持 15px compact selection target。
- [x] AMQ-2103 移除 Settings OSK checkbox 的尺寸、邊框、unchecked／checked 背景 `!important`，保留 skin image token 與 checked state。
- [x] AMQ-2104 移除 Free Player range track radius `!important`，維持自訂 dark track 與 thumb skin hook。
- [x] AMQ-2105 移除 Settings file input 背景 `!important`、dropdown skin image `!important`，以較具體 selector 管理；狀態提示改為 Settings scope。
- [x] AMQ-2106 移除 learning metrics card background `!important`，維持原有 gradient surface。
- [x] AMQ-2107 新增 `tests/ui-shell-css.contract.test.cjs`，驗證可移除的舊規則確實沒有回歸，必要的 hidden／reduced-motion 規則仍保留。
- [x] AMQ-2108 Chromium formal shell 133/133；OSK import browser 12/12；Architecture Checker 1,172/0；177 JS/CJS syntax、2 Python compile PASS。
- [x] AMQ-2109 AMQ／EMQ 資產 SHA-256 未變；測試與截圖證據在 `artifacts/batch229-regression/`。
- [~] AMQ-2110 Node test files 81/82 PASS；`tests/tooling.test.cjs` 全檔仍因並行 Architecture Checker 子程序耗時超出命令時間限制，非 architecture 子集 11/11 PASS。
- [!] AMQ-2111 HTTP-origin IndexedDB、真實 `.osk`／live 曲庫／音訊與 Candidate302／Candidate382 Stage 0 仍未驗收。
- [ ] AMQ-2112 Batch230：依逐頁 UI traceability 選定下一個高影響 UI 缺口，完成實作、桌面／390px 驗證及工作清單更新。


## Batch231：Catalog 作品封面 fallback 視覺與來源語義（2026-10-29）
- [x] AMQ-2121 開工前讀取 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、最新工作狀態、主清單、Batch230 handoff／next prompt、UI traceability 與 OSK role audit。
- [x] AMQ-2122 檢查工作副本 Git 狀態：沒有 `.git`，不初始化；Candidate302／Candidate382 Stage 0 原始檔缺席，不猜測或覆蓋；AMQ／EMQ 資產維持唯讀。
- [x] AMQ-2123 Catalog artwork fallback 加入由作品標題首字衍生的 mark，來源 AMQ／EMQ／MIX 以 `data-artwork-source` 與 ANIME／GAME／MIX label 明確區分。
- [x] AMQ-2124 CSS 以同一個語義結構呈現列表小封面與詳情大封面，加入 source-aware treatment、loading pulse 與 reduced-motion fallback；真圖仍優先，不安全 URL／缺資料／載入失敗不顯示假封面。
- [x] AMQ-2125 Catalog integration tests 驗證 source metadata、title-derived mark、GAME label、無 adapter fallback、圖片錯誤與 async lifecycle。
- [x] AMQ-2126 UI CSS contract 驗證 artwork fallback mark／source label／loading animation／reduced-motion 規則。
- [x] AMQ-2127 Chromium formal shell 139/139 PASS，包含桌面／390px mobile 與 reduced-motion computed styles。
- [x] AMQ-2128 OSK browser harness 12/12 PASS；Architecture Checker 1,172/0。
- [x] AMQ-2129 81/81 非-tooling Node test files 最終逐檔 PASS；tooling 非架構子集 11/11 PASS；181 JS/CJS syntax 與 2 Python compile PASS。
- [x] AMQ-2130 AMQ／EMQ asset SHA-256 與 Batch230 相同；回歸證據存於 `artifacts/batch231-regression/`。
- [x] AMQ-2131 更新 WORK_STATUS、AI start、README、traceability、handoff、next prompt、evidence、Manifest 與完整 ZIP。
- [!] AMQ-2132 HTTP-origin IndexedDB、真實 `.osk`／live artwork／音訊與 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- [x] AMQ-2133 Batch232：逐頁檢查首頁／結果頁視覺狀態與鍵盤／觸控互動缺口，完成可驗證 UI 實作（跨頁捲動重置）。

## Batch230：正式頁面導航觸控尺寸（2026-10-29）
- [x] AMQ-2113 檢查桌面／390px 手機正式頁面導航與返回首頁按鈕尺寸；確認目前 vertical padding 與 line-height 組合不足以保證 44px target。
- [x] AMQ-2114 `src/styles/ui-shell.css` 為 `.app-back-button` 與 `.app-shell-nav-links button` 明確設定 `min-height:44px`，保留既有導航樣式、焦點輪廓與頁面路由。
- [x] AMQ-2115 `tests/ui-shell-css.contract.test.cjs` 加入導航 touch target CSS contract。
- [x] AMQ-2116 `tests/app-shell.browser.test.py` 加入桌面／手機導航按鈕 computed-style assertions；formal shell 135/135 PASS。
- [x] AMQ-2117 81/81 非 tooling Node test files PASS；OSK browser 12/12；Architecture 1,172/0；177 JS/CJS syntax、2 Python compile PASS。
- [x] AMQ-2118 AMQ／EMQ 資產 SHA-256 未變；證據在 `artifacts/batch230-regression/`。
- [!] AMQ-2119 HTTP-origin IndexedDB、真實 `.osk`／live 曲庫／音訊與 Candidate302／Candidate382 Stage 0 仍未驗收。
- [ ] AMQ-2120 Batch231：對照各頁 UI traceability，選擇 artwork／empty-error／keyboard-touch 的高影響缺口並完成一批可驗證實作。


## Batch232：跨頁捲動重置（2026-10-29）
- [x] AMQ-2134 核對 Batch231 基準 ZIP SHA-256、MANIFEST、工作狀態與交接；不初始化 `.git`，不覆蓋正式基準。
- [x] AMQ-2135 跨頁 `navigate()` 更新頁面與目的頁焦點後重置 scroll 到頁首；保留 `options.scroll === false` 例外。
- [x] AMQ-2136 保留 Settings `data-settings-jump` 頁內快速跳轉，不套用跨頁頁首重置。
- [x] AMQ-2137 Chromium 390px route regression：從 Catalog scrollY=520 切到 Quiz 後 scrollY=0、標題可見。
- [x] AMQ-2138 更新 Batch232 工作狀態與交接紀錄；Batch232 測試證據保留於 `artifacts/batch232-regression/`。

## Batch233：首頁選單鍵盤狀態與結果頁 CTA 導航（2026-10-29）
- [x] AMQ-2139 核對 Batch232 正式交接、主清單、既有首頁／結果頁 UI 契約與 browser harness。
- [x] AMQ-2140 首頁主選單離開首頁時明確收合並同步 `aria-expanded`、標籤與 expanded class，避免暫態 UI 狀態跨頁殘留。
- [x] AMQ-2141 首頁主選單支援 Escape 關閉，並將鍵盤焦點返回主選單觸發按鈕。
- [x] AMQ-2142 Chromium formal shell 增加首頁 Escape、離頁收合、結果 CTA、Alt+Left 與 Settings 區塊跳轉回歸。
- [x] AMQ-2143 Chromium formal shell 150/150 PASS；結果 UI contract + CSS contract 7/7；OSK harness 12/12。
- [x] AMQ-2144 Architecture Checker 1,172 PASS／0 FAIL；177 個 JS/CJS 語法檢查 PASS；AMQ／EMQ 靜態資產 hash 未變。
- [x] AMQ-2145 新增 `docs/UI_TRACEABILITY.md`，明確記錄頁面導航／焦點／空狀態 CTA 契約。
- [x] AMQ-2146 更新工作狀態、交接、下一批提示詞、README／AI start、測試證據與 Manifest。
- [~] AMQ-2147 81 個非-tooling Node test files 本批全量重跑未完成；工作命令在 60 秒限制中斷。Focused tests 7/7 PASS；不得將未完成全量測試宣稱通過。
- [!] AMQ-2148 HTTP-origin IndexedDB、真實 `.osk`／live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 與實機 UI 仍未驗收。
- [ ] AMQ-2149 Batch234：驗證真實結果資料 owner 對 empty／completed／unsaved 狀態的呈現與持久化語義，並處理下一個有證據的跨頁 UI 缺口。

## Batch247：首頁與 Catalog 載入／重試狀態閉環（2026-10-29）
- [x] AMQ-24455 核對 Batch246 ZIP SHA-256 與 sidecar 一致，建立獨立 Batch247 工作副本；未初始化 `.git`、未覆蓋舊 ZIP。
- [x] AMQ-24456 閱讀開工規範、工作狀態、主清單、Batch246 handoff／next prompt、路線圖及 UI／visual-role traceability。
- [x] AMQ-24457 執行 `tools/audit-visual-role-coverage.cjs`；仍為 48 roles、35 wired、13 unsupported，未把靜態命中誤當逐角色 browser 驗收。
- [x] AMQ-24458 盤點 Catalog runtime load result 與 UI state precedence；找到未接受且無 error 的完成結果可能被 stale shared `loading` 狀態掩蓋。
- [x] AMQ-24459 `src/ui/catalog-browser.js` 對未接受且非 stale、無明確 error 的結果產生 `DATA_LOAD_NOT_ACCEPTED`，不把它當成空曲庫成功。
- [x] AMQ-24460 request-local `loadError` 優先於過期 shared `dataStatus=loading`，讓狀態標籤、錯誤提示、空狀態及重試按鈕一致顯示失敗。
- [x] AMQ-24461 `tests/catalog-browser.integration.test.cjs` 新增未接受載入結果 regression，驗證不會卡在 loading、錯誤碼可見且重試入口可用。
- [x] AMQ-24462 Catalog retry regression 驗證搜尋 query 在重新載入前後保留，且新 catalog 重新套用相同 query。
- [x] AMQ-24463 Catalog retry regression 驗證同一個 mount 的 reload click handler 只有一個，retry 不重複註冊 listener。
- [x] AMQ-24464 `tests/catalog-filter-layout.contract.test.cjs` 更新狀態優先順序、local error copy 與未接受結果 contract。
- [x] AMQ-24465 `src/styles/ui-shell.css` 將 Catalog reload／retry target 提升到 44px；修正較高 specificity 的 `#page-catalog #catalog-reload` 舊規則仍覆蓋 44px 的問題。
- [x] AMQ-24466 新增 `tests/batch247-home-catalog.browser.py`，以 Chromium 驗證正式頁面、桌面／390px Catalog layout、retry computed min-height、reduced-motion CSS 與無水平溢位。
- [x] AMQ-24467 重新執行 `tests/catalog-browser.integration.test.cjs`：PASS。
- [x] AMQ-24468 重新執行 `tests/catalog-browser.test.cjs`：PASS；包含 query/filter/sort/pagination controller contract。
- [x] AMQ-24469 重新執行 `tests/catalog-mode-switch.integration.test.cjs`：PASS；mode switch、stale load、retry failure/success 與 empty states 均有回歸。
- [x] AMQ-24470 Catalog layout／state CSS contract：13/13 PASS。
- [x] AMQ-24471 Batch247 Home/Catalog Chromium：22/22 PASS；390px 無頁面水平溢位，desktop/mobile retry target 至少 44px，reduced-motion override 存在。
- [x] AMQ-24472 Formal app-shell Chromium：150/150 PASS。
- [x] AMQ-24473 Quiz/Results Chromium：19/19 PASS；Canvas Chromium：15/15 PASS。
- [x] AMQ-24474 Mapping Studio／OSK Chromium harness：PASS，沿用 Batch246 apply/fallback/reset、44px 與 state-pair 回歸。
- [x] AMQ-24475 全量 Node `*.test.cjs` 90/90 files exit 0；逐檔 log 與 TSV 位於 `artifacts/batch247-regression/node-tests/`。長批次 shell 曾超時，缺項已分批逐檔補跑；不依賴被中斷的外層 runner 結果。
- [x] AMQ-24476 Architecture Checker：1,279 PASS／0 FAIL。
- [x] AMQ-24477 JS/CJS syntax：193/193 PASS；Python harness compile：12/12 PASS。
- [x] AMQ-24478 AMQ／EMQ 原始資料 hash 與已知基準一致；無修改原始資料。
- [ ] AMQ-24479 真實 HTTP-origin IndexedDB save/reload 仍受既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；未重試相同探測，需環境政策／可用 origin 改變後再驗收。
- [ ] AMQ-24480 真實 live catalog、artwork provider、音訊、Windows／實機及 Candidate302／Candidate382 Stage 0 未驗收；本批 Chromium 仍是 inline assets／fixture，不冒充真實資料來源驗收。
- [ ] AMQ-24481 逐一對 35 個已接線 visual roles 做 browser apply/fallback/reset；目前只保留代表性驗收，不將整體角色視為全部驗收。
- [ ] AMQ-24482 Batch248：核對 Quiz Arena／Results UI 的真實 round owner、audio error／timeout／answered 與保存語義，補齊有證據的 UI 缺口。

## Batch252：Skin fidelity 與真實 OSK 相容界線（2026-10-29）
- [x] AMQ-25201 核對 Batch251 ZIP／sidecar SHA-256，建立獨立工作副本，不初始化 Git、不覆蓋基準。
- [x] AMQ-25202 檢查可讀取的 `aristia hima.osk` SHA-256 與 ZIP CRC。
- [x] AMQ-25203 使用正式 `osk-importer.js` 解析真實 `.osk`，記錄 skin.ini name/author/version/sections 與圖片／音效數量。
- [x] AMQ-25204 稽核 AMQ 已知 mapping 缺件與 Mania reference resolution，報告只保留 metadata／計數，不複製第三方資產。
- [x] AMQ-25205 確認 `Version=latest` 只作原始 metadata，沒有推論 native stable version semantics。
- [x] AMQ-25206 新增 `tests/skin-compatibility-audit.contract.test.cjs`，保護 audit 報告與 native-fidelity false claims。
- [x] AMQ-25207 Skin／OSK／geometry／pixel focused suite 36/36 PASS。
- [x] AMQ-25208 全量 Node 92/92 files 最終逐檔 exit 0（audio-service 平行負載首次失敗、獨立重跑 PASS）；Architecture 1,293/0；JS/CJS 186 檔 syntax；Python 14/14；Chromium shell 150/150、cross-page 45/45、Home/Catalog 22/22、Backup/Restore 8/8、Skin Canvas 9/9。證據於 `artifacts/batch252-regression/`。
- [!] AMQ-25209 `aristia hima.osk` 的 98 個 Mania references 均未解析，該樣本對 Mania 素材不完整；沒有來源素材可判斷是封包缺件或 references mismatch。
- [!] AMQ-25210 HTTP-origin IndexedDB、live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0、native osu!stable fidelity 仍未驗收；35 wired roles 未逐一 browser closure，13 roles unsupported。
- [ ] AMQ-25211 Batch253：最終缺口盤點、狀態／證據對照與交付候選判定。


## Batch253：最終缺口稽核與交付候選判定（2026-10-29）
- [x] AMQ-25212 核對 Batch252 ZIP 實際 SHA-256、sidecar 與 ZIP CRC；確認實際 hash `514f7dd94063105617609fc89d5ad048ee4531c62900dfe2dfa7517c7ea9be3b`。
- [x] AMQ-25213 修正 Batch252 handoff 中與實際 ZIP 不一致的 hash；只修改 Batch253 工作副本，未更動既有交付 ZIP。
- [x] AMQ-25214 `tools/audit-visual-role-coverage.cjs` 新增 `--output-dir`，支援批次專屬輸出，避免稽核新批次時覆寫 Batch245 歷史證據。
- [x] AMQ-25215 `tests/visual-role-audit.test.cjs` 新增 output isolation regression，驗證 48／35／13 統計與 legacy report 不被改寫。
- [x] AMQ-25216 角色靜態稽核：48 total、35 wired、13 unsupported、35 CSS consumers、31 direct test evidence、33 with gaps；報告存於 `artifacts/batch253-regression/visual-role-audit/`。
- [x] AMQ-25217 全量 Node `*.test.cjs` 92/92 files 最終逐檔 exit 0；工具時間限制中斷的外層命令不算 PASS，續跑剩餘檔案後才確認完成。
- [x] AMQ-25218 Architecture Checker 1,293 PASS／0 FAIL；JS/CJS syntax 186/186；Python compile 14/14。
- [x] AMQ-25219 Chromium app-shell 150/150、cross-page 45/45、Home/Catalog 22/22、Backup/Restore 8/8、Skin Canvas 9/9。
- [x] AMQ-25220 確認 AMQ／EMQ raw data hashes 與基準一致，未修改原始資料。
- [x] AMQ-25221 更新工作狀態、主清單、roadmap、traceability、handoff、next prompt、AI start、README、測試證據、manifest 與完整 ZIP。
- [!] AMQ-25222 HTTP-origin IndexedDB、live audio/catalog/artwork、Windows／實機、Candidate baselines、逐角色 browser coverage、13 unsupported roles、native osu!stable fidelity 仍未驗收。
- [x] AMQ-25223 Batch254：建立 35 wired roles 的正式 DOM browser apply/fallback/reset coverage matrix；結果見 AMQ-25224 至 AMQ-25232。


## Batch254：正式 DOM 逐角色 Skin apply／fallback／reset（2026-10-29）
- [x] AMQ-25224 核對 Batch253 交付 ZIP SHA-256 `0b9fc8af5e36d24b27ce580185956830c3b8cf4c49158bf74a5f9f4a4c3c75ae`；獨立工作副本、無 Git repository、未初始化或覆蓋基準。
- [x] AMQ-25225 新增 `tests/batch254-skin-role-production.browser.py`，使用正式 `src/index.html`、正式腳本與 CSS 啟動 Chromium，逐一檢查 runtime role target。
- [x] AMQ-25226 35/35 production runtime role selectors 找到 DOM target；35/35 apply 成功、35/35 missing asset fail-closed 並回報 warning、35/35 reset 移除 token／active dataset 並撤銷已建立 object URLs。
- [x] AMQ-25227 新增 fixture matrix `tests/batch254-skin-role-matrix.browser.py` 與逐角色 JSON/log；明確標註 fixture evidence 不等於 production DOM evidence。
- [x] AMQ-25228 Chromium role matrix 105/105 assertions PASS（35 apply + 35 missing fallback + 35 reset），0 uncaught page errors；production DOM target count 35/35。初始 Home route 只有 4 個角色 target 可見，其餘在掛載的隱藏頁／狀態節點；尚未視為各 route visible-state 驗收。
- [x] AMQ-25229 全量 Node 92/92 `*.test.cjs` 檔案逐檔 exit 0；Architecture 1,293 PASS／0 FAIL；JS/CJS syntax 186 檔；Python compile 17/17。
- [x] AMQ-25230 正式 app-shell Chromium harness 通過；focused skin adapter／manifest／resolver／visual audit／compatibility audit Node tests 全部通過。
- [x] AMQ-25231 確認 AMQ／EMQ raw data hashes 未變；沒有修改原始資料或第三方 skin assets。
- [x] AMQ-25232 更新工作狀態、主清單、roadmap、traceability、handoff、next prompt、AI start、README、回歸證據、Manifest 與完整 ZIP。
- [!] AMQ-25233 13 unsupported roles、逐頁可見狀態／實際互動視覺驗收、HTTP-origin IndexedDB、live providers/audio、Windows／實機、Candidate baselines、native osu!stable compositor fidelity 仍未結案。
- [ ] AMQ-25234 Batch255：依語義追蹤 13 unsupported roles 的真實 DOM/render owner；只接線有正確 AMQ 語義的元件，並開始 route-aware visible-state browser coverage。


## Batch256：Catalog filter Skin role 接線與回歸（2026-10-29）
- [x] AMQ-25601 讀取專案規範、最新 handoff／status／checklist，確認工作副本無 `.git` 且不初始化 Git。
- [x] AMQ-25602 正式方向確認：新版獨立開發，Candidate302／Candidate382 不再是必要基準、待辦或阻塞。
- [x] AMQ-25603 追蹤 `buildCatalogWorkspace()` 的真實 DOM owner，確認 `.catalog-sidebar > .catalog-primary-controls` 是主要搜尋／篩選面板。
- [x] AMQ-25604 `src/skins/theme-adapter.js` 新增 `catalog.filter.background` 精確 runtime selector 與獨立 CSS token。
- [x] AMQ-25605 `src/styles/ui-shell.css` 新增 token consumer，限制背景只作用於主要篩選面板。
- [x] AMQ-25606 `tests/skin-theme-adapter.test.cjs` 新增 role apply、reset、Blob URL revoke、缺少 target 時 fail-closed regression。
- [x] AMQ-25607 更新 `tests/skin-contract-manifest.test.cjs` 與 `tests/visual-role-audit.test.cjs`，覆蓋 36 wired／12 unsupported。
- [x] AMQ-25608 靜態 visual-role audit：48 total、36 wired、12 unsupported、36 CSS consumers；報告位於 `artifacts/batch256-regression/visual-role-audit/`。
- [x] AMQ-25609 Focused Node tests 36/36 PASS；全量 92/92 Node test files exit 0，證據 `artifacts/batch256-regression/node-tests/`。
- [x] AMQ-25610 Architecture Checker 1,293 PASS／0 FAIL；JS/CJS syntax 186/186；Python compile 16/16。
- [x] AMQ-25611 Home/Catalog Chromium 22/22；production DOM role matrix 36/36 apply、36/36 missing fallback、36/36 reset，0 page errors。
- [x] AMQ-25612 確認 AMQ／EMQ raw data SHA-256 未變，未覆蓋 Batch255 ZIP，未初始化 Git。
- [x] AMQ-25613 更新 WORK_STATUS、roadmap、traceability、handoff、next prompt、README／AI start、Manifest 與完整交付 ZIP。
- [~] AMQ-25614 `catalog.action.random`：目前沒有 Catalog 專屬按鈕／事件 owner；播放器 random 不可代用。待定義產品行為後實作。
- [~] AMQ-25615 `settings.slider`：Settings 頁目前沒有 range input；播放器 progress／volume 不可錯標。待真正設定滑桿存在後再接線。
- [ ] AMQ-25616 36 wired roles 的 route-aware visible-state／互動矩陣仍需逐頁擴充；下一批 Batch257 先 Home、Catalog、Quiz、Results。
- [!] AMQ-25617 HTTP-origin IndexedDB、live providers/audio、Windows／實機需外部環境；本批不重試既有同一個 Chromium policy probe。


## Batch257：Home／Catalog／Quiz／Results route-aware Skin 可見狀態（2026-10-29）
- [x] AMQ-25701 讀取 AGENTS、AI_START、工作狀態、主清單、路線圖、UI traceability、Batch256 handoff 與 next prompt。
- [x] AMQ-25702 核對 Batch256 ZIP SHA-256 `5830ba0b35e6366bd5684657e0a699334550a1fa42d1eb89b8199e42f0cd1a39` 與 sidecar 一致；建立獨立副本；無 Git repository，未初始化。
- [x] AMQ-25703 確認 AMQ／EMQ raw data SHA-256 不變。
- [x] AMQ-25704 新增 `tests/batch257-route-skin-visible.browser.py`，以正式 app shell 與 Chromium 實際導航進入 Home、Catalog、Quiz、Results。
- [x] AMQ-25705 只將可見 DOM 目標列入 route coverage，避免把隱藏頁面節點當成可見角色。
- [x] AMQ-25706 Home 可見 4 roles；逐角色 apply／missing asset fallback／reset／token scope 全部 PASS。
- [x] AMQ-25707 Catalog 可見 15 roles；逐角色 apply／missing asset fallback／reset／token scope 全部 PASS。
- [x] AMQ-25708 Quiz 可見 9 roles；逐角色 apply／missing asset fallback／reset／token scope 全部 PASS。
- [x] AMQ-25709 Results 空狀態可見 4 roles；逐角色 apply／missing asset fallback／reset／token scope 全部 PASS；未把隱藏 results panel 當成可見。
- [x] AMQ-25710 Route-aware Chromium matrix 64/64 PASS；32/32 可見 role-route pairs 全部通過；0 page errors。
- [x] AMQ-25711 桌面／390px overflow、ARIA current、destination focus、reduced-motion 均有檢查；390px 四個 route 無水平溢位。
- [x] AMQ-25712 Batch251 cross-page Chromium 45/45、Batch247 Home/Catalog 22/22、Batch254 production roles 36/36 apply／fallback／reset 全部通過。
- [x] AMQ-25713 全量 Node `tests/*.test.cjs` 92/92 files 個別 exit 0；分組 logs 與統一 summary 保存在 `artifacts/batch257-regression/node-tests/`。
- [x] AMQ-25714 Architecture Checker 1,293 PASS／0 FAIL；JS/CJS syntax 186/186；Python AST compile 17/17。
- [x] AMQ-25715 更新 WORK_STATUS、MASTER_CHECKLIST、BATCH_ROADMAP、UI_TRACEABILITY、HANDOFF_BATCH257、NEXT_SESSION_PROMPT、AI_START、README、Manifest 與完整 ZIP。
- [!] AMQ-25716 HTTP-origin IndexedDB 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；本批未重試同一 probe。Live audio/catalog/artwork、Windows／實機仍未驗收。
- [~] AMQ-25717 `catalog.action.random` 缺少 Catalog 專屬功能 owner；`settings.slider` 缺少真正 Settings range input，維持 unsupported。
- [ ] AMQ-25718 Batch258：Settings／Learning Center／Multiplayer route-aware visible-state、error／empty／recovery 狀態驗收。


## Batch260 Home、Catalog 與 UI 文案政策
- [x] AMQ-260-001 凍結 Batch259 交付包作為唯讀基準
- [x] AMQ-260-002 確認正式首頁 owner 為 `src/ui/app-shell.js`
- [x] AMQ-260-003 移除首頁中心大圓盤 DOM
- [x] AMQ-260-004 移除首頁隱藏式主選單互動
- [x] AMQ-260-005 移除「不是 osu! 原生元件」式產品自我解說
- [x] AMQ-260-006 首頁六個主要入口直接可見
- [x] AMQ-260-007 首頁加入主視覺區域
- [x] AMQ-260-008 首頁最近學習採用誠實空狀態，不生成假資料
- [x] AMQ-260-009 移除 Home 裝飾性英文 eyebrow
- [x] AMQ-260-010 移除各頁重複的英文 eyebrow
- [x] AMQ-260-011 移除工程範圍 footer 產品文字
- [x] AMQ-260-012 移除首頁重複宣傳式說明句
- [x] AMQ-260-013 新增 `docs/UI_COPY_POLICY.md` 永久規範
- [x] AMQ-260-014 保留操作標籤與必要空／錯誤狀態訊息
- [x] AMQ-260-015 保留可存取性標籤與可程式化焦點標題
- [x] AMQ-260-016 更新舊 app-shell browser test，不再要求舊圓盤存在
- [x] AMQ-260-017 Home skin primary-action role 改接 `.home-feature-action`
- [x] AMQ-260-018 Home skin welcome-visual role 改接 `.home-feature`
- [x] AMQ-260-019 移除失效 Home pie CSS token consumer
- [x] AMQ-260-020 正式 Catalog 保留左篩選欄
- [x] AMQ-260-021 正式 Catalog 保留中央曲目列表
- [x] AMQ-260-022 正式 Catalog 保留右側選取詳情
- [x] AMQ-260-023 正式 Catalog 保留底部播放器 dock
- [x] AMQ-260-024 確認未將 prototype mock songs 接入正式資料源
- [x] AMQ-260-025 新增四尺寸 Home/Catalog 截圖測試
- [x] AMQ-260-026 驗證 1920×1080 無整頁垂直溢位
- [x] AMQ-260-027 驗證 1440×900 無整頁垂直溢位
- [x] AMQ-260-028 驗證 1024×768 無整頁垂直溢位
- [x] AMQ-260-029 驗證 390×844 無水平溢位
- [x] AMQ-260-030 驗證六個 Home 入口在四尺寸直接可見
- [x] AMQ-260-031 驗證舊圓盤與開發者說明不在正式 DOM
- [x] AMQ-260-032 驗證 Catalog 三欄 DOM owner
- [x] AMQ-260-033 驗證四尺寸無 uncaught browser exceptions
- [x] AMQ-260-034 更新 app-shell browser tests 到 144 項
- [x] AMQ-260-035 執行 skin-theme-adapter 測試 35/35
- [x] AMQ-260-036 執行 Catalog 單元測試 6/6
- [x] AMQ-260-037 執行 Catalog integration 測試
- [x] AMQ-260-038 執行 Architecture Checker 1,293/0
- [x] AMQ-260-039 更新工作狀態、交接與下一批提示
- [x] AMQ-260-040 更新 UI traceability
- [ ] AMQ-260-041 在允許 loopback HTTP 的環境重跑 IndexedDB 測試
- [ ] AMQ-260-042 以 HTTP-origin 驗證真實曲庫資料載入
- [ ] AMQ-260-043 以 HTTP-origin 驗證 ANN／其他合法封面來源載入
- [ ] AMQ-260-044 將真實近期學習紀錄接到 Home 視覺區
- [ ] AMQ-260-045 依真實封面資料調整 Home 視覺焦點
- [ ] AMQ-260-046 將 Catalog 1920×1080 截圖與 osu! 參考逐項對照
- [ ] AMQ-260-047 調整 Catalog 中央曲目列表密度與可視列數
- [ ] AMQ-260-048 驗證底部播放 Dock 不遮擋列表／篩選操作
- [ ] AMQ-260-049 對動態建立的元件加上 UI 文案政策檢查
- [ ] AMQ-260-050 將 AI 式註釋／裝飾性眉標掃描納入自動驗證
- [ ] AMQ-260-051 比較 Home 與 Catalog 的 1920×1080 參考／正式截圖差異
- [ ] AMQ-260-052 關閉重大構圖、密度、焦點差異後才標記視覺通過
- [ ] AMQ-260-053 保持 AMQ/EMQ 原始資料檔 hash 不變
- [ ] AMQ-260-054 交付前重建 manifest、ZIP 與 SHA-256 sidecar


## Batch261：Home 播放紀錄與 Catalog 密度（2026-10-29）
- [x] AMQ-261-001 `P0` 以 Batch260 為唯讀基準建立獨立 Batch261 工作副本
- [x] AMQ-261-002 `P0` Home 讀取正式 playback-history store，不使用 prototype mock songs
- [x] AMQ-261-003 `P0` 最近 6 筆播放紀錄使用 textContent 安全渲染
- [x] AMQ-261-004 `P0` 最新播放紀錄同步 Home feature title 與作品 metadata
- [x] AMQ-261-005 `P0` 無紀錄時顯示誠實空狀態
- [x] AMQ-261-006 `P0` history update 事件後重新渲染 Home
- [x] AMQ-261-007 `P0` 新增 history browser fixture 測試
- [x] AMQ-261-008 `P0` Catalog 桌面三欄寬度使用 viewport-aware 比例
- [x] AMQ-261-009 `P0` Catalog 曲目列高度與封面尺寸收斂
- [x] AMQ-261-010 `P0` 底部播放 Dock 固定並為 Catalog 留出內容空間
- [x] AMQ-261-011 `P1` 1180px 以下 Catalog 轉兩欄
- [x] AMQ-261-012 `P1` 760px 以下 Catalog 轉單欄並將 Dock 放回內容流
- [x] AMQ-261-013 `P0` Home/Catalog 四尺寸 browser contract 47/47
- [x] AMQ-261-051 `P0` App Shell Chromium regression 144/144
- [x] AMQ-261-014 `P0` Home history browser fixture 6/6
- [x] AMQ-261-015 `P0` App shell navigation regression 2/2
- [x] AMQ-261-016 `P0` Skin adapter regression 35/35
- [x] AMQ-261-017 `P0` Catalog unit regression 6/6
- [x] AMQ-261-018 `P0` Catalog integration regression PASS
- [x] AMQ-261-019 `P0` Architecture checker 1,293/0
- [x] AMQ-261-020 `P0` AMQ raw data hash 未變
- [x] AMQ-261-021 `P0` EMQ raw data hash 未變
- [x] AMQ-261-022 `P0` 更新 UI traceability 與 gap register
- [x] AMQ-261-023 `P0` 更新 handoff、work status、next prompt 與 AI start
- [ ] AMQ-261-024 `P0` playback history workId 對照正式作品索引
- [ ] AMQ-261-025 `P0` Home feature 接入真實 artwork provider URL
- [ ] AMQ-261-026 `P0` Home recent row 接入合法作品封面並驗證 fallback
- [ ] AMQ-261-027 `P0` 在允許 localhost 的環境完成 HTTP-origin IndexedDB 驗收
- [ ] AMQ-261-028 `P0` 以正常 Catalog data fixture 產生獨立截圖與差異表
- [ ] AMQ-261-029 `P0` 不將 opaque-origin IndexedDB error 畫面當作正常 Catalog 設計驗收
- [ ] AMQ-261-030 `P1` 清理無 DOM owner 的 Home pie 舊 CSS 規則
- [ ] AMQ-261-031 `P1` 擴大全產品動態元件 AI 式註釋掃描
- [ ] AMQ-261-032 `P0` 完成 Home 1920×1080 人工視覺比對與差異關閉
- [ ] AMQ-261-033 `P0` 完成 Catalog 1920×1080 人工視覺比對與差異關閉
- [ ] AMQ-261-034 `P1` 驗證 1440×900 Catalog 右側詳情與 Dock 空間
- [ ] AMQ-261-035 `P1` 驗證 1024×768 篩選／列表／詳情切換與捲動
- [ ] AMQ-261-036 `P1` 驗證 390×844 篩選、詳情與播放控制可用性
- [ ] AMQ-261-037 `P1` 確認 Home history store dispose 後沒有殘留 listener
- [ ] AMQ-261-038 `P1` 將 history 更新後 UI 狀態同步納入 integration test
- [ ] AMQ-261-039 `P1` 核對 Catalog footer／status 是否佔用過多垂直空間
- [ ] AMQ-261-040 `P1` 核對播放器展開狀態不遮蔽曲目操作
- [ ] AMQ-261-041 `P1` 核對 Skin Home roles 對新 feature/artwork 的作用目標
- [ ] AMQ-261-042 `P1` 檢查全域樣式中舊 Home pie selector 的實際剩餘引用
- [ ] AMQ-261-043 `P1` 將 normal data、empty data、provider failure 分別截圖
- [ ] AMQ-261-044 `P1` 確認最近播放紀錄過長標題不破壞 Home 網格
- [ ] AMQ-261-045 `P1` 確認作品／歌手 metadata 缺失時不顯示 undefined/null
- [ ] AMQ-261-046 `P1` 確認 Home history 只讀 playback history，不混入 quiz answer history
- [ ] AMQ-261-047 `P1` 確認 Home recent items 的鍵盤操作與焦點狀態
- [ ] AMQ-261-048 `P1` 確認 Home 來源 fallback 不被誤認為正式作品封面
- [ ] AMQ-261-049 `P0` 保持 UI_COPY_POLICY 對所有新元件生效
- [ ] AMQ-261-050 `P0` 只有 P0 視覺差距關閉後才標記 Home/Catalog 視覺通過


## Batch262：Home artwork 接線與舊 CSS 清理（2026-10-29）
- [x] AMQ-262-001 `P0` 從 Batch261 建立獨立 Batch262 工作副本，保護舊 ZIP
- [x] AMQ-262-002 `P0` 確認 source-runtime 對 workId 解析使用正式資料列
- [x] AMQ-262-003 `P0` AMQ workId 只使用資料內 ANNID，不以作品名稱猜 ID／URL
- [x] AMQ-262-004 `P0` EMQ workId 使用正式 works row 與明確 VNDB ID
- [x] AMQ-262-005 `P0` 未知來源／無效 workId 回傳 null，不合成 artworkRef
- [x] AMQ-262-006 `P0` App Shell 接入既有 artwork adapter 與 work resolver
- [x] AMQ-262-007 `P0` Home feature 使用安全 DOM image node，不將 provider 資料注入 HTML
- [x] AMQ-262-008 `P0` 最近 6 筆播放紀錄接入作品封面顯示
- [x] AMQ-262-009 `P0` image error 回復來源 fallback
- [x] AMQ-262-010 `P1` 記錄 artwork provider/status 以供測試追蹤
- [x] AMQ-262-011 `P1` Home recent click 改為事件委派，避免重繪累積 listener
- [x] AMQ-262-012 `P1` 無紀錄時 recent strip 改為內容高度
- [x] AMQ-262-013 `P1` 清理 ui-shell.css 中無 DOM owner 的 Home pie 舊 selectors
- [x] AMQ-262-014 `P1` 移除舊 Home copy/footer selector
- [x] AMQ-262-015 `P0` 更新 CSS contract 阻止舊 selector 回流
- [x] AMQ-262-016 `P0` source-runtime integration 驗證 AMQ workId→ANNID mapping
- [x] AMQ-262-017 `P0` source-runtime integration 驗證 EMQ workId→VNDB reference mapping
- [x] AMQ-262-018 `P0` Home artwork browser fixture 10/10
- [x] AMQ-262-019 `P0` Home/Catalog viewport browser checks 47/47
- [x] AMQ-262-020 `P0` App Shell browser regression 144/144
- [x] AMQ-262-021 `P0` Navigation contract 2/2
- [x] AMQ-262-022 `P0` Skin adapter tests 35/35
- [x] AMQ-262-023 `P0` Catalog unit 6/6 與 integration PASS
- [x] AMQ-262-024 `P0` UI shell CSS contract 8/8
- [x] AMQ-262-025 `P0` Architecture Checker 1,293/0
- [x] AMQ-262-026 `P0` 產生 Home/Catalog 四尺寸截圖
- [x] AMQ-262-027 `P0` 產生明確標示 fixture 的 Home artwork 截圖
- [ ] AMQ-262-028 `P0` 在允許 HTTP-origin 的環境驗證真實 IndexedDB 與 live artwork
- [ ] AMQ-262-029 `P0` 產生正常 Catalog data fixture 截圖，與 opaque-origin error 截圖分離
- [ ] AMQ-262-030 `P0` Home 空狀態主視覺空間與 osu! 參考差距關閉
- [ ] AMQ-262-031 `P0` Catalog 真實作品封面與列表密度人工視覺驗收
- [ ] AMQ-262-032 `P1` 全產品 UI_COPY_POLICY 動態元件掃描
- [ ] AMQ-262-033 `P1` Home 來源標記與 artwork fallback 對比／裁切驗收
- [ ] AMQ-262-034 `P1` 確認 Skin Home roles 仍對應新 feature/artwork targets
- [ ] AMQ-262-035 `P1` 驗證 Home store 與 artwork adapter dispose lifecycle
- [ ] AMQ-262-036 `P0` 全量 Node suite 重新分組執行並取得完整 aggregate summary
- [ ] AMQ-262-037 `P0` 重建 Manifest、ZIP 與 SHA-256 sidecar
- [ ] AMQ-262-038 `P0` 交付前核對 AMQ／EMQ 原始資料 SHA-256
- [ ] AMQ-262-039 `P0` 更新工作狀態、差距登記、traceability、handoff 與 next prompt
- [ ] AMQ-262-040 `P0` 最終視覺驗收未通過時，維持未通過標記

## 交付封裝原則（Batch268 起生效）
詳見 `docs/DELIVERY_PACKAGE_POLICY.md`。完整工作區與每批主要交付包分離；不得無條件攜帶所有歷史 PNG 與測試日誌。精簡前必須檢查引用與重建方式，保留最新驗收證據、歷史摘要索引、manifest 與 SHA-256；20–40 MB 是初始目標，不是犧牲完整性或可執行性的硬性配額。

## Batch268 交付證據規則與 UI 優先級
- UI 仍是主要工作；下一批先處理 Home/Catalog 真實作品視覺與正式資料布局，不得把檔案清理當作主要開發成果。
- 主要交付包只保留最新一輪 Home/Catalog 對照圖（四尺寸及獨立 error fixture），採 JPEG；舊照片與舊 raw logs 不再累積。
- 若有官方 osu! 參考圖，必須透過明確路徑 allowlist 保留；不可將 AMQ 原型截圖誤稱為 osu! 參考圖。
- 本批未完成 live artwork、正式 Catalog 資料或最終 osu! 視覺驗收，這些仍是未結案項目。
- Batch268：Catalog 曲目列選取／hover／鍵盤焦點視覺改善已實作；測試需執行 `node tests/batch268-catalog-row-visual.contract.test.cjs`。Home/Catalog 真實作品視覺仍是下一批 P0，UI 為主、封裝瘦身為輔。
- [進行中] Batch269 Catalog 對照官方 osu! Song Select 改善：固定列表可視區、加強作品縮圖與選取狀態；自動測試通過，正式資料與人工視覺 gate 未通過。
- [待處理] 在可用正式資料環境驗證 Catalog 25／50 首、真實封面 provider、右側詳情與播放 Dock。
- [待處理] 使用官方 osu! 參考圖完成 Home／Catalog 人工差距檢查；保留 P0 未結案狀態。

# Batch274 阻塞處理與測試恢復
- [x] AMQ-274-001 `P0` 讀取 Batch273 handoff、next prompt、主清單、工作狀態、traceability、design gap 與專案規範
- [x] AMQ-274-002 `P0` 確認工作副本獨立，未覆寫 Batch273 ZIP；確認本目錄非 Git repository，不初始化 Git
- [x] AMQ-274-003 `P0` 定位全量 Node 測試成本瓶頸，將 Quiz pool 統計迴圈改為 8,000／6,000 seeded draws 並保留分佈與 MIX 2:1 斷言
- [x] AMQ-274-004 `P0` 98 個 Node test files 分 20 組執行，35/35 組退出碼 0，303/303 subtests PASS；逐組 log 與 aggregate summary 已保存
- [x] AMQ-274-005 `P0` 重跑 Architecture checker 1,335/0、JS/CJS syntax 與 Python AST 32/32
- [x] AMQ-274-006 `P0` 重跑 Home/Catalog Browser 81/81、Multiplayer Lobby 32/32、Multiplayer Skin roles 5/5 apply/fallback/reset/scope
- [x] AMQ-274-007 `P1` 新增 Chromium native HTMLAudioElement + generated WAV browser check，5/5 PASS；明確限制在 media readiness/fallback/cleanup，不宣稱可聽外部播放
- [x] AMQ-274-008 `P0` 嘗試非 loopback HTTP-origin 作為既有 loopback blocker 的替代方案；仍被 ERR_BLOCKED_BY_ADMINISTRATOR 阻擋，記錄證據，不重複探測
- [x] AMQ-274-009 `P0` 建立 `docs/BATCH274_BLOCKER_RESOLUTION.md`，將已解決測試成本與外部環境／視覺 gate 分開記錄
- [ ] AMQ-274-010 `P0` 真實 HTTP-origin IndexedDB save/reload（Chromium policy 阻擋，需允許該 origin 的隔離瀏覽器環境）
- [ ] AMQ-274-011 `P0` Live ANN/VNDB artwork、正式 Home/Catalog 資料與成功率（外部 provider／正式 HTTP-origin 尚未驗收）
- [ ] AMQ-274-012 `P0` 外部 AMQ/EMQ provider 實際音源播放／可聽輸出（僅 native WAV readiness 已驗證）
- [ ] AMQ-274-013 `P0` Home/Catalog/Quiz/Multiplayer 人工 osu! Stable 視覺 gate（Home 主視覺構圖及真實 artwork 仍有明顯差距）
- [ ] AMQ-274-014 `P1` Windows／實機鍵盤、觸控與多瀏覽器驗收


## Batch282：Catalog Dock-aware layout 與交付包治理
- [x] 修正 feature route navigation 的 Grid row auto-placement，並保留 Home full-viewport。
- [x] Dock 使用 ResizeObserver 發布實際高度到 CSS custom property。
- [x] Dock dispose 清除 observer/listener 與 layout property。
- [x] Dock collapsed state 使用明確 data attribute 與緊湊高度。
- [x] Catalog list 高度依 viewport 與 Dock 實際高度計算。
- [x] Desktop/tablet pagination 與 fixed Dock 進行 bounding-box overlap regression。
- [x] Mobile Dock 回到 document flow，避免固定層遮擋內容。
- [x] 為 Catalog list、pagination、player dock 建立穩定 Skin component IDs。
- [x] 修正 Batch281 `app.home.logo` role 已在 runtime selector 但未同步兩份 manifest 的契約漂移；更新 audit 52/40/12 並修正回歸測試。
- [x] 四尺寸 browser fixture 118/118 PASS。
- [x] focused Node tests 38/38 PASS；全 Node test files 分組 318/318 subtests PASS；JS/CJS syntax 195/195。
- [x] Architecture checker 1,351/0；Python AST 35/35。
- [x] 精簡主交付包，移除重複歷史截圖/raw logs 與非 runtime source archive；保留最新證據與歷史摘要。
- [x] Compact ZIP 約 7.7 MB（較 Batch281 約 46 MB 減少約 83%），CRC PASS、Manifest 659/659 PASS、ZIP SHA-256 sidecar 已產生。
- [x] 精簡包解壓後重驗 focused Node 55/55、Architecture 1,351/0、Browser 118/118 PASS。
- [ ] 正式 HTTP-origin Catalog pagination／Dock live data 驗收。
- [ ] Home/Catalog 人工 osu! Stable 視覺 gate。
- [ ] 真實 artwork provider 與合法封面來源驗收。
- [ ] 全量 Node suite（本批未執行）。
- [ ] Windows／實機響應式驗收。


## Batch283：Catalog Stable 對照與 Dock 控制台（2026-10-30）
- [x] 先查看官方 `osu-song-selection.jpg`，產生 AMQ／Stable 並排圖及差距表。
- [x] 將來源 tabs 移至 Catalog 頂部，模式狀態改成折疊區，保留單一 mode owner。
- [x] Catalog 桌面視覺順序調整為左側篩選／中央作品舞台／右側歌曲佇列。
- [x] 選取作品背景只使用 artwork provider 成功載入的圖片，選取變更與過期請求安全處理。
- [x] 為選取背景、作品舞台、作品詳情新增穩定 Skin component IDs。
- [x] Dock 收合／展開兩態、實際高度與分頁遮擋完成四尺寸 browser matrix 148/148。
- [x] Focused Node 39/39；Architecture 1,358/0；JS/CJS 205/205；Python AST 37/37。
- [ ] 正式 Catalog／ANN/VNDB live artwork 與 provider success report。
- [ ] Catalog 人工 Stable visual gate。
- [ ] Windows／真機觸控、縮放、長標題驗收。
- [ ] 依原圖對照並完成 Multiplayer Lobby／Quiz UI 切片。

## Batch286 — Quiz gameplay reference layout / Skin roles
- [x] AMQ-286-001 `P0` 檢視使用者提供的 AMQ gameplay 原圖，記錄 SHA-256 與位置／功能映射。
- [x] AMQ-286-002 `P0` Quiz route 導覽改為頂部遊戲列，去除左側 rail/gutter 對遊戲畫面的擠壓。
- [x] AMQ-286-003 `P0` 以單一 DOM owner 建立 top HUD、左側回合摘要、中央答題舞台、右側狀態列與底部答案／操作區。
- [x] AMQ-286-004 `P0` 將真實答題紀錄放入右側狀態 rail；不偽造聊天室、排名、玩家分數、avatar 或歌曲封面。
- [x] AMQ-286-005 `P0` 保留既有 Quiz session、音訊、答案候選與回合控制 owner，無重複狀態管理。
- [x] AMQ-286-006 `P1` 手機版 Quiz HUD／舞台／答案／狀態 rail 重排，四尺寸無水平溢位。
- [x] AMQ-286-007 `P1` 新增 `quiz.game-hud`、`quiz.game-session-summary`、`quiz.game-stage`、`quiz.game-status-rail`、`quiz.answer.panel`、`quiz.answer.reveal` 六個 Skin roles。
- [x] AMQ-286-008 `P1` 同步 role manifest、runtime registry、visual-needs manifest、theme adapter selector 與 CSS token consumers。
- [x] AMQ-286-009 `P0` 更新 Batch264 舊測試 harness，改用 route owner，避免全產品腳本初始化拖死視覺檢查。
- [x] AMQ-286-010 `P0` 建立使用者原圖與正式 Quiz 截圖並排差距證據。
- [x] AMQ-286-011 `P0` Batch286 browser 55/55、Batch264 browser 38/38、Batch285 route 71/71、Batch283 Catalog 148/148。
- [x] AMQ-286-012 `P1` Focused Quiz/Skin tests 17/17，Architecture 1,358/0，JS/CJS 196/196，Python AST 39/39。
- [x] AMQ-286-013 `P1` Visual role audit 更新為 58 roles／46 runtime wired／12 unsupported。
- [ ] AMQ-286-014 `P0` 人工視覺驗收與中央舞台／右側 rail 的最後比例收斂。
- [ ] AMQ-286-015 `P0` 真實音訊與正式曲庫狀態下驗證 Quiz 題數、倒數、答題、揭曉與答題歷史。
- [ ] AMQ-286-016 `P1` 新增六個 Quiz Skin roles 的真實 OSK apply/fallback/reset browser evidence。
- [ ] AMQ-286-017 `P0` 全量 Node suite 分組執行並保存每組 exit code 與 aggregate summary。
- [ ] AMQ-286-018 `P1` Windows／真機鍵盤、觸控與縮放驗收。

# Batch289 Quiz 結果狀態與遊戲區比例（2026-10-30）
- [x] AMQ-289-001 `P0` 重新開啟使用者提供的 AMQ gameplay 原圖，依原圖定位左側摘要、中央舞台、右側狀態區與底部角色欄。
- [x] AMQ-289-002 `P0` 收斂桌面 Quiz board 寬度與三欄比例，取消中央區多餘左移，讓舞台／右側狀態欄集中在畫面中。
- [x] AMQ-289-003 `P0` 將 Quiz session phase 投影至正式 DOM `data-quiz-phase`，不新增第二份 session state。
- [x] AMQ-289-004 `P0` 將答對／答錯／跳過／未播放跳過／逾時／揭曉映射為舞台與答案表單的 `data-result-state`。
- [x] AMQ-289-005 `P0` 為倒數新增 running／paused／expired 的語義狀態與可視差異。
- [x] AMQ-289-006 `P0` 答案揭曉區增加依真實結果的 aria-label，無結果時保持隱藏。
- [x] AMQ-289-007 `P0` 調整 VNDB 角色欄桌面／手機角色圖比例與底部橫向呈現，不改變設定頁管理方式。
- [x] AMQ-289-008 `P0` 新增結果狀態、角色欄位置與遊戲區 AI 註釋掃描契約。
- [x] AMQ-289-009 `P0` 四尺寸 Quiz layout regression 55/55 PASS。
- [x] AMQ-289-010 `P0` Focused Node tests 31/31 PASS，涵蓋答案候選、Quiz session UI integration、Skin adapter 與本批新增契約。
- [ ] AMQ-289-011 `P0` 真實 VNDB 人物圖／完整答題流程 live E2E 與人工原圖視覺 gate。
- [ ] AMQ-289-012 `P0` Windows／手機實機、live audio 與正式 HTTP-origin persistence 驗收。
