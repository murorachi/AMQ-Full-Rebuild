# AMQ 新版重建交接：Batch122（多人音訊／伺服器期限倒數整合）

日期：2026-10-28。基礎為 Batch121 工作副本；無 `.git` metadata，未初始化／commit／push。

## 實作
- `src/app.js` 建立 app-scoped 單一 AudioService，與 playback coordinator 同時注入單人 QuizPanel／多人 MultiplayerPanel；cleanup 順序先釋放面板，再釋放共享服務。
- `src/engine/quiz-session.js` 新增 `disposeAudioService` 外部所有權控制；預設行為不變，只有 app 注入共享 AudioService 時才避免單一 session dispose 共享服務。已加 owner guard，播放權被撤銷的 QuizSession 忽略共享 AudioService 的多人播放事件，避免狀態污染。
- `src/ui/quiz-panel.js` 接受共享 AudioService，並將其所有權標記為 app scope。
- `src/ui/multiplayer-panel.js` 僅將 server `questionProjection` 的 candidates 傳給共享 AudioService；播放前檢查 roundId／questionId 一致及 HTTP(S) URL。新增播放／停止操作、AudioService 狀態呈現、全候選失敗診斷。
- playback lease revoke 時取消播放並禁用重新播放；離房、回合不再 active、dispose 都停止音訊並清理 QuizClock、AudioService subscription、lease。
- `server/multiplayer-host.cjs` 在含 currentRound 的非 unchanged snapshot 增加 `serverNow`。UI 使用 serverNow anchor + `deadlineAt` 餵給既有 QuizClock；倒數到零只停止本地播放、等待 server 結算，不由 client 判分。
- `src/index.html` 新增播放／停止按鈕與音訊狀態區，未做視覺大改。

## 修改檔案
- `src/app.js`
- `src/engine/quiz-session.js`
- `src/ui/quiz-panel.js`
- `src/ui/multiplayer-panel.js`
- `src/index.html`
- `server/multiplayer-host.cjs`
- `tests/multiplayer-panel.integration.test.cjs`
- `tests/quiz-session.test.cjs`
- `tests/multiplayer-host.integration.test.cjs`
- 文件：`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md`、`docs/HANDOFF_BATCH122.md`、`docs/ARCHITECTURE.md`、`docs/ACCEPTANCE.md`、`AI_START_HERE.md`、`README_FIRST.md`、`MANIFEST.sha256`。

## 驗證（修改後執行）
- 57/57 非-tooling `tests/*.test.cjs` scripts 逐檔 exit 0。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：893 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，無重複 ID、dangling references 或跨來源 ID collision。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，Catalog 55,660 records。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，5 runs，Catalog build 約 1,169.863 ms（僅本機 Node 觀測）。
- Source asset SHA-256、Manifest、ZIP CRC／檔案集合與封包 SHA-256 在最終打包步驟重驗。

## 尚未完成／限制
- 真實瀏覽器與多 client E2E 未執行；已知 Chromium 路徑 `ERR_BLOCKED_BY_ADMINISTRATOR`，本批不重試相同路徑。
- 倒數是顯示層估算；server deadline／assessment 仍是權威來源。
- 多人 SRS 自動寫入、durable offline queue、多裝置合併、WebSocket／多節點、真實音源供應商／CORS 驗收仍未完成。
- Candidate302／Candidate382 Stage 0 與 AMQ／EMQ source assets 保持唯讀。

## 下一步
Batch123：補足 stale projection、roundId mismatch、reconnect 後投影／lease／clock 重同步、server timeout／close 清理測試；然後評估 server assessment 到 source-aware SRS 寫入的安全冪等契約。

## 最終交付封包
- 檔名：`AMQ_Full_Rebuild_Batch122_Handoff_20261028.zip`
- Manifest：284 entries；ZIP 285 files（含 Manifest）；CRC PASS；ZIP missing／extra 0；Manifest missing／extra／hash mismatch 0。
- 未包含 `.git` metadata 或 `.pem`／`.key` 私鑰。ZIP 大小與 SHA-256 由本次最終交付回報提供，避免在封包內記錄自身雜湊造成自我參照。
