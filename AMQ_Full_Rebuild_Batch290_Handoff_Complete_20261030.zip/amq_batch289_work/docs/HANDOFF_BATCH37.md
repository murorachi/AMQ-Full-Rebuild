# Batch 37 交接：Normalized error projection 與 UI 整合回歸

## 結論
完成錯誤契約到 UI 的投影收尾。共用 `AMQCore.errors.normalize(error, defaults)` 可將不完整的錯誤輸入轉成穩定 AMQError；app、catalog browser、quiz panel 在顯示共享錯誤或處理捕獲例外前正規化。錯誤訊息仍透過 `textContent` 呈現，未將特殊字元解讀成 HTML，未做視覺重構。

## 修改檔案
- `src/core/errors.js`
- `src/app.js`
- `src/ui/catalog-browser.js`
- `src/ui/quiz-panel.js`
- `tests/core.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH37.md`
- `AI_START_HERE.md`
- `MANIFEST.sha256`

## 驗證
- `node tests/core.test.cjs`：77/77 PASS。
- `tests/*.test.cjs`：21/21 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：415 passed／0 failed。
- source audit PASS。
- mapper verification PASS：AMQ 38,821、EMQ 16,839、Catalog 55,660。
- catalog benchmark 5 iterations PASS。
- `src/`、`tests/`、`tools/` 全部 JS/CJS syntax PASS。
- 詳細日誌：`/mnt/data/amq_batch37_logs/`。

## 限制
- 真實瀏覽器 UI／音訊 E2E 仍 BLOCKED，已知頁面導覽政策回報 `ERR_BLOCKED_BY_ADMINISTRATOR`；沒有將 Node/fake DOM 測試當成瀏覽器驗收。
- 未證明目前來源資料是 Candidate302 配套版本；音訊可播放性未驗證。
- 工作副本沒有 `.git` metadata，沒有初始化 Git 或執行 commit/push。

## 下一批 Batch 38
核對 QuizEngine／QuizSession／QuizClock／AudioService／QuizPanel 狀態責任及生命週期，特別是開始、暫停、揭曉、跳過／下一題、結束，以及音訊實際進入 `playing` 後才開始計時的規則。補跨模組測試並記錄證據。UI 大重構仍排在核心、資料／持久化及必要功能回歸之後。
