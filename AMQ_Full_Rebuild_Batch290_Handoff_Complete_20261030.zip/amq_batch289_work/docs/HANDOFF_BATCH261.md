# Batch261 交接：Home 播放紀錄接線與 Catalog 版面收斂

## 基準與保護
- 唯讀基準：`AMQ_Full_Rebuild_Batch260_Home_Catalog_UI_Copy_20261029.zip`，Batch260 原始 ZIP 未修改。
- 工作副本沒有 `.git`，沒有初始化 Git。
- AMQ／EMQ 原始資料 hash 與 Batch260 記錄一致，均未改動。
- `docs/UI_COPY_POLICY.md` 繼續作為產品文案永久規範；不在產品 UI 添加設計自解說、裝飾 eyebrow、工程註釋或無功能宣傳文字。

## 本批實作
- Home 主視覺從靜態 AMQ 品牌字樣改為由播放紀錄資料驅動的作品／歌曲標題區。
- Home 建立 `playbackHistoryStore` 的單一讀取來源，顯示最近 6 筆實際播放紀錄；最新紀錄同步到主視覺；無紀錄時只顯示誠實空狀態，不虛構歌曲。
- Home history store 訂閱更新事件；以 DOM `textContent` 渲染標題、作品、歌手，沒有把資料當 HTML 注入。
- Catalog 版面在桌面尺寸收斂為篩選／列表／詳情三欄，減少列表列高與封面尺寸，底部播放 Dock 固定並為內容保留空間；平板改為兩欄、手機改為單欄且 Dock 回到內容流。
- 新增 `tests/batch261-home-catalog.browser.py` 與 `tests/batch261-home-history.browser.py`。

## 實際驗證
- Home/Catalog 四尺寸瀏覽器契約：47/47 PASS
- 正式 App Shell Chromium：144/144 PASS（1920×1080、1440×900、1024×768、390×844）。
- Home history fixture：6/6 PASS，確認最近紀錄資料來源、最新紀錄主視覺、舊紀錄列與空狀態切換；fixture 是測試資料，不是 live provider 驗收。
- `app-shell-navigation.contract.test.cjs`: 2/2 PASS。
- `skin-theme-adapter.test.cjs`: 20/20 PASS。
- `catalog-browser.test.cjs`: 6/6 PASS。
- `catalog-browser.integration.test.cjs`: PASS。
- `tools/check-architecture.cjs`: 1,293 PASS／0 FAIL。
- `node --check src/ui/app-shell.js`: PASS；Python AST compile：PASS。
- 原始資料 SHA-256：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 尚未通過／阻塞
- 本地瀏覽器截圖以 opaque origin 執行時，IndexedDB 仍回報不可用；先前 Chromium loopback HTTP 導航受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。本批未宣稱真實 HTTP-origin、持久化或 live 曲庫已通過，也未反覆重試相同環境探測。
- Home 目前使用有來源區別的作品識別 fallback，不等於已顯示真實作品封面。播放紀錄 schema 不含封面 URL／ANNID；下一步需透過明確 workId 對照與既有合法 artwork provider 接線，不可從歌曲標題猜 URL。
- Home/Catalog 截圖仍有明顯空間與資料狀態差距，未達「一眼像 osu!」視覺結案；Catalog 的錯誤狀態截圖不應當作正常載入視覺。
- 全量 Node suite、本機 HTTP-origin IndexedDB、live artwork/audio、Windows／實機仍未驗收。

## Batch262 優先工作
1. 在不重試已知被政策阻擋的 probe 前提下，確認是否有允許 localhost 的既有瀏覽器／測試執行方式；若沒有，保留阻塞記錄並完成其餘工作。
2. 將 playback history 的 `workId` 與正式資料索引做明確對照，接入既有 ANN/AniList/VNDB artwork adapter；缺少映射或 provider 失敗時維持 fallback，不新增假作品。
3. 用可控的資料 fixture 驗證 Catalog 正常載入視覺與封面；將 fixture 截圖與 opaque-origin error 截圖分開標示。
4. 清理已無 DOM owner 的 Home pie CSS，確認 Skin role 對新 Home feature/artwork 的作用範圍。
5. 繼續縮小首頁與 osu! Client Interface 參考之間的 P0 視覺差距，保持 UI_COPY_POLICY。
6. 更新本清單、WORK_STATUS、UI_TRACEABILITY、DESIGN_GAP_REGISTER、AI_START_HERE、Manifest 與交付包。
