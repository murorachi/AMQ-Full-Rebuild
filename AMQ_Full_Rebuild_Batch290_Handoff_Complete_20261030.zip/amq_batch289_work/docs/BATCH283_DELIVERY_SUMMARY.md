# Batch283 Delivery Summary

## Basis and package
- Starting workspace: extracted compact Batch282 package, `AMQ_Full_Rebuild_Batch282_Catalog_Dock_UI_Compact_20261030.zip` (previous delivered SHA-256 documented in prior handoff). This is an extracted independent working copy; no Git repository exists in the package, so no Git history was invented.
- New delivery: `AMQ_Full_Rebuild_Batch283_Catalog_Stable_Comparison_20261030.zip`.
- Primary UI work: Catalog stable-reference composition, top source-mode strip, provider-backed selected-artwork background, selected-work stage, right-side song queue, Dock collapsed/expanded geometry and Skin component IDs.

## Tests
- Browser: `python tests/batch283-catalog-stable.browser.py` — 148/148 PASS at 1920×1080, 1440×900, 1024×768, 390×844.
- Focused Node: `node --test tests/batch283-catalog-stable-layout.contract.test.cjs tests/catalog-filter-layout.contract.test.cjs tests/catalog-browser.integration.test.cjs tests/skin-theme-adapter.test.cjs tests/free-player-dock.test.cjs` — 39/39 PASS.
- CSS/Home regression: `node --test tests/ui-shell-css.contract.test.cjs tests/batch280-home-chrome.contract.test.cjs tests/batch281-home-note-question.contract.test.cjs` — 15/15 PASS.
- Architecture Checker — 1,358 PASS / 0 FAIL.
- JS/CJS syntax — 205/205 PASS. Python AST — 37/37 PASS.
- Node suite was executed in ten bounded groups across all 101 `*.test.cjs` files: 319/319 subtests PASS. The first orchestration hit the tool time window after group 7; groups 8–10 were run separately and all ten groups exited 0.

## Visual evidence
- `artifacts/batch283-catalog-stable/catalog-vs-osu-stable-1920x1080.jpg` is an explicit side-by-side with `artifacts/osu-reference/osu-song-selection.jpg`.
- `docs/OSU_CATALOG_VISUAL_GAP_BATCH283.md` lists differences per region.
- All AMQ Catalog screenshot rows/artwork are marked fixture; no live catalog/artwork success is claimed.

## Package trim
- Removed `artifacts/batch282-home-catalog/` because Batch283 replaces its screenshot evidence; preserved five Stable references, latest Batch283 screenshots, required historical audit JSON and archive index.
- Removed generated Python `__pycache__`/`.pyc` files.
- Kept `references/AMQ-Scripts-master.zip` because it is a user-supplied research input; did not package the 28 MB osu! source ZIP because it is neither runtime nor test dependency. Its source hash/context remains in research metadata.
- Historical test logs were not added; this summary records commands/results. The older Batch282 ZIP was not overwritten.

## Not verified
- Live HTTP-origin IndexedDB, real AMQ/EMQ data, live ANN/VNDB artwork, external audible playback, Windows/real-device interaction and human osu! Stable visual gate remain unverified.
