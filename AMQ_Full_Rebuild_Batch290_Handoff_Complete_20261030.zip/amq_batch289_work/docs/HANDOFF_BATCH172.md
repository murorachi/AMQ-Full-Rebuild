# Batch172 交接：AudioService loading 通知中的重入取消

## 1. 工作副本與基準
- 本次工作副本：`/mnt/data/amq_batch153_work`（由使用者提供的 Batch171 ZIP 解壓）。
- 工作副本沒有 `.git` metadata；未初始化 Git，無 branch／commit／diff 可報告。
- Candidate302 是既有正式維護基準，Candidate382 Stage 0 是 CSS 比較基準。兩份原始檔不在本副本；保留既有基準指定，不宣稱已 hash 比對或做相容驗收。
- `src/data/assets/data.js` 與 `src/data/assets/emq-data.js` 未修改；未覆蓋基準或曲庫資產。
- Node `v22.16.0`；71 個 `tests/*.test.cjs`。

## 2. 實際重現與修正
### 缺陷
`src/audio/audio-service.js` 的 `attemptCandidate()` 在確認 request 有效後，先同步 `publish({status: "loading"})`，再建立媒體物件。`publish()` 會同步呼叫訂閱者；若訂閱者在收到 loading 時呼叫 `cancel()`／`stop()`／`dispose()`，request 會立即終止，但舊程式仍繼續呼叫 `mediaFactory()`、接線事件並載入媒體。這會在請求已取消後取得並遺留媒體資源。

### 修正
- 在 loading 發布返回後立即重新檢查 `active === request` 與 `request.terminal`。
- 若訂閱者在通知期間已取消／終止請求，立即返回，不建立媒體、不註冊事件、不啟動 timer 或播放。
- 保留 AudioService 單一播放 owner、原有 fallback 順序與狀態模型；沒有新增平行播放狀態機。

## 3. 回歸測試
- `tests/audio-service.test.cjs` 新增重入取消案例：AudioService 訂閱者在第一個 `loading` 通知中同步呼叫 `cancel()`。
- 修正前測試失敗：實際 `mediaFactory` 仍被呼叫一次（預期 0），證明測試可重現缺陷。
- 修正後測試通過：結果為 `cancelled`、媒體建立數為 0、最終狀態為 `cancelled`。
- AudioService 測試檔共 19 個場景全部 PASS。

## 4. 本次驗證
- 71 個 Node `*.test.cjs` 檔案逐檔獨立執行，分 9 組：9/9 組 exit 0，0 個失敗檔案。日誌 `artifacts/batch172-regression/group-01.log` 至 `group-09.log`；摘要 `summary.json`。
- `node tests/audio-service.test.cjs`：19 個場景 PASS。
- `node tools/check-architecture.cjs`：1,051 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS，exit 0。Python 啟動時另有與測試無關的 `artifact_tool` spreadsheet warmup traceback stderr；測試自身明確輸出 12/12 且 exit 0，已完整保留於 log。
- `src/`、`tests/`、`tools/`、`server/` 共 160 個 JS/CJS 檔案 `node --check` PASS。
- `artifacts/batch172-regression/` 保存分組測試、架構、OSK harness、語法日誌與摘要。

## 5. 尚未驗收／阻塞
- 真實瀏覽器音訊播放、片段起點、跨域來源及實際可聽性。
- ANN API／CORS／圖片、真實 `.osk` 相容性、HTTP-origin IndexedDB save/reload/clear、實際 viewport／鍵盤流程。
- Candidate302／Candidate382 Stage 0 原始檔不在工作副本，不能完成原始檔 hash／相容比對。
- 本批只修復有 runtime failure injection 證據的 reentrant cancellation 缺陷；未發現證據支持重寫 QuizSession 或增加第二套狀態機。答題結果 persistence 的既有 failure-path 測試仍通過，本批沒有改動四級熟悉度規則。

## 6. 下一批 Batch173
1. 以可重現測試檢查 AudioService 的 `pause()`／`resume()`、timeout 與晚到 `play()` Promise rejection 交錯，避免使用者已取消或暫停後舊 rejection 觸發 fallback。
2. 檢查 QuizSession 的 mode switch／playback coordinator revoke 後，遲到的 AudioService subscription 是否可能覆蓋新狀態；只在找到可重現缺口時修正。
3. 持續補結果持久化 failure matrix，尤其 timeout、skip、submit、auto-next 與 round end 的結果一致性。
4. 不修改熟悉度規則：錯／超時 1；答對 0–10 秒 4、>10–15 秒 3、>15 秒 2；`all` 只依作品標題。
5. 更新同一份工作清單與交接文件，重新執行受影響測試、全量 Node 回歸、architecture、OSK harness 與語法檢查。
