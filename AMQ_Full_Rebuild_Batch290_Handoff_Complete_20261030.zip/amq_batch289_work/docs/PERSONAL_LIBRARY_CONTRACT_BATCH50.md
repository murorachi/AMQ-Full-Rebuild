# Batch 50：個人清單與看番狀態契約（靜態參考）

日期：2026-10-27

## 參考來源與限制

- 使用者上傳檔案：`/mnt/data/AMQ382(2).html`（工作包外的唯讀參考，不複製或修改）。
- SHA-256：`65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`；1,611,096 bytes。
- HTML `data-amq-candidate="381"`，title 明確標示 Candidate381。此檔可以提供靜態實作契約，但**不是 Candidate382 Stage 0，也不能證明 Candidate302 相容**。
- 靜態線索不等於瀏覽器驗收；既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試。

## 已觀察到的資料契約

### 自訂作品清單

- Storage key：`aniCustomPracticeListsV1`（參考檔約第 3484、3502–3515 行）。
- Recovery key：`aniCustomPracticeListsRecoveryV825`，衝突時加時間戳後綴（約第 3484–3507 行）。
- Payload 可接受 `{ version: 1, lists: [...] }`，讀取相容層也接受舊陣列格式（約第 1027–1035、3499–3511 行）。
- 每列至少包含 `animeIds: []`；正規化欄位為 `id`、`name`、`animeIds`、`createdAt`、`updatedAt`。清單 ID 轉字串，成員 ID 轉字串並去重；名稱最多 80 字元。舊資料即使有重複名稱仍保留讀取，不因名稱重複就隔離整份清單；新版建立／改名操作會拒絕新增重複名稱。
- 建立清單會去除首尾空白、合併連續空白，拒絕空名稱及不分大小寫的重複名稱；ID 形式為 `cpl-<時間>-<隨機尾碼>`（約第 3557、3561 行）。
- 重新命名拒絕空名稱／重複名稱並更新 `updatedAt`（約第 3643 行）。
- 加入／移除成員以作品 ID 字串去重；重複加入不產生重複成員（約第 3525、3562 行）。
- 刪除清單只移除清單本身，不刪作品或學習資料；同時清理猜歌設定內指向該清單的 ID（約第 3644 行）。
- 讀取錯誤與空清單需分開呈現；無效資料會先隔離，隔離失敗時阻止覆寫未知資料（約第 3502–3508 行）。

### 看番狀態

- Storage key：`aniAnimeWatch_v1`（約第 671、678 行）。
- 以作品 ID 字串作 key。已觀察的狀態為 `current`、`completed`、`paused`、`dropped`、`planning`、`repeating`；`none` 代表移除該筆狀態（約第 677–678、881 行）。
- 寫入值為 `{ status, source, updatedAt }`；手動變更預設 `source: "manual"`，外部匯入可使用來源標記（約第 678、824 行）。
- 參考程式使用簡單 `loadObj`／`saveObj`，沒有證據顯示它對看番狀態提供與自訂清單相同的 recovery 保證。新版 store 增加隔離與寫入失敗保護屬於安全強化，不應描述為逐位元相同的舊版實作。

### 收藏

- `aniFavorites_v1` 被讀取及納入備份／還原資料（約第 404、3282、3340 行），但在本次可讀檔案中沒有找到收藏新增／移除的實際行為 handler，亦未能證明 ID 是作品還是歌曲。
- 因身份範圍不明，Batch 50 **不實作收藏寫入**，避免把未知 ID 當成作品或歌曲並造成資料錯誤。此項需更完整的靜態線索或明確產品決策。

## Batch 50 實作範圍

新增 `src/persistence/personal-library-store.js`，提供可注入 storage 的清單／看番狀態 API：

- `refresh()`、`getListsResult()`、`getLists()`。
- `createList()`、`renameList()`、`deleteList()`、`setMembership()`、`hasMembership()`。
- `getWatchStatus()`、`getWatchEntry()`、`getWatchSnapshot()`、`setWatchStatus()`。
- 讀取／寫入錯誤狀態、損壞資料隔離、外部 `storage` event 更新、訂閱與 `dispose()`。
- 寫入成功後才發布新快照；失敗不會讓記憶體狀態假裝已保存。

目前此批只完成持久化模組及其自動化契約；新版 UI 尚未連接清單 CRUD／看番狀態操作，因此不能將整個產品功能標記完成。鍵盤靜態證據已能確認舊版 Song Select 路由只在非輸入／按鈕焦點時處理方向鍵與 Enter：方向鍵移動目前歌曲列，Enter 呼叫 canonical choose-song owner，方向下可觸發 tracklist load-more（約第 8184 行）。新版曲庫 UI 尚未提供相同歌曲列／播放 owner，故鍵盤整合保留待辦。


## Batch 52 更新：來源明確作品身份與出題池整合

- 新版清單新增 `workRefs: [{ source: "AMQ" | "EMQ", id: string }]`；清單身份使用來源 + 字串化作品 ID。AMQ:104 與 EMQ:104 是兩個不同成員。
- 舊 `animeIds` 保留原值、可讀可列出，但它沒有來源資訊，因此不會自動對應 AMQ 或 EMQ，也不會被猜歌出題池套用。UI 會指出舊成員尚未標記來源；使用者需在曲庫中重新加入來源明確作品。
- 新增 `setWorkMembership`、`hasWorkMembership`、`getWorkRefs`。舊 `setMembership`／`hasMembership` 仍維持舊資料語義，供相容讀取使用；新版 UI 只使用 source-aware API。
- 看番狀態新增 source-aware API `setWorkWatchStatus`／`getWorkWatchStatus`，使用 `@work:[source,id]` 格式的 key；既有 source-less watch entries 不會被猜測轉成來源明確項目，舊 API 仍可讀取舊 key。
- `QuizPanel` 以目前 `customListId` 過濾 quiz candidates，過濾依歌曲 record 的 `source + animeId` 與 `workRefs` 比對。MIX 保留每首歌自己的 AMQ／EMQ source。清單成員更新會使 session 重新計算 eligible pool；來源 ID 撞號不會跨來源匹配。
- `app.js` 在同一應用生命週期建立並共享個人清單與猜歌設定 store，避免曲庫 UI 和猜歌 UI 各自持有無法互相通知的記憶體快照；dispose 後清空引用，允許再次 mount 建立新 store。
- Node VM 整合測試覆蓋 AMQ／EMQ 相同作品 ID、清單成員動態更新、MIX pool 過濾及舊 source-less 成員不被猜測套用。這些不是瀏覽器 E2E 驗收。

- Batch 52 額外補上 UI 對 source-less legacy watch status 的提示：當目前來源沒有明確狀態、但裸 ID 舊狀態存在時，UI 只提示未解析，不把舊狀態套用到 AMQ／EMQ。個人清單 UI 同時呈現看番狀態 store 的 read/write blocked 與 recovery 狀態。
