# osu!stable Wiki → AMQ UI 逐頁追溯矩陣（Batch206）

日期：2026-10-29。這是元件語義與驗收邊界，不代表 AMQ 要逐像素複製 osu!stable，也不代表所有頁面已完成使用者驗收。

## 第一手規格

- Client / Interface: https://osu.ppy.sh/wiki/en/Client/Interface
- Skinning / Interface: https://osu.ppy.sh/wiki/en/Skinning/Interface
- Skinning / skin.ini: https://osu.ppy.sh/wiki/en/Skinning/skin.ini
- Client / Options: https://osu.ppy.sh/wiki/en/Client/Options

Wiki 說明 stable 的元件用途與行為，但不定義本專案 DOM、AMQ 題目語義或學習演算法。不得因外觀相似就把自訂區塊標成 stable 原生元件。

## 逐頁矩陣

| 頁面 | stable 參照行為／素材 | AMQ 正式落點 | extension slot／取捨 | 本批狀態 |
|---|---|---|---|---|
| 首頁 | `menu-background.jpg` 可對應主選單背景；stable 主選單本身不是 AMQ 的四入口圓形選單 | `#page-home`、`#home-pie`、`#home-pie-core`、四個 `[data-go-page]` 入口 | 圓形選單是 **AMQ adaptation**，沒有假稱存在專用 stable pie 素材；首頁只放選歌、猜歌、學習中心、設定 | 已在 UI 文字明示自訂語義；瀏覽器測試增加標籤檢查 |
| 選歌 | 搜尋、分組／排序、選取狀態與 beatmap carousel；`menu-button-background.png` 只在相符歌曲列語境，`selection-bar.png` 代表選取狀態，`songselect-bottom.png` 是選曲底框 | `#catalog-browser`、`.catalog-workspace`、`#catalog-query`、`#catalog-rows`、`#catalog-selection-details`、`#free-player-dock` | AMQ 作品封面、歌手／作品 metadata、來源／播放控制為 AMQ 資料；不虛構 star rating 或 osu! beatmap difficulty | 現有三欄 DOM 保留；本批未改查詢／排序邏輯，鍵盤／篩選清空選取仍需互動驗收 |
| 猜歌 | stable 的排名／成績圖片只代表 osu! 成績語義，不能直接等同 AMQ 正確／錯誤 | `#quiz-panel`、`#multiplayer-panel`，單人面板優先 | 答案輸入、音訊、揭曉、回合歷史與 SRS 是 AMQ extension slots；不把 `ranking-*.png` 當答題正誤圖 | 保留既有答題引擎與 DOM；需真實音訊與完整回合視覺驗收 |
| 學習中心 | stable 沒有與作品熟悉度、遺忘預測、FSRS 複習相同的原生元件 | `#statistics-dashboard`、七個既有指標、歷史／SRS 區塊 | 全部學習分析均明確為 AMQ extension；空狀態不得合成數據 | 保留既有資料 owner；需要真實持久化資料下的瀏覽器驗收 |
| 設定 | `skin.ini` 版本／色彩鍵有特定語義；stable Options 不能視為 AMQ 所有設定的同義詞 | `#page-settings`、`#workspace-preferences-panel`、`#skin-import-panel`、備份／更新／帳號面板 | AMQ 快捷鍵、資料備份、私人伺服器、學習選項與 OSK Mapping Studio 均為 extension slots；不把 `ComboN` 泛化成全站色票 | 保留明確 runtime-supported／unsupported 狀態；真實 `.osk` 與 HTTP-origin reload 未驗收 |

## Batch206 實作

- 首頁 eyebrow 改為 `AMQ ADAPTATION · osu!stable-inspired`。
- 首頁註記明確說明圓形選單是 AMQ 自訂導覽，不是 osu!stable 原生元件；不新增第二份曲庫／學習狀態。
- 導覽的 `aria-current` 只存在於目前頁面按鈕，移除非作用中按鈕上的字串 `false`，避免輔助技術把無效值當作狀態。
- `tests/app-shell.browser.test.py` 新增首頁 adaptation 與導覽狀態回歸檢查。

## 驗收邊界

- 本批會執行 formal shell Chromium test、focused skin contract tests、architecture check 與語法檢查；結果以工作狀態紀錄為準。
- inline `set_content` 使用 opaque origin，IndexedDB 不能因此視為通過或失敗。真實 `.osk`、HTTP-origin IndexedDB 重載、正式曲庫／封面／音訊、完整使用者桌面／手機驗收及 Candidate302／Candidate382 Stage 0 相容性仍未驗收。

## Batch207 補充：猜歌狀態與 Catalog selection 的互動語義

| AMQ 元件／狀態 | stable 對照 | AMQ 行為與取捨 | 驗證狀態 |
|---|---|---|---|
| Catalog row selection／ArrowUp／ArrowDown／Enter | stable 選曲的選取列與鍵盤導覽概念；AMQ 的作品身份、答案欄位與播放行為不是 stable 元件契約 | 點擊與方向鍵共用 `selectedRecordKey`；Enter 確認目前選取並更新作品詳情／個人清單選取，不直接播放音訊。篩選使選取記錄離開結果集時清空詳情與依賴選取狀態 | `tests/catalog-browser.integration.test.cjs` 驗證 DOM、方向鍵、Enter、篩選後清空與重新選取；PASS。不是 HTTP-origin／真實曲庫驗收 |
| Quiz ready／playing／answered／revealed／finished | stable gameplay HUD 與 ranking screen 是節奏遊戲的播放／成績語義；不能把 `ranking-*` 圖片當作 AMQ 答案正誤、熟悉度或 SRS 等級 | AMQ 以既有 QuizSession／QuizPanel phase 為單一狀態 owner；答案提交、揭曉、下一題、回合完成及 SRS 評級是 AMQ extension slots。正誤、跳過、揭曉、答題時間及學習記錄由 AMQ 規則判定 | `tests/quiz-panel.test.cjs` 覆蓋 ready／playing／answered、下一題、finished、來源錯誤、SRS 評級與模式切換；PASS。真實音訊及整套瀏覽器回合仍未驗收 |
| Learning／Settings empty／error／focus／touch | stable Options 的分類與控制項慣例可參考，但作品熟悉度、複習排程、資料備份與 OSK mapping 皆非 stable 原生功能 | 空狀態不得生成假統計；資料持久化錯誤應明示且不得報成功。OSK mapping 的 supported 只代表存在實際 selector 與 CSS consumer。手機完整觸控體驗仍需實機驗收 | 既有 `statistics-dashboard-panel`、workspace preferences、OSK panel tests 只覆蓋可重現的元件契約；本批不宣稱手機實機或真實持久化通過 |

### Batch207 驗收界線

本批新增 Catalog 篩選後 stale selection 的回歸斷言。Quiz 狀態由既有 integration suite 覆蓋，本批補齊 Wiki 語義對照，不引入 osu! ranking 圖片或假評級。Learning／Settings 只確認既有測試覆蓋範圍，不將 fixture 測試擴大解讀為真實瀏覽器驗收。


## Batch208 補充：回合設定、即時答題舞台與答題歷史

| AMQ 元件 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 回合設定 | stable Options 提供分類控制項的可理解層級，但不定義 AMQ 出題設定 | `#quiz-panel > .quiz-setup-section`、`#quiz-setup-heading`；沿用原 `quiz-target`、`quiz-count`、音訊片段與 autoplay controls，沒有建立第二份設定狀態 | Chromium 61/61；桌面三欄，390px 單欄；Quiz panel integration PASS |
| 出題篩選 | stable 選曲／篩選提供可展開條件的參考，但年份、作品類型、難度與看番狀態均是 AMQ 資料語義 | `.quiz-filter-panel` 的 summary 明確區分 QUESTION POOL；既有 filter IDs 與保存契約不變，不加入沒有資料依據的季別欄位 | formal shell 驗證 disclosure summary 與控制項仍存在；未將 fixture 視為真實曲庫驗收 |
| 即時回合／答題舞台 | stable gameplay HUD 顯示遊戲中狀態；osu!stable score／ranking 不等於 AMQ 答題結果 | `.quiz-round-section`、`#quiz-summary-row`、`#quiz-question-title`、`#quiz-answer-form`、`#quiz-actions`；正誤與 phase 仍由 QuizSession／QuizPanel 管理 | Chromium 61/61；桌面／390px 無水平溢位；Quiz integration PASS；真實音訊未驗收 |
| 答題歷史 | stable ranking screen 是單次 osu! 成績語義，不等於長期 AMQ 歷史 | `.quiz-history` 明確標示 `LOCAL HISTORY`，只顯示 quiz-history store 實際紀錄；不把跨回合歷史冒充單輪結算，不製造 PP／排名／PB | DOM／視覺已驗證；單輪結果頁仍待確認資料契約 |

### Batch208 驗收界線

這次實際替換猜歌設定／即時回合的正式 DOM 分區，保留所有既有控制項 ID 與狀態 owner。`artifacts/batch208-regression/quiz-desktop.png` 顯示本機資料來源失敗的真實錯誤狀態，沒有用假曲庫掩蓋。因測試使用 opaque origin，真實曲庫、HTTP-origin IndexedDB、音訊與 `.osk` 仍未驗收。


## Batch209 補充：本輪結果與跨回合歷史的分界

| AMQ 元件 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 本輪結果 | osu!stable ranking／score screen 是單次遊戲結果；不能把其 PP、排名、accuracy 語義直接套到 AMQ | `#quiz-round-results` 只在 QuizSession `finished` 時顯示；`roundId` 由 Quiz History Store `beginRound()` 產生並經 Session 快照傳遞；`getRoundHistory(roundId)` 只讀取該輪明確標記的新版 detail records | `quiz-history-store` 23/23、`quiz-session` 37/37、Quiz Panel integration PASS、formal shell 65/65。這是本機結果 UI，不是全球排行榜／PP／PB |
| 已保存與未保存紀錄 | 結算畫面不能把暫存在記憶體的紀錄冒充已保存資料 | round-history projection 的 `persisted` 僅為 API 投影欄位，不改變持久化 schema；未保存項目標示「尚未保存」，不納入已保存目標正確率 | Store regression 驗證失敗寫入後 `persisted=false`，flush 成功後 `persisted=true` |
| 空／錯誤／filtered-empty Catalog | stable 選曲需要清楚區分來源載入狀態與篩選結果 | 保留 `data-catalog-state`、`#catalog-status`、`#catalog-empty`；不以示意曲目掩蓋 opaque-origin 資料來源失敗 | Browser contract 驗證 loading／failed／loaded 與 source-empty／filtered-empty 視覺差異；真實 HTTP-origin 曲庫仍未驗收 |

### Batch209 驗收界線

- Result panel 只顯示可依 roundId 確認歸屬的紀錄；若沒有 roundId 或 store API 不可用，會明確隱藏明細而不是退回顯示跨回合歷史。
- `all` target 以三個獨立目標紀錄計算目標正確率；該百分比不是題目級單一正確率。揭曉與未播放跳過仍不寫入計分歷史。
- 本批沒有引入 osu! ranking 素材、PP、全球排名、個人最佳成績或假成績；真實 `.osk`、HTTP-origin IndexedDB、曲庫／音訊及 Candidate302／Candidate382 Stage 0 相容性仍未驗收。


## Batch210 補充：個人檔案與本機學習進度

| AMQ 元件 | stable／產品語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 個人檔案頁 | 玩家個人資訊與進度應與選歌、遊戲設定及學習統計有明確導航區隔 | 新增 `profile` 路由與 `#profile-panel`；顯示本機計分目標紀錄、目標正確率、作品進度、SRS 到期卡片、熟悉度明確分級、自由播放紀錄及最近作品。這是 local profile，不宣稱帳號身分或競技排名 | Profile panel 19/19 assertions；Chromium 72/72，390px 無水平溢位 |
| 共用學習資料 owner | 同一資料不應由多個 UI 重複建立、更新或維護不同副本 | `statistics-dashboard-panel` 提供唯讀 `getSnapshot()` 與 `subscribe()`；Profile 直接訂閱 dashboard 的報表，不新建 History／Familiarity／SRS／Playback stores，不另外持久化衍生統計 | Statistics dashboard panel test 驗證 snapshot、訂閱、讀取失敗傳播與取消訂閱 |
| 讀取錯誤與空狀態 | 資料無法讀取時不能顯示成零，零也不能代替「尚無資料」 | Profile 讀取失敗顯示「暫不可用」與原因；真正空資料顯示尚無答題資料；正確率無樣本時顯示「尚無資料」 | Unit test 覆蓋 error／empty／valid snapshot；inline browser 因 opaque origin 實際顯示讀取失敗，並未被當成成功資料驗收 |
| 全球排行榜／PP／PB | stable ranking 的計分契約不能由本機學習紀錄推導或假造 | Profile 明確標示全球排行榜、PP、PB 尚未接入可信競技資料來源；沒有建立排名資料、帳號身份或假成績 | UI 文案 contract PASS；排行榜資料 owner 仍待規劃與實作 |

### Batch210 驗收界線

- 個人檔案與學習中心共用同一統計 dashboard instance；Profile panel 不擁有第二套持久化 stores。
- `quiz.total` 是計分目標紀錄數，不等同遊戲回合數；all-target 可能每題產生三個目標紀錄。UI 用「計分目標紀錄／目標正確率」避免誤導。
- 本批沒有證明真實 HTTP-origin 持久化、外部封面 API、真實音訊、真實 `.osk` 或 Candidate302／Candidate382 Stage 0 相容性。


## Batch211 補充：結果生命週期與 Catalog artwork 降級

| AMQ 元件／狀態 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 回合手動結束／題庫耗盡 | stable ranking／結果畫面是已完成一局的結算語義；AMQ 不能把尚未計分或未播放題目算入結果 | `QuizSession.endRound()` 與 `nextQuestion()` 的 `round-complete`／`pool-exhausted` 都將 phase 切為 `finished`；結果只查 `getRoundHistory(roundId)`。手動結束只保留已寫入的計分紀錄；pool exhaustion 不補造未出題紀錄 | `quiz-session` 38/38；Quiz panel integration PASS。這是 session／DOM contract，不是 HTTP-origin／真實音訊 E2E |
| all-target 結算 | stable 的單一 score 不等於 AMQ 的多欄答案判定 | `target=all` 仍依既有 history store 寫出 anime／title／artist 三筆獨立目標；結果頁逐目標顯示，不把三筆誤稱三首歌曲 | `quiz-panel.test.cjs` 驗證三個目標與本輪結果，PASS |
| reveal／unplayed skip／保存失敗 | 結果只能反映實際計分與保存狀態 | reveal／unplayed skip 不寫入計分歷史；detail write failure 以 `persisted=false` 顯示「尚未保存」，不計入已保存正確率；回合仍可正常結束並顯示警告 | `quiz-session` 與 Quiz panel integration 回歸 PASS；未宣稱真實儲存設備驗收 |
| Catalog 封面 fallback | stable 選曲列表的封面是作品視覺入口；不能用不相干圖片冒充作品封面 | `catalog-browser.js` 每列保留作品封面 slot。只有 adapter 回傳安全 HTTPS URL 且圖片載入成功才顯示外部圖；無 adapter、無 artworkRef、provider 無資料／拒絕、圖片載入失敗時，使用作品標題型可讀 fallback，並更新狀態／ARIA。fallback 不冒充真實封面 | Catalog integration PASS，覆蓋 provider throw／no-result、圖片 load error、無 adapter／無 artworkRef 及詳情 fallback；77/77 Node test files、172 JS/CJS syntax、Chromium shell 72/72、Architecture 1137/0 PASS；真實外部 API 與圖片服務仍未驗收 |

### Batch211 驗收界線

- 本批的作品標題 fallback 是明確可替換的缺件視覺，不代表取得或授權任何真實作品封面。
- Chromium shell 72/72 PASS，證據輸出至 `artifacts/batch211-regression/`。inline fixture 仍不能證明 HTTP-origin IndexedDB、真實曲庫、真實音訊、真實 `.osk` 或使用者實機驗收。
- 排行榜／PP／PB 沒有可信後端資料 owner；不將本機學習歷史轉換成競技排名。


### Batch211 全球排行榜資料契約邊界

新增 `docs/LEADERBOARD_TRUST_CONTRACT.md` 作為未接入規格草案，限定未來榜單必須由可信服務端身份與版本化評分規則提供排名投影。沒有後端 owner、身份方案、評分規則、賽季與隱私決策前，前端只顯示未接入狀態；沒有新增 API client、帳號、資料庫 schema 或反作弊系統。此文件是需求契約，不是實作／安全驗收證據。


## Batch212 補充：OSK 結算面板 role 與 artwork lifecycle

| AMQ 元件 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 結算面板 skin role | stable ranking panel 是單次結果畫面的外觀語義；不等於 AMQ 計分規則 | `results.panel` 只映射到真實 `#quiz-round-results`，token `--amq-skin-role-results-panel`；深色遮罩保持文字可讀，不套用到整個猜歌頁，也不把 grade／PP 映射成答案正誤 | Chromium 72/72；31 runtime roles 都有 DOM target／CSS consumer，fixture asset apply PASS；不是實際 `.osk` 驗收 |
| Catalog artwork async lifecycle | 選曲列表中每個作品的視覺必須屬於目前 row／selection；切換與重繪後不得出現過期作品圖 | `catalog-browser.js` 以 `artworkRenderSequence`／`selectionArtworkSequence` 與 disposed guard 阻擋 stale Promise 寫入；不因單一 consumer 失效而取消共用 cache 中其他 consumer 的 lookup | Catalog integration 驗證快速選取切換、filter rerender、dispose 後 late resolve；不代表真實外部 provider／HTTP-origin 驗收 |
| 未支援 OSK roles | 只有具有明確語義對應、真實 DOM target 與 CSS consumer 的角色才可標為 supported | 新增 `docs/OSK_ROLE_GAP_AUDIT_BATCH212.md`；`results.panel` 接線後 runtime roles 由 30 增至 31，剩餘 16 個明確 unsupported。特別禁止 random character art 當作品封面、osu grade 當 AMQ 正誤、播放器 random 當隨機選曲 | `skin-contract-manifest` 9/9、`skin-theme-adapter` 13/13；完整 Node suite 最終值見 Batch212 工作狀態與 artifacts |


## Batch213 補充：獨立成績結果頁

| AMQ 元件 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 成績結果頁 | stable ranking 是一局結束後的結果畫面；其分數／PP／排名契約不等於 AMQ 學習資料 | 新增 `#results-workspace` 正式路由與導航，內含 `#quiz-round-results` 與初始空狀態。結果資料仍只由 QuizPanel 讀取既有 QuizSession phase 與 history store `roundId`，不建立第二個 history owner；未保存目標仍明示，不造 PP／排名／PB | Chromium 75/75；Quiz Panel integration PASS；結果頁手機 390px 無水平溢位。真實 HTTP-origin 保存／重載仍未驗收 |


## Batch214 補充：持久化回合完成狀態與多人準備狀態 role

| AMQ 元件 | stable／產品語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 最近完成回合 | 結算頁只能恢復一個明確完成的 round，不能用最近一筆跨回合歷史猜測是否完成 | `quiz-history-store` 以獨立 `amqLearningQuizLastCompletedRoundV1` key 記錄 schemaVersion／roundId／completedAt；`beginRound()` 清除 marker，`completeRound()` 僅接受 matching roundId；逐題明細仍由 round-scoped detail key 管理 | Store 26/26、Session 40/40、QuizPanel PASS；HTTP-origin Chromium 導航被 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋，真實 reload 未驗收 |
| 結果頁重載 | 已完成結果可從持久化資料恢復，但新回合開始後不可繼續顯示上一輪結果 | QuizPanel 在 idle 狀態讀取 last completed marker，依 marker 查詢 `getRoundHistory()`；active round 隱藏結果；沒有 marker 顯示空狀態 | QuizPanel test 覆蓋 idle restoration 與新回合清空；inline browser 不等於 HTTP-origin persistence proof |
| 多人準備狀態 | 玩家是否 ready 是房間 server snapshot 的狀態，不是前端自行推測 | `multiplayer-panel.js` 將玩家名稱與 ready badge 分離；badge 有 visible text、`data-ready`、`aria-label`。`multiplayer.ready-state` token 掛在穩定的 `#multiplayer-players`，只由 badge CSS consumer 使用 | Multiplayer panel integration PASS；Chromium formal shell 77/77，32 runtime roles 都有 CSS consumer；沒有宣稱真實多客戶端驗收 |

### Batch214 驗收界線

- HTTP-origin integration test 已新增，但本執行環境的 Chromium policy 阻止 loopback 導航；證據 `artifacts/batch214-regression/http-origin-blocker.txt`。不把這項阻塞記成通過。
- 新增的 `multiplayer.ready-state` 是 AMQ extension role，不將任何 osu!stable 成績圖映射為 AMQ 正誤或 ready 狀態。其餘 15 個 roles 仍保持 unsupported，直到有真實語義 target。


## Batch215 補充：學習歷史／複習清單與設定快速導覽

| AMQ 元件 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 最近答題歷史項目 | stable ranking 是單局結果，不等於 AMQ 長期學習紀錄；此處只借用可掃讀的列表層級 | `#learning-history-list > .learning-history-item`，由 Quiz History Store 真實 row 生成歌曲名稱、作品、來源、目標、結果與時間；最多 8 筆。失敗狀態與空狀態分開，不建立新的 history owner | statistics dashboard panel tests PASS；Chromium shell 86/86。opaque-origin 讀取失敗只驗證錯誤呈現，不代表真實儲存讀取成功 |
| 到期複習項目 | stable 選曲列表提供行項目視覺參考，但 SRS 是 AMQ extension，不等於 stable 原生玩法 | `#learning-review-list > .learning-review-item`；先由 SRS `chooseSession()` 選出可加入複習的 due IDs，再用同一 SRS snapshot 讀取狀態與到期時間。新卡／暫停卡不列為 due；目前顯示曲目 ID，不推測未保存的標題 | unit test 證明 due card 顯示、new card 排除及錯誤狀態清理；兩個 Skin role selector／CSS consumer contract PASS |
| 設定分類快速導覽 | stable Options 分類慣例可參考，但 AMQ 的帳號、備份、曲庫更新與 OSK 是產品自有模組 | `#page-settings .settings-quick-nav` 提供工作區／快捷鍵、帳號、備份、曲庫更新、OSK 五個按鈕；點擊後捲動至真實區塊並把焦點交給標題，不改變任何設定資料或 store owner | Chromium 桌面／手機功能測試 PASS，390px 無水平溢位，手機導覽兩欄排列 |

### Batch215 驗收界線

- Skin runtime roles 32→34，未支援角色由 15 降為 13。這只表示存在真實 DOM target 與 CSS consumer，不代表真實 `.osk` 的素材已驗收。
- HTTP-origin 測試本批再次因 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋 loopback 導覽，斷言沒有執行；不把它記成通過。
- Candidate302／Candidate382 Stage 0 原始檔缺席，未做相容性聲明；AMQ／EMQ 靜態曲庫資產 hash 未變。


## Batch216 補充：學習清單 source-aware artwork 與互動狀態

| AMQ 元件 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| 學習歷史／複習列作品識別 | stable song-select row 有作品識別與可掃讀層級；AMQ history／SRS 是產品自有資料契約 | `statistics-dashboard-panel.js` 只使用 `source + songId` exact identity 查詢當前 runtime catalog snapshot。跨來源同 ID 不互相命中；未載入來源保留已保存名稱／明確 ID，不自行載入第二份曲庫 | statistics panel tests 驗證 exact source identity；全量 Node 77/77 |
| 學習清單封面 | stable 選曲背景不等於作品封面；不可用 random OSK character art 填補 | 學習歷史／複習列只重用 app-scoped artwork adapter，且 record 必須帶明確 `artworkRef`。缺件、provider failure、圖片錯誤用可辨識 fallback；render generation／dispose guard 防 stale Promise | statistics panel artwork lifecycle regression PASS；不代表 live artwork API／實際圖片可用性驗收 |
| 結果／Catalog／多人互動 | stable 選曲與結果畫面提供 hover／focus／狀態回饋參考，但 AMQ 操作與多人狀態有獨立契約 | `ui-shell.css` 加入 focus-visible、disabled、error 與結果空狀態視覺；多人狀態仍以 server snapshot 為準，未建立第二份 state owner | Chromium shell 91/91；手機 390px 無水平溢位；無 uncaught browser exceptions |

Batch216 驗收界線：runtime catalog snapshot 只涵蓋當前載入模式；跨模式缺少可精確對應的記錄時不猜測標題。HTTP-origin／live artwork／音訊／真實 `.osk`／Candidate302 與 Candidate382 Stage 0 相容性仍未驗收。


## Batch217 補充：Catalog 焦點／觸控與多人 busy 語義

| AMQ 元件 | stable 參照語義 | AMQ 正式落點與取捨 | 驗證狀態 |
|---|---|---|---|
| Catalog row keyboard focus | 選曲列表需可由鍵盤定位與切換；AMQ row identity 必須含 source，不能只依 song ID | `catalog-browser.js` 在 render 前保存 focused row 的 `data-record-key`；render 後若同列仍在結果中就恢復焦點，否則聚焦搜尋欄。ArrowUp／ArrowDown／Enter 與既有選取 owner 不變，Enter 不播放音訊 | Catalog integration PASS；layout contract 12/12；Chromium shell 92/92 |
| Catalog touch target | 密集選曲列表仍需觸控可點選；長標題不能因固定列高而裁切 | `.catalog-table tbody tr` 高度 44px；table row height 是最低高度，長文字仍可自然擴高。手機仍使用既有獨立水平捲動區，不增加頁面溢位 | Chromium fixture 實測 row height >=44px；390px 無水平溢位 |
| Multiplayer busy state | 操作中與離線狀態應清楚呈現，但房間狀態由伺服器決定 | `#multiplayer-panel[aria-busy]` 反映 UI command busy；status 顯示操作處理中；錯誤仍由既有 `role=alert` owner 顯示，成功 snapshot 清錯，不推測 server state | Multiplayer integration 驗證 busy=false／offline alert／recovery；不是 live multi-client 驗收 |


## Batch218 補充：結果重掛載、Catalog 分頁焦點與多人 busy lifecycle

| AMQ 元件 | 語義要求 | 本批驗證 |
|---|---|---|
| 結果頁重新掛載 | 只能由已保存 completion marker 找回最近完成 round，不能從最近一筆任意 history 猜測 | QuizPanel fresh-mount regression 驗證 marker 恢復與 round-scoped rows；history store persistence／round isolation focused test PASS |
| Catalog 分頁焦點 | 分頁後原 focused row 不存在時，焦點不能留在 detached node | Catalog integration 透過分頁測試確認焦點回搜尋輸入；未改曲庫 selection／audio owner |
| Multiplayer pending command | Busy 是 client command lifecycle，不是 server room phase；伺服器 snapshot 仍是權威狀態 | 延遲 command fixture 驗證 `aria-busy=true`、ready action disabled、操作中 status；完成後清 busy，並由 server snapshot 更新 ready 狀態 |

Batch218 只新增／擴充測試，沒有 production source 變更；完整 Node suite 77/77 使用 Batch217 最終 source 已通過，本批修改的四個 Node test files個別重跑通過。HTTP-origin／live service／實機驗收仍未完成。


## Batch219 補充：多人命令拒絕與錯誤生命週期

| 元件 | 語義要求 | 實作／驗證 |
|---|---|---|
| Multiplayer command error | HTTP command rejection 是操作結果，不能被同一個 connected room snapshot 的 render 當成成功狀態清掉 | `multiplayer-panel.js` 以 `commandError` 管理錯誤：操作開始清舊錯誤，catch 設定新錯誤，finally render 保留拒絕原因；成功 retry 清除。Room state 仍由 server snapshot 決定 | Integration 注入 HTTP 409 `ROOM_COMMAND_REJECTED`，驗證 error 保留、busy 清除、retry 後清錯與 server ready state 同步；全量 Node 77/77 |


## Batch220 補充：Multiplayer network error recovery

- `multiplayer-panel.integration.test.cjs` 在命令 fetch 注入 network failure，確認 client command error 不會被 connected snapshot render 清除，`aria-busy` 會清除；後續 offline→connected recovery 清除 transient network error。房間 phase／ready 仍由 server snapshot 決定。
- Catalog mode-switch 測試尚未有隔離 fixture。現有 integration test 後段同時掛載多個 consumer 共用 DOM，不能以其結果聲稱單一 Catalog instance 的 mode switch 已驗收；此項保留待辦。


## Batch221 補充：Catalog mode-switch 與 source-empty 語義

| AMQ 元件 | 契約 | 實作／驗證 |
|---|---|---|
| Mode switch | 切換資料源後不得顯示上一個 mode 的 row／selection；過期 load 不得覆蓋較新的 mode | 新增隔離的 `catalog-mode-switch.integration.test.cjs`，驗證 AMQ→EMQ→MIX、focus 回搜尋、selected details 清理與 stale load protection |
| Source empty vs filtered-empty | 真正空曲庫與 filter 沒有匹配歌曲是不同狀態，文案／ARIA data state 不得混淆 | `catalog-browser.js` 將 `dataStatus="empty"` 提升為明確優先分支；測試驗證 empty snapshot 使用 `data-catalog-state="empty"`，filtered-empty 留給有資料但 filter 結果為零 |
| Failed load | 失敗後不得保留上一個來源的 rows／selected details | 隔離 mode-switch integration 驗證 failed load 清理與錯誤顯示；全量 Node 78/78 |


## Batch222 補充：Catalog source-state matrix

- 隔離 Catalog mode-switch fixture 追加 partial、retry、filtered-empty 與 empty source assertions。`partial`／`failed` 使用既有 error/status owner；retry 成功清除 error；真正空 source 使用 `data-catalog-state="empty"`，篩選無匹配使用 `filtered-empty`。
- 這批未改 production source，重跑新增／修改的 isolated test。下一批再評估 stale load cancellation／error detail 是否存在必要 production change。


## Batch223 補充：Catalog error／retry 的可讀狀態與鍵盤恢復

| 元件 | 語義要求 | 實作／驗證 |
|---|---|---|
| Catalog partial／failed | 錯誤需可讀、可辨識，partial 數量不應隱藏；不得只改色或只在 console 顯示 | `#catalog-error[role=alert]` 以文字呈現 code／message、輸入／可用／拒絕筆數或明確原因；`data-error-code` 供診斷；使用 `textContent` 不注入 HTML | Catalog mode-switch integration PASS；CSS contract 13/13；Chromium 96/96 |
| Retry busy／keyboard | 重新載入時要有 busy feedback，操作結束後鍵盤焦點不可掉到頁面外 | `#catalog-browser[aria-busy]`、按鈕「載入中…／重試載入／重新載入」、`aria-label`／`aria-describedby`；若操作前焦點在 reload，finally 恢復焦點 | isolated integration 覆蓋失敗 retry 與成功 retry；Chromium 驗證 desktop banner 與 390px 無溢位 |

Batch223 已確認取消／stale load 的權威責任在 `repository.js`／`runtime-bootstrap.js`；Catalog UI 只保留 render sequence guard，不另造 request owner。HTTP-origin 與 live provider 仍未驗收。


## Batch224 補充：結果頁主要操作與多人 busy focus

| 元件 | 語義要求 | 實作／驗證 |
|---|---|---|
| 結果頁空／完成狀態 | 空狀態要提供清楚下一步；已保存結果要有返回練習路徑，但不能偽裝為成績或自動開始回合 | `#results-return-to-quiz` 與 `#results-continue-quiz` 都導向 quiz setup；只負責導覽，不建立資料或觸發新回合 | `results-ui.contract.test.cjs` PASS；Chromium 104/104；桌面／390px 截圖位於 `artifacts/batch224-regression/` |
| Quiz route keyboard focus | 導覽後焦點必須落在當前可見頁面，而不是另一個隱藏頁面的控制項 | `app-shell.js` 改聚焦可見的 `#quiz-setup-heading`；移除對 Catalog `[data-mode="AMQ"]` 的錯誤聚焦 | Browser test 驗證由 results CTA 返回後 activeElement 為 quiz setup heading |
| Multiplayer command busy | 忙碌期間按鈕 disabled 不可令鍵盤焦點永久遺失；操作結果仍以 server snapshot 為準 | `multiplayer-panel.js` 保存操作前焦點；finally render 後恢復到可用控制項，不可用則聚焦狀態提示。房間狀態仍由 session snapshot 決定 | multiplayer integration 驗證 pending／409 rejection 後 focus restoration；房間 snapshot owner 未改 |

Batch224 不新增 OSK role；結果 CTA、busy/focus 與 touch target 是既有元件互動語義。真實多人 server／音訊、HTTP-origin 與實機仍未驗收。


## Batch225 補充：猜歌答題舞台的 audio／error state

| 元件 | 語義要求 | 實作／驗證 |
|---|---|---|
| Audio status | loading／playing／blocked／failed 不應只靠文字或顏色單獨辨識；狀態需對輔助技術公告 | `#quiz-audio-status` 使用 `role=status`／`aria-live=polite`，`data-audio-state` 由 QuizSession state 投影；各狀態有獨立 badge 視覺 | `quiz-panel.test.cjs`、`quiz-ui-state.contract.test.cjs` 與 Chromium 108/108 PASS |
| Error banner | 沒有錯誤時不留空 alert；舊錯誤不應覆蓋成功恢復後的狀態 | `#quiz-error[hidden]`；`data-error-state`／`data-error-code`；audioError 只在 audio state failed／blocked 時呈現 | audio failure 會顯示安全候選診斷；下一輪成功播放後清除舊 banner；手機長訊息換行 |
| 操作與建議 | 答題控制要可見 hover／disabled，觸控 target 需足夠大 | Quiz action buttons 44px、mobile 46px；suggestion option 44px | Browser test 驗證桌面／390px mobile layout 與無水平溢位 |

Batch225 沒有更改 QuizSession／AudioService 的狀態 owner；只將既有狀態正確投影到 UI。Live audio／HTTP-origin／實機仍未驗收。


## Batch226 補充：多人回合狀態與結果明細長內容

| 元件 | 語義要求 | 實作／驗證 |
|---|---|---|
| Multiplayer error | 無錯誤不應留下空 alert；有錯誤時需明顯但不遮蔽操作 | `#multiplayer-error[hidden]`、`data-error-state`／`data-error-code`、長訊息換行 | Multiplayer integration 與 `multiplayer-ui-state.contract.test.cjs` PASS；Chromium 114/114 |
| Round status | active／submitted／expired 狀態需明確；期限到達後不假裝前端已結算 | `#multiplayer-round-status[data-round-state]`；本機提交依 server snapshot answers 判斷；expired 提示等待伺服器結算 | integration 驗證 active／submitted；state contract 覆蓋 active／submitted／expired；伺服器仍是結算 owner |
| Audio status | waiting／loading／playing／failed 要能快速辨識 | `#multiplayer-audio-status[data-audio-state]`，由現有 AudioService 狀態／播放結果投影 | state contract 與 browser CSS state matrix PASS；不新增音訊 owner |
| Results metadata | 長作品標題與未保存警告在手機不能造成水平溢位 | `.quiz-round-result-item strong/span`、summary、note `overflow-wrap:anywhere` | Desktop／390px long-content fixture 無溢位；結果明細仍只用 round-scoped persisted rows |

Batch226 沒有新增 OSK role。HTTP-origin／live audio／實機驗收仍未完成。


## Batch227 補充：Question-card 舊樣式實際替換

| 元件 | 舊依賴 | 新 owner／驗證 |
|---|---|---|
| `.quiz-question-card` | `styles.css` 全域白底／12px 圓角／border；shell 另用 `!important` 蓋掉 | 刪除 global card／notice margin rule；quiz stage 保留專屬 answer surface；multiplayer room／round cards 在 `ui-shell.css` 明確擁有 padding／border／radius／dark surface | `quiz-ui-state.contract.test.cjs` PASS；Chromium 119/119 |
| quiz history／SRS／learning metrics | shell override group 使用不必要 `!important` | 移除 `!important`，由更具體的 page shell selector 與後續專屬 rule 管理；browser computed style 確認 dark surface 保留 | Chromium 119/119，無桌面／390px 溢位 |

Batch227 是實際移除舊 CSS，不只新增覆蓋規則；沒有更改資料 owner 或 OSK role inventory。


## Batch228 補充：表單控制項舊 palette 實際替換

| 元件 | 舊依賴 | 新 owner／驗證 |
|---|---|---|
| 一般 `input`／`select` | shell 最前段全域 `input,select` 使用 `!important`，蓋過所有頁面樣式，導致控制項外觀責任不明 | `.app-page` 與 `#free-player-dock` 明確管理一般文字／數字／選單控制項；checkbox／radio／range／file 排除，保留專屬 skin／原生規則 |
| Quiz answer fields | 額外 palette 規則與單人 answer input 的 border／radius／background 都使用 `!important` | 移除重複 palette 規則及 answer input `!important`，單人 answer 欄位由具體 shell selector 擁有；all-answer／multiplayer 欄位使用 scoped control palette |
| disabled input/select | 原本只有多人按鈕等零散 disabled feedback | shell 控制項 disabled 有 cursor／opacity feedback；既有 focus-visible outline 保留 |

驗證：`tests/quiz-ui-state.contract.test.cjs` 防止全域 `!important` palette 與 quiz answer 覆寫回歸；`tests/app-shell.browser.test.py` Chromium 127/127，實際 computed-style 覆蓋 Catalog、Free Player、Quiz、Multiplayer、Settings，並保留 390px 手機無水平溢位。未新增 OSK role；runtime role inventory 維持 34 supported／13 unsupported。真實 `.osk`、HTTP-origin persistence、live audio 與 Candidate302／Candidate382 Stage 0 仍未驗收。


## Batch229 補充：表單與 Skin 狀態舊覆寫替換

| 元件 | 舊依賴 | 新 owner／驗證 |
|---|---|---|
| Catalog row selection | `.catalog-row-select` 尺寸與 padding `!important` | 直接宣告 width／min-height／padding；Chromium computed style 驗證 15px、0 padding |
| Settings toggle | checkbox 尺寸、邊框、checked／unchecked 背景 `!important` | `#page-settings input[type=checkbox]` 與 `:checked` 由 ID scope 管理；保留 skin role token 與自訂 checkbox geometry |
| Free Player progress | range track radius `!important` | `#free-player-progress` 專屬 selector 管理 dark track／radius；thumb skin hooks 不變 |
| Settings file／dropdown | file input 背景與 dropdown skin image 使用 `!important` | file input 由 Settings scope 管理；`#page-settings select` 以較具體 selector 保留 dropdown gradient／skin token |
| Preferences status／learning metric | state status 與 metrics card 背景 `!important` | Settings state scope 與 learning dashboard selector 明確管理 gradient／色彩 |

驗證：`tests/ui-shell-css.contract.test.cjs` 與 Chromium shell 133/133 PASS，OSK import browser 12/12 PASS；Architecture 1,172/0。UI shell 剩餘 `!important` 限於 hidden state、reduced-motion 等必要語義；這不是追求零 `!important` 的盲目清理。沒有新增 OSK role，inventory 維持 34 supported／13 unsupported。


## Batch230 補充：正式頁面導航 touch target

- `.app-back-button` 與 `.app-shell-nav-links button` 現在明確具有 `min-height:44px`，避免桌面與 390px 手機因字體／行高／padding 變化而產生不足的觸控高度。
- `tests/app-shell.browser.test.py` 對桌面與手機實際導航 DOM 讀取 computed `min-height`；Chromium shell 135/135 PASS，並保留手機無水平溢位及首頁入口幾何檢查。
- 不新增 OSK role，不改頁面 route/state owner；UI 主線仍未結案。


## Batch231 補充：Catalog 作品封面 fallback 的來源語義

- 真實 artwork URL 成功載入時，仍由 artwork adapter 提供圖片；缺少 `artworkRef`、provider 無結果、URL 不安全或圖片 load error 時，不用隨機 OSK 圖片補位。
- `createArtworkFallback()` 以作品標題首個 Unicode 字元產生 mark，並依實際 source 設定 AMQ／EMQ／MIX 標記；這是有資料依據的視覺 fallback，不是對作品封面的冒充。
- 列表小封面與選取詳情大封面共用同一語義結構；loading pulse 遵守 `prefers-reduced-motion`。Chromium desktop／390px mobile 的 source badge、mark 與 reduced-motion computed-style assertions 為 139/139 PASS。
- 不新增 OSK role；`catalog.song-artwork` 仍 unsupported，因 OSK 資產不是作品封面。真實 live artwork provider／HTTP-origin 仍未驗收。


## Batch232 補充：跨頁導覽的閱讀位置與焦點

- 正式頁面切換會重置視窗捲動到頁首，避免使用者從 Catalog 深處切到 Quiz／Results／Settings 時，新頁標題留在視窗之外。路由仍由 `app-shell.js` 單一 owner 管理。
- 導覽焦點仍由既有 `navigate()` focus logic 負責；Quiz 特別聚焦可見 `#quiz-setup-heading`。設定頁快速導覽是頁內跳轉，繼續 `scrollIntoView()` 到指定區塊，不會被跨頁頁首重置干擾。
- Chromium 390px regression 由 520px scroll offset 切頁，驗證 `scrollY === 0` 與目的頁標題可見；formal shell 141/141 PASS。
