# Batch 20 交接：真實曲庫來源接線

## 工作起點
- 目前工作目錄不是 Git repository，沒有 `.git` metadata。
- 舊版參考仍是使用者指定的 `AMQ382(1).html`；不得修改，也不得再搜尋 Candidate302。
- 來源副本已納入 `src/data/assets/data.js` 與 `src/data/assets/emq-data.js`，hash 見 `docs/SOURCE_DATA_AUDIT_20261027.md`。

## 已完成
- `src/data/source-runtime.js` 將來源接到既有 mapper、adapter、registry、repository、runtime bootstrap。
- AMQ 38,821 首與 EMQ 16,839 首已用真實資料通過新版內部契約與 Catalog 驗證。
- 初次啟動載入 AMQ；切換 EMQ 會自動載入；重新載入按鈕接上 runtime。
- MIX 尚未核實，不做 AMQ + EMQ union，改顯示 `DATA_MODE_UNCONFIGURED`。
- `src/ui/catalog-browser.js` 以 load sequence 避免連續載入時舊 finally 覆寫新 loading 狀態。

## 測試
- `node tests/source-runtime.integration.test.cjs`：PASS。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：55,660 筆 PASS。
- 核心 67/67、資料管線 15/15、查詢 17/17、mapper 6/6、catalog browser 6/6、tooling 8/8 PASS。
- Architecture checker：206 passed、0 failed。
- Chromium headless 在本執行環境無法正常退出，瀏覽器 E2E 未驗收。

## 下一步
1. 擴充真實資料下的搜尋、分頁、分組及重新載入整合回歸。
2. 依靜態參考證據盤點猜歌回合狀態與答案比對規則，再實作不依賴未核實 MIX 語意的核心引擎。
3. 瀏覽器 E2E、舊版相容性、MIX 產品規則與音訊播放仍保持未驗收。
