# AMQ 新版重建交接：Batch144（唯讀 diagnostics CLI 邊界）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 維持唯讀。

## 修改
- 擴充 `tests/database-integrity.test.cjs`，使用特殊字元路徑驗證 inspector／retention report 成功且不修改輸入 DB。
- 對 malformed DB、directory path 驗證 inspector／retention／verify 明確失敗；sentinel payload 不會出現在 stdout／stderr。
- 驗證 backup tool 遇到 malformed source 時不留下目的檔。
- 未發現 production defect，沒有為了產生程式碼差異而修改穩定 CLI。

## Targeted test
- `node --test tests/database-integrity.test.cjs`：7/7 PASS。
- 最終完整回歸與封包結果以 `docs/WORK_STATUS.md` Batch144 收尾段落為準。

## 下一步
Batch145：回到功能真相表與產品核心契約，挑選可安全實作且可驗證的必要功能缺口；不要無限擴張 diagnostics tooling。
