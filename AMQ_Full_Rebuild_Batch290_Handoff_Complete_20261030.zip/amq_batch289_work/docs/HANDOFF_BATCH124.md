# AMQ 新版重建交接：Batch124（多人 SRS 原子寫入）

日期：2026-10-28。基礎為 Batch123 工作副本；無 `.git` metadata，未初始化／commit／push。

## 實作
- `server/database.cjs` 新增 `srs_assessment_events`，以 `(user_id,event_id)` 唯一鍵保存 fingerprint、source、songId、grade、狀態、revision 與結果。
- `server/srs-repository.cjs` 新增 `applyMultiplayerAssessmentInTransaction()`；同 event ID／同 fingerprint 冪等回放，不同 payload 回報 `SRS_ASSESSMENT_EVENT_CONFLICT`。函式要求呼叫者已持有 SQLite transaction。
- `server/multiplayer-host.cjs` 從 server-owned questionId、roundId、authenticated playerId 與 server assessment 建立 SRS event；`answer.submit` 與 server timeout 都會套用評級。MIX 依題目實際來源選擇 AMQ／EMQ schedule。
- `persistEntry()` 在同一 `BEGIN IMMEDIATE` transaction 保存 room state、command idempotency record、SRS schedule 與 assessment event。SRS 資料損壞或更新失敗會 rollback 整個 room command。
- `server/http-server.cjs` 將現有 SRS repository 注入多人 host。沒有增加可由 client 指定可信 grade 的 endpoint。
- SRS 只自動評級已入庫且未暫停卡片，不自動 enroll；source-less legacy AMQ cards 不會遷移到 EMQ。
- `tests/multiplayer-http.integration.test.cjs` 覆蓋 server grade、已入庫卡片寫入、timeout 寫入、source isolation、event replay/conflict、server restart replay 與 transaction rollback。

## 修改檔案
- `server/database.cjs`
- `server/srs-repository.cjs`
- `server/multiplayer-host.cjs`
- `server/http-server.cjs`
- `tests/multiplayer-http.integration.test.cjs`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `docs/HANDOFF_BATCH124.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `AI_START_HERE.md`
- `README_FIRST.md`
- `MANIFEST.sha256`

## Targeted 驗證
- `node --test tests/multiplayer-http.integration.test.cjs tests/multiplayer-host.integration.test.cjs tests/server-auth-srs.integration.test.cjs tests/private-server-backup.test.cjs`：10/10 subtests PASS。
- 修改 server／integration test 的 `node --check`：PASS。
- 全量測試、tooling、architecture、source audit／mapper／benchmark 與封包驗證需於本批收尾完成後，以最終結果更新本文。

## 限制
- 真實 browser／multi-client E2E 仍因 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞。
- 本批只評級既有未暫停 SRS 卡片，不自動 enrollment；未入庫或 suspended 卡片的事件會被記錄為 skipped，不會在日後入庫時補評級。
- 多人 durable offline queue／多裝置合併與 WebSocket／多節點未完成。

## 下一步
Batch125：修復單人音源失敗診斷的可行動呈現與答案建議鍵盤操作，不做大規模 CSS 改版。

## 最終交付封包
- 檔名：`AMQ_Full_Rebuild_Batch124_Handoff_20261028.zip`。
- Manifest／ZIP CRC／檔案集合與 SHA-256 由最終交付回報提供；封包不記錄自己的 SHA-256，避免自我參照。
- ZIP 不包含 `.git` metadata 或 `.pem`／`.key` 私鑰。
