# Batch290 Handoff：建立 Quiz Mods 單一規則／狀態 owner

## 本批完成
- 新增 `src/engine/quiz-mods.js`，提供唯一 Mods registry、倍率計算、選取正規化、互斥來源設定、本機持久化、訂閱、reset 與 dispose。
- Registry 只包含目前提出的 Reverse ×1.12、Fade Out ×1.06、Beat Shuffle ×1.12、Vocal Only、Background Only；Vocal Only／Background Only 互斥且不提高倍率。Short Reveal、Speed Up、Slow Motion 不在 registry。
- `src/index.html` 與 `tests/tests.html` 依順序載入模組；Architecture Checker 的 runtime load-order contract 同步更新。
- 新增 `tests/quiz-mods.test.cjs`，涵蓋 registry 排除項、倍率相乘、互斥選取、保存／恢復／reset、通知、未知 ID 與 dispose。

## 驗證
- `node --test tests/quiz-mods.test.cjs`：5/5 PASS。
- Focused Mods／Quiz panel／Batch289 result-state Node tests：11/11 PASS。
- `python tests/batch286-quiz-gameplay-layout.browser.py`：55/55 PASS，涵蓋 1920×1080、1440×900、1024×768、390×844；此為 geometry/fixture，不代表 live audio/provider。
- Architecture Checker：1,394 PASS／0 FAIL；Python AST：40/40 PASS。
- 全量 `node --test tests/*.test.cjs` 在 120 秒工具上限逾時，輸出到第 99 個測試檔附近但無 aggregate exit code；全量 suite 為 NOT_VERIFIED。clean-extract 驗證尚待完成。

## 重要界線
- 這批只建立規則與選取狀態 owner，**不是完整 Mods 功能交付**。尚未有 Mods 選擇 overlay，也未將 Reverse／Fade Out／Beat Shuffle 音訊變換接入 AudioService；也沒有 canonical score owner 將倍率套用至得分。UI 不應先畫出會讓人以為已生效的按鈕或倍率。
- 音源分離（Vocal Only／Background Only）也未有可用的音軌資料契約；目前只處理互斥規則，不假裝能分離音源。
- `src/engine/quiz-session.js`、答案判定、計時與得分流程未改。
- 原圖 `artifacts/osu-reference/osu-game-modifiers.jpg` 已檢視。Stable 視覺 gate、Quiz live session/audio、VNDB live HTTP、HTTP-origin IndexedDB、Windows／手機實機仍未驗收。

## 下一批
1. 先確認 AudioService 可安全提供的播放變換能力與真實音源限制，先做能實際作用的一個 Mod，不為了湊 UI 而虛構支援。
2. 將 Mods store 接到單一 Quiz settings owner，新增 modal／overlay、鍵盤焦點、Escape、Reset／Close 及 Skin component IDs；只有已接通的效果才可啟用。
3. 若倍率需要正式顯示或計分，先追蹤／建立單一 score owner，並測試倍率套用規則；未有得分系統前不得顯示「實際分數倍率」的假承諾。
4. 補 Quiz session phase transition matrix，然後跑 Architecture Checker、syntax／AST、四尺寸 browser、全量 Node 分組與 clean-extract 測試。
