# Batch 71 交接：產品範圍與全域 SRS 規格

日期：2026-10-27

## 本批完成
- `docs/PRODUCT_SCOPE_DECISIONS_BATCH71.md`：記錄功能納入／排除決策與驗收條件。
- `docs/SRS_AUTOMATIC_ASSESSMENT_SPEC_BATCH71.md`：定義全域 SRS、自動評估、手動覆寫、選題、資料契約與測試矩陣。
- 更新 `docs/FUNCTION_INVENTORY.md`、`docs/MASTER_CHECKLIST.md`（新增 AMQ-815 至 AMQ-850）、`docs/WORK_STATUS.md`。
- 本批是產品規格／工作清單更新，沒有修改 `src/`、AMQ／EMQ 資產或舊版參考檔；不可宣稱全域 SRS 已實作。

## 使用者決策（優先於 Batch 70 舊建議）
不做收藏、獨立作品圖鑑（暫不做）、歌手圖鑑、探索新歌獨立模式、弱點補強獨立模式、歌曲標籤、待聽佇列、主題切換。直接採深色背景。Batch 70 其他功能原則上都要做，依依賴／風險排序。

## SRS 方向
全域 toggle；開啟時啟用統計、排程、適應性出題與自動評估；關閉時停止 SRS 對選題／統計／排程的影響，但保留資料。自動評估基於真實可觀測的答題訊號，提供可解釋的評級建議；手動評級可覆寫並記錄來源。跨 AMQ／EMQ／MIX，保持 source-aware identity；SRS eligibility 必須服從所有硬性篩選。詳見 SRS 規格。

## 驗收政策
使用者已指出 P0 已驗收。不得因 AI 無法自行重跑瀏覽器而否定已驗收結果或讓整批 P0 永久阻塞。既有具體音訊／UI 失敗若仍有效，獨立列為已知問題；不要把它擴張成整批重驗。自動化測試與使用者實機驗收須分開標記。

## 下一批直接工作
1. 讀取本文件、`docs/PRODUCT_SCOPE_DECISIONS_BATCH71.md`、`docs/SRS_AUTOMATIC_ASSESSMENT_SPEC_BATCH71.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`。
2. 核對現有 FSRS scheduler、SRS store、app settings、QuizPool／Selector、QuizSession 事件與評級 UI API；不可先假設方法名稱或另建第二個 scheduler。
3. 實作一個完整切片：assessment decision table + global SRS toggle + source-aware selector integration + tests，或先做必要猜歌篩選完整切片，依現有依賴選最穩妥的批次。
4. 任何提示／重播訊號若沒有真實事件資料，標為 unknown，不可假造。
5. 全量跑既有 Node/tooling/architecture/source/mappers/syntax tests；只回報實際執行結果。
6. 更新唯一主清單、狀態、handoff、AI_START_HERE、NEXT_SESSION_PROMPT、manifest，交付完整 ZIP。

## 檔案保護
不搜尋 Candidate302；不修改 `src/data/assets/data.js`、`src/data/assets/emq-data.js` 或舊版參考 HTML；不提前做 UI/CSS 全面重構。保留既有 source-aware identity、FSRS scheduler、storage failure protection 與使用者已驗收結果。
