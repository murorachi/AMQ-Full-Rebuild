# AMQ Batch 64 交接：使用者實機驗收與答案下拉選單缺口

日期：2026-10-27

## 使用者實機回報

使用者已實際下載／解壓 Batch 63、找到啟動方式、成功啟動且畫面正常。使用者回報 AMQ／EMQ／MIX 出題、模式切換、答題／下一題、搜尋／篩選／排序及重新載入後測試資料保存皆可用。此處是使用者的人工驗收回報，並非本批 AI 直接執行或自動化測試。

未通過／未完成項目：
- 部分歌曲無法播放，畫面顯示 `AUDIO_ALL_CANDIDATES_FAILED`；根因未確認。
- 猜歌答案建議下拉選單缺失，使用者指出舊版下拉選單與邏輯消失。
- 使用者沒有看到收藏操作 UI；自訂清單操作回報正常。
- 響應式尚未測試。
- 鍵盤行為尚未由使用者驗收，先明確化快捷鍵語義。

## 下拉選單缺口的程式證據

- `src/index.html` 的 `#quiz-answer` 是一般 input，沒有 `quizSuggestions` listbox。
- `src/ui/quiz-panel.js` 沒有 `buildSuggestions()`、候選選項渲染或答案建議鍵盤導覽。
- 已提供的 `/mnt/data/AMQ382(2).html` SHA-256 為 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`，HTML 標示 Candidate381，靜態內容含 `quizAnswer`／`quizSuggestions`、`buildSuggestions()`、ArrowDown／ArrowUp／Enter／Escape、IME composition 防護及繁體中文建議選項設定線索。只可用作靜態功能線索，不可宣稱 Candidate302／Candidate382 Stage 0 相容。

## 鍵盤操作的明確定義

1. 在猜歌答案欄輸入文字時，出現符合的答案建議。
2. ArrowDown／ArrowUp 在建議選項間移動。
3. Enter 在建議清單開啟時選取目前建議，不得誤提交答案；未選建議時才依明確的表單流程提交。
4. Escape 關閉建議清單。
5. IME 組字期間不攔截 Enter／方向鍵。
6. 曲庫結果列另有方向鍵移動可見列、Enter 選取的行為，與猜歌建議下拉選單是不同功能。

## 下一批工作（Batch 65）

1. 恢復答案建議下拉選單與鍵盤操作，使用新版 Catalog／answer evaluator，不搬入整段舊版程式碼。
2. 補 Node integration tests：匹配建議、無結果、鍵盤移動、Enter 選取而非提交、Escape、IME composition、點選建議、切換作答目標後刷新。
3. 追查 `AUDIO_ALL_CANDIDATES_FAILED` 的產生點與候選結果，增加可診斷錯誤資訊；真實音訊播放仍須真實瀏覽器驗收。
4. 將收藏 UI 缺失列為功能缺口；`aniFavorites_v1` 身份及 source-less legacy IDs 仍 BLOCKED，不猜測寫入或遷移。
5. 重新執行受影響的 tests、全量 Node／tooling／architecture／source audit／mapper／benchmark／syntax，更新同一份 checklist／status／handoff／manifest／ZIP。

## 本批實作與測試聲明

本批只整理使用者驗收證據、確認下拉選單缺口並更新文件，**沒有修改產品程式碼，也沒有新增程式測試**。本批不重新宣稱 Batch 62 的測試為本批新測試。正式產品仍未最終驗收。
