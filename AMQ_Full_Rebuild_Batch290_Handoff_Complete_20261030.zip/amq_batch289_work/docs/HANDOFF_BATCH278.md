# Batch278 Handoff：批准 CI runner 的真實 origin 驗收工具

## 新增實作
- 新增 `.github/workflows/amq-acceptance.yml`：GitHub Actions 在標準 Ubuntu runner 安裝 Chromium/Playwright，透過 HTTP origin 提供正式 `src/`，執行正式 IndexedDB save/reload 與 live ANN artwork image load 探測，最後上傳 JSON 報告。沒有自動推送、部署或外傳使用者資料。
- 新增 `tests/approved-runner-live-acceptance.py`：使用實際 `skinThemeStore` 寫入版本化主題、重新載入頁面後讀回並清理；另從正式 `window.DB.anime` 找出明確 ANNID，透過正式 ANN adapter 請求並嘗試解碼回傳圖片。沒有用 fixture 取代 live provider。IndexedDB 未通過時 workflow job 失敗，診斷 JSON 仍由 `if: always()` artifact step 上傳。
- 本機目前 Chromium 對 HTTP/HTTPS app navigation 的 `ERR_BLOCKED_BY_ADMINISTRATOR` 已知，依政策沒有在本批重複探測；因此 CI workflow 尚未被觸發，這項仍是「待 runner 執行」，不是已驗收。

## 驗證
- Batch277 既有 Node：99 files／20 groups／310 subtests PASS；Architecture 1,344/0；JS/CJS 194/194；Python AST 34/34。
- 本批新增 acceptance Python script AST 檢查應列入最新總數；workflow 靜態檢視確認有 timeout、read-only contents permission、real HTTP origin、artifact upload。GitHub Actions 尚未執行，不能宣稱 workflow 或 live provider PASS。

## 尚未解除
1. 必須將此工作副本匯入使用者可執行 GitHub Actions 的 repository，並執行 `workflow_dispatch` 或 push/PR workflow。此環境無已確認的 repository/runner，因此不能代替使用者觸發。
2. Live artwork provider/CORS/image decode 仍依 runner JSON 結果決定；ANN 測試只選用資料內明確 ANNID。
3. Home/Catalog 人工 osu! Stable visual gate、外部 AMQ/EMQ 可聽音訊、Windows／實機鍵盤與觸控仍未驗收。

## 下一批 Batch279
- 讀取 Actions artifact 的 `acceptance-report.json`；若 IndexedDB 通過，結案該環境阻塞並繼續 live artwork；若失敗，依 report 的具體 error code 修正，不重試已知封鎖的本機 origin。
- 持續處理 Home/Catalog Stable visual gap；UI 修改前必須打開對應參考圖並定位正式 DOM/CSS/state owner。
