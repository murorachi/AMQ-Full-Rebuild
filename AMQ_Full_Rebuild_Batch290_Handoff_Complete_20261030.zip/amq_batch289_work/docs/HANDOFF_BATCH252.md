# Batch252 Handoff：Skin fidelity 與真實 OSK 相容界線

## 基準／安全
- 唯讀基準：`/mnt/data/AMQ_Full_Rebuild_Batch251_Cross_Page_E2E_20261029.zip`，SHA-256 `d6c1d49a9f1ba47d89b8a969d82f325da7c6bc997009772b33e60b6fa271b546`，sidecar 一致、ZIP CRC 完整。
- 工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch252_Skin_Fidelity/AMQ_Full_Rebuild_Batch245_Project`；沒有 Git repository，未初始化 `.git`；未覆蓋 Batch251。
- AMQ／EMQ raw data hashes 維持既有值，未修改。

## 實際 `.osk` 解析
- 輸入 `/mnt/data/aristia hima.osk` SHA-256 `f07fd7ed43c6279bb43db9c242da88c15e1a18326b0ba5cc6116c3697bf785d3`；`unzip -t` 通過。
- 使用 `src/skins/osk-importer.js` 真正解析 ZIP，注入 Node `zlib.inflateRaw`；`skin.ini` metadata：name `aristia hima`、author `osu! skin mixer by rednir`、version `latest`；sections `general`、`colours`、`fonts`、`catchthebeat`、`mania`。
- Parser 讀取 119 張圖片、0 個音效、總解壓大小 10,071,206 bytes。8 個已知 AMQ mapping 中找到 `selection-mode.png`、`selection-random.png`、`selection-options.png`、`ranking-panel.png`；未找到 menu background、selection bar、songselect top/bottom。
- Mania 參照稽核 98 checked／0 resolved／98 missing。ZIP listing 沒有 `mania/arrows` 路徑；因此這個樣本對 Mania 素材而言是不完整的。報告只保存 metadata／計數，不將第三方圖片或音效複製進專案。
- 報告：`artifacts/batch252-regression/aristia-hima-osk-audit.json`。

## 相容界線
- `skin.ini Version: latest` 僅當原始 metadata 記錄，不推論其代表某個 osu!stable 版本行為。
- `@2x` logical geometry、Normal/Hover pair、RGB multiply、明確 RGBA edge-repeat 都有各自 AMQ contracts/tests；不等於完整原生 osu! compositor。
- `nativeStableFidelity` 對 multiplicative tint、songselect-top edge-repeat 仍為 false；Canvas renderer 仍明確 false。
- 不宣稱完整動畫家族、所有版本幾何或原生 tint 行為已支援。

## 測試
- Focused Skin/OSK/geometry/pixel/renderer tests：36/36 PASS。
- 新增 `tests/skin-compatibility-audit.contract.test.cjs`：保護真實 OSK audit report 與 native-fidelity 限制。
- 全量 Node、Architecture、syntax、Python compile 與 browser suite 結果於最終交付前另行記錄；focused 36/36 不代替全量。

## 未解／下一步
- 98 個 Mania references 缺失是素材缺件或參照不匹配；沒有原始對應素材可進一步證明，不擅自合成資產。
- 35 wired roles 尚未逐一 browser apply/fallback/reset；13 unsupported roles 繼續維持 unsupported。
- HTTP-origin IndexedDB、live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0、native osu!stable compositor fidelity 仍未驗收。
- 下一批 Batch253：做最後缺口盤點與交付候選判定，核對所有待辦狀態與外部 gate，避免將阻塞項目算作結案。

## 交付封包
- `AMQ_Full_Rebuild_Batch252_Skin_Fidelity_20261029.zip`，SHA-256 `a090ef6490b2128f5370a9c9f0fb5a159ab3283b234422a8588ecd1cd6c87408`。
- `MANIFEST.sha256` 6,780 entries；manifest self-check 排除本身，完整逐項 hash check 通過；ZIP CRC 通過，ZIP 內 Manifest 與工作副本一致。
- AMQ raw data SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ raw data SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，未變。
