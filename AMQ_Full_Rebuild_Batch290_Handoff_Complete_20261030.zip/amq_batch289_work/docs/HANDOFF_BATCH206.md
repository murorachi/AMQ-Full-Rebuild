# Batch206 交接：逐頁 Wiki 追溯與首頁／導覽語義修正

## 基準與工作副本
- 基準封包：`AMQ_Full_Rebuild_Batch205_Wiki_Traceability_20261028.zip`。
- 開工前 SHA-256：`de0b58afb4e79b6f7801ce9a3e464de460b91c18100cb922e66cfa4d6fd994cf`，與交接紀錄相符。
- 新工作副本：`/mnt/data/amq_batch206_work/project`。原 Batch205 ZIP 與既有工作目錄未覆蓋。
- 無 `.git` metadata，未初始化 Git。

## 本批實作
- 新增 `docs/OSU_STABLE_WIKI_TRACEABILITY_BATCH206.md`，將首頁、選歌、猜歌、學習中心、設定的 Wiki 語義、AMQ 正式 DOM、extension slots、取捨及驗收狀態列成矩陣。
- `src/ui/app-shell.js` 首頁明確標記 `AMQ ADAPTATION · osu!stable-inspired`，並說明圓形主選單是 AMQ 自訂導覽，不是 stable 原生元件。
- 導覽 `aria-current` 僅在作用中頁面設定 `page`，其他按鈕移除該屬性，不再設定字串 `false`。
- `tests/app-shell.browser.test.py` 增加首頁自訂語義與作用中導覽狀態回歸。
- 更新主清單、工作狀態與下一批提示。

## 驗證結果
- `python tests/app-shell.browser.test.py`：54/54 PASS，正式 `src/index.html` 內嵌本機 CSS/JS 後以 Chromium `set_content` 測試；五頁導覽、桌面／手機布局與無水平溢位檢查通過。
- `node --test tests/skin-contract-manifest.test.cjs tests/skin-theme-adapter.test.cjs tests/catalog-filter-layout.contract.test.cjs tests/free-player-visual-contract.test.cjs`：33/33 PASS（free player visual contract 包含 21 assertions）。
- `node tools/check-architecture.cjs`：1,123 PASS／0 FAIL。
- 這批修改的 JS 由 Chromium 測試實際載入執行；本批沒有修改曲庫資料資產或音訊引擎。

## 尚未驗收／阻塞
- `set_content` 是 opaque origin，不能作為 HTTP-origin IndexedDB 保存／重新載入證據。
- 真實 `.osk`、使用者真實曲庫／封面／可聽音訊、HTTP-origin IndexedDB、完整真實桌面／手機驗收未完成。
- Candidate302 與 Candidate382 Stage 0 原始檔缺席，未宣稱相容性通過。
- 本批只完成首頁語義標註、導覽 accessibility 修正與逐頁追溯文件，不宣稱五頁 UI 全面完工。

## 下一批 Batch207
1. 優先完成 Catalog 鍵盤 ArrowUp／ArrowDown／Enter 與篩選後清空選取的正式 DOM 行為測試，確保選取狀態和詳情不會脫節。
2. 對 Quiz 的開始／答題／揭曉／回合完成各狀態補完整 UI traceability 與測試，不將 osu! ranking 圖直接套用到正誤狀態。
3. 對 Learning 與 Settings 核對空狀態、錯誤狀態、焦點與手機觸控；只修可重現缺口。
4. 延續真實 `.osk`／HTTP-origin 阻塞記錄，但不要因此停止其他可驗證工作。
