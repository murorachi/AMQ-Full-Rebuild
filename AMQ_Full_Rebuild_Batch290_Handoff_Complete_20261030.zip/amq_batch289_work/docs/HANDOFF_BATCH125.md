# AMQ 新版重建交接：Batch125（音訊診斷來源遮罩）

日期：2026-10-28。沿用 Batch124 工作副本；無 `.git` metadata，未初始化／commit／push。

## 修改
- `src/ui/quiz-panel.js` 新增 `safeAudioSourceLabel()`。完整 HTTP(S) URL 只顯示 host；遮罩 path、query、fragment、userinfo。非 URL source 清除控制字元、query／fragment，並限制長度。
- `tests/quiz-panel.test.cjs` 新增帶 query token 的 URL 候選失敗，驗證診斷保留 host／format／原因但不顯示路徑或 token。
- 答案建議盤點：`src/ui/answer-suggestions.js` 與 `src/index.html` 已接線，單答案／全答案欄位均有 listbox；ArrowDown／ArrowUp、Enter 選取不提交、Escape、IME composition、pointerdown 防 blur、穩定 option node 與 dispose 已有 15 項測試，本批不重寫。

## 驗證
- Targeted `node --test tests/quiz-panel.test.cjs tests/answer-suggestions.test.cjs tests/audio-service.test.cjs`：3/3 files PASS；suggestion tests 15/15。
- 57/57 非-tooling test scripts 逐檔通過，分四組執行。
- Tooling 13/13 PASS；architecture 893 passed／0 failed。
- Source audit／full mapper／5-run benchmark PASS；Catalog 55,660 records，build 約 1,218.086 ms（僅 Node 本機觀測值）。
- Source SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 限制
- 真實瀏覽器音訊／CORS／multi-client E2E 仍未驗收；已知瀏覽器路徑 `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試。
- 本批未改 CSS，也未重寫已完成的 suggestion controller。

## 下一步
Batch126：盤點 Remote SRS retry 的 durable queue／跨 reload 缺口，先確立安全的 revision／idempotency contract。
