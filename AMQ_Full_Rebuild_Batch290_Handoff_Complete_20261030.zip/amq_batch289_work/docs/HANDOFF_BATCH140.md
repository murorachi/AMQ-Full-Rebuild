# AMQ 新版重建交接：Batch140（舊 schema optional table inventory）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 維持唯讀。

## 實作
- `server/database-integrity.cjs` 新增 `missingOptionalTables`，揭露缺少的 `srs_assessment_events`、`multiplayer_rooms`、`multiplayer_commands`。
- `tools/inspect-private-server-database.cjs`、`tools/backup-private-server.cjs`、`tools/verify-private-server-backup.cjs` 輸出 optional history table 缺漏。舊 schema 仍可通過 core integrity，但不會被誤認為完整新版 schema。
- `tests/database-integrity.test.cjs` 新增 legacy schema test；確認唯讀檢查不自動 migration，且列出缺少的 optional tables。
- SRS event replay／conflict 行為已由既有 `tests/multiplayer-http.integration.test.cjs` 覆蓋：相同事件不重複更新 revision，不同 grade 以 conflict 拒絕。未發現需重寫的 production defect。

## Targeted 驗證
- `node --test tests/database-integrity.test.cjs tests/private-server-backup.test.cjs tests/multiplayer-http.integration.test.cjs`：8/8 PASS。
- 完整回歸與最終封包結果以 `docs/WORK_STATUS.md` Batch140 收尾段落為準。

## 限制／下一步
- core integrity PASS 不等於所有 optional/new history tables 都存在；現在會明確列出缺漏，不自動修復。
- Batch141：跨工具 SQLite diagnostics 一致性 fixture，維持 read-only，不新增 migration／清理／live restore。
