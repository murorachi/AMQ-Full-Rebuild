# Batch240 Handoff：Renderer 正式接線、State Pair 與四頁 Traceability

## 基準與安全
- 唯讀來源：`/mnt/data/AMQ_Full_Rebuild_Batch239_Quiz_Results_Renderer_20261029.zip`
- 來源 SHA-256：`3d7c9b8a0ee61ae1be0ee70ba3bde993b2c92985a005a2917c207da93f09a5f4`
- 工作副本：`/mnt/data/amq_batch240_work`
- 未初始化 Git；沒有 `.git`，也沒有覆蓋 Batch239 ZIP。
- AMQ／EMQ 原始資產未修改：`data.js` SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 本批實作
- `src/ui/skin-import-panel.js`：Mapping Studio 正式預覽使用 `skinRenderer.fitStyle()`、`logicalSize()` 與 `resolveStatePair()`。`@2x` raster 尺寸與 logical 尺寸分別寫入預覽 metadata；state pair 預覽並排顯示 Normal／Hover，缺件明確顯示 AMQ fallback。
- `app.navigation.back` 加入明確 Normal／Hover、fit、position 控制；完整配對才會套用。缺少任一狀態時整組不套用，避免只用 hover 當正常狀態或借用不相關圖片。正式 CSS 消費端為 `#app-back:hover`／`:focus-visible`，仍保留原本按鈕 hit-area 與鍵盤焦點。
- `src/skins/theme-adapter.js`：state pair 同時驗證、解碼兩張圖，套用 normal／hover CSS variables，reset 時清除全部 pair token。無效／缺件 pair 使用 AMQ 原生樣式 fallback。
- `src/persistence/skin-theme-store.js`：IndexedDB theme schema 升至 v4，向前接受 v1/v2/v3 並遷移；新增 `roleStateMappings` 驗證、保存及重載。
- `src/skins/theme-transfer.js`：portable bundle 保持 format v1，新增 `roleStateMappings` 匯出／匯入 round-trip 與 path allowlist 驗證，接受舊 schema 1/2/3 與目前 schema 4 的內部 theme record。
- `src/styles/ui-shell.css`：為返回按鈕加入 hover/focus-visible 狀態圖片 consumer，Mapping Studio pair controls 有桌面／手機版式。
- `docs/AMQ_VISUAL_NEEDS_TRACEABILITY_BATCH240.md`：列出 Home、Catalog、Quiz、Results 與共用視覺角色的 selector、CSS token consumer、幾何、fallback 及 native semantic 限制。35 個 runtime role inventory 與 manifest/test 預期已同步。
- `tests/osk-import-panel.browser.test.py`：加入 `@2x` logical-size 實際預覽、Normal/Hover 配對、缺件 fallback、桌面／手機畫面證據。

## 驗證結果
- 全部 `tests/*.test.cjs`：**86/86 檔案個別執行成功，245 個測試案例，0 failures**。逐檔 log 與摘要在 `artifacts/batch240-regression/node-suite-summary.*`。
- Focused Skin／visual contract：**58/58 PASS**，涵蓋 renderer、theme schema、transfer、adapter、manifest、visual needs、CSS contract。
- Chromium Mapping Studio：**30/30 assertions PASS**，含 `@2x` 2×2 raster → 1×1 logical size、明確 pair 預覽、缺 hover fallback、回復完整 pair、桌面／手機欄數、匯入／套用／匯出流程。截圖：`skin-mapping-desktop.png`、`skin-mapping-mobile.png`。
- Chromium Batch238 Home/Catalog：**19/19 PASS**；Batch239 Quiz/Results：**19/19 PASS**；formal app-shell：**150/150 PASS**。均測 1440px 桌面與 390px 手機、無頁面水平溢位／未捕捉錯誤。
- Architecture Checker：**1,228 PASS／0 FAIL**。
- JS/CJS syntax：**185/185 PASS**；Python browser harness `py_compile`：**5/5 PASS**。
- 原始 AMQ／EMQ asset hashes 未變。`MANIFEST.sha256` 已驗證 5,478 個檔案、0 failures；完整 Batch240 ZIP 已生成並通過 `unzip -t`。交付檔案：`AMQ_Full_Rebuild_Batch240_Skin_Renderer_State_Pairs_20261029.zip`。

## 明確阻塞與未驗證
- 以 `127.0.0.1` 與 `localhost` 各嘗試一次 HTTP-origin harness，Chromium 都因 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻止 loopback navigation；真實 HTTP-origin IndexedDB save/reload 沒有執行。證據：`artifacts/batch240-regression/http-origin-blocker.txt`。opaque-origin fixture 不作為持久化驗收。
- formal app-shell 初始 144/150 的六項問題已在本批修正／更新驗收契約：答案欄恢復一致深色 palette 與 4px radius，history/SRS radius 與結果空狀態／答題舞台高度斷言對齊實際設計。最終 150/150 PASS，log `app-shell-browser-final.log`；唯讀 Batch239 baseline 失敗紀錄留在 `app-shell-browser-baseline-check.log`。
- native multiplicative tint/blend、`songselect-top` 邊緣像素延展、動畫序列、自動 state-pair discovery、完整 osu!stable compositor 仍 unsupported。
- `app.navigation.options`、`settings.entry` 可編輯並保存 state pair，但目前沒有核實的 runtime target，仍標 unsupported。
- live catalog/artwork/audio、真實 HTTP-origin 曲庫、使用者裝置及 Candidate302／Candidate382 Stage 0 相容性未驗收。

## 下一批 Batch241
1. 在真實允許的 HTTP origin 驗收 state pair save/reload；取得可達 origin 前維持阻塞，不重複假測。
2. 逐一把 Home/Catalog/Quiz/Results 的 25 個視覺角色按 DOM、CSS consumer、幾何與 fallback 驗收；只在完整接線後才標 supported。
3. 以獨立模組實作 native blend/tint 或 edge-repeat 之前，先建立可測試的 renderer contract 與 licensed fixture；不把現有 repeat-x 預覽稱為原生 edge-repeat。
4. 追蹤 `app.navigation.options`／`settings.entry` 的真實 runtime target；無 target 就保持 unsupported。
5. 保留同一份 `MASTER_CHECKLIST.md`、`WORK_STATUS.md`、handoff、next prompt、manifest 與完整 ZIP，繼續 UI 主線，不擴大成無止境重構。
