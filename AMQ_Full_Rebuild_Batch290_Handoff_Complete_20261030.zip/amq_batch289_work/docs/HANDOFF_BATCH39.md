# Batch 39 交接：AMQ／EMQ／MIX 規則與音訊生命週期

## 結論
完成 AMQ／EMQ／MIX 已實作規則核對，並修正 AudioService 兩個有測試證據的生命週期問題。未進行視覺改版，也未改動來源資產。

## 修正
1. `src/audio/audio-service.js`：autoplay media 發出 `canplay` 時只表示 ready，不表示播放成功。先前無條件清除 timeout，若之後永遠沒有 `playing` 事件，候選會永久停在 ready，備援不會啟動。現在 autoplay 保留 deadline，timeout 後釋放 media 並試下一個候選。
2. 手動播放模式在 `canplay` 後仍可等待使用者操作；呼叫 `resume()` 時重新啟動候選 deadline。
3. 暫停後忽略遲到的 `playing` 事件，避免服務狀態被錯誤改回 playing。resume 重設等待狀態，仍以真正的 `playing` 事件作成功訊號。
4. `tests/audio-service.test.cjs` 新增 canplay stall primary→backup fallback 測試，以及 pause 後 late-playing 不撤銷 paused 的測試。

## 規則核對
- AMQ 候選順序：參考 HTML 靜態線索所示的三個 audio host；影片音軌欄位不混入 quiz candidates。
- EMQ 候選順序：Catbox self-host URL 先產生 Catbox mirror，再保留原 URL，依 URL 去重。
- MIX：兩來源皆有未出題候選時 AMQ 2/3、EMQ 1/3；來源耗盡時 fallback 到仍有候選的一方；身份維持 source + typed ID。
- 尚未移植舊版 AMQ-specific filter suppression（watchlist／watch status／season／anime type／difficulty／hard pool）。新版沒有相應控制，本批不新增猜測性 UI，也不宣稱完整相容。

## 修改檔案
- `src/audio/audio-service.js`
- `tests/audio-service.test.cjs`
- `docs/ARCHITECTURE.md`
- `docs/DATA_CONTRACT.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH39.md`
- `AI_START_HERE.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `MANIFEST.sha256`

## 驗證結果
- 21/21 `tests/*.test.cjs` scripts exit 0。
- `tests/audio-service.test.cjs`：12 個情境 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：415 passed／0 failed。
- Source audit：AMQ 38,821、EMQ 16,839；duplicate IDs／dangling work references 均為 0。
- Mapper verifier：PASS；Catalog 55,660，AMQ 有 audio candidates 37,939，EMQ 16,839。
- Catalog benchmark：5 次迭代 PASS。
- `src/`、`tests/`、`tools/` 全部 JS/CJS `node --check` PASS。
- 來源 SHA-256 未變：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 日誌：`/mnt/data/amq_batch39_logs/`。

## 阻塞與未驗證項目
- 真實瀏覽器 E2E 仍因先前 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋頁面導覽；本批沒有重試同一方式。
- 真實音源可聽性、跨域行為與真實瀏覽器 media event 時序未驗收。Mock media 測試只證明服務狀態契約。
- Candidate381 靜態參考不證明 Candidate302 或 Candidate382 Stage 0 相容。
- 工作副本無 `.git` metadata，未初始化 Git、未 commit／push。

## 下一批 Batch 40
1. 依 `FUNCTION_INVENTORY.md` 與 `ACCEPTANCE.md` 完成必要功能真相表。
2. 核對熟悉度、歷史、SRS、黑名單與設定的保存／恢復、來源隔離、錯誤原子性與舊 key 保護。
3. 對有證據的缺陷直接修復並加入測試；執行完整回歸。
4. UI／CSS 大重構仍排在階段 5。
