# AMQ OSK Theme Persistence Batch150

這是新版 AMQ 工作副本的增量變更包，不是完整獨立專案。請先備份同名檔案，再依相對路徑合併；不可覆蓋 Candidate302、Candidate382 Stage 0 或 AMQ／EMQ 原始曲庫資產。

## 內容
- `src/persistence/skin-theme-store.js`：版本化 IndexedDB Theme schema、Blob 保存、角色映射驗證、load/save/clear。
- `src/ui/skin-import-panel.js`：匯入保存、套用後保存 mapping、啟動還原與清除。
- `src/index.html`、`tests/tests.html`、`tools/check-architecture.cjs`：script 載入順序與架構檢查。
- `tests/skin-theme-store.test.cjs`：schema、restore、mapping/size guard、IndexedDB unavailable 測試。
- `tests/osk-import-panel.browser.test.py`：OSK 匯入 UI 操作測試。
- `AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/HANDOFF_BATCH150.md`、`docs/NEXT_SESSION_PROMPT.md`：持續進度與交接。

## 驗證狀態
- Theme store：4/4 PASS。
- OSK importer：6/6 PASS。
- Chromium panel：9/9 UI assertions PASS，但 opaque origin 不允許 IndexedDB，因此不代表真實瀏覽器持久化驗收。
- Architecture：961 PASS／0 FAIL。
- 多組 core、data、audio、quiz、persistence tests PASS，具體命令與結果見 `docs/WORK_STATUS.md` Batch150。
- 全量 Node 測試尚未完成；真實 `.osk` 尚未下載，因執行環境無法解析 github.com。
