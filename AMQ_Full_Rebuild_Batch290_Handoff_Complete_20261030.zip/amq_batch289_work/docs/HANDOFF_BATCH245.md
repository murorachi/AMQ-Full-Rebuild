# Batch245 交接：Visual-role 自動稽核

## 基準與安全
- 唯讀基準：`/mnt/data/AMQ_Full_Rebuild_Batch244_Renderer_Boundary_Safety_20261029.zip`，SHA-256 `c050330cdeedf12224cae8239b5b5cd350dc50fcd750da11f1e35a456e27fc55`。ZIP CRC 通過。
- 獨立工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch245/work`。無 Git repository，未初始化；原始 ZIP 與 AMQ／EMQ 資料未修改。

## 本批修改
- 新增 `tools/audit-visual-role-coverage.cjs`，讀取 visual-needs manifest、role manifest、theme adapter、`src/styles/**/*.css`、HTML 與相關測試檔，產生 `artifacts/batch245-regression/visual-role-audit.json` 與 `.md`。
- 新增 `tests/visual-role-audit.test.cjs`，驗證 48 個 role 全數有報告、已知 13 個 unsupported role 不會被誤標為 wired、CSS consumer 與 test evidence 分開列出。
- 沒有改動 `theme-adapter.js` runtime role map，因沒有新角色同時具備經核實的語義 target、CSS consumer、狀態／幾何、fallback/reset 與逐角色 browser evidence；避免為了增加支援數而亂接。

## 驗證
- Visual needs + role manifest + audit：19/19 PASS；Skin adapter/store/transfer focused：52/52 PASS。
- 全量 Node：90/90 `*.test.cjs` 檔案 exit 0，271 cases，0 failures；摘要 `artifacts/batch245-regression/node-suite-summary.txt`。
- Mapping Studio Chromium：30/30；Home/Catalog：19/19；Quiz/Results：19/19；Canvas：15/15；formal app-shell：150/150。
- Architecture Checker：1,279 PASS／0 FAIL；Python harness compile：11/11。
- 自動稽核摘要：48 roles、35 runtime selector／CSS consumer、13 unsupported、31 個 role 有直接測試檔線索；33 個 role 有至少一項 gap。這是靜態盤點，不代表逐角色 browser 驗收。

## 未解與阻塞
- 13 個角色仍 unsupported，原因與解除條件列於 audit Markdown；特別是作品封面不能用 OSK 角色圖代替。
- 35 個已接線角色尚未逐一證明 apply/fallback/reset；靜態 token 命中不能代替視覺驗收。
- HTTP-origin IndexedDB、真實音訊/live artwork、Windows／實機、Candidate302／Candidate382 Stage 0 與 native osu!stable fidelity 仍未驗收。
- 本次全量 Node shell 曾遇到總時限中止；已續跑缺少的單檔並彙總逐檔 TAP log，最終 90/90 exit 0。

## 下一批 Batch246
1. 先核對 audit 報告，再把 Mapping Studio state-pair 選取／預覽／套用／匯入匯出／fallback／reset 的實際流程補成端到端 regression。
2. 檢查 fit／position 與 @2x logical size 在儲存、匯出、匯入、重載之間是否 round-trip，禁止只測 UI 顯示。
3. 逐角色挑出已有真實語義 DOM/CSS consumer 的少量角色，補 apply/fallback/reset browser tests；不要一次接線全部角色。
4. 續做 Home/Catalog 的 error/retry、keyboard/focus、390px/reduced-motion，保留真實 artwork adapter 語義。
5. 不重試已知被 Chromium policy 阻擋的 HTTP-origin IndexedDB 探測；更新主清單、狀態、traceability、handoff、next prompt、manifest 與 ZIP。
