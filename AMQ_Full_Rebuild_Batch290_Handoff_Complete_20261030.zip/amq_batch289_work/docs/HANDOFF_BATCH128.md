# AMQ 新版重建交接：Batch128（音訊失敗評級保護／清單校正）

日期：2026-10-28。沿用 Batch127 工作副本；無 `.git` metadata，未初始化／commit／push。

## 修改
- `src/ui/quiz-panel.js`：automatic SRS assessment 新增 `audioStatus !== "failed"` guard。播放開始後所有候選失敗，即使 result 仍帶 elapsedSeconds，也不得自動建立／評級 SRS 卡片。
- `tests/quiz-panel.test.cjs`：全候選失敗後啟用 SRS 並提交答案，確認 SRS 卡片未被自動建立；普通答題／熟悉度仍照常運作。
- `docs/MASTER_CHECKLIST.md`：依後續 Batch72–75／901–917 實作證據校正過期的 AMQ-839–848／869–898 unchecked duplicate；保留 AMQ-849／899／900 的部分完成狀態，因真實瀏覽器／使用者驗收仍待處理。
- 盤點 personal library store：custom list CRUD、source-aware membership、watch status、storage-event refresh 與 malformed payload quarantine 已實作並有 10 組測試，不重做。

## Targeted 驗證
- `node tests/quiz-panel.test.cjs`：PASS。
- `tests/personal-library-store.test.cjs`：10/10 scenarios PASS。
- 全量回歸、tooling、architecture、source audit／mapper／benchmark 與 ZIP 最終驗證於本批收尾完成後記錄。

## 限制
- 本批只保護 SRS 資料，不修真實音源供應商／CORS 根因。
- 真實 browser／audio E2E 仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞。

## 下一步
Batch129：從剩餘未完成清單選擇可由現有 Node 工具獨立實作／驗證的核心缺口。
