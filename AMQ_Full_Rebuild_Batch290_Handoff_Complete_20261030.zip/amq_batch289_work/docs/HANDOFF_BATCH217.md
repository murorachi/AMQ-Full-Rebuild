# Batch217 交接：Catalog 焦點／觸控與多人忙碌狀態

日期：2026-10-29
工作副本：`/mnt/data/amq_batch216_work/project`（由 Batch216 工作樹直接延續；Batch216 交付 ZIP 保持不變）
來源交付：`AMQ_Full_Rebuild_Batch216_SourceAware_Learning_UI_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch217_Catalog_Keyboard_Multiplayer_UI_20261029.zip`

## 本批實作

- `src/ui/catalog-browser.js`：在列表重繪前記錄目前聚焦歌曲列的 source-aware record key。若該記錄仍在目前篩選結果中，重繪後恢復焦點到相同列；若篩選將其移除，焦點回到搜尋輸入，避免焦點掉回文件或失去鍵盤位置。保留原有 `ArrowUp`／`ArrowDown`／`Enter` selection owner，不觸發播放、不改曲庫資料。
- `src/styles/ui-shell.css`：Catalog 歌曲列設定 `height:44px` 作為實用觸控最小高度；文字換行時列可自然增高。保留既有三欄桌面布局與手機水平捲動。
- `src/ui/multiplayer-panel.js`：多人根節點以 `aria-busy` 暴露操作忙碌狀態；操作中狀態 badge 顯示「操作處理中」，完成後依 server session snapshot 還原狀態。離線仍以既有 `role=alert` 錯誤提示顯示，成功 snapshot 清除舊錯誤。未改 server-authoritative state owner 或 AudioService owner。
- `tests/catalog-browser.integration.test.cjs`：驗證篩選後仍存在的歌曲列恢復焦點、篩選掉焦點列時焦點回到搜尋。
- `tests/catalog-filter-layout.contract.test.cjs`：新增 44px touch target 與 focus restore contract，12/12 PASS。
- `tests/app-shell.browser.test.py`：正式 shell 92/92 PASS，新增真實 Chromium fixture 中歌曲列高度檢查，輸出位於 `artifacts/batch217-regression/`。
- `tests/multiplayer-panel.integration.test.cjs`：驗證 `aria-busy=false` 穩定狀態、離線 live error、恢復連線後清除錯誤。

## 驗證

- 全部 77 個 `tests/*.test.cjs`：逐檔 exit 0，`artifacts/batch217-regression/node-tests/summary.tsv`；因整體命令時間上限在兩個較慢測試前中止，將 `quiz-pool.test.cjs` 與 `tooling.test.cjs` 個別重跑，最終 77/77 PASS。
- Chromium formal shell：92/92 PASS；無 uncaught browser exceptions，390px 手機無頁面水平溢位。
- `node tools/check-architecture.cjs`：1,137 PASS／0 FAIL。
- 172 JS/CJS `node --check` PASS；3 個 Python browser tests `py_compile` PASS。
- `tests/quiz-panel.test.cjs`、`tests/quiz-history-store.test.cjs`、Catalog integration、multiplayer integration 均 PASS；AMQ／EMQ 靜態資料 hash 未變。

## 限制

- HTTP-origin persistence test 未重跑，因 Chromium loopback `ERR_BLOCKED_BY_ADMINISTRATOR` 的環境條件沒有改變；真實 HTTP-origin save/reload assertions 仍未執行。
- 真實曲庫／外部 artwork API／音訊／`.osk`、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收仍未完成。
- 無 `.git`，未初始化；正式基準原始檔缺席，不宣稱相容。全球排行榜沒有可信 backend owner，不造 PP／排名／PB。
- UI 主線仍未結案。

## 下一批優先

1. 結果頁使用 persisted round marker 與 round-scoped records 做重載／新回合／保存失敗整合回歸，保持不跨回合混資料。
2. Catalog 鍵盤焦點在分頁、排序、模式切換與 loading／failed 期間的回歸；確認 touch target 不造成手機 overflow。
3. 多人頁加入可控延遲命令的 busy-state integration，驗證命令期間 disabled／aria-busy、成功與失敗後恢復。
4. OSK 剩餘 13 roles 只有在有真實語義 target／CSS consumer 時才解除 unsupported。
5. HTTP-origin 測試只有在瀏覽器 policy／origin 改變後重跑。
