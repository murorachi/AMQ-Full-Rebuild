# osu! 原始碼研究紀錄（Batch271）

更新日期：2026-10-30  
輸入來源：使用者上傳的 `/mnt/data/osu-master.zip`；交付包內保留於 `references/osu-master.zip`  
來源 SHA-256：`973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`  
ZIP 項目數：6,270  
資料夾頂層標籤：`osu-master/`  
Git commit：ZIP 本身沒有提供可驗證的 commit hash；不得自行推測。

## 1. 結論摘要

1. 已收到並成功讀取官方 osu! GitHub 原始碼 ZIP，不需要使用者重新下載。
2. 這份原始碼主要是 osu!lazer / 當前開源客戶端程式碼，不是可直接視為 osu!stable 完整舊版客戶端的原始碼。
3. 原始碼中存在 Stable / Legacy Skin 相容機制，包括 `LegacySkin`、`LegacySkinDecoder`、`DefaultLegacySkin`、`SkinManager` 和測試；可以研究舊版 `.osk` 資產命名、設定解析、資源回退及部分舊版座標相容。
4. `osu.Game/Screens/Menu/MainMenuButton.cs` 明確實作斜切按鈕、hover 展開、elastic easing、hover overlay 等細節，是參考圖中主選單按鈕行為的重要技術參考。
5. `osu.Game/Screens/Select/SongSelect.cs` 與 `BeatmapCarousel.cs` 提供目前開源選歌頁的背景、輪播、選取、分組、排序及輸入處理線索；不能直接等同 Stable 截圖中的舊版布局。
6. `osu.Game/Overlays/Mods/ModSelectOverlay.cs` 可研究 Mod overlay 的選取與互斥處理，但其視覺與行為屬 lazer，不能直接當成 Stable 截圖的像素規格。
7. 在此 ZIP 內沒有找到可直接匯出為 Stable 預設 Skin 的完整 `Skins/Legacy` 資產目錄。`DefaultLegacySkin` 是透過 `NamespacedResourceStore(resources.Resources, "Skins/Legacy")` 讀取資源；這份壓縮包不能因此被宣稱包含可完整還原 Stable 預設 UI 的所有二進位素材。
8. 因此後續採「截圖作為 Stable 視覺驗收規格，原始碼作為互動與 Skin 相容架構參考」的雙來源策略。不得用 lazer 畫面取代 Stable 參考圖。

## 2. 已確認的檔案與責任

| 檔案 | 實際觀察 | 對 AMQ 的用途 | 限制 |
|---|---|---|---|
| `osu.Game/Screens/Menu/MainMenu.cs` | 建立主選單畫面、預設背景、按鈕系統及背景明暗轉換 | 研究畫面狀態、背景調暗、選單進出 | 是 lazer 的 MainMenu，不是 Stable 原始畫面實作 |
| `osu.Game/Screens/Menu/MainMenuButton.cs` | `background`、`backgroundContent`、`boxHoverLayer`、`SpriteIcon` 分層；背景使用 shear；hover 將寬度擴至初始寬度 1.5 倍，約 500ms `OutElastic`；按下 overlay 以約 1000ms `OutQuint` 淡入／淡出 | 將按鈕拆成底板、背景內容、hover 層、圖示與文字；設計可替換元件和狀態 | 這些是可借鑑的互動線索，不代表參考圖每個數值都相同 |
| `osu.Game/Screens/Select/SongSelect.cs` | 有 `BeatmapCarousel`、左側互動容器、右側水平漸層背景、背景 blur/dim 更新、selection 與鍵盤處理 | 研究選歌列表與背景分層、選取狀態及鍵盤操作 | lazer 的現行布局與使用者提供的 Stable 截圖不完全相同 |
| `osu.Game/Graphics/Carousel/Carousel.cs`、`CarouselItem.cs`、`osu.Game/Screens/Select/BeatmapCarousel.cs` | 輪播容器、項目、分組／排序／匹配 filter 的程式分散於多個檔案 | 研究列表項目狀態、分組與排序的責任分界 | AMQ 應保留既有 Catalog controller / query owner，不直接移植整個資料模型 |
| `osu.Game/Skinning/SkinManager.cs` | `GetDrawableComponent`、`GetTexture`、`GetSample`、`GetConfig` 都透過 `lookupWithFallback`；Legacy Skin 有回退到預設 classic skin 的路徑 | 研究單一 resolver 與明確 fallback chain | AMQ 自己的 resolver 順序仍需由產品規格決定並測試 |
| `osu.Game/Skinning/DefaultLegacySkin.cs` | 使用 `NamespacedResourceStore(..., "Skins/Legacy")`，設定 legacy version `2.7` 及預設設定 | 確認預設 Legacy Skin 透過程式資源 provider 建立，而不是必然可匯出的 `.osk` | ZIP 中沒有可直接取用的完整預設 Skin 匯出包 |
| `osu.Game/Skinning/LegacySkin.cs` | 註明 Legacy 座標以 480 高度為基礎，轉換到 768 的比例常數 `1.6f`；自訂 Legacy texture loader；處理 legacy texture lookup 與音效 fallback | 建立 Stable OSK 資產映射、@2x 尺寸、資源回退的研究依據 | 不應將 osu! 的 480→768 規則直接套用到 AMQ CSS viewport；只對應到 OSK 元件座標時才使用 |
| `osu.Game/Skinning/LegacySkinDecoder.cs` | 解析 legacy skin 設定與版本欄位 | 研究 `skin.ini` 設定解析、版本預設與舊版相容 | 不是 OSK ZIP 安全性政策的完整替代品 |
| `osu.Game/Database/LegacySkinExporter.cs` | 原始碼中存在 Legacy Skin 匯出相關類別 | 研究官方 exporter 的用途與適用對象 | 不代表 Stable 預設 Skin 一定能從該工具匯出；不能推翻使用者對預設 Skin 不可匯出的事實 |
| `osu.Game/Overlays/Mods/ModSelectOverlay.cs` | `ShearedOverlayContainer`、Mod column、selection update、設定 reset 等邏輯 | 研究分類式 Mod overlay、選取及重設互動 | AMQ 只實作已定義的 AMQ Mods；不可複製 osu! 的倍率或規則 |
| `osu.Game.Tests/Skins/LegacySkinDecoderTest.cs`、`ImportSkinTest.cs` | 有 Legacy 設定解析及 Skin 匯入測試 | 後續研究測試案例與錯誤情況 | 需要進一步逐測試分析，尚未宣稱完成全部 parser 安全稽核 |

## 3. 針對使用者五張 Stable 截圖的設計推導

### A. Main Menu
- 以圖片為主的全畫面背景。
- 巨型圓形 Logo／主視覺位於中央偏左，白色外圈與粉紅色內部。
- 右側四條縱向主選單列，紫色、斜切端點、白色文字及右側圖示。
- 主視覺與選單有重疊關係，不是互不相干的兩欄卡片。
- 按鈕至少拆為背景底板、圖示、文字、hover/pressed overlay、互動狀態。
- 動畫應由可測試的狀態驅動，支援 reduced-motion；背景素材與 Logo 必須可分別替換。

### B. Song Select
- 作品背景是畫面重要組成，不是裝飾小圖。
- 背景應依選取作品變更，並可調暗／模糊，避免文字對比不足。
- 左側是排名與成績密集列表；右側是高密度歌曲／難度佇列。
- 選取項目必須在色彩、大小、邊框、透明度或層級上與一般列明顯不同。
- 上方保留 Group、Sort、Collections、Recently Played、By Artist、By Difficulty 等操作區。
- 底部是固定操作列，包含 Mode、Mods、Random、Beatmap Options 對應操作。
- AMQ 的作品與歌曲資料仍由正式 Catalog owner 提供，不得用測試資料混入正式列表。

### C. Multiplayer Lobby
- 頂部標題、模式分類、搜尋／篩選區、密集房間列表、玩家頭像／槽位、狀態色及底部固定操作列。
- 聊天是獨立區域，不與房間列表合併成單一卡片。
- 所有狀態顏色必須對應真實房間狀態，不得以假資料模擬 live 房間。
- 先盤點 `#multiplayer-panel` 和 server API owner，不能建立第二份 room state。

### D. Game Modifiers
- 覆蓋層置於主畫面上，背景調暗但仍可辨識。
- 頂部有倍率／摘要區；中段是按分類排列的圖示網格；底部集中 Reset 與 Close。
- 每個 Mod 有明確 on/off 狀態、圖示、名稱、說明和互斥規則。
- AMQ 候選 Mods 需先確認實際規則與 multiplier owner；不得將 osu! Easy、No-Fail、Hard Rock 等規則直接移植。

### E. Intro Screen
- 獨立的品牌視覺狀態，不等同 Home。
- 中央大 Logo、全畫面背景、放射線／粒子分層與低干擾角落資訊。
- AMQ 不必新增無功能的啟動畫面；可將可復用的分層、動畫與背景控制用於 loading／transition。

## 4. OSK 匯入對 AMQ 的架構要求

OSK 是素材來源，不是 AMQ UI 結構定義。必須先有可映射的 component registry，再解析封包中的資產。

建議資料模型：
- `componentId`：穩定、不可隨 CSS class 改名而變。
- `pageId`、`regionId`：目標頁面與區域。
- `assetType`：background / texture / icon / animation / sound / font / configuration 等。
- `supportedStates`：default / hover / active / selected / disabled / loading 等。
- `logicalSize`、`sourceScale`、`anchor`、`fitMode`：尺寸、@2x、位置與裁切。
- `defaultAsset`、`skinAssetMapping`、`pageOverride`、`componentOverride`。
- `mappingConfidence`、`mappingSource`、`needsManualMapping`。
- `fallbackAsset`、`previewMetadata`。

Resolver 必須單一且有測試。沿用專案已定義的順序：Default → Selected Skin → Page/Region Override → Component Override（若實際 override 優先權有衝突，先在架構決策文件明確決定，不得讓 CSS 偶然決定）。

匯入安全：
- 防 ZIP Slip／路徑穿越、重複路徑、超大解壓、壓縮炸彈、非預期 MIME／圖片解碼錯誤。
- 設定檔必須有 schema／size limits，未知欄位不能直接執行。
- 資產映射不能隨機猜；低信心項目進人工 mapping queue。
- Import preview 必須顯示來源檔名、尺寸、格式、目標元件、映射信心與 fallback。
- Apply／Reset／Export／Import 都要測試，且不能更動 AMQ 曲庫、答題、音訊或多人狀態。

## 5. 不可混淆的事實

- 使用者提供的五張圖是 osu!stable 預設 Skin 的截圖；不可要求使用者匯出不存在的預設 `.osk`。
- 上傳的 `osu-master.zip` 是官方開源客戶端程式碼，但 ZIP 沒有可驗證 commit hash；本研究以檔案 SHA-256 鎖定來源。
- 本次未執行 `dotnet test`，未建立可運行的 osu! 客戶端，也未聲稱原始碼完整編譯。
- 原始碼只完成定向閱讀與檔案／方法核對，不代表所有 UI、Skin、匯入安全性均已完整審計。
- 沒有從上游複製任何程式碼或素材進 AMQ；本批只記錄檔案路徑、責任與設計推導。
- 使用者提供的截圖是 Stable 視覺驗收基準；Lazer 原始碼是行為與架構參考。二者不可互相替代。
