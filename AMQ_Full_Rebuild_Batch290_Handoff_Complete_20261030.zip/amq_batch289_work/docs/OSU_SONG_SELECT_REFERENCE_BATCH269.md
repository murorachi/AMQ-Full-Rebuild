# osu! 選歌頁參考來源與 Batch269 對照規則

## 官方參考
- osu! Client / Interface： https://osu.ppy.sh/wiki/en/Client/Interface
- 官方 Wiki 的 Song selection 圖片： https://osu.ppy.sh/wiki/images/Client/Interface/img/song-selection.jpg
- osu! Skinning / Interface： https://osu.ppy.sh/wiki/en/Skinning/Interface
- 官方 Wiki 原始文件（便於追蹤更新）： https://github.com/ppy/osu-wiki/blob/master/wiki/Client/Interface/en.md

官方 Song Select 參考圖顯示的主要視覺特徵：背景 artwork 佔據大面積；歌曲／難度項目是帶色彩狀態的垂直 carousel；目前選取項目具有明確反差；排序／分組／搜尋位於列表附近；底部工具列提供模式、Mods、Random、選項等操作。AMQ 不應逐像素複製 osu!，但應沿用這種「作品圖像優先、密集可掃描的選取列表、選中狀態突出、操作靠近播放區」的層級。

## Batch269 實作範圍
- 中央曲目區改為固定可視高度的可捲動列表，不再只依六筆 fixture 的自然高度縮成一小塊。
- 桌面作品縮圖從 34×45 提升至 46×60；中等視窗 42×56；手機 38×50。保留封面 fallback，不使用假圖冒充正式 artwork。
- 選取列加強左側狀態線與標題字重；表格欄位仍保留歌手、作品、類型與來源，避免丟失 AMQ 特有資訊。
- 右側作品視覺使用 3:4 展示比例，改善方形 placeholder 的視覺誤導；真實封面仍需正式 provider 驗證。
- 最新一輪 Home／Catalog 四尺寸與獨立 error state 截圖轉為 JPEG；舊批次照片不隨交付包累積。

## 限制
- 官方參考圖以官方 Wiki URL 保存，避免未經確認的第三方副本。執行環境無法直接下載官方圖片二進位檔，因此本批保留可追蹤的官方來源連結，而不是聲稱已把參考圖片本體打包。
- Batch269 Catalog 截圖仍使用六筆明確標示的 layout fixture 與 SVG 示意封面；它們只驗證布局，不代表正式曲庫／ANN／VNDB artwork 已載入。
- 最終人工視覺 gate 仍未通過；本批是對照後的局部視覺改善。
