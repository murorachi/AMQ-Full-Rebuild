# Batch173 交接：播放 Promise 競態與持久化 failure matrix

## 1. 工作副本／基準
- 工作副本：`/mnt/data/amq_batch153_work`。
- 無 `.git` metadata；未初始化。Node v22.16.0、Python 3.13.5，71 個 Node 測試檔。
- Candidate302 是正式維護基準，Candidate382 Stage 0 是 CSS 比較基準；兩份原始檔不在副本中，未 hash 比對、未覆蓋。AMQ／EMQ 曲庫資產未修改。

## 2. 實作與測試
### AudioService late play rejection
- 修改 `src/audio/audio-service.js`：每次 `startMediaPlayback()` 增加 request-local `playAttemptId`；`pause()` 增加該 ID 使未完成的舊播放呼叫失效。`handlePlayError()` 檢查 request、candidate、attempt id、paused 與 playbackStarted。
- 修改 `tests/audio-service.test.cjs`：測試第一次 `play()` 觸發 playing 後 pause/resume，等第二個 attempt 進入 playing，再拒絕第一次的 Promise。舊 rejection 不應觸發 fallback，也不應改寫目前狀態。
- 修正前確實失敗，實際狀態從預期 `paused` 被舊 rejection 改成 `loading`；證據在 `artifacts/batch173-regression/reproduction-before-fix.log`。修正後 AudioService 20/20 PASS。

### Playback coordinator lease revoke
- 修改 `tests/quiz-session.test.cjs`：新增延遲 `audioService.play()` Promise 在 coordinator lease 被其他模式取走後才 resolve 的測試。驗證 session 保持 `finished`、訊息仍是播放權已移交、audio projection 為 stopped。
- 現有 `playbackEpoch` guard 已正確攔截遲到 completion，因此未改 QuizSession production code。

### Persistence failure matrix
- `tests/quiz-session.test.cjs` 新增熟悉度與 history adapter 同時拋錯案例：scored skip 與 timeout 都提交結果、完成題數不回滾、顯示 persistence warning、auto-next 仍推進且 round-end 正常進入 finished。
- 原有 submit、history summary partial failure、history init failure、unplayed skip/reveal 不計分等測試保留。四級熟悉度規則未變。
- QuizSession 25/25 PASS。

## 3. 全量驗證
- 71 個 `tests/*.test.cjs` 檔案逐檔獨立執行，分 9 組，9/9 組 exit 0。第 2 組、第 8 組在最終變更後重新執行。
- `node tools/check-architecture.cjs`：1,051 PASS／0 FAIL。
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS，exit 0。
- `src`／`tests`／`tools`／`server` 共 160 個 JS/CJS 檔案 `node --check` PASS。
- 詳細 log 與 summary：`artifacts/batch173-regression/`。

## 4. 未驗收／阻塞
- 真實瀏覽器音訊、ANN API／CORS／圖片、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤流程未驗收。
- Candidate302／Candidate382 Stage 0 原始檔缺席，無法對原始檔 hash 或做實際相容比對。
- Node/mock/harness 通過不代表真實瀏覽器音訊已驗收。

## 5. Batch174 建議
1. 以可控事件順序測試 AudioService timeout callback 與 `playing`／`error` 同時到達時的終止一致性，確認只 settle 一次且不會讓過期候選覆蓋新狀態。
2. 檢查 Quiz History Store summary debounce、flush、dispose、儲存失敗及部分成功回報；只修可重現的資料遺失或錯誤成功狀態。
3. 保留 `playAttemptId`、`playbackEpoch`、單一播放 owner 及四級熟悉度規則。
4. 重跑全量 71 個 Node 測試、architecture、OSK harness 與 160 個 JS/CJS 語法檢查。
