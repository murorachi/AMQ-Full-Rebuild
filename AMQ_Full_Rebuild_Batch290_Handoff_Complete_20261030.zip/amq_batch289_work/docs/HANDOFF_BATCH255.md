# Batch255 Handoff：Unsupported Skin 角色語義審查

## 本批結果
- 以 Batch254 ZIP 解壓副本為唯讀來源，建立獨立 Batch255 工作副本；工作目錄沒有 `.git`，未初始化 Git。
- 新增 `docs/BATCH255_UNSUPPORTED_ROLE_AUDIT.md`，對 13 個 unsupported roles 逐項記錄語義風險、判定與解除條件。
- 沒有為了增加 supported 數字而硬接線。`catalog.filter.background`、`catalog.action.random`、`settings.slider` 列為可接線候選，但必須先確認精確 DOM／CSS 邊界和互動 owner；其他角色依語義維持 unsupported 或 fallback。
- 新增 Batch255 專屬 route coverage 證據於 `artifacts/batch255-regression/cross-page-browser.log`。既有正式 Chromium 跨頁 harness 45/45 PASS：Home menu keyboard navigation、Catalog、Quiz、Results、Learning、Settings、ARIA、query persistence、390px overflow、Settings 44px target、0 page errors。此測試驗證 route/navigation，不宣稱所有 Skin role 已在各頁可見狀態完成視覺驗收。
- Focused Node tests：`visual-role-audit.test.cjs`、`skin-theme-adapter.test.cjs`、`app-shell-navigation.contract.test.cjs`、`skin-contract-manifest.test.cjs` 均 exit 0；額外全量 Node 逐檔批次受 120 秒工具限制中斷，92 個 log 中 91 個有明確 TAP pass、0 個失敗標記，`quiz-pool.test.cjs` 沒有終端 TAP 結果，故不宣稱全量 Node 通過。個別 log 在 `artifacts/batch255-regression/`。
- 重新產生 Batch255 靜態角色稽核至 `artifacts/batch255-regression/visual-role-audit/`，與歷史批次報告隔離。
- AMQ／EMQ raw data SHA-256 保持已知值，沒有修改原始曲庫資料。

## 重要方向決策
新版 AMQ 是獨立產品。Candidate302／Candidate382 不再是必需基準，不得把尋找舊版本列為阻塞或完成條件。依新版自己的需求、DOM/render owner、測試證據與使用者驗收推進。舊版僅在能解決明確問題時才可選擇性參考。

## 尚未完成／未宣稱
- 13 個角色本批完成語義分級，但沒有全部接線；3 個可接線候選仍需精確 target／consumer／互動測試。
- 35 wired roles 的 route-aware visible-state／互動視覺矩陣仍需擴充到每個頁面與主要狀態。
- HTTP-origin IndexedDB 仍有既有 `ERR_BLOCKED_BY_ADMINISTRATOR` gate；live audio/catalog/artwork、Windows／實機仍未驗收；native osu!stable compositor fidelity 不是新版結案必要條件，只有在產品明確要求原生級複製時才另行定義驗收。
- 本批 focused tests 與 cross-page harness 通過，不等於全量 Node／Architecture／整體產品驗收已重跑。

## 下一批
1. 對 `catalog.filter.background` 建立精確的 filter panel target／CSS token consumer／reset contract，避免套用到整個 catalog browser。
2. 對 `catalog.action.random` 確認正式 button owner、selector、disabled/loading/focus 狀態後接線並驗證事件行為。
3. 為 `settings.slider` 先建立精確 range input selector，確認 value、keyboard、focus-visible 與 touch target 不受 Skin 破壞。
4. 建立 route-aware visible-state matrix，按頁面驗證 apply／missing fallback／reset；不要把隱藏 DOM target 計入可見覆蓋。
5. 每批保護 raw data hashes，更新同一份主清單與交接，輸出完整 ZIP、Manifest、SHA-256 sidecar。
