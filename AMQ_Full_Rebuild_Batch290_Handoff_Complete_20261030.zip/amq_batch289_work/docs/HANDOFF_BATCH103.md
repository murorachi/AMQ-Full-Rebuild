# Batch 103 交接包

日期：2026-10-27

## 本批成果

- 修正 idempotency cache replay 可能回傳過時 snapshot 的問題：若 authenticated caller 仍是 room member，replay 保留原始 event／assessment，但 snapshot 會從目前 state 重新建立，避免延遲重試把 client state 回退。
- 若 caller 已離房（例如原 `player.leave` 呼叫者），replay 不會取得 fresh membership-authorized snapshot，而是保留原始 leave response snapshot。
- 新增 delayed `answer.submit` replay regression：原回合已被 timeout 關閉後重試，event／assessment 保持原始結果，snapshot 顯示目前 revision 與 closed round；不重複評級或提交。
- 新增 former-host delayed leave replay regression，確認已離房者不會取得 fresh snapshot。

## 修改檔案

- `src/multiplayer/room-command-service.js`
- `tests/multiplayer-room-command-service.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/ARCHITECTURE.md`
- `docs/ACCEPTANCE.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `docs/HANDOFF_BATCH103.md`
- `MANIFEST.sha256`

## 驗證證據
- `node tests/multiplayer-room-command-service.test.cjs`：PASS。
- `node tests/multiplayer-room-state-machine.test.cjs`：PASS。
- 非-tooling `tests/*.test.cjs`：44/44 個腳本逐檔 exit 0，日誌 `/mnt/data/amq_batch103_validation.log`。
- `node --test tests/tooling.test.cjs`：9/9 PASS。
- `node tools/check-architecture.cjs`：719 passed／0 failed。
- JavaScript／CJS syntax：100/100 PASS。
- Source audit／mapper PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；Catalog 55,660 records；cross-source ID collisions 0。
- 5 次 Catalog benchmark PASS；本機 Node build 約 1,133.959 ms，非瀏覽器效能保證。
- 來源資產 hash unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 驗收契約

- 原始 event／assessment 在 replay 中不變，不能再次提交 transition／assessment。
- 當 caller 仍是 member，replay snapshot 必須反映目前 state/revision。
- 當 caller 已離房，replay 不得提供新的 membership-authorized snapshot。
- 本批沒有接入 transport/auth、durable idempotency、跨節點 state 或 reconnect。

## 未解決／下一步

1. 檢查 `getSnapshot(sinceRevision)` 的 stale/equal/future revision 邊界。
2. 檢查 closed room snapshot 與離房後重連的 membership authorization。
3. 多人 SRS persistence 需產品決策；真實瀏覽器／音訊／storage／multi-client E2E 未驗收。
