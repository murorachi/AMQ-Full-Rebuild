# Batch254 Handoff：正式 DOM 逐角色 Skin apply／fallback／reset

## 交付封包
- ZIP：`AMQ_Full_Rebuild_Batch254_Skin_Role_Matrix_20261029.zip`。
- ZIP SHA-256 以封包旁的 `.sha256` sidecar 為準，避免在 ZIP 內記錄自我雜湊造成循環。
- Manifest 7,002 entries，封包內逐項 SHA-256 0 missing／0 mismatch；ZIP CRC 通過。

## 基準與安全
- 唯讀基準 Batch253 ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch253_Final_Audit_20261029.zip`。
- SHA-256：`0b9fc8af5e36d24b27ce580185956830c3b8cf4c49158bf74a5f9f4a4c3c75ae`；以原交付 ZIP 與 sidecar 為基準，未覆蓋原 ZIP。
- 本批工作副本由 Batch253 解壓建立，無 Git repository，未初始化 `.git`。
- AMQ／EMQ raw hashes unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 實作與測試
- 新增 `tests/batch254-skin-role-production.browser.py`：以正式 `src/index.html` inline CSS／JS 啟動 Chromium，針對 35 個 runtime role selectors 實際套用可解碼 PNG、測試 missing-asset fail-closed、reset token／dataset 與 object URL revoke。
- 正式 DOM 矩陣：35/35 target present、35/35 apply、35/35 missing fallback、35/35 reset／revoke，0 uncaught page errors。證據 `artifacts/batch254-regression/skin-role-production-dom.json`、`skin-role-production-dom.log`、`skin-role-production-dom.png`。
- 輔助 fixture matrix：`tests/batch254-skin-role-matrix.browser.py`，35/35/35 PASS。報告清楚區分 fixture evidence 與正式 DOM evidence。
- 初始 Home route 只有 4 個 target 可見，另外 31 個存在於掛載但隱藏的其他頁／狀態節點；因此這批驗收的是 adapter 在正式 DOM 的 apply/fallback/reset lifecycle，不是所有頁面／互動狀態的視覺驗收。
- Node 92/92 `tests/*.test.cjs` files 逐檔 exit 0；Architecture 1,293 PASS／0 FAIL；JS/CJS syntax 186 檔通過；Python compile 17/17；`tests/app-shell.browser.test.py` 通過。證據在 `artifacts/batch254-regression/`。

## 尚未結案
- 13 unsupported roles；逐頁 route-aware visible-state／互動視覺驗收。
- HTTP-origin IndexedDB `ERR_BLOCKED_BY_ADMINISTRATOR`；live audio/catalog/artwork；Windows／實機；Candidate302／Candidate382 Stage 0；native osu!stable compositor fidelity。
- 不得因本批 35 個 role lifecycle PASS 而將上述 gate 標記完成。

## 下一步 Batch255
1. 對 13 unsupported roles 逐一追蹤真實 DOM／render owner，只有有正確 AMQ 語義的角色才接線。
2. 為 35 wired roles 增加 route-aware visible-state coverage，覆蓋 Home、Catalog、Quiz、Multiplayer、Results、Learning、Settings 的實際可見狀態；不以隱藏節點存在代替可見驗收。
3. 持續保護 raw data hashes、主清單、Manifest、完整 ZIP 與外部 gate 狀態。
