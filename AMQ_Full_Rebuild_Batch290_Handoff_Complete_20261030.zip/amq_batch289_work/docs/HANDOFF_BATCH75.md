# Batch 75 交接：SRS selector 模擬與三模式關閉保護

## 環境／基準
- 由 Batch 74 ZIP 建立的獨立工作副本，無 `.git` metadata；未初始化 Git、未 commit／push。
- Candidate302 與 Candidate382 Stage 0 未包含於本包；未覆蓋正式基準或曲庫資產。
- Node v22.16.0、npm 10.9.2；無 package.json，使用 Node 內建測試工具。

## 本批實作
1. `tests/quiz-pool.test.cjs` 新增固定 seed 的 40,000 次抽樣模擬，涵蓋 80 張新卡、80 張未到期卡、80 張一般到期卡、80 張 grade-1 且逾期 14 天卡片。斷言抽樣占比符合 weak-overdue > due > new > future，並確認 future 卡仍有有限機率。
2. `tests/quiz-pool.test.cjs` 新增固定 seed 的 30,000 次 MIX 模擬。即使 AMQ pool 是 60 張嚴重逾期弱卡、EMQ pool 是 15 張新卡，來源比例仍須約為 2:1，證明 source roll 與來源內 SRS 權重責任分離。
3. `tests/quiz-panel.test.cjs` 擴充 SRS-off integration，AMQ／EMQ／MIX 都開始並提交普通答案，驗證兩份 SRS schedule snapshot 不變、普通答題歷史繼續增加。
4. 更新 `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md` 與 Manifest。

## 實際驗證
- `tests/*.test.cjs`：28/28 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。首次合併命令在總時限內被終止，之後獨立重跑完成；只採用獨立重跑結果。
- `node tools/check-architecture.cjs`：495 passed／0 failed。
- Source audit PASS：AMQ 38,821、EMQ 16,839；重複／懸空／跨來源 ID 衝突為 0。
- Mapper verification PASS：Catalog 55,660 筆。
- Catalog benchmark 5 iterations PASS；build 約 1122.085 ms，僅本機 Node 觀察值。
- `src/`、`tests/`、`tools/` 全部 JS/CJS syntax check PASS。
- 真實瀏覽器／音訊／Windows 乾淨環境未測；不宣稱通過。

## 未完成／阻塞
- 全量備份／還原 API 尚未實作。需先盤點各 store schema、定義版本化 envelope/checksum、restore preflight、舊 schema 相容與多 key 失敗 rollback。
- 真實瀏覽器跨分頁 storage event 仍未驗收；既有 Chromium 導覽被環境政策阻擋，不重試同一方法。
- 無 Git metadata，無可信 branch／commit／diff。

## 下一批
1. 盤點 app settings、AMQ／EMQ SRS、history、familiarity、blacklist、personal library 的 schema、公開 API 與 recovery 行為。
2. 設計並實作版本化全量備份匯出、checksum、匯入預檢及 restore rollback。
3. 測試損壞匯入不覆蓋現有資料、部分寫入失敗回滾、舊 schema 相容。
4. UI／CSS 大重構繼續延後。
