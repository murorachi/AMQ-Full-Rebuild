# osu! Stable Quiz 視覺差距（Batch285）

參考原圖：`artifacts/osu-reference/osu-intro-screen.jpg`。新版畫面：`artifacts/batch285-quiz-route-ui/quiz-1920x1080.jpg`。並排：`artifacts/batch285-quiz-route-ui/quiz-vs-osu-stable.jpg`。

| Stable 原圖特徵 | AMQ 本批狀態 | 後續工作 |
|---|---|---|
| 佔滿視窗的遊戲畫面；中心 logo／背景 artwork；高層次 overlay | 修正前 body grid 將 header/main 放在兩欄，主內容只剩右半畫面；本批已修正為單欄全寬 | 已修根因；需將同一 route-grid contract 擴到所有頁面 |
| 背景圖案有細節與中心視覺焦點 | 目前使用可被 Skin 替換的 CSS 同心環，無正式背景 artwork | 不以漸層冒充完成；需將 osu skin region／OSK mapping 用於正式舞台 |
| 狀態、操作與中心畫面形成同一遊戲 overlay | AMQ 有本輪狀態、答題舞台、答案欄與控制列，但仍是傳統表單式工作區 | 下一批整體設計 overlay 分層與控制列，而非只換配色 |
| Intro 有音訊播放狀態／上層控制 | AMQ audio state 仍由 QuizSession／AudioService 提供；本批未改 state owner | 需要真實音源／live playback gate |
| Mods 選擇為專門 overlay，有分類與 reset | AMQ canonical Mods owner 尚未確認 | 先調查唯一 registry/state/multiplier/audio owner，沒有 owner 就先建規則模組，不畫假 UI |

## 視覺驗收結論
**尚未通過 osu! Stable fidelity。** 本批修復了重大版面錯位並縮小設定表單的首屏噪音；並排圖仍顯示背景質感、主視覺、overlay 層次及整體遊戲客戶端構圖差距。Browser geometry PASS 不是人工視覺 gate PASS。
