## Batch290：Mods 單一規則 owner

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-041 | 新增 `AMQEngine.quizMods` registry、倍率與持久化 selection store | 基礎 owner 已實作；focused 5/5 | 未接 AudioService effects／UI／score owner；不可視為 Mods 功能完成 |
| DG-042 | Vocal Only／Background Only 互斥規則 | 規則測試完成 | 音軌資料契約與真實音源分離未實作 |
| DG-043 | Stable Mods 原圖對照 | 原圖已檢視並記錄 | overlay、Skin component roles、四尺寸與人工 visual gate 未完成 |

## Batch287：VNDB Quiz 角色欄

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-038 | Quiz 底部角色欄接入 VNDB character ID 與圖片，設定只在 Settings 管理 | 功能與布局已實作；contract fixture 35/35 | 真實 VNDB API／圖片載入未驗收，人工比對使用者原圖未結案 |
| DG-039 | 新增 `quiz.character.bar`／`quiz.character.item` Skin roles 並同步 runtime | Runtime wiring 已完成 | OSK 真實素材 apply/fallback/reset 截圖矩陣未完成 |
| DG-040 | 設定頁角色 ID 的持久化、去重、移除、上限與過期請求保護 | 自動化測試完成 | Windows／實機與真實外部 API 尚未驗收 |

---

## Batch286：Quiz gameplay reference 位置／功能對照

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-035 | 依使用者提供的 AMQ gameplay screenshot 重構 Quiz：頂部 HUD、左側回合摘要、中央答題舞台、右側音訊／答題紀錄、底部答案與控制列；四尺寸 55/55 | 結構與互動布局已實作 | 背景依使用者要求未處理；原圖為多人畫面，單人 Quiz 用真實答題紀錄替代聊天室；人工視覺 gate 仍未通過 |
| DG-036 | 六個 Quiz Skin roles 接通 manifest、runtime registry、visual-needs、theme adapter 與 CSS tokens；audit 58/46/12 | Runtime wiring 完成 | 真實 OSK 素材 apply/fallback/reset 可見證據未完成；不能將 selector wiring 當作視覺驗收 |
| DG-037 | 更新 Batch264 browser harness，移除全產品腳本啟動造成的長時間等待，並修正過時 HUD 斷言；38/38 PASS | 測試 harness 修正完成 | 全量 Node suite aggregate 與 Windows／真機仍未驗收 |

## Batch285 route／Quiz 視覺差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-031 | 修正 feature route body implicit two-column root bug，route 71/71 | 根因已修 | 需將同一 regression 覆蓋所有 route；人工驗收仍待完成 |
| DG-032 | Quiz settings 原生 details 預設收合，答題舞台同心環背景 | 改善中 | 並排圖顯示仍不像 Stable；缺正式 artwork、overlay 深度與遊戲式控制層級 |
| DG-033 | Answer suggestion keyboard／dismissal matrix 擴至 18/18 | 自動化測試完成 | live answer/audio E2E、錯答後 UI 清理矩陣仍待驗收 |
| DG-034 | app status 移到 route bar，去除重複 global title header | 結構改善 | 需要全 route 人工視覺檢查與 Skin role 可視證據 |

## Batch284 Multiplayer／Quiz 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-021 | Lobby 緊湊版面、空列表 78px、四尺寸 browser 43/43 | 改善中 | Stable 玩家槽位／頭像／歌曲 artwork／chat 不在現有 API，live server 未驗收 |
| DG-024 | 開啟 `osu-intro-screen.jpg` 並對照 Quiz stage，輸出並排圖 | 改善中 | AMQ 是互動猜歌頁，不能複製 osu intro；人工視覺 gate未通過 |
| DG-026 | 保留 Lobby source tabs、room list、create-room Skin roles | 改善中 | 需要 OSK 真圖 apply/fallback/reset 截圖 gate |
| DG-029 | 修正舊 Lobby browser harness 對隱藏 nav click 的錯誤，32/32 PASS | 本批測試修正完成 | 此測試只驗證空狀態 DOM/CSS，不代表 live server |
| DG-030 | Quiz stage focus／answer suggestion selected styling | 改善中 | Arrow keys／Enter／Escape／錯答後清空與 shortcut conflict 尚未整合測試 |

## Batch272 Multiplayer Lobby 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-021 | 正式 Multiplayer Lobby 加入來源 tabs、搜尋／進行中篩選、server-backed room list、建立／加入工作區；四尺寸 geometry 32/32 | 改善中 | 目前 API 沒有玩家頭像槽位、房間曲目 artwork 或 chat；live server E2E 未驗收 |
| DG-026 | 新增三個穩定 Skin roles：lobby tab、room list、create-room，runtime roles 同步到 39 | 改善中 | OSK Mapping Studio 的實際 asset apply/fallback/reset 尚未逐角色驗收 |
| DG-027 | 盤點 AMQ Mods，未找到唯一 registry/state/multiplier/audio owner | 阻塞 | 先建立可測試的 canonical Mod owner，再開發 UI；不可虛構倍率或規則 |
| DG-028 | Stable Multiplayer 參考區域逐項建立差距表 | 已記錄 | 聊天、玩家槽位、曲目縮圖、完整底部操作列仍未對應 |

## Batch271：Stable 忠實重建與上游程式碼研究

| ID | 本批發現／決策 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-023 | 上傳的 `osu-master.zip` 可讀，已定向研究 MainMenuButton、SongSelect、SkinManager、LegacySkin、ModSelectOverlay | 研究完成 | 此來源主要是 lazer，非完整 Stable 原始碼；未編譯／未全量審計 |
| DG-024 | 建立 Stable Screenshot Fidelity 強制提示詞，逐頁定義 Main Menu、Song Select、Multiplayer Lobby、Mods、Intro/Transition 的構圖與互動 | 規格完成 | 尚未按提示詞完成所有正式 UI；人工並排視覺 gate 未通過 |
| DG-025 | 明確尊重 Stable 預設 Skin 無法匯出的限制；不再要求使用者提供預設 `.osk` | 決策完成 | 需依截圖和上游 Legacy 相容程式碼繼續建立元件映射 |
| DG-026 | OSK 元件 ID、資產類型、狀態、來源、尺寸、信心度與 fallback 契約納入提示詞 | 規格完成 | 需稽核現有 Registry/mapper/parser 是否已具備，補齊真正缺失項目 |

## Batch270 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Home 改成主視覺＋縱向主選單＋近期學習的遊戲客戶端構圖；四尺寸 77/77 | 改善中 | 無播放紀錄時沒有真實作品封面；需以正式 history/provider 實測並人工對照 |
| DG-003 | Catalog 保留 Batch269 封面、選取狀態與 viewport-bounded 列表；正式參考圖已納入封包 | 改善中 | 25／50 首正式資料、live artwork、詳情與 Dock 仍未驗收 |
| DG-014 | 最新 12 張四尺寸 JPEG 截圖及五張官方參考圖納入封包 | 證據已產生 | 自動化 fixture 不等於人工視覺 gate；Multiplayer／Mods 尚無新截圖 |
| DG-021 | 參考圖對應文件明確區分 Home、Catalog、Multiplayer Lobby、Mods | 改善完成 | Multiplayer 房間列表與 AMQ Mod owner 尚未實作／確認 |
| DG-022 | playback-history API 缺失時執行原 Home empty renderer，避免空狀態初始化缺口 | 本批修正完成 | 正式資料環境、store dispose lifecycle 仍需驗證 |

## Batch267 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Home 改為短主視覺、緊湊六入口列與最近學習工作區；空紀錄不造假 | 改善中 | 真實近期作品封面只在 history 有明確 workId 與 provider 成功時顯示；空狀態仍沒有作品圖像，需從真實資料取得證據 |
| DG-003 | Catalog 三欄骨架保留，曲目列縮至 56px CSS track、封面 34×45px | 改善中 | 六筆 layout fixture 不代表正式曲庫；HTTP-origin、live artwork、25/50 首真實資料密度仍未驗收 |
| DG-014 | Batch267 四尺寸 layout browser 63/63，新增獨立截圖目錄 | 證據已產生 | fixture 僅證明 CSS/DOM 幾何；沒有關閉人工 osu! 視覺 gate |
| DG-020 | 清理 Batch261–263 重複 Home/Catalog CSS 區段，統一為 Batch267 一個區段 | 本批結構改善完成 | ui-shell.css 中歷史 fallback 規則仍存在，後續需按實際 DOM owner 逐項確認，不得批量刪除 Skin role consumers |

## Batch266 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-004 | Multiplayer 面板保留獨立分區，恢復漸層可讀 overlay 並接回既有 Skin role token；Results 移除偽元素英文序號 | 改善中 | 截圖不含 live server/audio；Results 真實已保存回合的人工視覺對照仍待完成 |
| DG-005 | Settings 五類面板改為 ARIA tablist + bounded content workspace，桌面內部捲動、手機兩欄分類；既有狀態 owner 不變 | 結構改善完成 | 需要實際使用者流程與設定保存/OSK/備份還原端到端驗收；人工視覺對照仍未通過 |
| DG-010 | 新增四尺寸 Settings/Results/Multiplayer 截圖與 58/58 browser matrix | 證據已產生 | 目前為正式 DOM/CSS fixture/empty-state，不等於 live runtime 或人工 osu! 視覺通過 |
| DG-011 | 移除 Results `01 / ROUND RESULTS` pseudo-element 英文序號 | 此處改善完成 | 全產品動態文案與其他頁裝飾標籤仍需掃描 |
| DG-020 | Settings 專頁外框與內部內容區分離 | 改善中 | 手機長設定區仍需真機觸控檢查；固定工作區在多種瀏覽器下仍需驗收 |

## Batch263 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Home 主視覺改為全幅 art surface、底部文字疊層，調整最近學習高度 | 進行中 | 無真實播放紀錄時仍是 fallback；缺少 live artwork 實際畫面；與 osu! 主選單構圖仍有差距 |
| DG-003 | 新增正常資料布局 fixture screenshot，與 opaque-origin error screenshot 分離 | 進行中 | fixture 不代表正式 Catalog runtime；HTTP-origin IndexedDB／真實曲庫仍未驗收 |
| DG-006 | Artwork adapter fixture 與封面 fallback 測試保持 10/10 | 進行中 | live ANN/VNDB 請求、來源授權／歸因、真實封面裁切尚未驗收 |
| DG-014 | Batch263 四尺寸 Home/Catalog screenshots 47/47 | 證據已產生 | 自動化結構通過不代表人工視覺通過；Catalog 正式資料證據仍缺 |
| DG-017 | 錯誤截圖與 data fixture 截圖命名／內容分離 | 改善完成 | 仍需在允許的 HTTP-origin 環境取得真實 Catalog screenshot |



# 正式 UI 與 osu! 參考差距登記表（Batch259）

| ID | 頁面／區域 | 現況證據 | 目標結構 | 優先級 | 狀態 | 關閉證據 |
|---|---|---|---|---|---|---|
| DG-001 | 全域骨架 | 正式版使用一般頁首與橫向導航；原型有較接近遊戲客戶端的左側 rail | 固定全域導航 + 內容舞台 + 持續播放區 | P0 | 進行中 | 正式版 1920×1080 截圖與導航互動測試 |
| DG-002 | 首頁 | 正式版以大型同心圓／隱藏式圓盤入口為視覺中心，與目標主選單結構不符 | 清楚的主要功能入口、作品視覺、可見的最近學習／播放區 | P0 | 進行中 | Batch260 六入口已直接可見、圓盤已移除；主視覺仍待真實作品封面接線與人工視覺驗收 |
| DG-003 | 選歌 | 原型具左篩選／中央曲目視覺／右側詳情／底部播放控制；正式版並未採用原型骨架 | 正式 `src/` 已有左篩選／中央列表／右詳情／底部播放器骨架；需真實 HTTP-origin 資料與參考對照驗收 | P0 | 進行中 | Batch260 四尺寸截圖與 Catalog tests；HTTP-origin 因環境政策阻塞 |
| DG-004 | 猜歌 | 正式功能模組已掛入頁面，但頁面視覺需以 AMQ 問題與音訊操作為核心重新分層 | 題目、音訊、答案、回合狀態、單人／多人層級清楚 | P1 | 待處理 | 桌面／手機截圖、Quiz browser tests |
| DG-005 | 設定 | 設定內容已集中，但仍需以穩定區域與分組導覽驗收，避免長頁堆疊 | 分區設定工作區、明確當前分類、內容區內部捲動 | P1 | 待處理 | Settings 截圖、焦點／鍵盤／控制項測試 |
| DG-006 | 封面與作品識別 | 原型有原創 SVG 示意封面；它們不是正式曲庫作品封面 | 正式資料使用合法可用的作品圖片；失敗時顯示明確 fallback，不用空白漸層冒充 | P1 | 待處理 | Artwork provider 與 fallback 的真實資料證據 |
| DG-007 | Skin role 覆蓋 | 已有多個 role 契約測試，但測試通過不等於頁面結構視覺正確 | Skin roles 接到新正式 UI 的實際元件，保留覆蓋報告 | P1 | 待處理 | 每頁 role map 與 apply/fallback/reset 截圖 |
| DG-008 | 桌面無整頁捲動 | 現有頁面部分使用內容高度／垂直捲動 | 固定外框，只有指定內容區可捲動 | P1 | 待處理 | 1920×1080 的 scroll metrics 與人工截圖 |
| DG-009 | 小螢幕適配 | 既有 390px 測試多驗證溢位，不等於驗證視覺品質 | 導航收納、篩選抽屜、資訊面板折疊、觸控尺寸足夠 | P1 | 待處理 | 390×844 截圖與觸控測試 |
| DG-010 | 視覺驗收流程 | 以往主要是 DOM／狀態契約，缺少「正式版對照參考」的阻擋閘門 | 每頁參考／正式截圖、差異清單、P0 關閉後才能標記通過 | P0 | 已建立流程規格 | 本文件 + `DESIGN_LANDING_FLOW.md`；需後續執行 |


## Batch260 文案政策差距

- DG-011 裝飾性 UI 文案：已移除首頁圓盤自我解說、英文 eyebrow、重複 intro 及工程 footer；永久規則記錄於 `UI_COPY_POLICY.md`。動態元件掃描仍待補強。
- DG-012 真實作品視覺：首頁有主視覺容器與誠實空狀態，但真實近期作品／封面接線尚未驗收。
- DG-013 HTTP-origin 真實資料：Chromium loopback 被環境政策阻擋；不可把 opaque-origin screenshot 的 IndexedDB 錯誤當成正式環境結論。


## Batch261 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Home 讀取正式 playback history，主視覺跟隨最新紀錄；空狀態誠實呈現 | 進行中 | 真實封面 provider 未接通；空狀態仍有大面積空間，尚未達目標視覺密度 |
| DG-003 | Catalog 三欄比例、列密度、底部 Dock 與響應式結構收斂 | 進行中 | 正常 HTTP-origin 曲庫／封面視覺未驗收；當前截圖含 opaque-origin IndexedDB error |
| DG-006 | Home recent rows 可顯示真實 playback history metadata | 進行中 | history schema 沒有 artwork URL，需用 workId 對正式資料索引，再接既有合法 provider |
| DG-011 | Home history DOM 使用 textContent；新增 history browser regression | 進行中 | 全產品動態元件的文案掃描仍待擴大 |
| DG-014 | 主要尺寸 Home/Catalog 截圖與 history fixture 證據已生成 | 進行中 | P0 視覺差距尚未關閉，不能標記視覺通過 |


## Batch262 差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Home 空狀態 recent strip 改內容高度；主視覺可由播放紀錄驅動封面 | 進行中 | 主視覺仍有明顯空間，無播放紀錄時只能顯示誠實 fallback；與 osu! 參考構圖尚有差距 |
| DG-006 | playback `workId` 經正式 AMQ/EMQ work index 對照 ANNID/VNDB ID，再由既有 provider 載入 | 進行中 | 只驗證 resolver 與 fixture UI；live provider／HTTP-origin image load 未驗收 |
| DG-011 | 移除舊 Home pie／copy/footer dead selectors，CSS contract 防止回流 | 改善完成 | 仍需全產品 UI 文案掃描 |
| DG-015 | Home 封面 DOM 與 provider 狀態 traceability | 進行中 | 外部圖片載入、錯誤率、來源授權顯示與實機裁切需驗收 |
| DG-016 | Home/Catalog 四尺寸截圖與 artwork fixture screenshot | 證據已產生 | Catalog 正常資料截圖仍缺；opaque-origin error 不能替代 |


## Batch264 Quiz 視覺差距更新

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-004 | Quiz live round 透過 CSS order 移至設定之前；題目舞台／答案／控制列重新分層，四尺寸 38/38 | 改善中 | 畫面仍使用空曲庫／音訊狀態，真實題目視覺、live audio 與人工 osu! 對照尚未完成 |
| DG-011 | 移除 Quiz 裝飾編號、英文眉標與工程註記 | 改善完成 | 全產品動態 UI 文案掃描仍待擴大 |
| DG-018 | App Shell 舊圓角與手機觸控契約更新，回歸 144/144 | 改善完成 | 全量 Node suite 未執行 |
| DG-019 | 四尺寸 Quiz fixture 截圖分離並標示，不把 fixture 當成 live data/audio | 證據已產生 | 仍缺 HTTP-origin 正常曲庫與真實音訊截圖 |


## Batch265 差距更新
| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-004 | Quiz 設定區密度收斂、Multiplayer 獨立分區、Results 舞台層級改善 | 進行中 | 缺 Results/Multiplayer 正式四尺寸截圖與人工參考對照；App Shell regression 本次超時 |
| DG-005 | 本批未直接重構 Settings 專頁；僅保留設定控制的緊湊規則 | 待處理 | Settings 分區導覽／固定內容框架仍未實作 |
| DG-010 | 新增 Batch265 CSS 結構契約 | 進行中 | 自動契約不是人工 osu! 視覺驗收；Home/Catalog/Quiz/Results/Settings gate 未結案 |

## Batch269 差距更新
| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-003 | Catalog 中央列表改為固定可視高度捲動區、作品縮圖放大、選取列加強；四尺寸 69/69 | 改善中 | 六筆 fixture 不代表正式曲庫；真實 25／50 首、live artwork 與人工 osu! 對照未驗收 |
| DG-006 | 右側封面展示比例改為 3:4，保留正式 provider／fallback owner | 改善中 | live ANN/VNDB、來源授權／歸因與真實裁切未驗收 |
| DG-014 | Batch269 最新一輪四尺寸 Home/Catalog 與錯誤狀態證據改為 JPEG | 證據已產生 | 自動測試非人工視覺 gate；官方參考圖片以可追蹤來源 URL 保存，本批環境無法打包官方圖片二進位檔 |


## Batch273 Skin component mapping update

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-026 | Lobby 三個 Skin roles 改用穩定 `data-skin-component` selector；玩家列／ready state 加入 component ID；browser apply/fallback/reset 5/5 | 元件映射改善 | 仍需全頁 route-aware 覆蓋與 OSK 實際匯入資料驗收 |
| DG-029 | 使用者提供的 AMQ 社群腳本完成六檔定向考證，確認舊腳本依賴官方內部 prototype／quiz 物件，不直接移植 | 研究完成 | 答案輸入／鍵盤契約仍需以新版 `answer-suggestions` 與 Quiz owner 建立回歸測試 |
| DG-021 | 重新比對 Stable Main Menu 與 Multiplayer 參考圖，確認缺少的玩家槽位／作品縮圖／聊天／底部操作列仍沒有可靠資料 owner | 未通過 | 不造假資料；需先決定正式 API/protocol 是否提供必要欄位 |

## Batch274 blocker re-evaluation (2026-10-30)
- **DG-002 Home 主視覺空間／構圖：仍 P0、未通過。** 最新 Home screenshot 與 Stable Main Menu 並排重看：按鈕斜切／紫色漸層語彙已建立，但主視覺在無 playback history 時仍是音符 fallback 與大面積空區；缺少真實作品 artwork，與 Stable 的大主標誌、按鈕群構圖有明顯差距。不能以 81/81 DOM layout PASS 代替視覺 gate。
- **DG-006 正式作品封面：仍 P0、未驗收。** `workId → ANNID/VNDB ID → provider` mapping 與 adapter tests 存在；live ANN/VNDB response、HTTP-origin 圖片載入與正式作品封面成功率尚無證據。
- **DG-013 HTTP-origin persistence：仍阻塞。** Batch274 將測試 host 從 loopback 改成容器非 loopback interface，Chromium 仍回報 `ERR_BLOCKED_BY_ADMINISTRATOR`。見 `artifacts/batch274-regression/http-origin-blocker.txt`。不重複嘗試或繞過管理政策。
- **DG-017 Audio provider acceptance：新增 native media readiness 證據但未結案。** 生成 WAV 的 Chromium native media decode/fallback/stop 5/5 PASS；headless 未進入 playing，外部 AMQ/EMQ URL 與可聽輸出仍未驗收。
- **DG-018 Node test timeout：測試證據已恢復。** 98 個 test files 分 20 組、303/303 subtests PASS；Quiz pool 分佈統計改為 8k／6k deterministic draws。單一 monolithic `node --test tests/*.test.cjs` 仍未宣稱通過。


## Batch275 Home／Artwork gap update

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Home 主視覺改為大圓形 AMQ 品牌層與右側斜切入口重疊，四尺寸 85/85 | 改善中，未結案 | 真實作品封面／正式 playback history 的 live provider 證據仍缺；人工 Stable 參考並排 gate 未通過 |
| DG-006 | `setArtwork()` fallback 清除過期 provider／attribution/source URL；新增壞圖 fallback 回歸 14/14 | 失敗狀態可靠性改善 | ANN/VNDB 正式 provider response、圖片載入成功率、授權／歸因實際顯示仍待驗收 |
| DG-007 | `app.home.primary-action` 接到 CTA + 六個入口；`app.home.welcome-visual` 接到圓形 artwork surface；Skin tests 21/21 | role 接線改善 | 個別元件覆寫仍需 OSK mapping studio 逐 component 驗收；自訂 component IDs 不等同已具備獨立 Registry role |
| DG-013 | 另試 ephemeral HTTPS localhost app navigation，仍 `ERR_BLOCKED_BY_ADMINISTRATOR`；臨時 cert/server 已清理 | 環境阻塞仍在 | 需要批准的 browser/CI runner；不得繞過管理政策，也不把此結果當作 IndexedDB app logic failure |
| DG-014 | 最新 Home/Catalog 四尺寸 JPEG 產生，layout／DOM 85/85 | 證據更新 | 自動檢查不是人工像素視覺驗收；fixture 不代表 live data |


## Batch276 Artwork pipeline gap update

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-006 | Catalog image `load` 前維持 loading/fallback；`load` 後才 available/attribution；`error` 清掉 stale source link；provider factory shared crosswalk/AniList fallback 接線 | Contract 修正完成 | Live ANN/VNDB/AniList response、正式作品封面與授權歸因仍未驗收 |
| DG-015 | `app.js` 建立 AniList external client/feature，將共享 crosswalk provider 由 artwork composition boundary 注入 Catalog；移除 app 對 `AMQData` 的直接依賴 | Wiring 完成，fixture tests PASS | 不代表 live provider 可達；需要正式 browser origin 才能做 E2E |
| DG-013 | 本批不重試 local app navigation；保留 Batch275 `ERR_BLOCKED_BY_ADMINISTRATOR` 證據 | 環境 blocker 未解除 | 需批准的 browser/CI runner，不可繞過政策 |


## Batch277 provider observability update

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-006 | 新增 ANN/AniList/VNDB provider-specific outcome/error diagnostics，並由 artwork adapter 安全投影；真實資料 ID coverage audit：AMQ ANNID 99.72%、EMQ VNDB ID 98.87%；19/19 focused Node、310/310 full grouped subtests | 可觀測性／資料盤點改善完成，不代表 artwork 完成 | Live provider/CORS/rate-limit、正式封面 decode／來源歸因仍未驗收 |
| DG-013 | 本批遵循既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 證據，未重試或繞過 | 環境阻塞未解除 | 需批准 browser/CI runner 可正常載入正式 app origin |
| DG-002/DG-003 | 本批未改 Home/Catalog 視覺，避免以非視覺批次宣稱差距關閉 | P0 未通過 | 仍需真實作品圖與 Stable 並排人工視覺驗收 |



## Batch278 acceptance runner update

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-013 | 新增 GitHub Actions HTTP-origin IndexedDB save/reload harness，避免繞過本機 browser policy | Harness 已實作、未執行 | 需使用者可執行的 repository/runner 觸發並取得 artifact；不可標記 blocker 已解除 |
| DG-006 | Hosted runner 新增真實 ANNID → ANN response → image decode 探測 | Harness 已實作、未執行 | live network/CORS/圖片結果 pending |
| DG-002/DG-003 | 本批未修改 Home/Catalog UI | P0 視覺 gate仍未通過 | 需真實作品 artwork 與 Stable 並排人工驗收 |


## Batch279 UI task selection and Home density update
| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Desktop Home menu capped at 690px and vertically centered; empty-history recent region compacted; four-size browser assertions 87/87 | 局部改善 | Live artwork and human Stable composition gate remain open; layout tests do not close visual gap |
| DG-003 | No production Catalog structure/data changes in this batch; existing four-size fixture regression rerun | 未變更 | Need real Catalog records/artwork, Dock overlap verification and side-by-side osu! Song Select review |


## Batch280 Home chrome cleanup and remaining Stable fidelity gap
- Closed structurally: Home no longer renders the global header, fixed side navigation rail, or bottom recent-history panel. Main visual and six slanted destinations occupy the viewport. Feature routes retain a compact horizontal navigation bar.
- Closed structurally: Catalog fixed player Dock no longer reserves the removed 78px side rail. Home recent metadata drops nullish/placeholder strings; long titles wrap/clamp; visible focus styling and component IDs are present.
- Still P0 visual gap: the current AMQ brand disc is a fallback, not real anime/game artwork; background depth and Stable main-menu visual composition remain noticeably different. Do not claim osu! Stable visual acceptance.
- Evidence: four-size browser fixture 102/102; focused contracts 35/35 + Batch280 5/5; Architecture 1351/0. The full app-shell browser test timed out; no live catalog/artwork or physical-device acceptance.


## Batch281 Home logo update
| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-002 | Home fallback 改用原創音符＋問號圖示；圓盤改為低對比石墨色，並加入 `app.home.logo` Skin role；四尺寸 browser fixture 102/102 | 品牌 fallback 改善完成，Stable gate仍未通過 | 缺正式作品背景／動態主視覺，與 osu! Stable 構圖仍有差距 |
| DG-003 | 本批未變更正式 Catalog data owner；持續保留 layout fixture 限制 | 未結案 | Catalog Dock 真實列表遮擋、正式 artwork／曲庫與人工作業 gate仍待驗收 |


## Batch282 更新
- **DG-001（全域骨架）**：修正 feature-route 導覽列 auto-placement，現在明確在內容上方；四尺寸 fixture 中沒有頁面水平溢位。仍需人工 Stable 視覺 gate。
- **DG-003（Catalog）**：列表高度改為依 Dock 實際高度計算，分頁在桌面／平板保持於 fixed Dock 上方，手機 Dock 使用 document flow。四尺寸幾何測試通過；正式曲庫與 live provider 仍未驗收。
- **DG-007（Skin roles）**：新增 `catalog.song-list`、`catalog.pagination`、`player.dock` component IDs；仍需逐一證明 OSK asset mapping apply/fallback/reset 的可見效果。
- **DG-010（視覺 gate）**：維持未結案；自動化幾何通過不代表 osu! Stable 人工視覺通過。
- **DG-007（Skin roles）補充 Batch282**：修正 `app.home.logo` 在 runtime selector 與兩份 manifest 不一致的歷史缺陷；現在 inventory 52/40/12 一致。其餘 12 roles 仍明確 unsupported，沒有宣稱完整覆蓋。


## Batch283：Catalog 對照 Stable 後的差距

| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-003 | Catalog 桌面改為左側 AMQ 篩選、中央選取作品舞台、右側歌曲佇列；新增並排圖與逐項差距表 | 結構改善；P0 未結案 | 左側與 Stable ranking 語義不同；右側列尚非 Stable 彩色疊層；live artwork／正式資料未驗收 |
| DG-006 | 新增 provider 成功載入後才顯示的獨立選取作品背景層 | runtime 邏輯已實作 | 外部 provider／合法來源／圖片成功率與實際背景仍未驗收 |
| DG-007 | 新增三個穩定 Catalog component IDs，來源 tabs 重新接到既有 Skin role | 部分改善 | 全部新 component 的 OSK asset mapping apply/fallback/reset 截圖仍待完成 |
| DG-008 | Dock 收合／展開高度參與 Catalog list 尺寸計算，分頁保持在 Dock 上方 | 自動幾何改善 | Windows／真機與長標題／極端縮放仍待驗收 |
| DG-014 | 新增 `catalog-vs-osu-stable-1920x1080.jpg` 與 `OSU_CATALOG_VISUAL_GAP_BATCH283.md` | 證據已產生 | 並排圖為 layout fixture；人工 Stable gate仍未通過 |


## Batch288 更新：答案候選搜尋相容性
- `DG-004` Quiz 操作：改善中。參考社群 `amqAutocomplete.user.js` 增加多詞任意順序與重音折疊候選搜尋；不影響答案判定。真實 AMQ／裝置驗收仍待完成。
- `DG-011` UI 文案政策：持續有效；遊戲 UI 不可出現 AI 式解說、開發註記或測試標籤。
- `DG-014` 視覺 gate：未通過。本批為輸入功能修正，不代表 Quiz 或其他頁面已達 osu! Stable 視覺相似度。

## Batch289 Quiz 視覺狀態與比例更新
| ID | 本批變更 | 狀態 | 剩餘差距 |
|---|---|---|---|
| DG-035 | 桌面 Quiz board 改為有界寬置中三欄，中央舞台移除額外左偏；phase／result/timer 由真實 session state 投影為可見狀態；角色欄尺寸收斂；focused 31/31、四尺寸 55/55 | 結構與狀態視覺改善 | 背景按要求未處理；多人原圖的 chat/player/rank 不會偽造；live data/audio、人工視覺 gate 未驗收 |
| DG-039 | VNDB 角色欄 desktop/mobile 尺寸與底部比例更新 | 改善中 | 角色資料 fixture 不代表 live VNDB；需真實圖片與人工位置驗收 |
