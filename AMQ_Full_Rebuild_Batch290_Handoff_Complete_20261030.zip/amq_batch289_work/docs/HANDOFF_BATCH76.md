# Batch 76 Handoff: Versioned Backup / Restore API

## Environment and baseline
- Worktree: `/mnt/data/amq_batch74_verify/AMQ_Full_Rebuild_Batch74_Handoff` (packaged as `AMQ_Full_Rebuild_Batch74_Handoff/` in the ZIP).
- No `.git` metadata. `git status --short --branch` returned `fatal: not a git repository`; no Git init/commit/push was performed.
- Candidate302 and Candidate382 Stage 0 were not present. Neither baseline was modified; `src/data/assets/data.js` and `src/data/assets/emq-data.js` were not modified.
- Node `v22.16.0`, npm `10.9.2`, no `package.json`.

## Implemented
- Added `src/persistence/backup-restore.js`, loaded by `src/index.html` and `tests/tests.html`.
- Public API: `window.AMQPersistence.backupRestore.createBackupRestore(...)` returning `exportBackup()`, `preflight(input)`, and `restoreBackup(input)`.
- Envelope: `amq-learning-tool-backup`, format version 1, payload schema 1, SHA-256 checksum using stable JSON serialization.
- Includes 15 active/current/legacy data keys across settings, AMQ/EMQ SRS, current/legacy quiz history, AMQ/EMQ familiarity, song/work blacklist, custom practice lists, and watch status. Recovery/quarantine keys are intentionally excluded.
- Schema validation occurs before restore writes. Older app settings without optional `srsEnabled` are accepted. SRS AMQ/EMQ identity and card assessment provenance are preserved without rewriting raw JSON values.
- Restore snapshots existing target values and attempts rollback after a failed write/removal. If rollback also fails, result returns `rolledBack: false` and `rollbackErrors`; localStorage is not a true multi-key transaction.
- Added `docs/BACKUP_RESTORE_CONTRACT_BATCH76.md` and six dedicated tests.

## Changed files
- `src/persistence/backup-restore.js` (new)
- `src/index.html`
- `tests/tests.html`
- `tests/backup-restore.test.cjs` (new)
- `tools/check-architecture.cjs`
- `docs/BACKUP_RESTORE_CONTRACT_BATCH76.md` (new)
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `docs/HANDOFF_BATCH76.md` (new)
- `MANIFEST.sha256`

## Verification evidence
- `tests/*.test.cjs`: 29/29 scripts exit 0.
- `node tests/backup-restore.test.cjs`: 7/7 PASS, including legacy settings, legacy custom-list array, corrupt/tampered preflight no-write, AMQ/EMQ SRS provenance, recoverable rollback, persistent rollback failure reporting, partial v1 omitted-key behavior, and unsupported envelope version rejection.
- `node --test tests/tooling.test.cjs`: 8/8 PASS.
- `node tools/check-architecture.cjs`: 510 passed / 0 failed.
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`: PASS; AMQ 38,821, EMQ 16,839, duplicate IDs/dangling references/cross-source collisions all 0. Source hashes are unchanged from the existing work package.
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`: PASS; Catalog 55,660 records.
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`: PASS; build 1144.025 ms on this Node runtime, observation only.
- `node --check` for every JS/CJS file under `src/`, `tests/`, `tools/`: PASS.
- Manifest verification: all 163 manifest entries verified; ZIP integrity test passed after packaging.

## Limitations / blocked
- API only: no user-facing backup/download/import UI has been added.
- No historical v0 envelope contract exists; unknown format versions are rejected. Partial v1 backup semantics are tested: omitted keys remain unchanged.
- Browser quota/security behavior, real multi-tab storage events, and actual browser rollback behavior are not verified.
- If browser storage persistently refuses rollback writes, some original values may remain unrestored; the API reports that state explicitly.
- No real browser/audio E2E claim is made. The known environment-blocked Chromium navigation was not retried.

## Next batch
1. Evaluate a minimal UI workflow for export/import, including preflight summary, explicit overwrite confirmation, and clear rollback failure reporting; avoid large UI/CSS redesign.
2. Keep real-browser cross-tab/quota validation separately BLOCKED until an actually usable browser channel exists.
