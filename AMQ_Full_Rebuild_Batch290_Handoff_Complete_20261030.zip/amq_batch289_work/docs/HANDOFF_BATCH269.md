# Batch269 Handoff：osu! Song Select 對照後的 Catalog UI 改善

## 實際修改
- `src/styles/ui-design-landing.css` 新增 Batch269 正式 UI 規則：列表區採 viewport-bounded scroll area；桌面曲目封面 46×60、中尺寸 42×56、手機 38×50；選取列左側狀態線及標題字重更清楚；右側封面框改 3:4；列表滾動限制 overscroll chain。
- 沿用現有 Catalog DOM、查詢／選取狀態與音訊 owner，沒有引入新資料來源。
- 新增 `tests/batch269-home-catalog.browser.py` 與 `tests/batch269-catalog-visual.contract.test.cjs`。
- 新增 `docs/OSU_SONG_SELECT_REFERENCE_BATCH269.md`，記錄官方 osu! Wiki 參考來源與可驗收視覺原則。

## 測試證據
- Home/Catalog 四尺寸 Browser checks：69/69 PASS（1920×1080、1440×900、1024×768、390×844）。
- Batch269 Catalog visual contract：6/6 PASS。
- Batch268 Catalog row contract：5/5 PASS。
- UI shell CSS contract：8/8 PASS。
- Python AST compile：PASS。
- Manifest／ZIP CRC／SHA-256：以本次封包實際驗證結果為準。

## 截圖與參考
- Batch269 原始截圖已由 Batch270 最新一輪取代，不再隨目前主交付包攜帶；目前最新 12 張 JPEG：`artifacts/batch270-home-catalog/`。
- 差距表：`artifacts/batch269-home-catalog/visual-gap-table.md`。
- 官方 Song Select 參考圖本體由使用者於 Batch270 提供，現位於 `artifacts/osu-reference/osu-song-selection.jpg`；五張圖的對應與來源見 `docs/OSU_UI_REFERENCE_BATCH270.md`。

## 尚未驗收
- Catalog fixture 仍為六筆測試曲目與 SVG 示意圖，不代表正式曲庫。
- Live ANN/VNDB artwork、來源授權／歸因、HTTP-origin IndexedDB、音訊與 Windows／實機未驗收。
- Home 主視覺真實 artwork 仍未結案。
- 人工 osu! 視覺 gate未通過；本批是局部改善，不是整體視覺結案。
- 全量 Node suite 未執行。

## 下一批
Batch270 以 UI 為主：追蹤正式 artwork provider 的可驗證資料、改善 Home 真實作品視覺，並在正式資料環境驗證 Catalog 25／50 首與 Dock；不再累積舊截圖或原始測試日誌。
