# Batch149 交接：AMQ `.osk` Skin 匯入第一階段

日期：2026-10-28。工作副本 `/mnt/data/amq_batch129_work`。無 Git metadata；未初始化 Git。

## 使用者方向
使用者要求 AI 自行在線上尋找 osu! Skin 參考，並不是只拿 `.osk` 當設計靈感，而是希望 AMQ 最後也能直接讀取 `.osk`，以此支援高度自訂的介面。希望可自訂卡片框架、場景背景、右下角動漫角色與更多使用者主題元素。

## 研究結論
- 官方 osu! Skin 文件指出 Skin 是圖片／音效等素材的集合，`.osk` 可匯入 osu!。
- `skin.ini` 用來定義 Skin 名稱、作者、版本、顏色與其他顯示設定。
- `.osk` 不包含可直接運行的網頁 UI；AMQ 要有自己的 importer、素材角色映射、主題設定與 AMQ 元件適配。
- 本批已查閱官方文件與 ZIP parser 資料，但已找到可下載的真實候選 `.osk`：`https://github.com/fuyukiSmkw/osu-skin-KaKKeY/releases/download/2025.04.27.1/KKY.osk`（KaKKeY Skin release）。但目前工作容器 DNS 無法連線，尚未把二進位檔下載到本機並跑真實檔案驗收。

## 修改檔案
- `src/skins/osk-importer.js`：ZIP 中央目錄解析，Stored／Deflate，skin.ini metadata／Combo RGB，圖片素材篩選、命名映射與安全限制。
- `src/ui/skin-import-panel.js`：file input、圖片畫廊、背景／角色／框架角色指定、工作階段預覽與清除。
- `src/index.html`：新增 `.osk` 匯入區塊與 script 引用。
- `src/styles.css`：新增 Skin 背景、角色、選取框架預覽與素材畫廊樣式。
- `src/app.js`：以 app lifecycle scope mount/dispose 匯入面板。
- `tests/osk-importer.test.cjs`：6 個 importer tests。
- `tests/osk-import-panel.browser.test.py`：系統 Chromium browser integration。
- `tools/check-architecture.cjs`、`tests/tests.html`：更新模組載入／檢查。
- `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md`：更新進度與下一批工作。

## 驗證證據
- `node tests/osk-importer.test.cjs`：6/6 PASS。
- `python tests/osk-import-panel.browser.test.py`：9/9 assertions PASS（使用 `/usr/bin/chromium`）。
- `node tools/check-architecture.cjs`：946 PASS、0 FAIL。
- `node --test tests/core.test.cjs tests/app-lifecycle.integration.test.cjs tests/osk-importer.test.cjs`：3 suites PASS、0 FAIL。
- 三個修改 JS `node --check` PASS。
- `node --test tests/*.test.cjs` 超過 120 秒執行上限，未完成 summary；全量回歸狀態為待分批驗證。

## 已知限制
- 匯入資產目前只在目前 tab 工作階段有效，尚未 IndexedDB 持久化。
- 原型可讀 `.osk` 中的圖片與 `skin.ini`，不讀取或播放 Skin 音效，也不支援 ZIP64／多磁碟。
- 已找到真實候選 `.osk` 下載來源，但工作容器 DNS 不可用，尚未下載並測試真實檔案；ZIP fixture 為本地測試生成。
- Skin 中第三方動漫角色／背景的技術匯入不代表取得著作權授權。
- `.osk` 的 osu! 遊玩內元素不一定適合 AMQ；映射需要由 AMQ 自己定義，不應盲目照搬。

## 下一批優先順序
1. 取得並檢查一個可下載的真實 `.osk` 範例；驗證檔案實際壓縮法、skin.ini 編碼與圖片命名。
2. 分批完成正式產品 Node 測試，不要重試一次跑超過 120 秒的整包指令。
3. IndexedDB 持久化匯入圖片與角色映射，支援重新載入後自動還原、刪除／重設。
4. 建立可持續擴充的 Theme schema，將背景、卡片框架、角色裝飾、強調色與動態設定解耦。
5. 將已讀取的 Skin 元素映射到後續 osu-style Song Select 原型／正式 UI，驗證手機、reduced-motion 與素材缺漏 fallback。
