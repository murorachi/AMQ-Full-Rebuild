# Batch 96 交接包：多人命令 canonicalization 與狀態轉移邊界

## 起點與基準
- 起點為 `AMQ_Full_Rebuild_Batch95_Handoff_20261027.zip`。工作副本無 `.git`，未初始化 Git、未偽造 branch／commit。
- Candidate302、Candidate382 Stage 0 不在包內且未修改；`src/data/assets/data.js` 與 `src/data/assets/emq-data.js` 唯讀，未修改。

## 本批修改
- `src/multiplayer/room-command-service.js`：在讀取任何命令欄位前先以 descriptor-safe traversal 建立 detached canonical JSON 副本；拒絕非有限數字、循環參照、symbol、accessor、稀疏／額外屬性陣列及非 plain objects，無論有無 requestId 都避免執行 getter；requestId trim 後計算 fingerprint，保留跨 VM／realm plain object 相容性。
- `src/multiplayer/room-state-machine.js`：revision 達 `Number.MAX_SAFE_INTEGER` 時拒絕 transition，回報 `ROOM_REVISION_EXHAUSTED`。
- `tests/multiplayer-room-command-service.test.cjs`：新增 sparse array、NaN、accessor 與 getter 不執行測試。
- `tests/multiplayer-room-state-machine.test.cjs`：新增 6 類 timestamp／answer boundary mutation、revision exhaustion 與 24 次 deterministic round trace；驗證 revision 增量、唯一 round ID、normalize round-trip 與 active-round snapshot privacy。
- 更新 `docs/ARCHITECTURE.md`、`docs/ACCEPTANCE.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md` 與 manifest。

## 已知邊界
- requestId idempotency cache 與 per-player rate limit 仍是 process-local，不提供跨程序／跨節點保證。
- 真正 transport、authentication provider、durable idempotency、per-room serialization、reconnect 與 multi-client E2E 尚未實作。
- 多人評級 SRS persistence 需產品決策；不得寫入沒有 user identity 的共享 localStorage key。
- 真實瀏覽器／音訊／storage／外部 API／多人互通未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一路徑。

## 驗證
- 本文件與完整測試結果以 `docs/WORK_STATUS.md` Batch96 終驗附記為準。不得將 Node 純邏輯測試宣稱為真實 server／browser E2E。
