# AMQ visual needs traceability · Batch239

本表補上 Batch238/239 實際完成的 selector 與 CSS consumer 證據。`supported` 僅表示角色已有可查核的 DOM target 和 CSS token consumer，不表示其原生 osu! stable tint/blend、動畫或像素級幾何已完整還原。

| AMQ visual need / role | 真實 DOM selector | Runtime token | CSS consumer | 狀態／限制 |
|---|---|---|---|---|
| `home.background` / `app.home.background` | `#page-home` | `--amq-skin-role-app-home-background` | `#page-home` background image/position/cover | supported; 只提供背景 cover，不含原生混色 |
| `home.primary-action` / `app.home.primary-action` | `#home-pie` | `--amq-skin-role-app-home-primary-action` | `#home-pie` layered background | supported; AMQ 自訂入口，非 stable 原生元件 |
| `catalog.item.background` | `#catalog-browser` | `--amq-skin-role-catalog-item-background` | `#catalog-rows tr` | supported; 不等於 artwork |
| `catalog.item.selected` | `#catalog-browser` | `--amq-skin-role-catalog-item-selected` | `#catalog-rows tr[aria-selected="true"]` | supported; state tint 未實作 |
| `catalog.item.hover` | `#catalog-browser` | `--amq-skin-role-catalog-item-hover` | `#catalog-rows tr:hover` | supported; 僅 hover image slot，無自動 state pair |
| `quiz.background` | `#quiz-panel` | `--amq-skin-role-quiz-background` | Quiz Arena panel background cover with readable dark overlay | supported; overlay 由 AMQ 控制 |
| `quiz.answer.input` | `#quiz-answer` | `--amq-skin-role-quiz-answer-input` | `#quiz-panel #quiz-answer` background layer | supported; 不會取代 input 或其鍵盤操作 |
| `quiz.timer` | `#quiz-timer` | `--amq-skin-role-quiz-timer` | **no image consumer** | runtime target exists, but remains unsupported for visual image mapping until a semantic timer consumer is implemented |
| `results.panel` | `#quiz-round-results` | `--amq-skin-role-results-panel` | `#results-workspace #quiz-round-results` background with readable overlay | supported; true saved results only |
| `results.primary-action` | `#results-empty .results-primary-action`, `#quiz-round-results .results-primary-action` | `--amq-skin-role-results-primary-action` | `#results-workspace .results-primary-action` | supported; action semantics remain native button |
| `results.grade` | no dedicated grade element | none | none | unsupported; text/semantic result is not a stable grade badge |
| `quiz.result.correct` / `quiz.result.incorrect` | no dedicated persistent semantic feedback target | none | none | unsupported; do not map ranking grade artwork to correctness |
| `catalog.filter.background` | `.catalog-sidebar` | no dedicated role token | AMQ-native sidebar surface only | unsupported for OSK mapping until runtime role is intentionally declared |

## Renderer primitive contract

`src/skins/skin-renderer.js` now exposes pure/tested primitives for `@2x` logical dimensions, intrinsic dimension validation, `contain`/`cover` fit semantics, explicit normal/hover pair resolution, and background crop semantics. This is not yet a full native skin compositor. `native-tint`, multiplicative blend, nine-slice/edge-repeat, animated sequence binding and automatic state-pair selection remain unsupported.
