# Batch192 交接：AniList／MAL／VNDB provider 安全與取消契約

日期：2026-10-28
工作副本：由 Batch191 ZIP 解壓取得的 `amq_batch189/amq_batch153_work/`；無 `.git`，未初始化。

## 已完成

- MAL public read 使用獨立 `clientIdProvider`，送出 `X-MAL-CLIENT-ID`；private list 與 mutation 保留 OAuth2 Bearer token。沒有硬編碼第三方 client ID。
- 缺少、空白、格式不合法的 client ID 明確 fail closed；禁止呼叫端透過 headers 注入 Authorization 或覆寫 MAL client ID。
- AniList／MAL／VNDB feature methods 把呼叫端 AbortSignal／timeoutMs 傳至共用 HTTP client，涵蓋搜尋、精確讀取、私人清單及 mutation。
- MAL malformed rows／paging metadata 與 AniList MediaListCollection malformed lists／entries 做防禦性正規化。
- VNDB HTTP client 預設 timeout 2500 ms，單次上限 2800 ms，避免超過官方 Kana 文件所述 3 秒 server cutoff。沒有加自動重試；429／Retry-After、401／403、5xx、network、timeout、cancel、dispose 使用共用錯誤契約。
- 新增 `docs/EXTERNAL_PROVIDER_AUDIT_BATCH192.md`，並更新 `docs/EXTERNAL_SERVICE_AND_MULTIPLAYER_CONTRACT_BATCH89.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`AI_START_HERE.md` 與 `docs/NEXT_SESSION_PROMPT.md`。

## 修改檔案

- `src/integrations/external-service-adapter.js`
- `src/integrations/anilist-adapter.js`
- `src/integrations/mal-adapter.js`
- `src/integrations/vndb-adapter.js`
- `tests/external-service-adapter.test.cjs`
- `tests/external-service-feature-adapters.test.cjs`
- `docs/EXTERNAL_PROVIDER_AUDIT_BATCH192.md`
- `docs/EXTERNAL_SERVICE_AND_MULTIPLAYER_CONTRACT_BATCH89.md`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/HANDOFF_BATCH192.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `artifacts/batch192-regression/`

## 測試證據

- Node tests：75/75 files exit 0。第一輪總控在第 59 個測試檔後觸及外層時間限制；其餘 16 個檔案另行完成，最後對修改過的 `external-service-adapter.test.cjs` 再次獨立執行。完整結果見 `artifacts/batch192-regression/node-tests.tsv`、`node-tests.json`、`node-tests/`。
- Architecture Checker：1,102 PASS／0 FAIL，見 `architecture.log`。
- OSK import panel harness：12/12 assertions PASS，見 `osk-harness.log`。
- JavaScript／CJS syntax：171/171 PASS，見 `syntax-checks.tsv` 與 `syntax-checks.json`。
- AMQ／EMQ assets SHA-256 未變，見 `asset-sha256.txt`。

## 未完成／阻塞

- AniList OAuth callback、token 安全儲存／重新授權 UI 尚未實作。官方文件表示 AniList access token 約一年有效且不支援 refresh token，需重新授權；若採 Authorization Code Grant，client secret 必須留在 server，不能放前端。
- MAL client ID 設定、OAuth callback／refresh 與帳號同步 UI 尚未實作。MAL quota 仍 `quotaVerified: false`；本執行環境無法直接讀取 MAL 官方 reference，正式啟用前需再核實。
- VNDB private user list API 未實作；目前僅有 public VN query／exact ID lookup。
- 沒有執行 live API、OAuth、外部 CORS 或帳號同步 E2E。模擬／契約測試不能代替外部驗收。
- 真實瀏覽器導覽仍受 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋；Candidate302／Candidate382 Stage 0 原始檔缺席；無 `.git`，未初始化。

## 下一批

Batch193：審查既有多人 HTTP transport、room state、membership／authorization、command idempotency、server-authoritative scoring／timeout、答案遮蔽及音訊同步契約。只修可重現的高優先級缺口，不重寫已通過的 room state machine；對部署／音訊同步協定不足的部分記錄明確阻塞。
