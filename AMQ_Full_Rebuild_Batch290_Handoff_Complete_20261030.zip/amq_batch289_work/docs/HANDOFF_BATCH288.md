# Batch288：依使用者提供的 AMQ 社群腳本修正答案自動完成（2026-10-30）

## 參考來源與邊界
- 來源：`references/AMQ-Scripts-master.zip`，SHA-256 `76fc073a51da180d087ba4c6636b22531053ed5b1affeb5a8330e7de7c4aad04`。
- 本批直接檢視 `gameplay/amqAutocomplete.user.js` 的搜尋策略：字首／包含優先，並支援多個輸入詞以任意順序匹配作品標題；這是社群腳本行為參考，不是官方 AMQ 核心原始碼。
- 未將舊腳本注入新版 runtime，沒有覆寫 prototype、全域快捷鍵或答案判定流程。

## 實作
- `src/ui/answer-suggestions.js` 在既有字面匹配與分隔符匹配之後，新增多詞任意順序匹配；只有包含至少兩個長度大於 1 的詞的多詞查詢才啟用，避免單字母／標點查詢過度擴張。
- 增加拉丁重音符號折疊匹配，例如輸入 `cafe mar` 可找到 `Café del Mar`，但選項仍顯示原始作品名稱。
- 多詞匹配高亮會映射回原始字串位置；既有字首／包含排序、候選上限、鍵盤操作、IME、Escape 關閉、點擊外部關閉與 DOM 重用行為保留。
- 沒有改動 `quiz-session`、`answer-evaluator` 或正式答案判定；自動完成只協助找候選，不會替玩家猜答案或自動提交。
- 新增兩項回歸測試：詞序任意匹配且避免單字母過度匹配；重音折疊與原始字串高亮。

## 驗證
- `node tests/answer-suggestions.test.cjs`：20/20 PASS。
- `node tests/quiz-panel.test.cjs`：PASS；包含 768 種 selector 組合及 Quiz panel integration。
- `node tools/check-architecture.cjs`：1,372 PASS／0 FAIL。
- `python tests/batch287-vndb-character-settings.browser.py`：35/35 PASS（隔離 API／圖片 fixture）。
- `python tests/batch286-quiz-gameplay-layout.browser.py`：55/55 PASS（四尺寸 geometry／route fixture）。
- 真實 AMQ 網站／多人伺服器、外部音訊、Windows／手機實機及人工 osu! Stable 視覺 gate未由本批驗證。

## 已知限制
- 本批只將社群腳本的多詞搜尋行為移植成獨立、可測試的候選排序能力；沒有複製其 FuzzySet 模糊匹配或「回合結束自動猜答案」行為，避免誤導玩家或影響答案規則。
- 重音折疊只用於候選搜尋，不改變正式答案 evaluator 的接受規則。
- 本批不是 UI 視覺結案；主要目的為修正 AMQ 答案輸入的搜尋相容性，UI 與 osu! Stable 差距仍由主清單持續追蹤。
