# Batch240 AMQ 四頁 Skin Runtime Traceability

本矩陣區分素材指定、AMQ DOM/CSS 實際消費、以及 osu!stable 原生幾何／狀態語義。只有 DOM 與 CSS 接線成立仍不代表原生 Skin fidelity 已完成。未接線的角色維持 unsupported；`repeat-x` 不是 `songselect-top` 原生 edge-repeat，普通背景圖片也不等於原生 tint/blend。

- Runtime role inventory：35 個具名 selector。
- 需求範圍：Home、Catalog、Quiz、Results 及其共用導航／提示，共列出 25 個視覺角色。

| 頁面 | Visual need / role | Runtime selector | CSS token consumer | Geometry / state | Fallback | AMQ runtime | Native stable semantics |
|---|---|---|---|---|---|---|---|
| 首頁 / home.background | `app.home.background` | `#page-home` | `--amq-skin-role-app-home-background` (yes) | cover / center center | app-default-background | AMQ image slot wired | not claiming full stable renderer fidelity |
| 首頁 / home.primary-action | `app.home.primary-action` | `#home-pie` | `--amq-skin-role-app-home-primary-action` (yes) | role default contain | AMQ extension slot using shared button tokens; no dedicated stable cookie filename | AMQ image slot wired | not claiming full stable renderer fidelity |
| 共用 / navigation.back | `app.navigation.back` | `#app-back` | `--amq-skin-role-app-navigation-back` (yes) | role default contain | app-default-back | AMQ image slot wired | not claiming full stable renderer fidelity |
| 共用 / navigation.tab | `app.navigation.tab` | `#app-shell-nav` | `--amq-skin-role-app-navigation-tab` (yes) | role default contain | app-default-tab | AMQ image slot wired | not claiming full stable renderer fidelity |
| 首頁 / home.ambient | `app.home.ambient-effect` | `—` | `—` (no) | role default contain | disabled | unsupported | unsupported until DOM/CSS consumer exists |
| 選歌 / catalog.frame.top | `catalog.frame.top` | `#catalog-browser` | `--amq-skin-role-catalog-frame-top` (yes) | repeat-x / top left | catalog-default-top-frame | AMQ image slot wired | unsupported: native edge-repeat not implemented |
| 選歌 / catalog.frame.bottom | `catalog.frame.bottom` | `#free-player-dock` | `--amq-skin-role-catalog-frame-bottom` (yes) | stretch-x / bottom left | catalog-default-bottom-frame | AMQ image slot wired | not claiming full stable renderer fidelity |
| 選歌 / catalog.row.normal | `catalog.item.background` | `#catalog-browser` | `--amq-skin-role-catalog-item-background` (yes) | stateful-panel / bottom left | catalog-default-row | AMQ image slot wired | partial: native tint/state semantics not implemented |
| 選歌 / catalog.row.selected | `catalog.item.selected` | `#catalog-browser` | `--amq-skin-role-catalog-item-selected` (yes) | stateful-panel / bottom left | catalog-default-selected-row | AMQ image slot wired | partial: native tint/state semantics not implemented |
| 選歌 / catalog.row.hover | `catalog.item.hover` | `#catalog-browser` | `--amq-skin-role-catalog-item-hover` (yes) | role default contain | catalog-default-hover-row | AMQ image slot wired | partial: native tint/state semantics not implemented |
| 選歌 / catalog.artwork | `catalog.song-artwork` | `—` | `—` (no) | semantic-block / center center | real catalog artwork or explicitly replaceable artwork asset; never infer from random OSK character art | unsupported | unsupported until DOM/CSS consumer exists |
| 選歌 / catalog.detail.panel | `catalog.song-detail.panel` | `#catalog-selection-details` | `--amq-skin-role-catalog-song-detail-panel` (yes) | role default contain | AMQ extension slot; stable menu-button-background is not a generic detail panel | AMQ image slot wired | not claiming full stable renderer fidelity |
| 選歌 / catalog.search | `catalog.filter.background` | `—` | `—` (no) | role default contain | AMQ extension slot using shared panel tokens; keep search controls readable | unsupported | unsupported until DOM/CSS consumer exists |
| 選歌 / catalog.random | `catalog.action.random` | `—` | `—` (no) | role default contain | catalog-default-random-action | unsupported | unsupported until DOM/CSS consumer exists |
| 猜歌 / quiz.background | `quiz.background` | `#quiz-panel` | `--amq-skin-role-quiz-background` (yes) | cover / center center | quiz-default-background | AMQ image slot wired | not claiming full stable renderer fidelity |
| 猜歌 / quiz.timer | `quiz.timer` | `#quiz-timer` | `--amq-skin-role-quiz-timer` (yes) | role default contain | AMQ extension slot using shared progress component | AMQ image slot wired | not claiming full stable renderer fidelity |
| 猜歌 / quiz.answer | `quiz.answer.input` | `#quiz-answer` | `--amq-skin-role-quiz-answer-input` (yes) | role default contain | AMQ extension slot with accessible input fallback | AMQ image slot wired | not claiming full stable renderer fidelity |
| 猜歌 / quiz.feedback | `quiz.result.correct` | `—` | `—` (no) | role default contain | AMQ semantic result component; do not assume osu! grade means answer correctness | unsupported | unsupported until DOM/CSS consumer exists |
| 猜歌 / quiz.feedback | `quiz.result.incorrect` | `—` | `—` (no) | role default contain | AMQ semantic result component | unsupported | unsupported until DOM/CSS consumer exists |
| 結算 / results.panel | `results.panel` | `#quiz-round-results` | `--amq-skin-role-results-panel` (yes) | panel-contain / center center | results-default-panel | AMQ image slot wired | not claiming full stable renderer fidelity |
| 結算 / results.grade | `results.grade` | `—` | `—` (no) | intrinsic / center center | text-grade | unsupported | unsupported until DOM/CSS consumer exists |
| 結算 / results.primary-action | `results.primary-action` | `#quiz-round-results .results-primary-action, #results-empty .results-primary-action` | `--amq-skin-role-results-primary-action` (yes) | role default contain | shared primary button token | AMQ image slot wired | not claiming full stable renderer fidelity |
| 共用 / feedback.notice | `feedback.success` | `—` | `—` (no) | role default contain | accessible status text and icon | unsupported | unsupported until DOM/CSS consumer exists |
| 共用 / feedback.notice | `feedback.warning` | `.notice` | `--amq-skin-role-feedback-warning` (yes) | role default contain | accessible status text and icon | AMQ image slot wired | not claiming full stable renderer fidelity |
| 共用 / feedback.notice | `feedback.error` | `[role="alert"]` | `--amq-skin-role-feedback-error` (yes) | role default contain | AMQ extension slot with accessible text and icon | AMQ image slot wired | not claiming full stable renderer fidelity |

## Renderer 實際接線

- Mapping Studio 的圖片預覽使用 `skinRenderer.fitStyle()` 與 `logicalSize()`；`@2x` 預覽同時記錄 raster 與 logical 尺寸。
- `app.navigation.back` 可明確指定 normal／hover 素材、fit 與 position；兩張素材都存在且有效時才會套用。缺任一張時 adapter 跳過整個 pair，保持 AMQ 預設，不以另一張或無關素材補洞。
- pair 設定存入 IndexedDB theme schema v4，portable bundle format 仍為 v1 且向後相容；schema v1/v2/v3 可遷移至 v4。
- `app.navigation.options`、`settings.entry` 雖可編輯／保存 state pair，但尚未有已核實 runtime target，仍不會因為 pair 存在就宣稱支援。
- `catalog.frame.top` 的 AMQ repeat-x 預覽僅是幾何示意，沒有宣稱 osu!stable 的右側邊緣像素延展已實作。

## 尚未驗收

- 真實 HTTP-origin IndexedDB save/reload 仍受 Chromium loopback navigation policy 阻擋；本批沒有將 opaque-origin fixture 當作持久化證據。
- native multiplicative blend/tint、songselect-top edge-repeat、動畫序列、自動 state-pair discovery 與完整 stable renderer fidelity 均未支援。
- `catalog.song-artwork` 仍必須由真實作品封面 provider 或明確可替換作品封面提供；OSK 角色圖不可代替作品封面。


## Batch241 renderer-contract update

- `src/skins/skin-blend.js` exposes a tested RGB multiplication contract for RGBA pixels; source alpha is preserved. This is an AMQ pixel primitive, not full osu!stable native blend fidelity.
- `src/skins/skin-edge-repeat.js` exposes explicit right-edge pixel extension with caller-supplied edge width. It is not automatically applied to `catalog.frame.top`; exact native `songselect-top` behavior remains unsupported until geometry/version rules are verified.
- The formal script order loads both helpers before `skin-renderer.js`. The renderer advertises `multiply-rgba-contract-v1` and `explicit-right-edge-repeat-rgba-v1` while `nativeStableFidelity` keeps both native claims false.
- `app.navigation.options`, `settings.entry`, `catalog.action.random`, `catalog.filter.background`, `catalog.song-artwork`, result correctness feedback, and result grade remain unsupported because their exact semantic runtime target and consumer contract are not fully verified.


## Batch242: Canvas integration and remaining-role audit

- `skinCanvasRenderer` is now a tested shared renderer capability for Blob decode, Canvas RGBA readback, explicit AMQ pixel transforms and ImageData writeback. This is a general AMQ integration seam; it does not change any role's native osu!stable support status.
- Chromium synthetic PNG evidence is in `artifacts/batch242-regression/canvas-integration-result.json` and `canvas-integration.png`; 9/9 browser assertions pass. Node contracts cover invalid Blob, pixel limits, invalid dimensions, unavailable Canvas and load order.
- The remaining roles `app.navigation.options`, `settings.entry`, `catalog.action.random`, `catalog.filter.background`, `catalog.song-artwork`, `quiz.result.correct`, `quiz.result.incorrect`, `results.grade`, `feedback.success`, `settings.dialog`, `settings.slider`, `app.home.ambient-effect`, and `catalog.difficulty-marker` remain unsupported until the exact target, CSS token consumer, state/geometry, reset behavior and semantic fallback are all reviewed.
- `catalog.song-artwork` is especially constrained: the Catalog currently renders actual artwork-provider images when available and source-aware title-derived fallback otherwise. No arbitrary OSK character image is promoted into song-cover artwork. A future role mapping must only affect an explicitly designated fallback surface and must not obscure real provider artwork.
- HTTP-origin IndexedDB save/reload remains blocked by Chromium `ERR_BLOCKED_BY_ADMINISTRATOR`; this batch does not claim durable browser persistence acceptance.


## Batch243 語義角色再審核

本批重新檢查 `catalog.song-artwork`、`catalog.action.random`、`catalog.filter.background`、`quiz.result.correct`／`quiz.result.incorrect`、`results.grade`、`settings.entry` 與 `app.navigation.options`。沒有角色在本批被提升為完整支援：歌曲封面缺少可保證對應作品的素材來源；隨機選曲與設定入口尚未核實可套用的語義圖像 DOM target；搜尋面板背景必須和表單可讀性／focus state 共存；答對／答錯需由 QuizSession 的真實結果狀態驅動獨立回饋 target，而目前 answer reveal 只顯示答案 metadata，不能推斷為 correctness badge；評級角色亦不能混同正確率；設定入口與 options 仍缺完整的 runtime consumer。保持 unsupported 是正確結果，不是待辦漏接。

## Batch243 Canvas 安全性補充

`skin-canvas-renderer.js` 對 repeat output 先驗證安全整數與 `targetWidth × height <= maxPixels`，再進行像素擴展與輸出 Canvas 建立；`skin-edge-repeat.js` 也有獨立的預設／可調 pixel budget，避免呼叫端繞過 renderer 直接配置過大 buffer。Chromium alpha 測試記錄 premultiplication 導致的通道量化差異，不宣稱 byte-exact round-trip 對所有透明顏色成立。


## Batch244 renderer safety／role connection decision

- Renderer 對尺寸採 `Number.isSafeInteger`，並在配置前檢查 pixel product、RGBA byte product 與 `0x7fffffff` 的 TypedArray／Canvas byte-length 防線；不合法或超限的 edge-repeat 回傳 `null`，Canvas API 對 factory/readback/writeback failure 回傳穩定 `SKIN_*` error。
- `ImageBitmap` 在 decode 尺寸拒絕時盡力 close；close 本身拋錯不會遮蔽尺寸錯誤；`renderBlobToCanvas` 仍以 `finally` close，覆蓋 pipeline 例外。
- 本批沒有把任何 unsupported visual need 改為 supported。對 `catalog.song-artwork`、`catalog.action.random`、`catalog.filter.background`、correct/incorrect feedback、`results.grade`、`settings.entry`、`app.navigation.options`，仍要求語義 target、CSS consumer、state／geometry、fallback、reset 與 browser regression 齊全後才能接線。
- Batch244 Chromium synthetic Canvas assertions 15/15 PASS；結果與截圖位於 `artifacts/batch244-regression/`。此測試不構成 native osu!stable fidelity 證據。


## Batch245 自動稽核證據

- 可重複執行：`node tools/audit-visual-role-coverage.cjs`。
- 完整機器報告：`artifacts/batch245-regression/visual-role-audit.json`；閱讀版：`artifacts/batch245-regression/visual-role-audit.md`。
- 本次掃描 48 roles，35 個有 runtime selector 並可在 stylesheet 找到 token consumer；13 個仍 unsupported。31 個 role 可找到直接引用該 role/token 的測試檔線索，但這只證明存在相關測試，不代表逐角色 browser apply/fallback/reset 都已驗收。
- 靜態檢查對 HTML selector 的 literal hit 只作提示；動態建立的 DOM 必須以 browser evidence 核實。全域 adapter reset 的存在也不等於每個角色 reset 都已逐項驗收。
- 未支援角色保持原狀：`catalog.filter.background`、`catalog.song-artwork`、`quiz.result.correct`、`app.home.ambient-effect`、`app.navigation.options`、`settings.entry`、`catalog.action.random`、`catalog.difficulty-marker`、`quiz.result.incorrect`、`settings.slider`、`settings.dialog`、`results.grade`、`feedback.success`。作品封面不得由 OSK 角色圖代替。


## Batch246 Mapping Studio 閉環補充（2026-10-29）
- 代表性 `app.navigation.back` state-pair 已由 Chromium 實際驗證：Normal／Hover 素材選取、@2x logical size、fit=`cover`、position=`top left`、正式 adapter token 套用與 reset 後清除。鍵盤 focus 保持在可操作控制項；state-pair controls 的 computed min-height 為至少 44px。
- Apply lifecycle 具備防重入、disabled、`aria-busy`、例外訊息與 finally 清理；原焦點在控制項仍可用時恢復。UI contract 保護該責任，但沒有聲稱所有可能的 adapter/store 故障已由真實 IndexedDB 瀏覽器逐一驗收。
- `theme-store` 與 portable transfer 超限映射數量由靜默截斷改為拒絕，避免匯入／保存後的資料遺失。portable format v1 與 IndexedDB schema v4 不變。
- 本批不增加 runtime role inventory；48 個角色仍是 35 wired／13 unsupported。代表性 browser closure 不等於其餘 34 個已接線角色逐一驗收。
