# 歷史測試產物索引（Batch272 交付包）

為避免每一批都重複攜帶數十個舊批次的 raw logs／PNG，主要交付包只保留可由目前測試直接讀取的歷史 fixture、最新 UI 對照證據與官方參考圖。歷史工作狀態、測試命令、結果與限制仍保留於 `docs/WORK_STATUS.md`、`docs/HANDOFF_BATCH*.md`、`AI_START_HERE.md`。

## 保留的歷史產物
- `artifacts/batch245-regression/`：`tests/visual-role-audit.test.cjs` 與 `tools/audit-visual-role-coverage.cjs` 直接讀取的角色稽核 JSON／Markdown。
- `artifacts/batch252-regression/`：`tests/skin-compatibility-audit.contract.test.cjs` 直接讀取的 OSK audit JSON。
- `artifacts/batch270-home-catalog/`：最新前一輪 Home/Catalog 四尺寸 JPEG 與 error fixture，供下一批視覺比較。
- `artifacts/batch272-multiplayer-lobby/`：本批四尺寸 Chromium 截圖、Stable 並排比較圖及差距表。
- `artifacts/osu-reference/`：使用者提供的五張 osu! Stable 介面參考圖，屬永久視覺基準。

## 從主要 ZIP 移除的產物類別
- 其餘舊 `artifacts/batch*-regression/`／`batch*-*` 目錄內可再生的歷史測試日誌、重複截圖與舊狀態 JSON。這些結果的摘要仍存在工作狀態與交接文件中；本次不宣稱已建立外部二進位封存。
- 沒有刪除正式原始碼、測試程式、測試所需 fixture、來源 ZIP 或本批最新視覺證據。

## 驗證
- 在刪除前搜尋 `tests/`、`tools/` 對 `artifacts/` 的直接引用，確認需要執行期讀取的 `batch245-regression` 與 `batch252-regression` 保留。
- 交付前必須執行 `sha256sum -c MANIFEST.sha256` 與 ZIP integrity check。

## Batch283 最新視覺證據
- Catalog 與 osu! Stable Song Select 並排圖：`artifacts/batch283-catalog-stable/catalog-vs-osu-stable-1920x1080.jpg`。
- 最新四尺寸 Home/Catalog 截圖、Dock 展開圖位於 `artifacts/batch283-catalog-stable/`。Catalog 為明確標示的六筆 layout fixture，不代表正式曲庫或 live artwork。
- 差距表：`docs/OSU_CATALOG_VISUAL_GAP_BATCH283.md`；交付摘要：`docs/BATCH283_DELIVERY_SUMMARY.md`。
- Batch283 四尺寸 browser 148/148，focused Node 39/39，Architecture 1,358/0。人工 Stable gate仍未通過。
