# Multiplayer Room State Machine Contract（Batch 91）

## Scope

`src/multiplayer/room-state-machine.js` is a pure state-transition module intended to be hosted behind a trusted server boundary. It has no DOM, network transport, storage, timer loop, or dependency on the single-player app. It is not wired into app startup and does not make multiplayer a requirement for AMQ／EMQ／MIX.

## State and revision

- Room schema version is `1`; each room starts at revision `0` with one host in `lobby`.
- Every effective state change increments `revision` exactly once. `expectedRevision` is optional optimistic concurrency protection; stale commands fail with `ROOM_REVISION_CONFLICT` and report expected／actual revision.
- An unchanged ready command is a no-op and does not increment revision.
- `getSnapshot(state, sinceRevision, authenticatedViewerId)` returns `unchanged: true` when revisions match, otherwise a frozen detached snapshot. During an active round, other players' answer text is redacted; an authenticated viewer may see their own answer. Once the round closes, answers become visible in snapshots.
- The transport/server must derive `authenticatedViewerId` from its authenticated connection, never trust a client-supplied viewer ID. The module rejects a viewer ID that is not a current room member, but that check does not authenticate the ID. The module does not implement authentication.

## Commands and authority

- `player.join`: lobby only, unique member ID, capacity 2–64, max display name 64 chars.
- `player.ready`: lobby only, boolean readiness.
- `player.leave`: lobby only. If host leaves, host transfers to the earliest remaining member; an empty room closes.
- `round.start`: host only, lobby only, at least two players, all non-host players ready, unique round ID, server-supplied `questionId`, duration 1–300 seconds (default 15 seconds). Starting clears ready flags.
- `answer.submit`: current member, active matching round, one answer per player, non-empty answer up to 256 chars. Receipt time is supplied by the server clock; client timestamps are ignored.
- `round.close`: host only; moves active round to closed and returns room to lobby.
- `room.close`: host only and no active round.

Errors have stable `code` values for transport mapping. Commands that fail do not mutate the caller's frozen state. State transitions return a new frozen state and a frozen event; answer text is intentionally excluded from emitted answer events.

## Security and limits

- This module is pure business logic, not a security boundary by itself. Production integration must authenticate peers, authorize room membership at the transport boundary, rate-limit commands, persist or otherwise protect authoritative state as required, and broadcast per-viewer projected snapshots.
- The room state machine records submitted text and trusted receipt time but deliberately does not decide answer correctness, scoring, or anti-cheat policy. Those need a separately specified server-owned assessment contract; client-provided correctness or client timestamps must not be trusted.
- Reconnect/resync is currently snapshot-by-revision, not a delta log. If revisions differ, request a full projected snapshot; if equal, no payload state is required.
- No live server, websocket transport, OAuth, browser multiplayer, or cross-client interoperability test is included in this batch.
