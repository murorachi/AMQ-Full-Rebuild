# Batch 53 交接：持久化錯誤 UI 投影

## 結果

Batch 53 修正個人清單操作失敗仍可能顯示成功文案的缺陷，並補強 QuizPanel 對 familiarity、SRS 與 AMQ blacklist persistence 狀態的顯示。

## 變更

- `showLibraryResult(result, successMessage, failureMessage)` 明確分離成功／失敗文案。看番狀態或 membership 寫入失敗不會再顯示「已更新／已加入」。跨 store 部分成功使用專用 failure message。
- 個人清單 UI 顯示 watchlist read/write blocked、recovery 與未解析 source-less legacy watch status。
- QuizPanel 顯示 AMQ／EMQ familiarity read-blocked 狀態，無需等下一次答題才出現提示。
- SRS blocked/error/recoveryAvailable/persisted=false 警告優先於先前的成功訊息，避免外部讀取失敗後仍顯示「已保存」。
- AMQ blacklist persistence warning 在 AMQ 與 MIX 模式都會顯示，因 MIX 的 AMQ 子池仍受該 blacklist 影響。

## 修改檔案

`src/ui/catalog-browser.js`、`src/ui/quiz-panel.js`、`tests/catalog-browser.integration.test.cjs`、`tests/quiz-panel.test.cjs`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`docs/FUNCTION_INVENTORY.md`、`docs/ACCEPTANCE.md`、`AI_START_HERE.md`、`MANIFEST.sha256`。

## 驗證

- `tests/*.test.cjs`：25/25 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- Architecture：459 passed／0 failed。
- Source audit：PASS；AMQ 38,821、EMQ 16,839。
- Mapper verification：PASS；Catalog 55,660，AMQ audio candidates 37,939，EMQ 16,839。
- Benchmark：5 iterations PASS（Node in-memory only）。
- JS/CJS syntax：PASS。
- Manifest 128 entries；ZIP 129 entries（含 manifest）；CRC PASS，無 missing／extra／hash mismatch。
- Browser E2E：仍 BLOCKED，既有 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重試相同導航方式。

## 下一批 Batch 54

1. 依必要功能真相表處理仍有明確契約且可安全驗證的 P1 缺口。
2. 強化 AudioService／QuizSession／mode switch 的取消、fallback、pause/resume、計時起點、舊 session 狀態發布與 dispose 清理回歸。
3. 對測試暴露的真實缺陷直接修正，避免只增加測試。
4. 保留真實瀏覽器、真實音訊、Windows 啟動與舊版相容性為未驗收狀態。
