# Batch263 交接：Home 主視覺與 Catalog 正常布局證據分離

## 基準與保護
- 工作副本由 Batch262 建立：`/mnt/data/AMQ_Batch263/AMQ_Batch263/`。
- Batch262 ZIP 未覆寫；本副本無 `.git`，未初始化 Git。
- AMQ／EMQ 原始資料不應在本批被修改；封包前已確認其 SHA-256 與既知值相同。

## 實作
- `src/styles/ui-design-landing.css`：Home 主視覺 art 區覆蓋整張 feature，標題與開始按鈕位於底部漸層上；調整 Home 兩列比例，空紀錄狀態最小高度降為 42px。
- `tests/batch263-home-catalog.browser.py`：新建 Batch263 四尺寸 browser harness；保存 `catalog-opaque-origin-error-*` 作為環境錯誤證據，另保存 `catalog-data-fixture-*` 以六筆明確測試記錄與 SVG 觀察正式 DOM/CSS 布局。fixture 不代表正式資料 runtime 或 IndexedDB 成功。
- 更新 `WORK_STATUS.md`、`MASTER_CHECKLIST.md`、`UI_TRACEABILITY.md`、`DESIGN_GAP_REGISTER.md`、`NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`。

## 驗證
- `python tests/batch263-home-catalog.browser.py`：47/47 PASS，尺寸 1920×1080、1440×900、1024×768、390×844。
- `python tests/batch262-home-artwork.browser.py`：10/10 PASS（明確注入測試 adapter）。
- `python tests/app-shell.browser.test.py`：144/144 PASS。
- `node tests/app-shell-navigation.contract.test.cjs`：2/2 PASS。
- `node tests/skin-theme-adapter.test.cjs`：20/20 PASS。
- `node tests/catalog-browser.test.cjs`：6/6 PASS。
- `node tests/ui-shell-css.contract.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：1,293 PASS／0 FAIL。
- `python -m py_compile tests/batch263-home-catalog.browser.py`：PASS。

## 封包
- `MANIFEST.sha256`：7,645 entries；ZIP 內逐項 hash 比對 7,645/7,645，缺漏 0、不符 0。ZIP CRC 與外部 SHA-256 sidecar 通過。
- AMQ raw data SHA-256：`692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ raw data SHA-256：`88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 未驗收／限制
- 全量 Node suite 本批未執行。
- HTTP-origin IndexedDB 仍有已知環境政策 blocker；本批未重試同類 probe。
- Live ANN/VNDB artwork、真實曲庫載入、Windows／實機、最終 osu! 視覺驗收仍未完成。
- Home 空狀態仍顯示 fallback，缺少真實 artwork 的視覺說服力；Catalog fixture 只是布局畫面，不是正常資料成功證據。

## 下一批
依 `docs/NEXT_SESSION_PROMPT.md` 的 Batch264：先保留 Catalog 正式資料 gate 的真實限制，再直接做 Quiz 正式 UI 視覺批次與四尺寸截圖，不只補文件／測試。
