# AMQ 新版重建交接：Batch141（跨工具 SQLite diagnostics 一致性）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 維持唯讀。

## 修改
- 擴充 `tests/database-integrity.test.cjs`，以同一 temporary SQLite fixture 建立 active／closed rooms、command replay row 與 SRS assessment event。
- 對同一 DB 執行 `inspect-private-server-database.cjs`、`report-multiplayer-retention.cjs`、`backup-private-server.cjs`、`verify-private-server-backup.cjs`，確認歷史表筆數一致。
- 驗證 active／closed／unknown phase 分類 1／1／0，backup／verify 的 `missingOptionalTables` 為空；不改變 production data path。

## Targeted test
- `node --test tests/database-integrity.test.cjs`：5/5 PASS。
- 最終完整回歸與封包結果以 `docs/WORK_STATUS.md` Batch141 收尾段落為準。

## 下一步
Batch142：以大型合成歷史 DB 驗證 diagnostics 的 aggregate query／記憶體界線；不刪資料、不 migration、不輸出逐房或玩家資料。
