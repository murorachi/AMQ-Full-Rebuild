# Batch250 Handoff：Backup／Restore touch target 與持久化 gate

## 基準
- 唯讀基準：Batch249 ZIP `/mnt/data/AMQ_Full_Rebuild_Batch249_Settings_Learning_Multiplayer_20261029.zip`，SHA-256 `5b844eb274a31b117e1b7f2605f1576d828d7b0e9e85b6f44480df87e850fde5`。
- 獨立工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch250_Backup_Restore_Closure/AMQ_Full_Rebuild_Batch245_Project`；無 Git repository，未初始化 `.git`。

## 修改
- `src/styles/ui-shell.css`：Settings backup/restore、database update、Skin import actions 的 `min-height` 由 40px 改為 44px。
- `tests/ui-shell-css.contract.test.cjs`：新增 44px touch target contract。
- `tests/batch250-backup-restore.browser.py`：新增正式 Settings route Chromium test，驗證三個 backup/restore buttons 的 computed min-height／實際尺寸、桌面與 390px 溢位、page errors，並輸出截圖。

## 驗證
- Backup/restore、panel、multiplayer backup semantics、private server backup、CSS focused tests：12/12 PASS。
- Backup/Restore Chromium：8/8 PASS。
- Node 90/90 test files 最終逐檔 exit 0；parallel run 中 `audio-service.test.cjs` 曾因計時負載短暫失敗，獨立重跑 PASS。
- Architecture 1,279/0；JS/CJS syntax 193/193；Python compile 13/13。
- AMQ／EMQ raw data SHA-256 unchanged。

## 持久化 gate
既有 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 沒有可證明的環境變化，本批不重試相同 probe。Backup/restore 的 Storage fixture 證明 preflight、checksum、schema/key allowlist、rollback、rollback failure warning、stale preflight 與 busy lock；不代表真實 HTTP-origin IndexedDB save/reload 已驗收。

## 未解／下一批
HTTP-origin IndexedDB、live audio/catalog/artwork、Windows／實機、Candidate302／Candidate382 Stage 0、native osu!stable fidelity 未驗收。35 wired Skin roles 未逐一 browser closure，13 unsupported 保持 unsupported。下一批 Batch251 做跨頁端到端、鍵盤／ARIA／responsive 與交付候選完整性。
