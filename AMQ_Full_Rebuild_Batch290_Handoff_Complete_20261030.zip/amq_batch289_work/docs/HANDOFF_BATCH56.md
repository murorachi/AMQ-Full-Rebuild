# Batch 56 交接：模式切換後舊 Catalog 失效化

## 摘要

Batch 56 修正一個可重現的 P1 狀態錯誤：當 AMQ 已成功載入、目前沒有活動中的 Repository request 時，使用者切換到 EMQ／MIX，舊實作的 `repository.cancel()` 會因 `active === null` 直接回傳 `false`，而已發布的 AMQ Catalog 與 `dataStatus=loaded` 會繼續留在共享狀態。這會讓新模式在下一次載入前短暫看到舊來源資料。

## 實作

- `src/data/repository.js`
  - 保留 `cancel()` 的原始責任：只取消活動中的 request，沒有活動 request 時回傳 `false`。
  - 新增 `invalidate()`：若有活動 request，先 abort；然後立即呼叫 load-state controller `reset()`，增加 generation、清除 Catalog 並將 `dataStatus` 重設為 `not-loaded`。
  - 舊 request 即使忽略 abort 並稍後完成，也因 generation 已變更而無法發布結果。
- `src/data/runtime-bootstrap.js`
  - 共享 state 的 `mode` 變更時改呼叫 `repository.invalidate()`。
  - 不自動重載新模式，也不接管 QuizSession／AudioService 的責任。
- `tests/data-pipeline.integration.test.cjs`
  - 新增已載入後切換模式的回歸：AMQ 載入後切換 EMQ，狀態立即回到 `not-loaded`，舊 Catalog 立即為 `null`；重新載入後只包含 EMQ 記錄。
- 文件更新：`docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`、`README_FIRST.md`。

## 測試證據

最終程式碼與文件版本執行：

- `tests/*.test.cjs`：25/25 個測試腳本 exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：459 passed，0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 首歌、EMQ 16,839 首歌；重複 song/work ID、dangling work references 與跨來源衝突均為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660 筆；音訊候選總數 AMQ 113,817、EMQ 20,085。候選數不代表音訊可播放。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，5 次觀測執行完成；不是效能保證或產品驗收。
- `node --check` 對 `src/`、`tests/`、`tools/` 所有 JS／CJS：PASS。
- `data.js` SHA-256 維持 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`。
- `emq-data.js` SHA-256 維持 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

日誌位於 `/mnt/data/amq_batch56_logs/`。本批未執行真實瀏覽器 E2E；不將 Node／VM 測試當成瀏覽器驗收。

## 基準與環境

- 工作副本：`/mnt/data/amq_work/AMQ_Full_Rebuild_Starter_Pack`。
- 此副本沒有 `.git` metadata；沒有初始化 Git、commit 或 push。
- 沒有修改正式基準或來源資料。Candidate381 只作靜態參考，不當成 Candidate382 Stage 0；不再搜尋 Candidate302。
- Chromium binary 存在，但既有瀏覽器頁面導覽曾回報 `ERR_BLOCKED_BY_ADMINISTRATOR`。本批不重試相同導覽方式，也沒有新的正式基準檔案可解除阻塞。

## 尚未驗收／阻塞

- 真實瀏覽器 UI／responsive／鍵盤與跨分頁 storage。
- 真實音訊可聽性與乾淨 Windows 啟動。
- Candidate302／Candidate382 Stage 0 相容性。
- `aniFavorites_v1` 身份，以及舊 source-less `animeIds`／watch status 的安全遷移。

## 下一批 Batch 57

1. 先讀最新主清單與本交接，不重做 Batch 56。
2. 檢查 Repository `invalidate()` 與 QuizPanel／CatalogBrowser 對 `not-loaded` 的狀態投影是否在 Node integration 中有完整覆蓋；只補缺少的核心狀態測試，不做 UI 視覺改版。
3. 檢查 mode change 與外部 caller cancellation 的邊界，確保 invalidate 後舊請求不會清除新一代狀態。
4. 全量 Node／tooling／architecture／source audit／mapper／benchmark／syntax，更新唯一主清單與工作狀態並重建 ZIP。
5. 真實瀏覽器／音訊／正式基準維持 BLOCKED，除非出現新的可操作環境或正式檔案證據。
