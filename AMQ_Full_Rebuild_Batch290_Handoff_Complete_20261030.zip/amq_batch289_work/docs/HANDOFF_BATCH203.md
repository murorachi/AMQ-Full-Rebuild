# Batch203 交接：OSK 人工覆寫候選治理

本批不再把所有圖片塞入每個角色的下拉選單。Mapping Studio 預設只列 stable 檔名契約命中的候選；其他圖片必須透過折疊區主動啟用，並明確標示「非自動建議」。已保存的人工覆寫仍會在該角色保留可選項。

測試：`python tests/osk-import-panel.browser.test.py` 12/12 PASS；`node --check src/ui/skin-import-panel.js` PASS；`python -m py_compile tests/osk-import-panel.browser.test.py` PASS。

未完成：正式 UI 尚未逐頁達成 osu!stable 結構與素材語意整合；真實 `.osk` 與 HTTP-origin IndexedDB reload 未驗收；沒有覆蓋 Candidate302／Candidate382 Stage 0。工作副本無 Git repository，未初始化。

下一批優先：逐頁核對 stable 資產與正式 DOM/CSS；驗證角色預覽在正式元件即時反映、apply/reset 不殘留舊素材；擴充真實資源 fixture。UI 未完成前持續 UI 優先，不得宣告結案。
