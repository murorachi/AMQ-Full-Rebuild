# Batch 99 交接包

日期：2026-10-27

## 本批成果
- `src/multiplayer/room-command-service.js`：新命令只讀取一次可信 server clock，rate-limit accounting 與 room transition 共用同一 timestamp。修正先前 dispatch 限流與 `dispatchOnce()` 各讀一次時鐘、可能讓單一命令跨越不同 deadline／window 時刻的邊界。
- `tests/multiplayer-room-command-service.test.cjs`：新增 ticking clock 測試，證明單次新命令只讀一次時間、event 使用該時間，成功 idempotent replay 不讀取新時間。
- 新增 exact sliding-window cutoff 測試：窗口內超限 `retryAfterMs` 精確值可驗證；到達 cutoff 時舊 timestamp 過期並接受新命令。
- 更新主清單、工作狀態、架構、驗收、下一工作提示與 `AI_START_HERE.md`。

## 最終驗證證據
- 44 個非-tooling `tests/*.test.cjs` 逐檔執行：44/44 exit 0。
- `node --test tests/tooling.test.cjs`：9/9 PASS。第一次合併執行因環境 120 秒總 timeout 中止，後續已分開重跑並取得完整結果。
- `node tools/check-architecture.cjs`：719 passed／0 failed。
- `src/`、`tests/`、`tools/` JS／CJS syntax：100/100 PASS。
- Source audit PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；duplicate IDs、dangling references、cross-source collisions 均 0。
- Source mapper PASS：Catalog 55,660 records。
- 5 次 Catalog benchmark PASS；Catalog build 約 1,083.214 ms（本機 Node 觀察值，不代表瀏覽器效能）。
- 資料資產 hash unchanged：`data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 未完成／阻塞
1. rate limit／idempotency 仍為單一 service instance 記憶體保護，非正式 transport／跨節點保證。
2. durable idempotency、per-room serialization、auth／transport、reconnect、多 client E2E 尚未實作。
3. 多人 SRS persistence 需產品決策，不得寫入無 user identity 的共享 localStorage key。
4. 真實瀏覽器／音訊／storage／外部 API／多人互通未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試相同路徑。

## 基準／版本管理
- 從 Batch98 ZIP 解壓的獨立工作副本繼續，未覆蓋來源 ZIP。
- 工作包沒有 `.git`；未初始化 Git、未假造 branch／commit。
- Candidate302、Candidate382 Stage 0 與來源資料資產未修改。

## 下一批
- 檢查 `round.close`／`room.close` 的相同 requestId 重放、失敗命令 cache pollution 與 revision contract。
- 只修正能由測試證實的缺陷；不把純邏輯 service 宣稱為正式多人伺服器。
