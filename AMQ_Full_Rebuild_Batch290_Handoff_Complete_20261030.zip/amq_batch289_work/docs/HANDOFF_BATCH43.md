# Batch 43 交接：持久化狀態契約與部分成功恢復

## 已完成
- History summary pending 不再被 `summaryPersisted` 當成已保存；新增 `fullyPersisted`，append 回傳分離 detail／summary 狀態。
- History partial success 測試覆蓋 detail 寫入成功、summary 寫入失敗、重建 store 由 detail 重建摘要、summary 恢復保存且總數不重複。
- SRS persist／flush write failure 會通知 subscribers，status 新增 `persisted`。
- Blacklist song／work write failure 會通知 subscribers；`songWriteError`／`workWriteError` 與 read error 分開，quiz UI 分別呈現讀取與保存錯誤。
- Familiarity storage event 的讀取失敗不再回報持久化成功。
- 新增 familiarity、blacklist、SRS storage clear／read recovery／dispose 測試。

## 修改檔案
- `src/persistence/familiarity-store.js`
- `src/persistence/blacklist-store.js`
- `src/persistence/srs-store.js`
- `src/persistence/quiz-history-store.js`
- `src/ui/quiz-panel.js`
- `tests/familiarity-store.test.cjs`
- `tests/blacklist-store.test.cjs`
- `tests/srs-store.test.cjs`
- `tests/quiz-history-store.test.cjs`
- `docs/DATA_CONTRACT.md`
- `docs/ARCHITECTURE.md`
- `docs/FUNCTION_INVENTORY.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `AI_START_HERE.md`
- `docs/NEXT_SESSION_PROMPT.md`

## 驗證
- `tests/*.test.cjs`：22/22 scripts exit 0。
- Focused suites：familiarity 9/9、blacklist 11/11、SRS 18/18、quiz history 13/13。
- Tooling 8/8；architecture 430 passed／0 failed。
- Source audit PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；無重複 ID／dangling references／跨來源 ID collisions。
- Mapper verifier PASS：Catalog 55,660；AMQ audio candidates 37,939、EMQ 16,839。
- Benchmark 5 iterations PASS；所有 JS/CJS syntax PASS。
- 來源 asset SHA-256 unchanged。完整日誌位於 `/mnt/data/amq_batch43_logs/`。
- ZIP `/mnt/data/AMQ_Full_Rebuild_Batch43_PersistenceContract_20261027.zip`，4,400,722 bytes；manifest 113/113 一致、CRC 通過；SHA-256 `45c5dc2d96e02552f99aa0c11f2b2ffbec66b26131df5d80339da648981af75e`。

## 限制
- history detail／summary 仍分 key，無跨 key 原子交易保證；本批只證明 summary 寫入失敗後能由可讀 detail 重建目前統計，並以 processed IDs 避免重複計數。
- 真實瀏覽器 E2E 仍因先前 `ERR_BLOCKED_BY_ADMINISTRATOR` 導覽阻塞；沒有重試相同方法。
- 無 `.git` metadata；未初始化 Git、未 commit／push。來源資產及使用者指定參考基準不得修改。

## Batch 44 下一步
1. 建立必要功能到模組／測試的跨模組驗收矩陣。
2. 優先補足可在 Node 驗證的核心整合路徑與模式切換回歸。
3. 只修正由整合測試證實的缺陷，避免無目的重寫穩定模組。
4. 全量回歸、更新清單、manifest 與完整 ZIP；UI／CSS 大重構仍排在階段 5。
