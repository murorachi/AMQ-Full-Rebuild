# Batch 90 交接包（2026-10-27）

## 本批目標

加固 Batch89 已建立的外部服務請求邊界與多人協定資料契約，避免未經授權的認證標頭／重新導向，以及 payload 在驗證後遭呼叫端或消費端修改。

## 開工確認

- 已讀取 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`PROJECT_RULES.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md`、`docs/ARCHITECTURE.md`、`docs/ACCEPTANCE.md` 與 Batch89 handoff／契約。
- 以 Batch89 ZIP 為來源解壓至獨立工作副本。工作副本沒有 `.git`；`git status` 回報不是 Git repository，沒有初始化 Git、沒有假造 branch／commit。
- Candidate302 與 Candidate382 Stage 0 不在交付包內；沒有修改／覆蓋基準。`src/data/assets/data.js` SHA-256 為 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`，`src/data/assets/emq-data.js` SHA-256 為 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，均保持不變。
- Node v22.16.0、npm 10.9.2 可用；無 `package.json`，使用 Node 內建工具與 `node:test`。
- 已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 仍是既有瀏覽器導覽阻塞，本批沒有重試相同路徑。

## 實作

### 1. 外部服務 client

修改 `src/integrations/external-service-adapter.js`：

- 禁止呼叫端自行傳入任何大小寫形式的 `Authorization` header；認證只能由明確配置的 token provider 產生。
- Fetch 設定 `credentials: "omit"`，避免意外附帶瀏覽器 cookie。
- Fetch 設定 `redirect: "error"`，拒絕 redirect，避免認證請求沿重新導向進入非預期資源。
- 檢查認證 header 在建立請求 timer／active operation 之前完成，拒絕時不會建立未清理的請求狀態。

新增／擴充 `tests/external-service-adapter.test.cjs`，驗證 Authorization header 注入會在 fetch 前拒絕，並確認 `credentials`／`redirect` 設定。

### 2. 多人協定 payload

修改 `src/multiplayer/protocol.js`：

- 先把 payload 序列化成 JSON，拒絕 circular／BigInt／非 JSON payload。
- 以序列化後的實際 UTF-8 位元組數檢查大小上限。
- 解析成獨立副本後再驗證 schema，避免輸入物件的後續修改影響已驗證資料。
- 遞迴凍結 payload 的巢狀物件與陣列；回傳 envelope 不再只淺層凍結。

擴充 `tests/multiplayer-protocol.test.cjs`，覆蓋來源輸入修改、巢狀不可變性、循環參照與 BigInt。

## 驗證結果

- `tests/external-service-adapter.test.cjs`：PASS，新增未授權 Authorization header／fetch options 回歸。
- `tests/multiplayer-protocol.test.cjs`：PASS，新增 payload copy／deep-freeze／JSON 序列化回歸。
- 全部 42 個 `tests/*.test.cjs`：41 個非-tooling 腳本逐檔 exit 0；`tests/tooling.test.cjs` 另外以 `node --test tests/tooling.test.cjs` 執行，9/9 PASS。串行整批命令在 tooling 子測試開始後超出工具時間上限，因此不宣稱該整批命令本身通過；所有腳本都有各自成功證據。
- `node tools/check-architecture.cjs`：677 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 songs／9,516 works、EMQ 16,839 songs／6,645 works，重複 ID、懸空參照、跨來源衝突皆 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，Catalog 55,660 筆。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；Catalog build 約 1,213.741 ms，僅為本機 Node 觀察值，不是瀏覽器效能保證。
- 全專案 JavaScript／CJS 語法：94/94 PASS。
- `MANIFEST.sha256`：207 個項目、missing 0、hash mismatch 0、extra 0。來源資產 hash 已再次核對。
- 完整 ZIP：交付前建立並驗證 CRC 與逐項內容 hash；ZIP 含 manifest 本身，manifest 不包含自身 hash。

## 未完成／阻塞

- 外部服務 feature endpoints、OAuth callback／refresh、MAL 正式 quota、各服務實際資料映射與真實 API 呼叫仍未完成。
- 多人 transport、server authority、房間生命週期、重新連線／同步恢復、權限、計時／計分權威與 anti-cheat 仍未實作。
- 真實瀏覽器／網路／OAuth／多人互通未驗收；Node contract tests 不等於 E2E。
- 跨分頁 storage、真實音訊與其他先前瀏覽器驗收仍被已知環境阻塞。

## 下一步

1. 以官方文件為依據，先完成 AniList／MAL／VNDB 各自 feature adapter 的請求／回應 schema 與取消測試；不得宣稱真實帳號同步完成。
2. 為多人模式建立純邏輯 room state machine，先明確定義 server-authoritative 成員／狀態轉移、問題 round ID、重複答題防護及 snapshot revision；server／transport 仍獨立。
3. 瀏覽器通道解除阻塞後補做外部 API、音訊、storage 與多人互通實測。UI／CSS 大重構最後做。
