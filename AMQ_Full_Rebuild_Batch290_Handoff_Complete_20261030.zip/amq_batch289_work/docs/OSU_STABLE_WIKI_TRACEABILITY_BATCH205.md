# osu!stable Wiki 對照矩陣（Batch205）

日期：2026-10-28。這份矩陣是實作與驗收依據，不代表已經完成全部 UI 重建。

## 第一手規格來源

- Client / Interface：<https://osu.ppy.sh/wiki/en/Client/Interface>
- Skinning / Interface：<https://osu.ppy.sh/wiki/en/Skinning/Interface>
- Skinning / skin.ini：<https://osu.ppy.sh/wiki/en/Skinning/skin.ini>
- Client / Options：<https://osu.ppy.sh/wiki/en/Client/Options>

官方 Client / Interface 說明 stable 選曲畫面有歌曲／難度資訊、分組排序、搜尋、beatmap carousel 與選取狀態。官方 Skinning / Interface 將 `menu-button-background.png` 定義為 beatmap difficulty button 等特定用途，`songselect-bottom.png` 是橫向延展的選曲底框；它們不是通用網站面板或播放器底座素材。`star.png` 的用途是難度星級，不能在 AMQ 缺少對應難度資料時虛構星級。

## 本批逐項決策

| stable 元件／行為 | Wiki 語義 | AMQ 落點 | 決策／狀態 |
|---|---|---|---|
| `menu-background.jpg` | stable 主選單背景 | `#page-home` 背景 | 保留明確對應；cover viewport。首頁背景不是歌曲封面。 |
| `menu-button-background.png` | 選曲難度按鈕背景，另用於特定 scoreboard；有 state tint 與縮圖幾何 | `#catalog-rows tr` 的歌曲列背景／選取狀態 | 保留在歌曲列語境；移除詳細資訊、播放器、多人、學習及設定面板的自動對應。 |
| `selection-bar.png` | 選曲選取條，依 skin version 有行為／尺寸差異 | 已選歌曲列 | 保留；以明確選取狀態使用，不當一般列背景。 |
| `selection-tab.png` | 選曲分頁素材 | 導覽／選曲分頁 | 保留，但實際外觀仍需完整瀏覽器驗收。 |
| `songselect-top.png` | 選曲上框架，可依 stable 規則重複／延展 | Catalog 外框 | 保留在選曲頁。 |
| `songselect-bottom.png` | stable 選曲頁底框，延展至畫面寬度；過高會影響點擊區 | Catalog 底框 | 不再自動對應獨立的 AMQ player dock。 |
| `star.png` | 難度星級視覺 | AMQ 難度標記 | 僅在有真實、語義相同的難度值時使用；不生成假數據。 |
| `ranking-*.png` | stable 評級／排名視覺 | AMQ 結算評級候選 | 不把 osu! 評級圖直接當猜歌答對／答錯語義；必須人工明確映射或使用文字 fallback。 |
| `skin.ini` colours / version | 有版本及語義化顏色設定，命令大小寫有要求 | 主題解析與 token | 未支援的鍵保留原文；不可將 `ComboN` 全部當成全站主題色。 |
| Song Select search/group/sort | 搜尋、分組、排序及選取為真實操作模型 | Catalog 左篩選／中列表／右詳情 | 沿用 AMQ 真實篩選／排序狀態；不因視覺重建產生假功能或假統計。 |

## 本批程式變更

- 更新 `stable-asset-manifest.v1.json`，限制 `menu-button-background.png` 與 `songselect-bottom.png` 的可建議角色範圍。
- 更新 `amq-skin-role-manifest.v1.json`：歌曲詳情、播放器底座、多人、學習與設定面板改為 AMQ extension slot，不再冒充有 verified stable 對應素材。
- 同步 `src/skins/skin-contract.js` 的 runtime manifest。
- 增加測試，防止這些角色再次被錯誤掛到通用面板。

## 尚未驗收

本批完成的是有 Wiki 證據支援的素材語義修正，不代表五個正式頁面已逐像素還原 stable。尚需逐頁驗收選曲資料密度／狀態、首頁入口互動、猜歌答題／揭曉、學習歷史、設定表單、手機尺寸、真實 `.osk` 與 HTTP-origin IndexedDB。官方 Wiki 不是 DOM/CSS 規格，無法單憑它證明 AMQ 頁面視覺完成。
