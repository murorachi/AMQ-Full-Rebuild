# Batch259 Handoff：設計落地流程與正式版骨架第一切片

## 基準與安全
- 唯讀 Batch258 ZIP SHA-256：`94eef9de08c6b8b3969bd2919e66ce8139c2cf71cd7232195d4a2b0dbb0916a6`。
- 工作副本無 `.git`，未初始化 Git。Candidate302／Candidate382 不作為新版基準。
- 原始 AMQ／EMQ 資料檔未修改。

## 本批實作
- 新增 `docs/DESIGN_LANDING_FLOW.md`，將視覺驗收設為阻擋式 Gate 0–6。
- 新增 `docs/DESIGN_GAP_REGISTER.md`，登記 10 項正式版視覺／架構落差。
- 新增 `src/styles/ui-design-landing.css` 並在正式 `src/index.html` 載入：緊湊頂欄、固定左側導航 rail、低圓角深色工作區。
- `src/ui/app-shell.js` 不再於 Home 隱藏全域導航；首頁返回按鈕在 Home 設 `aria-current="page"`。
- 更新 `tests/app-shell.browser.test.py` 的 runtime skin role 數量契約：正式 adapter 實際為 36 roles，不再錯誤寫死 35。
- 新增 `tests/batch259-design-landing.browser.py` 與 1920×1080、1440×900、390×844 截圖。

## 驗證結果
- `python tests/app-shell.browser.test.py`: **150/150 PASS**。
- `python tests/batch259-design-landing.browser.py`: **17/17 PASS**。涵蓋導航在 Home／Catalog 常駐、aria-current、桌面整頁垂直溢位、無水平溢位、0 page errors。
- 截圖：`artifacts/batch259-design-landing/`。

## 尚未視覺驗收／不可宣稱完成
- 首頁仍保留原本大型圓盤主視覺與空白構圖，未達「一眼像 osu!」的最終門檻。
- Catalog prototype 仍未整合到正式 `src/`，正式 Catalog／AudioService 狀態 owner 尚未完成接線。
- Quiz／Settings／Results 尚未完成逐頁視覺差異關閉。
- 本批未執行全量 92 個 Node test files；不得宣稱全量 Node PASS。
- Live audio、live artwork provider、真實 multiplayer server、Windows／實機未驗收。

## Batch260 下一批最高優先級
1. 重做正式 Home 可見構圖：主要入口直接可見，縮減無功能空白，加入真實作品／近期學習視覺區；不再以隱藏式圓盤作為唯一入口。
2. 將原型 Catalog 的左篩選／中央封面曲目列表／右側詳情／底部播放 Dock 布局移入正式 `src/`，但不得把 mock-data 當真實曲庫。
3. 接回既有 Catalog／AudioService owner，保留搜尋、篩選、排序、選擇、播放與錯誤 fallback。
4. 1920×1080 截圖與差異表為必做驗收；P0 差距未關閉不得標記視覺通過。
5. 跑 app-shell、Home/Catalog、skin role 相關 browser tests；每次修正同步更新測試與主清單。
