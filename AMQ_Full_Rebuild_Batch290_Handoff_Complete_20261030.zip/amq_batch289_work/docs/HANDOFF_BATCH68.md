# AMQ Batch 68 交接：答案建議舊版匹配高亮與 EMQ 別名

日期：2026-10-27

## 本批目的

使用者同意直接參考後來的舊版 V82.x 實作，不再繼續考古 V48。這批以唯讀 `AMQ382(2).html`（實際標示 Candidate381）為參考，恢復答案下拉選單的匹配文字高亮與已證實的 EMQ 別名行為，保留 Batch 67 已驗收的 DOM／鍵盤／滑鼠生命週期修正。

## 參考證據

- 舊版 SHA-256：`65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`。
- 舊版 CSS：`#quizView .quizSuggestionMatch { color:var(--primary); font-weight:700; }`。
- 舊版函式：`mapQuizSuggestionTextV824()`、`quizSuggestionHighlightRangesV824()`、`renderQuizSuggestionLabelV824()`、`buildSuggestions()`。
- 舊版候選排序可見規則：標籤字元數短者優先，再依 NFKC／小寫 raw key、原始標籤穩定排序，保留前 25 項。本次沒有額外發明完全／前綴／部分三段式排序。
- 舊版 EMQ reader 可見 alias mapping：`ta`／`n` 作為歌曲標題別名、`aa` 作為歌手別名、`wa`／`wt`／`wn` 作為作品別名／列級標題。只映射實際存在的值。

## 修改檔案

- `src/ui/answer-suggestions.js`
  - 新增 `buildMatchEntries()`，保留 `buildMatches()` 的字串陣列 API。
  - 支援 raw、compact（忽略空白）、separator（空格／斜線／連字號）匹配的原始字元範圍映射。
  - 匹配部分以 `.quiz-suggestion-match` span 呈現，使用安全 text nodes，不將曲庫標籤解讀為 HTML。
  - query 改變時刷新高亮；一般相同 query 的 render 保留 option DOM 和 active index。
- `src/styles.css`：新增 `.quiz-suggestion-match` 主題強調色與粗體，未使用 `!important`。
- `src/data/source-mappers.js`：依舊版證據保留 EMQ `aliases`、`artistAliases`、`animeAliases`。
- `src/data/validate.js`：驗證歌手／作品別名欄位為字串陣列。
- `src/data/query-index.js`：支援搜尋及凍結三種別名陣列。
- `src/ui/quiz-panel.js`：有 metadata 時將歌曲／歌手／作品別名納入對應候選，不自行推測缺失資料。
- 測試更新：`tests/answer-suggestions.test.cjs`、`tests/quiz-panel.test.cjs`、`tests/source-mappers.test.cjs`、`tests/query-index.test.cjs`。
- 文件更新：`docs/DATA_CONTRACT.md`、`docs/FUNCTION_INVENTORY.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`。

## 驗證證據

- 全部 `tests/*.test.cjs`：27/27 scripts exit 0。
- `tests/answer-suggestions.test.cjs`：11/11 PASS。
- `tests/source-mappers.test.cjs`：7/7 PASS。
- `tests/query-index.test.cjs`：11/11 基本測試 PASS；額外排序／分組案例 PASS。
- `tests/quiz-panel.test.cjs`：PASS，含別名候選來源及原有 quiz lifecycle integration。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：480 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821 songs、EMQ 16,839 songs；無重複 ID／懸空關聯／跨來源 ID 衝突。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839、Catalog 55,660。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；55,660 筆 Catalog build 1031.172 ms。這是 Node 記憶體內觀察值，不是瀏覽器效能保證。
- 本批修改的 JS/CJS `node --check`：PASS。
- 資產 SHA-256 未變：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 尚未驗收／阻塞

1. 真實瀏覽器高亮色彩、IME、方向鍵、滑鼠點選、答案欄閃爍仍需使用者實機驗收。Fake DOM／Node 測試不等於瀏覽器 E2E。
2. 舊版繁體中文作品名稱候選依賴 `__aniChineseTitleAPIv8237`／`__aniEmqChineseTitleAPIv8259` 與設定開關；新版目前沒有等價 provider／設定接線。本批只保留 metadata 已存在時的候選能力，不宣稱中文名稱資料源完整恢復。
3. EMQ 真實音訊可聽性仍未驗收；本批未修改音訊候選規則。
4. 沒有 Git metadata；未初始化 Git、未 commit／push。
5. 未修改舊版 HTML、正式基準或原始曲庫資產。

## 下一步

- 先採用使用者對 Batch 68 的實機回報，記錄高亮、鍵盤／滑鼠／IME、閃爍是否通過。
- 再盤點如何以明確契約接回舊版 Chinese Title provider；沒有資料來源證據前，不虛構中文別名。
- 真實音訊仍獨立待驗收；UI／CSS 大重構仍排最後。
