# Batch247 交接：首頁與 Catalog 載入／重試狀態閉環

## 基準與安全
- 唯讀基準 ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch246_Mapping_Studio_Closure_20261029.zip`。
- SHA-256：`31baf02ac929ea90de39d1e6702c7d106634de449588ecdbf41cf8e9bdb4a550`，與 `.sha256` sidecar 一致。
- 獨立工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch247_Home_Catalog_Closure/AMQ_Full_Rebuild_Batch245_Project`。未發現 `.git`，未初始化；舊 ZIP 未覆蓋。
- AMQ／EMQ raw data 未修改；最後 hash 見 `artifacts/batch247-regression/raw-data-sha256.txt`。

## 修改檔案
- `src/ui/catalog-browser.js`：request-local `loadError` 優先於共享 state 過期的 `loading`；對完成但未接受、非 stale 且無 error 的結果顯示 `DATA_LOAD_NOT_ACCEPTED`，避免卡在 loading 或誤呈現空資料成功。
- `src/styles/ui-shell.css`：Catalog reload／retry control 的通用與高 specificity 規則均為 `min-height:44px`。
- `tests/catalog-browser.integration.test.cjs`：加入 unaccepted result、query-preserving retry、單一 reload listener 回歸。
- `tests/catalog-filter-layout.contract.test.cjs`：保護 failure precedence、error copy 與 unaccepted result contract。
- `tests/batch247-home-catalog.browser.py`：新增桌面／390px Catalog／首頁、retry computed target、reduced-motion、overflow 與 uncaught browser exception 驗證。
- `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/BATCH_ROADMAP.md`、`docs/UI_TRACEABILITY.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md`、`README_FIRST.md` 已更新；本 handoff 為新增文件。

## 驗證結果
- Catalog integration：PASS；Catalog controller tests 6/6；Catalog mode-switch integration：PASS；Catalog layout/state contract 13/13。
- Batch247 Home/Catalog Chromium：22/22 PASS；formal app-shell：150/150 PASS；Quiz/Results：19/19 PASS；Canvas：15/15 PASS；Mapping Studio／OSK harness：PASS。
- 全量 Node：90/90 `*.test.cjs` 檔案 exit 0。第一次串行 runner 超過 300 秒被中止；依 TSV 找出缺項並分批補跑，最終 90 個不同檔案皆 exit 0。因測試輸出混合 TAP 與自訂格式，未將不完整的 TAP `# pass` 數加總為總案例數。
- Architecture Checker：1,279 PASS／0 FAIL。
- JS/CJS syntax：193/193；Python harness compile：12/12。
- 瀏覽器證據與 Node logs：`artifacts/batch247-regression/`。
- 角色 audit：48 roles，35 wired、13 unsupported；執行 `node tools/audit-visual-role-coverage.cjs`。靜態報告不等於逐角色 browser 驗收。

## 未解／未驗收
- 13 visual roles 仍 unsupported；35 wired roles 未逐一 browser apply/fallback/reset。
- HTTP-origin IndexedDB save/reload 仍受既有 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋，本批沒有重試相同探測。
- Live catalog／artwork provider／audio、Windows／實機、Candidate302／Candidate382 Stage 0 與 native osu!stable fidelity 未驗收。
- 本批 Chromium 使用 inline assets／fixture；不宣稱真實 HTTP-origin、真實曲庫或外部 provider 驗收。

## 下一批 Batch248
1. 核對 `quiz-panel.js`、QuizSession、AudioService、round/result stores 的真實狀態 owner。
2. 測試 setup／playing／answered／timeout／audio error／empty pool／cancelled／unsaved result 狀態，不捏造本輪成績。
3. 驗證結果頁只讀取可證明的已保存 round record；保存失敗與部分資料需可見且可恢復。
4. 補齊 keyboard focus／ARIA／44px／390px／reduced-motion 回歸。
5. 保留 Batch246／247 的資料 fail-closed、Catalog failure/retry 與 Mapping Studio apply lifecycle contract。
