# Batch235 交接：Skin 語義映射、覆寫持久化與工作區視覺

日期：2026-10-29
基準：Batch234 完整專案 ZIP；原始 ZIP 保留，工作副本獨立，未初始化 `.git`。

## 官方規格與設計結論
- https://osu.ppy.sh/wiki/en/Skinning/Interface
- https://osu.ppy.sh/wiki/en/Skinning/skin.ini
- osu! Skin 是一組具備各自用途、尺寸、origin、tint/blend、動畫與版本語義的素材，不是通用 CSS theme。
- `menu-background.jpg` 是中心 cover；`menu-button-background.png` 是狀態染色的譜面難度／排行榜按鈕，並非泛用 panel；`songselect-top.png` 與 `songselect-bottom.png` 的伸縮／定位不同；`skin.ini` 版本及 `@2x` 會改變呈現方式。
- 詳見 `docs/SKIN_FRAMEWORK_CONTRACT.md`。

## 本批實作
- `skin-theme-store.js` schema v3，遷移 v1/v2 舊資料，保留 assets、mappings、roleMappings、skin.ini 與新增 overrides。
- `theme-transfer.js` portable format v1 加入 overrides 的驗證與往返保存；無 overrides 舊檔仍可匯入。
- `index.html` 將 resolver 放在 persistence 前載入，避免多套 schema validator。
- `theme-adapter.js` 支援單獨 layout overrides，並可在 reset 還原覆寫前 inline style。
- mapping studio 分頁全寬、桌面三欄／平板兩欄／手機一欄，透明素材預覽採 checkerboard + contain。
- 新增／更新 persistence、transfer、adapter、CSS contract 與 browser test。

## 測試證據
- Skin focused tests：33/33 PASS。
- Chromium OSK import + layout：15/15 assertions PASS。
- Chromium formal app shell：150/150 PASS。
- Architecture Checker：1,186 PASS／0 FAIL。
- 158 JS/CJS syntax PASS；2 Python harness py_compile PASS。
- 全量 Node test files 受命令時間限制中斷，未標記全量通過。

## 未完成與阻塞
- 尚未建立使用者可直接調整 overrides 的完整 UI；本批只打通資料、adapter 與 studio layout。
- HTTP-origin IndexedDB 仍受環境政策阻擋；瀏覽器 OSK 使用合成 fixture，不是真實 Skin 驗收。
- 尚未完成所有角色的 DOM/CSS consumer、fit/crop/anchor/state 逐一核對；不得宣稱完美一對一相容。
- Candidate302／Candidate382 Stage 0、live 曲庫／封面／音訊及實機 UI 仍未驗收。

## Batch236 優先
1. 新增正式 override editor，所有欄位由 resolver allowlist 驅動，套用／重置／保存／重載／匯出／匯入使用單一狀態 owner。
2. 建立逐角色 Skin traceability matrix，包含來源資產、官方尺寸/origin/tint/animation/version、實際 AMQ selector、CSS consumer、fit/crop/anchor、state variants、fallback 與驗收證據。
3. 清理錯誤自動映射；沒有語義等價的來源資產就保留 AMQ fallback，不能因檔名近似就套用。
4. 在可用時間內分批執行全量 Node tests，完整記錄成功／失敗／逾時。
5. 更新同一份 `WORK_STATUS.md`、`MASTER_CHECKLIST.md`、handoff、next prompt、Manifest 與 ZIP。
