# AMQ Batch 60 交接：Lifecycle timer 取消與 dispose 競態

日期：2026-10-27

## 目的與發現

檢查共享 state 與 lifecycle/runtime consumer 的跨模組邊界時，發現 `src/core/lifecycle.js` 的 timer 資源只依賴 `clearTimeout`／`clearInterval` 清除 host timer。若 callback 已經進入 host event queue，單純清除 timer 無法保證它不會執行。舊版 `timeout()` 雖然檢查 scope 的 `disposed`，但個別取消後已排入佇列的 callback 仍可能執行；`interval()` 原先也沒有 invocation-time active/disposed guard。

## 修改

- `src/core/lifecycle.js`
  - `timeout()` 新增每個 registration 的 `active` 狀態。callback 執行前先檢查 active，執行一次後立即失效；個別 cancel 與 scope dispose 都會設為 inactive。
  - `interval()` 新增每個 registration 的 `active` 狀態，callback 執行時同時檢查 active 與 scope `disposed`；個別 cancel 與 scope dispose 都會禁止後續遲到 callback。
  - 保留既有 timer 清理、scope LIFO cleanup、timeout one-shot 與 dispose 語義。
- `tests/core.test.cjs`
  - 新增 scope dispose 後已排入佇列的 interval callback 不得執行。
  - 新增個別取消 timeout 後已排入佇列 callback 不得執行。
  - 新增個別取消 interval 後已排入佇列 callback 不得執行。
  - 先以舊實作執行新增測試，核心結果 79/81，兩項個別取消案例失敗；修正後 81/81 PASS。
- `docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`：記錄 timer callback invocation-time cancellation 契約。
- `docs/MASTER_CHECKLIST.md`：新增 AMQ-657 至 AMQ-664。
- `docs/WORK_STATUS.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`、`README_FIRST.md`：更新批次狀態與下一步。

## 最終驗證

- `tests/*.test.cjs`：25/25 個測試腳本退出碼為 0。
- `node tests/core.test.cjs`：81/81 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：459 passed，0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS。AMQ 38,821 首、EMQ 16,839 首；重複 song/work ID、失效 song-work references、跨來源 ID collision 均為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS，Catalog 55,660 筆。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，5 次 Node 記憶體內基準；不代表瀏覽器效能。
- `node --check`：63 個 JS/CJS 檔案 PASS。
- 來源 SHA-256 未變：
  - `data.js`: `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`
  - `emq-data.js`: `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`
- 日誌：`/mnt/data/amq_batch60_logs/`。

## 交付檔案

- `src/core/lifecycle.js`
- `tests/core.test.cjs`
- `docs/ARCHITECTURE.md`
- `docs/DATA_CONTRACT.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH60.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `README_FIRST.md`
- `MANIFEST.sha256`（已重建）

## 尚未驗收／阻塞

- 真實瀏覽器 UI、響應式、鍵盤、跨分頁 localStorage、真實音訊可聽性與乾淨 Windows 啟動仍未驗收；沒有新瀏覽器環境，不重試已失敗的 Chromium CLI 導覽方式。
- Candidate302／Candidate382 Stage 0 相容性仍未驗收。Candidate381 僅作靜態參考。
- `aniFavorites_v1` 身份未證實；source-less legacy `animeIds`／watch status 不自動遷移。
- 工作副本無 `.git` metadata，未初始化 Git、未 commit／push；未修改正式基準與來源資料。

## 下一批 Batch 61

1. 檢查是否出現新的真實瀏覽器通道或正式基準證據；沒有就不重試舊方法。
2. 繼續檢查有明確契約的 lifecycle／runtime 跨模組邊界，先新增能重現問題的回歸測試，再實作。
3. 不猜測收藏身份、legacy source-less IDs 或 P2 行為；UI／CSS 大重構維持最後階段。
4. 完成全量驗證，更新唯一清單／狀態，重建並逐項驗證 Manifest／ZIP。
