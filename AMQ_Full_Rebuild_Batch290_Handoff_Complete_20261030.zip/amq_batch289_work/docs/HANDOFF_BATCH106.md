# Batch 106 交接包

日期：2026-10-28

## 本批成果
- 新增 `src/persistence/remote-srs-bridge.js`：以 memory-only storage 接入既有同步 SRS Store；登入時先 GET 目前 session 使用者的 AMQ／EMQ schedule；每個 source 的 PUT 由序列化 queue 依 revision 更新，不碰 browser localStorage。
- 更新 `src/ui/quiz-panel.js`，新增 `configureSrsStores()`，可在原本本機 store、遠端 store 與隔離空排程之間切換。
- 新增 `src/ui/account-panel.js` 與 `src/index.html` 帳號 UI：首次管理者 setup、登入、邀請碼註冊、管理者建立單次邀請、登出、同步狀態及 conflict reload。
- 更新 `src/app.js` lifecycle 組裝與 `START_LOCAL.bat`：優先以 Node 22.5+ 啟動 API／靜態 server；Python fallback 是 static-only。
- 更新 `docs/PRIVATE_SERVER.md`、`docs/ARCHITECTURE.md`、`docs/ACCEPTANCE.md`、`README_FIRST.md`、`AI_START_HERE.md`、`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/NEXT_SESSION_PROMPT.md`。
- 新增 `tests/remote-srs-bridge.test.cjs`、`tests/account-panel.integration.test.cjs`。

## 資料隔離與失敗語義
- 未登入：維持既有本機單人 SRS。
- 登入：先讀取 session 對應的 server schedules，使用 memory-only storage；舊 localStorage 沒有 user identity，不會自動上傳。
- 登出：回復本機 SRS；伺服器排程不會複製到共用 localStorage。
- 遠端 schedule 無法載入：切換隔離空排程，不顯示本機舊排程給登入帳號。
- 遠端保存 409／網路錯誤：停止後續盲目重試並顯示錯誤；使用者可選擇捨棄未同步變更並重新載入 server schedule。沒有自動合併或離線佇列。

## Targeted tests
- `node tests/quiz-panel.test.cjs`：PASS。
- `node tests/remote-srs-bridge.test.cjs`：3/3 PASS。
- `node tests/account-panel.integration.test.cjs`：PASS，覆蓋 setup、invite、login、remote SRS activation、logout 與 fail-closed remote-load。
- `node tests/app-lifecycle.integration.test.cjs`：PASS。
- `node tools/check-architecture.cjs`：755 passed／0 failed（targeted run）。

## 全量驗證結果
- 47/47 非-tooling `tests/*.test.cjs` scripts 逐檔 exit 0。
- `node --test tests/tooling.test.cjs`：9/9 PASS。
- `node tools/check-architecture.cjs`：755 passed／0 failed。
- `server/start.cjs` 實際啟動 smoke test：PASS，health API、`/src/` HTML 與 account-panel script 可正常提供。
- `src/`、`tests/`、`tools/`、`server/` JavaScript/CJS syntax：110/110 PASS。
- Source audit／mapper PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；Catalog 55,660 records；跨來源 song/work ID collision 0。
- 5 次 catalog benchmark PASS，build 觀察值約 1,402.071 ms（非瀏覽器效能保證）。
- 來源資產 hash unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 全量測試聚合命令在 tooling 階段曾被執行環境 timeout；47 個非-tooling scripts 已完成且 47/47 PASS，tooling 隨後獨立重跑 9/9 PASS，未把 timeout 視為通過。
- ZIP CRC PASS；Manifest 243 項，解壓後 missing 0、extras 0、hash mismatches 0；ZIP 共 259 entries（含目錄 entries）。

## 尚未完成
- 真實瀏覽器 E2E、音訊、多裝置多人連線尚未驗收；不可把 mocked DOM/HTTP tests 當成真實瀏覽器驗收。
- 遠端 conflict reload 會捨棄未同步變更；offline queue、merge、可靠 unload flush 尚未實作。
- `node:sqlite` ExperimentalWarning、記憶體 session、外網 HTTPS 部署限制沿用 Batch105 文件。

## 下一批
1. 需要使用者實機驗收 setup/login/logout、建立邀請、SRS 保存後重新載入；本工作環境的瀏覽器導覽受 `ERR_BLOCKED_BY_ADMINISTRATOR` 限制，不能代替真人驗收。
2. 補做多分頁／多裝置同時更新的 revision conflict E2E，確認不會靜默覆蓋；目前已有單分頁序列化、network failure 與 409 fail-closed 測試。
3. 設計離線佇列與多裝置合併策略，不可默認 last-write-wins。
4. 評估可靠 unload flush 與 session 持久化；目前 server restart 會使所有 session 失效。
