# Batch236 Handoff：OSK 真實樣本、幾何預覽與缺件診斷

## 基準與檔案
- 起始 ZIP：`AMQ_Full_Rebuild_Batch235_Skin_Framework_Alignment_20261029.zip`，SHA-256 `856665cee30db3ac7cd55730fde8c3016c967761ceb332cee275a9e86d6170a4`。
- Workspace：Batch235 ZIP 解壓後的獨立工作目錄；沒有 `.git`，沒有初始化。
- 使用者上傳 `aristia hima.osk` 僅用於本機 parser/UI 檢查，不會打包 Skin 圖片。

## Batch236 實作
- `src/skins/osk-importer.js`：`metadata.sectionBlocks` 保留重複 skin.ini 區塊；`auditSkinReferences` 檢查 Mania 圖片引用；支援 `selection-mode.png` 與 legacy `selection-mode-osu.png`。
- `src/skins/skin-geometry.js`：定義角色專屬預覽幾何語義。
- `src/ui/skin-import-panel.js`、`src/index.html`、`src/styles/ui-shell.css`：幾何說明、角色預覽模式與缺件警告。
- `tests/osk-importer.test.cjs`、`tests/skin-geometry.test.cjs`、`tests/osk-import-panel.browser.test.py`：新增 parser、幾何與 browser regression。
- `docs/SKIN_FRAMEWORK_CONTRACT.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md` 已更新。
- 真實樣本 metadata/count-only 證據：`artifacts/batch236-regression/real-osk-audit.json`。

## 驗證證據
- Focused Node：48/48 PASS，`artifacts/batch236-regression/focused-node-tests.log`。
- Chromium synthetic OSK panel：21/21 assertions PASS；另真實使用者 `.osk` Chromium import panel 5/5，119 張圖片呈現、47 個 role cards、98 個缺件警告、`selection-mode.png` 與幾何提示可見。真實樣本 IndexedDB save failed as expected in this restricted environment; UI reported no durable persistence. Evidence `artifacts/batch236-regression/real-osk-browser-check.json`.
- Architecture Checker：1,200 PASS／0 FAIL。
- formal `tests/app-shell.browser.test.py` 超過 200 秒工具限制 timeout；全量 Node suite未執行。

## 真實 OSK 樣本發現
- 120 entries，119 images，0 sounds；`Version: latest`；3 個 `[Mania]` blocks；沒有 `@2x`。
- 有 `selection-mode.png`、`selection-random.png`、`selection-options.png`、`menu-button-background.png`、`ranking-panel.png`。
- 缺 `menu-background.jpg`、`selection-bar.png`、`songselect-top.png`、`songselect-bottom.png`；Mania image refs 有 98 項缺件（14 項為 @2x refs）。這符合使用者為減少檔案大小而提供部分素材的說明，不是 importer 故障。

## 不可誤報的邊界
- Geometry previews are not a full osu! stable renderer. No claim of exact nine-slice/edge pixel repeat, blend/tint, animation, or native @2x scaling.
- Skin Override Editor and all-role traceability matrix remain incomplete.
- HTTP-origin IndexedDB and full shell browser suite remain unverified.

## 下一步
1. 用真實 `.osk` 做瀏覽器匯入與 UI 檢查並保存可重現證據。
2. 建立正式 override editor + persistence/transfer single state owner。
3. 完成 47 roles 的 target/CSS/geometry/state/fallback traceability。
4. 針對 official asset geometry 實作與測試可精確重現的 renderer，沒有對應的 AMQ extension roles 維持 fallback。
5. 分批執行全量 Node tests 與 formal shell browser regression，超時如實記錄。
