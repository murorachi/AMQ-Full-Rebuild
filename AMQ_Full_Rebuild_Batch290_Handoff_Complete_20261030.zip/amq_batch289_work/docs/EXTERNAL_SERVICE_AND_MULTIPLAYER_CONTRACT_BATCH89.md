# Batch 89：外部服務與多人協定邊界

## 目標與範圍

這批為 AMQ-965／AMQ-966 建立可獨立測試的契約邊界，不宣稱外部帳號同步或多人遊戲已完成。模組建立時不會自動發出請求、不登入、不開 WebSocket，也不要求單機啟動依賴外部服務或伺服器。

## 外部服務 adapter

位置：`src/integrations/external-service-adapter.js`，公開 API：`window.AMQIntegrations.externalServiceAdapter`。

- `createClient({ service, fetch, AbortController, tokenProvider, clientIdProvider, timeoutMs, now })` 建立一個服務範圍的 client；只允許對應服務的 HTTPS API host，避免把憑證交給任意 URL。
- `request({ url, method, headers, body, auth, signal, timeoutMs })` 由呼叫端明確選擇操作、認證策略及取消訊號。沒有設定 token provider 時，需授權的操作會以 `EXTERNAL_AUTH_REQUIRED` 失敗，不會提示或猜測憑證。
- token 只在該次請求組裝 Authorization header，不寫入 localStorage、IndexedDB、備份 envelope 或錯誤 details。此模組不負責 token 取得／刷新／持久化；實際 OAuth callback 與安全儲存仍未實作。
- 統一錯誤碼涵蓋未知服務、URL／method／auth policy、認證拒絕、HTTP、JSON、網路、timeout、取消、client dispose 與 rate limit。`429` 會讀 `Retry-After`，並讀取可用的 `X-RateLimit-*` headers；`5xx` 與網路／timeout 可重試，權限與格式錯誤不可盲目重試。
- dispose 會取消尚未結束的請求；外部 AbortSignal、timeout 與 dispose 分別保留錯誤原因。使用者關閉功能或切換頁面時應 dispose client。
- AniList policy 使用 `graphql.anilist.co`，將 public read 與 OAuth2 private/mutation 分開；配額以服務回應 headers 為準，不將短期動態限額寫死。
- MAL public read 使用獨立 `clientIdProvider` 注入 `X-MAL-CLIENT-ID`，不得把公開 client ID 當成 Bearer token；private read／mutation 仍使用 `tokenProvider` 的 OAuth2 Bearer token。公開 client ID 與使用者 OAuth token 的取得／設定流程尚未接入 UI。`quotaVerified: false`，MAL quota 仍未核實，不得把本模組當成已完成 MAL 帳號同步。
- VNDB policy 允許公開讀取；需使用者清單／私有操作使用 `Token` 認證。Kana API 文件標示最多 200 requests／5 minutes、每分鐘 1 秒執行時間預算、超過 3 秒的請求會中止；通用 client 預設 2.5 秒且將單次 timeout 上限限制為 2.8 秒。端點路徑、操作 payload 與服務政策仍由各 feature adapter 驗證；通用 client 不猜測資料映射。
- 已有中文標題 Provider 維持獨立；本批不把新的 client 接入現有答案建議，不改動其來源、快取或啟用預設。

參考官方文件：
- AniList GraphQL：<https://docs.anilist.co/>
- AniList rate limiting：<https://docs.anilist.co/guide/rate-limiting>
- VNDB API v2：<https://api.vndb.org/kana>
- MAL 官方 API 說明與配額尚須針對實際要支援的操作再次核實；本契約不假定固定數字。

## 多人 wire protocol

位置：`src/multiplayer/protocol.js`，公開 API：`window.AMQMultiplayer.protocol`。

### Envelope

```json
{
  "protocol": 1,
  "type": "player.ready",
  "roomId": "room-id",
  "playerId": "player-id",
  "seq": 1,
  "sentAt": 1790000000000,
  "payload": { "ready": true }
}
```

- `protocol` 必須等於目前支援版本；未知版本拒絕，不默默解析。
- `type` 必須在明確白名單：`hello`、`room.join`、`room.leave`、`room.snapshot`、`player.ready`、`quiz.question`、`quiz.answer`、`quiz.result`、`room.error`、`heartbeat.ping`、`heartbeat.pong`。
- `roomId`／`playerId` 需符合該訊息的必填規則及 128 字元限制；`seq` 是每個 peer 單調遞增的正整數；`sentAt` 若存在必須為非負有限數字。
- payload 必須是物件，預設上限 64 KiB。question／answer／result／ready／snapshot／error 有最小 schema 檢查。
- `negotiateVersion()` 只接受雙方支援範圍有交集的版本；無交集明確拒絕。
- `createSequenceGuard()` 分 peer 記錄序號；重複／舊序號拒絕，缺號回報 gap 並要求傳輸層重新同步，不能自行猜測或補造遺失訊息。

### 不在本批範圍

- 沒有 WebSocket／HTTP transport、server、房間建立／配對服務、認證、權限、反作弊、持久化房間、重連恢復或真正多人 UI。
- server 必須獨立驗證所有訊息、房間成員與權限；client-side validator 不是安全邊界。
- `quiz.answer` payload 不應包含正確答案以外的額外敏感伺服器狀態；正式 scoring、計時權威與防作弊規則須由後續 server contract 決定。
- 多人功能必須 opt-in，任何連線、協定不相容或 server 故障都不能阻斷 AMQ／EMQ／MIX 單機模式。

## Batch 89 測試證據

- `tests/external-service-adapter.test.cjs`：14 組，涵蓋服務白名單、host／HTTPS 限制、認證需求、token header、rate limit、401、5xx、JSON／網路錯誤、取消、timeout 與 dispose。
- `tests/multiplayer-protocol.test.cjs`：18 項／組，涵蓋 envelope、payload、大小限制、版本協商、未知訊息、ID／序號與重複／缺號 guard。
- 以上是 Node contract tests，不是外部服務真實呼叫、OAuth 流程、伺服器互通或多人 E2E。
