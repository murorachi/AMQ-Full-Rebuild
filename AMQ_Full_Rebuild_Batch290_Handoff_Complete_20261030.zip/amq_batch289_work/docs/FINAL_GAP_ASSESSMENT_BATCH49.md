# Batch 49：核心結案盤點與剩餘阻塞

日期：2026-10-27  
範圍：只依目前工作副本、測試日誌與既有靜態參考紀錄判定；不把 Node／mock 測試說成瀏覽器或舊版相容驗收。

## 1. 可確認已完成的新版內部核心

| 領域 | 證據 | 結論 |
|---|---|---|
| 工程基礎、共享狀態、生命週期、錯誤契約 | `src/core/*`、`tools/check-architecture.cjs`、`tests/core.test.cjs` | 新版內部模組契約與 Node 測試已建立 |
| AMQ／EMQ 資料管線 | source adapter／mapper／repository／runtime，source audit 與 mapper verification | 55,660 筆 canonical records mapping 通過；不代表 Candidate302 配套相容 |
| AMQ／EMQ／MIX 出題 | QuizPool／QuizSession tests | source-aware identity、MIX 2:1 weighting 與來源耗盡 fallback 有測試；未宣稱所有舊版篩選語義相容 |
| 猜歌狀態／答案／計時 | QuizEngine／QuizSession／QuizClock／AnswerEvaluator | Node 回歸涵蓋主要狀態、deadline race、no-repeat、計分與來源隔離 |
| 音訊服務 | AudioService tests + `audio-session.integration.test.cjs` | mock media 的候選備援、取消、`playing` 計時起點、pause/resume 有測試；真實可聽性未驗收 |
| 曲庫查詢／瀏覽 | query index、catalog controller／integration tests | 搜尋、篩選、排序、facet、分頁、loading／empty／failed 狀態有 Node 證據 |
| 持久化 | familiarity／history／settings／SRS／blacklist stores 與 QuizSession／QuizPanel integration | 讀寫失敗、快照恢復、狀態通知、部分持久化警告及來源隔離有測試 |

## 2. Batch 63 最新可用驗證證據（歷史 Batch 49 數字保留於後文）

- Batch 62 全量 `tests/*.test.cjs`：26/26 scripts exit 0。
- `tests/app-lifecycle.integration.test.cjs`：2/2 PASS；`tests/data-pipeline.integration.test.cjs`：20/20 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：466 passed／0 failed。
- Source audit PASS：AMQ 38,821 songs、EMQ 16,839 songs；無重複 ID、dangling references 或跨來源 ID collisions。
- Mapper verification PASS：Catalog 55,660；AMQ candidates 37,939、EMQ 16,839。
- Catalog benchmark 5 iterations PASS；所有 `src/`、`tests/`、`tools/` JS/CJS `node --check` PASS。
- 來源 asset SHA-256 未變：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 完整命令輸出及 ZIP 驗證位於 `/mnt/data/amq_batch49_logs/`。

## 3. 尚未完成，且目前不能誠實標為 PASS

### A. 必須由外部環境解除

1. **真實瀏覽器 E2E：BLOCKED。** 既有 `file://` 與 `127.0.0.1` 導覽回報 `ERR_BLOCKED_BY_ADMINISTRATOR`。本批沒有重試同一方式。
2. **真實音訊可聽性：未驗收。** mock media 只能驗證事件契約，不能證明 URL、跨域、瀏覽器 autoplay 或使用者實際聽得到音訊。
3. **乾淨 Windows 啟動：未驗收。** 目前工作環境無法實際執行 Windows `.bat` 與桌面瀏覽器流程。

### B. 缺少參考證據／產品契約

1. **清單／看番狀態：新版內部 CRUD 已實作並有 Node integration evidence；真實瀏覽器驗收未完成。** `aniFavorites_v1` 身份仍不明，不能新增收藏寫入；舊 source-less `animeIds`／watch status 不自動遷移。
2. **曲庫鍵盤列選取：新版已有單一選取 owner，Enter 僅選取、不推測播放；Node integration PASS。** 真實瀏覽器鍵盤與焦點行為仍未驗收。
3. **舊版完整相容：未證實。** Candidate302 正式基準與 Candidate382 Stage 0 CSS 比較基準不可讀；目前 `AMQ382(1).html` 的歷史 metadata 指向 Candidate381／Stage I 線索。不能把內部 mapping／Node PASS 當成版本相容證據。

### C. 明確延後或階段 5

- 大規模 UI／CSS 分層與舊 UI 替換、視覺基準截圖、窄螢幕／responsive／focus 驗收。
- 深色主題、背景 IndexedDB、多人服務端、AniList／MAL／VNDB 完整匯入。
- AMQ-specific MIX filter suppression：目前新版沒有 watchlist／season／difficulty／hard-pool／EMQ custom-list 控制；不新增猜測性 UI。

## 4. 主清單狀態解讀

Batch 49 將主清單中已由後續批次完成、但早期仍留在 `[ ]`／`[~]` 的項目更新為目前證據狀態，修正已過時的「資料來源不存在」「query UI 未接線」「EMQ SRS 不支援」等描述，並消除重複 task ID。現有主清單為 555 個唯一 task IDs；狀態統計：454 完成、66 阻塞、9 進行中、17 待處理（全部屬階段 5 UI／CSS）、9 不適用。這些是任務數量，不是產品完成率。

主清單狀態的數字是**任務項目狀態**，不是產品百分比；多筆歷史阻塞仍保留，因為它們記錄了各批當時真實發生的限制。不可將勾選比例直接換算為產品完成率。

## 5. 可以繼續開發的解除條件

- 若要重建舊版收藏／自訂清單／看番狀態與鍵盤選取：提供可讀的 `AMQ382(1).html`／指定的 CSS Stage 0 參考檔，或明確批准採用新版獨立契約而不宣稱舊版相容。
- 若要完成最終瀏覽器驗收：提供可用的本機瀏覽器／測試環境，使頁面導覽與真實音源請求可以實際執行。

在上述條件解除前，現有可安全執行的核心 Node／mock 整合工作已做過多輪回歸；繼續無目標修改穩定模組的風險高於收益。下一批應依新證據／授權執行，而不是重複審計或製造新批次。


## Batch 50 更新（2026-10-27，以下狀態覆蓋本文件對參考檔缺失的舊描述）

使用者已重新上傳 `/mnt/data/AMQ382(2).html`，SHA-256 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`，與先前登記的參考檔雜湊一致。它確實可讀，但檔內標示 Candidate381，不是 Candidate382 Stage 0。

- 自訂清單／看番狀態：已從靜態程式碼取得 key、payload、CRUD、狀態 enum 與刪除語義，並新增 `src/persistence/personal-library-store.js`；9/9 Node 情境通過。新版 UI 尚未接線，因此產品功能仍未完成。
- 收藏：只找到 `aniFavorites_v1` 讀取／備份線索，尚未找到可靠新增／移除 handler，ID 身份（作品或歌曲）不明。為避免錯寫資料，本批不新增收藏寫入。
- 鍵盤：靜態參考可見舊 Song Select 在非輸入／按鈕／select 焦點時用 ArrowUp／ArrowDown 移動歌曲列，Enter 呼叫 canonical choose-song owner；新版尚無對應的 playback owner，鍵盤整合仍待實作。
- 真實瀏覽器／音訊／Windows 驗收仍未完成；`ERR_BLOCKED_BY_ADMINISTRATOR` 不重試同一方式。
- Batch 50 完整測試：25/25 Node test scripts exit 0、tooling 8/8、architecture 459/0、source audit PASS、mapper verification PASS（55,660 records）、benchmark 5 iterations PASS、JS/CJS syntax PASS。此結果不代表舊版相容或瀏覽器驗收。

下一步以 `docs/HANDOFF_BATCH50.md` 與 `docs/NEXT_SESSION_PROMPT.md` 為準。


## Batch 63 更新：核心工程範圍結案評估（2026-10-27）

### 可在目前環境下確認的結論

- Batch 56–62 連續修正了已重現的 Repository mode invalidation race、pre-aborted signal、副作用狀態通知重入、timer 遲到 callback、runtime dispose 後 Catalog／loaded state 殘留，以及 app mount 部分失敗後資源洩漏。每項均有回歸測試；Batch 62 的最新全量驗證為 26/26 Node scripts、tooling 8/8、architecture 466/0、source audit／mapper／benchmark／64 個 JS/CJS syntax PASS。
- 根據目前主清單、`PRODUCT_CORE_CONTRACT.md`、更新後的 `FUNCTION_INVENTORY.md` 與可讀程式／測試，沒有找到另一項既有證據充分、可在不猜測舊版規則／資料身份且不依賴真實瀏覽器的 P0/P1 核心程式缺陷。這是本次範圍盤點結論，不是對所有產品功能的最終驗收聲明。
- 因此，**目前可在現有檔案與環境中可靠實作／驗證的核心工程範圍可暫時結案**；不再為了增加批次而反覆翻修穩定模組。

### 仍未結案的產品驗收與下一階段條件

1. 真實瀏覽器 mount／dispose／remount、主要操作、響應式、鍵盤、跨分頁 storage：需要可成功導覽頁面的瀏覽器／E2E 執行環境。現有 `ERR_BLOCKED_BY_ADMINISTRATOR` 與 Chromium CLI 無 DOM 結果不能算通過。
2. 真實音訊可聽性、跨域／autoplay 與乾淨 Windows 啟動：需實際瀏覽器／Windows 操作證據。
3. Candidate302／Candidate382 Stage 0 正式相容性：目前 Candidate381 靜態參考不足以證明，遵照使用者指示不再搜尋 Candidate302。
4. 收藏身份 `aniFavorites_v1`、source-less legacy IDs：需要可靠資料映射或明確產品決策，不做猜測式寫入／遷移。
5. 大規模 UI／CSS 重構：仍是階段 5；開始前須有可保留的核准視覺基準及可用的實際驗收通道，避免只按靜態線索重畫並誤稱保留了已認可畫面。
6. 深色主題、背景 IndexedDB、多人與外部匯入維持 P2／待確認，不阻擋目前單機核心工程結案。

### 結案定義

- **核心程式實作／自動化契約：** 目前可執行範圍暫結案，後續只處理新證據指出的具體缺陷。
- **整個 AMQ 產品重建：** 尚未結案。真實瀏覽器、音訊、正式基準相容性與 UI／CSS 階段仍未驗收。
