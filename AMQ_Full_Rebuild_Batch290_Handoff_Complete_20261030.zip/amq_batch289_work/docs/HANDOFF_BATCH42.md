# Batch 42 交接：持久化失敗恢復與狀態投影

## 已完成
- `src/persistence/srs-store.js`：外部 storage event 的讀取例外不再以空 schedule 覆蓋最後已知快照；阻塞寫入，成功讀取才替換快照。
- `src/persistence/quiz-history-store.js`：新版 detail 外部讀取失敗保留快照並阻止寫入；legacy detail read exception 不再靜默轉成空陣列，狀態以 `legacyReadError` 提供，保留上一個可讀唯讀快照。
- `src/persistence/app-settings-store.js`：寫入失敗通知 subscribers (`write-failed`)，無效資料備份後暴露 `recoveryNotice`。
- `src/ui/quiz-panel.js`：設定恢復提示、legacy history 暫時不可讀提示、未聚焦設定控制項外部更新。
- 回歸測試：`tests/srs-store.test.cjs` 新增外部讀取失敗保留快照／成功恢復；`tests/quiz-history-store.test.cjs` 新增新版 detail 與 legacy detail 讀取失敗恢復；`tests/app-settings-store.test.cjs` 新增寫入失敗訂閱通知與 storage clear；`tests/quiz-panel.test.cjs` 驗證 recovery UI 與聚焦控制項保護。

## 驗證
- `tests/*.test.cjs`：22/22 scripts exit 0。
- App settings 6/6；Quiz history 12/12；SRS 16/16；quiz panel integration PASS。
- Tooling 8/8；architecture 430 passed／0 failed。
- Source audit PASS；AMQ 38,821、EMQ 16,839，無重複 ID／dangling references／cross-source ID collisions。
- Mapper verifier PASS；Catalog 55,660，AMQ audio candidates 37,939、EMQ 16,839。
- Catalog benchmark 5 iterations PASS；所有 JS/CJS syntax PASS。
- Source asset SHA-256 unchanged；詳細日誌 `/mnt/data/amq_batch42_logs/`。
- 完整 ZIP：`/mnt/data/AMQ_Full_Rebuild_Batch42_PersistenceRecovery_20261027.zip`，4,395,080 bytes；113 個檔案項目、12 個目錄項目；manifest 112/112 一致，ZIP CRC 通過。

## 限制
- Node/mock storage tests 不等於真實瀏覽器跨分頁 localStorage、quota、pagehide 或音訊驗收。
- 瀏覽器 E2E 仍因先前 `ERR_BLOCKED_BY_ADMINISTRATOR` 導覽阻擋而 BLOCKED；本批未重試相同方式。
- Quiz history detail 與 summary 仍為不同 key，跨 key 寫入不具原子交易保證。
- 工作副本無 `.git` metadata；未初始化 Git、未 commit／push，未覆蓋正式基準與曲庫來源。

## Batch 43
1. 稽核各 persistence store write failure 是否通知 subscribers／暴露一致 status，並檢查 UI 投影。
2. 驗證 history detail 成功但 summary 寫入失敗的部分成功恢復、重載與去重。
3. 檢查 familiarity／blacklist／SRS storage clear、read recovery、dispose 邊界；只修正可證實問題。
4. 全量回歸與更新 manifest／ZIP；瀏覽器 E2E 阻塞持續如實記錄。
