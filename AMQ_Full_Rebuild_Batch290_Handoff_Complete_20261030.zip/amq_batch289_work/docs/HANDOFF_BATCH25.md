# Batch 25 交接：來源感知答題歷史與摘要

## 已完成
- `src/persistence/quiz-history-store.js`：新版明細 key `amqLearningQuizHistoryV1`、新版摘要 key `amqLearningQuizHistorySummaryV1`；舊版 `aniQuizHistory_v1`、`aniQuizHistorySummaryV1`、`aniQuizTargetSummaryV1` 只讀，不覆寫。
- 新版明細採 AMQ／EMQ source-aware 記錄；摘要涵蓋來源、目標、歌曲、日期；`all` 目標會拆成 anime／title／artist 三筆。
- 2,000 筆 detail cap、5,000 筆去重窗口、批次／延遲摘要保存、`pagehide`／`visibilitychange` flush、storage event 同步。
- 損壞新版 detail／summary 先隔離 recovery；detail 無法隔離時阻止覆寫。
- QuizSession 在計分作答／超時／播放後跳過寫入；揭曉及未播放跳過不寫入。主頁顯示新版／舊版紀錄數、最近五筆及儲存異常。

## 測試證據
- `node tests/quiz-history-store.test.cjs`：9/9 PASS。
- `node tests/quiz-session.test.cjs`：10/10 PASS。
- `node tests/quiz-panel.test.cjs`：PASS。
- 完整 Node 測試、來源 audit、mapper verifier、所有 JS/CJS 語法檢查 PASS。
- `node tools/check-architecture.cjs`：353 passed、0 failed。
- 真實瀏覽器 E2E 未執行；不得宣稱 UI／localStorage／媒體已瀏覽器驗收。

## 下一步
1. 實作 DOM-free source-aware FSRS／SRS schedule core，依 `AMQ382(1).html` 中 `aniSrsScheduleV1` 與 FSRS-6 靜態規則建立測試。
2. 舊版 SRS 卡片需透過當前曲庫明確解析來源；不能只用裸 song ID 遷移到新版 key。保留 legacy key 唯讀與 recovery。
3. 後續再接入排程 UI、評級按鈕與 quiz session；不要將猜歌正誤直接假裝成 FSRS grade 1–4，舊版 SRS 是獨立的明確評級流程。
4. 瀏覽器 E2E／真實音訊可用性仍受既有環境阻擋。
