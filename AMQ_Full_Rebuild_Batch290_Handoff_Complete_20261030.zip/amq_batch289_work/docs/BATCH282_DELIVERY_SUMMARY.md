# Batch282 交付摘要

- 基準：`AMQ_Full_Rebuild_Batch281_Home_Note_Question_Skin_UI_20261030.zip`，只讀解壓後另建工作副本；未覆寫 Batch281。
- 本批實作：feature-route nav grid placement、Dock ResizeObserver height contract、Dock collapsed state、Catalog dock-aware list/pagination geometry、三個 Skin component targets、Skin manifest consistency repair。
- Browser fixture：118/118 assertions PASS，涵蓋 Home/Catalog 四尺寸與 nav/dock/list/pagination 幾何；Catalog 仍是 fixture，不代表 live data。
- Node suite：100 test files 分 4 組，74/74、66/66、74/74、104/104 subtests PASS，共 318/318。
- Focused Node：38/38 PASS；Skin manifest/audit repair suite 17/17 PASS。
- Architecture checker：1,351 PASS／0 FAIL。
- JS/CJS syntax：195/195；Python AST：35/35。
- 精簡 ZIP 約 7.7 MB（比 Batch281 約 46 MB 小約 83%）；ZIP CRC PASS，Manifest 659/659 PASS，SHA-256 記錄在 ZIP sidecar。已從精簡包解壓後再次執行 focused tests 55/55、Architecture 1,351/0、Browser 118/118 PASS。

## 封裝精簡
- 原 Batch281 ZIP：46 MB 左右（含歷史證據與 28 MB osu! source ZIP）。
- Batch282 精簡交付保留正式原始碼、執行資源、全部測試、所有文件、官方 osu! 參考截圖、最新 Batch282 截圖、測試必需的歷史 role-audit/OSK-audit JSON，以及必要 blocker 摘要。
- 移除歷史重複 screenshots、可重生的 raw logs、與執行／測試無關的 `references/osu-master.zip`。其 SHA-256 與研究結論仍在 `references/OSU_SOURCE_ARCHIVE_INFO.md`、`docs/OSU_SOURCE_RESEARCH_BATCH271.md`、`docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`。完整 Batch281 包沒有修改。
- `artifacts/HISTORICAL_EVIDENCE_INDEX.md` 記錄精簡政策與保留路徑。

## 未宣稱通過
- 人工 osu! Stable 視覺 gate、正式 Catalog/live artwork、外部音訊、HTTP-origin IndexedDB、Windows／實機驗收仍未完成。
