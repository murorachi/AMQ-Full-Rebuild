# Batch 59 交接：共享 State 重入通知順序

## 結論

本批沒有新的可操作瀏覽器通道或正式基準檔案。檢查核心 state contract 時，找到 listener 重入更新的通知順序問題並修正。

`src/core/state.js` 原本直接遍歷 listener 並將當前全域 `state` 傳給每個 listener。如果第一個 listener 在通知中再次呼叫 `update()`，巢狀通知會先執行；外層通知恢復後，後續 listener 會再次讀到已更新的全域 state，導致原始 snapshot 被跳過且新 snapshot 重複通知。

## 修改

- `src/core/state.js`
  - 每次成功提交的不可變 snapshot 放入 FIFO notification queue。
  - 若正在通知時發生重入 `update()`，只提交並排隊；目前 snapshot 的 listener 輪次完成後再通知下一個 snapshot。
  - subscriber error diagnostic 保存實際觸發錯誤的 snapshot，而不是可能已被重入更新替換的全域 state。
  - 保留有界 50 筆錯誤佇列、listener exception isolation、unsubscribe 行為，以及 `update()` 回傳當前 state 的既有語義。
- `tests/core.test.cjs`
  - 新增重入回歸，要求第二個 listener 依序收到 `{mode: EMQ, questionStatus: idle}` 與 `{mode: EMQ, questionStatus: playing}`。
  - 修改前新增測試失敗，核心測試 77/78；修改後 78/78。
- `docs/ARCHITECTURE.md`、`docs/DATA_CONTRACT.md`：補充 FIFO 重入通知契約。
- `docs/MASTER_CHECKLIST.md`：新增 AMQ-649 至 AMQ-656。

## 驗證結果

- `tests/*.test.cjs`：25/25 scripts exit 0。
- `node tests/core.test.cjs`：78/78 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：459 passed，0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839；重複 song ID、dangling song-work references、跨來源 work/song ID 衝突皆為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660（AMQ 38,821、EMQ 16,839）。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS，5 次 Node in-memory benchmark；不代表瀏覽器效能。
- `node --check`：63 個 `src/`、`tests/`、`tools/` JS/CJS 檔案 PASS。
- 來源 hash 未變：`data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。
- 詳細日誌：`/mnt/data/amq_batch59_logs/`。

## 未驗收／阻塞

- 真實瀏覽器 UI、響應式／鍵盤、跨分頁 localStorage、真實音訊可聽性與乾淨 Windows 啟動仍未驗收。沒有新的瀏覽器通道；未重試已失敗的相同 Chromium CLI 導覽方式。
- Candidate302／Candidate382 Stage 0 相容性未驗收；Candidate381 仍只作靜態參考。
- `aniFavorites_v1` ID 身份未證實；legacy source-less `animeIds`／watch status 不自動遷移。
- 工作副本沒有 `.git` metadata；未初始化 Git、commit 或 push；正式基準及來源資料未修改。

## Batch 60 下一步

1. 先讀 `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md` 尾端及本交接，不重做 AMQ-649 至 AMQ-655。
2. 若沒有新的瀏覽器／正式基準證據，繼續檢查有明確契約且可測試的核心整合缺口，優先看 shared state 與 lifecycle／runtime consumer 的跨模組行為。
3. 不猜測收藏身份、source-less legacy ID 歸屬或 P2 行為；UI／CSS 大重構仍排最後。
4. 完成本批後更新同一份清單／狀態、全量驗證並重建 manifest／完整 ZIP。
