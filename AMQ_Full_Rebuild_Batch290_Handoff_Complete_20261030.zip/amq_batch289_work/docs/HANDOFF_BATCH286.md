# Batch286 Handoff：Quiz 依使用者遊戲畫面重建位置／功能

## 本批主成果
- 依使用者提供的 AMQ 遊戲畫面，重構正式 `src/index.html` Quiz DOM：頂部遊戲導覽與 HUD、左側真實回合摘要、中央答題舞台、右側未揭曉圖塊／音訊狀態／真實答題紀錄、底部答案列與回合控制。
- Quiz route 使用固定 viewport 內容層與頂部導覽列，不再沿用通用頁面 gutter／左側導覽 rail；桌面與手機都有獨立佈局。
- 答案輸入、提交、建議選單、音訊狀態、回合操作和設定 owner 全部保留，未另造第二份 Quiz state。
- 把原有 quiz history 真正移入右側狀態 rail，讓單人頁使用實際答題紀錄填充資訊區；沒有製作假聊天室、全球排名、玩家分數或假作品封面。
- 新增六個 Skin roles 並同步文件 manifest、runtime registry、visual-needs registry、theme adapter、CSS token consumers。
- 更新舊 Batch264 browser harness：停止載入所有產品腳本造成長時間等待，只載入 route owner；修正已過時的四指標與手機答案表單斷言。

## 視覺參考與證據
- 使用者原圖 SHA-256：`3ba957004e70d59faab1e7fdcd0522e102719beb78ccde28629de8ffd632001f`
- 原圖對照規格：`docs/QUIZ_GAMEPLAY_REFERENCE_BATCH286.md`
- 並排圖：`artifacts/batch286-quiz-gameplay-layout/quiz-reference-side-by-side.jpg`
- 最新 1920×1080 viewport：`artifacts/batch286-quiz-gameplay-layout/quiz-1920x1080.jpg`
- Browser tests：Batch286 55/55；更新後 Batch264 Quiz visual 38/38；Batch285 Quiz route 71/71；Batch283 Catalog regression 148/148。

## Focused test evidence
- `node --test tests/quiz-panel.test.cjs tests/quiz-ui-state.contract.test.cjs tests/answer-suggestions.test.cjs tests/app-shell-navigation.contract.test.cjs`：9/9 top-level tests PASS；Answer suggestions 18 cases PASS；Quiz selector matrix 768 combinations PASS。
- `node --test tests/skin-quiz-gameplay-layout-batch286.test.cjs tests/skin-contract-manifest.test.cjs tests/visual-role-audit.test.cjs`：17/17 PASS。
- Architecture Checker：1,365 PASS／0 FAIL。
- JS/CJS syntax：197 files PASS；Python AST：39 files PASS。
- Visual role audit：58 roles／46 runtime selectors／12 explicitly unsupported；45 roles有直接測試引用；其餘 audit gaps 仍保留。

## 尚未完成／不可宣稱通過
- 人工對照畫面仍有構圖比例差距，並排圖不是 pixel-perfect acceptance。
- 四尺寸測試用 fixture，只證明 DOM/CSS 幾何與路由，不證明 live audio、live data、外部 provider 或持久化。
- 全量 Node suite、HTTP-origin IndexedDB、Windows／真機與 live server 尚未驗收。
- 新增 Skin roles 已接上真實 DOM/CSS targets，但 OSK 真實素材 apply/fallback/reset 的逐 role browser evidence 尚未完成。

## 下一批優先
1. 繼續 UI 主線：依 `artifacts/osu-reference/osu-game-modifiers.jpg` 對照正式 Mods/Quiz 設定，先確認 canonical registry/state/audio owner；不可畫無功能的 Mods 裝飾按鈕。
2. 在不改 Quiz state owner 的前提下，補完整的答題互動回歸：正確／錯誤／跳過／揭曉／下一題時，答案列、音訊狀態與右側歷史更新要一致。
3. 繼續逐頁直接對照 Stable 原圖，尤其 Settings、Results、Profile；每批需保留並排圖與差距表。
4. 新增 Skin role 的 apply/fallback/reset 可見測試；不要將 selector 存在當成視覺支援完成。
5. 封裝時只帶最新 viewport 圖、原始使用者參考圖的精簡 JPEG、source/test/docs 與 audit 摘要；不帶約 28 MB osu! source archive。
