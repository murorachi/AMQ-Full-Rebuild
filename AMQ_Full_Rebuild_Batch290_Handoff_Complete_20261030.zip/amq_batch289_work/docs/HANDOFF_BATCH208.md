# Batch208 Handoff：猜歌設定／即時回合 UI 分區

日期：2026-10-29

## 基準與環境
- 延續工作副本：`/mnt/data/amq_batch207_work/project`。
- `AGENTS.md`、`AI_START_HERE.md`、主清單、工作狀態、Batch207 handoff、下一輪提示詞及 Wiki traceability 已讀取。
- `git status` 回報不是 Git repository；未初始化。Candidate302 與 Candidate382 Stage 0 原始檔不在工作副本中，沒有猜測或覆蓋。
- AMQ／EMQ 資產 SHA-256 未變，詳見 `artifacts/batch208-regression/asset-hashes.txt`。

## 修改
- `src/index.html`：新增 `.quiz-setup-section` 與 `.quiz-round-section`，提供回合設定、出題篩選、即時狀態、答題舞台的明確資訊層級。原控制項 ID、QuizPanel 查詢、QuizSession／history／SRS 狀態 owner 不變。
- `src/styles/ui-shell.css`：正式分區視覺、disclosure summary、focus-visible、桌面與 760px／420px 斷點。
- `tests/app-shell.browser.test.py`：加上 7 項 browser assertions，證據輸出至本批獨立資料夾。
- `docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/OSU_STABLE_WIKI_TRACEABILITY_BATCH206.md`、`docs/NEXT_SESSION_PROMPT.md`：更新持續性工作紀錄與下一批方向。

## 測試
- `python tests/app-shell.browser.test.py`：61/61 PASS。
- `node tests/quiz-panel.test.cjs`：PASS，eligibility matrix 768/768。
- `node tests/catalog-browser.integration.test.cjs`：PASS。
- `node tools/check-architecture.cjs`：1,123 PASS／0 FAIL。
- `node --check src/ui/quiz-panel.js`、`node --check src/ui/app-shell.js`、`python -m py_compile tests/app-shell.browser.test.py`：PASS。
- 證據：`artifacts/batch208-regression/`。本批未執行全量 Node suite。

## 未解決
- 真實 `.osk`、HTTP-origin IndexedDB、真實曲庫／封面／音訊與 Candidate302／Candidate382 Stage 0 相容性未驗收。
- `quiz-history` 是跨回合歷史，不能直接作為單輪結果頁；Batch209 必須先查明 round boundary 與逐題紀錄資料契約。
- 個人檔案／排行榜的真實資料 owner 尚未核實；不得合成 PP／全域排名／PB。
- UI 主線尚未完成，不能結案。

## 下一步
依 `docs/NEXT_SESSION_PROMPT.md` 直接執行 Batch209：追蹤真實 QuizSession／history round detail，建立有資料依據的結果 UI；同時繼續 Catalog 狀態／封面 UI，不要只做盤點。
