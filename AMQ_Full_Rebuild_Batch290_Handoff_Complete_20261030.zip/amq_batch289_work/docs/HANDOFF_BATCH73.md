# Batch 73 交接：全域 SRS 開關與一般練習評估接線切片

## 已完成
- `src/persistence/app-settings-store.js` 沿用既有 version 1 settings，新增 `srsEnabled`，不另建設定來源。舊 schema 缺欄位時套用啟用預設；設定可透過既有 storage event／reload 邏輯還原。
- `src/index.html` 的 SRS 區塊新增全域開關。
- `src/ui/quiz-panel.js` 將有效的一般 AMQ／EMQ 答題接入既有 `assessmentEngine` 與來源對應 SRS store；MIX 依題目來源寫回 AMQ／EMQ，不建 MIX schedule。只以作品標題判定；`title`／`artist` 排除，`all` 只看 anime 正確性。
- 未排程歌曲在有效評級時先 enroll；缺少可靠耗時不猜評級；卡片建立／評級失敗顯示錯誤，不假裝保存成功。
- SRS 關閉時，UI 隱藏／停止顯示 SRS 統計並停用 SRS 複習／卡片控制；一般猜歌、熟悉度與答題歷史仍沿原流程。

## 修改檔案
- `src/persistence/app-settings-store.js`
- `src/index.html`
- `src/ui/quiz-panel.js`
- `tests/app-settings-store.test.cjs`
- `tests/quiz-panel.test.cjs`
- `docs/MASTER_CHECKLIST.md`
- `docs/WORK_STATUS.md`
- `docs/HANDOFF_BATCH73.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `MANIFEST.sha256`

## 驗證
- 全部 `tests/*.test.cjs` 腳本 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：495 passed／0 failed。
- Source audit PASS；AMQ 38,821、EMQ 16,839；全量 mapper verification PASS，Catalog 55,660 筆。
- Node／靜態驗證不代表真實瀏覽器或音訊 E2E。

## 未完成
- AMQ-902–AMQ-918 尚未完成；selector、動態權重、完整統計、備份／還原、跨分頁／recovery 整合測試仍待處理。
- 全域 SRS 已接線切片，不等於全功能完成。
- Candidate302／Candidate382 Stage 0 相容性、真實瀏覽器及音訊可播放性未驗收。

## 下一個可執行批次
1. 補 SRS toggle off／on／reload、排程不變與一般猜歌持續運作的整合測試。
2. 實作 eligibility-first selector 與 source-aware AMQ／EMQ／MIX 選題策略。
3. 加入 due/new 動態相對權重、新題保護、回合去重、有界 fallback、MIX 2:1 模擬。
4. 補備份／還原、跨分頁、storage failure／recovery 測試。
