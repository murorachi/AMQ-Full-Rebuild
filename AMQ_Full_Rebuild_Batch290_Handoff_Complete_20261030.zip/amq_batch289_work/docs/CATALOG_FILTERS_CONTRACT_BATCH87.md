# 曲庫篩選與出題回歸契約（Batch 87）

## Catalog query criteria
- 可用條件：query、source、song type、work kind、animeId、animeYearFrom／animeYearTo、includeUnknownYear、animeType、animeDecade、watchStatus、familiarityLevel。
- 多條件以 AND 組合；篩選先於排序與分頁。`total` 是分頁前符合條件的數量。
- 年份起迄接受 1900–2100 四位年份輸入。年份缺失／非數字時，只有啟用年份範圍且 `includeUnknownYear=true` 才保留。
- 年代是年份的十年區間（例如 2020 表示 2020–2029）；未知年份不屬於任何年代。作品年份排序使用數值順序，缺失值在兩個方向都最後。
- 作品細分類、看番狀態與熟悉度用 exact matching；熟悉度限定 0–3。看番狀態依 `{source, workId}` 取值，熟悉度來自共用 Familiarity Store。
- Facet 計數排除該 facet 自身的 filter，保留其餘條件，且不受分頁影響。

## Quiz eligibility
- 所有 filters 在 no-repeat 選題前套用，與 source mode、song/work blacklist、source-aware custom list、SRS eligibility 共同決定候選池。
- 不從 EMQ 缺失欄位推測作品類型／難度。未知年份的 include/exclude 行為明確測試；AMQ／EMQ／MIX 使用相同 filter 設定測試 source-specific 結果。
- Node tests 證明內部契約，不證明 Candidate302 完全相容或真實瀏覽器行為。


## Batch 187 audit update (2026-10-28)

- Catalog filter presets are named snapshots of the existing Catalog controller state: all current filter values, sort field/direction and page size. The controller remains the single live filter state owner; the App Settings Store only persists snapshots.
- Persisted schema stays at version 1 and adds an optional `catalogFilterPresets` field. Legacy settings without this field normalize to an empty list. Invalid preset collections are rejected without committing the settings write. Maximum 30 presets; names are trimmed, 1–40 characters and unique case-insensitively; IDs unique; page size limited to the UI choices 10/25/50/100.
- Current quiz filter audit: year range and unknown-year behavior, work type, difficulty min/max, song type and watch status are implemented in `src/ui/quiz-panel.js` and covered by `tests/quiz-panel.test.cjs` and `tests/filter-matrix.test.cjs`. Season is intentionally not exposed because the verified AMQ/EMQ data contract has no reliable season field; do not infer it from titles or release dates. This is a data-contract limitation, not an unfinished UI control.
- Current catalog filter UI includes source, song type, work kind, work subtype, decade, year range, unknown-year inclusion, watch status and familiarity level. Query-index criteria are AND-composed before sorting and pagination. Familiarity levels 0–4 are used by the current UI; older references to 0–3 are stale.
- Node integration evidence does not replace real-browser viewport and storage acceptance.
