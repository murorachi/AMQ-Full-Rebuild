# Batch284 Handoff：Multiplayer Lobby／Quiz 依 Stable 原圖完成一批 UI 收斂

## 本批實際參考來源
- Stable Lobby screenshot：`artifacts/osu-reference/osu-multiplayer-lobby.jpg`。
- Stable intro screenshot：`artifacts/osu-reference/osu-intro-screen.jpg`。
- osu! upstream source archive：`/mnt/data/osu-master.zip`，SHA-256 `973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`。此來源主要是 lazer，不宣稱等於 Stable 原始 UI。
- AMQ community scripts：`references/AMQ-Scripts-master.zip`，SHA-256 `76fc073a51da180d087ba4c6636b22531053ed5b1affeb5a8330e7de7c4aad04`。定向參考 `gameplay/amqAutocomplete.user.js`、`gameplay/amqNoDropdown.user.js`、答案時間／玩家答案顯示腳本及背景腳本；只採用互動情境，不移植舊 runtime prototype patch。

## 完成項目
1. Multiplayer Lobby CSS 已整段重整為更緊湊的遊戲客戶端結構：標題／狀態、來源 tabs、搜尋／進行中篩選、房間列表／建立區、加入房間；移除舊有大塊 padding、卡片式雙框與過度留白。
2. 建立房間列表在 server 回傳空狀態時不再保留巨大的五列空白。原生選單由五列改為三列，單一 placeholder 時壓縮至 78px；有真實房間時仍使用既有 server-backed select，不生成假房間。
3. 保留唯一 `client.listRooms()`、create/join handlers、room/session/server snapshot owner；未加入假玩家、聊天、歌曲縮圖、成績、排行榜或 Mods。
4. Quiz 問題舞台調整為更清楚的主視覺區：保留音訊狀態、題目標題、答案輸入、建議選單與原有操作 owner；增加焦點狀態、答案建議選取態、reduced-motion 規則，未更動出題／音訊／答案評估邏輯。
5. 修正 Batch272 browser harness 的導航方式。舊測試從 Home 點擊隱藏的 feature nav，造成 timeout；改由可見 Home 主選單進入 Quiz。這是測試腳本錯誤，不是把失敗記成通過。
6. 更新 Batch272 視覺契約，反映本批新的桌面欄寬與 900px 以下堆疊斷點。

## 原圖對照證據
- `artifacts/batch284-multiplayer-quiz/multiplayer-vs-osu-stable-1920x1080.jpg`
- `artifacts/batch284-multiplayer-quiz/quiz-vs-osu-intro-1920x1080.jpg`
- 四尺寸輸出：`quiz-panel-*.jpg`、`multiplayer-panel-*.jpg`。
- Lobby 仍與 Stable 有明顯差異：目前產品 API 不提供 Stable 畫面裡的玩家槽位／頭像、歌曲 artwork 與 chat；本批沒有假造。空房間畫面是 empty server state，不是 live server acceptance。

## 測試
- `python tests/batch284-multiplayer-quiz.browser.py`：43/43 PASS，四尺寸 1920×1080、1440×900、1024×768、390×844；檢查 Quiz prompt/answer owner、round/setup order、無水平溢位、Lobby tabs/search/create controls、empty room list compact state、0 page errors。
- `python tests/batch272-multiplayer-lobby.browser.py`：32/32 PASS。此舊 harness 之前因點擊 Home 隱藏 nav 而逾時，已修正後重跑成功。
- Focused Node：17/17 PASS，涵蓋 Batch272 lobby contract、Batch273 skin component contract、Quiz UI state、Multiplayer UI state、Quiz panel integration。
- 全量 Node suite、人工 Stable 視覺 gate、Windows／真機、live server／audio 本批未執行；不得宣稱已驗收。

## 下一批
繼續對照 `osu-game-modifiers.jpg` 及 AMQ 現有 Quiz／設定 UI，但先查清 AMQ canonical mod owner；若不存在，先做資料／規則 owner，不畫假 Mods。另一條可執行線是把 Quiz 答案自動完成、方向鍵／Enter／Escape、錯答後清空等行為做完整互動測試，依社群腳本提供的情境而非直接移植腳本。

> Compact Batch286 package note: the Batch284 Quiz screenshot binaries are superseded by `artifacts/batch286-quiz-gameplay-layout/` and are not duplicated in the latest package. Batch284 Multiplayer screenshots remain.
