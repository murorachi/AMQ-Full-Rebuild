# AMQ 功能真相表（第一輪靜態盤點）

> 來源：使用者提供的 使用者上傳的 `AMQ382(1).html`（檔案內標題為 Candidate381、含 Stage I 線索；本批只作靜態參考）與開工包文件。這是線索盤點，不是瀏覽器實測或完整功能驗收。每項都需在後續對照真實基準及測試。

| ID | 功能領域 | 目前證據 | 新版處理方向 | 狀態 |
|---|---|---|---|---|
| FUNC-001 | AMQ 模式 | `source-runtime`、QuizPool／QuizSession、QuizPanel 與核心／整合測試 | 維持單一 mode state 與明確 AMQ source mapping；舊版差異另行核對 | 新版內部契約有 Node／integration evidence；正式基準相容性未驗收 |
| FUNC-002 | EMQ 模式 | EMQ mapper、source-aware identity、source runtime 與 quiz／SRS tests | 維持來源隔離與獨立資料契約，不假設所有 AMQ 規則相同 | 新版內部契約有 Node／integration evidence；真實音訊與正式基準相容性未驗收 |
| FUNC-003 | MIX 模式 | QuizPool／QuizSession tests 驗證 AMQ:EMQ 2:1 權重與來源耗盡 fallback | 保留明確來源抽樣；AMQ-specific filter suppression 等待新版相應篩選控制與正式規則證據 | 權重／fallback 內部測試通過；完整舊版篩選語義未驗收 |
| FUNC-004 | 真實曲庫載入 | `data.js`、`emq-data.js`、source audit、mapper verifier 與 Repository integration | 經 adapter、validator、repository 建立單一 Catalog | 55,660 筆映射及內部契約通過；來源配套版本、瀏覽器載入與真實播放仍待驗收 |
| FUNC-005 | 音訊播放與備援 | `AudioService`、候選生成、timeout／cancel／fallback 與 AudioService+QuizSession integration；Batch 65 依 Candidate381 V82.54／V82.55 線索補上 EMQ Asia CDN 與 WebM sibling 候選 | AudioService 為單一播放 owner，實際 `playing` 才啟動計時；EMQ userup 順序為 Asia WebA → 原始 WebA → Asia WebM → 原始 WebM，Catbox mirror 保留原始候選 | 候選建構與失敗診斷 Node tests PASS；真實可聽性／瀏覽器 E2E BLOCKED，不能宣稱已修復所有音訊 |
| FUNC-006 | 搜尋／篩選／排序 | `query-index.js`、`catalog-browser.js` 與 query／browser integration tests | 共用 query index；篩選、排序、分頁與 facet 計數走同一路徑 | 新版核心 Node／integration 通過；舊版完整選項與真實瀏覽器待驗收 |
| FUNC-007 | 鍵盤選取與猜歌答案建議 | 曲庫列鍵盤選取已有 Node integration；Batch 65 新增 `src/ui/answer-suggestions.js`，將猜歌答案建議接回 Catalog 與 QuizPanel | 支援 NFKC／大小寫正規化、保留空白與標點結構、特定標點單向空白容錯、前 25 個相關度優先排序結果、ArrowUp／ArrowDown、Enter 選取但不提交、Escape、IME 組字防護與 ARIA combobox/listbox | Node module tests 8/8、QuizPanel integration PASS；真實瀏覽器外觀／焦點與舊版完整中文 alias 相容性待驗收 |
| FUNC-008 | 自訂清單／收藏／看番狀態 | 自訂清單 CRUD 與看番狀態 UI 有 Node integration；收藏功能依 Batch71 產品範圍決策明確排除 | 不建立收藏 store、收藏 UI 或收藏篩選；`aniFavorites_v1` 身份未知，不遷移／不寫入 | 清單／看番功能已接線；收藏不屬新版待實作範圍 |
| FUNC-009 | 學習中心／間隔複習 | FSRS scheduler、source-aware SRS stores、QuizPanel 與 integration tests | 保持排程純邏輯、來源隔離、評級後才可下一題 | 新版內部 Node／integration evidence；真實瀏覽器驗收待做 |
| FUNC-010 | 猜歌測驗與答案比對 | QuizEngine／QuizSession／QuizClock／AnswerEvaluator 與 quiz panel integration tests | 新版內部規則由測試保護；不虛構來源缺少的 aliases | 新版核心 Node PASS；舊版完整 aliases／規則與瀏覽器待驗收 |
| FUNC-011 | 多人模式 | 舊版 UI 有多人相關模組線索；服務端未取得 | 以獨立 adapter 隔離外部連線，不阻止單機啟動 | P2／外部服務阻塞，不屬目前單機核心收尾範圍 |
| FUNC-012 | 使用者設定／深色主題 | 猜歌設定已有版本化 store、錯誤／恢復提示與測試；深色主題未實作 | 維持已實作設定契約，主題另列 P2／待確認 | 猜歌設定已實作；深色主題未實作且不阻擋核心結案 |
| FUNC-013 | 場景背景設定 | 舊版 HTML 有 IndexedDB 設定程式線索 | 需先確認是否為必要功能及資料限制 | P2／待確認，不猜測擴大範圍 |
| FUNC-014 | AniList／MAL／VNDB 匯入 | 舊版工作區有匯入入口線索，外部服務與權限未驗收 | 確認認證、配額、權限及失敗情境後再獨立規劃 | P2／延後，不阻擋單機核心 |
| FUNC-015 | CSS／設計系統 | 現有新版 UI 骨架及 Candidate381 靜態參考；無真實瀏覽器／核准視覺驗收環境 | 進入階段 5 後依核准視覺基準真正替換舊實作 | 延後至 UI／CSS 階段；不可宣稱視覺驗收通過 |
| FUNC-016 | 可存取性／響應式 | 靜態 CSS 線索及 VM/fake DOM 測試；無真實瀏覽器 E2E | 保留焦點可見、窄螢幕與 reduced-transparency 要求並安排實際驗收 | BLOCKED：需可用瀏覽器導覽環境 |


## Batch 50 更新

已再次唯讀檢查使用者上傳的 `AMQ382(2).html`，其 SHA-256 與先前登記的參考檔相同。此檔實際標示 Candidate381，僅作靜態契約來源，不升格為 Candidate382 Stage 0。自訂清單／看番狀態資料模型已有足夠靜態線索建立新版 persistence API；收藏寫入身份仍不明。

## 盤點限制

- 不把靜態 HTML 內出現的字串當成「功能可正常運作」證據。
- 不把歷史註解當成當前實作的完整說明。
- 使用者已明確指定以其上傳的 `AMQ382(1).html` 作為舊版參考，本批不再搜尋不存在／不可得的 Candidate302。本檔實際 SHA-256 為 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`，HTML title 顯示 Candidate381，歷史註記含 Stage I 線索；因此記錄為「使用者指定的 Candidate382 參考檔」，不擅自宣稱它是 Stage 0。
- 歷史 Batch 18 盤點時尚未取得真實曲庫；Batch 20 後已將已核對的 `data.js`／`emq-data.js` 放入 `src/data/assets/`，目前 source audit／mapper verification 通過。這仍不證明 Candidate302 配套相容或真實音訊可播放。


## Batch 18 補充：產品核心功能契約盤點

以下契約是「下一步實作的可驗證要求」，不是宣稱功能已完成。依據為使用者上傳的 `AMQ382(1).html` 靜態內容與新版已實作的內部 API。凡涉及舊版遊戲規則、資料部署及實際播放，仍需在可操作環境驗證。

| 契約 ID | 功能切片 | 最低可驗證要求 | 目前證據／限制 | 優先級 |
|---|---|---|---|---|
| PC-01 | 曲庫載入與狀態 | UI 只能讀取共享載入狀態；需區分未載入、載入中、成功、部分有效、空資料、失敗；舊請求不得覆蓋新結果 | Data pipeline、共享 state 與 catalog browser 狀態投影已有 Node／integration tests；真實瀏覽器待驗收 | P0 |
| PC-02 | 曲庫瀏覽與搜尋 | 使用唯一 query index；支援歌曲標題、歌手、作品標題／別名及歌曲 aliases；搜尋結果需有總數與分頁 | `query-index.js`、`catalog-browser.js` 與 UI integration 已接線；舊版完整語義及瀏覽器待驗收 | P0 |
| PC-03 | 篩選、排序、分組 | 篩選條件共用查詢路徑；排序穩定；缺值固定最後；分組不受分頁限制 | Query index、catalog browser UI integration 與 grouping/sorting tests 已通過；舊版實際選項與預設值尚未逐項核對 | P0 |
| PC-04 | AMQ／EMQ／MIX 模式 | 模式是單一共享狀態；來源組合與模式規則必須明確配置；切換會取消舊載入 | Shared state、registry、bootstrap、QuizPool 與 QuizPanel 有 Node／integration tests；舊版篩選抑制規則與瀏覽器待驗收 | P0 |
| PC-05 | 猜歌回合 | 必須定義 start、pause、resume、submit、next、timeout、end、reset 的合法轉移；非法轉移不得偷改分數或題目 | 新版 QuizEngine／QuizSession／QuizClock 已實作並有 unit／integration tests；舊版完整規則及真實瀏覽器 timer 行為未驗收 | P0；內部契約 PASS |
| PC-06 | 答案比對 | 需分開定義輸入正規化、別名、大小寫／符號處理、正確答案回饋與重複提交 | 新版 AnswerEvaluator 已有正規化、精確／部分比對、alias fixtures 與重複提交回歸；來源缺少的舊版 aliases 不自行編造 | P0；內部契約 PASS |
| PC-07 | 音訊播放 | 單一播放請求 owner；候選來源順序明確；新請求取消舊請求；區分載入、播放失敗與實際可聽 | AudioService、QuizSession 與 fallback／cancel／pause/resume integration tests 已通過；真實可聽性仍未驗收 | P0 |
| PC-08 | 收藏／自訂清單／看番狀態 | 清單與看番狀態有持久化 API 及新版管理 UI；處理重複操作、保存失敗、source-aware 身份與清單刪除參照清理 | `personal-library-store.js`、`catalog-browser.js`、QuizPool source-aware eligibility、保存失敗 UI tests 已完成；legacy source-less IDs 不自動遷移 | P1；收藏身份未知，瀏覽器驗收待做 |
| PC-09 | 設定與主題 | 設定需版本化；讀寫失敗有安全降級；UI 不持有第二份權威狀態 | Quiz settings 已有版本化 store、recovery/write-failure 提示及測試；深色主題／背景設定未實作，列 P2 待確認 | P1（quiz settings）；主題 P2 |
| PC-10 | 學習中心／間隔複習 | 定義學習項目、複習到期規則、評分結果與排程；先以可測試純邏輯實作 | FSRS scheduler、AMQ／EMQ source-aware stores、QuizPanel SRS UI 與 due queue integration 已實作；瀏覽器／真實資料驗收待做 | P1；瀏覽器驗收待做 |
| PC-11 | 響應式與無障礙 | 主要流程可鍵盤操作；焦點可見；窄螢幕不遮住主要操作；減少透明效果偏好可用 | 參考檔有 CSS 線索；僅靜態證據，無瀏覽器驗收 | P1 |
| PC-12 | 外部匯入／多人 | 外部服務必須有 timeout、取消、錯誤提示與隔離；不得阻止單機基本啟動 | 參考檔有 AniList／VNDB／多人線索；服務及權限未驗收 | P2 |

### 建議實作順序

1. 先做可操作的曲庫瀏覽切片（PC-01 至 PC-03），因 query index 與資料管線已有可測試底層。
2. 再用參考檔逐項核實猜歌回合及答案比對規則（PC-05、PC-06），把規則寫成測試後才實作引擎。
3. 同步盤點音訊 fallback 的真實候選順序與事件生命週期（PC-07）；不把 URL 字串存在當作可播放。
4. 收藏、設定、SRS、外部匯入依必要性排序，避免先建通用框架。


## Batch 40：必要功能真相表（以目前程式與測試為證據）

> 狀態不是產品最終驗收。`已實作／Node PASS` 只代表目前模組契約與自動測試通過；真實瀏覽器、舊版完整相容及外部服務仍需獨立驗證。

| 功能領域 | 優先級 | 現況分類 | 直接證據 | 尚缺驗收／處理 |
|---|---|---|---|---|
| AMQ 模式與曲庫 mapping | P0 必要 | 已實作，待真實基準相容驗收 | `src/data/source-mappers.js`、`src/data/source-runtime.js`、`tests/source-runtime.integration.test.cjs` | 來源資料配套版本未證實；不宣稱舊版相容 |
| EMQ 模式與來源隔離 | P0 必要 | 已實作，待舊版規則驗收 | `src/data/source-mappers.js`、`src/data/identity.js`、`tests/data-identity.test.cjs` | 真實 EMQ 音源可播性未驗證 |
| MIX 選池／權重／耗盡 fallback | P0 必要 | 已實作，部分舊版篩選規則延後 | `src/engine/quiz-pool.js`、`src/engine/quiz-session.js`、相關測試 | AMQ-specific watch/season/difficulty/hard-pool suppression 未接線；新版無相應控制 |
| 真實曲庫載入、取消、失敗狀態 | P0 必要 | 已實作，待瀏覽器整合驗收 | `src/data/repository.js`、`src/data/load-state.js`、`tests/data-pipeline.integration.test.cjs` | 瀏覽器 E2E BLOCKED；不等於實際部署驗收 |
| 曲庫搜尋／排序／分頁 | P0 必要 | 核心已實作，產品 UI 待階段 5 接線／驗收 | `src/data/query-index.js`、`tests/query-index.test.cjs`、`src/ui/catalog-browser.js` | 舊版選項與預設值尚未完整比對 |
| 猜歌狀態與計時 | P0 必要 | 核心已實作，Node 回歸 PASS | `src/engine/quiz-engine.js`、`quiz-session.js`、`quiz-clock.js`、`tests/quiz-session.test.cjs` | 真實瀏覽器 timer／背景分頁行為未驗收 |
| 答案正規化與計分 | P0 必要 | 核心已實作，Node 回歸 PASS | `src/engine/answer-evaluator.js`、`tests/answer-evaluator.test.cjs` | 舊版完整規則仍需真實基準證據 |
| 音訊候選、備援、取消、playing 計時起點 | P0 必要 | 服務契約已實作，mock 測試 PASS | `src/audio/audio-service.js`、`tests/audio-service.test.cjs` | 真實媒體事件、跨域及可聽性 BLOCKED／未驗證 |
| 熟悉度保存／恢復／來源隔離 | P1 必要 | 已實作；Batch 40 防止讀取失敗後覆寫未知資料 | `src/persistence/familiarity-store.js`、`tests/familiarity-store.test.cjs` | 多分頁真實瀏覽器驗收未完成 |
| 答題歷史明細／摘要／舊 key 保護 | P1 必要 | 已實作，Node 測試；舊 key 只讀 | `src/persistence/quiz-history-store.js`、`tests/quiz-history-store.test.cjs` | 真實跨分頁／Quota 行為未驗收 |
| FSRS 排程／AMQ 舊 key／EMQ 獨立 key | P1 必要 | 已實作，來源隔離與原子寫入有測試 | `src/persistence/srs-store.js`、`src/learning/fsrs-scheduler.js`、`tests/srs-store.test.cjs` | 舊版 schedule 不含 source，不自動猜測遷移 |
| 歌曲／作品黑名單 | P1 必要 | 已實作，Node 測試；AMQ 範圍與 EMQ 隔離 | `src/persistence/blacklist-store.js`、`tests/blacklist-store.test.cjs` | 瀏覽器多分頁驗收未完成 |
| 猜歌設定持久化 | P1 必要 | Batch 41 store 接線完成；Batch 42 補上 recovery notice、寫入失敗通知與 storage clear／聚焦輸入回歸 | `src/persistence/app-settings-store.js`、`src/ui/quiz-panel.js`、`tests/app-settings-store.test.cjs`、`tests/quiz-panel.test.cjs` | Node mock 測試通過；真實瀏覽器與跨分頁驗收待做 |
| 深色主題／背景設定 | P2 待確認 | 尚未實作，與猜歌設定 store 分開處理 | `FUNC-012`、`FUNC-013` 靜態線索 | 不憑靜態 HTML 線索直接複製功能 |
| 自訂清單／看番狀態 UI 與出題池過濾 | P1 必要 | 已接線、source-aware 並有 Node integration 測試；瀏覽器待驗收 | `src/ui/catalog-browser.js`、`src/persistence/personal-library-store.js`、`src/ui/quiz-panel.js` | legacy source-less membership 不自動遷移；收藏身份未證實，不寫入 |
| 學習中心／SRS UI | P1 必要 | FSRS、source-aware stores、QuizPanel 操作流程及 Node integration 已接線 | `src/learning/fsrs-scheduler.js`、`src/persistence/srs-store.js`、`src/ui/quiz-panel.js` | 真實瀏覽器操作與音訊待驗收；純視覺重構仍排階段 5 |
| 多人模式 | P2 延後／外部阻塞 | 未實作服務端整合 | `docs/ACCEPTANCE.md` PC-12 | 缺少服務端協定與可用測試環境，不影響單機核心 |
| AniList／MAL／VNDB 匯入 | P2 延後 | 未實作完整外部服務 | `docs/FUNCTION_INVENTORY.md` FUNC-014 | 需先確認認證、配額及權限，不阻擋單機核心 |
| 背景 IndexedDB 設定 | P2 待確認 | 未確認必要性 | FUNC-013 靜態線索 | 不憑靜態 HTML 線索直接複製功能 |
| UI／CSS、響應式、無障礙 | 階段 5 | 有部分現有骨架／CSS，未做完整瀏覽器驗收 | `src/index.html`、`src/styles.css`、`docs/ACCEPTANCE.md` | 保留既有視覺線索；全面重構最後做；瀏覽器 E2E BLOCKED |

### Batch 40 持久化檢查結論
- 熟悉度：AMQ key 保留 legacy fallback；EMQ 使用獨立 key；寫入失敗會回滾記憶體狀態。Batch 40 新增讀取失敗保護，不能把不可讀當空 map 後覆寫原資料。
- 答題歷史：新版明細／摘要使用新 key；legacy detail／summary 為只讀來源；有來源身份與重複 entry 去重測試。明細與摘要是分開寫入，不保證跨兩個 localStorage key 的交易原子性，失敗狀態可查詢。
- SRS：AMQ 保留舊 key，EMQ 使用獨立來源標記 key；不自動把 source-less legacy schedule 推測為 EMQ。
- 黑名單：歌曲／作品 key 分開，記錄判斷只將 AMQ 記錄套用舊版 AMQ 黑名單；寫入失敗不發布新記憶體狀態。
- 設定（Batch 40 當時狀態）：尚無獨立、完整版本化設定 store；Batch 41 已新增目前猜歌控制項的版本化 store，但不涵蓋深色主題、背景 IndexedDB 或其他尚未確認功能。


### Batch 41 持久化實作更新

- 答題歷史摘要讀取失敗現已阻止寫入，避免未知摘要被當成空摘要覆蓋；成功 reload 後可解除阻塞。
- 猜歌設定已由 `appSettingsStore` 以版本化 schema 保存，並接線到目標、題數、每題秒數、部分答案與自動播放控制。
- 深色主題、背景 IndexedDB、收藏／自訂清單及外部匯入仍未實作／待確認，不受本批設定 store 的完成狀態涵蓋。


### Batch 42 storage failure matrix 更新

- SRS 與新版答題歷史在外部 storage event 讀取失敗時保留最後已知快照，避免 UI 暫時投影為空資料；成功重讀後才以新資料取代。
- 舊版答題歷史是唯讀資料。其讀取例外現在由 `legacyReadError` 暴露，UI 不再靜默把讀取失敗顯示成沒有舊紀錄。
- 設定 store 的無效資料隔離成功會顯示 recovery notice；寫入失敗會通知訂閱者，UI 會顯示儲存警告。外部設定更新不覆蓋目前聚焦控制項。
- 上述狀態與恢復有 Node/mock storage 回歸測試；真實瀏覽器 E2E 仍 BLOCKED。


### Batch 43 persistence audit

- 已補齊：SRS 寫入／flush 失敗通知；blacklist 歌曲／作品寫入失敗通知與分離錯誤欄位；familiarity 外部讀取失敗事件不再回報持久化成功。
- History 的 `summaryPersisted` 現在排除 debounce pending 狀態；`fullyPersisted` 可用於判斷 detail + summary 是否都完成。detail／summary 跨 key 非原子性仍屬已知限制。
- 真實瀏覽器 localStorage、跨分頁、quota、pagehide 仍待環境解除阻塞後驗收。


## Batch 44：必要功能跨模組驗收矩陣

| 路徑 | 目前自動化證據 | 結論／剩餘缺口 |
|---|---|---|
| AMQ／EMQ／MIX 載入與取消 | `tests/data-pipeline.integration.test.cjs`、`tests/source-runtime.integration.test.cjs` | Node integration PASS；真實部署與瀏覽器載入未驗收 |
| 搜尋、篩選、排序、分頁、facet | `tests/query-index.test.cjs`、`tests/catalog-browser.test.cjs` | 核心與 controller 測試存在；舊版 UI 選項逐項比對及瀏覽器布局未驗收 |
| QuizSession + AudioService 真實事件契約（mock media） | `tests/audio-session.integration.test.cjs` | 新增整合測試：canplay 不啟動倒數，playing 才啟動；pause 凍結剩餘時間、resume 延續 deadline、dispose 清理 timer。這是 mock media 的整合證據，不是真實音源驗收 |
| QuizSession + familiarity/history | `tests/quiz-session.test.cjs` | 答題／timeout 寫入、未播放跳過不寫入、來源隔離與 all-target 皆有測試 |
| Quiz panel + SRS/blacklist/history/settings | `tests/quiz-panel.test.cjs` | 模式切換、SRS 評級、黑名單排除、EMQ ID 隔離、設定持久化已有整合測試；使用 fake DOM/audio 與部分 mock store |
| 真實瀏覽器 E2E／真實音訊 | 先前 `ERR_BLOCKED_BY_ADMINISTRATOR` | BLOCKED；不可用 Node 測試替代 |

Batch 44 沒有宣稱舊版全功能相容。自訂清單 CRUD、完整舊版篩選語義、多人與外部匯入仍是未完成／延後功能，需依產品必要性另外決定是否納入核心結案範圍。


### Batch 45：Catalog Browser 狀態投影回歸

- 修正 `src/ui/catalog-browser.js` 的狀態文案：空來源不再被誤稱為「沒有符合條件的歌曲」；載入失敗不再在空狀態區只顯示「曲庫尚未載入」；摘要使用「符合條件」標示篩選後的結果總數，避免被誤讀為整份曲庫數量。
- 新增 `tests/catalog-browser.integration.test.cjs`，透過 mount + shared state + runtime + query index 驗證 loading、loaded、搜尋無結果、分頁、empty source、failed state 與 dispose。
- 這是 fake DOM／mock runtime 的 Node integration；沒有宣稱真實瀏覽器布局、鍵盤、responsive 或真實資料部署已驗收。


### Batch 46：持久化結果跨模組錯誤傳遞

- `QuizSession.persistHistory()` 會辨別 history detail 寫入成功與 summary 寫入失敗；明確 summary failure 會觸發部分持久化警告，正常 debounce pending 不會觸發錯誤提示。
- 收藏／自訂清單／看番狀態仍未實作。現有 `docs/CANDIDATE382_STAGEI_STATIC_AUDIT.md` 只有自訂清單 handler／grid observer／timer 的高層靜態線索；本工作副本不含原始 `AMQ382(1).html`，無法核實資料 schema、key、清單成員身份及刪除語義。不得把自訂新 schema 宣稱為舊版相容。解除阻塞條件：取得可讀的使用者指定參考 HTML，或使用者明確批准一份新版獨立資料契約。


## Batch 49 核心結案分類

- **新版內部核心已實作且 Node／整合測試通過：** source adapters／repository／catalog query、AMQ／EMQ／MIX pool、QuizEngine／QuizSession／Clock、AudioService mock media contract、familiarity／history／SRS／blacklist／quiz settings、catalog browser functional state projection。
- **已實作但真實瀏覽器／外部環境待驗收：** 真實曲庫部署與舊版配套相容、真實音源可聽性、localStorage 多分頁／quota／pagehide、鍵盤與響應式、乾淨 Windows 啟動。
- **未實作且缺少可核對契約：** 收藏功能依 Batch71 明確排除；自訂清單／看番狀態 CRUD 已由後續批次接線。
- **明確延後：** 多人服務端、AniList／MAL／VNDB 完整匯入、背景 IndexedDB、深色主題與全面 UI／CSS 重構（後者依階段 5 執行）。


## Batch 52 功能狀態更新

- 自訂清單 CRUD／作品 membership：已實作來源明確 `workRefs`，舊 `animeIds` 保留為未解析資料。
- 看番狀態：新版 UI 已改用來源明確 work-ref API；舊裸 ID key 不會自動與新來源 key 合併。
- 猜歌出題池：已接入目前選取清單，AMQ／EMQ／MIX 依 source-aware work membership 過濾。
- 收藏 `aniFavorites_v1`：依 Batch71 產品範圍決策不實作、不遷移。
- 真實瀏覽器 E2E、真實音訊可聽性、乾淨 Windows 啟動及 Candidate302／Candidate382 Stage 0 相容性：仍未驗收。


## Batch 53 persistence UI 狀態投影

- Personal library：操作失敗不得顯示成功文案；list/watchlist read/write blocked、recovery 與 source-less legacy watch status 有明確提示。
- Quiz panel：familiarity source read-blocked 可在下一次答題前顯示；SRS blocked/error/recovery warning 優先於舊成功操作訊息；AMQ blacklist persistence 問題在 AMQ 與 MIX 都會顯示。
- Quiz history：detail／summary write failure、blocked、recovery 與 legacy read failure 維持獨立提示。
- 以上為 Node／VM/fake storage UI integration 測試；不等於真實瀏覽器 localStorage 跨分頁驗收。


## Batch 54：核心回歸狀態

- AudioService + QuizSession integration 現在涵蓋 primary play rejection → backup playing、失敗候選釋放、playing 才啟動單一倒數、pause/resume、dispose 與遲到 media event。
- QuizPanel mode-switch integration 驗證舊 AudioService 的遲到事件不能改寫新模式 `questionStatus`。
- PC-08 清單／看番狀態與 QuizPool source-aware eligibility 已接線；PC-09 quiz settings persistence 已接線；PC-10 FSRS／SRS UI 已接線。以上仍不代表真實瀏覽器或舊版完整相容性通過。
- P1 已實作部分的剩餘驗收多屬真實瀏覽器／跨分頁／音訊外部條件。收藏身份、source-less legacy migration 不具足夠證據，維持明確阻塞。


## Batch 64 使用者實機驗收增補

- 基本啟動、AMQ／EMQ／MIX、模式切換、答題／下一題、搜尋／篩選／排序及測試資料保存：使用者回報可用。
- 猜歌答案建議下拉選單：確認為新版可見功能缺口，應列必要互動回歸，而不是一般視覺改版。Candidate381 靜態參考提供行為線索，但不證明 Candidate302 相容。
- 收藏：目前 UI 沒有可見收藏操作；舊收藏 key 身份未證實，需分開處理 UI 功能與資料相容性，不可猜測寫入。
- 音訊：部分曲目 `AUDIO_ALL_CANDIDATES_FAILED`，實際根因未知；需補可診斷證據與真實瀏覽器驗收。


## Batch 68 答案建議候選體驗補充
- 舊版 V82.x 可確證匹配片段會使用強調色與粗體；新版已恢復對應行為，並保留 Batch 67 的穩定 DOM 生命週期。
- EMQ 別名 `ta`／`n`、`aa`、`wa`／`wt`／`wn` 已有來源映射及測試。
- 舊版繁體中文作品名稱仍依賴 Chinese Title Provider 與設定開關；Batch 68 當時尚未接回，新版接線進度以後續批次紀錄為準。

## Batch 69 答案建議匹配規格更新

- `src/ui/answer-suggestions.js` 已改為保留查詢空白／標點結構的 matcher；移除 compact 無空白比對。
- 指定標點與難輸入特殊 Unicode 各自只允許「相同字元或空白」的候選位置容錯；不同標點不互換，空白輸入不會反向匹配任意標點。
- 候選排序現在先按匹配相關度，再按字元長度及穩定字典順序；這項規格是使用者明確確認的新版行為，與舊版 V82.x 的 separatorMatcher／短字串排序存在差異。
- `tests/answer-suggestions.test.cjs` 15 個情境 PASS；真實瀏覽器外觀／互動仍待使用者驗收。


## Batch 70：舊版與新版功能差異盤點（2026-10-27）

- 詳細 50 項對照矩陣見 `docs/FUNCTION_PARITY_AUDIT_BATCH70.md`。
- 本次使用 `AMQ382(2).html`（SHA-256 `65f7d022b017b931e61056c74a6c51c210d8561e797858372641739cbf80053e`，內容標示 Candidate381／V82.x）作靜態參考；不宣稱 Candidate302／Candidate382 Stage 0 相容，也沒有把靜態控制項當成可正常運作的實機證據。
- 已確認新版核心模組之外，仍有明顯功能差異：作品圖鑑／探索新歌／弱點補強／統計儀表板、歌曲標籤、自由聽歌播放器與佇列、完整備份還原、舊版完整猜歌篩選與 Sample 設定、中文作品標題 provider、主題／背景、AniList／MAL／VNDB、多人模式等。收藏已依 Batch71 排除。
- 差異不等於每項都必須復刻。P0／P1 先按必要學習流程、資料安全與實際驗收排序；自由聽歌／外部服務／純視覺周邊先列 P2。真實瀏覽器／音訊仍未驗收，UI／CSS 大重構依原決策排最後。


## Batch 71：使用者產品範圍覆寫

以 `docs/PRODUCT_SCOPE_DECISIONS_BATCH71.md` 為準：不做收藏、獨立動畫作品圖鑑（暫不做）、歌手圖鑑、探索新歌獨立模式、弱點補強獨立模式、歌曲標籤管理、待聽佇列與主題切換；其餘 Batch 70 差異原則上均納入新版待實作範圍。背景直接採深色預設，不做亮／暗切換。全域 SRS 需有總開關、自動評估、手動覆寫、跨模式出題與統計。

## Batch 80 功能狀態更新
- 猜歌 eligibility 已接入年份起迄／未知年份、AMQ 來源可用的作品類型、歌曲類型、難度起迄、看番狀態；既有來源模式、黑名單與 source-aware 自訂清單同時生效。
- 新篩選保存於既有 versioned app settings store，且包含在現有完整備份／還原 key 中。Node integration／backup round-trip 已通過，真實瀏覽器尚未驗收。
- 季別、Random Sample、片段起始位置、自動下一題延遲仍未完成；季別是因目前已核對來源資料沒有可信 season 欄位，不可由年份猜測。
- 中文標題 Provider 已完成第一版可測試接線，但真實外部來源與曲庫全文搜尋整合仍待驗收；資料庫更新、自由播放歷史、統計儀表板、自由播放欄、外部服務及多人模式仍待實作，見 `docs/MASTER_CHECKLIST.md`。


## Batch 82 中文標題 Provider 第一版接線
- 使用固定版本的 AniList Chinese／Bangumi JSON 資料來源，透過明確的 MAL／VNDB／AniList site ID crosswalk 對應，不以相似標題猜配。
- 既有 `chineseTitlesEnabled` 設定預設關閉；啟用才下載外部資料與按需載入 OpenCC。答案建議會使用中文別名，答案揭曉可顯示已對應的中文作品名。
- Provider 支援 IndexedDB 7 天快取、過期快取回退、請求 timeout／取消及部分來源失敗。Node 測試通過不代表瀏覽器遠端資料／CORS／OpenCC CDN 實機驗收。


## Batch 85 增補：自由播放歷史與統計核心 API
- 自由播放歷史持久化 API 已存在：`AMQPersistence.playbackHistoryStore`，但尚未由播放器 Dock 呼叫。
- 統計摘要純函式已存在：`AMQLearning.statisticsDashboard.buildDashboard()`，能彙整傳入的答題歷史、熟悉度、SRS 與播放歷史 snapshots；dashboard UI 尚未實作。
- 不將此 API 狀態等同於完整自由播放器或儀表板功能完成。


## Batch 86 增補：自由播放與統計 UI
- 自由播放 Dock 已接線：`src/ui/free-player-dock.js`，提供可播放曲目搜尋／選取、播放／恢復、暫停、停止、隨機播放。它使用獨立 AudioService，並在實際播放至少 5 秒後寫入既有 playback history store。真實音訊／瀏覽器仍待驗收。
- 統計儀表板最小 UI 已接線：`src/ui/statistics-dashboard-panel.js`，以既有答題歷史、熟悉度、AMQ／EMQ SRS 與播放歷史快照呼叫 `buildDashboard()`。衍生數字不保存；Store 讀取失敗時停止投影。
- 外部服務整合與多人模式仍未實作；AMQ-967／968 完整篩選回歸矩陣仍待完成。


## Batch 87 增補：完整曲庫瀏覽篩選第一階段
- Catalog Browser 現已支援年份起迄／未知年份、年代、作品細分類、看番狀態、熟悉度及作品年份排序；query-index facets 隨其他篩選條件重算。
- 出題篩選回歸新增 MIX 未知年份開關、來源缺失 metadata 不補值、難度上下界及 AMQ／EMQ／MIX 組合矩陣。仍需擴大交叉組合並核對舊版實際語義。


## Batch184 增補：工作區偏好與鍵盤快捷鍵

- 已實作：獨立工作區偏好持久化、12 個可自訂快捷鍵、快捷鍵衝突拒絕、輸入欄位／IME 保護、10 個區塊顯示切換、預設功能入口、統計區塊排序。
- 仍未實機驗收：快捷鍵實際錄製／執行、瀏覽器焦點、響應式 UI 與跨分頁操作；Chromium 在本環境啟動逾時。
- 未實作：多組具名曲庫篩選預設；既有猜歌篩選保存仍由 App Settings Store 管理。


## Batch 187 current-scope correction (2026-10-28)

The latest user-approved feature scope supersedes historical Batch 71 exclusion notes where they conflict. Required remaining work includes named Catalog filter presets (implemented in Batch 187), any verified gaps in advanced quiz filters, batch select/apply, completing the Free Player Dock and queue/history integration, backup/restore UI workflow, song-tag CRUD and filter integration, work-level learning progress, player visualization, AniList/MAL/VNDB provider integration, and complete multiplayer play flow.

Explicitly out of scope by latest user decision: standalone new/unexplored-song discovery, standalone singer encyclopedia, and answer-alias hint UI. Do not re-add these to pending work. Dark theme/background and comprehensive UI/CSS replacement remain deferred to the final UI stage.

Advanced quiz-filter audit: year range/unknown-year behavior, work subtype, difficulty bounds, song type and watch-status filters already exist and have regression coverage. Season filtering remains unavailable because the current verified source contract does not provide a reliable season field.

Named Catalog presets: implemented in Batch 187. They are stored in `amqLearningAppSettingsV1.catalogFilterPresets`; active filter state remains exclusively in `AMQCatalogBrowser` controller.


## Batch 188 status update (2026-10-28)

- Named Catalog filter presets: implemented in Batch 187.
- Batch select/apply: implemented for source-aware row/page selection, batch add-to-current-custom-list, and bulk tag apply/remove. Batch list operations use existing per-work persistence API and report partial failure honestly.
- Song tag management: implemented in Batch 188 via the single `AMQPersistence.songTagsStore`; CRUD, source-aware assignments, query-index tag filter and backup/restore validation are connected.
- Explicitly excluded by latest user scope: new/unexplored-song discovery, standalone singer encyclopedia, answer-alias hint UI. Do not re-add.
- Remaining feature priorities: Free Player Dock controls/queue/history, backup/restore UI completion, work-level learning progress, player visualization, AniList/MAL/VNDB providers, multiplayer completion. Theme/background and full UI/CSS replacement remain deferred; osu!stable/OSK design direction remains fixed.


## Batch 189 status update (2026-10-28)

- Free Player Dock: volume, mute, seek/progress, collapse, queue controls, previous/next, sequential/loop/shuffle, natural-ended auto advance and playback history wiring implemented. Browser acceptance remains pending.
- AudioService remains the only media owner; the Dock uses its own AudioService instance and does not share QuizSession playback state.
- Playback history retains the 5-second actual-playing threshold and uses per-Dock lifetime IDs to avoid duplicate-ID collisions after remount.
- Next priorities: full backup/restore UI workflow and work-level learning progress, then player visualization, AniList/MAL/VNDB integrations, multiplayer.
