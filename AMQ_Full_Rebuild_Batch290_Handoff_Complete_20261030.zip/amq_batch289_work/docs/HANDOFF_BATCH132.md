# AMQ 新版重建交接：Batch132（Remote SRS stale callback 防護）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 唯讀。

## 修改
- `src/ui/account-panel.js`：新增 `authGeneration`，阻止過期 `/api/auth/me` refresh 與舊 user bridge connect 覆蓋新帳號。`activateUser()` 在成功／失敗路徑檢查 generation、disposed、user ID；`refreshRemoteSchedules()` 在 flush／discard／connect 邊界檢查 generation／expected user ID。dispose 後 DOM render／message／error helper 不再寫入。
- 初始 guest boot 不再多發 `configureSrsStores(null)`；只有已存在 user／bridge 時才 detach。
- `tests/account-panel.integration.test.cjs`：新增兩個 deferred response race tests：舊 `/api/auth/me` 回應晚到、舊帳號 bridge connect 晚到。

## 驗證
- `node tests/account-panel.integration.test.cjs`：PASS。
- `node tests/remote-srs-bridge.test.cjs`：12/12 PASS。
- 全量 57 個非-tooling test scripts 逐檔 exit 0，分組執行；tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
- AMQ SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`，未改變。

## 封包驗證
- 最終 Manifest 294 entries，missing 0／stale 0／hash mismatch 0。
- ZIP 295 files，CRC PASS，missing 0／extra 0；未包含 `.pem`／`.key` 私鑰檔。

## 未解決
- 真實瀏覽器多分頁、IndexedDB quota／reload／tab-close E2E 未驗收；Node deferred response tests 只證明 async race contract。

## 下一步
Batch133：擴充多人 server answer／timeout／request replay 的 race regression，確認同一 player/round 最多一筆 assessment，且 transaction／idempotency 在同時 timeout 與 answer 到達時保持原子。
