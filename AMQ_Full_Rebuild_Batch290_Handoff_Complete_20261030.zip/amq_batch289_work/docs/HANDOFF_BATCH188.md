# Batch188 交接：曲庫批次操作與歌曲標籤

日期：2026-10-28
工作副本：`/mnt/data/amq_batch153_work`

## 本批完成

### Song Tags Store
- 新增 `src/persistence/song-tags-store.js`，資料 key 為 `amqSongTagsV1`，recovery key 為 `amqSongTagsRecoveryV1`。
- 提供標籤建立／重新命名／刪除、歌曲關聯設定／移除、批次套用／移除、讀取／刷新／訂閱／dispose。
- 標籤名稱正規化，1–32 字，不分大小寫不可重複，最多 200 個。
- 使用 `AMQData.identity.createIdentity(source, id)` 作為歌曲關聯鍵，只接受 AMQ／EMQ；同 ID 不跨來源混用。
- 損壞 payload 會先隔離；storage read/write failure 不會假裝保存成功。批次標籤更新一次 commit，失敗不提交記憶體狀態。

### Query-index／Catalog UI
- `src/data/query-index.js` 新增 `tagId` filter；與其他條件 AND 組合，多 tag IDs 使用 any-match。record snapshot 的 `tagIds` 會凍結。
- Catalog Browser 將 tag assignments 作為衍生 snapshot 接入 query-index；tag store 更新後重建索引。
- UI 新增標籤建立／改名／刪除、標籤篩選、每列 checkbox、選取本頁、清除選取、批次加入目前自訂清單、批次套用／移除標籤。
- 選取狀態使用 source-aware identity，跨分頁保留；切換 AMQ／EMQ／MIX 清空，避免跨模式誤操作。
- 刪除活動篩選標籤會清除失效的 filter。具名曲庫預設 schema 同步支援 `tagId`。
- 批次加入個人清單沿用既有逐作品 API，可能部分成功；UI 回報成功／失敗數，不宣稱原子性。標籤批次操作是單次提交。

### Backup／restore
- `src/persistence/backup-restore.js` 將 `amqSongTagsV1` 加入支援 key 清單，preflight 使用 `songTagsStore.normalizePayload()` 驗證。
- 舊備份若省略標籤 key，還原時不會刪除目前標籤；無效 tag payload 在寫入前拒絕。

### 文件
- 新增 `docs/SONG_TAGS_CONTRACT_BATCH188.md`。
- 更新 `docs/DATA_CONTRACT.md`、`docs/BACKUP_RESTORE_CONTRACT_BATCH76.md`、`docs/PRODUCT_SCOPE_DECISIONS_BATCH187.md`、`docs/FUNCTION_INVENTORY.md`、`AI_START_HERE.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md` 與 `tests/tests.html`。

## 測試證據

- `tests/song-tags-store.test.cjs`：8/8 PASS。
- `tests/catalog-browser.test.cjs`：6/6 + tag filter controller PASS。
- `tests/catalog-browser.integration.test.cjs`：PASS，覆蓋 tag CRUD、source-aware assignments、tag filter、批次選取／標籤操作、批次加入自訂清單。
- `tests/query-index.test.cjs`：tag filter composition PASS。
- `tests/backup-restore.test.cjs`：11/11 scenarios，含 tag export／preflight／restore。
- `tests/app-lifecycle.integration.test.cjs`：mount/dispose/remount 與 rollback/retry PASS。
- 全量 74 個 `tests/*.test.cjs`：74/74 個獨立 exit code 為 0。證據在 `artifacts/batch188-regression/node-tests/`、`status/`、`node-tests.tsv`／`node-tests.json`。首輪 runner 觸及外層時間限制時，`quiz-pool.test.cjs` 已獨立重跑 10/10 PASS，最終所有 74 個 status 都是 0。
- Architecture Checker：1,095 PASS／0 FAIL，`artifacts/batch188-regression/architecture.log`。
- OSK import panel harness：12/12，`artifacts/batch188-regression/osk-harness.log`。
- 170 個 JS/CJS `node --check` PASS，`artifacts/batch188-regression/syntax-checks.json`。
- AMQ／EMQ 資產未修改，hash 與前批一致：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 未驗收／限制

- Fake DOM／Node tests 不代表真實瀏覽器多選與標籤 UI 視覺驗收。
- 真實音訊、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤及 Candidate302／Candidate382 Stage 0 相容性仍未驗收。
- 工作副本無 `.git`，未初始化。正式基準原始檔缺席，未做 hash／相容性聲稱。

## 下一批 Batch189

1. 完成 Free Player Dock 音量、靜音、收合與播放控制。
2. 新增自由播放佇列及順序／循環／隨機模式，明確定義目前曲目刪除、空佇列、切歌失敗、暫停恢復及模式切換。
3. 將實際播放事件接入播放歷史，保留至少播放 5 秒才記錄的規則，不重複記錄同一次播放。
4. 全量 Node tests、architecture、OSK、syntax；更新同一份清單並交付完整 ZIP／SHA-256。
