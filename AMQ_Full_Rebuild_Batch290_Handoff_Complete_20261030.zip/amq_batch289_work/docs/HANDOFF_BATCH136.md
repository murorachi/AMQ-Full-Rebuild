# AMQ 新版重建交接：Batch136（Closed room hot-cache retention）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。工作副本沒有 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 維持唯讀。

## 決策
Closed room 不做 durable delete。保留成員仍可查閱 closed snapshot，成功的 command requestId 仍可重放；相關 SRS event 也保持持久化。未定義歷史查閱／replay 保證期限前，不按 `updated_at` 清理任何資料。

## 修改
- `server/multiplayer-host.cjs`：`ensureLoaded()` 只 hydrate 非 closed rows；closed rooms 由 `roomEntry()` 按 ID 從 SQLite lazy-load，僅用於當次操作、不加入 `rooms` Map。
- `server/multiplayer-host.cjs`：成功 command 將 phase 推進至 closed 後，清除 timer 並 evict hot entry。
- `server/multiplayer-host.cjs`：`runSerialized()` 最後一個 pending operation 完成後清除 queue tail，避免 per-room Promise map 隨歷史房間無界成長。
- `tests/multiplayer-host-retention.test.cjs`：新增 closed row／command record 持久保留、restart snapshot、member authorization、close command replay、active room restart recovery regression。
- 更新 `docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、`docs/NEXT_SESSION_PROMPT.md`、`AI_START_HERE.md` 與 manifest。

## Targeted tests
- `node --check server/multiplayer-host.cjs`：PASS。
- `node --test tests/multiplayer-host-retention.test.cjs tests/multiplayer-host.integration.test.cjs tests/multiplayer-http.integration.test.cjs`：4/4 PASS。
- 最終 Batch139 regression：61/61 非-tooling scripts、tooling 13/13、architecture 925/0、source audit／mapper／5-run benchmark、143 個 JS/CJS syntax checks PASS；最終 ZIP／Manifest 已驗證。

## 完整驗證與封包
- 58/58 非-tooling `tests/*.test.cjs` scripts 逐檔 exit 0。
- `node --test tests/tooling.test.cjs`：13/13 PASS。
- `node tools/check-architecture.cjs`：900 passed／0 failed。
- Source audit、full mapper verification（Catalog 55,660 筆）、5-run catalog benchmark：PASS。
- 137 個 JS／CJS 檔案 `node --check`：PASS。
- AMQ／EMQ source hashes 與前批一致。
- 最終封包：300 files（Manifest 299 entries + Manifest itself）；ZIP CRC PASS，缺少 0／額外 0／SHA-256 mismatch 0，未包含 `.pem`／`.key`。
- ZIP SHA-256 與大小於最終工作狀態紀錄／交付回報列出。
- 逐檔測試日誌：`/mnt/data/amq_batch136_validation_logs/`。

## 尚未完成／限制
- SQLite 歷史 room／command／SRS rows 未刪除；本批僅降低 hot cache 與 queue map 常駐記憶體。
- 真實瀏覽器／多節點 E2E 未驗收；不重試已知被阻擋的 Chromium 路徑。
- Candidate302／Candidate382 Stage 0 相容性未證明；正式基準與 source assets 未修改。

## 下一批
Batch137：SQLite integrity／foreign-key 與帳號資料生命週期盤點，優先建立可重現的資料完整性驗證，不擅自刪除使用者歷史資料。
