# Batch243 Handoff：Canvas Alpha／Pixel Budget／Tooling Deadlock

## 基準與安全
- 唯讀基準：Batch242 ZIP `/mnt/data/AMQ_Full_Rebuild_Batch242_Skin_Canvas_Integration_20261029.zip`，SHA-256 `614fd641e4177cb71bf1c5e5cf28387a2cbf46e96d47cc5a9b5383caa56cf3b2`。
- 工作副本：`/mnt/data/AMQ_Full_Rebuild_Batch243`。沒有 Git repository，未初始化 `.git`。Batch242 ZIP 未覆蓋。
- AMQ／EMQ hashes 保持 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3` 與 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 實作
- `src/skins/skin-edge-repeat.js`：安全整數與來源／輸出 pixel budget。
- `src/skins/skin-canvas-renderer.js`：輸出 Canvas 幾何預檢；repeat output 超限於建立 output canvas 前拒絕。
- `tests/skin-edge-repeat.test.cjs`、`tests/skin-canvas-renderer.test.cjs`：direct helper 與 renderer output budget regressions。
- `tests/batch243-skin-canvas.browser.py`：Chromium 15/15，覆蓋 alpha、quantization、多列 edge-repeat、budget 與 ImageBitmap lifecycle。
- `tests/tooling.test.cjs`：修正 concurrent architecture checker 的 stdout pipe deadlock；並行測試之前會因 88KB stdout 沒有被消耗而卡死，現在 drain stdout 並驗證輸出。
- 更新 `docs/SKIN_FRAMEWORK_CONTRACT.md` 與 `docs/AMQ_VISUAL_NEEDS_TRACEABILITY_BATCH240.md`。沒有未達語義條件的角色被硬接。

## 驗證證據
- Node：89/89 test files，261 cases，0 failures。logs `artifacts/batch243-regression/node-tests/`；摘要 `node-suite-summary.txt`／`.json`。
- Focused Skin：32/32。Canvas Chromium：15/15。Home/Catalog：19/19。Quiz/Results：19/19。Mapping Studio：30/30。App shell：150/150。
- Architecture：1,270 passed／0 failed。JS/CJS syntax：182/182。Python harness py_compile：7/7。Manifest：5,792 entries，0 missing／extra／mismatch；ZIP CRC PASS。
- Browser logs：`canvas-browser.log`、`home-catalog.log`、`quiz-results.log`、`mapping-studio.log`、`app-shell.log`。

## 阻塞／限制
- loopback 與非 loopback (`172.26.39.239`) HTTP origin 都回報 `ERR_BLOCKED_BY_ADMINISTRATOR`。`artifacts/batch243-regression/http-origin-blocker.txt` 已記錄；沒有執行真實 IndexedDB save/reload。政策未改變前不要重複同樣 probe。
- Canvas alpha quantization 以目前 Chromium 可觀察值測試；不是跨瀏覽器 byte-exact 保證。native osu!stable tint/blend、精確 edge-repeat、動畫及 skin.ini 版本語義仍未支援。
- Candidate302／Candidate382 Stage 0 基準檔不在包內；live catalog/artwork/audio 未驗收。

## 下一批 Batch244
1. 只有在瀏覽器／網路政策或 origin 可用性改變時才驗收真實 IndexedDB save/reload。
2. 增加 pixel geometry safe-integer／32-bit boundary 及 decode failure cleanup 測試。
3. 繼續 UI 與角色接線主線，所有 role 必須有真實語義 DOM/CSS consumer、state、geometry、fallback、reset。
4. 全程更新同一份主清單、狀態、交接、traceability、manifest 與 ZIP。
