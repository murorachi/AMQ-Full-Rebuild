# Batch 84 交接包：安全曲庫更新／匯入
日期：2026-10-27

## 本批成果

1. 新增 `src/data/database-update.js`：
   - `amq-learning-database-update` v1、payload schema v1、固定 AMQ／EMQ source schema。
   - canonical JSON SHA-256；不執行 JSON package 內容。
   - 完整 AMQ／EMQ source mapper 與 `validateRecords()` preflight；檢查重複 ID、懸空 work reference、record schema 與 source labels。
   - 預檢差異：每個 source 的作品／歌曲新增、修改、移除數量。
   - 預檢後套用會重新驗證 checksum，避免預檢後選檔內容變動。
   - IndexedDB 單一 active envelope 透過單筆 readwrite transaction 原子替換；提供讀取 active dataset 與清除 override。
2. `src/data/source-runtime.js` 已讀取 active override，重驗後讓正規化記錄走既有 Source Adapter／Repository／Validator／Catalog。未匯入時仍使用內建來源；清除 override 後下一次載入回到內建來源。損壞 active package fail closed。
3. 新增 `src/ui/database-update-panel.js`，接入匯出目前曲庫、選檔、預檢、差異預覽、確認套用與恢復內建曲庫。成功後要求 reload。
4. 新增 `tools/create-database-update.cjs`，只解析來源檔中的單一 JSON assignment，不執行來源 JavaScript，且不覆蓋既有輸出檔。
5. AMQ-990 增加 catalog-browser integration regression，涵蓋中文別名搜尋命中、關閉後恢復原索引、Provider 失敗不影響一般搜尋、延遲結果不覆蓋已關閉設定。

## 使用方式

從可信來源腳本產生更新包：

```sh
node tools/create-database-update.cjs <trusted-data.js> <trusted-emq-data.js> <output.json>
```

在 app 的「曲庫更新與匯入」面板選擇 JSON，執行完整預檢並檢視差異，確認後套用。套用成功後重新載入頁面。若 active override 無法使用，可用「恢復內建曲庫」移除 override，不修改內建資產。

## 測試證據

- `tests/database-update.test.cjs`：PASS，6 個測試場景。
- `tests/database-update-runtime.integration.test.cjs`：PASS，驗證 runtime 真的消費匯入的 AMQ／EMQ records，清除後回到 bundled source。
- `tests/database-update-panel.test.cjs`：PASS，預檢失敗不套用、差異預覽、checksum 鎖定、套用提示、恢復內建與匯出。
- `tests/catalog-browser.integration.test.cjs`：PASS，新增中文別名搜尋／設定切換回歸。
- `tests/*.test.cjs`：35/35 scripts exit 0；`tests/tooling.test.cjs` 9/9 PASS。
- `node tools/check-architecture.cjs`：584 passed／0 failed。
- Source audit PASS：AMQ 38,821 songs／9,516 works，EMQ 16,839 songs／6,645 works；duplicate／dangling／cross-source collisions 皆 0。
- Mapper verification PASS，Catalog 55,660；benchmark 5 iterations PASS（6 search cases、2 grouping cases）。
- JS/CJS syntax 81/81 PASS。
- 使用內建真實曲庫產生 13 MB update package 並執行完整 preflight PASS；暫存包已移除。

## 尚未驗收／限制

- 真實瀏覽器 IndexedDB transaction、quota failure、跨分頁及 reload 後 AMQ／EMQ／MIX 一致性未實測。Node／injected store 測試不是 E2E。
- 已知 Chromium 導覽 `ERR_BLOCKED_BY_ADMINISTRATOR`，不重試相同路徑。
- 沒有核實的官方更新 endpoint，因此這是安全離線匯入／更新包流程，不是自動線上更新器。
- Candidate302、Candidate382 Stage 0 與 `src/data/assets/` 未修改；工作副本沒有 `.git`，無 branch／commit 可報告。

## 下一批優先順序

1. 在可用瀏覽器實測更新包匯出、匯入預檢、確認套用、reload、IndexedDB quota 與跨分頁行為；不要重試已知被封鎖路徑。
2. 若無瀏覽器，盤點既有歷史／統計資料來源，完成自由播放歷史與統計儀表板的核心資料 API，避免重複 store／第二份狀態。
3. 再做播放器 Dock、外部服務及多人模式；UI／CSS 大重構最後做。
