# Batch 74 交接：SRS eligibility-first 動態 selector 與關閉保護回歸

## 工作環境與基準
- 本工作副本由 `AMQ_Full_Rebuild_Batch73_Handoff_20261027.zip` 解壓建立，沒有 `.git` metadata；已檢查 `git status`，結果為 `fatal: not a git repository`。沒有初始化 Git、commit、push 或覆蓋正式基準。
- 正式舊版維護基準 Candidate302 與 Candidate382 Stage 0 均未提供於本包；Candidate381/V82.x 僅為既有唯讀靜態參考。未修改／重建正式基準。
- `src/data/assets/data.js` SHA-256 保持 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`。
- `src/data/assets/emq-data.js` SHA-256 保持 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 本批實作
1. `src/engine/quiz-pool.js`
   - 新增純函式 `pickSrsWeighted()` 與 `srsWeight()`。
   - 依既有卡片 `state`、FSRS `dueAt`、`lastRating`、逾期天數計算相對權重：新題保護、未到期卡降權、grade 1/2 及嚴重逾期提高優先度；停用卡不進 selector。
   - MIX 先按既有 2:1 AMQ／EMQ 機率選來源，再於該來源內按 SRS 權重抽樣，沒有建立 MIX schedule。
   - 未更改 FSRS scheduler／dueAt，也沒有固定每 N 題比例。
2. `src/engine/quiz-session.js`
   - 新增可選 `selectNext` 注入點；呼叫前已先套用 `isEligible` 並排除本回合 `seen` identity。
   - selector 回傳不屬於目前可用池的記錄、回傳 null 或丟出例外時，退回既有 no-repeat 選題，不會繞過 eligibility 或卡住。
3. `src/ui/quiz-panel.js`
   - 一般 AMQ／EMQ／MIX 練習在全域 SRS 開啟時使用 selector，透過來源對應的既有 SRS store 讀卡片；關閉時退回既有非 SRS 選題。
   - 若使用者或另一分頁在 SRS 複習進行中關閉全域開關，立即停止 SRS 專用回合並重建一般練習 session；未評級卡片與 schedule 保留。
4. 測試
   - `tests/quiz-pool.test.cjs`：新增動態權重、新題保護、MIX 2:1 分支、停用卡／無效 RNG 測試。
   - `tests/quiz-session.test.cjs`：驗證 selector 只收到 eligibility 後的 unseen pool，不能選回被排除的歌曲。
   - `tests/quiz-panel.test.cjs`：驗證全域 SRS 關閉時 AMQ／EMQ schedule snapshot 不變，普通答題歷史仍持續寫入。

## 實際驗證
- `tests/*.test.cjs`：28/28 scripts exit 0。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：495 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839；重複 ID、懸空關聯與跨來源 ID 衝突為 0。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；Catalog 55,660 筆。
- `src/`、`tests/`、`tools/` 全部 JS/CJS `node --check`：PASS。
- `node tools/benchmark-catalog.cjs ... 5`：PASS，Catalog build 1175.407 ms；本機 Node 觀察值，非效能保證。
- Node／fake DOM／靜態檢查不是瀏覽器 E2E，也不證明外部音訊可播放。

## 未完成／風險
- AMQ-913 的大規模分布模擬（新題大量、已熟題大量、due pool 稀少、來源不平衡等）仍待補；本批只驗證核心權重與 MIX 分支。
- AMQ／EMQ／MIX 在 SRS 關閉時的一般出題、熟悉度與歷史完整矩陣尚未全部逐模式測試；本批已驗證 AMQ 關閉保護及歷史持續寫入。
- 全量備份／還原功能目前不存在於本架構，尚未實作。需先設計版本化匯出格式、完整性驗證、還原前驗證與失敗原子性，再批次實作，不能只把 SRS 欄位塞進不存在的 API。
- 真實瀏覽器／音訊與 Windows 乾淨啟動仍按既有紀錄追蹤；不重試已知被管理政策阻擋的同一 Chromium CLI 方法。
- 無 `.git` metadata，無法提供真正 branch／commit／diff；交付 ZIP 是本次變更載體。

## 下一批最高優先級
1. 完成 SRS selector 多分布模擬與各模式 off/on/reload 的整合測試。
2. 檢查 storage event／toggle-off／selector 互動回歸，補 SRS off 時不改寫 schedule 的 EMQ／MIX 覆蓋。
3. 設計並實作版本化全量備份／還原 API，涵蓋 app settings、AMQ／EMQ SRS、history、familiarity、blacklist、personal library；驗證舊備份相容與損壞匯入不覆蓋現有資料。
4. 最後更新 manifest、完整 ZIP 與測試摘要；UI／CSS 大重構仍延後。
