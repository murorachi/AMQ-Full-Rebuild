# 曲庫遠端更新發布契約（Batch109）

## 目的與範圍

Batch109 建立 AMQ＋EMQ 完整資料包的發布工具與前端遠端下載流程。由於目前尚未指定／建立固定的公開託管位置，本批不把任何上游網站冒充為 AMQ 更新 API，也不在專案中假造發布網址。自架者可將產物放在自己信任的 HTTPS 靜態目錄，並在 `src/data/database-update-config.js` 設定預設 `window.AMQ_DATABASE_UPDATE_MANIFEST_URL`；也可在 UI 中手動貼上 manifest 網址。

## 產生發布包

```sh
node tools/create-database-update-release.cjs <trusted-data.js> <trusted-emq-data.js> <output-directory> <release-version> <ed25519-private-key.pem>
```

例如版本 `1.2.3` 會建立：
- `amq-database-update-1.2.3.json`：完整 AMQ＋EMQ 更新包。
- `latest.json`：版本清單，記錄版本、格式相容範圍、檔案大小、完整檔案 SHA-256、payload checksum、來源作品／歌曲數及 Ed25519 簽章。
- 發布工具要求明確指定 Ed25519 私鑰檔；私鑰在生成 bundle 前先驗證，錯誤／缺失金鑰不會留下半成品。簽章覆蓋 canonical JSON 形式的整份 manifest（排除 signature 欄位），簽章欄位含演算法、由公鑰 DER SHA-256 產生的 key ID 及 Base64 簽章。

工具只呼叫既有的非執行式 JSON 解析打包工具，不會執行上游 JavaScript。若版本化包或 `latest.json` 已存在，會拒絕覆蓋；發布後請將兩檔放在同一個目錄，manifest 的 bundle URL 必須是相對路徑。

## 前端更新流程

1. 從設定或 UI 輸入可信任的 `latest.json` HTTPS URL（`localhost` HTTP 僅供開發）。
2. 以 `cache: no-store`、不帶 cookie、拒絕 redirect 的方式取得 manifest。
3. 驗證 manifest 格式／版本相容性、bundle URL 為同來源相對路徑、檔案大小上限與 SHA-256。
4. 驗證包內 payload checksum、來源 schema、完整 mapping、作品關聯及所有記錄。
5. 顯示 AMQ／EMQ 歌曲與作品的新增／修改／移除差異；使用者仍須明確確認套用。
6. 套用沿用既有單一 IndexedDB readwrite transaction；成功後重新載入。任何下載、checksum、schema 或提交失敗均不應改寫內建來源檔。

## 安全限制

- SHA-256 可偵測檔案傳輸損壞及 manifest／bundle 不一致，但**不能證明發布者身分**。若 manifest 與 bundle 都來自同一個遭入侵的主機，攻擊者可能同時替換兩者。請只使用信任的 HTTPS 發布位置；獨立的 Ed25519 簽章與內嵌公鑰仍是後續強化項目。
- 不允許 HTTP 公網、跨來源 bundle URL、URL redirect、嵌入帳密或不相容格式。
- 自動檢查與下載不是自動套用。仍需預檢、差異預覽及使用者確認。
- 目前沒有專案官方固定的公開 manifest URL，因此 UI 能執行遠端流程，但公開版的免設定更新入口仍待發布端點決策與部署。
- 真實瀏覽器、跨域政策、靜態主機設定及 IndexedDB 實機原子交易尚未驗收；Node 測試不等於瀏覽器 E2E。


## 發布簽章金鑰保管與自架設定（Batch110）

- 官方驗證公鑰位於 `src/data/database-update-config.js`，可公開；對應私鑰不得放進公開原始碼、ZIP、網站靜態目錄或版本控制。
- 官方私鑰應由維護者離線保管並限制檔案權限；遺失私鑰會需要透過已信任的程式更新輪替公鑰。私鑰洩漏時應立即停止發布，並以可信任的應用程式更新方式輪替公鑰與 key ID。
- 發布命令：`node tools/create-database-update-release.cjs <data.js> <emq-data.js> <output-directory> <release-version> <ed25519-private-key.pem>`。只上傳產物中的 `latest.json` 與版本化 bundle，不上傳私鑰。
- 自架者應自行產生 Ed25519 key pair，將 public key 的 SPKI DER Base64 與 key ID 設定到 `database-update-config.js`，再使用自己的 private key 產生更新包。key ID 計算方式為 public SPKI DER 的 SHA-256 十六進位前 16 字元。
- 這不會自動建立公開 hosting；可信任 HTTPS 發布端點仍需由架設者設定。
