# 中文作品標題 Provider 契約（Batch 82）

## 資料來源
- AniList Chinese：`https://cdn.jsdelivr.net/gh/soruly/anilist-chinese@763fcd7e368f36bab437b18806b548ca42176892/anilist-chinese.json`
- Bangumi-data：`https://cdn.jsdelivr.net/gh/bangumi-data/bangumi-data@bae940f6116ae4b93c73a711827056faaf23957a/dist/data.json`
- OpenCC：`https://cdn.jsdelivr.net/npm/opencc-js@1.4.2/dist/umd/full.js`

以上來源 URL 與版本從 Candidate381/V82.x 靜態參考中核實。此契約不宣稱遠端服務現在可連線，也不代表與 Candidate302 或 Candidate382 Stage 0 相容。

## 身份契約
- 更正（Batch158）：AMQ work ID 是內部 ID，AMQ work row 的 `row[6]` 才是 ANNID；不得把 AMQ work ID 當成 MAL ID。
- EMQ work 只使用來源資料明確提供的 `vndbId`。
- Bangumi `sites` 的 ID 對應作為 AniList ID crosswalk；不得使用標題相似度推測身份。
- 找不到明確 ID 時回傳空標題／別名，沿用原有標題。

## API 與狀態
`window.AMQData.chineseTitleProvider.createChineseTitleProvider(dependencies)` 提供：
- `load({ signal, force })`：載入或使用 cache，回傳狀態與對應數量。
- `getTitle(record)`：回傳對應的首選中文作品名，未找到時為空字串。
- `getAliases(record)`：回傳去重中文標題別名。
- `getStatus()`：回傳 ready/status/error/loadedAt 等診斷資訊。
- `dispose()`：停止繼續使用此 Provider instance。

## 快取／失敗
- IndexedDB 資料 cache TTL 為 7 天。IndexedDB 失敗時 cache 是可選功能，不可使成功的遠端資料失敗。
- 逾期 cache 在遠端資料源不可用時作 stale fallback。
- Bangumi 交叉映射是必要來源；AniList JSON 是可選補充來源。若只有 Bangumi 成功，仍可提供 Bangumi 已有的中文標題。
- 請求 timeout 與 AbortSignal 取消會阻止未完成資料發布。OpenCC 不可用時保留來源標題，不阻擋猜歌。

## UI 接線
- `chineseTitlesEnabled` 儲存於既有 `amqLearningAppSettingsV1` schemaVersion 1，預設 false。
- 使用者啟用後才載入外部資料與 OpenCC；關閉或卸載時取消仍在進行的載入。
- 目前 Provider 用於作品答案建議與答案揭曉；曲庫全文搜尋索引尚未整合。

## 驗收界線
Node tests 驗證 parser、ID 對應、快取、取消、錯誤回退及 UI 設定持久化；尚未完成真實瀏覽器網路／CORS／CDN 驗收。不得將 Node 測試當成外部服務 E2E。
