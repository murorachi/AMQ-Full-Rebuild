# Batch175 交接：History debounce stale callback 與 AudioService error ordering

## 工作副本／基準
- 工作副本：`/mnt/data/amq_batch153_work`。無 `.git` metadata，未初始化。Node v22.16.0。
- Candidate302 是正式維護基準，Candidate382 Stage 0 是 CSS 比較基準；原始檔不在副本，未 hash 比對或覆蓋。AMQ／EMQ 曲庫資產未修改。

## 本批修改
1. `src/persistence/quiz-history-store.js`：加入 `summaryTimerGeneration` 與 `cancelSummaryTimer()`。clearTimeout 無法撤回已排入事件佇列的 callback，故 flush／persistSummary／dispose 會遞增 generation；callback 執行時若 generation 過期或 store 已 disposed，就直接返回。
2. `tests/quiz-history-store.test.cjs`：加入兩個 fake-timer regression。修正前 flush 後與 dispose 後的 stale callback 都會造成 summary 額外寫入，write count 從 2 變 3；修正後無額外寫入。
3. `tests/audio-service.test.cjs`：加入 playing 後收到 media error，fallback 至 backup，再手動觸發舊 candidate handler 的事件順序測試。既有 request/candidate index guard 和 listener detach 已正確保護，因此不改 AudioService production code。

## 驗證
- AudioService 22/22 scenarios PASS。
- Quiz History Store 16/16 PASS。
- QuizSession 25/25 PASS。
- 全量 71 個 Node test files 分 9 組，9/9 組 exit 0。總控執行一度觸及外層時間限制，最後一組另行逐檔完成 7/7 PASS。
- Architecture Checker 1,051 PASS／0 FAIL。
- OSK import panel harness 12/12 assertions，exit 0。
- `src`／`tests`／`tools`／`server` 160 個 JS/CJS `node --check` PASS。
- 詳細日誌在 `artifacts/batch175-regression/`；`history-debounce-before-fix.log` 保留修正前失敗證據。

## 未驗收
- 真實瀏覽器音訊／可聽性、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。
- Candidate302／Candidate382 Stage 0 原始檔缺席，無法比對原始檔 hash。

## Batch176 下一步
1. 檢查 detail persistence retry、storage event refresh 與 summary timer generation 交錯是否造成跨分頁資料覆蓋／摘要回退。
2. 繼續盤點可重現的 P0/P1 核心缺口，沒有失敗證據就不改穩定程式碼。
3. 保留 detail-first summary consistency、generation guard、AudioService 單一 owner、`playAttemptId`／`playbackEpoch` 與四級熟悉度規則。
