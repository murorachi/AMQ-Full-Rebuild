# Batch238 Handoff：Home + Catalog Visual Framework

## 基準
- 來源：`AMQ_Full_Rebuild_Batch237_Visual_Needs_First_20261029.zip`
- 來源 SHA-256：`ac268debe1d98689a98664e9c6d33448213a9bd31708d869d09c23bd95d3f18f`
- 工作副本：由已驗證 Batch237 解壓後的 `/mnt/data/amq_batch237_work` 延續。原始 ZIP 未覆蓋；沒有初始化 `.git`。

## 實作
- `src/styles/ui-shell.css` 新增 Batch238 product-level visual pass。首頁保留原有圓形導航和預設收合行為，提升 hero、軌道、中心動作、五個入口的層級；手機調整個人檔案入口避免與上方入口重疊。
- Catalog 保留既有 DOM/state/data owner，改善三欄／兩欄／手機單欄、篩選與列表層級、選取詳情面板。作品封面尺寸由 34×45 增至桌面 48×64、手機 42×56。
- 不使用 mock song data；瀏覽器 harness 只在測試期間暫時插入一列 DOM fixture，以量測 CSS，不改動產品狀態或資料源。

## 驗證
- Focused Node 16/16 PASS：CSS contract、Catalog unit/integration、visual needs、geometry。
- Chromium 19/19 PASS：首頁／Catalog，1440px desktop、390px mobile，0 page errors，0 page-level overflow，首頁五入口不重疊。
- Architecture Checker 1,214 PASS / 0 FAIL。
- Evidence: `artifacts/batch238-regression/home-desktop.png`, `catalog-desktop.png`, `catalog-mobile.png`, `home-mobile-expanded.png`。

## 未驗證／阻塞
- 全量 Node suite與 `tests/app-shell.browser.test.py` 本批未執行。
- Inline/opaque-origin Chromium 仍回報 IndexedDB `DATA_SOURCE_READ_FAILED`；因此 live catalog/artwork/audio 不算驗收通過。
- OSK native tint/blend、`@2x`、state-pair、edge-repeat、override editor 尚未完成。
- Quiz/Results 正式 UI、真實 HTTP-origin、使用者裝置及 Candidate302/Candidate382 Stage 0 仍未驗收。

## 下一批
1. 完成 Quiz Arena 與 Results 的正式視覺框架和空狀態。
2. 加桌面／手機 Chromium 回歸，保護主要操作、焦點、結果 CTA 和無溢位。
3. 為已完成 Home/Catalog 的視覺需求建立可驗證的 selector/CSS consumer traceability。
4. 以獨立測試逐項實作 `@2x` 邏輯尺寸、fit/crop、state pair 等 renderer primitive。
5. 分批執行 Node suite，更新主清單與完整 ZIP。
