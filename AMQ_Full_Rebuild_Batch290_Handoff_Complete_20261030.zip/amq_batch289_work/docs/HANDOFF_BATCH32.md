# Batch 32 交接：AudioService 錯誤契約與 MIX 訊息一致性

## 本批實作
- `src/audio/audio-service.js` 為播放錯誤新增 `errorInfo`，使用共享 `AMQCore.errors.createError()`（category `audio`），同時保留舊有 `error` 字串以避免破壞既有呼叫端。
- 標準化錯誤涵蓋：`AUDIO_ALL_CANDIDATES_FAILED`、`AUDIO_AUTOPLAY_BLOCKED`、`AUDIO_CANDIDATES_INVALID`、`AUDIO_NO_CANDIDATES`、`AUDIO_TIMEOUT_INVALID`、`AUDIO_SERVICE_DISPOSED`。所有候選失敗包含失敗摘要與 retryable 標記。共享錯誤模組不存在時仍會回傳相同基本結構的 fallback object。
- `tests/audio-service.test.cjs` 載入共享錯誤模組並驗證 code/category/retryable 與 service state 的錯誤資訊。這是 mock media 測試，不代表真實音訊播放通過。
- `src/ui/quiz-panel.js`、`src/index.html` 修正 Batch 29 MIX 接線後遺留的「尚未配置／未核實」提示，改為說明 2:1 source weighting 與單一來源 SRS 限制。
- `docs/PRODUCT_CORE_CONTRACT.md` 修正過期 MIX 描述；`docs/MASTER_CHECKLIST.md` 將 Batch 31 已覆蓋的 AMQ-055、已有 mock media 覆蓋且本批補強的 AMQ-067 更新為完成，新增 AMQ-404..409。

## 驗證結果
- `tests/*.test.cjs` 全部 exit code 0；`node --test tests/tooling.test.cjs` 8/8。
- `node tools/check-architecture.cjs`：400 passed、0 failed。
- 真實來源稽核與 mapper verifier PASS：AMQ 38,821/38,821，EMQ 16,839/16,839，Catalog 55,660；這不是 Candidate302 相容性或音訊可播放性證明。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5` PASS。
- `src/`、`tests/`、`tools/` 全部 `.js`／`.cjs` `node --check` PASS。
- 真實瀏覽器 E2E 仍 BLOCKED；不重試相同 Chromium 導覽方式。

## 下一批建議
1. 核對 AMQ-030 資料正規化、AMQ-032 重複歌曲辨識與 AMQ-033 ID 穩定性：先檢查現有 mapper、query index 與 source audit 的契約，避免把搜尋索引正規化誤當成資料本體正規化。
2. 以來源 + ID 型別 + ID 值作為目前 identity 契約，評估是否需要明確化為獨立 identity helper，並以跨來源同 ID 測試保護。
3. 保持來源資料唯讀；不以猜測的標題相似度自動合併歌曲。
4. 真實瀏覽器／音訊 E2E 仍記錄為阻塞，不用 Node 測試替代。
