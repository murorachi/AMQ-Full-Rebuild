# Batch 97 交接包

日期：2026-10-27

## 本批成果
- `src/multiplayer/room-command-service.js`：新增單調 server clock guard。任何低於此 service 最後觀測 timestamp 的時鐘值都拒絕為 `ROOM_SERVER_TIME_REGRESSION`；相同時間戳允許。
- `tests/multiplayer-room-command-service.test.cjs`：新增 clock rollback regression；回退不改 revision，恢復至最後觀測值後可繼續。
- 新增 assessment failure atomicity regression：assessment throw 時 tentative answer transition 不提交、不增加 revision、不寫入答案、不進入冪等成功快取；相同命令在 assessor 恢復後可成功重試，revision 僅增加一次。

## 驗證證據
- 44 個非-tooling `tests/*.test.cjs` 逐檔執行：44/44 exit 0。
- `node --test tests/tooling.test.cjs`：9/9 PASS。
- `node tools/check-architecture.cjs`：719 passed／0 failed。
- `src/`、`tests/`、`tools/` JS/CJS syntax：100/100 PASS。
- Source audit PASS：AMQ 38,821 songs／9,516 works；EMQ 16,839 songs／6,645 works；duplicate IDs、dangling references、cross-source collisions 均 0。
- Source mapper PASS：Catalog 55,660 records。
- 5-iteration catalog benchmark PASS；本次 Catalog build 約 1,205.352 ms（本機 Node 觀察，不是瀏覽器效能保證）。
- 來源資產 hash unchanged：`data.js` `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；`emq-data.js` `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 未完成／阻塞
1. `expireRound()` 的多玩家 timeout assessments 若中途失敗，state transition 不會 commit，但需明確定義部分 assessment 計算的重試語義；目前 assessor 為純邏輯契約，不能將其當作未來外部副作用交易保證。
2. `round.start` selector／round ID factory 的副作用順序仍可再檢查。
3. durable idempotency、per-room concurrency、跨節點 state、真正 auth／transport、reconnect、多 client E2E 未實作。
4. 多人 SRS persistence 需產品決策，不得寫入沒有 user identity 的共享 browser localStorage key。
5. 真實瀏覽器／音訊／storage／外部 API／多人互通未驗收；已知 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試相同路徑。

## 基準／版本管理
- 從 Batch96 ZIP 解壓的獨立工作副本繼續，未覆蓋來源 ZIP。
- 工作包沒有 `.git`；未初始化 Git、未假造 branch／commit。
- Candidate302、Candidate382 Stage 0 與來源資料資產均未修改。
- 下一批優先做 `expireRound()` timeout assessment failure semantics 與 round.start side-effect ordering，再跑完整回歸。
