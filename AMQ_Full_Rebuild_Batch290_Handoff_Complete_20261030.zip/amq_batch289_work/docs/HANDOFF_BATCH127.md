# AMQ 新版重建交接：Batch127（Remote SRS durable queue）

日期：2026-10-28。沿用 Batch126 工作副本；無 `.git` metadata，未初始化／commit／push。

## 修改
- `src/persistence/remote-srs-bridge.js`：新增內建 IndexedDB adapter `amq-remote-srs-pending-v1`，key 依 userId/source 分離；持久化 base revision／base schedule／in-flight payload／latest payload。沒有 IndexedDB 時 `durable:false`，保留舊 session-only 行為並向 UI 暴露狀態。
- `src/ui/account-panel.js`：bridge 使用 authenticated user ID；UI 顯示 memory-only warning；明確重新載入會丟棄 pending queue，若刪除持久化 queue 失敗則取消 reload、保留狀態。
- 安全恢復：server revision/base schedule 一致時可重送；server revision 已增且 schedule 等於 in-flight/latest payload 時可認定已提交；不同 payload 仍 conflict/fail-closed。
- 多次 full-schedule writes 合併最新狀態；若較新狀態在 PUT 進行中抵達，先確認前一 revision，再以新 revision 提交後續 payload。
- `tests/remote-srs-bridge.test.cjs` 新增 fake IndexedDB adapter／bridge recreation、順序、response-lost、user isolation、conflict、discard 與 storage delete failure tests。
- `tests/account-panel.integration.test.cjs` 覆蓋 retry 與明確 reload/discard。

## 驗證
- `node --test tests/remote-srs-bridge.test.cjs tests/account-panel.integration.test.cjs`：13/13 subtests PASS。
- 57/57 非-tooling test scripts 逐檔通過，分四組執行。
- Tooling 13/13 PASS；architecture 893 passed／0 failed。
- Source audit／full mapper／5-run benchmark PASS；Catalog 55,660 records，build 約 1,063.672 ms（僅 Node 本機觀測值）。
- Source SHA-256 unchanged：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 限制
- Fake IndexedDB／Node bridge recreation 不等於真實瀏覽器 IndexedDB transaction、quota、reload 或 tab-close 驗收；已知 Chromium 路徑 `ERR_BLOCKED_BY_ADMINISTRATOR` 不重試。
- Conflict 不自動 merge；使用者需明確重試或重新載入，reload 會丟棄 pending。

## 下一步
Batch128：盤點並完成可獨立驗證的資料／個人收藏功能，優先處理已確認的 CRUD／watch status／跨分頁缺口。
