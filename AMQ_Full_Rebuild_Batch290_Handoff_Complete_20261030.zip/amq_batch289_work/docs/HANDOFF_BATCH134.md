# AMQ 新版重建交接：Batch134（多人 HTTP 安全邊界）

日期：2026-10-28。工作副本：`/mnt/data/amq_batch129_work`。無 `.git` metadata；未初始化 Git。Candidate302、Candidate382 Stage 0 與 AMQ／EMQ source assets 唯讀。

## 修改
- `tests/server-auth-srs.integration.test.cjs`：新增 multiplayer HTTP boundary test，覆蓋未登入 lobby／snapshot、跨 origin room create、malformed JSON、oversized body 與有效登入後建立房間。request helper 支援 `rawBody`。
- Production audit 確認既有 `readBody` 同時檢查 Content-Length／streaming bytes；mutation routes 共用 origin check；room routes 要求 authenticated user；command service 已有 actor derivation、allowlist、requestId idempotency、revision／deadline checks 與 per-player 60 commands／10s limiter。未重複造第二套 validator／limiter。

## 驗證
- `node --test tests/server-auth-srs.integration.test.cjs`：7/7 PASS。
- 全量 57 個非-tooling test scripts 逐檔 exit 0；tooling 13/13、architecture 893/0、source audit／mapper／5-run benchmark PASS。
- AMQ／EMQ readonly source SHA-256 unchanged。

## 風險／下一步
- Room creation 本身沒有獨立的 per-user/IP rate limit／active-room cap；login／registration attempt maps 的過期 key cleanup 也尚未實作。本批不臆定產品上限。
- Batch135：加入 bounded cleanup 與可設定的 room creation limits；必須確認新限制不影響既有房間 snapshot／answer／timeout／request replay。
