# AMQ 新版重建交接：Batch121（安全多人題目投影）

日期：2026-10-28。基礎為 Batch120 工作副本；沒有 `.git` metadata，未初始化 Git。

## 本批實作
- `server/multiplayer-runtime.cjs` 新增 `projectPlayableQuestion(questionId, roundId)`：以 server-owned question map 查詢可信題目，只回傳 roundId、opaque questionId、HTTP(S) audio candidate URL 與 source/kind；不回傳作品標題、歌名、歌手、別名或 trusted record。
- `server/multiplayer-host.cjs` 將安全投影附加至 active-round snapshot；建立房間、一般命令、idempotent replay 與 polling snapshot 共用投影邏輯。非 active round、無效題目或沒有有效候選時不產生投影。
- `tests/multiplayer-host.integration.test.cjs` 增加真實 HTTP 房間流程：開局後檢查 projection 與 server questionId/roundId 一致、音源 URL 為 HTTP(S)、投影不包含標題／歌手／答案／完整 record。

## 驗證
- `node --check server/multiplayer-runtime.cjs`：PASS。
- `node --check server/multiplayer-host.cjs`：PASS。
- `node --check tests/multiplayer-host.integration.test.cjs`：PASS。
- `node --test tests/multiplayer-host.integration.test.cjs`：1/1 PASS。

## 尚未完成／阻塞
- 本批只完成安全題目投影，**尚未接入多人 AudioService 播放按鈕或與 server deadline 對齊的 QuizClock UI**，不得宣稱多人模式已可完整遊玩。
- 下一步：使用現有 `AMQAudio.audioService.createAudioService` 接線，確保 coordinator lease 被撤銷、離房、回合結束、dispose 時停止／取消播放；再將顯示倒數錨定到 server `deadlineAt`，不讓 client 倒數參與判分。
- 需要回歸 audio candidate fallback、lease owner handoff、leave、timeout、reconnect，以及完整測試套件。
- 真實瀏覽器 E2E 仍因既有環境政策阻擋而未執行；不可重試同一路徑或聲稱瀏覽器驗收通過。
