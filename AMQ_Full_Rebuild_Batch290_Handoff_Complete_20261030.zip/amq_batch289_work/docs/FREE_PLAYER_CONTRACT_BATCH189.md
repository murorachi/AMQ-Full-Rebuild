# 自由播放 Dock／佇列契約（Batch189）

## AudioService

- AudioService 是媒體唯一 owner。Dock 不直接建立 HTMLAudioElement、不直接控制媒體元素。
- `setVolume(number)` 接受 0–1；`setMuted(boolean)` 接受布林值；兩者更新 active media，並套用到後續 fallback candidates。
- `seek(seconds)` 只接受有限非負秒數且要求 active media duration 有效，位置 clamp 到 duration；失敗回傳 false。
- 媒體原生 `ended` 事件會先發布 `ended` 狀態，讓訂閱者能讀取最終播放指標，再終止 request 並釋放媒體；舊 candidate callback 仍必須通過 request identity guard。

## 佇列與播放模式

- Queue 以 source-aware typed song identity 去重；同一曲目不重複入列。直接播放曲目若尚未入列，會自動加入佇列。
- 順序模式在末項自然結束後停止自動推進；循環模式回到首項；隨機模式在佇列有多項時避免立即重播目前項。自然 ended event 會依模式自動推進。
- 上一首依實際 queue play history 回退；移除目前播放項會停止播放、清除 current record 並重置歷史索引；移除其他項會調整 current index；清空佇列會停止播放並清空 queue history。
- 搜尋結果清單與佇列分開；搜尋只影響可加入的曲目，不會刪除已入列項目。

## 播放歷史

- 保留實際播放累積至少 5 秒才記錄的規則；暫停時間不計入 playing elapsed。
- 同一 AudioService sequence 最多記錄一次。歷史 ID 包含 Dock lifetime ID、sequence 及本次 entry counter，避免 App remount 後 sequence 重置造成舊記錄被誤判為 duplicate。
- 歷史寫入失敗不假裝成功；達到門檻後若 storage 暫時失敗，後續 tick 仍可重試。

## Dock UI

- 提供音量、靜音、進度／seek、收合、搜尋、結果清單、播放控制、佇列與播放模式。
- Dock 使用 sticky bottom panel 與最大高度／內部捲動，真實 viewport、背景播放及鍵盤操作仍需瀏覽器驗收。
