# Batch202 交接：OSK 契約誠實性修正

日期：2026-10-28

## 本批修改
- Mapping Studio 角色卡不再將「規格存在 stableAssets」誤報成「本次 OSK 有對應素材」。只有實際找到契約檔名候選時，才顯示命中數量。
- 沒找到素材時顯示「此 Skin 缺少對應素材」及 fallback 說明；其他圖片仍可人工覆寫，但明確標示非自動建議。
- 更新 `tests/osk-import-panel.browser.test.py`，覆蓋缺少 stable 素材時的角色卡狀態。

## 測試證據
- `python tests/osk-import-panel.browser.test.py`：12/12 assertions PASS。
- `node --check src/ui/skin-import-panel.js`：PASS。
- `python -m py_compile tests/osk-import-panel.browser.test.py`：PASS。

## 邊界
這是 Mapping Studio 的真實性修正，不是整套 UI 結案。OSK 套件、stable 元件語意與 AMQ runtime 尚需逐頁整合；真實 `.osk`、HTTP-origin IndexedDB、曲庫與音訊仍未驗收。無 `.git`，未初始化；沒有修改 AMQ／EMQ 曲庫資產。

## 下一批最高優先級
1. 對照 stable skin 元件清單，逐頁確認首頁、選歌、猜歌、學習中心、設定的結構與素材落點，不以「深色風格」冒充 stable 相容。
2. 讓自動建議依檔名／資產類型／manifest 規則產生；對歧義素材保留人工覆寫但不把全部圖片預先塞進每個角色下拉。
3. 完成 Catalog 鍵盤選取與篩選後選取清除的互動回歸。
4. 完成 Mapping Studio apply/reset/import/export/reload fixture 回歸，分開標記真實 `.osk` 阻塞。
5. 更新主清單、工作狀態、開工文件、MANIFEST 與 ZIP；不可宣稱整套 UI 已完成。
