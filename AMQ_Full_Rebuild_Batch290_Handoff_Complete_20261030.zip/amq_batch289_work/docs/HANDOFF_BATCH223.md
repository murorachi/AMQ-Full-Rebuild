# Batch223 交接：Catalog 錯誤細節、重試狀態與鍵盤焦點

日期：2026-10-29
工作副本：`/mnt/data/amq_batch223_work/project`
來源交付：`AMQ_Full_Rebuild_Batch222_CatalogStateMatrix_Recovery_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch223_Catalog_ErrorRetry_UI_20261029.zip`

## 開工檢查與基準

- 已讀 `AGENTS.md`、`AI_START_HERE.md`、`README_FIRST.md`、`docs/WORK_STATUS.md`、`docs/MASTER_CHECKLIST.md`、Batch222 handoff／next prompt、架構、Wiki traceability、OSK role audit 與 leaderboard trust contract。
- 工作目錄沒有 `.git`；沒有初始化。Candidate302 正式維護基準與 Candidate382 Stage 0 CSS 比較基準原始檔缺席，不宣稱相容、不覆蓋舊基準。
- AMQ／EMQ 靜態資料資產唯讀，SHA-256 維持原值。
- 已檢查 `repository.js`／`runtime-bootstrap.js`：repository 已持有單一 AbortController／active load owner，新的 load 會取消舊請求；mode change 會 invalidate 舊 Catalog，UI 另以 load sequence 防止 stale render。故本批沒有新增重複的 request owner。

## 本批實作

- `src/ui/catalog-browser.js`
  - 新增可讀的 Catalog error formatter。
  - `DATA_PARTIAL` 顯示輸入／可用／拒絕筆數；錯誤有 `details.reason` 時顯示具體原因；有 cause message 時顯示來源原因；可重試錯誤明示可重試。
  - `#catalog-error` 以 `hidden` 與 `data-error-code` 表達目前錯誤，不把錯誤塞進 HTML，全部使用 `textContent`。
  - Catalog root 使用 `aria-busy`；重新載入按鈕依狀態顯示「載入中…／重試載入／重新載入」，提供 aria-label 與 error description。
  - 若鍵盤使用者由重新載入按鈕啟動操作，完成後恢復焦點到同一按鈕，避免按鈕在 loading 被 disabled 時丟失焦點。
- `src/styles/ui-shell.css`
  - 新增錯誤 banner、partial 警告、retry button touch height 與 520px 以下標題／動作區重排。
  - 錯誤內容可換行，避免長 error detail 撐破手機畫面。
- `tests/catalog-mode-switch.integration.test.cjs`
  - 驗證 partial 計數細節、failed state、retry failure 保留新原因、retry success 清錯、aria-busy lifecycle、retry label、keyboard focus restore。
- `tests/catalog-filter-layout.contract.test.cjs`
  - 新增錯誤／重試可存取性與響應式 CSS contract。
- `tests/app-shell.browser.test.py`
  - 產出改至 `artifacts/batch223-regression/`，加入錯誤 banner／重試控制的桌面與 390px 手機視覺檢查。

## 驗證結果

- Node test files：78/78 PASS，逐檔日誌與 `summary.tsv` 位於 `artifacts/batch223-regression/node-tests/`。
- Chromium formal shell：96/96 PASS，無 uncaught browser exceptions；錯誤細節在 390px viewport 無頁面水平溢位。
- Architecture Checker：1,144 PASS／0 FAIL。
- 164 個 `src/`、`tests/`、`tools/` JS/CJS `node --check`：PASS。
- 3 個 Python browser test `py_compile`：PASS。
- AMQ／EMQ 靜態資料 SHA-256 未變，見 `artifacts/batch223-regression/asset-hashes.txt`。
- ZIP CRC、manifest hash、缺漏／額外檔案及 ZIP SHA-256 在交付前另行驗證。

## 尚未驗收／阻塞

- HTTP-origin IndexedDB persistence/reload：Chromium loopback `ERR_BLOCKED_BY_ADMINISTRATOR` 條件未變，本批不重試；真實 save/reload assertions 未執行。
- 真實 `.osk`、live 曲庫／封面 API／音訊、Candidate302／Candidate382 Stage 0 相容性、完整實機視覺與互動驗收仍未完成。
- 全球排行榜仍無可信 backend owner，不產生虛構 PP／排名／PB。
- UI 主線仍未結案；本批是 Catalog 錯誤／重試 UI 的局部收尾，不代表整體 UI 完工。

## 下一批

依 `docs/NEXT_SESSION_PROMPT.md`：繼續真正的 UI 主線，優先檢查結果頁、多人頁與 Catalog 的 error／disabled／focus／hover／touch 視覺狀態；逐頁核對實際 DOM／CSS，不以純文件盤點替代 UI 實作。保持單一狀態 owner；不要把已存在的 repository cancellation 重做一遍。
