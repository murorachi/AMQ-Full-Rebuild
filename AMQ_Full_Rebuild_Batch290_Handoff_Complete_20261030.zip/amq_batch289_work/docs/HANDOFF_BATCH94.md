# Batch 94 交接包：多人命令冪等重放與滑動視窗限流

Batch94 的程式變更保留在 Batch95 最終交付包內，以下是該批的獨立紀錄。

## 修改
- `src/multiplayer/room-command-service.js` 新增可選 `requestId` 冪等重放：key 以 JSON tuple `[authenticatedPlayerId, requestId]` 編碼；相同玩家／ID／命令重放回傳原成功結果，標示 `replayed: true`，不重複狀態轉移或評級；同 ID 不同 payload 拒絕 `ROOM_REQUEST_ID_REUSED`；不同玩家隔離。
- fingerprint 依排序後 JSON key 生成；循環參照、BigInt、function、symbol、undefined 等非 JSON 值拒絕。
- 有界 FIFO 快取預設 256 筆，`maxIdempotencyEntries` 允許 0–10,000。
- 每玩家 sliding-window rate limit 預設 60 commands／10,000 ms；`maxCommandsPerWindow` 允許 1–100,000，`commandWindowMs` 允許 100–600,000。超限回報 `ROOM_RATE_LIMITED`、`retryAfterMs`、limit/window；冪等重放不消耗額度。
- 測試更新於 `tests/multiplayer-room-command-service.test.cjs`，並更新架構／驗收／主清單／工作狀態／下一階段提示。

## 專項驗證
- `node --check src/multiplayer/room-command-service.js`：PASS。
- `node tests/multiplayer-room-command-service.test.cjs`：PASS，涵蓋 replay、payload mismatch、跨玩家隔離、cache eviction、限流、窗口到期及非法設定。

## 限制
冪等快取與限流只在單一 service instance 記憶體生命週期內有效，不取代正式 server 的 durable idempotency、per-room serialization、認證、連線／IP／帳號層限流與多客戶端 E2E。多人 SRS persistence 仍需產品決策，禁止寫入沒有 user identity 的共用本機 key。
