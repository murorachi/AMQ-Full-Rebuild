# Batch194 交接：多人題目投影威脅模型與 stale polling 契約

日期：2026-10-28
工作副本：使用者提供的 Batch193 handoff ZIP 解壓取得；無 `.git`，未初始化。

## 本批完成
- 新增 `docs/MULTIPLAYER_THREAT_MODEL_BATCH194.md`，明確區分一般答案欄位遮蔽與強反作弊，記錄 `state.currentRound.questionId`、`questionProjection`、audioCandidates URL 的可觀察性，以及 HTTP polling／跨裝置音訊同步的限制。
- `tests/multiplayer-room-session.test.cjs` 新增 stale polling controlled regression：較舊 poll 在較新 command snapshot 套用後才完成，不得回滾 revision 或發布舊 revision。RoomSession 8/8 PASS。
- 未找到足以支持重寫 room state machine 或新增第二個 AudioService owner 的證據，因此沒有修改 production state machine／audio owner。

## 修改檔案
- `tests/multiplayer-room-session.test.cjs`
- `docs/MULTIPLAYER_THREAT_MODEL_BATCH194.md`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/HANDOFF_BATCH194.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `artifacts/batch194-regression/*`

## 驗證
- 全量 Node tests：75/75 檔案 exit 0。`quiz-pool.test.cjs` 首次觸及 12 秒單檔限制後另行執行，10/10 PASS；完整逐檔狀態與 logs 在 `artifacts/batch194-regression/node-tests.tsv`、`node-tests.json`、`node-tests/`。
- Multiplayer test files：12/12 exit 0，見 `multiplayer-tests.tsv` 與 `multiplayer/`。
- Architecture Checker：1,102 PASS／0 FAIL。
- OSK import panel harness：12/12 assertions PASS。
- JS/CJS syntax：171/171 PASS。
- AMQ asset SHA-256 `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ asset SHA-256 `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 尚未完成／阻塞
- 公開快照的 `state.currentRound.questionId` 仍可能與本機曲庫記錄對應；audioCandidates URL 亦可被觀察。只移除 projection 的單一欄位無法解決，需要 public DTO 與 server-private identity 完整分離。
- 真實多人瀏覽器／音訊 E2E 仍受既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。沒有宣稱音訊同步、強反作弊、WebSocket 或多節點已完成。
- Candidate302／Candidate382 Stage 0 原始檔缺席，未宣稱相容性驗收；無 `.git`，未初始化。

## 下一批 Batch195
檢查所有 `currentRound.questionId` 使用點，設計並測試 public snapshot DTO 與 server-private round identity 分離；補 active-round transition projection freshness tests。保持 server-authoritative assessment/deadline/SRS、requestId idempotency、membership authorization 與單一 AudioService owner。
