# Batch218 交接：結果頁重掛載、Catalog 分頁焦點與多人延遲命令

日期：2026-10-29
工作副本：`/mnt/data/amq_batch216_work/project`
來源交付：`AMQ_Full_Rebuild_Batch217_Catalog_Keyboard_Multiplayer_UI_20261029.zip`
本批交付：`AMQ_Full_Rebuild_Batch218_ResultRestore_BusyLifecycle_UI_20261029.zip`

## 本批完成

- `tests/quiz-panel.test.cjs` 新增 fresh-mount result restore：完成回合後先 dispose 原 QuizPanel，再以相同持久化 history owner 重掛載，確認結果頁恢復最近完成 marker，並且列表數量只等於該 roundId 的已保存明細。沒有建立第二份 history store，也沒有跨回合合併資料。
- `tests/catalog-browser.integration.test.cjs` 新增分頁焦點回歸：若目前聚焦歌曲列在翻頁後不再存在，焦點回到搜尋輸入；前批已驗證篩選後保留相同 row 或退回搜尋欄。
- `tests/multiplayer-panel.integration.test.cjs` 新增可控延遲 command：伺服器命令 pending 時 `aria-busy=true`、ready toggle disabled、status 顯示「操作處理中」；命令完成後 `aria-busy=false` 並反映 server snapshot。離線 alert／恢復清錯仍通過。
- `tests/quiz-history-store.test.cjs` 重跑，確認 marker persistence 與 round ID isolation 契約維持。
- `tests/app-shell.browser.test.py` 輸出更新到 `artifacts/batch218-regression/`，正式 shell 92/92 PASS；Architecture 1,137/0；172 JS/CJS syntax 與 3 Python `py_compile` PASS。

## 驗證界線

- Batch217 全量 Node suite 77/77 PASS；Batch218 修改的三個 integration suites（Catalog、QuizPanel、Multiplayer）與 Quiz History Store 已個別重跑 PASS。因本批只擴充測試、不修改 production source，未再次重跑全部 77 個檔案。若下一批改動 production source，需重新跑全量 suite。
- HTTP-origin test 未重跑，因 Chromium loopback `ERR_BLOCKED_BY_ADMINISTRATOR` 的 policy／origin 條件沒有改變；真實 save/reload assertions 仍未執行。
- 真實 `.osk`、live 曲庫／封面／音訊、Candidate302／Candidate382 Stage 0 相容性與完整實機驗收仍未完成。全球排行榜無可信 backend owner，不造 PP／排名／PB。
- 無 `.git`，未初始化；正式基準原始檔缺席，不宣稱相容。UI 主線未結案。

## 下一批優先

1. 若修改 production code，先跑全量 77 Node test files，再執行 browser／architecture／syntax。
2. Catalog mode switch、loading／failed／empty 狀態與 keyboard focus 的整合回歸。
3. 多人命令拒絕／網路失敗時 busy 清除與可重試狀態。
4. OSK 剩餘 13 roles 只有在有語義正確 DOM／CSS consumer 時才解除 unsupported。
5. HTTP-origin test 只在 browser policy／origin 改變時重跑。
