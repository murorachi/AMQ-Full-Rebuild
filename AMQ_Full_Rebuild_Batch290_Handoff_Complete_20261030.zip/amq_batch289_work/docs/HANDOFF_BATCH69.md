# AMQ Batch 69 交接：答案建議匹配結構與相關度排序修正

日期：2026-10-27

## 本批目的

依使用者已確認的搜尋規格修正答案候選匹配。舊版 V82.x 靜態程式雖提供高亮及候選 UI 線索，但其 `separatorMatcher` 將空白、斜線、連字號合併成同一類；這個行為與使用者本次明確規格衝突，因此不照搬該缺陷。

## 修改範圍

- `src/ui/answer-suggestions.js`
  - 移除 compact 無空白搜尋；不再先刪除候選中的空白／符號再匹配。
  - NFKC／大小寫正規化保留空白、標點及特殊 Unicode 的結構。
  - 使用者輸入 `/ - : ; ' . ,` 或指定特殊 Unicode 符號時，該位置只允許匹配相同符號或一個空白；不同標點不互換。
  - 使用者輸入空白時只匹配空白，不會反向匹配任意標點。
  - `AB` 只匹配連續 `AB`，不會命中 `A-B`、`A B`、`A★B`。
  - 排序層級：正規化後完全符合 → 字面開頭 → 分隔符容錯開頭 → 字面包含 → 分隔符容錯包含。每層內短名稱優先，再依正規化文字／原文穩定排序。
  - 保留最多 25 筆、候選去重、原始顯示標籤、安全 DOM 高亮與既有 controller 生命週期。
- `tests/answer-suggestions.test.cjs`
  - 由 11 個情境擴充為 15 個，覆蓋標點互斥、單向空白容錯、連續字串、Unicode、匹配層級與排序。
- 文件已同步更新：`docs/MASTER_CHECKLIST.md`、`docs/WORK_STATUS.md`、`docs/DATA_CONTRACT.md`、`docs/FUNCTION_INVENTORY.md`、`AI_START_HERE.md`、`docs/NEXT_SESSION_PROMPT.md`。

## 關鍵驗收案例

| 輸入 | 可匹配規則 | 不可匹配 |
|---|---|---|
| `A-B` | `A-B`、`A B`，以及包含完整字串／前綴延伸的相關候選 | `A/B`、`A:B` |
| `A B` | 保留空白結構的結果，如 `A B`、`A BC`、`CA B` | `A-B`、`A/B` |
| `A/B` | `A/B`、`A B`，以及包含完整結構的相關候選 | `A-B`、`A:B` |
| `AB` | `AB`、`ABC`、`XABY` | `A-B`、`A B`、`A★B` |
| `A★B` | `A★B`、`A B` | `A-B`、`A/B` |

排序不只按長度：先按匹配相關度，再按名稱長度。以 `A-B` 為例，`A-B` 排最前，接著 `A-BC`、`A-BCD`，分隔符容錯結果 `A B` 在後，內部包含的 `CA-B` 不會排在 `A-B` 前面。

## 實際測試證據

- 全部 `tests/*.test.cjs`：27/27 scripts exit 0。
- `tests/answer-suggestions.test.cjs`：15 個情境 PASS。
- `node --test tests/tooling.test.cjs`：8/8 PASS。
- `node tools/check-architecture.cjs`：480 passed／0 failed。
- `node tools/audit-source-data.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS。
- `node tools/verify-source-mappers.cjs src/data/assets/data.js src/data/assets/emq-data.js`：PASS；AMQ 38,821、EMQ 16,839、Catalog 55,660。
- `node tools/benchmark-catalog.cjs src/data/assets/data.js src/data/assets/emq-data.js 5`：PASS；Catalog build 約 1,189.675 ms（本機 Node 記憶體內觀察，不是瀏覽器效能保證）。
- `src/`、`tests/`、`tools/` 所有 JS/CJS `node --check`：PASS。
- 來源資產 SHA-256 未變：AMQ `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3`；EMQ `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 未驗收／阻塞

- 真實瀏覽器的候選清單、高亮、IME、方向鍵、Enter、滑鼠選取與視覺穩定性仍待使用者驗收。Node／fake DOM 測試不等於 E2E。
- 真實音訊可聽性未驗收，本批未修改音訊程式。
- 繁體中文作品標題 provider、收藏 UI／legacy identity、Candidate302／Candidate382 Stage 0 相容性維持既有阻塞。
- 工作副本沒有 `.git` metadata；沒有初始化 Git、commit 或 push。

## 下一步

1. 使用者本機抽測 `A-B`、`A B`、`A/B`、`AB`、`: ; ' . ,` 與難輸入 Unicode 的搜尋結果及排序。
2. 驗收高亮、方向鍵、Enter 選取不提交、Escape、滑鼠點選及中文輸入法。
3. 如有錯誤，先加具體回歸案例，再修改 matcher；不可恢復 compact 無空白匹配或把不同標點視為同一類。
4. 真實瀏覽器／音訊仍維持未驗收；不搜尋 Candidate302、不改來源資產、不提前全面 UI／CSS 重構。
