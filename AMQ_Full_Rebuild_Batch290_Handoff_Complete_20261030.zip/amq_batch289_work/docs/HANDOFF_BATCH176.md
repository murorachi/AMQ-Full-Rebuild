# Batch176 交接：跨分頁 History pending rows 與 summary rebuild

## 工作副本／基準
- 工作副本：`/mnt/data/amq_batch153_work`；無 `.git` metadata，未初始化。Node v22.16.0。
- Candidate302 是正式維護基準；Candidate382 Stage 0 是 CSS 比較基準。原始檔不在副本，未 hash 比對或覆蓋。AMQ／EMQ 曲庫資產未修改。

## 已修正的可重現缺陷
1. **外部 storage event 遺失本地未保存紀錄**：`src/persistence/quiz-history-store.js` 新增 `pendingDetailIds`，只記錄 detail write 失敗時新加入的 entry IDs。外部 detail refresh 成功時，以外部快照為主，合併仍 pending 且未重複的本地列；合併 detail 寫入成功才清空 pending IDs。若重試仍失敗，保留 pending 狀態，下一次 storage event 可再次嘗試。
2. **外部 detail snapshot 替換後 summary 只增不減**：當事件是 detail key，且既有 summary baseline 未標記可能截斷、detail 讀取成功、沒有待保存資料時，強制由 authoritative detail 重建 summary，避免已不存在的舊 rows 留在 aggregate。若 `baseline.mayBeTruncated === true`，不從最多 2,000 筆 detail 反推完整摘要，以免遺失被截斷的歷史總量。

## 測試與證據
- `tests/quiz-history-store.test.cjs` 新增兩項 regression，修正前分別重現本地 pending row 遺失及 summary total 由 1 錯誤增至 2；修正後 18/18 PASS。
- 修正前證據：`artifacts/batch176-regression/history-cross-tab-before-fix.log`、`artifacts/batch176-regression/history-summary-rebuild-before-fix.log`。
- AudioService 22 個情境 PASS；QuizSession 25/25 PASS。
- 71 個 Node test files 分 9 組全數 exit 0；architecture 1,051 PASS／0 FAIL；OSK harness 12/12；160 個 JS/CJS `node --check` PASS。
- 完整 log／摘要：`artifacts/batch176-regression/README.md`、`summary.json` 與 `group-01.log` 至 `group-09.log`。
- 分組執行有觸及外層時間限制；被中止的 orchestration 未算通過，之後逐組補跑並確認九組都有完成的 log 與 exit 0。

## 未驗收／限制
- 真實瀏覽器音訊與可聽性、ANN API／CORS／封面、真實 `.osk`、HTTP-origin IndexedDB、viewport／鍵盤仍未驗收。
- Candidate302／Candidate382 Stage 0 原始檔缺席，無法 hash 比對；無 Git metadata。
- 外部 summary event 先於 detail event，以及 baseline 已截斷的跨分頁更新仍需 Batch177 針對性驗證。

## Batch177 下一步
1. 以 controlled storage event 明確模擬 summary key event 先於 detail key event，檢查讀取順序是否會短暫或永久覆寫摘要。
2. 以超過 detail cap 的 summary fixture，驗證 `mayBeTruncated` 狀態下 append／external snapshot／retry 的去重及總數一致性。
3. 只修改能由 regression 重現的 P0/P1；保留 detail-first consistency、timer generation、單一 playback owner、`playAttemptId`、`playbackEpoch` 與四級熟悉度規則。
