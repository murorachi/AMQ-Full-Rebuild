# Batch274 Handoff：Node 測試逾時拆解與 blocker evidence refresh

## 本批已完成
- 獨立工作副本 `/tmp/AMQ_Batch274`，來源 Batch273 未覆寫；本工作目錄沒有 `.git`，未初始化 Git。
- 找出 `tests/quiz-pool.test.cjs` 兩個高成本 seeded distribution loops 是測試窗口的重要成本之一：40,000／30,000 draws 改為 8,000／6,000。仍保留 weak-overdue > due > new > future、future share <10%、MIX AMQ ratio 65–68% 等統計契約。單檔約 5 秒完成。
- 98 個 Node test files 分 20 組執行，20/20 組 exit 0，303/303 subtests PASS。每組 log 在 `artifacts/batch274-regression/node-groups/group-01.log` 至 `group-20.log`；aggregate `artifacts/batch274-regression/node-suite-summary.json`。
- `node tools/check-architecture.cjs`：1,335 PASS／0 FAIL；JS/CJS syntax 全部 exit 0；Python AST 33/33 PASS。
- Browser regressions：Home/Catalog 81/81、Multiplayer Lobby 32/32、Multiplayer Skin role apply/fallback/reset/scope 5/5，page errors 0。
- 新增 `tests/audio-service.native-browser.test.py`，使用 Chromium 原生 HTMLAudioElement 解碼 generated WAV，測試失效候選 fallback、duration、stop 清理 5/5 PASS。Headless 媒體停在 `ready`，因此不宣稱可聽播放。
- 本地 server 的 multiplayer HTTP/auth/room lifecycle integration tests 已在 Node 分組中通過；不是外部部署環境驗收。

## 仍然阻塞，不可假裝解決
- HTTP-origin IndexedDB：原 loopback 與非 loopback container interface 都被 Chromium `ERR_BLOCKED_BY_ADMINISTRATOR` 阻擋。證據 `artifacts/batch274-regression/http-origin-blocker.txt`。需要允許 HTTP-origin 的隔離瀏覽器／CI；目前環境不能靠改 host 解決，不要再重複探測或繞過政策。
- Live ANN/VNDB artwork、正式 Home/Catalog data、外部 AMQ/EMQ audio provider：mapping／adapter／fallback 已有測試，但外部 provider 成功回應與真實音訊播放尚無證據。
- 人工 osu! Stable visual gate：未通過。Home 主視覺空白/fallback 與 Stable Main Menu 的構圖差距明顯；DG-002、DG-006 保持 P0。
- Windows／實機鍵盤、觸控與人工驗收未執行。

## 下一批 Batch275
1. 若執行環境未變，不重試 HTTP-origin browser navigation；先取得可允許正常 HTTP-origin 的隔離瀏覽器/CI，才跑保存／重載驗收。
2. 推進真實 Home/Catalog artwork 與資料視覺；沒有正式資料/provider response 時保留 fallback，不用 fixture 假裝 live。
3. 真正關閉 Home 主視覺構圖差距，再做 Stable 參考／正式截圖人工判定。
4. 對外部 AMQ/EMQ 音源建立 provider-specific 可重現 browser evidence；native WAV readiness 不可替代。
5. 以 20 組 Node 測試證據做回歸，避免 monolithic runner 逾時遮蔽測試結果。

詳細界線：`docs/BATCH274_BLOCKER_RESOLUTION.md`。
