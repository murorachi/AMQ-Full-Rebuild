# Batch193 交接：多人房間逾時持久化退避

日期：2026-10-28
工作副本：由 Batch192 ZIP 解壓取得；無 `.git`，未初始化。

## 本批完成

- `server/multiplayer-host.cjs` 新增可注入 `setTimeout`／`clearTimeout` 與 `timeoutRetryDelayMs`。重試退避預設 1000ms，合法設定範圍 100–60000ms。
- `restoreEntry()` 若恢復的是已超過 deadline 的 active round，會套用最小退避；避免 timer callback 或 GET snapshot 的持久化失敗把逾時排程重新設成 0ms。
- `tests/multiplayer-host-retention.test.cjs` 使用 SQLite trigger 注入持久化失敗，覆蓋 timer-driven timeout 與 snapshot-driven timeout；兩條路徑均確認退避並在故障解除後成功結算。
- 修正前測試失敗證據 `artifacts/batch193-regression/timeout-backoff-before-fix.log`；修正後 `timeout-backoff-after-fix.log`。

## 修改檔案

- `server/multiplayer-host.cjs`
- `tests/multiplayer-host-retention.test.cjs`
- `docs/WORK_STATUS.md`
- `docs/MASTER_CHECKLIST.md`
- `docs/HANDOFF_BATCH193.md`
- `docs/NEXT_SESSION_PROMPT.md`
- `AI_START_HERE.md`
- `artifacts/batch193-regression/*`

## 驗證

- 全量 75 個 Node test files 75/75 exit 0；首輪執行於 59 個檔案後觸及外層時間限制，剩餘 16 個另行補跑。狀態與個別 log 在 `artifacts/batch193-regression/node-tests.tsv`、`node-tests.json`、`node-tests/`。
- 最終程式碼上 13 個多人／server auth test files 13/13 exit 0，`multiplayer-tests.tsv` 與 `multiplayer/`。
- Architecture 1,102 PASS／0 FAIL；OSK panel harness 12/12；171 JS/CJS syntax checks PASS。
- AMQ／EMQ asset SHA-256 與 Batch192 一致。

## 尚未驗收

- 仍是 authenticated HTTP polling，沒有 WebSocket／多節點共享 queue；狀態保證限單一 SQLite／單一 server process。
- 多人 UI／多客戶端真實瀏覽器 E2E、AudioService 音訊同步、音源 availability 與時鐘差異尚未驗收。
- `questionId` 與音訊 URL 可能與本機曲庫關聯答案；目前 answer masking 不代表強反作弊。需先定義威脅模型。
- 真實瀏覽器導覽既有 `ERR_BLOCKED_BY_ADMINISTRATOR` 阻塞；Candidate302／Candidate382 Stage 0 原始檔缺席；無 `.git`。

## 下一批 Batch194

建立題目投影／音訊同步威脅模型與契約測試，檢查 questionId、audioCandidates、stale polling、AbortSignal 及 AudioService owner；在不新增第二個 media owner 的前提下完成可獨立驗證的部分。不要宣稱 WebSocket、強反作弊或多客戶端音訊同步已完成。
