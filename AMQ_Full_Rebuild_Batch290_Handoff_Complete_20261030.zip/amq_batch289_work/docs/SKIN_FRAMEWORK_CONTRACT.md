# Skin Framework Contract: OSK semantics, geometry, and AMQ layout

## Source of truth reviewed

- Official Skinning overview: https://osu.ppy.sh/wiki/en/Skinning
- Official interface asset catalogue: https://osu.ppy.sh/wiki/en/Skinning/Interface
- Official `skin.ini` specification: https://osu.ppy.sh/wiki/en/Skinning/skin.ini

The wiki describes a set of individually named interface/game assets with specific origins, dimensions, tint/blend behavior, animation rules, and version-dependent semantics. An `.osk` is therefore **not** a website-wide theme stylesheet. Importing bytes and putting an image on a vaguely similar DOM node is not a faithful mapping strategy.

## Geometry and mapping rules

1. Preserve semantic role boundaries. A filename match is only a candidate when the source element's purpose matches the AMQ destination. Never use a random character image as a song cover, a song-select frame as the independent player dock, or a ranking grade as answer correctness.
2. Treat `menu-background.jpg` as a viewport background: centered, `cover`, aspect ratio preserved, crop overflow. The wiki documents the 1366x768 suggested SD size and center/cover behavior.
3. Treat `menu-button-background.png` as a state-tinted beatmap/difficulty button/scoreboard asset, not a generic panel. Wiki notes include minimum 690x85, bottom-left origin, thumbnail support in skin version 2.2+, and state-dependent tinting.
4. Treat `songselect-top.png` and `songselect-bottom.png` as frame pieces with different geometry. The top piece can repeat edge pixels based on resolution; the bottom stretches to viewport width. The bottom piece must not be mapped automatically to AMQ's player dock.
5. Preserve state variants and animation families. For example, `selection-options-over.png` is a hover state, and `menu-back-{n}.png` is an animation sequence. A single arbitrary frame is not a complete replacement when the state/animation family exists.
6. Read `skin.ini` case-sensitively. Its version changes positioning and behavior; `@2x` assets are high-density variants. Do not infer physical CSS dimensions directly from image pixels without applying the documented scale/version semantics.
7. The mapping studio preview uses `object-fit: contain` on a checkerboard surface so transparent edges and intrinsic proportions remain visible. Runtime rendering is role-specific; each role's final CSS consumer must define its fit, crop, anchor, stacking, and state behavior explicitly.
8. AMQ extension slots remain explicit when no equivalent osu! asset exists. They use the existing AMQ fallback until a suitable mapping is manually selected. A successful archive parse is not proof that every role is supported.

## Framework layers

- Archive parser: reads `.osk` entries and `skin.ini`; does not decide where every image belongs.
- Stable asset contract: records filename, source semantics, dimensions/anchor notes, skin version sensitivity, and mapping policy.
- AMQ role contract: names the exact destination component and default fallback.
- Mapping studio: displays evidence, exact matches, runtime support, and a proportional preview; manual candidates are kept separate from automatic suggestions.
- Theme resolver: normalizes safe region/component layout overrides and defines precedence.
- Persistence/transfer: saves and exports mappings plus overrides without dropping legacy records.
- Runtime adapter: applies only to real DOM targets, reports missing targets, and restores prior inline styles on reset.

## Acceptance boundary

The goal is a coherent, well-composed AMQ shell with role-level replacement, not a claim that every osu! element has a one-to-one AMQ equivalent. A mapping is considered implemented only when the target exists, its CSS consumes the assigned token/asset, the aspect/crop/anchor behavior is intentional, and browser tests show the normal fallback and reset path still work. Real `.osk` and visual browser/device acceptance remain separate gates.


## Batch236: role geometry preview and real partial Skin audit

- `src/skins/skin-geometry.js` adds a role-specific preview contract. Home/quiz backgrounds use centered `cover`; song-select top and bottom frames are deliberately distinct (`repeat-x` guidance versus horizontal stretch); `menu-button-background` is labelled stateful rather than a generic panel; result grades and artwork slots retain semantic boundaries.
- The mapping studio displays each role's geometry note beside its preview. These are previews/guidance, not a claim that the browser reproduces every osu! stable blend, tint, edge-pixel repetition, input state or native coordinate system.
- `osk-importer.js` now preserves repeated `[Mania]` blocks in `metadata.sectionBlocks`, audits referenced Mania image paths against the archive, warns on missing references without rejecting partial skins, and recognizes both `selection-mode.png` and legacy `selection-mode-osu.png`.
- The user-provided `aristia hima.osk` was inspected locally. It contains 120 entries (119 images, no audio), declares `Version: latest`, has no `@2x` files, and its three `[Mania]` blocks reference assets that are absent from this intentionally partial archive. The archive has `selection-mode.png`, `selection-random.png`, `selection-options.png`, `menu-button-background.png`, and `ranking-panel.png`, but no `menu-background.jpg`, `selection-bar.png`, `songselect-top.png`, or `songselect-bottom.png`. See `artifacts/batch236-regression/real-osk-audit.json`; it contains metadata/counts only, not copied artwork.
- The geometry-aware preview can show the difference between intrinsic asset preview and intended target geometry, but it does not yet implement native nine-slice/edge-pixel reconstruction, full tint blend modes, or state-pair auto-binding. Those remain explicit next steps rather than implied capabilities.


## Batch237: AMQ visual requirements before asset assignment

- Added `docs/skin-contract/amq-visual-needs.v1.json` as the requirements-first inventory: 30 needs across home, catalog, quiz, multiplayer, learning, results, settings, player, and shared feedback. This is separate from the imported OSK inventory; missing files never remove a UI requirement.
- Added `src/skins/amq-visual-needs.js` and a visible Mapping Studio needs board. It shows required/optional needs, current selected mapping coverage, and whether referenced roles have a reviewed runtime target. The board deliberately separates "asset assigned" from "runtime component supported".
- Added `catalog.filter.background` as an explicit AMQ extension role. It is intentionally not claimed as runtime-supported until a real target/CSS consumer is reviewed.
- Added `docs/AMQ_VISUAL_NEEDS_TRACEABILITY_BATCH237.md`, linking each need to geometry, role IDs, stable candidates, runtime selectors/support state and fallback rules.
- Official Wiki source review confirms the asset table describes per-element behavior, not a generic image pack: for example, `menu-background.jpg` uses centered cover/crop; button pieces have specific origins, stretch behavior and state tint; sounds have explicit event semantics and must not be assigned randomly.
- Validation: requirements registry + importer/geometry/adapter/store/transfer/manifest focused tests are run separately; synthetic Chromium mapping studio asserts the requirements board renders before per-role selectors. Native stable renderer fidelity remains unverified.

## Batch241 pixel renderer contracts

- `src/skins/skin-blend.js` adds deterministic RGBA channel multiplication (`source RGB × tint RGB / 255`) while preserving source alpha. It validates input geometry and is useful as a unit-testable AMQ pixel primitive. It is **not** evidence that the complete osu!stable multiplicative blend pipeline, skin.ini version rules, alpha composition, or GPU compositing have been reproduced.
- `src/skins/skin-edge-repeat.js` adds an explicit right-edge RGBA extension contract. Callers must supply the edge width; invalid dimensions fail closed. This lets tests verify the pixel-copy behavior without third-party artwork, but it is **not** asserted to match every `songselect-top` version/resolution rule. Native stable edge-repeat remains unsupported until its exact algorithm and real target geometry are independently verified.
- The shared renderer exposes these contracts only when their scripts load first. `nativeStableFidelity.multiplicativeTint` and `.songselectTopEdgeRepeat` intentionally remain `false`. Existing Mapping Studio `repeat-x` remains preview guidance, not a native renderer claim.
- Test fixtures are synthetic RGBA arrays created in source code; no third-party skin artwork is copied into the project.


## Batch242: Canvas integration seam (not native stable fidelity)

- `src/skins/skin-canvas-renderer.js` adds a browser Canvas pipeline: bounded Blob decode via `createImageBitmap`, pixel-limited RGBA readback, optional use of the AMQ multiply contract, optional explicit edge extension, and ImageData writeback. `renderBlobToCanvas` owns and closes its temporary ImageBitmap in a `finally` block.
- The default decode budget is 16 MiB and the default pixel budget is 16 megapixels. Callers can lower either bound per operation. Invalid geometry, unsupported Canvas APIs, decode failures, readback failures and writeback failures use stable `SKIN_*` error codes.
- The shared renderer exposes the integration seam as `canvas-decode-read-transform-write-v1`. The browser test builds a tiny PNG from generated RGBA data and checks real Chromium decode/read/write behavior; it does not import or redistribute third-party artwork.
- This integration seam does **not** claim native osu!stable fidelity. `nativeStableFidelity` remains false for multiplicative tint and `songselect-top` edge-repeat. Exact skin.ini version rules, premultiplication/compositing, animation and target-geometry semantics remain separate acceptance tasks.


## Batch243：Canvas 像素預算與 alpha 量化

- `skin-edge-repeat.js` 的 `extendRightEdgeRgba(..., maxPixels)` 現在同時限制來源與輸出像素數；省略上限時使用 16 MP 預設值。幾何須為安全整數，避免溢位或不受控 TypedArray allocation。
- `skin-canvas-renderer.js` 在配置輸出 Canvas 前檢查 `targetWidth × height`，輸出延展超過 `maxPixels` 時回傳 `SKIN_IMAGE_PIXEL_LIMIT_EXCEEDED`，不配置輸出 Canvas。來源 readback canvas 仍可能在判定輸出幾何前建立一次，這是讀取來源像素所需的成本。
- Chromium 測試覆蓋 opaque、partial-alpha、fully-transparent pixel、逐列 edge repeat、解碼超過像素上限時關閉 ImageBitmap，以及 render pipeline 例外時的 `finally` cleanup。
- Canvas 的 premultiplied-alpha／PNG encode-decode 可能造成低位元 RGB 量化差異；例如半透明通道在 readback/writeback 後可由 25 變成 26。這不是原生 osu!stable compositor 的相容性證明，測試明確驗證目前 Chromium 的可觀察契約，`nativeStableFidelity` 仍保持 false。
