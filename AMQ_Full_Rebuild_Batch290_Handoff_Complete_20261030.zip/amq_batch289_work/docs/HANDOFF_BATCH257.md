# Batch257 Handoff：Route-aware Skin 可見狀態矩陣

## 基準與交付方向
- 唯讀基準 ZIP：`AMQ_Full_Rebuild_Batch256_Catalog_Filter_Skin_Role_20261029.zip`
- SHA-256：`5830ba0b35e6366bd5684657e0a699334550a1fa42d1eb89b8199e42f0cd1a39`，sidecar 一致。
- 新版 AMQ 獨立開發。Candidate302／Candidate382 不再列入基準、待辦或阻塞。
- 工作副本無 `.git`；未初始化 Git，未修改 AMQ／EMQ 原始資料。

## 實作與證據
- 新增 `tests/batch257-route-skin-visible.browser.py`：使用正式 `src/index.html`、正式 JS／CSS 與 Chromium，透過 app 的實際導航進入 Home、Catalog、Quiz、Results。
- `artifacts/batch257-regression/route-skin-visible-state.json` 記錄 route、可見角色與每項檢查；截圖為 `home-visible-state.png`、`catalog-visible-state.png`、`quiz-visible-state.png`、`results-visible-state.png`。
- 64/64 route assertions PASS；32 個可見 role-route 配對全部完成 apply／missing asset fallback／reset／token scope 驗證。
- 可見角色數：Home 4、Catalog 15、Quiz 9、Results 4。只計可見 DOM，不把隱藏頁面目標當作可見覆蓋。Results 當前是真實 empty state，未將隱藏的 `results.panel` 當作可見角色。
- Batch251 cross-page Chromium 45/45；Batch247 Home/Catalog Chromium 22/22；Batch254 production DOM role matrix 36/36 apply、36/36 fallback、36/36 reset，0 page errors。
- Node 92/92 test files exit 0，證據 `artifacts/batch257-regression/node-tests/summary.json`、`summary.tsv` 及 chunk logs。
- Architecture Checker 1,293 PASS／0 FAIL；JS/CJS syntax 186/186；Python AST compile 17/17。
- AMQ／EMQ raw data hashes unchanged: `692f69f56079d6cc0b30bd1951ab625f53799b87525c1bd52a27f29274703cf3` / `88441b4a6090c01db1dae23c970a6fa24d457a54f4b915be3e23c3799b3794cc`。

## 限制
- 本批是正式 DOM／inline assets 的本地 Chromium 驗收，不代表真實 HTTP-origin IndexedDB、live audio/catalog/artwork provider 或 Windows／實機驗收。
- `catalog.action.random`、`settings.slider` 維持 unsupported，因目前沒有對應的 Catalog 行為 owner／Settings range input。
- Native osu!stable compositor fidelity 不是新版預設驗收要求，亦未宣稱已達成。

## 下一批 Batch258
1. 新增 Settings、Learning Center、Multiplayer route-aware visible-state matrix。
2. 針對可見控制項驗證 skin apply／fallback／reset、ARIA、鍵盤焦點、390px overflow、reduced motion。
3. 覆蓋真實空狀態與可觸發的錯誤／復原狀態；不得製造假成績或假統計。
4. 更新主清單、工作狀態、traceability、handoff、next prompt、README／AI start、manifest 與 ZIP。
