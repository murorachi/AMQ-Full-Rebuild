# Batch167 交接：面板建構期間的資源回滾

## 確認
- 延續 Batch166 工作副本 `/mnt/data/amq_batch153_work`；沒有 `.git` metadata，未初始化 Git。
- Candidate302、Candidate382 Stage 0 與原始 AMQ／EMQ 資產維持唯讀。
- 未重試已知被環境政策阻擋的瀏覽器導覽。

## 實作
- `src/ui/statistics-dashboard-panel.js`：先驗證必要的 statistics projection dependency，再建立 quiz history、familiarity、SRS 與 playback history stores。缺少必要 projection 時，現在會在任何 store 建立前 fail fast，避免 constructor 拋錯但 disposer 尚未回傳時留下資源。
- `tests/statistics-dashboard-panel.test.cjs`：新增缺少 projection 時不建立任何 persistence store 的 regression assertion。
- `src/ui/free-player-dock.js`：先取得 AudioService，再取得 playback history store；若後者建立失敗且 AudioService 由 Dock 自己建立，立即 dispose AudioService 並重新拋出原始錯誤。
- `tests/free-player-dock.test.cjs`：新增 history store 初始化失敗時 AudioService 恰好 dispose 一次的 regression assertion。

## 驗證
- 受影響測試：`node --test tests/statistics-dashboard-panel.test.cjs tests/free-player-dock.test.cjs tests/app-lifecycle.integration.test.cjs tests/app-artwork-lifecycle.integration.test.cjs`，4/4 top-level test files PASS；新增兩項 failure-path assertion 通過。
- 架構檢查：`node tools/check-architecture.cjs`，1,051 PASS／0 FAIL，exit 0。
- `src`／`tests`／`tools`／`server` 共 160 個 JS／CJS 檔案語法檢查，0 failures。
- 全部 71 個 `tests/*.test.cjs` 分 9 組執行，165/165 tests PASS、0 failures；每組 exit 0。完整分組清單、log、exit code 與 `summary.json` 位於 `artifacts/batch166-regression/`（此目錄延續收錄 Batch166／167 的回歸證據）。
- OSK panel 12/12 assertions PASS（沿用 Batch166 同一工作副本的結果；本批未改 OSK code）。

## 未解決／阻塞
- 真實 Chromium viewport、ANN API／CORS／圖片、真實 `.osk`、非 opaque HTTP origin IndexedDB 尚未驗收。
- 沒有 Git metadata；未初始化 Git。

## 下一步 Batch168
1. 以同樣標準檢查 Catalog mount：根節點／必要依賴應在建立自有 store/provider 前驗證；若有可重現失敗路徑，先補 regression 再修。
2. 檢查其他 panel constructor 的多資源 acquisition 是否在第二項資源建立失敗時回滾第一項；僅修已證實的漏洞。
3. 保持選曲與播放責任分離，繼續回歸驗證及更新同一份工作清單。
