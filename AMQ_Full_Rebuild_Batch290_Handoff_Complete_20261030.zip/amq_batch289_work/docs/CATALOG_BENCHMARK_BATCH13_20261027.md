# Catalog 效能量測（Batch 13，2026-10-27）

> 範圍：目前可取得的 Library AMQ／EMQ 檔案、目前有證據的 mapper 與 Node 記憶體內 Catalog。不是瀏覽器延遲、Candidate302 相容性或音訊播放驗收。

## 資料與環境

- Node：`v22.16.0`（linux/x64）
- AMQ：38,821 首；EMQ：16,839 首；合計 55,660 首。
- Catalog 建置：714.749 ms（不含檔案讀取、解壓、mapping 與驗證）。
- 每案例暖身 1 次，量測 30 次。

## 搜尋與篩選

| 案例 | P50 | P95 |
|---|---:|---:|
| `title_substring` | 11.768 ms | 13.355 ms |
| `artist_substring` | 10.663 ms | 12.218 ms |
| `work_title_substring` | 10.890 ms | 11.971 ms |
| `source_type_filter` | 0.969 ms | 2.210 ms |
| `combined_filter` | 8.141 ms | 9.623 ms |
| `empty_query_first_page` | 1.420 ms | 2.445 ms |

## 分組統計

| 案例 | 匹配總數 | 分組數 | P50 | P95 |
|---|---:|---:|---:|---:|
| `group_by_source` | 55,660 | 2 | 13.468 ms | 15.624 ms |
| `group_by_type_with_source_filter` | 38,821 | 3 | 9.283 ms | 10.615 ms |

## 限制

- 這是觀察性基線，不設定未經產品需求支持的效能門檻。
- 搜尋與分組目前會掃描記憶體內快照；未實作倒排索引或模糊搜尋。
- 真實資料來源與 Candidate302 配套關係仍未確認；瀏覽器 E2E 與音訊可播放性仍阻塞。
- 可重現指令：`node tools/benchmark-catalog.cjs /mnt/data/files/data.js /mnt/data/files/emq-data.js 30`。
