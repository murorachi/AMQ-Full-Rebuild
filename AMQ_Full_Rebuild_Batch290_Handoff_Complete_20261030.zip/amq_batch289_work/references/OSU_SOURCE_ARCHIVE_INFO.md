# osu! Source archive metadata

- Archive supplied by user: `/mnt/data/osu-master.zip` (outside the compact project package).
- SHA-256: `973d68341d669c2e056563ee3b7a25e12aab1c8f73a8795790ed519497cfe583`.
- Research notes retained in this project: `docs/OSU_SOURCE_RESEARCH_BATCH271.md`, `docs/UI_OSU_STABLE_FIDELITY_PROMPT.md`.
- This archive primarily contains osu!lazer source; it is not claimed to be the complete osu!stable UI implementation or a complete export of the default Stable skin. Stable screenshot references remain the visual source of truth.
- The large archive is intentionally excluded from compact delivery ZIPs because it is research-only and not required to run AMQ or tests.
