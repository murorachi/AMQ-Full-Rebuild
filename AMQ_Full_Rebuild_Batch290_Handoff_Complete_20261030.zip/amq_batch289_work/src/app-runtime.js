/* Application composition boundary: the UI asks for a runtime without reading source globals itself. */
(function (global) {
  "use strict";

  function createRuntime(options) {
    const settings = options && typeof options === "object" ? options : {};
    const factory = global.AMQData && global.AMQData.sourceRuntime;
    if (!factory || typeof factory.createBrowserRuntime !== "function") return null;
    if (!global.DB || typeof global.__EMQ_PACKED_B64 !== "string") return null;
    return factory.createBrowserRuntime(settings);
  }

  global.AMQAppRuntime = Object.freeze({ createRuntime });
})(window);
