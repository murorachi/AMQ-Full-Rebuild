/* Coordinates dataset validation, shared application state, and normalized errors. */
(function (global) {
  "use strict";

  const allowedStatuses = new Set(["not-loaded", "loading", "loaded", "partial", "empty", "failed"]);

  function createController(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const store = deps.stateStore || (global.AMQCore && global.AMQCore.state);
    const validator = deps.validator || global.AMQData;
    const errors = deps.errors || (global.AMQCore && global.AMQCore.errors);
    const catalogFactory = typeof deps.catalogFactory === "function" ? deps.catalogFactory : null;
    let catalog = null;
    if (!store || typeof store.update !== "function" || typeof store.getState !== "function") {
      throw new TypeError("data load controller requires a state store");
    }
    if (!validator || typeof validator.validateRecords !== "function") {
      throw new TypeError("data load controller requires a dataset validator");
    }
    if (!errors || typeof errors.createError !== "function" || typeof errors.fromException !== "function") {
      throw new TypeError("data load controller requires the shared error contract");
    }

    let generation = 0;

    function snapshot() { return store.getState(); }

    function begin() {
      generation += 1;
      catalog = null;
      store.update({ dataStatus: "loading", dataError: null, dataInputCount: 0, dataValidCount: 0, dataRejectedCount: 0 });
      return generation;
    }

    function accept(rawRecords, requestGeneration) {
      if (requestGeneration !== undefined && requestGeneration !== generation) {
        return Object.freeze({ accepted: false, stale: true, state: snapshot(), result: null });
      }
      let result;
      try {
        result = validator.validateRecords(rawRecords);
      } catch (error) {
        const failed = fail(error, { code: "DATA_VALIDATION_FAILED", message: "曲庫資料驗證程序發生錯誤", generation: requestGeneration });
        return Object.freeze({ accepted: failed.accepted, stale: failed.stale === true, state: failed.state, result: null, error: failed.error || null });
      }
      let nextCatalog = null;
      if (result.status !== "failed" && catalogFactory) {
        try {
          nextCatalog = catalogFactory(result.records);
        } catch (error) {
          const failed = fail(error, { code: "DATA_CATALOG_BUILD_FAILED", category: "data", message: "曲庫查詢索引建立失敗", retryable: false, generation: requestGeneration });
          return Object.freeze({ accepted: failed.accepted, stale: failed.stale === true, state: failed.state, result: null, catalog: null, error: failed.error || null });
        }
      }
      const dataError = result.status === "failed"
        ? errors.createError({ code: result.errors[0] && result.errors[0].code || "DATA_INVALID", category: "data", message: result.errors[0] && result.errors[0].message || "曲庫資料無法使用", retryable: false, details: { inputCount: result.inputCount, rejectedCount: result.rejectedCount } })
        : result.status === "partial"
          ? errors.createError({ code: "DATA_PARTIAL", category: "data", message: "部分曲庫記錄未通過驗證", retryable: false, details: { inputCount: result.inputCount, validCount: result.validCount, rejectedCount: result.rejectedCount } })
          : null;
      catalog = nextCatalog;
      store.update({
        dataStatus: result.status,
        dataError,
        dataInputCount: result.inputCount,
        dataValidCount: result.validCount,
        dataRejectedCount: result.rejectedCount
      });
      return Object.freeze({ accepted: true, stale: false, state: snapshot(), result, catalog });
    }

    function fail(cause, options) {
      const settings = options && typeof options === "object" ? options : {};
      if (settings.generation !== undefined && settings.generation !== generation) {
        return Object.freeze({ accepted: false, stale: true, state: snapshot(), error: null });
      }
      const error = cause && cause.name === "AMQError" && typeof cause.code === "string"
        ? cause
        : errors.fromException(cause, { code: settings.code || "DATA_LOAD_FAILED", category: "data", message: settings.message || (cause && cause.message) || "曲庫載入失敗", retryable: settings.retryable === true, details: settings.details });
      generation += 1;
      catalog = null;
      store.update({ dataStatus: "failed", dataError: error, dataInputCount: 0, dataValidCount: 0, dataRejectedCount: 0 });
      return Object.freeze({ accepted: true, stale: false, state: snapshot(), error });
    }

    function reset() {
      generation += 1;
      catalog = null;
      store.update({ dataStatus: "not-loaded", dataError: null, dataInputCount: 0, dataValidCount: 0, dataRejectedCount: 0 });
      return snapshot();
    }

    function isCurrent(requestGeneration) { return requestGeneration === generation; }

    return Object.freeze({ begin, accept, fail, reset, snapshot, catalogSnapshot: () => catalog, isCurrent, get generation() { return generation; }, allowedStatuses: Object.freeze([...allowedStatuses]) });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.loadState = { createController, allowedStatuses: Object.freeze([...allowedStatuses]) };
})(window);
