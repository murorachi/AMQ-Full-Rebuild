/* Chinese title lookup adapter based on the pinned V82.x reference data contracts. */
(function (global) {
  "use strict";
  const VERSION = "amq-chinese-title-provider-v1";
  const CACHE_DB = "amqChineseTitleProviderV1";
  const CACHE_STORE = "maps";
  const CACHE_KEY = "merged-map-v1";
  const CACHE_TTL_MS = 7 * 24 * 60 * 60 * 1000;
  const URLS = Object.freeze({
    anilist: "https://cdn.jsdelivr.net/gh/soruly/anilist-chinese@763fcd7e368f36bab437b18806b548ca42176892/anilist-chinese.json",
    bangumi: "https://cdn.jsdelivr.net/gh/bangumi-data/bangumi-data@bae940f6116ae4b93c73a711827056faaf23957a/dist/data.json",
    opencc: "https://cdn.jsdelivr.net/npm/opencc-js@1.4.2/dist/umd/full.js"
  });

  function clean(value) { return typeof value === "string" ? value.trim() : ""; }
  function unique(values) {
    const result = [], seen = new Set();
    for (const value of values) {
      const text = clean(value);
      if (!text) continue;
      const key = text.normalize("NFKC").toLocaleLowerCase("und");
      if (!seen.has(key)) { seen.add(key); result.push(text); }
    }
    return result;
  }
  function siteIds(entry) {
    const ids = { mal: "", anilist: "", vndb: "", ann: "" };
    for (const site of Array.isArray(entry && entry.sites) ? entry.sites : []) {
      const name = clean(site && site.site).toLowerCase();
      const id = clean(site && site.id);
      if (!id) continue;
      if (["myanimelist", "mal"].includes(name)) ids.mal = ids.mal || id;
      else if (name === "anilist") ids.anilist = ids.anilist || id;
      else if (name === "vndb") ids.vndb = ids.vndb || id.toLowerCase();
      else if (["anime-news-network", "animenewsnetwork", "ann"].includes(name)) ids.ann = ids.ann || id;
    }
    return ids;
  }
  function translatedTitles(entry) {
    const translate = entry && entry.titleTranslate && typeof entry.titleTranslate === "object" ? entry.titleTranslate : {};
    const traditional = [translate["zh-Hant"], translate["zh-TW"], translate["zh-Hant-HK"]].flatMap(v => Array.isArray(v) ? v : [v]);
    const simplified = [translate["zh-Hans"], translate["zh-CN"], translate["zh"]].flatMap(v => Array.isArray(v) ? v : [v]);
    return { preferred: unique([...traditional, ...simplified, entry && entry.name_cn]), all: unique([...traditional, ...simplified, entry && entry.name_cn]) };
  }
  function parseAniListMap(payload) {
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw new TypeError("AniList Chinese map must be an object keyed by AniList ID");
    const result = new Map();
    for (const [id, value] of Object.entries(payload)) {
      if (!/^\d+$/.test(id)) continue;
      const titles = typeof value === "string" ? [value] : value && typeof value === "object"
        ? [value.title, value.name, value.chinese, value.zh, value["zh-Hans"], value["zh-Hant"]].flatMap(v => Array.isArray(v) ? v : [v]) : [];
      const values = unique(titles);
      if (values.length) result.set(id, values);
    }
    if (!result.size) throw new TypeError("AniList Chinese map contains no valid ID/title entries");
    return result;
  }
  function parseBangumi(payload) {
    if (!Array.isArray(payload)) throw new TypeError("Bangumi data must be an array");
    const byMal = new Map(), byVndb = new Map(), byAnn = new Map(), malToAniList = new Map(), vndbToAniList = new Map(), annToAniList = new Map();
    let matched = 0;
    for (const entry of payload) {
      if (!entry || typeof entry !== "object") continue;
      const ids = siteIds(entry);
      const titles = translatedTitles(entry);
      const row = { title: titles.preferred[0] || titles.all[0] || "", aliases: titles.all };
      if (ids.mal) { byMal.set(ids.mal, row); matched++; }
      if (ids.vndb) byVndb.set(ids.vndb, row);
      if (ids.ann) byAnn.set(ids.ann, row);
      if (ids.mal && ids.anilist) malToAniList.set(ids.mal, ids.anilist);
      if (ids.vndb && ids.anilist) vndbToAniList.set(ids.vndb, ids.anilist);
      if (ids.ann && ids.anilist) annToAniList.set(ids.ann, ids.anilist);
    }
    if (!matched && !byVndb.size && !byAnn.size) throw new TypeError("Bangumi data contains no usable MyAnimeList/VNDB/ANN title mappings");
    return { byMal, byVndb, byAnn, malToAniList, vndbToAniList, annToAniList };
  }
  function toPlainMap(map) { return Object.fromEntries([...map.entries()].map(([key, value]) => [key, value])); }
  function serializeMaps(maps, savedAt) {
    return { version: 1, savedAt, byMal: toPlainMap(maps.byMal), byVndb: toPlainMap(maps.byVndb), byAnn: toPlainMap(maps.byAnn || new Map()), malToAniList: toPlainMap(maps.malToAniList), vndbToAniList: toPlainMap(maps.vndbToAniList), annToAniList: toPlainMap(maps.annToAniList || new Map()), anilist: toPlainMap(maps.anilist) };
  }
  function deserializeMaps(value) {
    if (!value || value.version !== 1 || !value.byMal || !value.byVndb || !value.malToAniList || !value.vndbToAniList || !value.anilist) return null;
    return { byMal: new Map(Object.entries(value.byMal)), byVndb: new Map(Object.entries(value.byVndb)), byAnn: new Map(Object.entries(value.byAnn || {})), malToAniList: new Map(Object.entries(value.malToAniList)), vndbToAniList: new Map(Object.entries(value.vndbToAniList)), annToAniList: new Map(Object.entries(value.annToAniList || {})), anilist: new Map(Object.entries(value.anilist)) };
  }
  function openDatabase(indexedDB) {
    return new Promise((resolve, reject) => {
      if (!indexedDB || typeof indexedDB.open !== "function") { reject(new Error("indexeddb-unavailable")); return; }
      let request;
      try { request = indexedDB.open(CACHE_DB, 1); } catch (error) { reject(error); return; }
      request.onupgradeneeded = () => { if (!request.result.objectStoreNames.contains(CACHE_STORE)) request.result.createObjectStore(CACHE_STORE); };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error("indexeddb-open-failed"));
    });
  }
  async function idbGet(indexedDB) {
    const db = await openDatabase(indexedDB);
    try { return await new Promise((resolve, reject) => { const tx = db.transaction(CACHE_STORE, "readonly"), req = tx.objectStore(CACHE_STORE).get(CACHE_KEY); req.onsuccess = () => resolve(req.result || null); req.onerror = () => reject(req.error || new Error("cache-read-failed")); }); }
    finally { db.close(); }
  }
  async function idbSet(indexedDB, value) {
    const db = await openDatabase(indexedDB);
    try { return await new Promise((resolve, reject) => { const tx = db.transaction(CACHE_STORE, "readwrite"); tx.objectStore(CACHE_STORE).put(value, CACHE_KEY); tx.oncomplete = () => resolve(true); tx.onerror = tx.onabort = () => reject(tx.error || new Error("cache-write-failed")); }); }
    finally { db.close(); }
  }
  function abortError() { const error = new Error("Chinese title lookup cancelled"); error.name = "AbortError"; return error; }
  function createChineseTitleProvider(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const fetcher = deps.fetch || global.fetch;
    const AbortControllerCtor = deps.AbortController || global.AbortController;
    const indexedDB = Object.prototype.hasOwnProperty.call(deps, "indexedDB") ? deps.indexedDB : global.indexedDB;
    const urls = Object.freeze({ ...URLS, ...(deps.urls || {}) });
    const now = typeof deps.now === "function" ? deps.now : Date.now;
    const timeoutMs = Number.isFinite(deps.timeoutMs) ? Math.max(100, deps.timeoutMs) : 15000;
    let maps = null, inFlight = null, status = "idle", lastError = "", lastLoadedAt = 0, disposed = false;
    const converter = typeof deps.convertToTraditional === "function" ? deps.convertToTraditional : value => value;

    async function loadConverter() { return converter; }
    async function fetchJson(url, signal) {
      if (typeof fetcher !== "function") throw new Error("fetch-unavailable");
      if (signal && signal.aborted) throw abortError();
      if (typeof AbortControllerCtor !== "function") throw new Error("abort-controller-unavailable");
      const controller = new AbortControllerCtor();
      let timer;
      const abort = () => controller.abort();
      if (signal) signal.addEventListener("abort", abort, { once: true });
      timer = setTimeout(() => controller.abort(), timeoutMs);
      try {
        const response = await fetcher(url, { signal: controller.signal, headers: { Accept: "application/json" } });
        if (!response || response.ok !== true) throw new Error(`http-${response && response.status || "failed"}`);
        return await response.json();
      } catch (error) {
        if (signal && signal.aborted) throw abortError();
        if (controller.signal.aborted) throw new Error("request-timeout");
        throw error;
      } finally { clearTimeout(timer); if (signal) signal.removeEventListener("abort", abort); }
    }
    function traditionalize(values, convert) {
      return unique(values.map(value => { try { return convert(value); } catch (_) { return value; } }));
    }
    function buildMaps(anilistPayload, bangumiPayload, convert) {
      const anilist = anilistPayload && typeof anilistPayload === "object" && !Array.isArray(anilistPayload) && Object.keys(anilistPayload).length
        ? parseAniListMap(anilistPayload) : new Map();
      const bangumi = parseBangumi(bangumiPayload);
      const attachAniList = (row, id) => {
        const titles = anilist.get(String(id || "")) || [];
        const aliases = traditionalize([...row.aliases, ...titles], convert);
        return { title: traditionalize([row.title, ...titles], convert)[0] || "", aliases };
      };
      for (const [mal, row] of bangumi.byMal) bangumi.byMal.set(mal, attachAniList(row, bangumi.malToAniList.get(mal)));
      for (const [vndb, row] of bangumi.byVndb) bangumi.byVndb.set(vndb, attachAniList(row, bangumi.vndbToAniList.get(vndb)));
      for (const [ann, row] of bangumi.byAnn) bangumi.byAnn.set(ann, attachAniList(row, bangumi.annToAniList.get(ann)));
      return { ...bangumi, anilist };
    }
    async function readCached() {
      try {
        if (deps.cache && typeof deps.cache.get === "function") return await deps.cache.get();
        return await idbGet(indexedDB);
      } catch (_) { return null; }
    }
    async function writeCached(value) {
      if (deps.cache && typeof deps.cache.set === "function") { try { await deps.cache.set(value); } catch (_) {} return; }
      try { await idbSet(indexedDB, value); } catch (_) { /* Cache is optional; do not fail a valid lookup. */ }
    }
    async function load(options) {
      const opts = options && typeof options === "object" ? options : {};
      if (disposed) throw new Error("provider-disposed");
      if (opts.signal && opts.signal.aborted) throw abortError();
      if (maps && !opts.force) return Object.freeze({ ok: true, cached: true, count: maps.byMal.size + maps.byVndb.size, status });
      if (inFlight && !opts.force && !opts.signal) return inFlight;
      status = "loading"; lastError = "";
      const task = (async () => {
        const cached = !opts.force ? await readCached() : null;
        if (opts.signal && opts.signal.aborted) throw abortError();
        if (cached && now() - Number(cached.savedAt || 0) < CACHE_TTL_MS) {
          const decoded = deserializeMaps(cached.maps);
          if (decoded) { maps = decoded; lastLoadedAt = Number(cached.savedAt) || now(); status = "ready-cache"; return Object.freeze({ ok: true, cached: true, count: maps.byMal.size + maps.byVndb.size, status }); }
        }
        const results = await Promise.allSettled([fetchJson(urls.anilist, opts.signal), fetchJson(urls.bangumi, opts.signal)]);
        if (opts.signal && opts.signal.aborted) throw abortError();
        const anilistResult = results[0], bangumiResult = results[1];
        if (bangumiResult.status === "rejected") {
          if (cached && deserializeMaps(cached.maps)) { maps = deserializeMaps(cached.maps); status = "ready-stale"; lastError = "crosswalk-source-unavailable"; return Object.freeze({ ok: true, cached: true, stale: true, count: maps.byMal.size + maps.byVndb.size, status }); }
          throw new Error(`all-title-sources-failed:${anilistResult.reason && anilistResult.reason.message}/${bangumiResult.reason && bangumiResult.reason.message}`);
        }
        // The AniList file is keyed by AniList ID, so a Bangumi crosswalk is required to associate it with MAL/VNDB records.
        const parsedAniList = anilistResult.status === "fulfilled" ? anilistResult.value : {};
        const parsedBangumi = bangumiResult.value;
        const converterFn = await loadConverter();
        if (opts.signal && opts.signal.aborted) throw abortError();
        const next = buildMaps(parsedAniList, parsedBangumi, converterFn);
        if (disposed) throw new Error("provider-disposed");
        maps = next; lastLoadedAt = now(); status = results.every(item => item.status === "fulfilled") ? "ready" : "ready-partial";
        const cacheValue = { savedAt: lastLoadedAt, maps: serializeMaps(next, lastLoadedAt) };
        await writeCached(cacheValue);
        return Object.freeze({ ok: true, cached: false, partial: status === "ready-partial", count: maps.byMal.size + maps.byVndb.size, status });
      })().catch(error => {
        if (error && error.name === "AbortError") { status = maps ? "ready" : "idle"; throw error; }
        lastError = error && error.message || "title-provider-failed";
        status = maps ? "ready-stale" : "error";
        throw error;
      }).finally(() => { if (inFlight === task) inFlight = null; });
      if (!opts.signal) inFlight = task;
      return task;
    }
    function getRow(record) {
      if (!maps || !record || typeof record !== "object") return null;
      if (record.source === "AMQ") return maps.byAnn.get(String(record.animeAnnId || record.artworkRef && record.artworkRef.annId || "")) || null;
      if (record.source === "EMQ") return maps.byVndb.get(clean(record.animeVndbId).toLowerCase()) || null;
      return null;
    }
    function getTitle(record) { const row = getRow(record); return row ? row.title : ""; }
    function getAliases(record) { const row = getRow(record); return row ? row.aliases.slice() : []; }
    function getAniListId(record) {
      if (!maps || !record || record.source !== "AMQ") return "";
      const annId = String(record.animeAnnId || record.artworkRef && record.artworkRef.annId || "").trim();
      return annId ? maps.annToAniList.get(annId) || "" : "";
    }
    function getStatus() { return Object.freeze({ version: VERSION, status, lastError, lastLoadedAt, ready: Boolean(maps), disposed }); }
    function dispose() { if (disposed) return false; disposed = true; maps = null; return true; }
    return Object.freeze({ version: VERSION, urls, load, getTitle, getAliases, getAniListId, getStatus, dispose, parseAniListMap, parseBangumi });
  }
  global.AMQData = global.AMQData || {};
  global.AMQData.chineseTitleProvider = Object.freeze({ version: VERSION, urls: URLS, createChineseTitleProvider, parseAniListMap, parseBangumi });
})(window);
