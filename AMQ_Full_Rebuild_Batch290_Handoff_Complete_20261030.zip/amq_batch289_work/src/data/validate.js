/* Validator for the new internal song-record contract; it does not map legacy source fields. */
(function (global) {
  "use strict";

  const identity = global.AMQData && global.AMQData.identity;
  if (!identity || typeof identity.createIdentity !== "function") {
    throw new Error("data identity module must load before validator");
  }
  const isIdentifier = identity.isIdentifier;

  function issue(code, field, message) {
    return Object.freeze({ code, field, message });
  }

  function validateRecord(record) {
    const issues = [];
    if (!record || typeof record !== "object" || Array.isArray(record)) {
      return [issue("RECORD_NOT_OBJECT", "$", "歌曲記錄必須是物件")];
    }
    if (!isIdentifier(record.id)) issues.push(issue("INVALID_ID", "id", "id 必須是非空字串或有限數字"));
    if (typeof record.title !== "string" || record.title.trim().length === 0) {
      issues.push(issue("INVALID_TITLE", "title", "title 必須是非空字串"));
    }
    if (record.aliases !== undefined && (!Array.isArray(record.aliases) || record.aliases.some(value => typeof value !== "string"))) {
      issues.push(issue("INVALID_ALIASES", "aliases", "aliases 若存在，必須是字串陣列"));
    }
    for (const field of ["artistAliases", "animeAliases"]) {
      if (record[field] !== undefined && (!Array.isArray(record[field]) || record[field].some(value => typeof value !== "string"))) {
        issues.push(issue("INVALID_ALIASES", field, `${field} 若存在，必須是字串陣列`));
      }
    }
    if (record.animeId !== undefined && record.animeId !== null && !isIdentifier(record.animeId)) {
      issues.push(issue("INVALID_ANIME_ID", "animeId", "animeId 必須是非空字串、有限數字或 null"));
    }
    if (record.animeTitle !== undefined && record.animeTitle !== null && typeof record.animeTitle !== "string") {
      issues.push(issue("INVALID_ANIME_TITLE", "animeTitle", "animeTitle 必須是字串或 null"));
    }
    if (record.type !== undefined && record.type !== null && typeof record.type !== "string") {
      issues.push(issue("INVALID_TYPE", "type", "type 必須是字串或 null"));
    }
    if (record.source !== undefined && (typeof record.source !== "string" || record.source.trim().length === 0)) {
      issues.push(issue("INVALID_SOURCE", "source", "source 若存在，必須是非空字串"));
    }
    if (record.audioCandidates !== undefined) {
      if (!Array.isArray(record.audioCandidates)) {
        issues.push(issue("INVALID_AUDIO_CANDIDATES", "audioCandidates", "audioCandidates 必須是陣列"));
      } else {
        const seenAudioUrls = new Set();
        record.audioCandidates.forEach((candidate, index) => {
          if (!candidate || typeof candidate !== "object" || Array.isArray(candidate)
            || typeof candidate.url !== "string" || !candidate.url.trim()
            || typeof candidate.source !== "string" || !candidate.source.trim()
            || candidate.kind !== "audio") {
            issues.push(issue("INVALID_AUDIO_CANDIDATE", `audioCandidates[${index}]`, "音源候選必須包含非空 url/source 並且 kind 為 audio"));
            return;
          }
          if (seenAudioUrls.has(candidate.url)) issues.push(issue("DUPLICATE_AUDIO_CANDIDATE", `audioCandidates[${index}].url`, "同一首歌的音源候選網址不可重複"));
          seenAudioUrls.add(candidate.url);
        });
      }
    }
    return issues;
  }

  function validateRecords(records) {
    if (!Array.isArray(records)) {
      return Object.freeze({
        status: "failed", ok: false, inputCount: 0, validCount: 0, rejectedCount: 0,
        records: Object.freeze([]), rejected: Object.freeze([]),
        errors: Object.freeze([issue("DATASET_NOT_ARRAY", "$", "曲庫資料必須是陣列")])
      });
    }

    const valid = [];
    const rejected = [];
    const errors = [];
    const seenIds = new Map();

    records.forEach((record, index) => {
      const recordIssues = validateRecord(record);
      if (recordIssues.length === 0) {
        const source = typeof record.source === "string" ? record.source : "";
        const key = identity.createIdentity(source, record.id);
        if (seenIds.has(key)) {
          recordIssues.push(issue("DUPLICATE_ID", "id", `同一來源的 id 與第 ${seenIds.get(key) + 1} 筆有效記錄重複`));
        } else {
          seenIds.set(key, index);
        }
      }
      if (recordIssues.length) {
        const entry = Object.freeze({ index, record, issues: Object.freeze(recordIssues) });
        rejected.push(entry);
        recordIssues.forEach(item => errors.push(Object.freeze({ index, ...item })));
      } else {
        // Keep source object identity and values intact; normalization belongs to a separate adapter.
        valid.push(record);
      }
    });

    const status = records.length === 0 ? "empty" : valid.length === 0 ? "failed" : rejected.length ? "partial" : "loaded";
    return Object.freeze({
      status,
      ok: status === "loaded" || status === "empty",
      inputCount: records.length,
      validCount: valid.length,
      rejectedCount: rejected.length,
      records: Object.freeze(valid),
      rejected: Object.freeze(rejected),
      errors: Object.freeze(errors)
    });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.validateRecord = validateRecord;
  global.AMQData.validateRecords = validateRecords;
})(window);
