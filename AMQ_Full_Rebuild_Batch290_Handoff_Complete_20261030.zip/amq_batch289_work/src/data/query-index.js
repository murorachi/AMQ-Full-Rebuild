/* Rebuildable search/filter index over normalized internal song records. */
(function (global) {
  "use strict";

  const ALLOWED_CRITERIA = new Set(["query", "source", "type", "workKind", "animeId", "animeYearFrom", "animeYearTo", "includeUnknownYear", "animeType", "animeDecade", "watchStatus", "familiarityLevel", "tagId", "limit", "offset", "sortBy", "sortDirection"]);
  const SORT_FIELDS = new Set(["title", "artist", "animeTitle", "type", "source", "id", "number", "difficulty", "animeYear"]);
  const SEARCH_FIELDS = ["title", "artist", "animeTitle", "animeAlternateTitle", "alternateTitle", "aliases", "artistAliases", "animeAliases"];

  function normalizeText(value) {
    return String(value == null ? "" : value)
      .normalize("NFKC")
      .toLocaleLowerCase("und")
      .replace(/\s+/gu, " ")
      .trim();
  }

  const identity = global.AMQData && global.AMQData.identity;
  if (!identity || typeof identity.createIdentity !== "function") {
    throw new Error("data identity module must load before query index");
  }

  function valuesFor(record, field) {
    if (["aliases", "artistAliases", "animeAliases"].includes(field)) return Array.isArray(record[field]) ? record[field] : [];
    const value = record[field];
    return typeof value === "string" && value.trim() ? [value] : [];
  }

  function cloneRecord(record) {
    const copy = { ...record };
    for (const field of ["aliases", "artistAliases", "animeAliases", "tagIds"]) {
      if (Array.isArray(record[field])) copy[field] = Object.freeze(record[field].slice());
    }
    return Object.freeze(copy);
  }

  function asFilterSet(value, field) {
    if (value === undefined || value === null || value === "") return null;
    const list = Array.isArray(value) ? value : [value];
    if (list.some(item => typeof item !== "string" || !item.trim())) {
      throw new TypeError(`${field} filter must be a non-empty string or an array of non-empty strings`);
    }
    return new Set(list.map(item => item.trim()));
  }

  function compareSortValues(left, right, field) {
    const a = left[field];
    const b = right[field];
    const aMissing = a === undefined || a === null || a === "";
    const bMissing = b === undefined || b === null || b === "";
    if (aMissing || bMissing) return aMissing === bMissing ? 0 : aMissing ? 1 : -1;
    if (["number", "difficulty", "animeYear"].includes(field)) {
      const aNumber = Number(a);
      const bNumber = Number(b);
      if (Number.isFinite(aNumber) && Number.isFinite(bNumber)) return aNumber < bNumber ? -1 : aNumber > bNumber ? 1 : 0;
    }
    if (field === "id" && typeof a === "number" && typeof b === "number") return a < b ? -1 : a > b ? 1 : 0;
    const aText = normalizeText(field === "id" ? `${typeof a}:${String(a)}` : a);
    const bText = normalizeText(field === "id" ? `${typeof b}:${String(b)}` : b);
    return aText < bText ? -1 : aText > bText ? 1 : 0;
  }

  const FACET_FIELDS = new Set(["source", "type", "workKind", "animeId", "animeTitle", "artist", "animeType", "animeDecade", "watchStatus", "familiarityLevel", "tagId"]);
  const FILTER_CRITERIA = new Set(["query", "source", "type", "workKind", "animeId", "animeYearFrom", "animeYearTo", "includeUnknownYear", "animeType", "animeDecade", "watchStatus", "familiarityLevel", "tagId"]);

  function createCatalog(records) {
    if (!Array.isArray(records)) throw new TypeError("catalog records must be an array");

    const indexed = [];
    const seen = new Set();
    records.forEach((raw, ordinal) => {
      if (!raw || typeof raw !== "object" || Array.isArray(raw)) throw new TypeError(`record at index ${ordinal} must be an object`);
      if ((typeof raw.id !== "string" || !raw.id.trim()) && (typeof raw.id !== "number" || !Number.isFinite(raw.id))) {
        throw new TypeError(`record at index ${ordinal} must have a valid id`);
      }
      if (typeof raw.title !== "string" || !raw.title.trim()) throw new TypeError(`record at index ${ordinal} must have a non-empty title`);
      const source = typeof raw.source === "string" ? raw.source : "";
      const key = identity.createIdentity(source, raw.id);
      if (seen.has(key)) throw new TypeError(`duplicate catalog identity: ${source || "(no source)"}/${String(raw.id)}`);
      seen.add(key);
      const record = cloneRecord(raw);
      const searchable = SEARCH_FIELDS.flatMap(field => valuesFor(record, field))
        .map(normalizeText).filter(Boolean);
      indexed.push(Object.freeze({ record, ordinal, source, idKey: identity.identifierKey(record.id), searchable }));
    });

    const snapshot = Object.freeze(indexed.slice());

    function validateFilterCriteria(criteria, allowed = ALLOWED_CRITERIA) {
      const options = criteria == null ? {} : criteria;
      if (typeof options !== "object" || Array.isArray(options)) throw new TypeError("search criteria must be an object");
      for (const key of Object.keys(options)) {
        if (!allowed.has(key)) throw new TypeError(`unknown search criterion: ${key}`);
      }
      const query = normalizeText(options.query);
      const sourceFilter = asFilterSet(options.source, "source");
      const typeFilter = asFilterSet(options.type, "type");
      const kindFilter = asFilterSet(options.workKind, "workKind");
      const hasAnimeId = options.animeId !== undefined && options.animeId !== null;
      if (hasAnimeId && !((typeof options.animeId === "string" && options.animeId.trim()) || (typeof options.animeId === "number" && Number.isFinite(options.animeId)))) {
        throw new TypeError("animeId filter must be a non-empty string or finite number");
      }
      for (const field of ["animeYearFrom", "animeYearTo", "animeDecade", "familiarityLevel"]) {
        if (options[field] !== undefined && options[field] !== null && options[field] !== "" && !Number.isFinite(Number(options[field]))) throw new TypeError(`${field} filter must be numeric`);
      }
      if (options.includeUnknownYear !== undefined && typeof options.includeUnknownYear !== "boolean") throw new TypeError("includeUnknownYear must be boolean");
      if (options.familiarityLevel !== undefined && options.familiarityLevel !== null && options.familiarityLevel !== "" && (!Number.isInteger(Number(options.familiarityLevel)) || Number(options.familiarityLevel) < 0 || Number(options.familiarityLevel) > 4)) throw new RangeError("familiarityLevel must be between 0 and 4");
      if (options.animeDecade !== undefined && options.animeDecade !== null && options.animeDecade !== "" && Number(options.animeDecade) % 10 !== 0) throw new RangeError("animeDecade must be a decade boundary");
      const animeTypeFilter = asFilterSet(options.animeType, "animeType");
      const watchStatusFilter = asFilterSet(options.watchStatus, "watchStatus");
      const tagFilter = asFilterSet(options.tagId, "tagId");
      return { options, query, sourceFilter, typeFilter, kindFilter, hasAnimeId, animeTypeFilter, watchStatusFilter, tagFilter };
    }

    function filterItems(criteria, allowed = ALLOWED_CRITERIA) {
      const { options, query, sourceFilter, typeFilter, kindFilter, hasAnimeId, animeTypeFilter, watchStatusFilter, tagFilter } = validateFilterCriteria(criteria, allowed);
      const matches = [];
      for (const item of snapshot) {
        const song = item.record;
        if (sourceFilter && !sourceFilter.has(item.source)) continue;
        if (typeFilter && !typeFilter.has(song.type)) continue;
        if (kindFilter && !kindFilter.has(song.workKind)) continue;
        if (hasAnimeId && identity.identifierKey(song.animeId) !== identity.identifierKey(options.animeId)) continue;
        if (options.animeYearFrom != null || options.animeYearTo != null) {
          const year = song.animeYear == null || song.animeYear === "" ? NaN : Number(song.animeYear);
          if (!Number.isFinite(year)) { if (options.includeUnknownYear === false) continue; }
          else if (options.animeYearFrom != null && year < Number(options.animeYearFrom) || options.animeYearTo != null && year > Number(options.animeYearTo)) continue;
        }
        if (animeTypeFilter && !animeTypeFilter.has(String(song.animeType == null ? "" : song.animeType).trim())) continue;
        if (options.animeDecade != null && options.animeDecade !== "") {
          const year = Number(song.animeYear);
          if (!Number.isFinite(year) || Math.floor(year / 10) * 10 !== Number(options.animeDecade)) continue;
        }
        if (watchStatusFilter && !watchStatusFilter.has(String(song.watchStatus == null ? "none" : song.watchStatus))) continue;
        if (tagFilter && (!Array.isArray(song.tagIds) || !song.tagIds.some(id => tagFilter.has(String(id))))) continue;
        if (options.familiarityLevel != null && options.familiarityLevel !== "" && Number(song.familiarityLevel) !== Number(options.familiarityLevel)) continue;
        if (query && !item.searchable.some(field => field.includes(query))) continue;
        matches.push(item);
      }
      return matches;
    }

    function search(criteria) {
      const options = criteria == null ? {} : criteria;
      const matches = filterItems(options);
      const offset = options.offset === undefined ? 0 : options.offset;
      const limit = options.limit === undefined ? 100 : options.limit;
      if (!Number.isSafeInteger(offset) || offset < 0) throw new RangeError("offset must be a non-negative safe integer");
      if (!Number.isSafeInteger(limit) || limit < 0 || limit > 10000) throw new RangeError("limit must be an integer between 0 and 10000");
      const sortBy = options.sortBy === undefined || options.sortBy === null || options.sortBy === "" ? null : options.sortBy;
      const sortDirection = options.sortDirection === undefined ? "asc" : options.sortDirection;
      if (sortBy !== null && (typeof sortBy !== "string" || !SORT_FIELDS.has(sortBy))) {
        throw new TypeError(`sortBy must be one of: ${Array.from(SORT_FIELDS).join(", ")}`);
      }
      if (sortBy === null && options.sortDirection !== undefined) throw new TypeError("sortDirection requires sortBy");
      if (sortDirection !== "asc" && sortDirection !== "desc") throw new TypeError("sortDirection must be asc or desc");
      if (sortBy !== null) {
        const direction = sortDirection === "desc" ? -1 : 1;
        matches.sort((a, b) => {
          const comparison = compareSortValues(a.record, b.record, sortBy);
          if (comparison === 0) return a.ordinal - b.ordinal;
          const aMissing = a.record[sortBy] === undefined || a.record[sortBy] === null || a.record[sortBy] === "";
          const bMissing = b.record[sortBy] === undefined || b.record[sortBy] === null || b.record[sortBy] === "";
          if (aMissing || bMissing) return comparison;
          return comparison * direction;
        });
      }
      return Object.freeze({ total: matches.length, offset, limit, records: Object.freeze(matches.slice(offset, offset + limit).map(item => item.record)) });
    }

    function groupBy(field, criteria) {
      if (typeof field !== "string" || !FACET_FIELDS.has(field)) {
        throw new TypeError(`groupBy field must be one of: ${Array.from(FACET_FIELDS).join(", ")}`);
      }
      const matches = filterItems(criteria, FILTER_CRITERIA);
      const groups = new Map();
      for (const item of matches) {
        const value = field === "source" ? item.source : item.record[field];
        if (value === undefined || value === null || value === "") continue;
        const key = identity.identifierKey(value);
        const current = groups.get(key);
        if (current) current.count += 1;
        else groups.set(key, { value, label: field === "animeDecade" ? `${value} 年代` : String(value), count: 1, normalizedLabel: normalizeText(value), key });
      }
      const result = [...groups.values()]
        .sort((a, b) => b.count - a.count || (a.normalizedLabel < b.normalizedLabel ? -1 : a.normalizedLabel > b.normalizedLabel ? 1 : a.key < b.key ? -1 : a.key > b.key ? 1 : 0))
        .map(({ value, label, count }) => Object.freeze({ value, label, count }));
      return Object.freeze({ total: matches.length, groups: Object.freeze(result) });
    }

    return Object.freeze({ size: snapshot.length, search, groupBy });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.queryIndex = Object.freeze({ createCatalog, normalizeText });
})(window);
