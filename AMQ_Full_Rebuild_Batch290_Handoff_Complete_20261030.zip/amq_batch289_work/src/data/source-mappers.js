/* Explicit mappers for the inspected Library datasets / Candidate382 Stage I schema evidence.
 * This module does not assert Candidate302 compatibility. Audio candidate fields follow only the inspected reference HTML rules.
 */
(function (global) {
  "use strict";

  function requirePositiveId(value, field) {
    if (!Number.isSafeInteger(value) || value <= 0) throw new TypeError(`${field} must be a positive safe integer`);
    return value;
  }
  function requiredText(value, field) {
    if (typeof value !== "string" || value.trim() === "") throw new TypeError(`${field} must be non-empty text`);
    return value;
  }
  function uniqueTexts(...values) {
    const result = [], seen = new Set();
    const visit = value => {
      if (Array.isArray(value)) { for (const item of value) visit(item); return; }
      if (typeof value !== "string") return;
      const text = value.trim();
      if (!text || seen.has(text)) return;
      seen.add(text); result.push(text);
    };
    values.forEach(visit);
    return result;
  }
  function mapAMQWork(row) {
    if (!Array.isArray(row) || row.length !== 7) throw new TypeError("AMQ work row must contain exactly 7 columns");
    return Object.freeze({ id: requirePositiveId(row[0], "AMQ work id"), title: requiredText(row[1] || row[2], "AMQ work title"), alternateTitle: typeof row[2] === "string" ? row[2] : "", annId: Number.isSafeInteger(row[6]) && row[6] > 0 ? row[6] : null, artworkRef: Object.freeze({ kind: "anime", source: "AMQ", id: requirePositiveId(row[0], "AMQ work id"), ...(Number.isSafeInteger(row[6]) && row[6] > 0 ? { annId: row[6] } : {}) }), animeType: typeof row[4] === "string" && row[4].trim() ? row[4].trim() : null, year: Number.isFinite(Number(row[5])) && Number(row[5]) > 0 ? Number(row[5]) : null, source: "AMQ", sourceSchema: "candidate382-stageI-library-data-v1" });
  }
  function createAMQSongMapper(animeRows) {
    if (!Array.isArray(animeRows)) throw new TypeError("AMQ animeRows must be an array");
    const audioCandidates = global.AMQData && global.AMQData.audioCandidates;
    if (!audioCandidates || typeof audioCandidates.createAMQAudioCandidates !== "function") throw new TypeError("AMQ audio candidate resolver must be loaded before source mappers");
    const works = new Map();
    for (const row of animeRows) {
      const work = mapAMQWork(row);
      if (works.has(work.id)) throw new TypeError(`duplicate AMQ work id ${work.id}`);
      works.set(work.id, work);
    }
    return function mapAMQSong(row) {
      if (!Array.isArray(row) || row.length !== 12) throw new TypeError("AMQ song row must contain exactly 12 columns");
      const workId = requirePositiveId(row[0], "AMQ song work id");
      const work = works.get(workId);
      if (!work) throw new TypeError(`AMQ song references unknown work ${workId}`);
      const typeCode = row[2];
      if (!(typeof typeCode === "number" && Number.isFinite(typeCode)) && typeof typeCode !== "string") throw new TypeError("AMQ song type must be a number or string");
      const id = requirePositiveId(row[1], "AMQ song id");
      const title = requiredText(row[4], "AMQ song title");
      const artist = typeof row[5] === "string" ? row[5] : "";
      return Object.freeze({ id, title, artist, animeId: workId, animeTitle: work.title, animeAlternateTitle: work.alternateTitle, animeType: work.animeType, animeYear: work.year, animeAnnId: work.annId, artworkRef: work.artworkRef, type: String(typeCode), number: Number.isFinite(Number(row[3])) ? Number(row[3]) : null, difficulty: Number.isFinite(Number(row[6])) ? Number(row[6]) : null, audioCandidates: audioCandidates.createAMQAudioCandidates(row[9]), source: "AMQ", workKind: "anime", sourceSchema: "candidate382-stageI-library-data-v1" });
    };
  }
  function createEMQSongMapper(worksRows) {
    if (!Array.isArray(worksRows)) throw new TypeError("EMQ worksRows must be an array");
    const audioCandidates = global.AMQData && global.AMQData.audioCandidates;
    if (!audioCandidates || typeof audioCandidates.createEMQAudioCandidates !== "function") throw new TypeError("EMQ audio candidate resolver must be loaded before source mappers");
    const works = new Map();
    for (const row of worksRows) {
      if (!row || typeof row !== "object" || Array.isArray(row)) throw new TypeError("EMQ work must be an object");
      const id = requirePositiveId(row.i, "EMQ work id");
      if (works.has(id)) throw new TypeError(`duplicate EMQ work id ${id}`);
      works.set(id, Object.freeze({ id, title: requiredText(row.t, "EMQ work title"), alternateTitle: typeof row.n === "string" ? row.n : "", artworkRef: Object.freeze({ kind: "visual_novel_game", source: "EMQ", id, ...(typeof row.vndbId === "string" && row.vndbId.trim() ? { vndbId: row.vndbId.trim().toLowerCase() } : {}) }), animeType: null, year: Number.isFinite(Number(row.y)) && Number(row.y) > 0 ? Number(row.y) : null, vndbId: typeof row.vndbId === "string" ? row.vndbId.trim().toLowerCase() : "" }));
    }
    return function mapEMQSong(row) {
      if (!row || typeof row !== "object" || Array.isArray(row)) throw new TypeError("EMQ song must be an object");
      const id = requirePositiveId(row.i, "EMQ song id");
      const workId = requirePositiveId(row.w, "EMQ song work id");
      const work = works.get(workId);
      if (!work) throw new TypeError(`EMQ song references unknown work ${workId}`);
      const title = requiredText(row.t, "EMQ song title");
      const artist = requiredText(row.a, "EMQ song artist");
      const record = { id, title, artist, animeId: workId, animeTitle: work.title, animeAlternateTitle: work.alternateTitle, animeType: work.animeType, animeYear: work.year, animeVndbId: work.vndbId, artworkRef: work.artworkRef, type: typeof row.k === "string" ? row.k : null, number: Number.isFinite(Number(row.o)) ? Number(row.o) : null, difficulty: null, audioCandidates: audioCandidates.createEMQAudioCandidates(row.v), source: "EMQ", workKind: "visual_novel_game", sourceSchema: "candidate382-stageI-library-emq-v1" };
      // Candidate381/V82.x's EMQ reader explicitly builds these suggestion aliases from
      // ta/aa/wa and the song/work alternate labels. Preserve only values actually supplied.
      const titleAliases = uniqueTexts(row.ta, row.n);
      const artistAliases = uniqueTexts(row.aa);
      const animeAliases = uniqueTexts(row.wa, row.wt, row.wn);
      if (titleAliases.length) record.aliases = Object.freeze(titleAliases);
      if (artistAliases.length) record.artistAliases = Object.freeze(artistAliases);
      if (animeAliases.length) record.animeAliases = Object.freeze(animeAliases);
      return Object.freeze(record);
    };
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.sourceMappers = Object.freeze({ mapAMQWork, createAMQSongMapper, createEMQSongMapper });
})(window);
