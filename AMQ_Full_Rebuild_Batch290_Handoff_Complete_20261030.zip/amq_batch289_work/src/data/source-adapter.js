/* Source boundary: reading and mapping are injected; no legacy schema is assumed. */
(function (global) {
  "use strict";

  function createAdapter(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const read = deps.read;
    const mapRecord = deps.mapRecord;
    const errors = deps.errors || (global.AMQCore && global.AMQCore.errors);
    const timeoutMs = deps.timeoutMs === undefined ? 15000 : deps.timeoutMs;

    if (typeof read !== "function") throw new TypeError("source adapter requires read({ signal })");
    if (typeof mapRecord !== "function") throw new TypeError("source adapter requires an explicit mapRecord(raw, index)");
    if (!errors || typeof errors.createError !== "function") throw new TypeError("source adapter requires the shared error contract");
    if (!Number.isFinite(timeoutMs) || timeoutMs < 0) throw new RangeError("timeoutMs must be a non-negative finite number");

    function makeError(code, message, category, retryable, cause) {
      return errors.createError({ code, message, category, retryable, cause });
    }

    async function load(options) {
      const settings = options && typeof options === "object" ? options : {};
      const externalSignal = settings.signal;
      if (externalSignal && externalSignal.aborted) {
        throw makeError("DATA_LOAD_CANCELLED", "曲庫載入已取消", "data", false, externalSignal.reason);
      }

      const controller = new AbortController();
      let timeoutId = null;
      let externalAbortHandler = null;
      let timedOut = false;
      let externallyAborted = false;

      const abortPromise = new Promise((_, reject) => {
        if (externalSignal) {
          externalAbortHandler = () => {
            externallyAborted = true;
            controller.abort(externalSignal.reason);
            reject(makeError("DATA_LOAD_CANCELLED", "曲庫載入已取消", "data", false, externalSignal.reason));
          };
          externalSignal.addEventListener("abort", externalAbortHandler, { once: true });
        }
      });

      const timeoutPromise = new Promise((_, reject) => {
        if (timeoutMs > 0) {
          timeoutId = setTimeout(() => {
            timedOut = true;
            const timeoutError = makeError("DATA_SOURCE_TIMEOUT", `曲庫來源超過 ${timeoutMs} 毫秒仍未回應`, "network", true);
            controller.abort(timeoutError);
            reject(timeoutError);
          }, timeoutMs);
        }
      });

      try {
        const rawRecords = await Promise.race([
          Promise.resolve().then(() => read({ signal: controller.signal })),
          abortPromise,
          timeoutPromise
        ]);
        if (!Array.isArray(rawRecords)) {
          throw makeError("DATA_SOURCE_SHAPE_INVALID", "曲庫來源必須回傳陣列", "data", false);
        }
        let records;
        try {
          records = rawRecords.map((record, index) => mapRecord(record, index));
        } catch (error) {
          throw makeError("DATA_SOURCE_MAPPING_FAILED", "曲庫來源轉換失敗", "data", false, error);
        }
        return Object.freeze({ records, sourceCount: rawRecords.length });
      } catch (error) {
        if (error && error.name === "AMQError") throw error;
        if (timedOut) throw makeError("DATA_SOURCE_TIMEOUT", `曲庫來源超過 ${timeoutMs} 毫秒仍未回應`, "network", true, error);
        if (externallyAborted || (externalSignal && externalSignal.aborted)) {
          throw makeError("DATA_LOAD_CANCELLED", "曲庫載入已取消", "data", false, error);
        }
        throw makeError("DATA_SOURCE_READ_FAILED", "無法讀取曲庫來源", "data", true, error);
      } finally {
        if (timeoutId !== null) clearTimeout(timeoutId);
        if (externalSignal && externalAbortHandler) externalSignal.removeEventListener("abort", externalAbortHandler);
      }
    }

    return Object.freeze({ load, timeoutMs });
  }

  function createCompositeAdapter(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const errors = deps.errors || (global.AMQCore && global.AMQCore.errors);
    if (!errors || typeof errors.createError !== "function") throw new TypeError("composite adapter requires the shared error contract");
    const sources = Array.isArray(deps.sources) ? deps.sources.slice() : [];
    if (!sources.length) throw new TypeError("composite adapter requires at least one source");
    const names = new Set();
    for (const source of sources) {
      if (!source || typeof source !== "object" || typeof source.name !== "string" || !source.name.trim()) {
        throw new TypeError("each composite source requires a non-empty name");
      }
      if (names.has(source.name)) throw new TypeError(`duplicate composite source name: ${source.name}`);
      names.add(source.name);
      if (!source.adapter || typeof source.adapter.load !== "function") {
        throw new TypeError(`composite source ${source.name} requires an adapter`);
      }
    }

    async function load(options) {
      const settings = options && typeof options === "object" ? options : {};
      const externalSignal = settings.signal;
      if (externalSignal && externalSignal.aborted) {
        throw makeCompositeError("DATA_LOAD_CANCELLED", "曲庫載入已取消", false, externalSignal.reason);
      }
      const controller = new AbortController();
      let externalAbortHandler = null;
      let rejectOnAbort = null;
      if (externalSignal) {
        externalAbortHandler = () => {
          const cancellation = makeCompositeError("DATA_LOAD_CANCELLED", "曲庫載入已取消", false, externalSignal.reason);
          controller.abort(cancellation);
          rejectOnAbort(cancellation);
        };
        externalSignal.addEventListener("abort", externalAbortHandler, { once: true });
      }
      try {
        const cancellation = new Promise((_, reject) => { rejectOnAbort = reject; });
        const results = await Promise.race([Promise.all(sources.map(async source => {
          const result = await source.adapter.load({ signal: controller.signal, mode: settings.mode });
          if (!result || !Array.isArray(result.records) || !Number.isSafeInteger(result.sourceCount) || result.sourceCount < 0) {
            throw new TypeError(`composite source ${source.name} returned an invalid adapter result`);
          }
          for (const record of result.records) {
            if (!record || record.source !== source.name) {
              throw new TypeError(`composite source ${source.name} returned a record with mismatched source`);
            }
          }
          return { name: source.name, records: result.records, sourceCount: result.sourceCount };
        })), cancellation]);
        const records = results.flatMap(result => result.records);
        const sourceCounts = Object.freeze(Object.fromEntries(results.map(result => [result.name, result.sourceCount])));
        return Object.freeze({ records: Object.freeze(records), sourceCount: results.reduce((sum, result) => sum + result.sourceCount, 0), sourceCounts });
      } catch (error) {
        controller.abort(error);
        throw error;
      } finally {
        rejectOnAbort = null;
        if (externalSignal && externalAbortHandler) externalSignal.removeEventListener("abort", externalAbortHandler);
      }
    }

    function makeCompositeError(code, message, retryable, cause) {
      return errors.createError({ code, message, category: "data", retryable, cause });
    }

    return Object.freeze({ load, sources: Object.freeze(sources.map(source => source.name)) });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.sourceAdapter = Object.freeze({ createAdapter, createCompositeAdapter });
})(window);
