/* Composes the injected source adapter with the single load-state controller. */
(function (global) {
  "use strict";

  function createRepository(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const adapter = deps.adapter || (global.AMQData && global.AMQData.sourceAdapter);
    const loadState = deps.loadState || (global.AMQData && global.AMQData.loadState);
    const queryIndex = deps.queryIndex || (global.AMQData && global.AMQData.queryIndex);
    if (!adapter || typeof adapter.load !== "function") throw new TypeError("repository requires a source adapter");
    if (!loadState || typeof loadState.createController !== "function") throw new TypeError("repository requires load-state controller factory");
    const controllerDependencies = { ...(deps.controllerDependencies || {}) };
    if (!controllerDependencies.catalogFactory && queryIndex && typeof queryIndex.createCatalog === "function") {
      controllerDependencies.catalogFactory = records => queryIndex.createCatalog(records);
    }
    const controller = deps.controller || loadState.createController(controllerDependencies);
    const errors = deps.errors || (global.AMQCore && global.AMQCore.errors);
    if (!errors || typeof errors.createError !== "function") throw new TypeError("repository requires the shared error contract");
    let active = null;

    function validateSourceResult(result) {
      const invalid = reason => errors.createError({
        code: "DATA_ADAPTER_RESULT_INVALID",
        category: "data",
        message: "曲庫來源回傳結果不符合契約",
        retryable: false,
        details: { reason }
      });
      if (!result || typeof result !== "object" || Array.isArray(result)) throw invalid("result must be an object");
      if (!Array.isArray(result.records)) throw invalid("records must be an array");
      if (!Number.isSafeInteger(result.sourceCount) || result.sourceCount < 0) throw invalid("sourceCount must be a non-negative safe integer");
      if (result.sourceCount !== result.records.length) throw invalid("sourceCount must equal mapped record count");
      if (result.sourceCounts !== undefined) {
        const counts = result.sourceCounts;
        if (!counts || typeof counts !== "object" || Array.isArray(counts)) throw invalid("sourceCounts must be an object");
        const names = Object.keys(counts);
        if (!names.length) throw invalid("sourceCounts must not be empty");
        let total = 0;
        const observed = Object.create(null);
        for (const name of names) {
          const count = counts[name];
          if (!name.trim() || !Number.isSafeInteger(count) || count < 0) throw invalid("sourceCounts values must be non-negative safe integers with non-empty names");
          total += count;
          observed[name] = 0;
        }
        if (!Number.isSafeInteger(total) || total !== result.sourceCount) throw invalid("sourceCounts total must equal sourceCount");
        for (const record of result.records) {
          if (!record || typeof record.source !== "string" || !Object.prototype.hasOwnProperty.call(observed, record.source)) {
            throw invalid("each record source must be declared in sourceCounts");
          }
          observed[record.source] += 1;
        }
        for (const name of names) {
          if (observed[name] !== counts[name]) throw invalid("sourceCounts must match records grouped by source");
        }
      }
      return result;
    }

    async function load(options) {
      const settings = options && typeof options === "object" ? options : {};
      if (active) active.abortController.abort(new Error("superseded by a newer load"));
      const abortController = new AbortController();
      const generation = controller.begin();
      const externalSignal = settings.signal;
      let externalAbortHandler = null;
      if (externalSignal) {
        if (externalSignal.aborted) abortController.abort(externalSignal.reason);
        else {
          externalAbortHandler = () => abortController.abort(externalSignal.reason);
          externalSignal.addEventListener("abort", externalAbortHandler, { once: true });
        }
      }
      const request = { abortController, generation };
      active = request;
      let abortHandler = null;
      const abortPromise = new Promise((_, reject) => {
        abortHandler = () => reject(errors.createError({
          code: "DATA_LOAD_CANCELLED",
          category: "data",
          message: "曲庫載入已取消",
          retryable: false,
          cause: abortController.signal.reason
        }));
        if (abortController.signal.aborted) abortHandler();
        else abortController.signal.addEventListener("abort", abortHandler, { once: true });
      });

      try {
        // Do not invoke injected adapters for requests that were already cancelled
        // before load() began. Adapters are external boundaries and may perform
        // side effects before they inspect the supplied AbortSignal.
        if (abortController.signal.aborted) await abortPromise;
        const adapterPromise = Promise.resolve(adapter.load({ signal: abortController.signal, mode: settings.mode }));
        const sourceResult = validateSourceResult(await Promise.race([adapterPromise, abortPromise]));
        if (!controller.isCurrent(generation)) {
          return Object.freeze({ accepted: false, stale: true, cancelled: false, sourceCount: sourceResult.sourceCount, sourceCounts: sourceResult.sourceCounts || null, state: controller.snapshot() });
        }
        const accepted = controller.accept(sourceResult.records, generation);
        return Object.freeze({ ...accepted, cancelled: false, sourceCount: sourceResult.sourceCount, sourceCounts: sourceResult.sourceCounts || null });
      } catch (error) {
        if (!controller.isCurrent(generation)) {
          return Object.freeze({ accepted: false, stale: true, cancelled: error && error.code === "DATA_LOAD_CANCELLED", error: null, state: controller.snapshot() });
        }
        if (error && error.code === "DATA_LOAD_CANCELLED") {
          const state = controller.reset();
          return Object.freeze({ accepted: false, stale: false, cancelled: true, error, state });
        }
        const failed = controller.fail(error, { generation });
        return Object.freeze({ ...failed, cancelled: false });
      } finally {
        if (abortHandler) abortController.signal.removeEventListener("abort", abortHandler);
        if (externalSignal && externalAbortHandler) externalSignal.removeEventListener("abort", externalAbortHandler);
        if (active === request) active = null;
      }
    }

    function cancel() {
      if (!active) return false;
      active.abortController.abort(new Error("cancelled by caller"));
      return true;
    }

    // A mode change invalidates the published catalog even when no load is active.
    // Cancelling alone is insufficient in that case and would leave the previous
    // mode's records visible under a new mode.
    function invalidate() {
      if (active) active.abortController.abort(new Error("invalidated by source mode change"));
      controller.reset();
      return true;
    }

    function snapshot() { return controller.snapshot(); }
    function catalogSnapshot() { return typeof controller.catalogSnapshot === "function" ? controller.catalogSnapshot() : null; }
    return Object.freeze({ load, cancel, invalidate, snapshot, catalogSnapshot, isLoading: () => active !== null });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.repository = { createRepository };
})(window);
