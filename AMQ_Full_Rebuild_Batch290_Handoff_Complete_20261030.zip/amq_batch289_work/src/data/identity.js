/* Canonical source-scoped identity for songs and works. */
(function (global) {
  "use strict";

  function isIdentifier(value) {
    return (typeof value === "string" && value.trim().length > 0) ||
      (typeof value === "number" && Number.isFinite(value));
  }

  function identifierKey(value) {
    if (!isIdentifier(value)) throw new TypeError("identity id must be a non-empty string or finite number");
    return `${typeof value}:${String(value)}`;
  }

  function createIdentity(source, id) {
    if (source !== undefined && source !== null && typeof source !== "string") {
      throw new TypeError("identity source must be a string when provided");
    }
    const sourceKey = source == null ? "" : source;
    return JSON.stringify([sourceKey, identifierKey(id)]);
  }

  function sameIdentity(left, right) {
    return !!left && !!right && createIdentity(left.source, left.id) === createIdentity(right.source, right.id);
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.identity = Object.freeze({ isIdentifier, identifierKey, createIdentity, sameIdentity });
})(window);
