/* Source-evidenced quiz audio candidate construction. Candidate order is intentional. */
(function (global) {
  "use strict";

  const AMQ_AUDIO_HOSTS = Object.freeze([
    "https://nawdist.animemusicquiz.com/",
    "https://naedist.animemusicquiz.com/",
    "https://eudist.animemusicquiz.com/"
  ]);

  function freezeCandidates(candidates) {
    return Object.freeze(candidates.map(candidate => Object.freeze({
      url: candidate.url, source: candidate.source, kind: "audio"
    })));
  }

  function createAMQAudioCandidates(rawAudioFile) {
    const filename = String(rawAudioFile || "").split("/").pop().trim();
    if (!filename) return Object.freeze([]);
    return freezeCandidates(AMQ_AUDIO_HOSTS.map(host => ({
      url: host + encodeURIComponent(filename),
      source: host.replace(/^https:\/\/([^/]+)\/$/i, "$1")
    })));
  }

  function createEMQAudioCandidates(rawUrls) {
    if (rawUrls !== undefined && !Array.isArray(rawUrls)) throw new TypeError("EMQ audio URLs must be an array");
    const output = [];
    const seen = new Set();
    const add = (url, source) => {
      const value = String(url || "").trim();
      if (!value || seen.has(value)) return;
      seen.add(value);
      const host = value.match(/^https?:\/\/([^/]+)/i);
      output.push({ url: value, source: source || (host ? host[1].toLowerCase() : "emq-direct") });
    };
    const asianMirror = url => String(url).replace(
      /^https?:\/\/erogemusicquiz\.com(?=\/selfhoststorage\/userup\/)/i,
      "https://asiadist.erogemusicquiz.com"
    );
    for (const raw of rawUrls || []) {
      const url = String(raw || "").trim();
      if (!url) continue;

      // Legacy V82.54: Catbox-backed EMQ audio has a public direct mirror.
      const catbox = url.match(/^https?:\/\/[^/]+\/selfhoststorage\/catbox\/([^/?#]+)([?#].*)?$/i);
      if (catbox) add(`https://files.catbox.moe/${catbox[1]}`, "files.catbox.moe");

      // Legacy V82.55: prefer the Asia CDN for userup audio, then keep the original.
      const asian = asianMirror(url);
      if (asian !== url) add(asian, "asiadist.erogemusicquiz.com");
      add(url);

      // Legacy V82.54: .weba files may have a sibling .webm at userup/{uuid}.webm.
      // Preserve query/hash suffixes and mirror the fallback through the Asia CDN first.
      const weba = url.match(/^(https?:\/\/[^/]+\/selfhoststorage\/userup)\/weba\/([0-9a-f-]+)\.weba([?#].*)?$/i);
      if (weba) {
        const webm = `${weba[1]}/${weba[2]}.webm${weba[3] || ""}`;
        const asianWebm = asianMirror(webm);
        if (asianWebm !== webm) add(asianWebm, "asiadist.erogemusicquiz.com");
        add(webm);
      }
    }
    return freezeCandidates(output);
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.audioCandidates = Object.freeze({
    AMQ_AUDIO_HOSTS,
    createAMQAudioCandidates,
    createEMQAudioCandidates
  });
})(window);
