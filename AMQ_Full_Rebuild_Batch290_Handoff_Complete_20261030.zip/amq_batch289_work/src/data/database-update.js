/* Versioned, checksummed, atomic local database-update packages. */
(function (global) {
  "use strict";

  const FORMAT = "amq-learning-database-update";
  const FORMAT_VERSION = 1;
  const PAYLOAD_SCHEMA_VERSION = 1;
  const DB_NAME = "amq-learning-database-updates";
  const DB_VERSION = 1;
  const STORE_NAME = "datasets";
  const ACTIVE_KEY = "active";
  const SOURCE_SCHEMAS = Object.freeze({
    AMQ: "candidate382-stageI-library-data-v1",
    EMQ: "candidate382-stageI-library-emq-v1"
  });

  function stableStringify(value) {
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
  }

  function cloneJson(value) { return JSON.parse(JSON.stringify(value)); }
  function isObject(value) { return Boolean(value) && typeof value === "object" && !Array.isArray(value); }

  function createStore(options) {
    const settings = options && typeof options === "object" ? options : {};
    const indexedDBApi = settings.indexedDB || global.indexedDB;
    let databasePromise = null;
    function open() {
      if (!indexedDBApi || typeof indexedDBApi.open !== "function") return Promise.reject(new Error("IndexedDB 不可用，無法安全儲存曲庫更新"));
      if (!databasePromise) {
        databasePromise = new Promise((resolve, reject) => {
          let request;
          try { request = indexedDBApi.open(DB_NAME, DB_VERSION); }
          catch (error) { reject(error); return; }
          request.onupgradeneeded = () => {
            const database = request.result;
            if (!database.objectStoreNames.contains(STORE_NAME)) database.createObjectStore(STORE_NAME);
          };
          request.onsuccess = () => resolve(request.result);
          request.onerror = () => { databasePromise = null; reject(request.error || new Error("無法開啟曲庫更新資料庫")); };
          request.onblocked = () => { databasePromise = null; reject(new Error("曲庫更新資料庫被其他分頁阻擋")); };
        });
      }
      return databasePromise;
    }
    async function getActive() {
      const database = await open();
      return new Promise((resolve, reject) => {
        const transaction = database.transaction(STORE_NAME, "readonly");
        const request = transaction.objectStore(STORE_NAME).get(ACTIVE_KEY);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => reject(request.error || new Error("讀取已套用曲庫更新失敗"));
        transaction.onabort = () => reject(transaction.error || new Error("讀取曲庫更新交易中止"));
      });
    }
    async function replaceAtomic(envelope) {
      const database = await open();
      return new Promise((resolve, reject) => {
        let settled = false;
        const transaction = database.transaction(STORE_NAME, "readwrite");
        transaction.objectStore(STORE_NAME).put(cloneJson(envelope), ACTIVE_KEY);
        transaction.oncomplete = () => { settled = true; resolve(true); };
        transaction.onerror = () => {
          if (settled) return;
          settled = true;
          reject(transaction.error || new Error("曲庫更新交易失敗，原資料未提交"));
        };
        transaction.onabort = () => {
          if (settled) return;
          settled = true;
          reject(transaction.error || new Error("曲庫更新交易已回復，原資料未提交"));
        };
      });
    }
    async function clearAtomic() {
      const database = await open();
      return new Promise((resolve, reject) => {
        let settled = false;
        const transaction = database.transaction(STORE_NAME, "readwrite");
        transaction.objectStore(STORE_NAME).delete(ACTIVE_KEY);
        transaction.oncomplete = () => { settled = true; resolve(true); };
        transaction.onerror = () => {
          if (settled) return;
          settled = true;
          reject(transaction.error || new Error("移除曲庫更新交易失敗"));
        };
        transaction.onabort = () => {
          if (settled) return;
          settled = true;
          reject(transaction.error || new Error("移除曲庫更新交易已中止"));
        };
      });
    }
    return Object.freeze({ getActive, replaceAtomic, clearAtomic });
  }

  function createManager(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const store = deps.store || createStore({ indexedDB: deps.indexedDB });
    const mappers = deps.sourceMappers || (global.AMQData && global.AMQData.sourceMappers);
    const validator = deps.validator || (global.AMQData && global.AMQData.validateRecords);
    const cryptoApi = deps.crypto || global.crypto;
    const getCurrentSources = typeof deps.getCurrentSources === "function" ? deps.getCurrentSources : async () => null;
    if (!store || typeof store.getActive !== "function" || typeof store.replaceAtomic !== "function" || typeof store.clearAtomic !== "function") throw new TypeError("database update manager requires an atomic store");
    if (!mappers || typeof mappers.createAMQSongMapper !== "function" || typeof mappers.createEMQSongMapper !== "function") throw new TypeError("database update manager requires source mappers");
    if (typeof validator !== "function") throw new TypeError("database update manager requires the record validator");
    let validatedActive = null;
    let operation = Promise.resolve();

    function enqueue(task) {
      const next = operation.then(task, task);
      operation = next.then(() => undefined, () => undefined);
      return next;
    }

    async function digest(payload) {
      if (!cryptoApi || !cryptoApi.subtle || typeof cryptoApi.subtle.digest !== "function") throw new Error("目前環境不支援 SHA-256，已停用曲庫更新");
      const bytes = new TextEncoder().encode(stableStringify(payload));
      const result = await cryptoApi.subtle.digest("SHA-256", bytes);
      return [...new Uint8Array(result)].map(byte => byte.toString(16).padStart(2, "0")).join("");
    }

    function parseInput(input) {
      if (typeof input === "string") {
        try { return JSON.parse(input); }
        catch (_) { throw new Error("更新檔不是有效 JSON"); }
      }
      if (!isObject(input)) throw new Error("更新檔必須是 JSON 物件");
      return input;
    }

    function validateSourceShape(payload) {
      if (!isObject(payload) || payload.schemaVersion !== PAYLOAD_SCHEMA_VERSION || !isObject(payload.sources)
        || Object.keys(payload).sort().join(",") !== "schemaVersion,sources") throw new Error("更新檔 payload schema 不支援");
      const sources = payload.sources;
      if (Object.keys(sources).sort().join(",") !== "AMQ,EMQ") throw new Error("更新檔必須同時且只包含 AMQ 與 EMQ 來源");
      if (!isObject(sources.AMQ) || Object.keys(sources.AMQ).sort().join(",") !== "anime,schema,songs"
        || sources.AMQ.schema !== SOURCE_SCHEMAS.AMQ || !Array.isArray(sources.AMQ.anime) || !Array.isArray(sources.AMQ.songs)) {
        throw new Error("AMQ 更新資料格式不符，需包含已知 schema 的 anime 與 songs 陣列");
      }
      if (!isObject(sources.EMQ) || Object.keys(sources.EMQ).sort().join(",") !== "schema,songs,version,works"
        || sources.EMQ.schema !== SOURCE_SCHEMAS.EMQ || sources.EMQ.version !== 1 || !Array.isArray(sources.EMQ.works) || !Array.isArray(sources.EMQ.songs)) {
        throw new Error("EMQ 更新資料格式不符，需包含 version 1 的 works 與 songs 陣列");
      }
      if (!sources.AMQ.anime.length || !sources.AMQ.songs.length || !sources.EMQ.works.length || !sources.EMQ.songs.length) throw new Error("更新檔不可包含空曲庫或空作品表");
      return sources;
    }

    function mapAndValidate(sources) {
      const amqMapper = mappers.createAMQSongMapper(sources.AMQ.anime);
      const emqMapper = mappers.createEMQSongMapper(sources.EMQ.works);
      const amqRecords = sources.AMQ.songs.map(amqMapper);
      const emqRecords = sources.EMQ.songs.map(emqMapper);
      const amqValidation = validator(amqRecords);
      const emqValidation = validator(emqRecords);
      for (const [name, records, result] of [["AMQ", amqRecords, amqValidation], ["EMQ", emqRecords, emqValidation]]) {
        if (!result || result.status !== "loaded" || result.validCount !== records.length || result.rejectedCount !== 0) {
          const first = result && result.errors && result.errors[0];
          throw new Error(`${name} 更新資料驗證失敗${first ? `：${first.code} ${first.field}` : ""}`);
        }
        if (records.some(record => record.source !== name)) throw new Error(`${name} 更新資料來源標籤不一致`);
      }
      return Object.freeze({ AMQ: Object.freeze(amqRecords), EMQ: Object.freeze(emqRecords) });
    }

    function indexRows(rows, source) {
      const map = new Map();
      for (const row of rows) {
        const id = source === "AMQ" ? row[1] : row.i;
        map.set(`${typeof id}:${String(id)}`, stableStringify(row));
      }
      return map;
    }
    function indexWorks(rows, source) {
      const map = new Map();
      for (const row of rows) {
        const id = source === "AMQ" ? row[0] : row.i;
        map.set(`${typeof id}:${String(id)}`, stableStringify(row));
      }
      return map;
    }
    function compareRows(beforeRows, afterRows, source, works) {
      const before = works ? indexWorks(beforeRows, source) : indexRows(beforeRows, source);
      const after = works ? indexWorks(afterRows, source) : indexRows(afterRows, source);
      let added = 0, removed = 0, changed = 0;
      for (const [key, value] of after) {
        if (!before.has(key)) added += 1;
        else if (before.get(key) !== value) changed += 1;
      }
      for (const key of before.keys()) if (!after.has(key)) removed += 1;
      return Object.freeze({ added, removed, changed, before: before.size, after: after.size });
    }

    async function preflight(input, options) {
      const settings = options && typeof options === "object" ? options : {};
      try {
        const envelope = parseInput(input);
        if (envelope.format !== FORMAT || envelope.formatVersion !== FORMAT_VERSION || !isObject(envelope.payload)
          || typeof envelope.checksum !== "string" || !/^[a-f0-9]{64}$/i.test(envelope.checksum)
          || typeof envelope.createdAt !== "string" || !Number.isFinite(Date.parse(envelope.createdAt))) throw new Error("更新檔格式、建立時間或版本不支援");
        const sources = validateSourceShape(envelope.payload);
        const actualChecksum = await digest(envelope.payload);
        if (actualChecksum !== envelope.checksum) throw new Error("SHA-256 checksum 不符，檔案可能損壞或被修改");
        const normalized = mapAndValidate(sources);
        let diff = null;
        if (settings.compare !== false) {
          const current = await getCurrentSources();
          if (current) {
            diff = Object.freeze({
              AMQ: Object.freeze({ songs: compareRows(current.AMQ.songs, sources.AMQ.songs, "AMQ", false), works: compareRows(current.AMQ.anime, sources.AMQ.anime, "AMQ", true) }),
              EMQ: Object.freeze({ songs: compareRows(current.EMQ.songs, sources.EMQ.songs, "EMQ", false), works: compareRows(current.EMQ.works, sources.EMQ.works, "EMQ", true) })
            });
          }
        }
        const clonedEnvelope = cloneJson(envelope);
        return Object.freeze({ ok: true, formatVersion: FORMAT_VERSION, checksum: actualChecksum,
          sourceCounts: Object.freeze({ AMQ: Object.freeze({ songs: sources.AMQ.songs.length, works: sources.AMQ.anime.length }), EMQ: Object.freeze({ songs: sources.EMQ.songs.length, works: sources.EMQ.works.length }) }),
          diff, normalized, envelope: clonedEnvelope });
      } catch (error) {
        return Object.freeze({ ok: false, reason: error && error.message ? error.message : "曲庫更新預檢失敗" });
      }
    }

    async function createPackage(sources) {
      try {
        const payload = { schemaVersion: PAYLOAD_SCHEMA_VERSION, sources: cloneJson(sources) };
        validateSourceShape(payload);
        mapAndValidate(payload.sources);
        return Object.freeze({ ok: true, envelope: Object.freeze({ format: FORMAT, formatVersion: FORMAT_VERSION, createdAt: new Date().toISOString(), payload, checksum: await digest(payload) }) });
      } catch (error) { return Object.freeze({ ok: false, reason: error && error.message ? error.message : "無法建立曲庫更新包" }); }
    }

    async function apply(input, expectedChecksum) {
      return enqueue(async () => {
        const checked = await preflight(input, { compare: false });
        if (!checked.ok) return Object.freeze({ ok: false, phase: "preflight", reason: checked.reason });
        if (expectedChecksum && expectedChecksum !== checked.checksum) return Object.freeze({ ok: false, phase: "preflight", reason: "更新檔在預檢後發生變更，請重新預檢" });
        try {
          await store.replaceAtomic(checked.envelope);
          validatedActive = { checksum: checked.checksum, envelope: checked.envelope, normalized: checked.normalized };
          return Object.freeze({ ok: true, checksum: checked.checksum, sourceCounts: checked.sourceCounts, requiresReload: true });
        } catch (error) {
          return Object.freeze({ ok: false, phase: "commit", reason: error && error.message ? error.message : "IndexedDB 原子提交失敗；原曲庫更新未套用" });
        }
      });
    }

    function getActiveDataset() {
      // Reads and validation must share the same operation queue as apply/clear.
      // Otherwise a slow validation of the previous envelope can finish after a
      // newer atomic apply and return stale catalogue data to a concurrent caller.
      return enqueue(async () => {
        const envelope = await store.getActive();
        if (!envelope) { validatedActive = null; return null; }
        if (validatedActive && validatedActive.checksum === envelope.checksum) return validatedActive;
        const checked = await preflight(envelope, { compare: false });
        if (!checked.ok) throw new Error(`已儲存的曲庫更新無法驗證：${checked.reason}`);
        validatedActive = { checksum: checked.checksum, envelope: checked.envelope, normalized: checked.normalized };
        return validatedActive;
      });
    }

    async function clearActive() {
      return enqueue(async () => {
        try {
          await store.clearAtomic();
          validatedActive = null;
          return Object.freeze({ ok: true, requiresReload: true });
        } catch (error) { return Object.freeze({ ok: false, reason: error && error.message ? error.message : "無法安全移除曲庫更新" }); }
      });
    }

    return Object.freeze({ format: FORMAT, formatVersion: FORMAT_VERSION, sourceSchemas: SOURCE_SCHEMAS,
      createPackage, preflight, apply, getActiveDataset, clearActive });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.databaseUpdate = Object.freeze({ createStore, createManager, format: FORMAT, formatVersion: FORMAT_VERSION, sourceSchemas: SOURCE_SCHEMAS });
})(typeof window !== "undefined" ? window : globalThis);
