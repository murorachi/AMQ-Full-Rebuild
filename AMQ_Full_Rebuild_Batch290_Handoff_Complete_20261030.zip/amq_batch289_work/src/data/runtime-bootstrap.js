/* Runtime entry point: one repository, explicit mode source selection, and no legacy assumptions. */
(function (global) {
  "use strict";

  function createRuntimeBootstrap(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const registry = deps.registry || (global.AMQData && global.AMQData.sourceRegistry);
    const repositoryFactory = deps.repositoryFactory || (global.AMQData && global.AMQData.repository);
    const stateStore = deps.stateStore || (global.AMQCore && global.AMQCore.state);
    if (!registry || typeof registry.createAdapterForMode !== "function") throw new TypeError("runtime bootstrap requires a source registry");
    if (!repositoryFactory || typeof repositoryFactory.createRepository !== "function") throw new TypeError("runtime bootstrap requires a repository factory");
    if (!stateStore || typeof stateStore.getState !== "function" || typeof stateStore.subscribe !== "function") {
      throw new TypeError("runtime bootstrap requires a subscribable state store");
    }

    const adapter = Object.freeze({
      load(options) {
        const settings = options && typeof options === "object" ? options : {};
        const selected = registry.createAdapterForMode(settings.mode);
        return selected.load({ signal: settings.signal });
      }
    });
    const repositoryDependencies = { ...(deps.repositoryDependencies || {}), adapter };
    const repository = repositoryFactory.createRepository(repositoryDependencies);
    let currentMode = stateStore.getState().mode;
    let disposed = false;
    const unsubscribe = stateStore.subscribe(nextState => {
      if (nextState.mode === currentMode) return;
      currentMode = nextState.mode;
      if (typeof repository.invalidate === "function") repository.invalidate();
      else repository.cancel();
    });

    function loadCurrentMode(options) {
      if (disposed) throw new Error("runtime bootstrap has been disposed");
      const settings = options && typeof options === "object" ? options : {};
      const mode = stateStore.getState().mode;
      return repository.load({ ...settings, mode });
    }

    function cancel() { return repository.cancel(); }
    function snapshot() { return repository.snapshot(); }
    function catalogSnapshot() { return repository.catalogSnapshot(); }

    function dispose() {
      if (disposed) return false;
      disposed = true;
      unsubscribe();
      // Disposal ends this runtime's ownership of the catalog. Reset synchronously
      // so shared UI state cannot claim "loaded" while a remounted runtime has no catalog.
      if (typeof repository.invalidate === "function") repository.invalidate();
      else repository.cancel();
      return true;
    }

    return Object.freeze({ loadCurrentMode, cancel, snapshot, catalogSnapshot, dispose, get isDisposed() { return disposed; } });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.runtimeBootstrap = Object.freeze({ createRuntimeBootstrap });
})(window);
