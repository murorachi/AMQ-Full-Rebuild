/* Explicit registry for selecting preconfigured data adapters by application mode. */
(function (global) {
  "use strict";

  const ALLOWED_MODES = new Set(["AMQ", "EMQ", "MIX"]);

  function createRegistry(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const sourcesInput = deps.sources;
    const modeSourcesInput = deps.modeSources;
    const compositeFactory = deps.createCompositeAdapter || (global.AMQData && global.AMQData.sourceAdapter && global.AMQData.sourceAdapter.createCompositeAdapter);
    if (!sourcesInput || typeof sourcesInput !== "object" || Array.isArray(sourcesInput)) {
      throw new TypeError("source registry requires a sources object");
    }
    if (!modeSourcesInput || typeof modeSourcesInput !== "object" || Array.isArray(modeSourcesInput)) {
      throw new TypeError("source registry requires an explicit modeSources object");
    }
    if (typeof compositeFactory !== "function") throw new TypeError("source registry requires a composite adapter factory");

    const sources = new Map();
    for (const [name, adapter] of Object.entries(sourcesInput)) {
      if (!name.trim()) throw new TypeError("source names must not be empty");
      if (!adapter || typeof adapter.load !== "function") throw new TypeError(`source ${name} requires an adapter`);
      sources.set(name, adapter);
    }
    if (sources.size === 0) throw new TypeError("source registry requires at least one source");

    const configuredModes = new Map();
    for (const [mode, configuredNames] of Object.entries(modeSourcesInput)) {
      if (!ALLOWED_MODES.has(mode)) throw new TypeError(`unsupported application mode: ${mode}`);
      if (!Array.isArray(configuredNames) || configuredNames.length === 0) {
        throw new TypeError(`mode ${mode} must select at least one source`);
      }
      const seen = new Set();
      for (const name of configuredNames) {
        if (typeof name !== "string" || !sources.has(name)) throw new TypeError(`mode ${mode} references unknown source: ${String(name)}`);
        if (seen.has(name)) throw new TypeError(`mode ${mode} selects source more than once: ${name}`);
        seen.add(name);
      }
      configuredModes.set(mode, Object.freeze(configuredNames.slice()));
    }

    function sourceNamesForMode(mode) {
      if (!ALLOWED_MODES.has(mode)) throw new TypeError(`unsupported application mode: ${String(mode)}`);
      const names = configuredModes.get(mode);
      if (!names) throw new TypeError(`application mode ${mode} has no source mapping`);
      return names;
    }

    function createAdapterForMode(mode) {
      const names = sourceNamesForMode(mode);
      return compositeFactory({ sources: names.map(name => ({ name, adapter: sources.get(name) })) });
    }

    return Object.freeze({
      modes: Object.freeze([...configuredModes.keys()]),
      sourceNames: Object.freeze([...sources.keys()]),
      sourceNamesForMode,
      createAdapterForMode
    });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.sourceRegistry = Object.freeze({ createRegistry, allowedModes: Object.freeze([...ALLOWED_MODES]) });
})(window);
