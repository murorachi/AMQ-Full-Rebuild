/* Self-hosted release endpoint and pinned Ed25519 release-verification key. */
(function (global) {
  "use strict";
  if (typeof global.AMQ_DATABASE_UPDATE_MANIFEST_URL !== "string") {
    global.AMQ_DATABASE_UPDATE_MANIFEST_URL = "";
  }
  if (typeof global.AMQ_DATABASE_UPDATE_RELEASE_PUBLIC_KEY !== "string") {
    global.AMQ_DATABASE_UPDATE_RELEASE_PUBLIC_KEY = "MCowBQYDK2VwAyEAUxOCPPkuVvVb2MNzOubzenbalEc9k8OeUVdLxr4uiQI=";
  }
  if (typeof global.AMQ_DATABASE_UPDATE_RELEASE_KEY_ID !== "string") {
    global.AMQ_DATABASE_UPDATE_RELEASE_KEY_ID = "55f06a8b96214b9b";
  }
})(window);
