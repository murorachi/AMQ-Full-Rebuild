/* Browser source wiring for verified bundled assets and validated local database overrides. */
(function (global) {
  "use strict";

  function createBrowserRuntime(options) {
    const settings = options && typeof options === "object" ? options : {};
    const data = global.AMQData;
    const errors = global.AMQCore && global.AMQCore.errors;
    const stateStore = settings.stateStore || (global.AMQCore && global.AMQCore.state);
    if (!data || !data.sourceAdapter || !data.sourceMappers || !data.sourceRegistry || !data.runtimeBootstrap || !data.databaseUpdate) {
      throw new TypeError("browser source runtime requires the data modules");
    }
    if (!errors || typeof errors.createError !== "function") throw new TypeError("browser source runtime requires the shared error contract");
    if (!stateStore) throw new TypeError("browser source runtime requires the shared state store");

    function sourceError(code, message, cause) {
      return errors.createError({ code, message, category: "data", retryable: false, cause });
    }
    function assertActive(signal) {
      if (signal && signal.aborted) throw sourceError("DATA_LOAD_CANCELLED", "曲庫載入已取消", signal.reason);
    }

    const database = global.DB;
    if (!database || !Array.isArray(database.anime) || !Array.isArray(database.songs)) {
      throw sourceError("DATA_SOURCE_NOT_AVAILABLE", "AMQ 資料檔未載入或格式不符。請確認 src/data/assets/data.js 已成功載入。");
    }

    let emqPayload = null;
    let emqPayloadPromise = null;
    const mapAMQSong = data.sourceMappers.createAMQSongMapper(database.anime);
    const AMQ_NORMALIZED_RECORD = Symbol("amq-normalized-record");
    const EMQ_NORMALIZED_RECORD = Symbol("emq-normalized-record");
    let mapEMQSong = null;

    async function readBundledEMQPayload({ signal } = {}) {
      assertActive(signal);
      if (emqPayload) return emqPayload;
      if (!emqPayloadPromise) {
        emqPayloadPromise = (async () => {
          const packed = global.__EMQ_PACKED_B64;
          if (typeof packed !== "string" || !packed) throw sourceError("DATA_SOURCE_NOT_AVAILABLE", "EMQ 壓縮資料未載入。請確認 src/data/assets/emq-data.js 已成功載入。");
          if (typeof global.atob !== "function" || typeof global.DecompressionStream !== "function" || typeof global.Response !== "function" || typeof global.Blob !== "function") {
            throw sourceError("DATA_SOURCE_DECODE_UNSUPPORTED", "此瀏覽器缺少解壓 EMQ 曲庫所需的 Web API（atob／DecompressionStream）。");
          }
          try {
            const binary = global.atob(packed);
            const bytes = new Uint8Array(binary.length);
            for (let index = 0; index < binary.length; index += 1) bytes[index] = binary.charCodeAt(index);
            const stream = new global.Blob([bytes]).stream().pipeThrough(new global.DecompressionStream("gzip"));
            const payload = await new global.Response(stream).json();
            if (!payload || payload.version !== 1 || !Array.isArray(payload.songs) || !Array.isArray(payload.works)) throw new TypeError("EMQ payload must contain version 1, songs, and works");
            emqPayload = payload;
            mapEMQSong = data.sourceMappers.createEMQSongMapper(payload.works);
            return payload;
          } catch (error) {
            if (error && error.name === "AMQError") throw error;
            throw sourceError("DATA_SOURCE_DECODE_FAILED", "無法解壓或解析 EMQ 曲庫資料。", error);
          }
        })().catch(error => { emqPayloadPromise = null; throw error; });
      }
      const payload = await emqPayloadPromise;
      assertActive(signal);
      return payload;
    }

    const updateManager = data.databaseUpdate.createManager({
      store: settings.databaseUpdateStore,
      crypto: settings.crypto,
      getCurrentSources: async () => {
        const active = await updateManager.getActiveDataset();
        if (active) return active.envelope.payload.sources;
        const emq = await readBundledEMQPayload();
        return {
          AMQ: { schema: data.databaseUpdate.sourceSchemas.AMQ, anime: database.anime, songs: database.songs },
          EMQ: { schema: data.databaseUpdate.sourceSchemas.EMQ, version: 1, works: emq.works, songs: emq.songs }
        };
      }
    });

    const amqAdapter = data.sourceAdapter.createAdapter({
      errors,
      async read({ signal }) {
        assertActive(signal);
        const active = await updateManager.getActiveDataset();
        if (active) return active.normalized.AMQ.map(record => Object.freeze({ [AMQ_NORMALIZED_RECORD]: record }));
        return database.songs;
      },
      mapRecord(record) { return record && record[AMQ_NORMALIZED_RECORD] ? record[AMQ_NORMALIZED_RECORD] : mapAMQSong(record); }
    });

    const emqAdapter = data.sourceAdapter.createAdapter({
      errors,
      async read({ signal }) {
        assertActive(signal);
        const active = await updateManager.getActiveDataset();
        if (active) return active.normalized.EMQ.map(record => Object.freeze({ [EMQ_NORMALIZED_RECORD]: record }));
        const payload = await readBundledEMQPayload({ signal });
        mapEMQSong = data.sourceMappers.createEMQSongMapper(payload.works);
        return payload.songs;
      },
      mapRecord(record) {
        if (record && record[EMQ_NORMALIZED_RECORD]) return record[EMQ_NORMALIZED_RECORD];
        if (typeof mapEMQSong !== "function") throw sourceError("DATA_SOURCE_DECODE_FAILED", "EMQ 歌曲映射器尚未建立。");
        return mapEMQSong(record);
      }
    });

    const registry = data.sourceRegistry.createRegistry({
      sources: { AMQ: amqAdapter, EMQ: emqAdapter },
      modeSources: { AMQ: ["AMQ"], EMQ: ["EMQ"], MIX: ["AMQ", "EMQ"] }
    });
    const runtime = data.runtimeBootstrap.createRuntimeBootstrap({ registry, stateStore });
    async function resolveArtworkRecord(source, workId) {
      const normalizedSource = String(source || "").trim().toUpperCase();
      const id = Number(workId);
      if (!Number.isSafeInteger(id) || id <= 0 || !["AMQ", "EMQ"].includes(normalizedSource)) return null;
      const active = await updateManager.getActiveDataset();
      const sources = active && active.envelope && active.envelope.payload && active.envelope.payload.sources;
      if (normalizedSource === "AMQ") {
        const works = sources && sources.AMQ && Array.isArray(sources.AMQ.anime) ? sources.AMQ.anime : database.anime;
        const row = works.find(item => Array.isArray(item) && Number(item[0]) === id);
        if (!row) return null;
        const work = data.sourceMappers.mapAMQWork(row);
        return Object.freeze({ source: "AMQ", animeId: work.id, animeTitle: work.title, animeAnnId: work.annId, artworkRef: work.artworkRef, workKind: "anime" });
      }
      let works = sources && sources.EMQ && Array.isArray(sources.EMQ.works) ? sources.EMQ.works : null;
      if (!works) { const payload = await readBundledEMQPayload(); works = payload.works; }
      const row = works.find(item => item && Number(item.i) === id);
      if (!row) return null;
      return Object.freeze({ source: "EMQ", animeId: id, animeTitle: String(row.t || ""), animeVndbId: typeof row.vndbId === "string" ? row.vndbId : "", artworkRef: Object.freeze({ kind: "visual_novel_game", source: "EMQ", id, ...(typeof row.vndbId === "string" && row.vndbId.trim() ? { vndbId: row.vndbId.trim().toLowerCase() } : {}) }), workKind: "visual_novel_game" });
    }

    async function exportDatabaseUpdatePackage() {
      const active = await updateManager.getActiveDataset();
      let sources;
      if (active) sources = active.envelope.payload.sources;
      else {
        const emq = await readBundledEMQPayload();
        sources = {
          AMQ: { schema: data.databaseUpdate.sourceSchemas.AMQ, anime: database.anime, songs: database.songs },
          EMQ: { schema: data.databaseUpdate.sourceSchemas.EMQ, version: 1, works: emq.works, songs: emq.songs }
        };
      }
      return updateManager.createPackage(sources);
    }
    return Object.freeze({
      runtime,
      databaseUpdate: updateManager,
      exportDatabaseUpdatePackage,
      resolveArtworkRecord,
      sourceInfo: Object.freeze({
        AMQ: Object.freeze({ works: database.anime.length, songs: database.songs.length, schema: data.databaseUpdate.sourceSchemas.AMQ }),
        EMQ: Object.freeze({ payloadVersion: 1, schema: data.databaseUpdate.sourceSchemas.EMQ, compressed: true }),
        MIX: Object.freeze({ configured: true, sources: Object.freeze(["AMQ", "EMQ"]), selection: "2:1 AMQ:EMQ when both eligible pools are non-empty; fall back to the available source", filterScope: "current rebuild applies shared filters only; legacy AMQ-specific filter suppression is documented" })
      }),
      dispose() { return runtime.dispose(); }
    });
  }

  global.AMQData = global.AMQData || {};
  global.AMQData.sourceRuntime = Object.freeze({ createBrowserRuntime });
})(window);
