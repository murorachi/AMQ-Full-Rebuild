/* Role-specific geometry guidance for faithful OSK previews. This does not claim that a preview is a native osu! renderer. */
(function (global) {
  "use strict";
  const RULES = Object.freeze({
    "app.home.background": { mode: "cover", anchor: "center center", label: "滿版背景 · cover 裁切", note: "官方 menu-background 建議 1366×768，置中並覆蓋視窗，保留比例、裁切超出部分。" },
    "quiz.background": { mode: "cover", anchor: "center center", label: "滿版背景 · cover 裁切", note: "AMQ 延伸用途；沿用背景 cover 幾何，但不代表 osu! 原生遊戲場景語義完全相同。" },
    "catalog.frame.top": { mode: "repeat-x", anchor: "top left", label: "上框架 · 水平延展", note: "官方上框架會重複右側邊緣像素；單純拉伸整張圖並不等價，正式 renderer 仍需切片／邊緣延展。" },
    "catalog.frame.bottom": { mode: "stretch-x", anchor: "bottom left", label: "下框架 · 橫向拉伸", note: "官方下框架橫向延伸至視窗寬度，且高度會影響下層點擊。僅允許映射至選歌頁框架。" },
    "catalog.item.background": { mode: "stateful-panel", anchor: "bottom left", label: "選曲列 · 狀態化面板", note: "menu-button-background 用於難度列與特定分數板，具有狀態 tint；不是通用面板，也不是作品封面。" },
    "catalog.item.selected": { mode: "stateful-panel", anchor: "bottom left", label: "選曲列 · 選取狀態", note: "需保留選取狀態與 skin version 差異；selection-bar 與 menu-button-background 不可無條件互換。" },
    "app.navigation.options": { mode: "state-pair", anchor: "bottom left", label: "按鈕 · normal / hover 配對", note: "selection-options.png 與 selection-options-over.png 是不同互動狀態，不可只把 hover 圖當一般按鈕。" },
    "settings.entry": { mode: "state-pair", anchor: "bottom left", label: "設定入口 · normal / hover 配對", note: "原生素材有正常與 hover 狀態；AMQ 需保留鍵盤 focus-visible 與 disabled 狀態。" },
    "results.panel": { mode: "panel-contain", anchor: "center center", label: "結算面板 · 比例預覽", note: "ranking-panel 是結算畫面素材；需依 AMQ 面板尺寸檢查裁切與內容可讀性，不能直接當任意全站背景。" },
    "results.grade": { mode: "intrinsic", anchor: "center center", label: "評級徽章 · 保留比例", note: "ranking grade 只代表評級視覺，不能替代答對／答錯回饋。" },
    "catalog.song-artwork": { mode: "semantic-block", anchor: "center center", label: "作品封面 · 禁止猜圖", note: "osu! Skin 中的角色或遊戲素材不等於曲庫作品封面；沒有可靠封面來源時保留作品封面 fallback。" },
    "player.dock.background": { mode: "semantic-block", anchor: "center center", label: "播放器底座 · AMQ 專屬槽位", note: "songselect-bottom 是選歌頁框架，不會自動套用至獨立播放器底座。" }
  });
  const DEFAULT = Object.freeze({ mode: "contain", anchor: "center center", label: "保留原始比例 · contain", note: "此預覽只顯示素材本身；正式套用仍取決於角色的真實 DOM target 與 CSS consumer。" });
  function describe(roleId, filename) {
    const rule = RULES[roleId] || DEFAULT;
    const name = String(filename || "").split(/[\\/]/).pop().toLowerCase();
    let versionNote = "";
    if (/@2x\./i.test(name)) versionNote = "此素材為 @2x 高密度檔，顯示尺寸需依 skin.ini 版本語義縮放，不能直接用像素值當 CSS 尺寸。";
    if (/selection-options-over|selection-random-over|selection-mods-over/.test(name)) versionNote = `${versionNote ? versionNote + " " : ""}檔名表示 hover 狀態，需與 normal 狀態配對。`;
    return Object.freeze({ ...rule, versionNote });
  }
  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.skinGeometry = Object.freeze({ describe, rules: RULES });
})(window);
