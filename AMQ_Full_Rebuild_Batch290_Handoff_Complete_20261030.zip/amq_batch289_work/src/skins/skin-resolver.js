/* Resolves Skin configuration through one deterministic precedence chain. */
(function (global) {
  "use strict";
  const MAX_ROLES = 500;
  const MAX_PROPERTIES = 32;
  const STYLE_RULES = Object.freeze({
    width: { type: "length", min: 0, max: 4096 }, height: { type: "length", min: 0, max: 4096 },
    minWidth: { type: "length", min: 0, max: 4096 }, minHeight: { type: "length", min: 0, max: 4096 },
    opacity: { type: "number", min: 0, max: 1 }, zIndex: { type: "number", min: -1000, max: 1000 },
    borderRadius: { type: "length", min: 0, max: 256 }, gap: { type: "length", min: 0, max: 256 },
    padding: { type: "length", min: 0, max: 256 }, margin: { type: "length", min: -256, max: 256 },
    objectFit: { type: "enum", values: ["contain", "cover", "fill", "none", "scale-down"] },
    objectPosition: { type: "position" }, display: { type: "enum", values: ["block", "inline", "inline-block", "flex", "grid", "none"] },
    color: { type: "color" }, backgroundColor: { type: "color" }, borderColor: { type: "color" },
    fontSize: { type: "length", min: 8, max: 96 }, fontWeight: { type: "enum", values: ["300", "400", "500", "600", "700", "800", "900", "normal", "bold"] },
    textAlign: { type: "enum", values: ["left", "center", "right", "start", "end"] }
  });
  function validStyle(key, value) {
    const rule = STYLE_RULES[key];
    if (!rule) return false;
    if (rule.type === "length") return typeof value === "number" && Number.isFinite(value) && value >= rule.min && value <= rule.max;
    if (rule.type === "number") return typeof value === "number" && Number.isFinite(value) && value >= rule.min && value <= rule.max;
    if (rule.type === "enum") return rule.values.includes(String(value));
    if (rule.type === "color") return typeof value === "string" && /^(#[\da-f]{3,8}|transparent|currentColor|rgba?\([\d.,%\s]+\))$/i.test(value);
    if (rule.type === "position") return typeof value === "string" && /^(left|center|right|top|bottom|\d{1,3}%)(\s+(left|center|right|top|bottom|\d{1,3}%))?$/.test(value);
    return false;
  }
  function normalizeOverrides(input) {
    if (input == null) return Object.freeze({ regions: Object.freeze({}), components: Object.freeze({}) });
    if (!input || typeof input !== "object" || Array.isArray(input)) return null;
    const output = { regions: {}, components: {} };
    for (const scope of ["regions", "components"]) {
      const source = input[scope] && typeof input[scope] === "object" && !Array.isArray(input[scope]) ? input[scope] : {};
      const entries = Object.entries(source);
      if (entries.length > MAX_ROLES) return null;
      for (const [id, props] of entries) {
        if (!/^[a-z][a-z0-9.-]{1,120}$/.test(id) || !props || typeof props !== "object" || Array.isArray(props)) return null;
        const safe = {};
        for (const [key, value] of Object.entries(props).slice(0, MAX_PROPERTIES)) if (validStyle(key, value)) safe[key] = value;
        output[scope][id] = Object.freeze(safe);
      }
    }
    return Object.freeze({ regions: Object.freeze(output.regions), components: Object.freeze(output.components) });
  }
  function merge(...layers) { return Object.assign({}, ...layers.filter(layer => layer && typeof layer === "object" && !Array.isArray(layer))); }
  function resolve(options) {
    const input = options || {};
    const defaults = input.defaults || {};
    const selected = input.selectedSkin || {};
    const overrides = normalizeOverrides(input.overrides);
    if (!overrides) throw new TypeError("skin-overrides-invalid");
    const roleIds = new Set([...Object.keys(defaults), ...Object.keys(selected), ...Object.keys(overrides.regions), ...Object.keys(overrides.components)]);
    if (roleIds.size > MAX_ROLES) throw new RangeError("skin-role-limit");
    const result = {};
    for (const role of roleIds) result[role] = Object.freeze(merge(defaults[role], selected[role], overrides.regions[role], overrides.components[role]));
    return Object.freeze(result);
  }
  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.skinResolver = Object.freeze({ resolve, normalizeOverrides, validStyle, styleRules: STYLE_RULES, precedence: Object.freeze(["defaults", "selectedSkin", "regionOverride", "componentOverride"]) });
})(window);
