/* Deterministic pixel-level tint primitives. This is a multiply contract, not a claim of pixel-perfect osu!stable compositing. */
(function (global) {
  "use strict";
  function byte(value) { return Math.max(0, Math.min(255, Math.round(Number(value) || 0))); }
  function multiplyRgba(source, tint) {
    if (!source || !tint || source.length < 4 || tint.length < 3) return null;
    return Object.freeze([
      Math.round(byte(source[0]) * byte(tint[0]) / 255),
      Math.round(byte(source[1]) * byte(tint[1]) / 255),
      Math.round(byte(source[2]) * byte(tint[2]) / 255),
      byte(source[3])
    ]);
  }
  function multiplyRgbaBuffer(source, tint, width, height) {
    const w = Number(width), h = Number(height);
    if (!Number.isInteger(w) || !Number.isInteger(h) || w <= 0 || h <= 0 || !source || source.length !== w * h * 4 || !tint || tint.length < 3) return null;
    const output = new Uint8ClampedArray(source.length);
    for (let i = 0; i < source.length; i += 4) {
      output[i] = Math.round(byte(source[i]) * byte(tint[0]) / 255);
      output[i + 1] = Math.round(byte(source[i + 1]) * byte(tint[1]) / 255);
      output[i + 2] = Math.round(byte(source[i + 2]) * byte(tint[2]) / 255);
      output[i + 3] = byte(source[i + 3]);
    }
    return output;
  }
  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.skinBlend = Object.freeze({ multiplyRgba, multiplyRgbaBuffer, contract: "rgb-multiply-preserve-source-alpha-v1" });
})(window);
