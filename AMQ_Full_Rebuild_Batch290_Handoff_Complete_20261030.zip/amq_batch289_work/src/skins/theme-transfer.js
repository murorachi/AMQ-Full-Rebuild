/* Explicit local export/import for portable AMQ Skin Theme bundles. */
(function (global) {
  "use strict";
  const FORMAT = "amq-skin-theme";
  const FORMAT_VERSION = 1;
  const MAX_ASSET_BYTES = 24 * 1024 * 1024;
  const MAX_TOTAL_BYTES = 120 * 1024 * 1024;
  const MAX_ASSETS = 5000;
  const ROLES = ["background", "selectionFrame", "characterOverlay"];
  const SUPPORTED_EXTENSIONS = new Set(["png", "jpg", "jpeg", "webp", "gif", "bmp", "wav", "mp3", "ogg"]);
  function fail(code, message) { const error = new Error(message); error.code = code; throw error; }
  function safePath(path) {
    return typeof path === "string" && path.length > 0 && path.length <= 1024 && !path.startsWith("/") && !/^[a-z]:/i.test(path) && !path.includes("\\") && !path.split("/").some(part => !part || part === "." || part === "..");
  }
  function bytesToBase64(bytes, encode) {
    let binary = "";
    const chunkSize = 0x8000;
    for (let offset = 0; offset < bytes.length; offset += chunkSize) binary += String.fromCharCode(...bytes.subarray(offset, Math.min(offset + chunkSize, bytes.length)));
    return encode(binary);
  }
  async function exportTheme(theme, dependencies) {
    const deps = dependencies || {};
    const encode = deps.btoa || global.btoa;
    if (typeof encode !== "function") fail("THEME_TRANSFER_BASE64_UNAVAILABLE", "此環境不支援主題匯出編碼。");
    const normalized = validateTheme(theme, true);
    let total = 0;
    const assets = [];
    for (const item of normalized.assets) {
      const bytes = new Uint8Array(await item.blob.arrayBuffer());
      total += bytes.byteLength;
      if (bytes.byteLength > MAX_ASSET_BYTES || total > MAX_TOTAL_BYTES) fail("THEME_TRANSFER_SIZE_LIMIT", "主題素材超出匯出大小限制。");
      assets.push({ path: item.path, name: item.name, extension: item.extension, mime: item.blob.type || item.mime || "application/octet-stream", dataBase64: bytesToBase64(bytes, encode) });
    }
    return JSON.stringify({ format: FORMAT, formatVersion: FORMAT_VERSION, exportedAt: new Date().toISOString(), notice: "匯入的素材可能受第三方著作權或授權條款限制；請在分享或發布前自行確認權利。匯出只在本機執行，不會上傳。", theme: { schemaVersion: 1, enabled: normalized.enabled, metadata: normalized.metadata, mappings: normalized.mappings, roleMappings: normalized.roleMappings || {}, roleStateMappings: normalized.roleStateMappings || {}, skinIniText: normalized.skinIniText || "", skinIniSections: normalized.skinIniSections || {}, accentColors: normalized.accentColors, motionPreference: normalized.motionPreference, overrides: normalized.overrides, assets } });
  }
  function validateTheme(input, allowBlob) {
    if (!input || typeof input !== "object" || Array.isArray(input) || ![1, 2, 3, 4].includes(input.schemaVersion) || !Array.isArray(input.assets) || input.assets.length > MAX_ASSETS) fail("THEME_TRANSFER_INVALID_SCHEMA", "主題設定格式無效或版本不支援。");
    const resolver = global.AMQSkins && global.AMQSkins.skinResolver;
    const overrides = resolver && typeof resolver.normalizeOverrides === "function"
      ? resolver.normalizeOverrides(input.overrides)
      : (input.overrides == null ? { regions: {}, components: {} } : null);
    if (!overrides) fail("THEME_TRANSFER_INVALID_OVERRIDES", "主題版面覆寫格式無效或包含不支援的值。");
    const paths = new Set(); let total = 0;
    const assets = input.assets.map(item => {
      if (!item || !safePath(item.path) || paths.has(item.path)) fail("THEME_TRANSFER_INVALID_PATH", "主題含有無效或重複的素材路徑。");
      paths.add(item.path);
      const extension = String(item.extension || item.path.split(".").pop() || "").toLowerCase();
      if (!SUPPORTED_EXTENSIONS.has(extension)) fail("THEME_TRANSFER_UNSUPPORTED_ASSET", "主題包含不支援的素材格式。");
      if (allowBlob) {
        if (!item.blob || typeof item.blob.arrayBuffer !== "function" || item.blob.size > MAX_ASSET_BYTES) fail("THEME_TRANSFER_ASSET_INVALID", "主題素材無效或超過單檔限制。");
        total += item.blob.size;
        return { path: item.path, name: String(item.name || item.path.split("/").pop()).slice(0, 255), extension, mime: String(item.mime || item.blob.type || "application/octet-stream"), blob: item.blob };
      }
      if (typeof item.dataBase64 !== "string" || item.dataBase64.length > Math.ceil(MAX_ASSET_BYTES * 4 / 3) + 8 || !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(item.dataBase64)) fail("THEME_TRANSFER_ASSET_INVALID", "主題圖片資料格式無效。");
      return { path: item.path, name: String(item.name || item.path.split("/").pop()).slice(0, 255), extension, mime: String(item.mime || "application/octet-stream"), dataBase64: item.dataBase64 };
    });
    const mappings = {};
    for (const role of ROLES) { const path = input.mappings && input.mappings[role]; if (path != null && (typeof path !== "string" || !paths.has(path))) fail("THEME_TRANSFER_INVALID_MAPPING", "主題映射指向不存在的素材。"); mappings[role] = path || null; }
    const colors = Array.isArray(input.accentColors) ? input.accentColors.filter(value => typeof value === "string" && /^#[\da-f]{6}$/i.test(value)).slice(0, 8) : [];
    if (total > MAX_TOTAL_BYTES) fail("THEME_TRANSFER_SIZE_LIMIT", "主題素材總量超過限制。");
    const roleMappings = {};
    const sourceRoleMappings = input.roleMappings && typeof input.roleMappings === "object" ? input.roleMappings : {};
    if (Object.keys(sourceRoleMappings).length > 500) fail("THEME_TRANSFER_INVALID_SCHEMA", "主題元件映射數量超過 500 個上限。");
    for (const [role, path] of Object.entries(sourceRoleMappings)) {
      if (!/^[a-z][a-z0-9.-]{1,120}$/.test(role) || (path != null && (typeof path !== "string" || !paths.has(path)))) fail("THEME_TRANSFER_INVALID_MAPPING", "主題含有無效的元件角色映射。");
      roleMappings[role] = path || null;
    }
    const roleStateMappings = {};
    const sourceStateMappings = input.roleStateMappings && typeof input.roleStateMappings === "object" ? input.roleStateMappings : {};
    if (Object.keys(sourceStateMappings).length > 100) fail("THEME_TRANSFER_INVALID_SCHEMA", "主題互動狀態配對數量超過 100 個上限。");
    for (const [role, pair] of Object.entries(sourceStateMappings)) {
      if (!/^[a-z][a-z0-9.-]{1,120}$/.test(role) || !pair || typeof pair !== "object" || Array.isArray(pair)) fail("THEME_TRANSFER_INVALID_MAPPING", "主題含有無效的狀態素材配對。");
      const normal = pair.normal == null || pair.normal === "" ? null : pair.normal;
      const hover = pair.hover == null || pair.hover === "" ? null : pair.hover;
      if ((normal !== null && (typeof normal !== "string" || !paths.has(normal))) || (hover !== null && (typeof hover !== "string" || !paths.has(hover)))) fail("THEME_TRANSFER_INVALID_MAPPING", "狀態素材配對指向不存在的素材。");
      const fit = ["contain", "cover", "fill", "none", "scale-down"].includes(pair.fit) ? pair.fit : "contain";
      const position = typeof pair.position === "string" && pair.position.length <= 80 && /^[a-zA-Z0-9% .-]+$/.test(pair.position) ? pair.position : "center center";
      roleStateMappings[role] = { normal, hover, fit, position };
    }
    return { schemaVersion: 1, enabled: input.enabled === true, metadata: { name: String(input.metadata && input.metadata.name || "未命名 osu! Skin").slice(0, 200), author: String(input.metadata && input.metadata.author || "").slice(0, 200), version: String(input.metadata && input.metadata.version || "").slice(0, 80) }, mappings, roleMappings, roleStateMappings, skinIniText: typeof input.skinIniText === "string" ? input.skinIniText.slice(0, 1024 * 1024) : "", skinIniSections: input.skinIniSections && typeof input.skinIniSections === "object" ? input.skinIniSections : {}, accentColors: colors, motionPreference: ["system", "reduce", "full"].includes(input.motionPreference) ? input.motionPreference : "system", overrides, assets };
  }
  async function importTheme(text, dependencies) {
    const deps = dependencies || {};
    const decode = deps.atob || global.atob;
    const BlobCtor = deps.Blob || global.Blob;
    if (typeof decode !== "function" || typeof BlobCtor !== "function") fail("THEME_TRANSFER_UNAVAILABLE", "此環境不支援主題匯入。");
    let bundle;
    try { bundle = JSON.parse(String(text)); } catch (_) { fail("THEME_TRANSFER_INVALID_JSON", "主題檔不是有效的 JSON。"); }
    if (!bundle || bundle.format !== FORMAT || bundle.formatVersion !== FORMAT_VERSION) fail("THEME_TRANSFER_UNSUPPORTED_VERSION", "不是支援的 AMQ Skin Theme 檔案或版本。");
    const checked = validateTheme(bundle.theme, false);
    let total = 0;
    const assets = checked.assets.map(item => {
      const binary = decode(item.dataBase64);
      if (binary.length > MAX_ASSET_BYTES) fail("THEME_TRANSFER_SIZE_LIMIT", "單一圖片超過 24 MiB 限制。");
      total += binary.length;
      if (total > MAX_TOTAL_BYTES) fail("THEME_TRANSFER_SIZE_LIMIT", "素材總量超過 120 MiB 限制。");
      const bytes = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
      return { path: item.path, name: item.name, extension: item.extension, mime: item.mime, blob: new BlobCtor([bytes], { type: item.mime || "application/octet-stream" }) };
    });
    const theme = { ...checked, assets };
    return validateTheme(theme, true);
  }
  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.themeTransfer = Object.freeze({ exportTheme, importTheme, validateTheme, format: FORMAT, formatVersion: FORMAT_VERSION, limits: Object.freeze({ assetBytes: MAX_ASSET_BYTES, totalBytes: MAX_TOTAL_BYTES, assets: MAX_ASSETS }) });
})(window);
