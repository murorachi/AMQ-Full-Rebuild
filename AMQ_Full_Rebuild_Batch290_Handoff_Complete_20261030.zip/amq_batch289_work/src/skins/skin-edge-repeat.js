/* Generic, explicit right-edge pixel extension. This is not asserted to reproduce osu!stable's exact songselect-top algorithm. */
(function (global) {
  "use strict";
  function extendRightEdgeRgba(source, sourceWidth, height, targetWidth, edgeWidth, maxPixels) {
    const sw = Number(sourceWidth), h = Number(height), tw = Number(targetWidth), ew = Number(edgeWidth);
    const pixelLimit = Number.isFinite(maxPixels) && maxPixels > 0 ? Math.floor(maxPixels) : 16 * 1024 * 1024;
    const sourcePixels = sw * h;
    const targetPixels = tw * h;
    const sourceBytes = sourcePixels * 4;
    const targetBytes = targetPixels * 4;
    // Canvas and TypedArray implementations commonly impose signed 32-bit or
    // lower implementation limits. Refuse these geometries before allocation.
    if (![sw, h, tw, ew].every(Number.isSafeInteger) || sw <= 0 || h <= 0 || tw <= 0 || ew <= 0 || ew > sw || !source ||
        !Number.isSafeInteger(sourcePixels) || !Number.isSafeInteger(targetPixels) ||
        !Number.isSafeInteger(sourceBytes) || !Number.isSafeInteger(targetBytes) ||
        sourcePixels > pixelLimit || targetPixels > pixelLimit ||
        sourceBytes > 0x7fffffff || targetBytes > 0x7fffffff || source.length !== sourceBytes) return null;
    let output;
    try { output = new Uint8ClampedArray(targetBytes); } catch (_) { return null; }
    const copyWidth = Math.min(sw, tw);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < copyWidth; x++) {
        const from = (y * sw + x) * 4, to = (y * tw + x) * 4;
        output.set(source.slice(from, from + 4), to);
      }
      for (let x = sw; x < tw; x++) {
        const edgeX = sw - ew + ((x - sw) % ew);
        const from = (y * sw + edgeX) * 4, to = (y * tw + x) * 4;
        output.set(source.slice(from, from + 4), to);
      }
    }
    return output;
  }
  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.skinEdgeRepeat = Object.freeze({ extendRightEdgeRgba, contract: "explicit-right-edge-repeat-rgba-v1" });
})(window);
