/* Browser Canvas integration for the explicit AMQ pixel contracts. Not a native osu!stable compositor. */
(function (global) {
  "use strict";

  function canvasError(code, cause) {
    const error = new Error(code);
    error.code = code;
    if (cause) error.cause = cause;
    return error;
  }

  async function decodeImageBlob(blob, options) {
    const opts = options && typeof options === "object" ? options : {};
    const maxBytes = Number.isFinite(opts.maxBytes) && opts.maxBytes > 0 ? opts.maxBytes : 16 * 1024 * 1024;
    const maxPixels = Number.isFinite(opts.maxPixels) && opts.maxPixels > 0 ? opts.maxPixels : 16 * 1024 * 1024;
    if (typeof Blob === "undefined" || !(blob instanceof Blob) || blob.size <= 0 || blob.size > maxBytes) {
      throw canvasError("SKIN_IMAGE_BLOB_INVALID");
    }
    let bitmap;
    try {
      if (typeof global.createImageBitmap !== "function") throw canvasError("SKIN_IMAGE_DECODE_UNAVAILABLE");
      bitmap = await global.createImageBitmap(blob);
    } catch (error) {
      if (error && typeof error.code === "string" && error.code.startsWith("SKIN_")) throw error;
      throw canvasError("SKIN_IMAGE_DECODE_FAILED", error);
    }
    const pixels = bitmap && bitmap.width * bitmap.height;
    const bytes = pixels * 4;
    if (!bitmap || !Number.isSafeInteger(bitmap.width) || !Number.isSafeInteger(bitmap.height) || bitmap.width <= 0 || bitmap.height <= 0 ||
        !Number.isSafeInteger(pixels) || !Number.isSafeInteger(bytes) || pixels > maxPixels || bytes > 0x7fffffff) {
      if (bitmap && typeof bitmap.close === "function") { try { bitmap.close(); } catch (_) {} }
      throw canvasError("SKIN_IMAGE_DIMENSIONS_INVALID");
    }
    return bitmap;
  }

  function createCanvas(width, height, canvasFactory, maxPixels) {
    const limit = Number.isFinite(maxPixels) && maxPixels > 0 ? maxPixels : 16 * 1024 * 1024;
    const pixels = width * height;
    const bytes = pixels * 4;
    if (!Number.isSafeInteger(width) || !Number.isSafeInteger(height) || width <= 0 || height <= 0 ||
        !Number.isSafeInteger(pixels) || !Number.isSafeInteger(bytes) || pixels > limit || bytes > 0x7fffffff) throw canvasError("SKIN_IMAGE_PIXEL_LIMIT_EXCEEDED");
    let canvas;
    try {
      canvas = typeof canvasFactory === "function" ? canvasFactory(width, height) : global.document.createElement("canvas");
      if (!canvas || typeof canvas.getContext !== "function") throw canvasError("SKIN_CANVAS_UNAVAILABLE");
      canvas.width = width;
      canvas.height = height;
      return canvas;
    } catch (error) {
      if (error && error.code === "SKIN_CANVAS_UNAVAILABLE") throw error;
      throw canvasError("SKIN_CANVAS_CREATE_FAILED", error);
    }
  }

  function readImageRgba(image, options) {
    if (!image || !Number.isSafeInteger(image.width) || !Number.isSafeInteger(image.height) || image.width <= 0 || image.height <= 0) {
      throw canvasError("SKIN_IMAGE_DIMENSIONS_INVALID");
    }
    const opts = options && typeof options === "object" ? options : {};
    const maxPixels = Number.isFinite(opts.maxPixels) && opts.maxPixels > 0 ? opts.maxPixels : 16 * 1024 * 1024;
    const pixels = image.width * image.height;
    if (!Number.isSafeInteger(pixels) || !Number.isSafeInteger(pixels * 4) || pixels > maxPixels || pixels * 4 > 0x7fffffff) throw canvasError("SKIN_IMAGE_PIXEL_LIMIT_EXCEEDED");
    const canvas = createCanvas(image.width, image.height, opts.canvasFactory, maxPixels);
    try {
      const context = canvas.getContext("2d", { willReadFrequently: true });
      if (!context) throw canvasError("SKIN_CANVAS_CONTEXT_UNAVAILABLE");
      context.clearRect(0, 0, image.width, image.height);
      context.drawImage(image, 0, 0);
      const result = context.getImageData(0, 0, image.width, image.height);
      if (!result || !result.data || result.data.length !== pixels * 4) throw canvasError("SKIN_CANVAS_READ_FAILED");
      return result;
    } catch (error) {
      if (error && error.code === "SKIN_CANVAS_CONTEXT_UNAVAILABLE") throw error;
      if (error && error.code === "SKIN_CANVAS_READ_FAILED") throw error;
      throw canvasError("SKIN_CANVAS_READ_FAILED", error);
    }
  }

  function renderToCanvas(image, options) {
    const opts = options && typeof options === "object" ? options : {};
    const imageData = readImageRgba(image, opts);
    let pixels = imageData.data;
    let width = imageData.width;
    const height = imageData.height;
    const blend = global.AMQSkins && global.AMQSkins.skinBlend;
    const edge = global.AMQSkins && global.AMQSkins.skinEdgeRepeat;
    if (opts.tint != null) {
      if (!blend || typeof blend.multiplyRgbaBuffer !== "function" || !opts.tint || opts.tint.length < 3) throw canvasError("SKIN_TINT_UNAVAILABLE");
      pixels = blend.multiplyRgbaBuffer(pixels, opts.tint, width, height);
      if (!pixels) throw canvasError("SKIN_TINT_FAILED");
    }
    if (opts.repeat) {
      if (!edge || typeof edge.extendRightEdgeRgba !== "function") throw canvasError("SKIN_EDGE_REPEAT_UNAVAILABLE");
      const targetWidth = Number(opts.repeat.targetWidth);
      const edgeWidth = Number(opts.repeat.edgeWidth);
      const maxPixels = Number.isFinite(opts.maxPixels) && opts.maxPixels > 0 ? opts.maxPixels : 16 * 1024 * 1024;
      if (!Number.isSafeInteger(targetWidth) || targetWidth <= 0 || !Number.isSafeInteger(targetWidth * height) || targetWidth * height > maxPixels) throw canvasError("SKIN_IMAGE_PIXEL_LIMIT_EXCEEDED");
      const expanded = edge.extendRightEdgeRgba(pixels, width, height, targetWidth, edgeWidth, maxPixels);
      if (!expanded) throw canvasError("SKIN_EDGE_REPEAT_INVALID_GEOMETRY");
      pixels = expanded;
      width = targetWidth;
    }
    const canvas = createCanvas(width, height, opts.canvasFactory, opts.maxPixels);
    let context;
    let output;
    try {
      context = canvas.getContext("2d", { willReadFrequently: true });
      if (!context) throw canvasError("SKIN_CANVAS_CONTEXT_UNAVAILABLE");
      output = typeof global.ImageData === "function"
        ? new global.ImageData(new Uint8ClampedArray(pixels), width, height)
        : context.createImageData(width, height);
      if (!output.data || output.data.length !== pixels.length) throw canvasError("SKIN_CANVAS_OUTPUT_GEOMETRY_INVALID");
      if (output.data !== pixels) output.data.set(pixels);
      context.putImageData(output, 0, 0);
    } catch (error) {
      if (error && error.code === "SKIN_CANVAS_CONTEXT_UNAVAILABLE") throw error;
      if (error && error.code === "SKIN_CANVAS_OUTPUT_GEOMETRY_INVALID") throw error;
      throw canvasError("SKIN_CANVAS_WRITE_FAILED", error);
    }
    return canvas;
  }

  async function renderBlobToCanvas(blob, options) {
    const bitmap = await decodeImageBlob(blob, options);
    try {
      return renderToCanvas(bitmap, options);
    } finally {
      if (bitmap && typeof bitmap.close === "function") bitmap.close();
    }
  }

  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.skinCanvasRenderer = Object.freeze({
    decodeImageBlob,
    readImageRgba,
    renderToCanvas,
    renderBlobToCanvas,
    contract: "canvas-decode-read-transform-write-v1",
    nativeStableFidelity: false
  });
})(window);
