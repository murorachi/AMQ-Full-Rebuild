/* Adapts imported osu! Skin assets to AMQ UI roles; never owns quiz or audio state. */
(function (global) {
  "use strict";
  const IMAGE_TYPES = Object.freeze({ png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif", bmp: "image/bmp" });
  const DEFAULT_MAPPINGS = Object.freeze({ background: null, selectionFrame: null, characterOverlay: null });
  // Only roles with a concrete runtime destination are applied. Other mappings remain saved
  // and are reported as unsupported rather than pretending they changed the product UI.
  const ROLE_RUNTIME = Object.freeze({
    "app.home.background": { selector: "#page-home", token: "--amq-skin-role-app-home-background" },
    "app.home.logo": { selector: ".home-brand-mark, .app-brand-icon", token: "--amq-skin-role-app-home-logo" },
    "app.home.primary-action": { selector: ".home-feature-action, .home-main-action", token: "--amq-skin-role-app-home-primary-action" },
    "app.navigation.tab": { selector: "#app-shell-nav", token: "--amq-skin-role-app-navigation-tab" },
    "catalog.item.background": { selector: "#catalog-browser", token: "--amq-skin-role-catalog-item-background" },
    "catalog.item.selected": { selector: "#catalog-browser", token: "--amq-skin-role-catalog-item-selected" },
    "catalog.item.hover": { selector: "#catalog-browser", token: "--amq-skin-role-catalog-item-hover" },
    "catalog.frame.top": { selector: "#catalog-browser", token: "--amq-skin-role-catalog-frame-top" },
    "catalog.frame.bottom": { selector: "#free-player-dock", token: "--amq-skin-role-catalog-frame-bottom" },
    "catalog.song-detail.panel": { selector: "#catalog-selection-details", token: "--amq-skin-role-catalog-song-detail-panel" },
    "catalog.tab": { selector: "#catalog-browser", token: "--amq-skin-role-catalog-tab" },
    "catalog.mode-selector": { selector: "#catalog-mode-selector", token: "--amq-skin-role-catalog-mode-selector" },
    "catalog.filter.background": { selector: ".catalog-sidebar > .catalog-primary-controls", token: "--amq-skin-role-catalog-filter-background" },
    "player.control.play": { selector: "#free-player-play", token: "--amq-skin-role-player-control-play" },
    "player.control.pause": { selector: "#free-player-pause", token: "--amq-skin-role-player-control-pause" },
    "player.progress.track": { selector: "#free-player-progress", token: "--amq-skin-role-player-progress-track" },
    "quiz.answer.input": { selector: "#quiz-answer", token: "--amq-skin-role-quiz-answer-input" },
    "settings.toggle": { selector: "#page-settings input[type=\"checkbox\"]", token: "--amq-skin-role-settings-toggle" },
    "quiz.background": { selector: "#quiz-panel", token: "--amq-skin-role-quiz-background" },
    "quiz.game-hud": { selector: ".quiz-game-hud", token: "--amq-skin-role-quiz-game-hud" },
    "quiz.game-session-summary": { selector: ".quiz-game-session-card", token: "--amq-skin-role-quiz-game-session-summary" },
    "quiz.game-stage": { selector: ".quiz-question-card", token: "--amq-skin-role-quiz-game-stage" },
    "quiz.game-status-rail": { selector: ".quiz-game-rail", token: "--amq-skin-role-quiz-game-status-rail" },
    "quiz.answer.panel": { selector: ".quiz-answer-form", token: "--amq-skin-role-quiz-answer-panel" },
    "quiz.answer.reveal": { selector: "#quiz-answer-reveal", token: "--amq-skin-role-quiz-answer-reveal" },
    "quiz.character.bar": { selector: "#quiz-character-bar", token: "--amq-skin-role-quiz-character-bar" },
    "quiz.character.item": { selector: ".quiz-character-item", token: "--amq-skin-role-quiz-character-item" },
    "multiplayer.room.panel": { selector: "#multiplayer-panel", token: "--amq-skin-role-multiplayer-room-panel" },
    "multiplayer.lobby.tab": { selector: '[data-skin-component="multiplayer.lobby.source-tabs"]', token: "--amq-skin-role-multiplayer-lobby-tab" },
    "multiplayer.lobby.room-list": { selector: '[data-skin-component="multiplayer.lobby.room-list"]', token: "--amq-skin-role-multiplayer-lobby-room-list" },
    "multiplayer.lobby.create-room": { selector: '[data-skin-component="multiplayer.lobby.create-room"]', token: "--amq-skin-role-multiplayer-lobby-create-room" },
    "player.dock.background": { selector: "#free-player-dock", token: "--amq-skin-role-player-dock-background" },
    "learning.progress.panel": { selector: "#statistics-dashboard", token: "--amq-skin-role-learning-progress-panel" },
    "settings.panel": { selector: "#page-settings", token: "--amq-skin-role-settings-panel" },
    "app.navigation.back": { selector: "#app-back", token: "--amq-skin-role-app-navigation-back" },
    "app.home.welcome-visual": { selector: ".home-feature-art", token: "--amq-skin-role-app-home-welcome-visual" },
    "quiz.timer": { selector: "#quiz-timer", token: "--amq-skin-role-quiz-timer" },
    "results.panel": { selector: "#quiz-round-results", token: "--amq-skin-role-results-panel" },
    "results.primary-action": { selector: "#quiz-round-results .results-primary-action, #results-empty .results-primary-action", token: "--amq-skin-role-results-primary-action" },
    "feedback.error": { selector: '[role="alert"]', token: "--amq-skin-role-feedback-error" },
    "feedback.warning": { selector: ".notice", token: "--amq-skin-role-feedback-warning" },
    "player.progress.thumb": { selector: "#free-player-progress", token: "--amq-skin-role-player-progress-thumb" },
    "multiplayer.member.item": { selector: '[data-skin-component="multiplayer.member-list"]', token: "--amq-skin-role-multiplayer-member-item" },
    "multiplayer.ready-state": { selector: '[data-skin-component="multiplayer.member-list"]', token: "--amq-skin-role-multiplayer-ready-state" },
    "learning.history.item": { selector: "#learning-history-list", token: "--amq-skin-role-learning-history-item" },
    "learning.review.item": { selector: "#learning-review-list", token: "--amq-skin-role-learning-review-item" },
    "settings.dropdown": { selector: "#page-settings select", token: "--amq-skin-role-settings-dropdown" },
    "app.ambient-effect": { selector: ".app-header", token: "--amq-skin-role-app-ambient-effect" }
  });

  function normalizeMappings(value, assets) {
    const mappings = value && typeof value === "object" ? value : {};
    const paths = new Set((Array.isArray(assets) ? assets : []).map(asset => asset && asset.path).filter(path => typeof path === "string"));
    return Object.freeze(Object.fromEntries(Object.keys(DEFAULT_MAPPINGS).map(role => {
      const path = mappings[role];
      return [role, typeof path === "string" && paths.has(path) ? path : null];
    })));
  }
  function targetsFor(doc, selector) {
    if (!doc || !selector) return [];
    if (typeof doc.querySelectorAll === "function") return Array.from(doc.querySelectorAll(selector));
    const one = typeof doc.querySelector === "function" ? doc.querySelector(selector) : null;
    return one ? [one] : [];
  }
  function getRoleSupport(doc) {
    const targetDocument = doc || global.document;
    return Object.freeze(Object.fromEntries(Object.entries(ROLE_RUNTIME).map(([id, config]) => {
      const targets = targetsFor(targetDocument, config.selector);
      return [id, Object.freeze({ supported: targets.length > 0, selector: config.selector, targetCount: targets.length })];
    })));
  }
  const REGION_RUNTIME = Object.freeze({
    home: "#page-home", catalog: "#catalog-browser", quiz: "#quiz-panel", multiplayer: "#multiplayer-panel",
    results: "#quiz-round-results", learning: "#statistics-dashboard", settings: "#page-settings",
    "shared-player": "#free-player-dock", shared: "#app-shell-nav"
  });
  const NON_LENGTH_PROPERTIES = new Set(["opacity", "zIndex", "objectFit", "objectPosition", "display", "color", "backgroundColor", "borderColor", "fontWeight", "textAlign"]);
  function cssProperty(name) { return name.replace(/[A-Z]/g, match => `-${match.toLowerCase()}`); }
  function cssValue(name, value) { return typeof value === "number" && !NON_LENGTH_PROPERTIES.has(name) ? `${value}px` : String(value); }
  function createThemeAdapter(dependencies) {
    const deps = dependencies || {};
    const doc = deps.document || global.document;
    const targetSelector = typeof deps.targetSelector === "string" ? deps.targetSelector : "#catalog-browser";
    const urlApi = deps.URL || global.URL;
    const makeBlob = deps.Blob || global.Blob;
    let activeUrls = [];
    let activeInlineOverrides = [];
    let generation = 0;
    let disposed = false;

    function revokeActive() {
      for (const url of activeUrls) { try { urlApi.revokeObjectURL(url); } catch (_) {} }
      activeUrls = [];
    }
    function restoreInlineOverrides() {
      for (const item of activeInlineOverrides) {
        if (!item.node || !item.node.style) continue;
        if (item.value) item.node.style.setProperty(item.property, item.value, item.priority);
        else item.node.style.removeProperty(item.property);
      }
      activeInlineOverrides = [];
    }
    function reset() {
      generation += 1;
      revokeActive();
      restoreInlineOverrides();
      if (!doc || !doc.documentElement || !doc.body) return;
      const root = doc.documentElement;
      const target = typeof doc.querySelector === "function" ? doc.querySelector(targetSelector) : null;
      if (target) {
        target.style.removeProperty("--amq-skin-background");
        target.style.removeProperty("--amq-skin-selection-frame");
        target.style.removeProperty("--amq-skin-accent");
        delete target.dataset.amqSkinBackground;
        delete target.dataset.amqSkinFrame;
        delete target.dataset.amqSkinActive;
      }
      // Clean legacy root-level tokens without ever applying new theme styles globally.
      root.style.removeProperty("--amq-skin-background");
      root.style.removeProperty("--amq-skin-selection-frame");
      root.style.removeProperty("--amq-skin-accent");
      delete root.dataset.amqSkinBackground;
      delete root.dataset.amqSkinFrame;
      delete root.dataset.amqSkinActive;
      delete doc.body.dataset.amqSkinBackground;
      for (const config of Object.values(ROLE_RUNTIME)) {
        for (const roleTarget of targetsFor(doc, config.selector)) {
          if (roleTarget && roleTarget.style) { roleTarget.style.removeProperty(config.token); roleTarget.style.removeProperty(`${config.token}-hover`); roleTarget.style.removeProperty(`${config.token}-fit`); roleTarget.style.removeProperty(`${config.token}-position`); }
          if (roleTarget && roleTarget.dataset) delete roleTarget.dataset.amqSkinRoleActive;
        }
      }
      const character = doc.getElementById("amq-skin-character");
      if (character) character.remove();
    }
    function blobFor(asset) {
      if (asset.blob && typeof asset.blob.size === "number") return asset.blob;
      if (!asset.data) throw new Error("skin-asset-data-missing");
      const type = IMAGE_TYPES[String(asset.extension || "").toLowerCase()] || "application/octet-stream";
      return new makeBlob([asset.data], { type });
    }
    function validateImage(blob) {
      if (typeof deps.validateImage === "function") return Promise.resolve(deps.validateImage(blob));
      if (typeof global.createImageBitmap === "function") return global.createImageBitmap(blob).then(bitmap => { bitmap.close(); return true; });
      if (typeof global.Image !== "function") return Promise.resolve(true);
      const probe = new global.Image();
      const objectUrl = urlApi.createObjectURL(blob);
      return new Promise((resolve, reject) => {
        probe.onload = () => { urlApi.revokeObjectURL(objectUrl); resolve(true); };
        probe.onerror = () => { urlApi.revokeObjectURL(objectUrl); reject(new Error("skin-image-decode-failed")); };
        probe.src = objectUrl;
      });
    }
    async function apply(theme) {
      if (disposed) return { applied: false, roles: [], warnings: ["theme-adapter-disposed"] };
      reset();
      if (!theme || theme.enabled !== true || !doc || !doc.documentElement || !doc.body) return { applied: false, roles: [], warnings: ["theme-disabled-or-document-unavailable"] };
      // The legacy three-slot adapter is catalog-scoped, but role-aware mappings
      // can target any real page. Do not make the catalog a prerequisite for
      // applying a home/settings/quiz role while the user is on another page.
      const target = typeof doc.querySelector === "function" ? doc.querySelector(targetSelector) : null;
      const declaredRoleMappings = theme.roleMappings && typeof theme.roleMappings === "object" ? theme.roleMappings : {};
      const hasOverrides = theme.overrides && typeof theme.overrides === "object" && (Object.keys(theme.overrides.regions || {}).length > 0 || Object.keys(theme.overrides.components || {}).length > 0);
      if (!target && !Object.values(declaredRoleMappings).some(Boolean) && !hasOverrides) return { applied: false, roles: [], warnings: ["theme-target-unavailable"] };
      const token = generation;
      const assets = Array.isArray(theme.assets) ? theme.assets : [];
      const mappings = normalizeMappings(theme.mappings, assets);
      const byPath = new Map(assets.map(asset => [asset.path, asset]));
      const roles = [];
      const warnings = [];
      const root = doc.documentElement;
      const prefersReduced = theme.motionPreference === "reduce" || (theme.motionPreference === "system" && global.matchMedia && global.matchMedia("(prefers-reduced-motion: reduce)").matches);
      const accent = Array.isArray(theme.accentColors) ? theme.accentColors.find(color => /^#[\da-f]{6}$/i.test(color)) : null;
      if (accent && target && target.style) target.style.setProperty("--amq-skin-accent", accent);
      for (const role of ["background", "selectionFrame", "characterOverlay"]) {
        const path = mappings[role];
        const asset = path && byPath.get(path);
        if (!asset) { if (path) warnings.push(`${role}:mapped-asset-missing`); continue; }
        if (!target) { warnings.push(`${role}:theme-target-unavailable`); continue; }
        let blob;
        try { blob = blobFor(asset); await validateImage(blob); }
        catch (_) { warnings.push(`${role}:image-invalid`); continue; }
        if (token !== generation) return { applied: false, roles: [], warnings: ["theme-application-superseded"] };
        const objectUrl = urlApi.createObjectURL(blob);
        activeUrls.push(objectUrl);
        if (role === "background") {
          target.style.setProperty("--amq-skin-background", `url("${objectUrl}")`);
          target.dataset.amqSkinBackground = "true";
        } else if (role === "selectionFrame") {
          target.style.setProperty("--amq-skin-selection-frame", `url("${objectUrl}")`);
          target.dataset.amqSkinFrame = "true";
        } else {
          let element = doc.getElementById("amq-skin-character");
          if (!element) { element = doc.createElement("img"); element.id = "amq-skin-character"; element.alt = "Skin 角色裝飾"; element.setAttribute("aria-hidden", "true"); element.decoding = "async"; doc.body.append(element); }
          element.src = objectUrl;
          if (prefersReduced) element.dataset.motionReduced = "true";
        }
        roles.push(role);
      }
      const roleMappings = declaredRoleMappings;
      const roleStateMappings = theme.roleStateMappings && typeof theme.roleStateMappings === "object" ? theme.roleStateMappings : {};
      const roleIds = new Set([...Object.keys(roleMappings), ...Object.keys(roleStateMappings)]);
      const renderer = global.AMQSkins && global.AMQSkins.skinRenderer;
      for (const roleId of roleIds) {
        const path = roleMappings[roleId];
        const statePair = roleStateMappings[roleId];
        if (!path && !statePair) continue;
        const config = ROLE_RUNTIME[roleId];
        if (!config) { warnings.push(`${roleId}:unsupported-role`); continue; }
        const roleTargets = targetsFor(doc, config.selector).filter(roleTarget => roleTarget && roleTarget.style);
        if (!roleTargets.length) { warnings.push(`${roleId}:role-target-unavailable`); continue; }
        let normalAsset = null, hoverAsset = null;
        if (statePair) {
          const resolved = renderer && renderer.resolveStatePair
            ? renderer.resolveStatePair(assets, statePair.normal, statePair.hover)
            : { normal: byPath.get(statePair.normal) || null, hover: byPath.get(statePair.hover) || null, complete: Boolean(byPath.get(statePair.normal) && byPath.get(statePair.hover)), fallback: "renderer-unavailable" };
          if (!resolved.complete) { warnings.push(`${roleId}:state-pair-incomplete:${resolved.fallback || "unknown"}`); continue; }
          normalAsset = resolved.normal; hoverAsset = resolved.hover;
        } else {
          normalAsset = path ? byPath.get(path) : null;
          if (!normalAsset) { warnings.push(`${roleId}:mapped-asset-missing`); continue; }
        }
        let normalBlob, hoverBlob;
        try {
          normalBlob = blobFor(normalAsset); await validateImage(normalBlob);
          if (hoverAsset) { hoverBlob = blobFor(hoverAsset); await validateImage(hoverBlob); }
        } catch (_) { warnings.push(`${roleId}:image-invalid`); continue; }
        if (token !== generation) return { applied: false, roles: [], warnings: ["theme-application-superseded"] };
        const normalUrl = urlApi.createObjectURL(normalBlob); activeUrls.push(normalUrl);
        const hoverUrl = hoverBlob ? urlApi.createObjectURL(hoverBlob) : null;
        if (hoverUrl) activeUrls.push(hoverUrl);
        const fit = statePair && renderer ? renderer.fitStyle(statePair.fit, statePair.position) : null;
        roleTargets.forEach(roleTarget => {
          roleTarget.style.setProperty(config.token, `url("${normalUrl}")`);
          if (hoverUrl) roleTarget.style.setProperty(`${config.token}-hover`, `url("${hoverUrl}")`);
          if (fit) {
            const size = fit.objectFit === "contain" ? "contain" : fit.objectFit === "cover" ? "cover" : fit.objectFit;
            roleTarget.style.setProperty(`${config.token}-fit`, size);
            roleTarget.style.setProperty(`${config.token}-position`, fit.objectPosition);
          }
          if (roleTarget.dataset) roleTarget.dataset.amqSkinRoleActive = "true";
        });
        roles.push(roleId);
      }
      const resolver = global.AMQSkins && global.AMQSkins.skinResolver;
      if (theme.overrides && resolver && typeof resolver.normalizeOverrides === "function") {
        const overrides = resolver.normalizeOverrides(theme.overrides);
        if (!overrides) warnings.push("overrides:invalid-schema");
        else {
          const applyStyle = (selector, props, label) => {
            const nodes = targetsFor(doc, selector).filter(node => node && node.style);
            if (!nodes.length) { warnings.push(`${label}:override-target-unavailable`); return; }
            for (const node of nodes) for (const [name, value] of Object.entries(props)) {
              if (!resolver.validStyle(name, value)) continue;
              const property = cssProperty(name);
              activeInlineOverrides.push({ node, property, value: node.style.getPropertyValue(property), priority: node.style.getPropertyPriority(property) });
              node.style.setProperty(property, cssValue(name, value));
            }
            roles.push(`${label}:layout`);
          };
          for (const [region, props] of Object.entries(overrides.regions)) {
            if (REGION_RUNTIME[region]) applyStyle(REGION_RUNTIME[region], props, `region.${region}`);
            else warnings.push(`region.${region}:unsupported-region`);
          }
          for (const [roleId, props] of Object.entries(overrides.components)) {
            const config = ROLE_RUNTIME[roleId];
            if (config) applyStyle(config.selector, props, `component.${roleId}`);
            else warnings.push(`component.${roleId}:unsupported-role`);
          }
        }
      }
      if (roles.length && target && target.dataset) target.dataset.amqSkinActive = "true";
      return { applied: roles.length > 0, roles, warnings, unsupportedRoles: warnings.filter(item => item.endsWith(":unsupported-role")).map(item => item.slice(0, -":unsupported-role".length)) };
    }
    function dispose() { if (disposed) return false; disposed = true; reset(); return true; }
    return Object.freeze({ apply, reset, dispose, normalizeMappings });
  }
  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.themeAdapter = Object.freeze({ createThemeAdapter, normalizeMappings, getRoleSupport, runtimeRoles: Object.freeze(Object.keys(ROLE_RUNTIME)), defaultMappings: DEFAULT_MAPPINGS });
})(window);
