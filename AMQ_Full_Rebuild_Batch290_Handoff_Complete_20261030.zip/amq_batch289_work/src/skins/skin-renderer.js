/* Pure rendering primitives for osu! Skin assets. These helpers do not claim native stable blend/tint or edge-repeat support. */
(function (global) {
  "use strict";
  const FITS = new Set(["contain", "cover", "fill", "none", "scale-down"]);
  function logicalSize(width, height, filename, scaleOverride) {
    const w = Number(width), h = Number(height);
    if (!Number.isFinite(w) || !Number.isFinite(h) || w <= 0 || h <= 0) return null;
    const scale = Number.isFinite(Number(scaleOverride)) && Number(scaleOverride) > 0
      ? Number(scaleOverride) : /@2x\.[^./]+$/i.test(String(filename || "")) ? 2 : 1;
    return Object.freeze({ width: w / scale, height: h / scale, scale, highDensity: scale > 1 });
  }
  function fitStyle(mode, position) {
    const fit = FITS.has(mode) ? mode : "contain";
    return Object.freeze({ objectFit: fit, objectPosition: typeof position === "string" && position.trim() ? position : "center center" });
  }
  function resolveStatePair(assets, normalName, hoverName) {
    const list = Array.isArray(assets) ? assets : [];
    const byPath = new Map(list.filter(item => item && typeof item.path === "string").map(item => [item.path, item]));
    const byName = new Map();
    for (const item of list) if (item && typeof item.path === "string") {
      const key = item.path.split(/[\\/]/).pop().toLowerCase();
      if (!byName.has(key)) byName.set(key, item);
    }
    const resolve = value => {
      const requested = String(value || "");
      if (!requested) return null;
      return byPath.get(requested) || (!requested.includes("/") && !requested.includes("\\") ? byName.get(requested.toLowerCase()) : null) || null;
    };
    const normal = resolve(normalName);
    const hover = resolve(hoverName);
    return Object.freeze({ normal, hover, complete: Boolean(normal && hover), fallback: !normal ? "normal-missing" : !hover ? "hover-missing" : null });
  }
  function backgroundStyle(mode, position) {
    if (mode === "cover") return Object.freeze({ backgroundSize: "cover", backgroundPosition: position || "center center", backgroundRepeat: "no-repeat" });
    if (mode === "contain") return Object.freeze({ backgroundSize: "contain", backgroundPosition: position || "center center", backgroundRepeat: "no-repeat" });
    return Object.freeze({ backgroundSize: "auto", backgroundPosition: position || "center center", backgroundRepeat: "no-repeat" });
  }
  global.AMQSkins = global.AMQSkins || {};
  const blend = global.AMQSkins.skinBlend || null;
  const edgeRepeat = global.AMQSkins.skinEdgeRepeat || null;
  const canvas = global.AMQSkins.skinCanvasRenderer || null;
  global.AMQSkins.skinRenderer = Object.freeze({
    logicalSize, fitStyle, resolveStatePair, backgroundStyle,
    decodeImageBlob: canvas ? canvas.decodeImageBlob : null,
    readImageRgba: canvas ? canvas.readImageRgba : null,
    renderToCanvas: canvas ? canvas.renderToCanvas : null,
    renderBlobToCanvas: canvas ? canvas.renderBlobToCanvas : null,
    multiplyTintRgba: blend ? blend.multiplyRgba : null,
    multiplyTintRgbaBuffer: blend ? blend.multiplyRgbaBuffer : null,
    extendRightEdgeRgba: edgeRepeat ? edgeRepeat.extendRightEdgeRgba : null,
    supportedPrimitives: Object.freeze(["logical-size-@2x", "intrinsic-ratio", "contain", "cover-crop", "explicit-state-pair", ...(blend ? ["multiply-rgba-contract-v1"] : []), ...(edgeRepeat ? ["explicit-right-edge-repeat-rgba-v1"] : []), ...(canvas ? ["canvas-decode-read-transform-write-v1"] : [])]),
    nativeStableFidelity: Object.freeze({ multiplicativeTint: false, songselectTopEdgeRepeat: false, note: "Pixel primitives are explicit AMQ renderer contracts; native osu!stable fidelity remains unverified." })
  });
})(window);
