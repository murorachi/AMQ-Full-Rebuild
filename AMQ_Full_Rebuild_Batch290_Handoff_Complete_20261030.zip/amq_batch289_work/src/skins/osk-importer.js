/* Safe, browser-native reader for osu! stable .osk ZIP skin archives. */
(function (global) {
  "use strict";
  const MAX_ARCHIVE_BYTES = 80 * 1024 * 1024;
  const MAX_EXPANDED_BYTES = 120 * 1024 * 1024;
  const MAX_ENTRY_BYTES = 24 * 1024 * 1024;
  const MAX_ENTRIES = 5000;
  const IMAGE_EXTENSIONS = new Set(["png", "jpg", "jpeg", "webp", "gif", "bmp"]);
  const SOUND_EXTENSIONS = new Set(["wav", "mp3", "ogg"]);
  const SUPPORTED_EXTENSIONS = new Set([...IMAGE_EXTENSIONS, ...SOUND_EXTENSIONS]);
  const TEXT_DECODER = typeof TextDecoder === "function" ? new TextDecoder("utf-8") : null;

  function fail(code, message) {
    const error = new Error(message);
    error.code = code;
    throw error;
  }
  function viewOf(input) {
    if (input instanceof ArrayBuffer) return new DataView(input);
    if (ArrayBuffer.isView(input)) return new DataView(input.buffer, input.byteOffset, input.byteLength);
    throw new TypeError("osk input must be an ArrayBuffer or typed array");
  }
  function decodeText(bytes) {
    if (TEXT_DECODER) return TEXT_DECODER.decode(bytes);
    let out = "";
    for (const byte of bytes) out += String.fromCharCode(byte);
    return out;
  }
  async function inflateRaw(bytes, expectedSize, injectedInflater) {
    if (typeof injectedInflater === "function") {
      const result = new Uint8Array(await injectedInflater(bytes));
      if (result.byteLength > MAX_ENTRY_BYTES || result.byteLength > expectedSize) fail("OSK_DECOMPRESSED_SIZE_LIMIT", "Skin 解壓結果超出中央目錄宣告大小或單檔限制。" );
      return result;
    }
    if (typeof DecompressionStream !== "function") fail("OSK_DEFLATE_UNSUPPORTED", "此瀏覽器不支援 ZIP 解壓所需的 DecompressionStream；請更新瀏覽器。" );
    let stream;
    try { stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream("deflate-raw")); }
    catch (_) { fail("OSK_DEFLATE_UNSUPPORTED", "此瀏覽器不支援 deflate-raw ZIP 解壓格式。" ); }
    const reader = stream.getReader();
    const chunks = [];
    let total = 0;
    try {
      while (true) {
        const part = await reader.read();
        if (part.done) break;
        total += part.value.byteLength;
        if (total > MAX_ENTRY_BYTES || total > expectedSize) {
          await reader.cancel();
          fail("OSK_DECOMPRESSED_SIZE_LIMIT", "Skin 解壓結果超出中央目錄宣告大小或單檔限制。" );
        }
        chunks.push(part.value);
      }
    } finally { reader.releaseLock(); }
    const result = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) { result.set(chunk, offset); offset += chunk.byteLength; }
    return result;
  }
  function decodeSkinIni(bytes) {
    if (bytes.length >= 2 && bytes[0] === 0xff && bytes[1] === 0xfe) return new TextDecoder("utf-16le").decode(bytes.subarray(2));
    if (bytes.length >= 2 && bytes[0] === 0xfe && bytes[1] === 0xff) return new TextDecoder("utf-16be").decode(bytes.subarray(2));
    const utf8 = new TextDecoder("utf-8").decode(bytes);
    if (!utf8.includes("\ufffd")) return utf8;
    try { return new TextDecoder("windows-1252").decode(bytes); } catch (_) { return utf8; }
  }
  const ASSET_ROLE_CATALOG = Object.freeze({
    background: Object.freeze({ exact: Object.freeze(["menu-background.jpg", "menu-background.png", "menu-background.webp", "menu-background.jpeg"]), pattern: /(?:^|\/)menu-background\.(?:png|jpe?g|webp)$/i }),
    selectionFrame: Object.freeze({ exact: Object.freeze(["selection-bar.png", "selection-bar@2x.png", "songselect-top.png", "songselect-top@2x.png", "songselect-bottom.png", "songselect-bottom@2x.png", "selection-mode-osu.png", "selection-random.png", "selection-options.png"]), pattern: /(?:selection-bar|selection-mode|selection-random|selection-options|songselect-top|songselect-bottom|ranking-panel)/i }),
    characterOverlay: Object.freeze({ exact: Object.freeze([]), pattern: /(?:character|mascot|avatar|\.(?:png|jpe?g|webp)$)/i })
  });
  function candidatesForRole(entries, role) {
    const definition = ASSET_ROLE_CATALOG[role];
    if (!definition) return [];
    const exact = new Set(definition.exact.map(name => name.toLowerCase()));
    const images = (Array.isArray(entries) ? entries : []).filter(entry => entry && IMAGE_EXTENSIONS.has(String(entry.extension || "").toLowerCase()));
    if (role === "characterOverlay") return images.filter(entry => /(?:character|mascot|avatar|chara|girl|boy|sprite)/i.test(entry.name || entry.path));
    return images.filter(entry => exact.has(String(entry.name || "").toLowerCase()) || definition.pattern.test(entry.path || entry.name || ""));
  }
  function parseSkinIni(text) {
    const result = { name: "未命名 osu! Skin", author: "", version: "", colors: {}, sections: {}, sectionBlocks: [], rawText: String(text || "") };
    let section = "";
    let activeBlock = null;
    for (const rawLine of String(text || "").replace(/^\uFEFF/, "").split(/\r?\n/)) {
      const line = rawLine.trim();
      if (!line || line.startsWith("//") || line.startsWith(";") || line.startsWith("#")) continue;
      const header = line.match(/^\[([^\]]+)\]$/);
      if (header) { section = header[1].trim().toLowerCase(); if (!result.sections[section]) result.sections[section] = {}; activeBlock = { name: section, values: {} }; result.sectionBlocks.push(activeBlock); continue; }
      const pair = line.match(/^([^:]+):\s*(.*?)\s*$/);
      if (!pair) continue;
      const originalKey = pair[1].trim();
      const key = originalKey.toLowerCase();
      const value = pair[2].trim();
      if (section) { result.sections[section][originalKey] = value; if (activeBlock) activeBlock.values[originalKey] = value; }
      if (section === "general" && key === "name") result.name = value || result.name;
      else if (section === "general" && key === "author") result.author = value;
      else if (section === "general" && key === "version") result.version = value;
      else if (section === "colours" && /^combo\d+$/.test(key)) {
        const rgb = value.split(",").slice(0, 3).map(part => Number(part.trim()));
        if (rgb.length === 3 && rgb.every(n => Number.isInteger(n) && n >= 0 && n <= 255)) result.colors[key] = `rgb(${rgb.join(", ")})`;
      }
    }
    return result;
  }
  function auditSkinReferences(entries, skinIni) {
    const byLowerPath = new Map((Array.isArray(entries) ? entries : []).map(entry => [String(entry.path || "").toLowerCase(), entry]));
    const blocks = skinIni && Array.isArray(skinIni.sectionBlocks) ? skinIni.sectionBlocks : [];
    const references = [];
    for (const block of blocks) {
      if (!block || block.name !== "mania") continue;
      for (const [key, rawValue] of Object.entries(block.values || {})) {
        if (!/^(?:KeyImage|NoteImage|StageHint|StageLight|LightingN|LightingL|Hit\d)/i.test(key)) continue;
        const value = String(rawValue || "").trim();
        if (!value || value.toLowerCase() === "_blank") continue;
        if (/^#[0-9a-f]{3,8}$/i.test(value)) continue;
        const base = value.replace(/\\/g, "/").replace(/^\/+/, "");
        const candidates = /\.(?:png|jpe?g|webp|gif|bmp)$/i.test(base) ? [base] : [`${base}.png`, `${base}@2x.png`, `${base}.jpg`, `${base}@2x.jpg`];
        const found = candidates.find(candidate => byLowerPath.has(candidate.toLowerCase()));
        const hdOnly = /@2x(?:\.|$)/i.test(base);
        references.push({ section: block.name, key, value, resolvedPath: found ? byLowerPath.get(found.toLowerCase()).path : null, status: found ? "resolved" : (hdOnly ? "missing-hd-reference" : "missing-reference") });
      }
    }
    const missing = references.filter(item => item.status !== "resolved");
    return Object.freeze({ checked: references.length, resolved: references.length - missing.length, missing: Object.freeze(missing), references: Object.freeze(references) });
  }
  function mapAssets(entries) {
    const byLowerPath = new Map(entries.map(entry => [entry.path.toLowerCase(), entry]));
    const find = (...names) => {
      for (const name of names) {
        const found = byLowerPath.get(name.toLowerCase());
        if (found) return found;
      }
      return null;
    };
    return Object.freeze({
      background: find("menu-background.jpg", "menu-background.png", "menu-background.webp", "menu-background.jpeg"),
      selectionBar: find("selection-bar.png", "selection-bar@2x.png"),
      selectionMode: find("selection-mode.png", "selection-mode@2x.png", "selection-mode-osu.png", "selection-mode-osu@2x.png"),
      selectionRandom: find("selection-random.png", "selection-random@2x.png"),
      selectionOptions: find("selection-options.png", "selection-options@2x.png"),
      songSelectTop: find("songselect-top.png", "songselect-top@2x.png"),
      songSelectBottom: find("songselect-bottom.png", "songselect-bottom@2x.png"),
      rankingPanel: find("ranking-panel.png", "ranking-panel@2x.png"),
      characterCandidates: Object.freeze(candidatesForRole(entries, "characterOverlay"))
    });
  }
  async function read(input, options) {
    const opts = options || {};
    const view = viewOf(input);
    const bytes = new Uint8Array(view.buffer, view.byteOffset, view.byteLength);
    if (bytes.byteLength < 22) fail("OSK_INVALID_ZIP", "檔案太小，不是有效的 .osk ZIP 封裝。" );
    if (bytes.byteLength > MAX_ARCHIVE_BYTES) fail("OSK_ARCHIVE_TOO_LARGE", "Skin 封裝超過 80 MiB 上限。" );
    const dv = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    let eocd = -1;
    const scanStart = Math.max(0, bytes.length - 22 - 65535);
    for (let offset = bytes.length - 22; offset >= scanStart; offset -= 1) {
      if (dv.getUint32(offset, true) === 0x06054b50) { eocd = offset; break; }
    }
    if (eocd < 0) fail("OSK_INVALID_ZIP", "找不到 ZIP 中央目錄，檔案可能損壞。" );
    const disk = dv.getUint16(eocd + 4, true);
    const centralDisk = dv.getUint16(eocd + 6, true);
    const diskEntries = dv.getUint16(eocd + 8, true);
    const totalEntries = dv.getUint16(eocd + 10, true);
    const centralSize = dv.getUint32(eocd + 12, true);
    const centralOffset = dv.getUint32(eocd + 16, true);
    if (disk || centralDisk || diskEntries !== totalEntries || totalEntries === 0xffff || centralOffset === 0xffffffff || centralSize === 0xffffffff) fail("OSK_ZIP64_OR_MULTIDISK", "不支援多磁碟或 ZIP64 格式的 Skin。" );
    if (totalEntries > MAX_ENTRIES || centralOffset + centralSize > bytes.length) fail("OSK_ENTRY_LIMIT", "Skin 檔案數量超出限制或中央目錄不完整。" );
    const entries = [];
    let cursor = centralOffset;
    let expandedTotal = 0;
    let skinIni = null;
    for (let index = 0; index < totalEntries; index += 1) {
      if (cursor + 46 > bytes.length || dv.getUint32(cursor, true) !== 0x02014b50) fail("OSK_INVALID_CENTRAL_DIRECTORY", "Skin 中央目錄項目無效。" );
      const flags = dv.getUint16(cursor + 8, true);
      const method = dv.getUint16(cursor + 10, true);
      const compressedSize = dv.getUint32(cursor + 20, true);
      const uncompressedSize = dv.getUint32(cursor + 24, true);
      const nameLength = dv.getUint16(cursor + 28, true);
      const extraLength = dv.getUint16(cursor + 30, true);
      const commentLength = dv.getUint16(cursor + 32, true);
      const localOffset = dv.getUint32(cursor + 42, true);
      const nameStart = cursor + 46;
      const next = nameStart + nameLength + extraLength + commentLength;
      if (next > bytes.length || localOffset + 30 > bytes.length) fail("OSK_INVALID_CENTRAL_DIRECTORY", "Skin 項目位置超出檔案範圍。" );
      const path = decodeText(bytes.subarray(nameStart, nameStart + nameLength)).replace(/\\/g, "/");
      cursor = next;
      if (!path || path.endsWith("/")) continue;
      if (path.startsWith("/") || /^[a-z]:/i.test(path) || path.split("/").some(part => part === ".." || part === ".")) continue;
      if (flags & 1) continue;
      if (method !== 0 && method !== 8) continue;
      const extension = (path.split(".").pop() || "").toLowerCase();
      const isSkinIni = path.toLowerCase() === "skin.ini" || path.toLowerCase().endsWith("/skin.ini");
      const isSupportedAsset = SUPPORTED_EXTENSIONS.has(extension);
      if (!isSkinIni && !isSupportedAsset) continue;
      if (uncompressedSize > MAX_ENTRY_BYTES) fail("OSK_ENTRY_TOO_LARGE", `Skin 項目 ${path} 超過單檔大小上限。` );
      expandedTotal += uncompressedSize;
      if (expandedTotal > MAX_EXPANDED_BYTES) fail("OSK_EXPANDED_TOO_LARGE", "Skin 解壓後超過 120 MiB 上限。" );
      if (dv.getUint32(localOffset, true) !== 0x04034b50) fail("OSK_INVALID_LOCAL_HEADER", `Skin 項目 ${path} 的檔案標頭無效。` );
      const localNameLength = dv.getUint16(localOffset + 26, true);
      const localExtraLength = dv.getUint16(localOffset + 28, true);
      const dataStart = localOffset + 30 + localNameLength + localExtraLength;
      const dataEnd = dataStart + compressedSize;
      if (dataEnd > bytes.length) fail("OSK_INVALID_ENTRY_DATA", `Skin 項目 ${path} 的資料不完整。` );
      const compressed = bytes.subarray(dataStart, dataEnd);
      let data;
      if (method === 0) data = compressed.slice();
      else data = await inflateRaw(compressed, uncompressedSize, opts.inflateRaw);
      if (data.byteLength !== uncompressedSize) fail("OSK_SIZE_MISMATCH", `Skin 項目 ${path} 解壓後大小不符。` );
      const entry = { path, name: path.split("/").pop(), extension, size: data.byteLength, data };
      entries.push(entry);
      if (isSkinIni && !skinIni) skinIni = parseSkinIni(decodeSkinIni(data));
    }
    if (!entries.length) fail("OSK_NO_SUPPORTED_ASSETS", "找不到可讀取的 skin.ini 或圖片素材。" );
    const mapped = mapAssets(entries);
    const referenceAudit = auditSkinReferences(entries, skinIni);
    return Object.freeze({ format: "osk", metadata: Object.freeze(skinIni || { name: "未命名 osu! Skin", author: "", version: "", colors: {}, sectionBlocks: [] }), referenceAudit,
      entries: Object.freeze(entries), mappings: mapped, skinIniText: skinIni ? skinIni.rawText : "", imageCount: entries.filter(entry => IMAGE_EXTENSIONS.has(entry.extension)).length,
      soundCount: entries.filter(entry => SOUND_EXTENSIONS.has(entry.extension)).length, supportedAssetCount: entries.filter(entry => SUPPORTED_EXTENSIONS.has(entry.extension)).length,
      totalBytes: entries.reduce((sum, entry) => sum + entry.size, 0) });
  }
  global.AMQSkins = global.AMQSkins || {};
  global.AMQSkins.oskImporter = Object.freeze({ read, parseSkinIni, auditSkinReferences, mapAssets, candidatesForRole, assetRoleCatalog: ASSET_ROLE_CATALOG, imageExtensions: Object.freeze(Array.from(IMAGE_EXTENSIONS)), soundExtensions: Object.freeze(Array.from(SOUND_EXTENSIONS)), supportedExtensions: Object.freeze(Array.from(SUPPORTED_EXTENSIONS)), limits: Object.freeze({ archiveBytes: MAX_ARCHIVE_BYTES, expandedBytes: MAX_EXPANDED_BYTES, entryBytes: MAX_ENTRY_BYTES, entries: MAX_ENTRIES }) });
})(window);
