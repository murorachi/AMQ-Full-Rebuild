/* Canonical AMQ quiz-mod rules and selection state. Audio effects are applied by the playback layer, never here. */
(function (global) {
  "use strict";

  const MODS = Object.freeze([
    Object.freeze({ id: "reverse", label: "Reverse", category: "audio", multiplier: 1.12, effect: "reverse-audio" }),
    Object.freeze({ id: "fade-out", label: "Fade Out", category: "audio", multiplier: 1.06, effect: "fade-audio-tail" }),
    Object.freeze({ id: "beat-shuffle", label: "Beat Shuffle", category: "audio", multiplier: 1.12, effect: "shuffle-audio-segments" }),
    Object.freeze({ id: "vocal-only", label: "Vocal Only", category: "source", multiplier: 1, effect: "filter-vocal-track", exclusiveGroup: "audio-source" }),
    Object.freeze({ id: "background-only", label: "Background Only", category: "source", multiplier: 1, effect: "filter-background-track", exclusiveGroup: "audio-source" })
  ]);
  const BY_ID = new Map(MODS.map(mod => [mod.id, mod]));
  const STORAGE_KEY = "amqQuizModsV1";

  function normalizeSelection(value) {
    const input = Array.isArray(value) ? value : value && Array.isArray(value.selected) ? value.selected : [];
    const selected = [];
    const groups = new Set();
    for (const candidate of input) {
      const id = typeof candidate === "string" ? candidate : "";
      const mod = BY_ID.get(id);
      if (!mod || selected.includes(id)) continue;
      if (mod.exclusiveGroup && groups.has(mod.exclusiveGroup)) continue;
      selected.push(id);
      if (mod.exclusiveGroup) groups.add(mod.exclusiveGroup);
    }
    return selected;
  }

  function getMultiplier(selection) {
    return normalizeSelection(selection).reduce((total, id) => total * BY_ID.get(id).multiplier, 1);
  }

  function createQuizModsStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    let selected = [];
    let disposed = false;
    const listeners = new Set();
    const storageKey = typeof deps.storageKey === "string" && deps.storageKey.trim() ? deps.storageKey.trim() : STORAGE_KEY;

    function snapshot() {
      return Object.freeze({ selected: Object.freeze(selected.slice()), multiplier: getMultiplier(selected), activeMods: Object.freeze(selected.map(id => BY_ID.get(id))) });
    }
    function notify() { const state = snapshot(); for (const listener of [...listeners]) { try { listener(state); } catch (_) {} } }
    function persist() {
      if (!storage || typeof storage.setItem !== "function") return false;
      try { storage.setItem(storageKey, JSON.stringify({ version: 1, selected })); return true; } catch (_) { return false; }
    }
    function setSelection(value) {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: snapshot() });
      const next = normalizeSelection(value);
      const changed = next.length !== selected.length || next.some((id, index) => id !== selected[index]);
      if (!changed) return Object.freeze({ accepted: true, changed: false, persisted: true, state: snapshot() });
      selected = next;
      const persisted = persist();
      notify();
      return Object.freeze({ accepted: true, changed: true, persisted, state: snapshot() });
    }
    function toggle(id, enabled) {
      if (!BY_ID.has(id)) return Object.freeze({ accepted: false, reason: "unknown-mod", state: snapshot() });
      const mod = BY_ID.get(id);
      const shouldEnable = enabled === undefined ? !selected.includes(id) : enabled === true;
      const next = selected.filter(item => item !== id && !(shouldEnable && mod.exclusiveGroup && BY_ID.get(item).exclusiveGroup === mod.exclusiveGroup));
      if (shouldEnable) next.push(id);
      return setSelection(next);
    }
    function load() {
      if (disposed) return false;
      if (!storage || typeof storage.getItem !== "function") return false;
      try {
        const raw = storage.getItem(storageKey);
        const parsed = raw ? JSON.parse(raw) : null;
        if (!parsed || parsed.version !== 1 || !Array.isArray(parsed.selected)) return false;
        selected = normalizeSelection(parsed.selected);
        notify();
        return true;
      } catch (_) { return false; }
    }
    function reset() { return setSelection([]); }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      if (disposed) throw new Error("quiz mods store is disposed");
      listeners.add(listener);
      let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function dispose() { if (disposed) return false; disposed = true; listeners.clear(); return true; }

    load();
    return Object.freeze({ getState: snapshot, setSelection, toggle, reset, load, subscribe, dispose, get isDisposed() { return disposed; } });
  }

  global.AMQEngine = global.AMQEngine || {};
  global.AMQEngine.quizMods = Object.freeze({ MODS, STORAGE_KEY, normalizeSelection, getMultiplier, createQuizModsStore });
})(typeof window !== "undefined" ? window : globalThis);
