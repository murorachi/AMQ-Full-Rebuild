/* Pure quiz pool filtering and no-repeat selection. */
(function (global) {
  "use strict";

  const identity = global.AMQData && global.AMQData.identity;
  if (!identity || typeof identity.createIdentity !== "function") {
    throw new Error("data identity module must load before quiz pool");
  }
  function questionIdentity(record) { return identity.createIdentity(record.source || "", record.id); }

  function createQuizPool(records, source) {
    if (!Array.isArray(records)) throw new TypeError("quiz pool records must be an array");
    if (source !== "AMQ" && source !== "EMQ" && source !== "MIX") {
      throw new TypeError("quiz pool source must be AMQ, EMQ, or MIX");
    }
    const result = [];
    const seen = new Set();
    for (const record of records) {
      if (!record || typeof record !== "object" || (source === "MIX" ? record.source !== "AMQ" && record.source !== "EMQ" : record.source !== source)) continue;
      if (typeof record.title !== "string" || !record.title.trim()) continue;
      if (typeof record.artist !== "string" || !record.artist.trim()) continue;
      if (!Array.isArray(record.audioCandidates) || record.audioCandidates.length === 0) continue;
      const key = questionIdentity(record);
      if (seen.has(key)) continue;
      seen.add(key);
      result.push(record);
    }
    return Object.freeze(result);
  }

  function pickUnseen(pool, seenIds, random) {
    if (!Array.isArray(pool)) throw new TypeError("quiz pool must be an array");
    if (!seenIds || Object.prototype.toString.call(seenIds) !== "[object Set]" || typeof seenIds.has !== "function") throw new TypeError("seenIds must be a Set");
    const rng = typeof random === "function" ? random : Math.random;
    const available = pool.filter(record => !seenIds.has(questionIdentity(record)));
    if (!available.length) return null;
    const value = rng();
    if (!Number.isFinite(value) || value < 0 || value >= 1) throw new RangeError("random must return a value in [0, 1)");
    return available[Math.floor(value * available.length)];
  }

  function getQuestionKey(record) {
    if (!record || typeof record !== "object") throw new TypeError("question record is required");
    return questionIdentity(record);
  }

  function srsWeight(record, getCard, timestamp) {
    let card = null;
    try { card = typeof getCard === "function" ? getCard(record) : null; } catch (_) { card = null; }
    if (!card || card.state === "new") return 1.35; // protect a useful new-question share
    if (card.state === "suspended") return 0;
    const dueAt = Number(card.dueAt);
    if (!Number.isFinite(dueAt)) return 1.0;
    if (dueAt > timestamp) return 0.18; // future reviews remain eligible, but less likely
    const overdueDays = Math.max(0, (timestamp - dueAt) / 86400000);
    const grade = Number(card.lastRating);
    const weaknessBoost = grade === 1 ? 1.25 : grade === 2 ? 0.65 : grade === 3 ? 0.25 : grade === 4 ? 0 : 0.4;
    return 1.0 + Math.min(14, overdueDays) * 0.12 + weaknessBoost;
  }

  function pickSrsWeighted(pool, options) {
    if (!Array.isArray(pool)) throw new TypeError("quiz pool must be an array");
    const config = options && typeof options === "object" ? options : {};
    const rng = typeof config.random === "function" ? config.random : Math.random;
    const timestamp = Number.isFinite(config.timestamp) ? config.timestamp : Date.now();
    const getCard = config.getCard;
    const source = config.source === "MIX" ? "MIX" : String(config.source || "AMQ").toUpperCase();
    if (!["AMQ", "EMQ", "MIX"].includes(source)) throw new TypeError("source must be AMQ, EMQ, or MIX");
    const available = pool.filter(record => record && srsWeight(record, getCard, timestamp) > 0);
    if (!available.length) return null;
    let candidates = available;
    if (source === "MIX") {
      const amq = available.filter(record => record.source === "AMQ");
      const emq = available.filter(record => record.source === "EMQ");
      if (amq.length && emq.length) {
        const sourceRoll = rng();
        if (!Number.isFinite(sourceRoll) || sourceRoll < 0 || sourceRoll >= 1) throw new RangeError("random must return a value in [0, 1)");
        candidates = sourceRoll < 2 / 3 ? amq : emq;
      } else candidates = amq.length ? amq : emq;
    }
    const weights = candidates.map(record => srsWeight(record, getCard, timestamp));
    const total = weights.reduce((sum, weight) => sum + weight, 0);
    if (!(total > 0) || !Number.isFinite(total)) return pickUnseen(candidates, new Set(), rng);
    const roll = rng();
    if (!Number.isFinite(roll) || roll < 0 || roll >= 1) throw new RangeError("random must return a value in [0, 1)");
    let cursor = roll * total;
    for (let index = 0; index < candidates.length; index++) {
      cursor -= weights[index];
      if (cursor < 0) return candidates[index];
    }
    return candidates[candidates.length - 1];
  }

  global.AMQEngine = global.AMQEngine || {};
  global.AMQEngine.quizPool = Object.freeze({ createQuizPool, pickUnseen, pickSrsWeighted, getQuestionKey, srsWeight });
})(window);
