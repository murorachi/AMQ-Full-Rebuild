/* Pure answer matching based on behavior observed in the user-provided reference HTML. */
(function (global) {
  "use strict";

  const TARGETS = new Set(["anime", "title", "artist"]);

  function normalizeAnswer(value) {
    return String(value ?? "").normalize("NFKC").toLocaleLowerCase().replace(/[\s\p{C}]/gu, "");
  }

  function asList(value) {
    if (Array.isArray(value)) return value;
    return value == null ? [] : [value];
  }

  function fieldAliases(record, target) {
    const aliases = record && record.aliases;
    if (target === "anime") {
      return [record.animeTitle, record.animeAlternateTitle, record.alternateTitle,
        ...asList(record.workAliases), ...asList(record.animeAliases),
        ...asList(aliases && !Array.isArray(aliases) ? aliases.work : [])];
    }
    if (target === "artist") {
      return [record.artist, ...asList(record.artistAliases),
        ...asList(aliases && !Array.isArray(aliases) ? aliases.artist : [])];
    }
    return [record.title, ...asList(record.titleAliases),
      ...asList(Array.isArray(aliases) ? aliases : []),
      ...asList(aliases && !Array.isArray(aliases) ? aliases.title : [])];
  }

  function uniqueNormalized(values) {
    const result = [];
    const seen = new Set();
    for (const value of values) {
      const normalized = normalizeAnswer(value);
      if (!normalized || seen.has(normalized)) continue;
      seen.add(normalized);
      result.push(normalized);
    }
    return result;
  }

  function signature(record) {
    const title = normalizeAnswer(record && record.title);
    const artist = normalizeAnswer(record && record.artist);
    return title && artist ? `${title}\u0000${artist}` : "";
  }

  function createAnswerEvaluator(records) {
    if (!Array.isArray(records)) throw new TypeError("answer evaluator records must be an array");
    const relatedAMQWorkAliases = new Map();
    for (const record of records) {
      if (!record || record.source !== "AMQ") continue;
      const key = signature(record);
      if (!key) continue;
      if (!relatedAMQWorkAliases.has(key)) relatedAMQWorkAliases.set(key, new Set());
      const aliases = relatedAMQWorkAliases.get(key);
      fieldAliases(record, "anime").forEach(value => {
        const normalized = normalizeAnswer(value);
        if (normalized) aliases.add(normalized);
      });
    }

    function evaluate(record, target, answer, options) {
      if (!record || !TARGETS.has(target)) throw new TypeError("answer target must be anime, title, or artist");
      const candidate = normalizeAnswer(answer);
      if (!candidate) return false;
      const settings = options && typeof options === "object" ? options : {};
      const aliases = uniqueNormalized(fieldAliases(record, target));
      if (aliases.includes(candidate)) return true;

      // The reference accepts another AMQ work title only when the same normalized
      // song title and artist are associated with that work. EMQ intentionally does not.
      if (target === "anime" && record.source === "AMQ") {
        const key = signature(record);
        const related = key ? relatedAMQWorkAliases.get(key) : null;
        if (related && related.has(candidate)) return true;
      }

      if (settings.acceptPartial !== true || candidate.length < 4) return false;
      return aliases.some(alias => candidate.length >= Math.ceil(alias.length * 0.55)
        && (alias.startsWith(candidate) || alias.includes(candidate)));
    }

    function evaluateAll(record, answers, options) {
      const input = answers && typeof answers === "object" ? answers : {};
      return Object.freeze({
        anime: evaluate(record, "anime", input.anime, options),
        artist: evaluate(record, "artist", input.artist, options),
        title: evaluate(record, "title", input.title, options)
      });
    }

    return Object.freeze({ evaluate, evaluateAll, normalizeAnswer });
  }

  global.AMQEngine = global.AMQEngine || {};
  global.AMQEngine.answerEvaluator = Object.freeze({ createAnswerEvaluator, normalizeAnswer });
})(window);
