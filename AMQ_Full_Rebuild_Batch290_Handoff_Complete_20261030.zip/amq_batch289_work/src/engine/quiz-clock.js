/* Single countdown owner for quiz clip time. It never starts until the caller confirms audio playback. */
(function (global) {
  "use strict";

  function createQuizClock(options) {
    const settings = options && typeof options === "object" ? options : {};
    const now = typeof settings.now === "function" ? settings.now : () => Date.now();
    const schedule = typeof settings.setInterval === "function" ? settings.setInterval : global.setInterval.bind(global);
    const unschedule = typeof settings.clearInterval === "function" ? settings.clearInterval : global.clearInterval.bind(global);
    const tickMs = settings.tickMs === undefined ? 100 : settings.tickMs;
    const onTick = typeof settings.onTick === "function" ? settings.onTick : () => {};
    const onTimeout = typeof settings.onTimeout === "function" ? settings.onTimeout : () => {};
    if (!Number.isFinite(tickMs) || tickMs < 10 || tickMs > 1000) throw new RangeError("tickMs must be between 10 and 1000");

    let intervalId = null;
    let deadline = null;
    let remainingMs = 0;
    let running = false;
    let paused = false;
    let disposed = false;

    function secondsLeft() { return Math.ceil(Math.max(0, remainingMs) / 1000); }
    function notifyTick() { try { onTick(secondsLeft(), Object.freeze({ running, paused, remainingMs: Math.max(0, remainingMs) })); } catch (_) {} }
    function clearIntervalTimer() {
      if (intervalId !== null) unschedule(intervalId);
      intervalId = null;
    }
    function tick() {
      if (!running || disposed || deadline === null) return;
      remainingMs = Math.max(0, deadline - now());
      notifyTick();
      if (remainingMs <= 0) {
        clearIntervalTimer();
        running = false;
        paused = false;
        deadline = null;
        try { onTimeout(); } catch (_) {}
      }
    }
    function start(seconds) {
      if (disposed) return false;
      if (!Number.isFinite(seconds) || seconds < 1 || seconds > 120) throw new RangeError("seconds must be between 1 and 120");
      clearIntervalTimer();
      remainingMs = seconds * 1000;
      deadline = now() + remainingMs;
      running = true;
      paused = false;
      intervalId = schedule(tick, tickMs);
      notifyTick();
      return true;
    }
    function pause() {
      if (!running || disposed || deadline === null) return false;
      remainingMs = Math.max(0, deadline - now());
      clearIntervalTimer();
      running = false;
      paused = true;
      deadline = null;
      notifyTick();
      if (remainingMs <= 0) {
        paused = false;
        try { onTimeout(); } catch (_) {}
      }
      return true;
    }
    function resume() {
      if (!paused || disposed) return false;
      if (remainingMs <= 0) {
        paused = false;
        try { onTimeout(); } catch (_) {}
        return true;
      }
      deadline = now() + remainingMs;
      paused = false;
      running = true;
      intervalId = schedule(tick, tickMs);
      notifyTick();
      return true;
    }
    function stop() {
      clearIntervalTimer();
      deadline = null;
      remainingMs = 0;
      running = false;
      paused = false;
      notifyTick();
      return true;
    }
    function dispose() {
      if (disposed) return false;
      stop();
      disposed = true;
      return true;
    }
    return Object.freeze({ start, pause, resume, stop, dispose, getRemainingSeconds: secondsLeft,
      getState: () => Object.freeze({ running, paused, remainingMs: Math.max(0, remainingMs), disposed }) });
  }

  global.AMQEngine = global.AMQEngine || {};
  global.AMQEngine.quizClock = Object.freeze({ createQuizClock });
})(window);
