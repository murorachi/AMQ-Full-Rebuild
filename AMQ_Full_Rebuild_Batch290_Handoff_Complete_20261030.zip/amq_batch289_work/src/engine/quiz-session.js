/* Session coordinator: one quiz engine, one audio service, one countdown clock, one no-repeat pool. */
(function (global) {
  "use strict";

  function createQuizSession(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const records = deps.records;
    const source = deps.source;
    const poolApi = global.AMQEngine && global.AMQEngine.quizPool;
    const evaluatorApi = global.AMQEngine && global.AMQEngine.answerEvaluator;
    const engineApi = global.AMQEngine && global.AMQEngine.quizEngine;
    const clockApi = global.AMQEngine && global.AMQEngine.quizClock;
    const audioApi = global.AMQAudio && global.AMQAudio.audioService;
    if (!poolApi || !evaluatorApi || !engineApi || !clockApi) throw new TypeError("quiz session requires quiz pool, evaluator, engine, and clock modules");
    const pool = poolApi.createQuizPool(records, source);
    const isEligible = typeof deps.isEligible === "function" ? deps.isEligible : () => true;
    let eligibleCache = null;
    function getEligiblePool() {
      if (!eligibleCache) eligibleCache = pool.filter(record => { try { return isEligible(record) !== false; } catch (_) { return false; } });
      return eligibleCache;
    }
    function pickNextAvailable() {
      const available = getEligiblePool().filter(record => !seen.has(poolApi.getQuestionKey(record)));
      if (typeof deps.selectNext === "function") {
        try {
          const selected = deps.selectNext(available, { source, seen: new Set(seen), random });
          if (selected && available.includes(selected)) return selected;
        } catch (_) { /* Selector failure falls back to the established no-repeat policy. */ }
      }
      if (source !== "MIX") return poolApi.pickUnseen(available, seen, random);
      const amq = available.filter(record => record.source === "AMQ");
      const emq = available.filter(record => record.source === "EMQ");
      if (!amq.length && !emq.length) return null;
      if (!amq.length || !emq.length) return poolApi.pickUnseen(amq.length ? amq : emq, seen, random);
      const sourceRoll = random();
      if (!Number.isFinite(sourceRoll) || sourceRoll < 0 || sourceRoll >= 1) throw new RangeError("random must return a value in [0, 1)");
      return poolApi.pickUnseen(sourceRoll < 2 / 3 ? amq : emq, seen, random);
    }
    const questionQueue = Array.isArray(deps.questionQueue) ? deps.questionQueue.map(String) : null;
    let questionQueueIndex = 0;
    const random = typeof deps.random === "function" ? deps.random : Math.random;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    const ownsAudioService = deps.disposeAudioService !== false;
    const audioService = deps.audioService || (audioApi && audioApi.createAudioService({ timeoutMs: deps.audioTimeoutMs }));
    if (!audioService || typeof audioService.play !== "function" || typeof audioService.subscribe !== "function") throw new TypeError("quiz session requires an audio service");
    const evaluator = evaluatorApi.createAnswerEvaluator(records);
    const familiarityStore = deps.familiarityStore && typeof deps.familiarityStore.getLevel === "function"
      && typeof deps.familiarityStore.setLevel === "function" ? deps.familiarityStore : null;
    const historyStore = deps.historyStore && typeof deps.historyStore.recordResult === "function"
      && typeof deps.historyStore.beginRound === "function" ? deps.historyStore : null;
    const getFamiliarity = typeof deps.getFamiliarity === "function" ? deps.getFamiliarity
      : familiarityStore ? record => familiarityStore.getLevel(record) : undefined;
    const engine = engineApi.createQuizEngine({ evaluator, now, getFamiliarity });
    const listeners = new Set();
    const listenerErrors = [];
    const seen = new Set();
    let disposed = false;
    let revokingPlayback = false;
    let suppressEngineNotifications = false;
    let sessionTransitionInProgress = false;
    let persistenceInProgress = false;
    let roundId = null;

    function mutateEngine(callback) {
      const previous = suppressEngineNotifications;
      suppressEngineNotifications = true;
      try { return callback(); }
      finally { suppressEngineNotifications = previous; }
    }
    function mutationBlocked() { return persistenceInProgress || suppressEngineNotifications || sessionTransitionInProgress || revokingPlayback; }
    function blockedResult() {
      return Object.freeze({ accepted: false, reason: revokingPlayback ? "playback-revoking" : persistenceInProgress ? "persistence-in-progress" : "session-transitioning", state: getState() });
    }
    const playbackCoordinator = deps.playbackCoordinator && typeof deps.playbackCoordinator.acquire === "function" ? deps.playbackCoordinator : null;
    const playbackOwnerId = typeof deps.playbackOwnerId === "string" && deps.playbackOwnerId.trim()
      ? deps.playbackOwnerId.trim() : `quiz-session-${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    let playbackLease = null;
    let playbackEpoch = 0;
    let settings = { clipSeconds: 20, autoPlay: true, randomSample: false, clipStartSeconds: 0, autoNextDelaySeconds: 0 };
    const scheduleTimeout = typeof deps.setTimeout === "function" ? deps.setTimeout
      : typeof global.setTimeout === "function" ? global.setTimeout.bind(global)
        : typeof setTimeout === "function" ? setTimeout : () => null;
    const cancelTimeout = typeof deps.clearTimeout === "function" ? deps.clearTimeout
      : typeof global.clearTimeout === "function" ? global.clearTimeout.bind(global)
        : typeof clearTimeout === "function" ? clearTimeout : () => {};
    let autoNextTimer = null;
    let autoNextToken = 0;
    function cancelAutoNext() {
      autoNextToken++;
      if (autoNextTimer !== null) cancelTimeout(autoNextTimer);
      autoNextTimer = null;
    }
    function scheduleAutoNext(result) {
      cancelAutoNext();
      if (!result || !result.accepted || !result.state || !["answered", "timed-out", "revealed"].includes(result.state.phase)) return;
      if (result.state.result && result.state.result.unplayed) return;
      if (settings.autoNextDelaySeconds <= 0 || disposed) return;
      const token = autoNextToken;
      autoNextTimer = scheduleTimeout(() => {
        if (disposed || token !== autoNextToken) return;
        autoNextTimer = null;
        nextQuestion();
      }, settings.autoNextDelaySeconds * 1000);
    }
    let message = "尚未開始猜歌回合";
    let persistenceWarning = "";
    let audioState = typeof audioService.getState === "function" ? audioService.getState() : { status: "idle" };
    let remainingSeconds = 0;

    function notify() {
      if (disposed) return getState();
      const snapshot = getState();
      for (const listener of [...listeners]) {
        if (!listeners.has(listener)) continue;
        try { listener(snapshot); }
        catch (error) {
          listenerErrors.push(Object.freeze({ error, state: snapshot }));
          if (listenerErrors.length > 20) listenerErrors.shift();
        }
      }
      return snapshot;
    }
    function getState() {
      const current = engine.getState();
      return Object.freeze({ ...current, source, roundId, poolSize: getEligiblePool().length, seenCount: seen.size,
        audioStatus: audioState.status || "idle", audioError: audioState.error || null,
        audioErrorInfo: audioState.errorInfo || null,
        audioFailures: Object.freeze((audioState.failures || []).map(item => Object.freeze({ ...item }))),
        audioCandidateIndex: audioState.candidateIndex || null, audioCandidateSource: audioState.candidateSource || null,
        remainingSeconds, message, persistenceWarning, settings: Object.freeze({ ...settings }) });
    }
    const clock = clockApi.createQuizClock({
      now,
      setInterval: deps.setInterval,
      clearInterval: deps.clearInterval,
      tickMs: deps.tickMs === undefined ? 100 : deps.tickMs,
      onTick(seconds) { if (disposed) return; remainingSeconds = seconds; notify(); },
      onTimeout() {
        if (disposed || revokingPlayback) return;
        const result = mutateEngine(() => engine.timeout());
        if (result.accepted) {
          message = "時間到，這題已判定為未答對。";
          persistProgress(result);
        }
        remainingSeconds = 0;
        scheduleAutoNext(result);
        notify();
      }
    });

    function releasePlaybackLease() {
      playbackEpoch += 1;
      const lease = playbackLease;
      playbackLease = null;
      if (lease && typeof lease.release === "function") lease.release();
    }
    function revokePlaybackLease() {
      playbackEpoch += 1;
      playbackLease = null;
      if (disposed) return;
      revokingPlayback = true;
      try {
        cancelAutoNext();
        clock.stop();
        audioService.stop();
        if (typeof audioService.getState === "function") audioState = audioService.getState();
        remainingSeconds = 0;
        const phase = engine.getState().phase;
        if (phase !== "idle" && phase !== "finished") mutateEngine(() => engine.endRound());
        message = "播放權已交給其他模式，本回合已停止。";
      } finally {
        // Keep the mutation guard active while subscribers receive the final
        // revocation snapshot; those callbacks are synchronous and may re-enter
        // session methods before the coordinator's revoke callback returns.
        try { notify(); }
        finally { revokingPlayback = false; }
      }
    }
    function ensurePlaybackLease() {
      if (!playbackCoordinator) return true;
      if (playbackLease && playbackLease.isActive) return true;
      try {
        playbackLease = playbackCoordinator.acquire(playbackOwnerId, { onRevoke: revokePlaybackLease });
        playbackEpoch += 1;
        return Boolean(playbackLease && playbackLease.isActive);
      } catch (error) {
        message = error && error.message ? error.message : "無法取得音訊播放權。";
        return false;
      }
    }
    const unsubscribeEngine = engine.subscribe(() => { if (!suppressEngineNotifications) notify(); });
    const unsubscribeAudio = audioService.subscribe(nextState => {
      if (disposed || revokingPlayback || sessionTransitionInProgress) return;
      if (playbackCoordinator && (!playbackLease || !playbackLease.isActive)) return;
      audioState = nextState;
      const phase = engine.getState().phase;
      if (nextState.status === "playing") {
        if (phase === "ready" && engine.getState().question) {
          const started = mutateEngine(() => engine.markAudioStarted());
          if (started.accepted) {
            message = "音訊播放中，計時已開始。";
            clock.start(settings.clipSeconds);
          }
        } else if (phase === "paused") {
          const resumed = mutateEngine(() => engine.resume());
          if (resumed.accepted) {
            clock.resume();
            message = "已恢復播放與計時。";
          }
        }
      } else if (nextState.status === "blocked") {
        message = "瀏覽器阻擋自動播放。按「播放／恢復音訊」後才會開始計時。";
      } else if (nextState.status === "ready" && phase === "ready") {
        message = "音訊已就緒，計時尚未開始。按「播放／恢復音訊」開始。";
      } else if (nextState.status === "failed" && phase === "ready") {
        message = "所有音源候選都失敗；本題尚未開始計時，可選擇跳過或揭曉。";
      } else if (nextState.status === "paused") {
        message = "音訊已暫停。";
      }
      notify();
    });

    function persistFamiliarity(result) {
      if (!familiarityStore || !result || !result.accepted || !result.state || !result.state.result
        || result.state.result.scored !== true || result.state.result.familiarityLevel === null
        || result.state.result.familiarityLevel === undefined || !result.state.question) return true;
      try {
        const write = familiarityStore.setLevel(result.state.question, result.state.result.familiarityLevel);
        return Boolean(write && write.ok === true);
      } catch (_) {
        return false;
      }
    }
    function persistHistory(result) {
      if (!historyStore || !result || !result.accepted || !result.state || !result.state.result
        || result.state.result.scored !== true || !result.state.question) return true;
      try {
        const write = historyStore.recordResult({ question: result.state.question, result: result.state.result });
        // `persisted` remains the legacy detail-write result. A store may report a
        // successful detail write alongside a failed summary write; surface that
        // partial failure without treating a normally debounced summary as an error.
        return Boolean(write && write.persisted === true && write.summaryFailed !== true);
      } catch (_) {
        return false;
      }
    }
    function persistProgress(result) {
      if (persistenceInProgress) return false;
      persistenceInProgress = true;
      let familiarityOk = false;
      let historyOk = false;
      try {
        familiarityOk = persistFamiliarity(result);
        historyOk = persistHistory(result);
      } finally {
        persistenceInProgress = false;
      }
      persistenceWarning = !familiarityOk || !historyOk
        ? "部分進度未能持久化；請檢查瀏覽器儲存空間。" : "";
      return familiarityOk && historyOk;
    }

    function persistRoundCompletion() {
      if (!historyStore || !roundId || typeof historyStore.completeRound !== "function") return true;
      try {
        const result = historyStore.completeRound(roundId);
        if (result && result.ok === true && result.persisted === true) return true;
        persistenceWarning = "回合已結束，但本輪完成狀態未能保存；重新載入後可能無法恢復結果頁。";
        return false;
      } catch (_) {
        persistenceWarning = "回合已結束，但本輪完成狀態保存失敗；重新載入後可能無法恢復結果頁。";
        return false;
      }
    }

    function startRound(options) {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      const config = options && typeof options === "object" ? options : {};
      if (!getEligiblePool().length) return Object.freeze({ accepted: false, reason: "empty-pool", state: getState() });
      if (engine.getState().phase !== "idle" && engine.getState().phase !== "finished") return Object.freeze({ accepted: false, reason: "round-active", state: getState() });
      const clipSeconds = config.clipSeconds === undefined ? 20 : config.clipSeconds;
      if (!Number.isFinite(clipSeconds) || clipSeconds < 1 || clipSeconds > 120) throw new RangeError("clipSeconds must be between 1 and 120");
      const clipStartSeconds = config.clipStartSeconds === undefined ? 0 : config.clipStartSeconds;
      const autoNextDelaySeconds = config.autoNextDelaySeconds === undefined ? 0 : config.autoNextDelaySeconds;
      if (!Number.isFinite(clipStartSeconds) || clipStartSeconds < 0 || clipStartSeconds > 600) throw new RangeError("clipStartSeconds must be between 0 and 600");
      if (!Number.isInteger(autoNextDelaySeconds) || autoNextDelaySeconds < 0 || autoNextDelaySeconds > 30) throw new RangeError("autoNextDelaySeconds must be an integer between 0 and 30");
      settings = { clipSeconds, autoPlay: config.autoPlay !== false, randomSample: config.randomSample === true, clipStartSeconds, autoNextDelaySeconds };
      const started = mutateEngine(() => engine.startRound({
        target: config.target === undefined ? "anime" : config.target,
        questionCount: config.questionCount === undefined ? 25 : config.questionCount,
        instantSeconds: config.instantSeconds === undefined ? 5 : config.instantSeconds,
        acceptPartial: config.acceptPartial === true,
        keepHigher: config.keepHigher !== false
      }));
      if (!started.accepted) return Object.freeze({ accepted: false, reason: started.reason, state: getState() });
      // Do not let a failed new start expose the previous round's result view.
      roundId = null;
      persistenceWarning = "";
      if (!ensurePlaybackLease()) {
        mutateEngine(() => engine.endRound());
        releasePlaybackLease();
        notify();
        return Object.freeze({ accepted: false, reason: "playback-owner-unavailable", state: getState() });
      }
      seen.clear();
      questionQueueIndex = 0;
      message = "回合已開始，正在準備第一題。";
      if (historyStore) {
        try {
          const round = historyStore.beginRound();
          roundId = round && round.ok === true && typeof round.roundId === "string" ? round.roundId : null;
          if (!roundId) persistenceWarning = "歷史紀錄未能建立本輪識別碼；本輪結果無法可靠歸屬。";
          else if (round.warning === "previous-result-clear-failed" || round.previousResultClear && round.previousResultClear.persisted === false) {
            persistenceWarning = "上一輪完成結果指標清除失敗；本輪仍可進行，但重新載入時可能恢復上一輪結果。請勿將恢復的舊結果視為本輪成績。";
          }
        } catch (_) { persistenceWarning = "歷史紀錄初始化失敗；本回合紀錄可能不完整。"; }
      }
      return nextQuestion();
    }

    function nextQuestion() {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      cancelAutoNext();
      const current = engine.getState();
      const allowed = current.phase === "ready" && !current.question || ["answered", "timed-out", "revealed"].includes(current.phase);
      if (!allowed) return Object.freeze({ accepted: false, reason: "question-active", state: getState() });
      if (current.questionCount > 0 && current.completedCount >= current.questionCount) {
        audioService.stop(); clock.stop(); mutateEngine(() => engine.endRound()); persistRoundCompletion(); releasePlaybackLease(); message = "本輪題數已完成。";
        return Object.freeze({ accepted: false, reason: "round-complete", state: getState() });
      }
      let question = null;
      if (questionQueue) {
        while (questionQueueIndex < questionQueue.length && !question) {
          const queuedId = questionQueue[questionQueueIndex++];
          const candidate = getEligiblePool().find(record => String(record.id) === queuedId);
          if (candidate && !seen.has(poolApi.getQuestionKey(candidate))) question = candidate;
        }
      } else question = pickNextAvailable();
      if (!question && current.questionCount === 0 && !questionQueue) {
        seen.clear();
        question = pickNextAvailable();
      }
      if (!question) {
        audioService.stop(); clock.stop(); mutateEngine(() => engine.endRound()); persistRoundCompletion(); releasePlaybackLease(); message = "本模式可播放曲目已全部出題，回合提前結束。";
        return Object.freeze({ accepted: false, reason: "pool-exhausted", state: getState() });
      }
      if (!ensurePlaybackLease()) {
        clock.stop(); audioService.stop(); mutateEngine(() => engine.endRound()); releasePlaybackLease(); notify();
        return Object.freeze({ accepted: false, reason: "playback-owner-unavailable", state: getState() });
      }
      let changed;
      sessionTransitionInProgress = true;
      try {
        audioService.stop();
        clock.stop();
        changed = mutateEngine(() => engine.setQuestion(question));
      } finally { sessionTransitionInProgress = false; }
      if (!changed.accepted) return Object.freeze({ accepted: false, reason: changed.reason, state: getState() });
      seen.add(poolApi.getQuestionKey(question));
      message = "正在載入音訊候選；播放成功後才開始倒數。";
      const playbackRequestEpoch = playbackEpoch;
      const pending = audioService.play(question.audioCandidates, { autoPlay: settings.autoPlay, timeoutMs: deps.audioTimeoutMs,
        randomSample: settings.randomSample, clipStartSeconds: settings.clipStartSeconds, clipSeconds: settings.clipSeconds, random });
      if (pending && typeof pending.then === "function") pending.then(result => {
        if (disposed || playbackEpoch !== playbackRequestEpoch || (playbackCoordinator && (!playbackLease || !playbackLease.isActive)) || engine.getState().question !== changed.state.question) return;
        if (result && result.status === "failed") message = "音訊候選全部失敗；未開始計時。";
        else if (result && result.status === "blocked") message = "瀏覽器阻擋自動播放，請手動開始音訊。";
        notify();
      }).catch(error => { if (!disposed && playbackEpoch === playbackRequestEpoch && (!playbackCoordinator || playbackLease && playbackLease.isActive)) { message = error && error.message ? error.message : "音訊服務失敗"; notify(); } });
      notify();
      return Object.freeze({ accepted: true, state: getState() });
    }

    function submitAnswer(answer) {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      const result = mutateEngine(() => engine.submitAnswer(answer));
      if (result.accepted) {
        clock.stop();
        const correct = result.state.result.correct;
        message = result.state.target === "all"
          ? `作答完成：作品${result.state.result.correctByTarget.anime ? "正確" : "錯誤"}、歌手${result.state.result.correctByTarget.artist ? "正確" : "錯誤"}、歌曲${result.state.result.correctByTarget.title ? "正確" : "錯誤"}。`
          : (correct ? "回答正確。" : "回答錯誤。");
        persistProgress(result);
        scheduleAutoNext(result);
      }
      notify();
      return result;
    }
    function reveal() {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      const result = mutateEngine(() => engine.reveal());
      if (result.accepted) { clock.stop(); message = "已揭曉答案，不計分也不增加完成題數。"; scheduleAutoNext(result); }
      notify(); return result;
    }
    function skip() {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      const result = mutateEngine(() => engine.skip());
      if (result.accepted) {
        clock.stop();
        if (result.state.result.unplayed) {
          sessionTransitionInProgress = true;
          try { audioService.stop(); }
          finally { sessionTransitionInProgress = false; }
        }
        message = result.state.result.unplayed ? "音訊尚未開始，已略過且不計分。" : "已略過，視為答錯。";
        persistProgress(result);
        scheduleAutoNext(result);
      }
      notify(); return result;
    }
    function pause() {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      if (engine.getState().phase !== "playing") return Object.freeze({ accepted: false, reason: "not-playing", state: getState() });

      // Freeze/check the deadline while the engine is still playing. If the deadline
      // has elapsed since the last interval tick, clock.pause() synchronously calls
      // onTimeout(); doing engine.pause() first would make that timeout get rejected
      // as a timeout against a paused question and leave the session stuck.
      const clockPaused = clock.pause();
      if (!clockPaused) return Object.freeze({ accepted: false, reason: "clock-not-running", state: getState() });
      if (engine.getState().phase !== "playing") {
        return Object.freeze({ accepted: false, reason: "deadline-reached", state: getState() });
      }

      const result = mutateEngine(() => engine.pause());
      if (!result.accepted) {
        clock.resume();
        return result;
      }
      sessionTransitionInProgress = true;
      try { audioService.pause(); }
      finally { sessionTransitionInProgress = false; }
      message = "已暫停；恢復播放後會繼續剩餘時間。";
      notify(); return Object.freeze({ accepted: true, state: getState() });
    }
    function resumeAudio() {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      if (playbackCoordinator && (!playbackLease || !playbackLease.isActive)) {
        message = "目前播放權已移交，無法恢復音訊。";
        notify();
        return Object.freeze({ accepted: false, reason: "playback-owner-unavailable", state: getState() });
      }
      const accepted = audioService.resume();
      if (!accepted) message = "目前音訊不在可恢復狀態。";
      notify(); return Object.freeze({ accepted, state: getState() });
    }
    function endRound() {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      cancelAutoNext();
      let result;
      sessionTransitionInProgress = true;
      try {
        clock.stop(); audioService.stop();
        result = mutateEngine(() => engine.endRound());
        if (result.accepted) persistRoundCompletion();
        releasePlaybackLease();
        if (result.accepted) message = "回合已結束。";
      } finally { sessionTransitionInProgress = false; }
      notify(); return result;
    }
    function reset() {
      if (disposed) return Object.freeze({ accepted: false, reason: "disposed", state: getState() });
      if (mutationBlocked()) return blockedResult();
      cancelAutoNext();
      let result;
      sessionTransitionInProgress = true;
      try {
        clock.stop(); audioService.stop(); releasePlaybackLease(); seen.clear(); roundId = null;
        result = mutateEngine(() => engine.reset()); message = "回合已重設。";
      } finally { sessionTransitionInProgress = false; }
      notify(); return result;
    }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener);
      let activeSubscription = true;
      return function unsubscribe() { if (!activeSubscription) return; activeSubscription = false; listeners.delete(listener); };
    }
    function dispose() {
      if (disposed) return false;
      disposed = true;
      cancelAutoNext();
      releasePlaybackLease();
      unsubscribeEngine(); unsubscribeAudio();
      clock.dispose();
      if (ownsAudioService && typeof audioService.dispose === "function") audioService.dispose();
      listeners.clear();
      return true;
    }

    return Object.freeze({ startRound, nextQuestion, submitAnswer, reveal, skip, pause, resumeAudio, endRound, reset, dispose,
      getState, subscribe, getSubscriberErrors: () => listenerErrors.slice(), clearSubscriberErrors: () => { listenerErrors.length = 0; },
      getPoolSize: () => getEligiblePool().length, refreshEligibility: () => { eligibleCache = null; return getEligiblePool().length; }, isDisposed: () => disposed });
  }

  global.AMQEngine = global.AMQEngine || {};
  global.AMQEngine.quizSession = Object.freeze({ createQuizSession });
})(window);
