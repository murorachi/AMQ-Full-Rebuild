/* DOM-free quiz state machine. QuizSession coordinates audio playback, persistence, and the single countdown owner. */
(function (global) {
  "use strict";

  const PHASES = new Set(["idle", "ready", "playing", "paused", "answered", "timed-out", "revealed", "finished"]);
  const TARGETS = new Set(["anime", "title", "artist", "all"]);

  function createQuizEngine(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const evaluatorFactory = deps.evaluatorFactory || (global.AMQEngine && global.AMQEngine.answerEvaluator && global.AMQEngine.answerEvaluator.createAnswerEvaluator);
    if (typeof evaluatorFactory !== "function") throw new TypeError("quiz engine requires an answer evaluator factory");
    const evaluator = deps.evaluator || evaluatorFactory(deps.records || []);
    if (!evaluator || typeof evaluator.evaluate !== "function" || typeof evaluator.evaluateAll !== "function") {
      throw new TypeError("quiz engine requires evaluate and evaluateAll functions");
    }
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    const getFamiliarity = typeof deps.getFamiliarity === "function" ? deps.getFamiliarity : question => question && question.familiarityLevel;
    const listeners = new Set();
    const listenerErrors = [];
    let state = freezeState({
      phase: "idle", target: "anime", question: null, questionCount: 25,
      completedCount: 0, roundNumber: 0, startedAt: null, pausedAt: null,
      pausedFrom: null, result: null,
      settings: { instantSeconds: 5, acceptPartial: false, keepHigher: true }
    });

    function freezeState(next) {
      if (next.settings && !Object.isFrozen(next.settings)) next.settings = Object.freeze({ ...next.settings });
      if (next.result && !Object.isFrozen(next.result)) next.result = Object.freeze({ ...next.result });
      return Object.freeze(next);
    }
    function publish(patch) {
      state = freezeState({ ...state, ...patch });
      for (const listener of [...listeners]) {
        if (!listeners.has(listener)) continue;
        try { listener(state); }
        catch (error) {
          listenerErrors.push(Object.freeze({ error, state }));
          if (listenerErrors.length > 20) listenerErrors.shift();
        }
      }
      return state;
    }
    function response(accepted, reason) { return Object.freeze({ accepted, reason: reason || null, state }); }
    function reject(reason) { return response(false, reason); }
    function elapsedSeconds(at) {
      if (state.startedAt === null) return null;
      return Math.max(0, (at - state.startedAt) / 1000);
    }
    function familiarity(correct, elapsed) {
      // Familiarity tracks recognition of the work title only. In all-target mode,
      // the anime/work field is the sole input to this calculation; song and artist
      // correctness must not improve or lower work familiarity.
      if (state.target !== "anime" && state.target !== "all") return null;
      const nextLevel = !correct ? 1 : elapsed !== null && elapsed <= 10 ? 4 : elapsed !== null && elapsed <= 15 ? 3 : 2;
      if (!state.settings.keepHigher || !state.question) return nextLevel;
      let currentLevel = 0;
      try { currentLevel = Number(getFamiliarity(state.question)) || 0; } catch (_) { currentLevel = 0; }
      currentLevel = Math.max(0, Math.min(4, currentLevel));
      return Math.max(currentLevel, nextLevel);
    }
    function resultFor(kind, correct, elapsed, extra) {
      return Object.freeze({ kind, correct, elapsedSeconds: elapsed, target: state.target,
        familiarityLevel: correct === null ? null : familiarity(correct, elapsed),
        scored: correct !== null, ...(extra || {}) });
    }
    function freezeQuestion(question) {
      const copy = { ...question };
      for (const key of ["aliases", "titleAliases", "artistAliases", "workAliases", "animeAliases"]) {
        if (Array.isArray(copy[key])) copy[key] = Object.freeze(copy[key].slice());
      }
      if (copy.aliases && typeof copy.aliases === "object" && !Array.isArray(copy.aliases)) {
        const aliases = { ...copy.aliases };
        for (const key of ["title", "artist", "work"]) if (Array.isArray(aliases[key])) aliases[key] = Object.freeze(aliases[key].slice());
        copy.aliases = Object.freeze(aliases);
      }
      return Object.freeze(copy);
    }

    function validateQuestionCount(value) {
      if (!Number.isSafeInteger(value) || value < 0 || value > 500) throw new RangeError("questionCount must be an integer between 0 and 500");
      return value;
    }

    function startRound(options) {
      if (state.phase !== "idle" && state.phase !== "finished") return reject("round-active");
      const config = options && typeof options === "object" ? options : {};
      const target = config.target === undefined ? "anime" : config.target;
      if (!TARGETS.has(target)) throw new TypeError("target must be anime, title, artist, or all");
      const questionCount = validateQuestionCount(config.questionCount === undefined ? 25 : config.questionCount);
      const instantSeconds = config.instantSeconds === undefined ? 5 : config.instantSeconds;
      if (!Number.isFinite(instantSeconds) || instantSeconds < 1 || instantSeconds > 30) throw new RangeError("instantSeconds must be between 1 and 30");
      const settings = {
        instantSeconds,
        acceptPartial: config.acceptPartial === true,
        keepHigher: config.keepHigher !== false
      };
      publish({ phase: "ready", target, question: null, questionCount, completedCount: 0,
        roundNumber: 0, startedAt: null, pausedAt: null, pausedFrom: null, result: null, settings });
      return response(true);
    }

    function setQuestion(question) {
      if (!["ready", "answered", "timed-out", "revealed"].includes(state.phase)) return reject("invalid-phase");
      if (state.questionCount > 0 && state.completedCount >= state.questionCount) {
        publish({ phase: "finished", question: null, startedAt: null, pausedAt: null, pausedFrom: null });
        return reject("round-complete");
      }
      if (!question || typeof question !== "object" || Array.isArray(question)) throw new TypeError("question must be a record object");
      publish({ phase: "ready", question: freezeQuestion(question), roundNumber: state.completedCount + 1,
        startedAt: null, pausedAt: null, pausedFrom: null, result: null });
      return response(true);
    }

    function markAudioStarted() {
      if (state.phase !== "ready" || !state.question) return reject("question-not-ready");
      const at = now();
      if (!Number.isFinite(at)) throw new TypeError("clock must return a finite number");
      publish({ phase: "playing", startedAt: at, pausedAt: null, pausedFrom: null });
      return response(true);
    }

    function pause() {
      if (!state.question || !["ready", "playing"].includes(state.phase)) return reject("not-pausable");
      const at = now();
      if (!Number.isFinite(at)) throw new TypeError("clock must return a finite number");
      publish({ phase: "paused", pausedAt: at, pausedFrom: state.phase });
      return response(true);
    }

    function resume() {
      if (state.phase !== "paused" || !state.pausedFrom) return reject("not-paused");
      const at = now();
      if (!Number.isFinite(at)) throw new TypeError("clock must return a finite number");
      const shift = state.pausedFrom === "playing" && state.pausedAt !== null ? Math.max(0, at - state.pausedAt) : 0;
      publish({ phase: state.pausedFrom, startedAt: state.startedAt === null ? null : state.startedAt + shift,
        pausedAt: null, pausedFrom: null });
      return response(true);
    }

    function submitAnswer(answer) {
      if (state.phase === "paused") return reject("paused");
      if (state.phase !== "playing" || !state.question) return reject("not-playing");
      const isAll = state.target === "all";
      const supplied = isAll && answer && typeof answer === "object" ? answer : { [state.target]: answer };
      const anyInput = isAll ? [supplied.anime, supplied.artist, supplied.title].some(value => String(value ?? "").trim()) : String(supplied[state.target] ?? "").trim() !== "";
      if (!anyInput) return reject("empty-answer");
      const elapsed = elapsedSeconds(now());
      const evaluated = isAll
        ? evaluator.evaluateAll(state.question, supplied, { acceptPartial: state.settings.acceptPartial })
        : evaluator.evaluate(state.question, state.target, supplied[state.target], { acceptPartial: state.settings.acceptPartial });
      const correctForFamiliarity = isAll ? evaluated.anime : evaluated;
      const result = resultFor("submitted", correctForFamiliarity, elapsed, {
        answers: Object.freeze(isAll ? { anime: String(supplied.anime ?? ""), artist: String(supplied.artist ?? ""), title: String(supplied.title ?? "") } : { [state.target]: String(supplied[state.target] ?? "") }),
        correctByTarget: isAll ? evaluated : null,
        keepHigher: state.settings.keepHigher
      });
      publish({ phase: "answered", completedCount: state.completedCount + 1, startedAt: null, pausedAt: null, pausedFrom: null, result });
      return response(true);
    }

    function timeout() {
      if (state.phase === "paused") return reject("paused");
      if (state.phase !== "playing" || !state.question) return reject("not-playing");
      const elapsed = elapsedSeconds(now());
      const correct = false;
      const result = resultFor("timeout", correct, elapsed, {
        answers: Object.freeze(state.target === "all" ? { anime: "", artist: "", title: "" } : { [state.target]: "" }),
        correctByTarget: state.target === "all" ? Object.freeze({ anime: false, artist: false, title: false }) : null,
        keepHigher: state.settings.keepHigher
      });
      publish({ phase: "timed-out", completedCount: state.completedCount + 1, startedAt: null, pausedAt: null, pausedFrom: null, result });
      return response(true);
    }

    function reveal() {
      if (!state.question || !["ready", "playing"].includes(state.phase)) return reject("not-revealable");
      publish({ phase: "revealed", startedAt: null, pausedAt: null, pausedFrom: null,
        result: resultFor("revealed", null, elapsedSeconds(now()), { answers: null, correctByTarget: null }) });
      return response(true);
    }

    function skip() {
      if (!state.question || !["ready", "playing"].includes(state.phase)) return reject("not-skippable");
      if (state.phase === "ready") {
        publish({ phase: "revealed", startedAt: null, pausedAt: null, pausedFrom: null,
          result: resultFor("unplayed-skip", null, null, { answers: null, correctByTarget: null, unplayed: true }) });
        return response(true);
      }
      const elapsed = elapsedSeconds(now());
      const result = resultFor("skip", false, elapsed, {
        answers: Object.freeze(state.target === "all" ? { anime: "", artist: "", title: "" } : { [state.target]: "" }),
        correctByTarget: state.target === "all" ? Object.freeze({ anime: false, artist: false, title: false }) : null,
        keepHigher: state.settings.keepHigher
      });
      publish({ phase: "answered", completedCount: state.completedCount + 1, startedAt: null, pausedAt: null, pausedFrom: null, result });
      return response(true);
    }

    function endRound() {
      if (state.phase === "idle") return reject("round-not-started");
      publish({ phase: "finished", question: null, startedAt: null, pausedAt: null, pausedFrom: null });
      return response(true);
    }

    function reset() {
      publish({ phase: "idle", target: "anime", question: null, questionCount: 25,
        completedCount: 0, roundNumber: 0, startedAt: null, pausedAt: null,
        pausedFrom: null, result: null,
        settings: { instantSeconds: 5, acceptPartial: false, keepHigher: true } });
      return response(true);
    }

    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener);
      let active = true;
      return function unsubscribe() { if (!active) return; active = false; listeners.delete(listener); };
    }

    return Object.freeze({ startRound, setQuestion, markAudioStarted, pause, resume, submitAnswer, timeout, reveal, skip, endRound, reset,
      getState: () => state, subscribe,
      getSubscriberErrors: () => listenerErrors.slice(),
      clearSubscriberErrors: () => { listenerErrors.length = 0; },
      phases: Object.freeze([...PHASES]) });
  }

  global.AMQEngine = global.AMQEngine || {};
  global.AMQEngine.quizEngine = Object.freeze({ createQuizEngine, phases: Object.freeze([...PHASES]) });
})(window);
