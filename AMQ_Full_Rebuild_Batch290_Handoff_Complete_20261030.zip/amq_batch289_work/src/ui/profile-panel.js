/* Local profile projection over the existing statistics dashboard owner. No duplicate stores or synthetic rank data. */
(function (global) {
  "use strict";
  function mount(options) {
    const deps = options && typeof options === "object" ? options : {};
    const dashboard = deps.dashboard;
    if (!dashboard || typeof dashboard.getSnapshot !== "function" || typeof dashboard.subscribe !== "function") {
      throw new TypeError("profile panel requires the shared statistics dashboard snapshot owner");
    }
    const ids = {
      status: "profile-status", error: "profile-error", summary: "profile-summary",
      quizTotal: "profile-stat-quiz-total", accuracy: "profile-stat-accuracy", works: "profile-stat-work-count",
      srsDue: "profile-stat-srs-due", familiarity: "profile-stat-familiarity", playback: "profile-stat-playback",
      source: "profile-source-breakdown", targets: "profile-target-breakdown", workList: "profile-work-list", empty: "profile-work-empty"
    };
    const elements = Object.fromEntries(Object.entries(ids).map(([key, id]) => [key, global.document.getElementById(id)]));
    const removers = [];
    let disposed = false;
    function setText(element, value) { if (element) element.textContent = String(value ?? ""); }
    function percent(value) { return value === null || value === undefined ? "尚無資料" : `${(value * 100).toFixed(1)}%`; }
    function familiarityTotal(levels) { return [0, 1, 2, 3, 4].reduce((sum, level) => sum + (Number(levels[`level${level}`]) || 0), 0); }
    function render(snapshot) {
      if (disposed) return;
      const current = snapshot || dashboard.getSnapshot();
      if (!current || current.available !== true || !current.report) {
        setText(elements.status, "資料讀取失敗");
        setText(elements.error, `本機個人進度暫不可用：${(current && current.issues || ["統計資料 owner 不可用"]).join("、")}。為避免把讀取錯誤顯示成零，暫停呈現統計。`);
        setText(elements.summary, "請先確認答題歷史、熟悉度、SRS 與播放歷史的本機儲存狀態。");
        for (const key of ["quizTotal", "accuracy", "works", "srsDue", "familiarity", "playback", "source", "targets"]) setText(elements[key], "暫不可用");
        if (elements.workList) elements.workList.replaceChildren();
        if (elements.empty) { elements.empty.hidden = false; setText(elements.empty, "資料讀取失敗，作品進度未顯示。"); }
        return;
      }
      setText(elements.error, "");
      const report = current.report, quiz = report.quiz;
      const srsDue = report.srs.AMQ.due + report.srs.EMQ.due;
      const familiarityCount = familiarityTotal(report.familiarity.AMQ) + familiarityTotal(report.familiarity.EMQ);
      setText(elements.status, quiz.total ? "本機檔案已更新" : "尚無答題資料");
      setText(elements.summary, quiz.total
        ? `已累積 ${quiz.total} 個計分目標紀錄，${report.workProgress.totalWorks} 部作品有答題紀錄。這些數字由本機歷史即時計算，不代表全球排名或遊戲 PP。`
        : "這份個人檔案目前還沒有答題紀錄。開始猜歌後，這裡會依本機保存的真實資料更新，不會填入預設成績。");
      setText(elements.quizTotal, quiz.total.toLocaleString());
      setText(elements.accuracy, percent(quiz.accuracy));
      setText(elements.works, report.workProgress.totalWorks.toLocaleString());
      setText(elements.srsDue, srsDue.toLocaleString());
      setText(elements.familiarity, familiarityCount.toLocaleString());
      setText(elements.playback, report.playback.total.toLocaleString());
      setText(elements.source, ["AMQ", "EMQ"].map(source => `${source}：${quiz.bySource[source].total} 個目標，正確率 ${percent(quiz.bySource[source].accuracy)}`).join("；"));
      setText(elements.targets, [["anime", "作品"], ["title", "歌曲"], ["artist", "歌手"]].map(([target, label]) => `${label}：${quiz.byTarget[target].total} 個目標，正確率 ${percent(quiz.byTarget[target].accuracy)}`).join("；"));
      const works = report.workProgress.works.slice(0, 6);
      if (elements.workList) {
        const items = works.map(work => {
          const item = global.document.createElement("li"); item.className = "profile-work-item";
          const title = global.document.createElement("strong"); title.textContent = String(work.title || "未命名作品");
          const detail = global.document.createElement("span");
          detail.textContent = `${work.source} · ${work.total} 個計分目標 · ${work.uniqueSongs} 首歌曲 · 正確率 ${percent(work.accuracy)}${work.lastAt ? ` · 最近 ${work.lastAt.slice(0, 10)}` : ""}`;
          item.appendChild(title); item.appendChild(detail); return item;
        });
        elements.workList.replaceChildren(...items);
      }
      if (elements.empty) { elements.empty.hidden = works.length > 0; setText(elements.empty, "尚無可歸屬至作品的答題紀錄。"); }
    }
    const unsubscribe = dashboard.subscribe(render);
    removers.push(unsubscribe);
    return Object.freeze({ render: () => render(), dispose() { if (disposed) return false; disposed = true; removers.splice(0).forEach(remove => { try { remove(); } catch (_) {} }); return true; }, get isDisposed() { return disposed; } });
  }
  global.AMQUI = global.AMQUI || {};
  global.AMQUI.profilePanel = Object.freeze({ mount });
})(window);
