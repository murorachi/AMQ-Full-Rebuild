(function (global) {
  "use strict";

  const KEY_LABELS = Object.freeze({
    amqLearningAppSettingsV1: "猜歌設定（含全域 SRS 開關）",
    aniSrsScheduleV1: "AMQ 間隔複習排程",
    amqLearningEmqSrsScheduleV1: "EMQ 間隔複習排程",
    amqLearningQuizHistoryV1: "新版答題詳細歷史",
    amqLearningQuizHistorySummaryV1: "新版答題摘要",
    aniQuizHistory_v1: "舊版答題詳細歷史",
    aniQuizHistorySummaryV1: "舊版答題摘要",
    aniQuizTargetSummaryV1: "舊版目標摘要",
    aniCollection_v2: "作品熟悉度",
    anisongFieldGuide_v1: "舊版作品熟悉度",
    amqLearningFamiliarityV1: "EMQ 作品熟悉度",
    amqSongTagsV1: "歌曲標籤與歌曲關聯",
    aniBlacklistedSongs_v1: "歌曲黑名單",
    aniBlacklistedAnime_v1: "作品黑名單",
    aniCustomPracticeListsV1: "自訂練習清單",
    aniAnimeWatch_v1: "看番狀態"
  });

  function createBackupRestorePanel(options) {
    const opts = options && typeof options === "object" ? options : {};
    const documentApi = opts.document || global.document;
    const api = opts.api || global.AMQPersistence?.backupRestore;
    let storage = opts.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const confirmRestore = opts.confirm || ((message) => global.confirm(message));
    const createObjectURL = opts.createObjectURL || ((blob) => global.URL.createObjectURL(blob));
    const revokeObjectURL = opts.revokeObjectURL || ((url) => global.URL.revokeObjectURL(url));
    const makeBlob = opts.makeBlob || ((parts, settings) => new global.Blob(parts, settings));
    const getElement = (id) => documentApi && documentApi.getElementById(id);
    const elements = {
      export: getElement("backup-export"), file: getElement("backup-file"),
      preflight: getElement("backup-preflight"), restore: getElement("backup-restore"),
      status: getElement("backup-status"), preview: getElement("backup-preview"),
      fileName: getElement("backup-file-name")
    };
    if (!api || !elements.export || !elements.file || !elements.preflight || !elements.restore || !elements.status || !elements.preview) {
      return Object.freeze({ ok: false, reason: "backup-panel-elements-missing", dispose() {} });
    }

    let selectedBackup = null;
    let checkedBackup = null;
    let selectionVersion = 0;
    let restoreInProgress = false;
    let disposed = false;
    const removers = [];
    function listen(element, eventName, handler) {
      element.addEventListener(eventName, handler);
      removers.push(() => element.removeEventListener(eventName, handler));
    }
    function status(message, isError) {
      elements.status.textContent = message;
      elements.status.dataset.state = isError ? "error" : "ok";
      elements.status.setAttribute("role", isError ? "alert" : "status");
    }
    function renderPreview(checked) {
      elements.preview.replaceChildren();
      if (!checked || !checked.ok) {
        elements.preview.hidden = true;
        return;
      }
      const heading = documentApi.createElement("p");
      heading.textContent = `備份版本 ${checked.formatVersion}；包含 ${checked.keys.length} 個資料項目。`;
      elements.preview.append(heading);
      const list = documentApi.createElement("ul");
      for (const key of checked.keys) {
        const item = documentApi.createElement("li");
        item.textContent = KEY_LABELS[key] || key;
        list.append(item);
      }
      elements.preview.append(list);
      const note = documentApi.createElement("p");
      note.textContent = "還原只會處理上列項目；備份中未包含的 key 會維持現狀。還原成功後請重新載入頁面，讓所有 Store 重新讀取資料。";
      elements.preview.append(note);
      elements.preview.hidden = false;
    }
    function resetPreflight() {
      checkedBackup = null;
      elements.preflight.disabled = false;
      elements.restore.disabled = true;
      renderPreview(null);
    }
    async function exportBackup() {
      elements.export.disabled = true;
      try {
        const result = await api.createBackupRestore({ storage, crypto: global.crypto }).exportBackup();
        if (!result.ok) {
          status(`備份匯出失敗：${result.reason || "未知錯誤"}`, true);
          return;
        }
        const filename = `amq-learning-backup-${new Date(result.backup.createdAt).toISOString().replace(/[:.]/g, "-")}.json`;
        const blob = makeBlob([JSON.stringify(result.backup, null, 2)], { type: "application/json;charset=utf-8" });
        const url = createObjectURL(blob);
        const anchor = documentApi.createElement("a");
        anchor.href = url;
        anchor.download = filename;
        anchor.hidden = true;
        documentApi.body.append(anchor);
        anchor.click();
        anchor.remove();
        global.setTimeout(() => revokeObjectURL(url), 0);
        status(`備份已產生並開始下載：${filename}`, false);
      } catch (error) {
        status(`備份匯出失敗：${error?.message || "未知錯誤"}`, true);
      } finally {
        elements.export.disabled = false;
      }
    }
    async function readSelectedFile() {
      if (disposed || restoreInProgress) return;
      const requestVersion = ++selectionVersion;
      resetPreflight();
      selectedBackup = null;
      const file = elements.file.files && elements.file.files[0];
      if (elements.fileName) elements.fileName.textContent = file ? file.name : "尚未選擇備份檔案。";
      if (!file) {
        status("請先選擇備份 JSON 檔案。", true);
        return;
      }
      if (file.size > 50 * 1024 * 1024) {
        status("備份檔案超過 50 MB 上限，已拒絕讀取。", true);
        return;
      }
      try {
        const contents = await file.text();
        if (disposed || requestVersion !== selectionVersion) return;
        selectedBackup = contents;
        status("檔案已讀取；請執行預檢。尚未修改任何資料。", false);
      } catch (error) {
        if (disposed || requestVersion !== selectionVersion) return;
        selectedBackup = null;
        status(`讀取備份檔案失敗：${error?.message || "未知錯誤"}`, true);
      }
    }
    async function preflight() {
      if (disposed || restoreInProgress) return;
      resetPreflight();
      if (selectedBackup === null) {
        status("請先選擇並讀取備份檔案。", true);
        return;
      }
      const requestVersion = selectionVersion;
      const input = selectedBackup;
      elements.preflight.disabled = true;
      try {
        const checked = await api.createBackupRestore({ storage, crypto: global.crypto }).preflight(input);
        if (disposed || requestVersion !== selectionVersion || selectedBackup !== input) return;
        if (!checked.ok) {
          status(`預檢失敗，未修改任何資料：${checked.reason || "未知錯誤"}${checked.key ? `（${checked.key}）` : ""}`, true);
          return;
        }
        checkedBackup = checked;
        renderPreview(checked);
        elements.restore.disabled = restoreInProgress || checked.keys.length === 0;
        status(`預檢通過。共 ${checked.keys.length} 個項目等待確認；目前尚未修改任何資料。`, false);
      } catch (error) {
        if (disposed || requestVersion !== selectionVersion || selectedBackup !== input) return;
        status(`預檢失敗，未修改任何資料：${error?.message || "未知錯誤"}`, true);
      } finally {
        if (!disposed && requestVersion === selectionVersion) elements.preflight.disabled = false;
      }
    }
    async function restore() {
      if (disposed || restoreInProgress) return;
      if (!checkedBackup || !checkedBackup.ok) {
        status("尚無通過預檢的備份，無法還原。", true);
        return;
      }
      const summary = checkedBackup.keys.map((key) => KEY_LABELS[key] || key).join("\n• ");
      const accepted = confirmRestore(`即將覆蓋／刪除以下 ${checkedBackup.keys.length} 個資料項目：\n\n• ${summary}\n\n此操作不可由本工具自動合併。還原成功後需要重新載入頁面。確定繼續？`);
      if (!accepted) {
        status("已取消還原；目前資料未修改。", false);
        return;
      }
      const backupToRestore = checkedBackup;
      restoreInProgress = true;
      elements.restore.disabled = true;
      elements.preflight.disabled = true;
      elements.file.disabled = true;
      elements.export.disabled = true;
      try {
        const result = await api.createBackupRestore({ storage, crypto: global.crypto }).restoreBackup(backupToRestore.backup);
        if (disposed) return;
        if (result.ok) {
          resetPreflight();
          status(`還原完成：已處理 ${result.restoredKeys.length} 個資料項目。請重新載入頁面以套用還原結果。`, false);
        } else if (result.phase === "commit" && result.rolledBack === false) {
          const keys = (result.rollbackErrors || []).map((item) => item.key).filter(Boolean).join("、");
          status(`嚴重警告：還原失敗，且無法確認完整回滾。請立即重新匯出目前資料並檢查：${keys || "部分資料項目"}。原因：${result.reason || "未知錯誤"}`, true);
        } else if (result.phase === "commit" && result.rolledBack === true) {
          status(`還原失敗；已成功回復原始資料。原因：${result.reason || "未知錯誤"}`, true);
        } else {
          resetPreflight();
          status(`還原前驗證失敗，資料未修改：${result.reason || "未知錯誤"}`, true);
        }
      } catch (error) {
        if (!disposed) status(`還原流程發生未預期錯誤，請檢查資料狀態：${error?.message || "未知錯誤"}`, true);
      } finally {
        restoreInProgress = false;
        if (!disposed) {
          elements.file.disabled = false;
          elements.export.disabled = false;
          elements.preflight.disabled = false;
          elements.restore.disabled = !checkedBackup || !checkedBackup.ok || checkedBackup.keys.length === 0;
        }
      }
    }

    listen(elements.export, "click", exportBackup);
    listen(elements.file, "change", readSelectedFile);
    listen(elements.preflight, "click", preflight);
    listen(elements.restore, "click", restore);
    elements.restore.disabled = true;
    status("可匯出目前支援的本機資料，或選擇既有備份先執行預檢。", false);
    return Object.freeze({ ok: true, dispose() { if (disposed) return; disposed = true; selectionVersion += 1; removers.splice(0).forEach((remove) => remove()); } });
  }

  global.AMQUI = global.AMQUI || {};
  global.AMQUI.backupRestorePanel = Object.freeze({ createBackupRestorePanel, keyLabels: KEY_LABELS });
})(typeof window !== "undefined" ? window : globalThis);
