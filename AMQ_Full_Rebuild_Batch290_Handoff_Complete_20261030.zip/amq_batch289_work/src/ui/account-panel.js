/* Account/setup UI and session-scoped remote SRS lifecycle. */
(function (global) {
  "use strict";

  function mount(options) {
    const settings = options && typeof options === "object" ? options : {};
    const quizPanel = settings.quizPanel || null;
    const root = document.getElementById("account-panel");
    if (!root) throw new Error("account panel root is missing");
    const bridgeApi = global.AMQPersistence && global.AMQPersistence.remoteSrsBridge;
    const elements = {
      state: document.getElementById("account-state"), message: document.getElementById("account-message"), error: document.getElementById("account-error"),
      setupFields: document.getElementById("account-setup-fields"), setupForm: document.getElementById("account-setup-form"), setupToken: document.getElementById("account-setup-token"),
      setupUsername: document.getElementById("account-setup-username"), setupPassword: document.getElementById("account-setup-password"),
      guestFields: document.getElementById("account-guest-fields"), loginForm: document.getElementById("account-login-form"), loginUsername: document.getElementById("account-login-username"),
      loginPassword: document.getElementById("account-login-password"), registerForm: document.getElementById("account-register-form"),
      registerUsername: document.getElementById("account-register-username"), registerPassword: document.getElementById("account-register-password"), userFields: document.getElementById("account-user-fields"),
      currentUser: document.getElementById("account-current-user"), googleLogin: document.getElementById("account-google-login"), googleUnavailable: document.getElementById("account-google-unavailable"),
      logout: document.getElementById("account-logout"), syncStatus: document.getElementById("account-sync-status"), syncRetry: document.getElementById("account-sync-retry"), syncReload: document.getElementById("account-sync-reload"),
      googleLink: document.getElementById("account-google-link"), googleUnlink: document.getElementById("account-google-unlink"), googleLinkHelp: document.getElementById("account-google-link-help"),
      passwordForm: document.getElementById("account-password-form"), passwordCurrentField: document.getElementById("account-password-current-field"),
      passwordCurrent: document.getElementById("account-password-current"), passwordNew: document.getElementById("account-password-new")
    };
    const removers = [];
    let disposed = false;
    let serverAvailable = false;
    let setupRequired = false;
    let googleConfigured = false;
    let user = null;
    let bridge = null;
    let bridgeStatus = null;
    let bridgeUnsubscribe = null;
    let bridgeFailure = null;
    let busy = false;
    // Invalidate stale auth/bootstrap completions so an older refresh cannot replace
    // the bridge or UI state belonging to a newer authenticated user.
    let authGeneration = 0;

    function listen(element, type, handler) {
      if (!element) return;
      element.addEventListener(type, handler);
      removers.push(() => element.removeEventListener(type, handler));
    }
    function setError(message) { if (!disposed && elements.error) elements.error.textContent = message || ""; }
    function setMessage(message) { if (!disposed && elements.message) elements.message.textContent = message || ""; }
    async function api(path, options = {}) {
      const response = await global.fetch(path, { credentials: "same-origin", ...options,
        ...(options.body === undefined ? {} : { headers: { "content-type": "application/json", ...(options.headers || {}) } }) });
      let body = null;
      try { body = await response.json(); } catch (_) {}
      if (!response.ok) {
        const detail = body && body.error;
        const error = new Error(detail && detail.message || `伺服器請求失敗（${response.status}）。`);
        error.code = detail && detail.code || "ACCOUNT_REQUEST_FAILED";
        error.status = response.status;
        throw error;
      }
      return body;
    }
    function render() {
      if (disposed) return;
      if (elements.state) elements.state.textContent = !serverAvailable ? "伺服器離線" : user ? "已登入" : setupRequired ? "首次設定" : "未登入";
      if (elements.setupFields) elements.setupFields.hidden = !serverAvailable || !setupRequired || Boolean(user);
      if (elements.guestFields) elements.guestFields.hidden = !serverAvailable || setupRequired || Boolean(user);
      if (elements.userFields) elements.userFields.hidden = !serverAvailable || !user;
      if (elements.currentUser && user) elements.currentUser.textContent = `目前帳號：${user.displayName && user.displayName !== user.username ? `${user.displayName}（帳號：${user.username}）` : user.username}（${user.role === "admin" ? "管理者" : "一般使用者"}；登入方式：${(user.authMethods || []).map(method => method === "google" ? "Google" : "帳號密碼").join("、") || "未知"}）`;
      if (elements.googleLogin) elements.googleLogin.hidden = !serverAvailable || !googleConfigured || setupRequired || Boolean(user);
      if (elements.googleUnavailable) elements.googleUnavailable.hidden = !serverAvailable || googleConfigured || setupRequired || Boolean(user);
      const authMethods = user && Array.isArray(user.authMethods) ? user.authMethods : [];
      const hasPassword = authMethods.includes("password");
      const hasGoogle = authMethods.includes("google");
      if (elements.googleLink) elements.googleLink.hidden = !serverAvailable || !user || !googleConfigured || hasGoogle;
      if (elements.googleUnlink) { elements.googleUnlink.hidden = !serverAvailable || !user || !hasGoogle; elements.googleUnlink.disabled = busy || !hasPassword; elements.googleUnlink.title = hasPassword ? "解除 Google 登入連結" : "請先設定一般帳號密碼，再解除 Google 連結"; }
      if (elements.googleLinkHelp) elements.googleLinkHelp.hidden = !user || !hasGoogle || hasPassword;
      if (elements.passwordForm) elements.passwordForm.hidden = !serverAvailable || !user;
      if (elements.passwordCurrentField) elements.passwordCurrentField.hidden = !hasPassword;
      if (elements.passwordCurrent) elements.passwordCurrent.required = hasPassword;
      if (elements.syncRetry) { elements.syncRetry.hidden = !user || !bridge || !bridgeStatus || !Object.values(bridgeStatus.sources || {}).some(source => source.state === "error"); elements.syncRetry.disabled = busy || Boolean(bridgeStatus && bridgeStatus.state === "saving"); }
      if (elements.syncReload) elements.syncReload.hidden = !user || !(bridgeFailure || bridgeStatus && ["error", "conflict"].includes(bridgeStatus.state));
      if (elements.syncStatus && user) {
        if (bridgeFailure) elements.syncStatus.textContent = `個人 SRS 尚未連線：${bridgeFailure.message}。目前已隔離本機舊排程，沒有自動上傳。`;
        else if (!bridgeStatus) elements.syncStatus.textContent = "正在載入個人伺服器 SRS。";
        else if (bridgeStatus.state === "saving") elements.syncStatus.textContent = "個人 SRS 同步中，請勿關閉伺服器。";
        else if (bridgeStatus.state === "conflict") elements.syncStatus.textContent = "偵測到其他分頁／裝置已更新排程。為避免覆蓋資料，遠端寫入已暫停；可重新載入伺服器排程。";
        else if (bridgeStatus.state === "error") elements.syncStatus.textContent = `遠端 SRS 保存失敗（${bridgeStatus.error && bridgeStatus.error.code || "未知錯誤"}）。最新變更仍保留在本次登入工作階段，可重試；若伺服器 revision 已變更，系統會轉為衝突並停止重送。`;
        else elements.syncStatus.textContent = `個人 AMQ／EMQ SRS 已連線；目前 revision：AMQ ${bridgeStatus.sources.AMQ ? bridgeStatus.sources.AMQ.revision : "?"}、EMQ ${bridgeStatus.sources.EMQ ? bridgeStatus.sources.EMQ.revision : "?"}。`;
        if (bridgeStatus && bridgeStatus.durable === false && !bridgeFailure) elements.syncStatus.textContent += " 此環境無法使用跨重新載入的持久化佇列，未同步變更只保留於本次登入工作階段。";
      }
    }
    async function detachBridge({ restoreLocal = true } = {}) {
      const previous = bridge;
      if (bridgeUnsubscribe) { bridgeUnsubscribe(); bridgeUnsubscribe = null; }
      bridge = null; bridgeStatus = null;
      if (restoreLocal && quizPanel && typeof quizPanel.configureSrsStores === "function") quizPanel.configureSrsStores(null);
      if (previous) {
        try { await previous.flush(); } catch (_) {}
        previous.close();
      }
    }
    async function activateUser(nextUser, generationInput) {
      const generation = Number.isSafeInteger(generationInput) ? generationInput : ++authGeneration;
      if (disposed || generation !== authGeneration) return false;
      user = nextUser;
      setupRequired = false;
      bridgeFailure = null;
      bridgeStatus = null;
      setError("");
      render();
      if (!bridgeApi || !quizPanel || typeof quizPanel.configureSrsStores !== "function") {
        bridgeFailure = new Error("遠端 SRS 模組尚未載入");
        quizPanel && quizPanel.configureSrsStores({ mode: "disabled" });
        render();
        return false;
      }
      const nextBridge = bridgeApi.createRemoteSrsBridge({ userId: nextUser.id });
      try {
        await nextBridge.connect();
        if (disposed || generation !== authGeneration || Number(user && user.id) !== Number(nextUser.id)) {
          nextBridge.close();
          return false;
        }
        bridge = nextBridge;
        bridgeStatus = bridge.getStatus();
        bridgeUnsubscribe = bridge.subscribe(status => { bridgeStatus = status; render(); });
        quizPanel.configureSrsStores(bridge);
        setMessage("已登入私人伺服器。SRS 只會讀寫目前帳號的伺服器排程；本機舊排程不會自動上傳。");
        render();
        return true;
      } catch (error) {
        nextBridge.close();
        if (disposed || generation !== authGeneration || Number(user && user.id) !== Number(nextUser.id)) return false;
        bridgeFailure = error;
        quizPanel.configureSrsStores({ mode: "disabled" });
        setMessage("帳號已登入，但伺服器 SRS 無法載入。為避免顯示其他人的本機排程，SRS 已切換到隔離的暫存空排程。");
        render();
        return false;
      }
    }
    async function refreshRemoteSchedules() {
      if (busy || !user) return;
      const generation = ++authGeneration;
      const expectedUserId = Number(user.id);
      const isCurrent = () => !disposed && generation === authGeneration && Number(user && user.id) === expectedUserId;
      if (typeof global.confirm === "function" && !global.confirm("重新載入會永久捨棄此帳號尚未同步的 SRS 變更，改用伺服器最新排程。要繼續嗎？")) return;
      busy = true; render(); setError("");
      const previous = bridge;
      if (bridgeUnsubscribe) { bridgeUnsubscribe(); bridgeUnsubscribe = null; }
      bridge = null; bridgeStatus = null; bridgeFailure = null;
      if (quizPanel && typeof quizPanel.configureSrsStores === "function") quizPanel.configureSrsStores({ mode: "disabled" });
      if (previous) {
        try { await previous.flush(); } catch (_) {}
        if (!isCurrent()) return;
        if (typeof previous.discardPending === "function") {
          try { await previous.discardPending(); }
          catch (error) {
            if (!isCurrent()) return;
            bridge = previous; bridgeStatus = previous.getStatus(); bridgeFailure = null;
            bridgeUnsubscribe = bridge.subscribe(status => { bridgeStatus = status; render(); });
            if (quizPanel && typeof quizPanel.configureSrsStores === "function") quizPanel.configureSrsStores(bridge);
            setError(`無法安全清除尚未同步的 SRS 佇列（${error.code || "PENDING_QUEUE_DELETE_FAILED"}）；為避免遺失資料，已取消重新載入。`);
            setMessage("清除操作未完整完成；部分來源可能已清除，未清除的佇列仍保留。請先恢復本機持久化儲存能力，再檢查狀態。");
            busy = false; render(); return;
          }
        }
        previous.close();
      }
      if (!isCurrent()) return;
      const nextBridge = bridgeApi.createRemoteSrsBridge({ userId: expectedUserId });
      try {
        await nextBridge.connect();
        if (!isCurrent()) { nextBridge.close(); return; }
        bridge = nextBridge;
        bridgeStatus = bridge.getStatus();
        bridgeUnsubscribe = bridge.subscribe(status => { bridgeStatus = status; render(); });
        quizPanel.configureSrsStores(bridge);
        setMessage("已重新載入伺服器排程。先前未同步的本機工作階段變更已捨棄。");
      } catch (error) {
        nextBridge.close();
        if (!isCurrent()) return;
        bridgeFailure = error;
        setMessage("仍無法載入伺服器排程；目前維持隔離的暫存空排程，不會回退到共用本機 SRS。");
      } finally { if (generation === authGeneration) { busy = false; render(); } }
    }
    async function refreshInitialState() {
      if (disposed || busy) return false;
      const generation = ++authGeneration;
      const isCurrent = () => !disposed && generation === authGeneration;
      try {
        const [setup, googleStatus, me] = await Promise.all([api("/api/setup/status"), api("/api/auth/google/status"), api("/api/auth/me")]);
        if (!isCurrent()) return false;
        setupRequired = setup.setupRequired === true;
        googleConfigured = googleStatus.configured === true;
        serverAvailable = true;
        if (me.user) await activateUser(me.user, generation);
        else {
          const hadAuthenticatedSession = Boolean(user || bridge);
          user = null; bridgeFailure = null; bridgeStatus = null;
          if (hadAuthenticatedSession) await detachBridge({ restoreLocal: true });
          if (!isCurrent()) return false;
          setMessage(setupRequired ? "伺服器尚未建立管理者，請輸入啟動主控台顯示的一次性設定權杖。" : "可使用 Google 或一般帳號登入或註冊；登入後只會讀寫該帳號的個人 SRS。");
        }
        if (!isCurrent()) return false;
        const params = new URLSearchParams(global.location && global.location.search || "");
        if (params.get("account_error") === "setup_required") setError("請先完成此伺服器的首次管理者設定，再使用 Google 登入或建立一般帳號。");
        else if (params.get("account_error") === "google_not_configured") setError("此伺服器尚未設定 Google OAuth，請使用一般帳號登入或註冊。");
        else if (params.get("account_error") === "google_login_failed") setError("Google 登入未完成或驗證失敗。請重試，或使用一般帳號登入。");
        else if (params.get("account_error") === "google_link_failed") setError("Google 連結未完成。請確認仍登入原帳號、該 Google 身分未連結到其他 AMQ 帳號，再重試。");
        if (params.get("auth") === "google_linked") setMessage("Google 身分已連結至目前 AMQ 帳號；不會合併或搬移其他帳號的 SRS。");
        if ((params.has("auth") || params.has("account_error")) && global.history && typeof global.history.replaceState === "function") global.history.replaceState(null, "", (global.location && global.location.pathname || "/") + (global.location && global.location.hash || ""));
        render();
        return true;
      } catch (error) {
        if (!isCurrent()) return false;
        serverAvailable = false;
        setMessage("無法連線到私人伺服器 API。單人本機練習仍可使用；多人帳號與伺服器 SRS 目前不可用。");
        setError(error.message || "伺服器連線失敗");
        render();
        return false;
      }
    }

    listen(elements.setupForm, "submit", async event => {
      event.preventDefault(); if (busy) return;
      busy = true; setError(""); render();
      try {
        const result = await api("/api/setup", { method: "POST", headers: { "x-amq-setup-token": elements.setupToken.value.trim() }, body: JSON.stringify({ username: elements.setupUsername.value.trim(), password: elements.setupPassword.value }) });
        elements.setupPassword.value = ""; elements.setupToken.value = "";
        serverAvailable = true; await activateUser(result.user);
      } catch (error) { setError(error.message); }
      finally { busy = false; render(); }
    });
    listen(elements.loginForm, "submit", async event => {
      event.preventDefault(); if (busy) return;
      busy = true; setError(""); render();
      try {
        const result = await api("/api/auth/login", { method: "POST", body: JSON.stringify({ username: elements.loginUsername.value.trim(), password: elements.loginPassword.value }) });
        elements.loginPassword.value = ""; serverAvailable = true; await activateUser(result.user);
      } catch (error) { setError(error.message); }
      finally { busy = false; render(); }
    });
    listen(elements.registerForm, "submit", async event => {
      event.preventDefault(); if (busy) return;
      busy = true; setError(""); render();
      try {
        const result = await api("/api/auth/register", { method: "POST", body: JSON.stringify({ username: elements.registerUsername.value.trim(), password: elements.registerPassword.value }) });
        elements.registerPassword.value = ""; serverAvailable = true; await activateUser(result.user);
      } catch (error) { setError(error.message); }
      finally { busy = false; render(); }
    });

    listen(elements.passwordForm, "submit", async event => {
      event.preventDefault(); if (busy || !user) return;
      busy = true; setError(""); render();
      try {
        const result = await api("/api/auth/password", { method: "POST", body: JSON.stringify({ currentPassword: elements.passwordCurrent ? elements.passwordCurrent.value : "", password: elements.passwordNew.value }) });
        user = result.user;
        if (elements.passwordCurrent) elements.passwordCurrent.value = "";
        if (elements.passwordNew) elements.passwordNew.value = "";
        setMessage("一般帳號密碼已更新。若之後要解除 Google 連結，請確認帳號密碼可正常登入。");
      } catch (error) { setError(error.message); }
      finally { busy = false; render(); }
    });
    listen(elements.googleUnlink, "click", async () => {
      if (busy || !user || !(user.authMethods || []).includes("google") || !(user.authMethods || []).includes("password")) return;
      if (typeof global.confirm === "function" && !global.confirm("解除後，此 AMQ 帳號將不再使用目前 Google 身分登入。其他 AMQ 帳號與 SRS 不會合併。要繼續嗎？")) return;
      busy = true; setError(""); render();
      try {
        const result = await api("/api/auth/google/unlink", { method: "POST", body: "{}" });
        user = result.user;
        setMessage("Google 登入已解除；目前 AMQ 帳號仍可使用一般帳號密碼登入。其他帳號資料未變更。");
      } catch (error) { setError(error.message); }
      finally { busy = false; render(); }
    });
    listen(elements.logout, "click", async () => {
      if (busy || !user) return;
      const generation = ++authGeneration;
      const logoutUserId = Number(user.id);
      busy = true; setError(""); render();
      try {
        if (bridge) {
          let status;
          try { status = await bridge.flush(); } catch (_) { status = bridge.getStatus(); }
          if (disposed || generation !== authGeneration || Number(user && user.id) !== logoutUserId) return;
          if (status.state === "error" || status.state === "conflict") {
            if (typeof global.confirm === "function" && !global.confirm("部分 SRS 變更尚未同步。登出會捨棄這些未同步變更，仍要登出嗎？")) return;
          }
        }
        if (disposed || generation !== authGeneration || Number(user && user.id) !== logoutUserId) return;
        await api("/api/auth/logout", { method: "POST", body: "{}" });
        if (disposed || generation !== authGeneration) return;
        await detachBridge({ restoreLocal: true });
        if (disposed || generation !== authGeneration) return;
        user = null; bridgeFailure = null; bridgeStatus = null;
        setMessage("已登出並切回本機單人 SRS。伺服器排程不會複製到本機共用資料。");
      } catch (error) {
        if (!disposed && generation === authGeneration) setError(error.message);
      } finally { if (!disposed && generation === authGeneration) { busy = false; render(); } }
    });
    listen(elements.syncRetry, "click", async () => {
      if (busy || !user || !bridge || typeof bridge.retryPending !== "function") return;
      busy = true; render(); setError("");
      try {
        bridgeStatus = await bridge.retryPending();
        if (bridgeStatus.state === "synced") setMessage("未同步的 SRS 變更已保存到目前帳號的伺服器排程。");
        else if (bridgeStatus.state === "conflict") setMessage("伺服器排程已被其他位置更新。為避免覆蓋資料，請先確認後重新載入伺服器排程。");
      } catch (error) { setError(error.message); }
      finally { busy = false; render(); }
    });
    listen(elements.syncReload, "click", refreshRemoteSchedules);

    void refreshInitialState();
    return Object.freeze({
      refresh: refreshInitialState,
      getState: () => Object.freeze({ serverAvailable, setupRequired, googleConfigured, user, bridgeStatus, bridgeFailure: bridgeFailure && bridgeFailure.message }),
      dispose() {
        if (disposed) return false;
        disposed = true;
        ++authGeneration;
        removers.splice(0).forEach(remove => { try { remove(); } catch (_) {} });
        if (bridgeUnsubscribe) { bridgeUnsubscribe(); bridgeUnsubscribe = null; }
        const previous = bridge; bridge = null;
        if (quizPanel && typeof quizPanel.configureSrsStores === "function") quizPanel.configureSrsStores(null);
        if (previous) void previous.flush().finally(() => previous.close());
        return true;
      },
      get isDisposed() { return disposed; }
    });
  }

  global.AMQUI = global.AMQUI || {};
  global.AMQUI.accountPanel = Object.freeze({ mount });
})(window);
