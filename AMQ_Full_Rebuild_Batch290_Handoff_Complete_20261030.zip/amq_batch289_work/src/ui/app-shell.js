/* Page shell: keeps existing feature modules mounted while providing real product navigation. */
(function (global) {
  "use strict";
  function mount() {
    const main = document.querySelector("main");
    if (!main || main.dataset.appShellMounted === "true") return { dispose() {} };
    main.dataset.appShellMounted = "true";
    const originalSections = Array.from(main.children).filter(node => node.tagName === "SECTION");
    const pages = [
      { id: "home", label: "首頁" }, { id: "catalog", label: "選歌" },
      { id: "quiz", label: "猜歌" }, { id: "learning", label: "學習中心" },
      { id: "settings", label: "設定" }, { id: "profile", label: "個人檔案" }, { id: "results", label: "成績結果" }
    ];
    const pageNodes = new Map();
    for (const page of pages) {
      const section = document.createElement("section");
      section.className = `app-page app-page--${page.id}`;
      section.id = `page-${page.id}`;
      section.dataset.appPage = page.id;
      section.setAttribute("aria-label", page.label);
      section.hidden = page.id !== "home";
      pageNodes.set(page.id, section);
    }
    const home = pageNodes.get("home");
    home.innerHTML = `
      <div class="home-dashboard">
        <section class="home-feature" aria-label="選歌" data-skin-component="home.feature">
          <div class="home-feature-art" id="home-feature-art" data-skin-component="home.feature.artwork" data-artwork-status="fallback" aria-hidden="true"><span class="home-brand-mark" data-skin-component="home.logo" role="img" aria-label="AMQ 音樂問號標誌"></span></div>
          <div class="home-feature-copy" data-skin-component="home.feature.copy"><h2 id="home-feature-title">選歌</h2><p id="home-feature-work" hidden></p><button type="button" class="home-feature-action" data-go-page="catalog" data-skin-component="home.feature.action" aria-label="前往選歌">開始 <span aria-hidden="true">›</span></button></div>
        </section>
        <nav class="home-main-actions" aria-label="主要功能">
          <button class="home-main-action" type="button" data-go-page="catalog" data-skin-component="home.menu.catalog"><span class="home-action-icon" aria-hidden="true">♫</span><strong>選歌</strong></button>
          <button class="home-main-action" type="button" data-go-page="quiz" data-skin-component="home.menu.quiz"><span class="home-action-icon" aria-hidden="true">▶</span><strong>猜歌</strong></button>
          <button class="home-main-action" type="button" data-go-page="learning" data-skin-component="home.menu.learning"><span class="home-action-icon" aria-hidden="true">◷</span><strong>學習中心</strong></button>
          <button class="home-main-action" type="button" data-go-page="profile" data-skin-component="home.menu.profile"><span class="home-action-icon" aria-hidden="true">◎</span><strong>個人檔案</strong></button>
          <button class="home-main-action" type="button" data-go-page="results" data-skin-component="home.menu.results"><span class="home-action-icon" aria-hidden="true">▤</span><strong>成績結果</strong></button>
          <button class="home-main-action" type="button" data-go-page="settings" data-skin-component="home.menu.settings"><span class="home-action-icon" aria-hidden="true">⚙</span><strong>設定</strong></button>
        </nav>
        <section class="home-recent" aria-labelledby="home-recent-heading">
          <div class="home-section-heading"><h2 id="home-recent-heading">最近學習</h2><button type="button" data-go-page="results">全部紀錄 <span aria-hidden="true">›</span></button></div>
          <div class="home-recent-list" id="home-recent-list"><div class="home-recent-empty" id="home-recent-empty">尚無學習紀錄</div></div>
        </section>
      </div>`;
    const nav = document.createElement("nav");
    nav.id = "app-shell-nav"; nav.className = "app-shell-nav"; nav.setAttribute("aria-label", "主要導覽");
    nav.innerHTML = `<button id="app-back" class="app-back-button" type="button" data-go-page="home" aria-label="返回首頁">← <span class="app-brand-icon" data-skin-component="home.logo" aria-hidden="true"></span><span>首頁</span></button><div class="app-shell-nav-links">${pages.filter(page => page.id !== "home").map(page => `<button type="button" data-go-page="${page.id}" data-nav-page="${page.id}">${page.label}</button>`).join("")}</div>`;
    const routeStatus = document.getElementById("app-status");
    if (routeStatus) nav.appendChild(routeStatus);
    main.replaceChildren(nav, ...pages.map(page => pageNodes.get(page.id)));

    const placement = {
      catalog: new Set(["catalog-browser", "free-player-dock"]),
      quiz: new Set(["multiplayer-panel", "quiz-panel"]),
      learning: new Set(["statistics-dashboard"]),
      settings: new Set(["workspace-preferences-panel", "vndb-character-settings-panel", "account-panel", "backup-restore-panel", "database-update-panel", "skin-import-panel"]),
      profile: new Set(["profile-panel"]),
      results: new Set(["results-workspace"])
    };
    const pageTitles = { quiz: "猜歌", learning: "學習中心", settings: "設定", profile: "個人檔案", results: "成績結果" };
    for (const [pageId, titleText] of Object.entries(pageTitles)) {
      const intro = document.createElement("header");
      intro.className = `app-page-intro app-page-intro--${pageId}`;
      const heading = document.createElement("h2");
      heading.textContent = titleText;
      intro.appendChild(heading);
      pageNodes.get(pageId).prepend(intro);
    }
    const settingsWorkspace = document.createElement("div");
    settingsWorkspace.className = "settings-workspace";
    settingsWorkspace.setAttribute("aria-label", "設定工作區");
    const settingsQuickNav = document.createElement("nav");
    settingsQuickNav.className = "settings-quick-nav";
    settingsQuickNav.setAttribute("aria-label", "設定分類");
    settingsQuickNav.setAttribute("role", "tablist");
    settingsQuickNav.setAttribute("aria-orientation", "vertical");
    settingsQuickNav.innerHTML = `
      <button type="button" role="tab" aria-selected="true" aria-controls="workspace-preferences-panel" data-settings-jump="workspace-preferences-panel">工作區與快捷鍵</button>
      <button type="button" role="tab" aria-selected="false" aria-controls="vndb-character-settings-panel" data-settings-jump="vndb-character-settings-panel" tabindex="-1">猜歌角色</button>
      <button type="button" role="tab" aria-selected="false" aria-controls="account-panel" data-settings-jump="account-panel" tabindex="-1">帳號</button>
      <button type="button" role="tab" aria-selected="false" aria-controls="backup-restore-panel" data-settings-jump="backup-restore-panel" tabindex="-1">備份與還原</button>
      <button type="button" role="tab" aria-selected="false" aria-controls="database-update-panel" data-settings-jump="database-update-panel" tabindex="-1">曲庫更新</button>
      <button type="button" role="tab" aria-selected="false" aria-controls="skin-import-panel" data-settings-jump="skin-import-panel" tabindex="-1">OSK 外觀</button>`;
    const settingsContent = document.createElement("div");
    settingsContent.className = "settings-content";
    settingsContent.id = "settings-content";
    settingsContent.setAttribute("role", "presentation");
    settingsWorkspace.append(settingsQuickNav, settingsContent);
    pageNodes.get("settings").appendChild(settingsWorkspace);
    for (const section of originalSections) {
      const id = section.id;
      let destination = "catalog";
      for (const [page, ids] of Object.entries(placement)) if (ids.has(id)) destination = page;
      if (destination === "settings") settingsContent.append(section);
      else pageNodes.get(destination).append(section);
    }
    const settingsPanels = Array.from(settingsContent.children).filter(node => node.id);
    function activateSettingsPanel(panelId, options = {}) {
      const targetPanel = settingsPanels.find(panel => panel.id === panelId);
      if (!targetPanel) return false;
      settingsPanels.forEach(panel => { panel.hidden = panel !== targetPanel; panel.setAttribute("role", "tabpanel"); panel.setAttribute("aria-labelledby", `settings-tab-${panel.id}`); });
      settingsQuickNav.querySelectorAll('[role="tab"]').forEach(tab => {
        const active = tab.dataset.settingsJump === panelId;
        tab.id = `settings-tab-${tab.dataset.settingsJump}`;
        tab.setAttribute("aria-selected", String(active));
        tab.tabIndex = active ? 0 : -1;
      });
      if (options.focusPanel) {
        const heading = targetPanel.querySelector("h2, h3");
        if (heading) { if (!heading.hasAttribute("tabindex")) heading.tabIndex = -1; heading.focus({ preventScroll: true }); }
      }
      return true;
    }
    activateSettingsPanel("workspace-preferences-panel");
    // Single-player is the primary quiz flow; multiplayer is presented after it as a separate mode.
    const quizPage = pageNodes.get("quiz");
    const singlePlayerPanel = quizPage.querySelector("#quiz-panel");
    const multiplayerPanel = quizPage.querySelector("#multiplayer-panel");
    if (singlePlayerPanel && multiplayerPanel) multiplayerPanel.before(singlePlayerPanel);
    // Keep the catalog as the primary content; the optional free player follows it rather than pushing it down.
    const catalogPage = pageNodes.get("catalog");
    const catalogBrowser = catalogPage.querySelector("#catalog-browser");
    const freePlayer = catalogPage.querySelector("#free-player-dock");
    if (catalogBrowser && freePlayer) catalogBrowser.after(freePlayer);
    // The original first panel (AMQ / EMQ / MIX source mode) has no ID and is intentionally in Catalog.
    const modePanel = pageNodes.get("catalog").querySelector("section.panel:not([id])");
    if (modePanel) { modePanel.id = "catalog-mode-selector"; modePanel.dataset.skinRole = "catalog.mode-selector"; }

    const title = document.querySelector(".app-header h1");
    const status = document.getElementById("app-status");
    const listeners = [];
    let currentPage = "home";
    function listen(node, type, handler) { node.addEventListener(type, handler); listeners.push(() => node.removeEventListener(type, handler)); }
    function navigate(pageId, options = {}) {
      if (!pageNodes.has(pageId)) return false;
      currentPage = pageId;
      for (const [id, node] of pageNodes) node.hidden = id !== pageId;
      // Home is a clean, full-viewport game menu. The global shell is only needed
      // after entering a feature page; navigation remains owned by this router.
      nav.hidden = pageId === "home";
      document.body.dataset.currentPage = pageId;
      const shellHeader = document.querySelector(".app-header");
      if (shellHeader) shellHeader.hidden = true;
      const homeButton = nav.querySelector("#app-back");
      if (homeButton) {
        if (pageId === "home") homeButton.setAttribute("aria-current", "page");
        else homeButton.removeAttribute("aria-current");
      }
      nav.querySelectorAll("[data-nav-page]").forEach(button => {
        const active = button.dataset.navPage === pageId;
        if (active) button.setAttribute("aria-current", "page");
        else button.removeAttribute("aria-current");
      });
      main.dataset.currentPage = pageId;
      if (title) title.textContent = pageId === "home" ? "動畫歌曲學習工具" : ({ catalog: "選歌", quiz: "猜歌", results: "成績結果", learning: "學習中心", settings: "設定", profile: "個人檔案" })[pageId];
      const subtitle = document.querySelector(".header-subtitle");
      if (subtitle) subtitle.textContent = "";
      if (status) status.dataset.page = pageId;
      if (options.focus !== false) {
        const target = pageNodes.get(pageId).querySelector("h2, h3, input, button") || pageNodes.get(pageId);
        if (target && typeof target.focus === "function") {
          // Headings are not programmatically focusable by default. Add a temporary
          // navigation target tabindex so route changes actually move keyboard focus.
          if (!target.hasAttribute("tabindex") && !target.matches("input, button, select, textarea, a[href]")) target.tabIndex = -1;
          target.focus({ preventScroll: true });
        }
      }
      if (pageId === "quiz") {
        const quizSetupHeading = document.getElementById("quiz-setup-heading");
        if (quizSetupHeading && !quizSetupHeading.closest("[hidden]")) {
          if (!quizSetupHeading.hasAttribute("tabindex")) quizSetupHeading.setAttribute("tabindex", "-1");
          try { quizSetupHeading.focus({ preventScroll: true }); } catch (_) { quizSetupHeading.focus(); }
        }
      }
      // Page navigation is a new reading context: don't inherit the previous page's scroll offset.
      // In-page settings quick navigation intentionally remains scroll-to-section instead.
      if (options.scroll !== false && typeof window.scrollTo === "function") {
        try { window.scrollTo({ top: 0, left: 0, behavior: "auto" }); } catch (_) { window.scrollTo(0, 0); }
      }
      return true;
    }
    document.body.dataset.currentPage = "home";
    const shellHeader = document.querySelector(".app-header");
    if (shellHeader) shellHeader.hidden = true;
    nav.hidden = true;
    const recentList = home.querySelector("#home-recent-list");
    const featureTitle = home.querySelector("#home-feature-title");
    const featureWork = home.querySelector("#home-feature-work");
    const featureArt = home.querySelector("#home-feature-art");
    let playbackHistory = null;
    let removePlaybackSubscription = null;
    let artworkAdapter = null;
    let resolveArtworkRecord = null;
    const artworkRequestTokens = new WeakMap();
    let artworkRequestSequence = 0;
    function setArtwork(target, row, feature = false) {
      if (!target || !row) return;
      const token = ++artworkRequestSequence;
      artworkRequestTokens.set(target, token);
      const fallback = () => {
        if (artworkRequestTokens.get(target) !== token) return;
        target.replaceChildren();
        const mark = document.createElement("span");
        mark.className = feature ? "home-brand-mark" : "home-artwork-fallback-label";
        if (feature) { mark.dataset.skinComponent = "home.logo"; mark.setAttribute("role", "img"); mark.setAttribute("aria-label", "AMQ 音樂問號標誌"); }
        else mark.textContent = String(row.source || "AMQ");
        target.appendChild(mark);
        target.dataset.artworkStatus = "fallback";
        delete target.dataset.artworkProvider; delete target.dataset.artworkAttribution; delete target.dataset.artworkSourceUrl;
      };
      fallback();
      if (!artworkAdapter || typeof resolveArtworkRecord !== "function" || !row.workId) return;
      Promise.resolve().then(() => resolveArtworkRecord(row.source, row.workId)).then(record => {
        if (!record || !record.artworkRef || artworkRequestTokens.get(target) !== token) return null;
        return artworkAdapter.getArtwork(record);
      }).then(result => {
        if (!result || !result.url || artworkRequestTokens.get(target) !== token) return;
        const img = document.createElement("img");
        img.alt = ""; img.loading = feature ? "eager" : "lazy"; img.decoding = "async"; img.referrerPolicy = "no-referrer";
        img.src = result.url;
        img.addEventListener("error", fallback, { once: true });
        target.replaceChildren(img);
        target.dataset.artworkStatus = "loading";
        img.addEventListener("load", () => {
          if (artworkRequestTokens.get(target) !== token) return;
          target.dataset.artworkStatus = "available";
        }, { once: true });
        if (result.provider) target.dataset.artworkProvider = result.provider; else delete target.dataset.artworkProvider;
        if (result.attribution) target.dataset.artworkAttribution = result.attribution; else delete target.dataset.artworkAttribution;
        if (result.sourceUrl) target.dataset.artworkSourceUrl = result.sourceUrl; else delete target.dataset.artworkSourceUrl;
      }).catch(fallback);
    }
    function displayText(value) {
      if (value === null || value === undefined) return "";
      const text = String(value).trim();
      return !text || /^(?:null|undefined|nan)$/i.test(text) ? "" : text;
    }
    function renderHomeRecent() {
      if (!recentList) return;
      let rows = [];
      try { rows = playbackHistory ? playbackHistory.getEntries({ limit: 6 }) : []; } catch (_) { rows = []; }
      recentList.replaceChildren();
      if (!rows.length) {
        home.dataset.historyState = "empty";
        const empty = document.createElement("div"); empty.className = "home-recent-empty"; empty.id = "home-recent-empty"; empty.textContent = "尚無學習紀錄"; recentList.appendChild(empty);
        if (featureTitle) featureTitle.textContent = "選歌";
        if (featureWork) { featureWork.textContent = ""; featureWork.hidden = true; }
        if (featureArt) {
          featureArt.replaceChildren();
          const mark = document.createElement("span"); mark.className = "home-brand-mark"; mark.dataset.skinComponent = "home.logo"; mark.setAttribute("role", "img"); mark.setAttribute("aria-label", "AMQ 音樂問號標誌");
          featureArt.appendChild(mark); featureArt.dataset.source = "empty"; featureArt.dataset.artworkStatus = "fallback";
          delete featureArt.dataset.artworkProvider; delete featureArt.dataset.artworkAttribution; delete featureArt.dataset.artworkSourceUrl;
        }
        return;
      }
      home.dataset.historyState = "available";
      const latest = rows[0];
      if (featureTitle) featureTitle.textContent = displayText(latest.title) || displayText(latest.workTitle) || "最近播放";
      if (featureWork) { featureWork.textContent = [displayText(latest.workTitle), displayText(latest.source)].filter(Boolean).join(" · "); featureWork.hidden = !featureWork.textContent; }
      if (featureArt) { featureArt.dataset.source = latest.source || "AMQ"; setArtwork(featureArt, latest, true); }
      for (const row of rows) {
        const item = document.createElement("button"); item.type = "button"; item.className = "home-recent-item"; item.dataset.goPage = "catalog"; item.dataset.skinComponent = "home.recent.item";
        const art = document.createElement("span"); art.className = "home-recent-art"; art.dataset.source = displayText(row.source) || "AMQ"; art.dataset.skinComponent = "home.recent.artwork"; art.setAttribute("aria-hidden", "true");
        const mark = document.createElement("span"); mark.textContent = String(row.source || "AMQ"); art.appendChild(mark);
        const copy = document.createElement("span"); copy.className = "home-recent-copy";
        const titleText = document.createElement("strong"); titleText.dataset.skinComponent = "home.recent.title";
        titleText.textContent = displayText(row.title) || displayText(row.workTitle) || (displayText(row.songId) ? `歌曲 ${displayText(row.songId)}` : "最近播放");
        const metadata = [displayText(row.workTitle), displayText(row.artist)].filter(Boolean).join(" · ") || displayText(row.source) || "";
        const workText = document.createElement("small"); workText.textContent = metadata;
        if (!metadata) workText.hidden = true;
        copy.append(titleText, workText); item.append(art, copy); recentList.appendChild(item);
        setArtwork(art, row, false);
      }
    }
    listen(recentList, "click", event => {
      const item = event.target && typeof event.target.closest === "function" ? event.target.closest(".home-recent-item") : null;
      if (item && recentList.contains(item)) navigate("catalog");
    });
    try {
      const historyApi = global.AMQPersistence && global.AMQPersistence.playbackHistoryStore;
      if (historyApi && typeof historyApi.createPlaybackHistoryStore === "function") {
        playbackHistory = historyApi.createPlaybackHistoryStore();
        removePlaybackSubscription = playbackHistory.subscribe(renderHomeRecent);
        renderHomeRecent();
        listen(document, "amq-learning-playback-history-updated-v1", renderHomeRecent);
      } else {
        renderHomeRecent();
      }
    } catch (_) { renderHomeRecent(); }
    main.querySelectorAll("[data-go-page]").forEach(button => listen(button, "click", () => navigate(button.dataset.goPage)));
    settingsQuickNav.querySelectorAll('[role="tab"]').forEach((button, index, buttons) => {
      listen(button, "click", () => {
        if (activateSettingsPanel(button.dataset.settingsJump)) {
          const heading = document.getElementById(button.dataset.settingsJump)?.querySelector("h2, h3");
          if (heading) { if (!heading.hasAttribute("tabindex")) heading.tabIndex = -1; heading.focus({ preventScroll: true }); }
        }
      });
      listen(button, "keydown", event => {
        if (!["ArrowDown", "ArrowRight", "ArrowUp", "ArrowLeft", "Home", "End"].includes(event.key)) return;
        event.preventDefault();
        let next = index;
        if (event.key === "Home") next = 0;
        else if (event.key === "End") next = buttons.length - 1;
        else if (["ArrowDown", "ArrowRight"].includes(event.key)) next = (index + 1) % buttons.length;
        else next = (index - 1 + buttons.length) % buttons.length;
        buttons[next].focus();
        buttons[next].click();
      });
    });
    const onKey = event => {
      const target = event.target;
      const editing = target && (target.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName || ""));
      if (!editing && event.altKey && event.key === "ArrowLeft" && currentPage !== "home" && !event.ctrlKey && !event.metaKey) { event.preventDefault(); navigate("home"); }
    };
    document.addEventListener("keydown", onKey); listeners.push(() => document.removeEventListener("keydown", onKey));
    // Existing modules query stable IDs, so moving their sections does not change their data or lifecycle.
    navigate("home", { focus: false });
    return Object.freeze({ navigate, setArtworkAdapter(adapter, resolver) { artworkAdapter = adapter && typeof adapter.getArtwork === "function" ? adapter : null; resolveArtworkRecord = typeof resolver === "function" ? resolver : null; renderHomeRecent(); return Boolean(artworkAdapter && resolveArtworkRecord); }, get currentPage() { return currentPage; }, dispose() { for (const remove of listeners.splice(0).reverse()) remove(); if (removePlaybackSubscription) removePlaybackSubscription(); if (playbackHistory && typeof playbackHistory.dispose === "function") playbackHistory.dispose(); main.dataset.appShellMounted = "false"; } });
  }
  global.AMQUI = global.AMQUI || {};
  let activeShell = null;
  global.AMQUI.appShell = Object.freeze({
    mount() { if (!activeShell || !main || main.dataset.appShellMounted !== "true") activeShell = mount(); return activeShell; },
    setArtworkAdapter(adapter, resolver) { return Boolean(activeShell && typeof activeShell.setArtworkAdapter === "function" && activeShell.setArtworkAdapter(adapter, resolver)); }
  });
  activeShell = mount();
})(window);
