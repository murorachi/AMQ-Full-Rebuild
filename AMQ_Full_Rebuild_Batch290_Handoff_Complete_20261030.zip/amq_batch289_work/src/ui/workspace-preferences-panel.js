/* Workspace preferences UI and safe, user-configurable keyboard command routing. */
(function (global) {
  "use strict";
  const ACTIONS = Object.freeze([
    ["focusAnswer", "聚焦答案輸入框"], ["startRound", "開始回合"], ["playQuiz", "播放／恢復猜歌音訊"],
    ["pauseQuiz", "暫停猜歌音訊"], ["revealAnswer", "揭曉答案"], ["skipQuestion", "跳過本題"],
    ["nextQuestion", "前往下一題"], ["focusCatalog", "前往曲庫並聚焦搜尋"], ["focusFreePlayer", "前往自由播放搜尋"],
    ["openPreferences", "開啟工作區設定位置"], ["randomFreePlay", "隨機播放歌曲"], ["focusStatistics", "前往學習統計"]
  ]);
  const SECTION_CONTROLS = Object.freeze({
    account: "account-panel", multiplayer: "multiplayer-panel", backupRestore: "backup-restore-panel",
    databaseUpdate: "database-update-panel", catalog: "catalog-browser", freePlayer: "free-player-dock",
    statistics: "statistics-dashboard", skinImport: "skin-import-panel"
  });
  const STAT_IDS = Object.freeze({ source: "statistics-by-source", target: "statistics-by-target", familiarity: "statistics-familiarity", srs: "statistics-srs", playback: "statistics-playback", daily: "statistics-daily" });
  const STAT_LABELS = Object.freeze({ source: "來源表現", target: "作答目標", familiarity: "作品熟悉度", srs: "間隔複習", playback: "自由播放", daily: "最近每日答題" });

  function isEditable(target) {
    if (!target) return false;
    if (target.isContentEditable) return true;
    if (typeof target.closest !== "function") return false;
    return !!target.closest("input, textarea, select, [contenteditable]:not([contenteditable='false']), [role='textbox'], [data-shortcut-capture]");
  }
  function canonicalEvent(event) {
    if (event.getModifierState && event.getModifierState("AltGraph")) return null;
    const key = event.key;
    if (!key || ["Control", "Alt", "Shift", "Meta"].includes(key)) return null;
    let normalizedKey;
    if (/^[a-z]$/i.test(key)) normalizedKey = key.toUpperCase();
    else if (/^[0-9]$/.test(key) || /^F(?:[1-9]|1[0-2])$/.test(key)) normalizedKey = key;
    else return null;
    const modifiers = [];
    if (event.ctrlKey) modifiers.push("Ctrl");
    if (event.altKey) modifiers.push("Alt");
    if (event.shiftKey) modifiers.push("Shift");
    if (event.metaKey) modifiers.push("Meta");
    if (!modifiers.some(modifier => ["Ctrl", "Alt", "Meta"].includes(modifier))) return null;
    return [...["Ctrl", "Alt", "Shift", "Meta"].filter(modifier => modifiers.includes(modifier)), normalizedKey].join("+");
  }
  function mount(options) {
    const settings = options && typeof options === "object" ? options : {};
    const root = global.document && global.document.getElementById("workspace-preferences-panel");
    const storeApi = global.AMQPersistence && global.AMQPersistence.workspacePreferencesStore;
    const preferencesStore = settings.preferencesStore || (storeApi && storeApi.createWorkspacePreferencesStore());
    const ownsStore = !settings.preferencesStore;
    if (!root || !preferencesStore) return Object.freeze({ dispose() { if (ownsStore && preferencesStore) preferencesStore.dispose(); }, isDisposed: true });
    const scopeApi = global.AMQCore && global.AMQCore.lifecycle;
    const scope = scopeApi && scopeApi.createScope ? scopeApi.createScope() : null;
    const cleanup = [];
    let disposed = false;
    let captureAction = null;
    let statusNode = root.querySelector("#workspace-preferences-status");

    function listen(target, type, handler) {
      if (!target || !target.addEventListener) return;
      if (scope) scope.listen(target, type, handler);
      else { target.addEventListener(type, handler); cleanup.push(() => target.removeEventListener(type, handler)); }
    }
    function status(message, isError = false) {
      if (!statusNode) return;
      statusNode.textContent = message;
      statusNode.dataset.state = isError ? "error" : "ok";
    }
    function setHidden(id, hidden) {
      const element = global.document.getElementById(id);
      if (element) { element.hidden = hidden; if (element.style) element.style.display = hidden ? "none" : ""; }
    }
    function applyStatisticsOrder(order) {
      const grid = global.document.querySelector("#statistics-dashboard .statistics-grid");
      if (!grid) return;
      for (const key of order) {
        const value = global.document.getElementById(STAT_IDS[key]);
        const item = value && value.parentElement;
        if (item && item.parentElement === grid) grid.appendChild(item);
      }
    }
    function applyPreferences(preferences, jumpToDefault = false) {
      for (const [key, id] of Object.entries(SECTION_CONTROLS)) setHidden(id, !preferences.visibility[key]);
      const quizHistory = global.document.querySelector("#quiz-panel .quiz-history");
      const quizSrs = global.document.querySelector("#quiz-panel .quiz-srs");
      if (quizHistory) { quizHistory.hidden = !preferences.visibility.quizHistory; quizHistory.style.display = quizHistory.hidden ? "none" : ""; }
      if (quizSrs) { quizSrs.hidden = !preferences.visibility.quizSrs; quizSrs.style.display = quizSrs.hidden ? "none" : ""; }
      applyStatisticsOrder(preferences.statisticsOrder);
      for (const input of root.querySelectorAll("[data-workspace-visibility]")) input.checked = preferences.visibility[input.dataset.workspaceVisibility] !== false;
      const defaultSelect = root.querySelector("#workspace-default-section");
      if (defaultSelect) defaultSelect.value = preferences.defaultSection;
      for (const button of root.querySelectorAll("[data-capture-shortcut]")) {
        const key = button.dataset.captureShortcut;
        button.textContent = preferences.shortcuts[key] || "未設定";
        button.setAttribute("aria-label", `${(ACTIONS.find(item => item[0] === key) || [key, key])[1]}：${button.textContent}。點擊後按下新組合鍵`);
      }
      const entry = root.querySelector("[data-workspace-stat-order]");
      if (entry) {
        entry.replaceChildren();
        for (const key of preferences.statisticsOrder) {
          const row = global.document.createElement("li");
          const label = global.document.createElement("span"); label.textContent = STAT_LABELS[key]; row.appendChild(label);
          for (const [direction, text] of [[-1, "上移"], [1, "下移"]]) {
            const button = global.document.createElement("button"); button.type = "button"; button.textContent = text; button.dataset.moveStatistic = key; button.dataset.direction = String(direction);
            button.disabled = preferences.statisticsOrder.indexOf(key) + direction < 0 || preferences.statisticsOrder.indexOf(key) + direction >= preferences.statisticsOrder.length;
            button.setAttribute("aria-label", `${text}${STAT_LABELS[key]}`); row.appendChild(button);
          }
          entry.appendChild(row);
        }
      }
      if (jumpToDefault && preferences.defaultSection !== "none") {
        const id = storeApi.sectionIds[preferences.defaultSection];
        const destination = id && global.document.getElementById(id);
        if (destination && !destination.hidden) {
          try { destination.scrollIntoView({ block: "start", behavior: "auto" }); } catch (_) {}
        }
      }
    }
    function save(patch, successMessage = "設定已保存。") {
      const result = preferencesStore.set(patch);
      if (!result.ok) {
        applyPreferences(preferencesStore.getPreferences());
        status(result.reason === "invalid-preferences" ? "設定無效或快捷鍵衝突，未保存。" : `保存失敗：${result.reason}`, true);
        return false;
      }
      status(successMessage); return true;
    }
    function visibleAndEnabled(element) { return !!element && !element.disabled && !element.closest("[hidden]"); }
    function click(id) {
      const element = global.document.getElementById(id);
      if (!visibleAndEnabled(element) || typeof element.click !== "function") return false;
      element.click(); return true;
    }
    function focus(id, sectionId) {
      const section = sectionId && global.document.getElementById(sectionId);
      if (section && section.hidden) return false;
      const element = global.document.getElementById(id);
      if (!element || element.disabled || element.closest("[hidden]") || typeof element.focus !== "function") return false;
      if (section) { try { section.scrollIntoView({ block: "start", behavior: "auto" }); } catch (_) {} }
      element.focus(); return true;
    }
    function execute(action) {
      switch (action) {
        case "focusAnswer": {
          const multi = global.document.getElementById("quiz-answer-anime");
          const single = global.document.getElementById("quiz-answer");
          const target = multi && !multi.closest("[hidden]") ? multi : single;
          return focus(target && target.id, "quiz-panel");
        }
        case "startRound": return click("quiz-start");
        case "playQuiz": return click("quiz-play");
        case "pauseQuiz": return click("quiz-pause");
        case "revealAnswer": return click("quiz-reveal");
        case "skipQuestion": return click("quiz-skip");
        case "nextQuestion": return click("quiz-next");
        case "focusCatalog": return focus("catalog-query", "catalog-browser");
        case "focusFreePlayer": return focus("free-player-search", "free-player-dock");
        case "openPreferences": return focus("workspace-default-section", "workspace-preferences-panel");
        case "randomFreePlay": return click("free-player-random");
        case "focusStatistics": {
          const section = global.document.getElementById("statistics-dashboard");
          if (!section || section.hidden) return false;
          try { section.scrollIntoView({ block: "start", behavior: "auto" }); } catch (_) {}
          return true;
        }
        default: return false;
      }
    }
    function onKeydown(event) {
      if (disposed || event.isComposing || event.keyCode === 229) return;
      if (captureAction) {
        if (event.key === "Escape") { event.preventDefault(); captureAction = null; status("已取消快捷鍵錄製。"); return; }
        const combo = canonicalEvent(event);
        if (!combo) return;
        event.preventDefault(); event.stopPropagation();
        const action = captureAction; captureAction = null;
        const current = preferencesStore.getPreferences();
        if (Object.entries(current.shortcuts).some(([other, value]) => other !== action && value === combo)) { status(`${combo} 已被其他操作使用，請選擇不同組合鍵。`, true); return; }
        const result = preferencesStore.set({ shortcuts: { ...current.shortcuts, [action]: combo } });
        if (!result.ok) { status("快捷鍵不合法或發生衝突，原設定保留。", true); return; }
        status(`已更新快捷鍵：${combo}`); return;
      }
      if (event.defaultPrevented || event.repeat || isEditable(event.target)) return;
      const combo = canonicalEvent(event);
      if (!combo) return;
      const preferences = preferencesStore.getPreferences();
      const match = Object.entries(preferences.shortcuts).find(([, value]) => value === combo);
      if (!match || !execute(match[0])) return;
      event.preventDefault();
    }
    function onClick(event) {
      const reset = event.target.closest && event.target.closest("[data-workspace-reset]");
      if (reset) {
        if (!global.confirm || global.confirm("要將工作區顯示、統計順序與所有快捷鍵恢復預設值嗎？")) {
          const defaults = storeApi.defaults;
          save({ shortcuts: { ...defaults.shortcuts }, visibility: { ...defaults.visibility }, defaultSection: defaults.defaultSection, statisticsOrder: defaults.statisticsOrder.slice() }, "工作區與快捷鍵已恢復預設值。");
        }
        return;
      }
      const capture = event.target.closest && event.target.closest("[data-capture-shortcut]");
      if (capture) { captureAction = capture.dataset.captureShortcut; status(`錄製「${(ACTIONS.find(item => item[0] === captureAction) || [captureAction, captureAction])[1]}」：按下 Ctrl／Alt／Meta 組合鍵；按 Escape 取消。`); return; }
      const move = event.target.closest && event.target.closest("[data-move-statistic]");
      if (move) {
        const preferences = preferencesStore.getPreferences(); const order = preferences.statisticsOrder.slice();
        const from = order.indexOf(move.dataset.moveStatistic); const to = from + Number(move.dataset.direction);
        if (from < 0 || to < 0 || to >= order.length) return;
        [order[from], order[to]] = [order[to], order[from]];
        save({ statisticsOrder: order }, "統計區塊順序已保存。");
      }
    }
    listen(root, "click", onClick);
    listen(global.document, "keydown", onKeydown);
    listen(root, "change", event => {
      const input = event.target;
      if (input.matches && input.matches("[data-workspace-visibility]")) {
        const current = preferencesStore.getPreferences();
        const visibility = { ...current.visibility, [input.dataset.workspaceVisibility]: input.checked };
        const defaultSectionKey = { catalog: "catalog", freePlayer: "freePlayer", statistics: "statistics" }[input.dataset.workspaceVisibility];
        const patch = { visibility };
        if (!input.checked && defaultSectionKey === current.defaultSection) patch.defaultSection = "none";
        save(patch, "工作區顯示設定已保存。");
      } else if (input.id === "workspace-default-section") save({ defaultSection: input.value }, "預設入口已保存，下次開啟時生效。");
    });
    const unsubscribe = preferencesStore.subscribe((storeStatus, preferences, source) => {
      applyPreferences(preferences);
      if (source === "external") status("已同步其他分頁的工作區設定。");
      if (source === "write-failed") status(`設定未保存：${storeStatus.error || "儲存失敗"}`, true);
    });
    if (scope) scope.add(unsubscribe); else cleanup.push(unsubscribe);
    applyPreferences(preferencesStore.getPreferences(), true);
    if (!preferencesStore.getStatus().persisted) status("工作區設定使用暫時預設值，儲存目前不可用。", true);
    return Object.freeze({ dispose() { if (disposed) return []; disposed = true; captureAction = null; const errors = scope ? scope.dispose() : []; for (const release of cleanup.splice(0).reverse()) { try { release(); } catch (error) { errors.push(error); } } if (ownsStore) preferencesStore.dispose(); return errors; }, get isDisposed() { return disposed; }, get preferencesStore() { return preferencesStore; } });
  }
  global.AMQUI = global.AMQUI || {};
  global.AMQUI.workspacePreferencesPanel = Object.freeze({ mount, actions: ACTIONS });
})(window);
