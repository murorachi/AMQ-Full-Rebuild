/* Accessible, storage-independent autocomplete for the single-answer quiz field. */
(function (global) {
  "use strict";

  const OPTIONAL_SEPARATOR_SYMBOLS = new Set(Array.from("★☆✩✪✦✧✫✬✭✮✯✰⋆✶✷✸✹✺＊·♥❤∽・〜†♪♫→␣°∞△↓♡∬"));
  const PUNCTUATION_SEPARATORS = new Set(Array.from("/-:;'.,"));
  // Include NFKC forms of uncommon symbols, while keeping each symbol distinct.
  for (const symbol of [...OPTIONAL_SEPARATOR_SYMBOLS]) {
    for (const normalized of Array.from(symbol.normalize("NFKC"))) OPTIONAL_SEPARATOR_SYMBOLS.add(normalized);
  }
  function normalizeSuggestionText(value) {
    return Array.from(String(value == null ? "" : value), char => char.normalize("NFKC").toLocaleLowerCase()).join("");
  }
  function normalize(value) { return normalizeSuggestionText(value).trim(); }
  function foldDiacritics(value) {
    return Array.from(String(value == null ? "" : value).normalize("NFKC"), char =>
      char.normalize("NFKD").replace(/[\u0300-\u036f]/gu, "").toLocaleLowerCase()).join("");
  }
  function isFlexibleSeparator(char) {
    return PUNCTUATION_SEPARATORS.has(char) || OPTIONAL_SEPARATOR_SYMBOLS.has(char);
  }
  function escapeRegExp(value) { return value.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&"); }
  function buildQueryMatcher(query) {
    const normalizedQuery = normalizeSuggestionText(query).trim();
    if (!normalizedQuery) return null;
    let pattern = "";
    for (const originalChar of Array.from(String(query == null ? "" : query).trim())) {
      const normalizedChars = Array.from(originalChar.normalize("NFKC").toLocaleLowerCase());
      for (const char of normalizedChars) {
        // Whitespace typed by the user remains whitespace. A typed punctuation/special
        // separator can match itself OR whitespace, never a different punctuation mark.
        if (/\s/u.test(char)) pattern += escapeRegExp(char);
        else if (isFlexibleSeparator(char)) pattern += `(?:${escapeRegExp(char)}|\\s)`;
        else pattern += escapeRegExp(char);
      }
    }
    try { return { query: normalizedQuery, matcher: new RegExp(pattern, "u") }; }
    catch (_) { return { query: normalizedQuery, matcher: null }; }
  }
  function mapSuggestionLabel(label) {
    let searchText = "", foldedText = "", sourceStarts = [], sourceEnds = [], foldedStarts = [], foldedEnds = [], originalOffset = 0;
    for (const char of label) {
      const sourceStart = originalOffset;
      originalOffset += char.length;
      const normalized = normalizeSuggestionText(char);
      const folded = foldDiacritics(char);
      for (let i = 0; i < normalized.length; i++) {
        searchText += normalized[i];
        sourceStarts.push(sourceStart);
        sourceEnds.push(originalOffset);
      }
      for (let i = 0; i < folded.length; i++) {
        foldedText += folded[i];
        foldedStarts.push(sourceStart);
        foldedEnds.push(originalOffset);
      }
    }
    return {
      label,
      searchText,
      sourceStarts,
      sourceEnds,
      foldedText,
      foldedStarts,
      foldedEnds,
      titleLength: Array.from(label).length,
      rawKey: label.normalize("NFKC").toLocaleLowerCase()
    };
  }
  function buildMatchEntries(values, query, limit = 25) {
    const queryInfo = buildQueryMatcher(query);
    if (!queryInfo || !queryInfo.matcher) return [];
    const rawQuery = queryInfo.query;
    const foldedQuery = foldDiacritics(rawQuery);
    const queryTokens = foldedQuery.split(/[^\p{L}\p{N}]+/u).filter(Boolean);
    const unique = new Set();
    const hits = [];
    const addSearchRange = (item, ranges, start, end) => {
      for (let i = Math.max(0, start); i < Math.min(end, item.searchText.length); i++) {
        const char = item.searchText[i];
        if (!char || /\s/u.test(char)) continue;
        const sourceStart = item.sourceStarts[i], sourceEnd = item.sourceEnds[i];
        ranges.push({ start: sourceStart, end: sourceEnd });
      }
    };
    const getRanges = (item, match) => {
      const ranges = [];
      if (match) addSearchRange(item, ranges, match.index, match.index + match[0].length);
      ranges.sort((a, b) => a.start - b.start || a.end - b.end);
      const merged = [];
      for (const range of ranges) {
        const last = merged[merged.length - 1];
        if (last && range.start <= last.end) last.end = Math.max(last.end, range.end);
        else merged.push({ ...range });
      }
      return merged;
    };
    const addFoldedRange = (item, ranges, start, end) => {
      for (let i = Math.max(0, start); i < Math.min(end, item.foldedText.length); i++) {
        const char = item.foldedText[i];
        if (!char || /[^\p{L}\p{N}]/u.test(char)) continue;
        ranges.push({ start: item.foldedStarts[i], end: item.foldedEnds[i] });
      }
    };
    const compare = (a, b) => a.matchRank - b.matchRank
      || a.titleLength - b.titleLength
      || (a.rawKey < b.rawKey ? -1 : a.rawKey > b.rawKey ? 1 : a.label < b.label ? -1 : a.label > b.label ? 1 : 0);
    const maxHits = Math.max(1, Number(limit) || 25);
    for (const value of values || []) {
      const label = String(value == null ? "" : value).trim();
      if (!label || unique.has(label)) continue;
      unique.add(label);
      const item = mapSuggestionLabel(label);
      const match = queryInfo.matcher.exec(item.searchText);
      const literalIndex = item.searchText.indexOf(rawQuery);
      if (match) {
        if (item.searchText === rawQuery) item.matchRank = 0;                 // exact
        else if (item.searchText.startsWith(rawQuery)) item.matchRank = 1;   // literal prefix
        else if (match.index === 0) item.matchRank = 2;                      // separator-tolerant prefix
        else if (literalIndex >= 0) item.matchRank = 3;                      // literal substring
        else item.matchRank = 4;                                             // separator-tolerant substring
        item.ranges = getRanges(item, match);
      } else {
        // Match the community-script behavior: multiword queries can match words
        // in any order, while each typed token must be present in the title/alias.
        // This is intentionally not fuzzy scoring and never changes answer evaluation.
        const canUseWordOrder = /\s/u.test(rawQuery) && queryTokens.length > 1 && queryTokens.every(token => Array.from(token).length > 1);
        const canUseAccentFold = foldedQuery !== rawQuery;
        if (!queryTokens.length || (!canUseWordOrder && !canUseAccentFold)) continue;
        const ranges = [];
        let matched = true;
        for (const token of queryTokens) {
          const index = item.foldedText.indexOf(token);
          if (index < 0) { matched = false; break; }
          addFoldedRange(item, ranges, index, index + token.length);
        }
        if (!matched) continue;
        item.matchRank = 5;
        ranges.sort((a, b) => a.start - b.start || a.end - b.end);
        const merged = [];
        for (const range of ranges) {
          const last = merged[merged.length - 1];
          if (last && range.start <= last.end) last.end = Math.max(last.end, range.end);
          else merged.push({ ...range });
        }
        item.ranges = merged;
      }
      // Match relevance comes first. Within each relevance tier, shorter names lead,
      // then normalized/original lexical order gives stable results for season variants.
      let low = 0, high = hits.length;
      while (low < high) {
        const mid = (low + high) >> 1;
        if (compare(hits[mid], item) <= 0) low = mid + 1;
        else high = mid;
      }
      if (low < maxHits) {
        hits.splice(low, 0, item);
        if (hits.length > maxHits) hits.pop();
      }
    }
    return hits;
  }
  function buildMatches(values, query, limit = 25) {
    return buildMatchEntries(values, query, limit).map(item => item.label);
  }
  function renderLabel(button, item, doc) {
    if (!item.ranges.length) {
      button.textContent = item.label;
      return;
    }
    let offset = 0;
    for (const range of item.ranges) {
      if (range.start > offset) button.appendChild(doc.createTextNode(item.label.slice(offset, range.start)));
      const span = doc.createElement("span");
      span.className = "quiz-suggestion-match";
      span.textContent = item.label.slice(range.start, range.end);
      button.appendChild(span);
      offset = range.end;
    }
    if (offset < item.label.length) button.appendChild(doc.createTextNode(item.label.slice(offset)));
  }

  function createController(options) {
    const settings = options || {};
    const input = settings.input;
    const listbox = settings.listbox;
    const doc = settings.document || global.document;
    if (!input || !listbox || !doc || typeof settings.getValues !== "function") throw new TypeError("answer suggestions require input, listbox, document and getValues");
    const getValues = settings.getValues;
    const isEnabled = typeof settings.isEnabled === "function" ? settings.isEnabled : () => true;
    const onSelect = typeof settings.onSelect === "function" ? settings.onSelect : () => {};
    const removers = [];
    let composing = false;
    let activeIndex = -1;
    let lastQuery = null;
    let lastHits = null;
    let disposed = false;

    input.setAttribute("role", "combobox");
    input.setAttribute("aria-autocomplete", "list");
    input.setAttribute("aria-controls", listbox.id || "quiz-suggestions");
    input.setAttribute("aria-expanded", "false");
    input.setAttribute("autocapitalize", "off");
    input.setAttribute("spellcheck", "false");
    listbox.setAttribute("role", "listbox");
    listbox.hidden = true;

    function listen(target, type, handler, capture = false) {
      target.addEventListener(type, handler, capture);
      removers.push(() => target.removeEventListener(type, handler, capture));
    }
    function close() {
      activeIndex = -1;
      listbox.replaceChildren();
      listbox.hidden = true;
      listbox.classList.remove("open");
      input.setAttribute("aria-expanded", "false");
      input.removeAttribute("aria-activedescendant");
    }
    function setActive(index) {
      const items = [...listbox.querySelectorAll("[role='option']")];
      if (!items.length) { activeIndex = -1; return; }
      activeIndex = (index + items.length) % items.length;
      items.forEach((item, i) => {
        const selected = i === activeIndex;
        item.classList.toggle("active", selected);
        item.setAttribute("aria-selected", String(selected));
      });
      const item = items[activeIndex];
      if (item && item.id) input.setAttribute("aria-activedescendant", item.id);
      if (item && typeof item.scrollIntoView === "function") item.scrollIntoView({ block: "nearest" });
    }
    function select(value) {
      const label = String(value == null ? "" : value).trim();
      if (!label || disposed || input.disabled || composing || !isEnabled()) return false;
      input.value = label;
      input.focus({ preventScroll: true });
      try { input.setSelectionRange(label.length, label.length); } catch (_) {}
      const EventCtor = doc.defaultView && doc.defaultView.Event || global.Event;
      if (typeof EventCtor === "function") input.dispatchEvent(new EventCtor("input", { bubbles: true }));
      close();
      onSelect(label);
      return true;
    }
    function refresh(force = false) {
      if (disposed || composing || input.dataset && input.dataset.imeComposing === "1" || input.disabled || !isEnabled()) {
        close();
        lastQuery = input.value;
        lastHits = [];
        return [];
      }
      const query = input.value;
      if (!normalize(query)) {
        close();
        lastQuery = query;
        lastHits = [];
        return [];
      }
      // QuizPanel renders on every timer/audio state update. Do not rebuild an unchanged
      // listbox: replacing option nodes resets keyboard navigation and can detach a
      // mouse target between pointerdown and click. A real input edit forces a refresh.
      if (!force && query === lastQuery && lastHits !== null) return lastHits;
      const entries = buildMatchEntries(getValues(), query, 25);
      const hits = entries.map(entry => entry.label);
      const sameHits = lastHits !== null && hits.length === lastHits.length && hits.every((hit, index) => hit === lastHits[index]);
      const queryChanged = query !== lastQuery;
      lastQuery = query;
      lastHits = hits;
      // A changed query must repaint match ranges even when it returns the same labels.
      // Unchanged timer/audio renders keep the existing option DOM and active index.
      if (force || queryChanged || !sameHits || listbox.children.length !== entries.length) {
        listbox.replaceChildren();
        entries.forEach((entry, index) => {
          const item = doc.createElement("button");
          item.type = "button";
          item.id = `${listbox.id || "quiz-suggestions"}-option-${index + 1}`;
          item.className = "quiz-suggestion-option";
          item.setAttribute("role", "option");
          item.setAttribute("aria-selected", "false");
          renderLabel(item, entry, doc);
          listbox.appendChild(item);
        });
        activeIndex = -1;
      }
      const open = hits.length > 0;
      listbox.hidden = !open;
      listbox.classList.toggle("open", open);
      input.setAttribute("aria-expanded", String(open));
      return hits;
    }
    function onKeyDown(event) {
      if (disposed || event.isComposing || event.keyCode === 229 || composing || input.dataset && input.dataset.imeComposing === "1") return;
      const items = listbox.querySelectorAll("[role='option']");
      if (event.key === "ArrowDown" && !listbox.hidden && items.length) {
        event.preventDefault(); setActive(activeIndex + 1); return;
      }
      if (event.key === "ArrowUp" && !listbox.hidden && items.length) {
        event.preventDefault(); setActive(activeIndex <= 0 ? items.length - 1 : activeIndex - 1); return;
      }
      if (event.key === "Enter" && !listbox.hidden && items.length) {
        event.preventDefault();
        const index = activeIndex >= 0 ? activeIndex : 0;
        select(items[index].textContent);
        return;
      }
      if (event.key === "Escape" && !listbox.hidden) { event.preventDefault(); close(); }
    }
    function onCompositionStart() { composing = true; close(); }
    function onCompositionEnd() { composing = false; if (!disposed) global.setTimeout(() => refresh(true), 0); }
    function onDocumentClick(event) {
      if (event.target === input || listbox.contains(event.target)) return;
      close();
    }
    function onListPointerDown(event) {
      if (event.target && event.target.closest && event.target.closest("[role='option']")) event.preventDefault();
    }
    function onListClick(event) {
      const item = event.target && event.target.closest && event.target.closest("[role='option']");
      if (!item || !listbox.contains(item)) return;
      event.preventDefault();
      select(item.textContent);
    }
    listen(input, "input", () => refresh(true));
    listen(input, "keydown", onKeyDown);
    listen(input, "compositionstart", onCompositionStart);
    listen(input, "compositionend", onCompositionEnd);
    listen(listbox, "pointerdown", onListPointerDown);
    listen(listbox, "click", onListClick);
    listen(doc, "click", onDocumentClick);

    return Object.freeze({ refresh, close, select, isComposing: () => composing, dispose() { if (disposed) return false; disposed = true; close(); for (const remove of removers.splice(0)) remove(); return true; } });
  }

  global.AMQUI = global.AMQUI || {};
  global.AMQUI.answerSuggestions = Object.freeze({ normalize, buildMatches, createController, buildMatchEntries });
})(window);
