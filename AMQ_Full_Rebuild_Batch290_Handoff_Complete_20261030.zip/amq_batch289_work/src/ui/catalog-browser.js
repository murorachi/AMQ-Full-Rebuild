/* Accessible catalog browsing UI. Search semantics remain owned by query-index. */
(function (global) {
  "use strict";

  function formatCatalogError(error, fallback) {
    if (!error || !global.AMQCore || !global.AMQCore.errors) return "";
    const normalized = global.AMQCore.errors.normalize(error, {
      code: "DATA_LOAD_FAILED", category: "data", message: fallback || "曲庫載入失敗"
    });
    const parts = [`${normalized.code}：${normalized.message}`];
    const details = normalized.details && typeof normalized.details === "object" ? normalized.details : null;
    if (details && Number.isFinite(details.inputCount) && Number.isFinite(details.rejectedCount)) {
      const validCount = Number.isFinite(details.validCount) ? details.validCount : Math.max(0, details.inputCount - details.rejectedCount);
      parts.push(`資料明細：輸入 ${details.inputCount} 筆、可用 ${validCount} 筆、拒絕 ${details.rejectedCount} 筆`);
    } else if (details && typeof details.reason === "string" && details.reason.trim()) {
      parts.push(`原因：${details.reason.trim()}`);
    }
    if (normalized.cause && typeof normalized.cause.message === "string" && normalized.cause.message.trim()
      && !parts.some(part => part.includes(normalized.cause.message))) {
      parts.push(`來源原因：${normalized.cause.message.trim()}`);
    }
    if (normalized.retryable) parts.push("此錯誤可重試。");
    return parts.join("；");
  }

  function createController(queryIndex) {
    if (!queryIndex || typeof queryIndex.createCatalog !== "function") throw new TypeError("catalog browser requires query-index");
    let catalog = null;
    let filters = { query: "", source: "", type: "", workKind: "", animeYearFrom: "", animeYearTo: "", includeUnknownYear: "true", animeType: "", animeDecade: "", watchStatus: "", familiarityLevel: "", tagId: "" };
    let sortBy = "title";
    let sortDirection = "asc";
    let page = 0;
    let pageSize = 25;

    function criteria(includePage) {
      const result = {};
      if (filters.query.trim()) result.query = filters.query;
      if (filters.source) result.source = filters.source;
      if (filters.type) result.type = filters.type;
      if (filters.workKind) result.workKind = filters.workKind;
      if (filters.animeYearFrom !== "") result.animeYearFrom = Number(filters.animeYearFrom);
      if (filters.animeYearTo !== "") result.animeYearTo = Number(filters.animeYearTo);
      result.includeUnknownYear = filters.includeUnknownYear !== "false";
      if (filters.animeType) result.animeType = filters.animeType;
      if (filters.animeDecade) result.animeDecade = Number(filters.animeDecade);
      if (filters.watchStatus) result.watchStatus = filters.watchStatus;
      if (filters.familiarityLevel !== "") result.familiarityLevel = Number(filters.familiarityLevel);
      if (filters.tagId) result.tagId = filters.tagId;
      if (sortBy) { result.sortBy = sortBy; result.sortDirection = sortDirection; }
      if (includePage) { result.offset = page * pageSize; result.limit = pageSize; }
      return result;
    }

    function setCatalog(recordsOrCatalog) {
      catalog = recordsOrCatalog && typeof recordsOrCatalog.search === "function"
        ? recordsOrCatalog
        : queryIndex.createCatalog(recordsOrCatalog);
      page = 0;
      return snapshot();
    }

    function clearCatalog() { catalog = null; page = 0; return snapshot(); }
    function setFilter(name, value) {
      if (!Object.prototype.hasOwnProperty.call(filters, name)) throw new TypeError(`unsupported filter: ${name}`);
      if (typeof value !== "string") throw new TypeError(`${name} filter must be a string`);
      if (["animeYearFrom", "animeYearTo"].includes(name) && value !== "" && (!/^\d{4}$/.test(value) || Number(value) < 1900 || Number(value) > 2100)) throw new RangeError(`${name} must be a year between 1900 and 2100`);
      if (name === "familiarityLevel" && value !== "" && !["0", "1", "2", "3", "4"].includes(value)) throw new RangeError("familiarityLevel must be 0–4");
      if (name === "includeUnknownYear" && !["true", "false"].includes(value)) throw new TypeError("includeUnknownYear must be true or false");
      filters[name] = value;
      page = 0;
      return snapshot();
    }
    function setSort(field, direction) {
      const allowed = new Set(["", "title", "artist", "animeTitle", "type", "source", "id", "number", "difficulty", "animeYear"]);
      if (!allowed.has(field)) throw new TypeError("unsupported sort field");
      if (direction !== "asc" && direction !== "desc") throw new TypeError("sort direction must be asc or desc");
      sortBy = field;
      sortDirection = direction;
      page = 0;
      return snapshot();
    }
    function setPageSize(value) {
      if (!Number.isSafeInteger(value) || value < 1 || value > 200) throw new RangeError("page size must be between 1 and 200");
      pageSize = value;
      page = 0;
      return snapshot();
    }
    function movePage(delta) {
      if (!Number.isSafeInteger(delta)) throw new TypeError("page delta must be an integer");
      const total = catalog ? catalog.search(criteria(false)).total : 0;
      const lastPage = Math.max(0, Math.ceil(total / pageSize) - 1);
      page = Math.min(lastPage, Math.max(0, page + delta));
      return snapshot();
    }
    function snapshot() {
      const result = catalog ? catalog.search(criteria(true)) : { total: 0, offset: page * pageSize, limit: pageSize, records: [] };
      function facetCriteria(excluded) {
        const criteria = {};
        const names = ["query", "source", "type", "workKind", "animeYearFrom", "animeYearTo", "includeUnknownYear", "animeType", "animeDecade", "watchStatus", "familiarityLevel", "tagId"];
        names.forEach(name => {
          if (name === excluded) return;
          const value = filters[name];
          if (name === "includeUnknownYear") criteria.includeUnknownYear = value !== "false";
          else if (value !== "" && value != null) criteria[name] = ["animeYearFrom", "animeYearTo", "animeDecade", "familiarityLevel"].includes(name) ? Number(value) : value;
        });
        return criteria;
      }
      const facets = catalog ? {
        sources: catalog.groupBy("source", facetCriteria("source")).groups,
        types: catalog.groupBy("type", facetCriteria("type")).groups,
        workKinds: catalog.groupBy("workKind", facetCriteria("workKind")).groups,
        animeTypes: catalog.groupBy("animeType", facetCriteria("animeType")).groups,
        decades: catalog.groupBy("animeDecade", facetCriteria("animeDecade")).groups
      } : { sources: [], types: [], workKinds: [], animeTypes: [], decades: [] };
      return Object.freeze({
        hasCatalog: Boolean(catalog), filters: Object.freeze({ ...filters }), sortBy, sortDirection,
        page, pageSize, total: result.total, records: result.records, facets,
        pageCount: Math.ceil(result.total / pageSize), start: result.total ? result.offset + 1 : 0,
        end: result.offset + result.records.length
      });
    }
    return Object.freeze({ setCatalog, clearCatalog, setFilter, setSort, setPageSize, movePage, snapshot });
  }

  function buildCatalogWorkspace(root) {
    if (!root || root.querySelector(".catalog-workspace") || typeof root.appendChild !== "function" || typeof document.createElement !== "function") return;
    const heading = root.querySelector(".catalog-title-row");
    const scene = document.createElement("div"); scene.className = "catalog-scene-background";
    scene.setAttribute("aria-hidden", "true"); scene.dataset.artworkStatus = "missing"; scene.dataset.skinComponent = "catalog.selected-artwork-background";
    const sceneImage = document.createElement("img"); sceneImage.alt = ""; sceneImage.decoding = "async";
    scene.appendChild(sceneImage);
    root.prepend(scene);
    const workspace = document.createElement("div"); workspace.className = "catalog-workspace";
    workspace.setAttribute("data-catalog-layout", "osu-stable-inspired");
    const sidebar = document.createElement("aside"); sidebar.className = "catalog-sidebar"; sidebar.setAttribute("aria-label", "曲庫搜尋、篩選與管理");
    const center = document.createElement("section"); center.className = "catalog-main-list"; center.setAttribute("aria-label", "歌曲列表");
    const detail = document.createElement("aside"); detail.className = "catalog-detail-column"; detail.dataset.skinComponent = "catalog.selected-work-stage"; detail.setAttribute("aria-label", "目前選取歌曲資訊");
    const oldLayout = root.querySelector(".catalog-select-layout");
    const list = oldLayout && oldLayout.querySelector(".catalog-list-wrap");
    const details = root.querySelector("#catalog-selection-details");
    const move = (selector, parent) => { const node = root.querySelector(selector); if (node) parent.appendChild(node); return node; };
    const collapsible = (selectors, title, className) => {
      const nodes = selectors.map(selector => root.querySelector(selector)).filter(Boolean);
      if (!nodes.length) return;
      const disclosure = document.createElement("details"); disclosure.className = `catalog-management-group ${className || ""}`;
      const summary = document.createElement("summary"); summary.textContent = title; disclosure.appendChild(summary);
      nodes.forEach(node => disclosure.appendChild(node)); sidebar.appendChild(disclosure);
    };
    if (heading) heading.after(workspace); else root.appendChild(workspace);
    workspace.append(sidebar, center, detail);
    const modePanel = root.parentElement && root.parentElement.querySelector("#catalog-mode-selector");
    if (modePanel) {
      const modeStrip = document.createElement("div");
      modeStrip.id = "catalog-mode-selector";
      modeStrip.className = "catalog-mode-strip";
      modeStrip.dataset.skinRole = "catalog.mode-selector";
      modeStrip.dataset.skinComponent = "catalog.mode-selector";
      modeStrip.setAttribute("role", "group");
      modeStrip.setAttribute("aria-label", "AMQ／EMQ／MIX 曲庫來源");
      const modeRow = modePanel.querySelector(".mode-row");
      if (modeRow) modeStrip.appendChild(modeRow);
      if (heading) heading.insertBefore(modeStrip, heading.querySelector(".catalog-actions"));
      const stateGrid = modePanel.querySelector(".state-grid");
      const message = modePanel.querySelector("#app-message");
      if (stateGrid || message) {
        const statusDetails = document.createElement("details");
        statusDetails.className = "catalog-mode-status";
        const statusSummary = document.createElement("summary"); statusSummary.textContent = "曲庫／練習狀態";
        statusDetails.appendChild(statusSummary);
        if (stateGrid) statusDetails.appendChild(stateGrid);
        if (message) statusDetails.appendChild(message);
        sidebar.appendChild(statusDetails);
      }
      modePanel.remove();
    }
    move(".catalog-primary-controls", sidebar);
    move("#catalog-advanced-filters", sidebar);
    collapsible([".catalog-presets-controls", "#catalog-filter-preset-status"], "篩選預設", "catalog-presets-group");
    collapsible([".catalog-tags-controls", "#catalog-tag-status"], "歌曲標籤", "catalog-tags-group");
    collapsible([".catalog-batch-controls", "#catalog-batch-status"], "批次操作", "catalog-batch-group");
    collapsible([".personal-library"], "個人作品清單", "catalog-library-group");
    move(".catalog-summary-row", center);
    move("#catalog-error", center);
    if (list) center.appendChild(list);
    if (details) detail.appendChild(details);
    move(".pagination", center);
    move(".catalog-footnote", center);
    if (oldLayout) oldLayout.remove();
  }

  function mount(options) {
    const settings = options && typeof options === "object" ? options : {};
    const store = settings.stateStore || (global.AMQCore && global.AMQCore.state);
    const queryIndex = settings.queryIndex || (global.AMQData && global.AMQData.queryIndex);
    if (!store || typeof store.getState !== "function" || typeof store.subscribe !== "function") throw new TypeError("catalog browser requires shared state store");
    const root = document.getElementById("catalog-browser");
    if (!root) throw new Error("catalog browser root is missing");
    buildCatalogWorkspace(root);
    const controller = createController(queryIndex);
    let runtime = settings.runtime || null;
    const artworkAdapter = settings.artworkAdapter && typeof settings.artworkAdapter.getArtwork === "function" ? settings.artworkAdapter : null;
    let artworkRenderSequence = 0;
    let disposed = false;
    let loading = false;
    let loadError = "";
    let loadSequence = 0;
    let lastMode = store.getState().mode;
    let selectedRecord = null;
    let selectedRecordKey = "";
    const batchSelection = new Map();
    const libraryApi = global.AMQPersistence && global.AMQPersistence.personalLibraryStore;
    const settingsApi = global.AMQPersistence && global.AMQPersistence.appSettingsStore;
    const familiarityApi = global.AMQPersistence && global.AMQPersistence.familiarityStore;
    const songTagsApi = global.AMQPersistence && global.AMQPersistence.songTagsStore;
    const chineseTitleApi = global.AMQData && global.AMQData.chineseTitleProvider;
    const ownsChineseTitleProvider = !settings.chineseTitleProvider;
    const chineseTitleProvider = settings.chineseTitleProvider || (chineseTitleApi && typeof chineseTitleApi.createChineseTitleProvider === "function"
      ? chineseTitleApi.createChineseTitleProvider() : null);
    let chineseTitleRequest = 0;
    let lastChineseEnabled = false;
    const ownsLibraryStore = !settings.personalLibraryStore;
    const ownsSettingsStore = !settings.appSettingsStore;
    const ownsFamiliarityStore = !settings.familiarityStore;
    const ownsSongTagsStore = !settings.songTagsStore;
    const personalLibrary = settings.personalLibraryStore || (libraryApi && libraryApi.createPersonalLibraryStore());
    const appSettings = settings.appSettingsStore || (settingsApi && settingsApi.createAppSettingsStore());
    const familiarity = settings.familiarityStore || (familiarityApi && familiarityApi.createFamiliarityStore());
    const songTags = settings.songTagsStore || (songTagsApi && songTagsApi.createSongTagsStore());
    if (personalLibrary && typeof personalLibrary.refresh === "function") personalLibrary.refresh();
    if (appSettings && typeof appSettings.refresh === "function") appSettings.refresh();
    lastChineseEnabled = Boolean(appSettings && appSettings.getSettings && appSettings.getSettings().chineseTitlesEnabled === true);
    const elements = {
      query: root.querySelector("#catalog-query"), source: root.querySelector("#catalog-source"),
      type: root.querySelector("#catalog-type"), workKind: root.querySelector("#catalog-work-kind"),
      yearFrom: root.querySelector("#catalog-year-from"), yearTo: root.querySelector("#catalog-year-to"), includeUnknownYear: root.querySelector("#catalog-unknown-year"),
      animeType: root.querySelector("#catalog-anime-type"), decade: root.querySelector("#catalog-decade"), watchFilter: root.querySelector("#catalog-watch-status"), familiarityFilter: root.querySelector("#catalog-familiarity"),
      sort: root.querySelector("#catalog-sort"), direction: root.querySelector("#catalog-direction"),
      tagFilter: root.querySelector("#catalog-tag-filter"), tagName: root.querySelector("#catalog-tag-name"), tagCreate: root.querySelector("#catalog-tag-create"),
      tagRename: root.querySelector("#catalog-tag-rename"), tagDelete: root.querySelector("#catalog-tag-delete"), tagStatus: root.querySelector("#catalog-tag-status"),
      selectPage: root.querySelector("#catalog-select-page"), clearSelection: root.querySelector("#catalog-clear-selection"), selectedCount: root.querySelector("#catalog-selected-count"),
      batchListAdd: root.querySelector("#catalog-batch-list-add"), batchTag: root.querySelector("#catalog-batch-tag"), batchTagApply: root.querySelector("#catalog-batch-tag-apply"), batchTagRemove: root.querySelector("#catalog-batch-tag-remove"), batchStatus: root.querySelector("#catalog-batch-status"),
      preset: root.querySelector("#catalog-filter-preset"), presetName: root.querySelector("#catalog-filter-preset-name"),
      presetSave: root.querySelector("#catalog-filter-preset-save"), presetApply: root.querySelector("#catalog-filter-preset-apply"),
      presetDelete: root.querySelector("#catalog-filter-preset-delete"), presetStatus: root.querySelector("#catalog-filter-preset-status"),
      pageSize: root.querySelector("#catalog-page-size"), previous: root.querySelector("#catalog-previous"),
      next: root.querySelector("#catalog-next"), reload: root.querySelector("#catalog-reload"),
      summary: root.querySelector("#catalog-summary"), status: root.querySelector("#catalog-status"),
      rows: root.querySelector("#catalog-rows"), empty: root.querySelector("#catalog-empty"),
      selectionDetails: root.querySelector("#catalog-selection-details"), selectionEmpty: root.querySelector("#catalog-selection-empty"),
      selectionContent: root.querySelector("#catalog-selection-content"),
      error: root.querySelector("#catalog-error"),
      listSelect: root.querySelector("#personal-list-select"), listName: root.querySelector("#personal-list-name"),
      listCreate: root.querySelector("#personal-list-create"), listRename: root.querySelector("#personal-list-rename"),
      listDelete: root.querySelector("#personal-list-delete"), addWork: root.querySelector("#personal-list-add-work"),
      removeWork: root.querySelector("#personal-list-remove-work"), watchStatus: root.querySelector("#personal-watch-status"),
      librarySelection: root.querySelector("#personal-library-selection"), libraryStatus: root.querySelector("#personal-library-status"),
      libraryError: root.querySelector("#personal-library-error"), listMembers: root.querySelector("#personal-list-members")
    };
    const removers = [];
    function listen(element, event, handler) {
      if (!element) return;
      element.addEventListener(event, handler);
      removers.push(() => element.removeEventListener(event, handler));
    }
    let chineseTitleLoaded = false;
    function recordsFromCatalog(catalog) {
      if (!catalog || typeof catalog.search !== "function") return [];
      const records = [];
      for (let offset = 0; offset < catalog.size; offset += 10000) records.push(...catalog.search({ offset, limit: Math.min(10000, catalog.size - offset) }).records);
      return records.map(record => {
        const year = Number(record.animeYear);
        const workRef = record.animeId == null ? null : { source: record.source, id: record.animeId };
        const status = workRef && personalLibrary && typeof personalLibrary.getWorkWatchStatus === "function" ? personalLibrary.getWorkWatchStatus(workRef) : "none";
        const level = familiarity && typeof familiarity.getLevel === "function" ? familiarity.getLevel(record) : 0;
        const aliases = chineseTitleLoaded && chineseTitleProvider ? chineseTitleProvider.getAliases(record) : [];
        const tagIds = songTags && typeof songTags.getTagIds === "function" ? songTags.getTagIds(record) : [];
        return { ...record, tagIds, animeDecade: Number.isFinite(year) && year > 0 ? Math.floor(year / 10) * 10 : null,
          watchStatus: status || "none", familiarityLevel: Number.isInteger(level) && level >= 0 && level <= 4 ? level : null,
          ...(aliases.length ? { animeAliases: [...new Set([...(record.animeAliases || []), ...aliases])] } : {}) };
      });
    }
    function rebuildCatalogIndex() {
      if (disposed || !runtime || !runtime.catalogSnapshot) return false;
      const catalog = runtime.catalogSnapshot();
      if (!catalog) return false;
      controller.setCatalog(recordsFromCatalog(catalog));
      render();
      return true;
    }
    function optionLabel(group) { return `${group.label} (${group.count})`; }
    function refreshSelect(select, groups, allLabel, selected) {
      if (!select) return;
      const options = [{ value: "", label: allLabel }, ...groups.map(group => ({ value: String(group.value), label: optionLabel(group) }))];
      const previous = selected;
      if (previous && !options.some(item => item.value === previous)) options.push({ value: previous, label: `${previous} (目前篩選)` });
      select.replaceChildren(...options.map(item => {
        const option = document.createElement("option");
        option.value = item.value;
        option.textContent = item.label;
        return option;
      }));
      select.value = options.some(item => item.value === previous) ? previous : "";
    }
    function recordKey(record) { return record && global.AMQData && global.AMQData.identity ? global.AMQData.identity.createIdentity(record.source || "", record.id) : record ? `${String(record.source || "")}\u0000${typeof record.id}:${String(record.id)}` : ""; }
    function selectedWorkId() { return selectedRecord && selectedRecord.animeId != null ? String(selectedRecord.animeId) : ""; }
    function selectedWorkRef() { return selectedRecord && selectedRecord.animeId != null && (selectedRecord.source === "AMQ" || selectedRecord.source === "EMQ")
      ? { source: selectedRecord.source, id: String(selectedRecord.animeId) } : null; }
    function selectedListId() { return elements.listSelect && elements.listSelect.value ? elements.listSelect.value : ""; }
    function selectedList() {
      if (!personalLibrary) return null;
      const result = personalLibrary.getListsResult();
      return result.data && result.data.lists.find(item => String(item.id) === selectedListId()) || null;
    }
    let libraryActionMessage = "";
    let libraryActionError = "";
    function libraryMessage(message, error) {
      libraryActionMessage = message || "";
      libraryActionError = error || "";
      if (elements.libraryStatus) elements.libraryStatus.textContent = libraryActionMessage;
      if (elements.libraryError) elements.libraryError.textContent = libraryActionError;
    }
    function showLibraryResult(result, successMessage, failureMessage) {
      if (result && result.ok && result.persisted !== false) libraryMessage(successMessage || "已保存。", "");
      else libraryMessage(failureMessage || "操作未完成，資料未確認保存。", result && result.reason ? `原因：${result.reason}` : "個人清單功能目前不可用。");
      renderLibrary();
    }
    function renderLibrary() {
      if (!personalLibrary || !elements.listSelect) return;
      const result = personalLibrary.getListsResult();
      const currentId = appSettings && appSettings.getSettings ? appSettings.getSettings().customListId || "" : elements.listSelect.value;
      const lists = result.data && result.data.lists || [];
      const options = [{ value: "", label: "請選擇清單" }, ...lists.map(item => ({ value: String(item.id), label: `${item.name} (${item.animeIds.length + (item.workRefs || []).length})` }))];
      if (currentId && !options.some(option => option.value === currentId)) options[0].label = "請選擇清單";
      elements.listSelect.replaceChildren(...options.map(item => { const option = document.createElement("option"); option.value = item.value; option.textContent = item.label; return option; }));
      elements.listSelect.value = options.some(item => item.value === currentId) ? currentId : "";
      const list = selectedList();
      const workId = selectedWorkId();
      const workRef = selectedWorkRef();
      const member = Boolean(list && workRef && personalLibrary.hasWorkMembership(list.id, workRef));
      const hasWork = Boolean(workRef);
      const listStatus = result.error
        ? result.status === "unavailable" || result.status === "invalid" ? `個人清單讀取失敗：${result.error}` : `個人清單保存失敗：${result.error}`
        : result.status === "recovered-invalid" ? "已隔離無效的個人清單資料，請確認復原備份。" : "個人清單已連接本機持久化。";
      const watchPersistence = personalLibrary.getStatus().watchlist;
      const watchProblem = watchPersistence.blocked || watchPersistence.readError || watchPersistence.writeError
        ? `看番狀態儲存異常：${watchPersistence.readError || watchPersistence.writeError || "寫入已阻塞"}`
        : watchPersistence.recoveryAvailable ? "看番狀態資料曾經損壞，原始內容已隔離；請確認復原備份。" : "";
      if (!libraryActionMessage && (["unavailable", "invalid", "recovered-invalid"].includes(result.status) || result.error)) {
        if (elements.libraryStatus) elements.libraryStatus.textContent = listStatus;
        if (elements.libraryError) elements.libraryError.textContent = result.error ? `儲存狀態：${result.error}` : "";
      } else if (!libraryActionMessage) {
        if (elements.libraryStatus) elements.libraryStatus.textContent = listStatus;
        if (elements.libraryError) elements.libraryError.textContent = watchProblem;
      }
      if (elements.librarySelection) elements.librarySelection.textContent = selectedRecord ? `目前作品：${selectedRecord.animeTitle || "未提供作品名稱"}（${workRef ? `${workRef.source}:${workId}` : "來源未知"}）` : "尚未選取歌曲／作品";
      if (elements.listRename) elements.listRename.disabled = !list;
      if (elements.listDelete) elements.listDelete.disabled = !list;
      if (elements.addWork) elements.addWork.disabled = !list || !hasWork || member;
      if (elements.removeWork) elements.removeWork.disabled = !list || !hasWork || !member;
      const currentWorkWatchStatus = hasWork ? personalLibrary.getWorkWatchStatus(workRef) : "none";
      const legacyWorkWatchStatus = workId ? personalLibrary.getWatchStatus(workId) : "none";
      if (elements.watchStatus) { elements.watchStatus.disabled = !hasWork; elements.watchStatus.value = currentWorkWatchStatus; }
      if (!libraryActionError && !watchProblem && hasWork && currentWorkWatchStatus === "none" && legacyWorkWatchStatus !== "none"
        && elements.libraryError) {
        elements.libraryError.textContent = `找到未標記來源的舊看番狀態「${legacyWorkWatchStatus}」，為避免 AMQ／EMQ ID 撞號未自動套用。`;
      }
      if (elements.listMembers) {
        const refs = list ? (list.workRefs || []).map(ref => `${ref.source}:${ref.id}`) : [];
        const legacy = list ? list.animeIds : [];
        elements.listMembers.textContent = list
          ? `來源明確成員（${refs.length}）：${refs.join(", ") || "無"}${legacy.length ? `；舊版未標記來源的成員（${legacy.length}）不會自動套用出題池：${legacy.join(", ")}` : ""}`
          : "目前清單尚未選擇。";
      }
      renderBatchSelection();
    }
    let selectionArtworkSequence = 0;
    function artworkFallbackLabel(record) {
      const title = String(record && record.animeTitle || "").trim();
      if (title) return title.length > 14 ? `${title.slice(0, 13)}…` : title;
      const source = String(record && record.source || "作品").trim();
      return source === "EMQ" ? "GAME" : source === "AMQ" ? "ANIME" : "ARTWORK";
    }
    function createArtworkFallback(record, className) {
      const artwork = document.createElement("span");
      artwork.className = className || "catalog-artwork";
      artwork.setAttribute("data-artwork-status", "missing");
      artwork.setAttribute("aria-label", `作品封面未提供：${String(record && record.animeTitle || "未命名作品")}`);
      const source = String(record && record.source || "MIX").toUpperCase();
      const sourceLabel = source === "EMQ" ? "GAME" : source === "AMQ" ? "ANIME" : "MIX";
      artwork.setAttribute("data-artwork-source", source === "AMQ" || source === "EMQ" ? source : "MIX");
      artwork.setAttribute("data-artwork-source-label", sourceLabel);
      const fallback = document.createElement("span");
      fallback.className = "catalog-artwork-fallback";
      fallback.setAttribute("aria-hidden", "true");
      fallback.setAttribute("data-artwork-source-label", sourceLabel);
      const mark = document.createElement("span");
      mark.className = "catalog-artwork-mark";
      const title = String(record && record.animeTitle || "").trim();
      mark.textContent = title ? Array.from(title)[0] : source === "EMQ" ? "G" : source === "AMQ" ? "A" : "M";
      const label = document.createElement("span");
      label.className = "catalog-artwork-title-label";
      label.textContent = artworkFallbackLabel(record);
      fallback.appendChild(mark);
      fallback.appendChild(label);
      artwork.appendChild(fallback);
      return { artwork, fallback };
    }
    function createArtworkSourceLink(result) {
      if (!result || typeof result.sourceUrl !== "string" || typeof result.attribution !== "string") return null;
      let sourceUrl;
      try { sourceUrl = new URL(result.sourceUrl); } catch (_) { return null; }
      if (sourceUrl.protocol !== "https:") return null;
      const sourceLink = document.createElement("a");
      sourceLink.className = "catalog-artwork-source";
      sourceLink.href = sourceUrl.href;
      sourceLink.target = "_blank";
      sourceLink.rel = "noopener noreferrer";
      sourceLink.textContent = `來源：${result.provider || "作品資料"}`;
      sourceLink.title = result.attribution;
      sourceLink.setAttribute("aria-label", `${result.attribution}，在新分頁開啟作品來源`);
      return sourceLink;
    }
    function setCatalogSceneArtwork(url, sequence) {
      const scene = root.querySelector(".catalog-scene-background");
      const image = scene && scene.querySelector("img");
      if (!scene || !image) return;
      if (!url) {
        image.removeAttribute("src");
        scene.dataset.artworkStatus = "missing";
        scene.removeAttribute("data-artwork-sequence");
        return;
      }
      const candidate = new URL(url, global.location && global.location.href || "https://localhost/");
      if (!(["https:", "blob:"].includes(candidate.protocol))) return;
      const probe = new Image();
      probe.decoding = "async";
      probe.onload = () => {
        if (disposed || sequence !== selectionArtworkSequence || !scene.isConnected) return;
        image.src = candidate.href;
        scene.dataset.artworkStatus = "available";
        scene.dataset.artworkSequence = String(sequence);
      };
      probe.onerror = () => {
        if (disposed || sequence !== selectionArtworkSequence) return;
        image.removeAttribute("src");
        scene.dataset.artworkStatus = "missing";
      };
      probe.src = candidate.href;
    }
    function renderSelectionDetails(record) {
      if (!elements.selectionContent || !elements.selectionEmpty) return;
      selectionArtworkSequence += 1;
      const sequence = selectionArtworkSequence;
      setCatalogSceneArtwork(null, sequence);
      elements.selectionContent.replaceChildren();
      elements.selectionContent.hidden = !record;
      elements.selectionEmpty.hidden = Boolean(record);
      if (!record) { elements.selectionEmpty.textContent = "選取一首歌曲以查看作品資訊。"; return; }
      elements.selectionEmpty.textContent = "";
      const songTitle = document.createElement("h4");
      songTitle.className = "catalog-selection-song-title";
      songTitle.textContent = record.title || "未提供歌曲名稱";
      const workTitle = document.createElement("p");
      workTitle.className = "catalog-selection-work-title";
      workTitle.textContent = record.animeTitle || "未提供作品名稱";
      const artist = document.createElement("p");
      artist.className = "catalog-selection-meta";
      artist.textContent = `歌手：${record.artist || "未提供"}`;
      const metadata = document.createElement("p");
      metadata.className = "catalog-selection-meta";
      const year = record.animeYear ? String(record.animeYear) : "年份未知";
      metadata.textContent = `${record.type || "類型未知"} · ${year} · ${record.source || "來源未知"}`;
      elements.selectionContent.appendChild(songTitle);
      elements.selectionContent.appendChild(workTitle);
      elements.selectionContent.appendChild(artist);
      elements.selectionContent.appendChild(metadata);
      const cover = document.createElement("div");
      cover.className = "catalog-selection-cover";
      const fallbackParts = createArtworkFallback(record, "catalog-selection-artwork-fallback");
      cover.appendChild(fallbackParts.artwork);
      elements.selectionContent.appendChild(cover);
      if (artworkAdapter && record.artworkRef) {
        fallbackParts.fallback.textContent = "封面載入中";
        fallbackParts.artwork.setAttribute("data-artwork-status", "loading");
        void artworkAdapter.getArtwork(record).then(result => {
          if (disposed || sequence !== selectionArtworkSequence || cover.isConnected === false) return;
          if (!result || !result.url) {
            fallbackParts.fallback.textContent = artworkFallbackLabel(record);
            fallbackParts.artwork.setAttribute("data-artwork-status", "missing");
            fallbackParts.artwork.setAttribute("aria-label", `作品封面未提供：${String(record.animeTitle || "未命名作品")}`);
            return;
          }
          const image = document.createElement("img");
          image.className = "catalog-selection-cover-image";
          image.alt = `${record.animeTitle || "作品"}封面`;
          image.loading = "lazy";
          image.decoding = "async";
          image.addEventListener("load", () => {
            if (disposed || sequence !== selectionArtworkSequence || cover.isConnected === false) return;
            fallbackParts.fallback.hidden = true;
            fallbackParts.artwork.setAttribute("data-artwork-status", "available");
            setCatalogSceneArtwork(result.url, sequence);
            fallbackParts.artwork.setAttribute("aria-label", `作品封面：${String(record.animeTitle || "未命名作品")}`);
            const sourceLink = createArtworkSourceLink(result);
            if (sourceLink) cover.appendChild(sourceLink);
          }, { once: true });
          image.addEventListener("error", () => {
            image.remove();
            for (const link of cover.children.filter(child => child.className === "catalog-artwork-source")) link.remove();
            fallbackParts.fallback.textContent = artworkFallbackLabel(record);
            fallbackParts.fallback.hidden = false;
            fallbackParts.artwork.setAttribute("data-artwork-status", "missing");
            fallbackParts.artwork.setAttribute("aria-label", `作品封面載入失敗：${String(record.animeTitle || "未命名作品")}`);
          }, { once: true });
          cover.insertBefore(image, fallbackParts.artwork);
          fallbackParts.artwork.setAttribute("data-artwork-status", "loading");
          fallbackParts.artwork.setAttribute("aria-label", `作品封面載入中：${String(record.animeTitle || "未命名作品")}`);
          image.src = result.url;
        }).catch(() => {
          if (!disposed && sequence === selectionArtworkSequence) {
            fallbackParts.fallback.textContent = artworkFallbackLabel(record);
            fallbackParts.artwork.setAttribute("data-artwork-status", "missing");
            fallbackParts.artwork.setAttribute("aria-label", `作品封面未提供：${String(record.animeTitle || "未命名作品")}`);
          }
        });
      }
    }
    function selectRecord(record, row, focus) {
      selectedRecord = record || null; selectedRecordKey = recordKey(record);
      if (elements.rows) for (const item of elements.rows.children || []) {
        const isSelected = item.getAttribute ? item.getAttribute("data-record-key") === selectedRecordKey : false;
        if (item.setAttribute) item.setAttribute("aria-selected", String(isSelected));
      }
      renderSelectionDetails(selectedRecord);
      if (focus && row && typeof row.focus === "function") row.focus();
      renderLibrary();
    }
    function isInteractiveTarget(target) {
      const tag = String(target && target.tagName || "").toLowerCase();
      return ["input", "textarea", "select", "button", "a"].includes(tag) || Boolean(target && target.isContentEditable);
    }
    renderSelectionDetails(null);
    function getFilterPresets() {
      return appSettings && appSettings.getSettings ? appSettings.getSettings().catalogFilterPresets || [] : [];
    }
    function selectedFilterPreset() {
      const id = elements.preset && elements.preset.value;
      return id ? getFilterPresets().find(item => item.id === id) || null : null;
    }
    function renderFilterPresets() {
      if (!elements.preset) return;
      const presets = getFilterPresets();
      const selectedId = elements.preset.value;
      const options = [{ value: "", label: "選擇預設" }, ...presets.map(item => ({ value: item.id, label: item.name }))];
      elements.preset.replaceChildren(...options.map(item => {
        const option = document.createElement("option"); option.value = item.value; option.textContent = item.label; return option;
      }));
      elements.preset.value = options.some(item => item.value === selectedId) ? selectedId : "";
      const selected = selectedFilterPreset();
      if (elements.presetApply) elements.presetApply.disabled = !selected;
      if (elements.presetDelete) elements.presetDelete.disabled = !selected;
      if (elements.presetSave) elements.presetSave.disabled = !appSettings || presets.length >= 30 && !presets.some(item => item.name.toLocaleLowerCase() === String(elements.presetName && elements.presetName.value || "").trim().toLocaleLowerCase());
    }
    function setPresetStatus(message, isError = false) {
      if (!elements.presetStatus) return;
      elements.presetStatus.textContent = message;
      elements.presetStatus.dataset.state = isError ? "error" : "ok";
    }
    function applyFilterPreset(preset) {
      if (!preset) return false;
      const mapping = {
        query: elements.query, source: elements.source, type: elements.type, workKind: elements.workKind,
        animeYearFrom: elements.yearFrom, animeYearTo: elements.yearTo, includeUnknownYear: elements.includeUnknownYear,
        animeType: elements.animeType, animeDecade: elements.decade, watchStatus: elements.watchFilter,
        familiarityLevel: elements.familiarityFilter, tagId: elements.tagFilter
      };
      try {
        for (const [name, element] of Object.entries(mapping)) {
          const value = preset.filters[name];
          if (name === "includeUnknownYear") {
            controller.setFilter(name, value);
            if (element) element.checked = value !== "false";
          } else {
            controller.setFilter(name, value);
            if (element) element.value = value;
          }
        }
        controller.setSort(preset.sortBy, preset.sortDirection);
        controller.setPageSize(preset.pageSize);
        if (elements.sort) elements.sort.value = preset.sortBy;
        if (elements.direction) elements.direction.value = preset.sortDirection;
        if (elements.pageSize) elements.pageSize.value = String(preset.pageSize);
        if (preset.filters.watchStatus || preset.filters.familiarityLevel !== "") rebuildCatalogIndex();
        render();
        setPresetStatus(`已套用「${preset.name}」。`);
        return true;
      } catch (error) {
        setPresetStatus(`無法套用「${preset.name}」：${error.message}`, true);
        return false;
      }
    }
    function currentTags() { return songTags && typeof songTags.getTags === "function" ? songTags.getTags() : []; }
    function selectedTagId() { return elements.batchTag && elements.batchTag.value || ""; }
    function setTagStatus(message, isError = false) {
      if (elements.tagStatus) { elements.tagStatus.textContent = message; elements.tagStatus.dataset.state = isError ? "error" : "ok"; }
    }
    function setBatchStatus(message, isError = false) {
      if (elements.batchStatus) { elements.batchStatus.textContent = message; elements.batchStatus.dataset.state = isError ? "error" : "ok"; }
    }
    function renderTagControls() {
      const tags = currentTags();
      const activeTagId = controller.snapshot().filters.tagId;
      if (activeTagId && !tags.some(tag => tag.id === activeTagId)) controller.setFilter("tagId", "");
      for (const select of [elements.tagFilter, elements.batchTag]) {
        if (!select) continue;
        const previous = select.value;
        const options = [{ value: "", label: select === elements.tagFilter ? "全部標籤" : "選擇標籤" }, ...tags.map(tag => ({ value: tag.id, label: tag.name }))];
        select.replaceChildren(...options.map(item => { const option = document.createElement("option"); option.value = item.value; option.textContent = item.label; return option; }));
        select.value = options.some(item => item.value === previous) ? previous : "";
      }
      const selected = elements.tagFilter && elements.tagFilter.value;
      if (elements.tagRename) elements.tagRename.disabled = !selected;
      if (elements.tagDelete) elements.tagDelete.disabled = !selected;
      if (elements.batchTagApply) elements.batchTagApply.disabled = !selectedTagId() || batchSelection.size === 0;
      if (elements.batchTagRemove) elements.batchTagRemove.disabled = !selectedTagId() || batchSelection.size === 0;
    }
    function renderBatchSelection() {
      if (elements.selectedCount) elements.selectedCount.textContent = `已選取 ${batchSelection.size} 首`;
      if (elements.clearSelection) elements.clearSelection.disabled = batchSelection.size === 0;
      if (elements.batchListAdd) elements.batchListAdd.disabled = batchSelection.size === 0 || !selectedListId();
      if (elements.batchTagApply) elements.batchTagApply.disabled = batchSelection.size === 0 || !selectedTagId();
      if (elements.batchTagRemove) elements.batchTagRemove.disabled = batchSelection.size === 0 || !selectedTagId();
      if (elements.selectPage) {
        const visible = controller.snapshot().records;
        const count = visible.filter(record => batchSelection.has(recordKey(record))).length;
        elements.selectPage.textContent = visible.length && count === visible.length ? "取消選取本頁" : "選取本頁歌曲";
        elements.selectPage.disabled = visible.length === 0;
      }
    }
    function setBatchSelected(record, selected) {
      const key = recordKey(record);
      if (selected) batchSelection.set(key, record); else batchSelection.delete(key);
      renderBatchSelection();
      renderTagControls();
    }
    function render() {
      const activeElement = document.activeElement;
      const focusedRecordKey = activeElement && typeof activeElement.getAttribute === "function" ? activeElement.getAttribute("data-record-key") : null;
      const shouldRestoreRowFocus = Boolean(focusedRecordKey);
      const appState = store.getState();
      let state = controller.snapshot();
      if (selectedRecordKey && !state.records.some(record => recordKey(record) === selectedRecordKey)) {
        selectedRecord = null;
        selectedRecordKey = "";
        renderSelectionDetails(null);
      }
      if (["not-loaded", "loading", "failed"].includes(appState.dataStatus) && state.hasCatalog) {
        controller.clearCatalog();
        state = controller.snapshot();
      }
      const statusLabels = { "not-loaded": "尚未載入真實曲庫", loading: "曲庫載入中", loaded: "曲庫已載入", partial: "曲庫部分載入，存在無效記錄", empty: "曲庫資料為空", failed: "曲庫載入失敗" };
      const catalogState = loadError || appState.dataStatus === "failed" ? "failed"
        : loading || appState.dataStatus === "loading" ? "loading"
          : appState.dataStatus === "empty" ? "empty"
            : appState.dataStatus === "partial" ? "partial"
              : state.hasCatalog && state.total === 0 ? "filtered-empty"
                : state.hasCatalog ? "loaded" : "not-loaded";
      if (typeof root.setAttribute === "function") {
        root.setAttribute("data-catalog-state", catalogState);
        root.setAttribute("aria-busy", loading ? "true" : "false");
      }
      if (elements.status) {
        elements.status.textContent = catalogState === "loading" ? "曲庫載入中"
          : catalogState === "failed" ? "曲庫載入失敗"
            : catalogState === "filtered-empty" ? "沒有符合條件的歌曲"
              : (statusLabels[appState.dataStatus] || "資料狀態未知");
        if (typeof elements.status.setAttribute === "function") elements.status.setAttribute("data-status", catalogState);
      }
      if (elements.error) {
        const dataErrorText = appState.dataError ? formatCatalogError(appState.dataError, "曲庫載入失敗") : "";
        const errorText = loadError || dataErrorText;
        elements.error.textContent = errorText;
        elements.error.hidden = !errorText;
        if (typeof elements.error.setAttribute === "function") {
          const normalized = appState.dataError ? global.AMQCore.errors.normalize(appState.dataError, { code: "DATA_LOAD_FAILED", category: "data", message: "曲庫載入失敗" }) : null;
          elements.error.setAttribute("data-error-code", normalized ? normalized.code : (loadError.match(/^([A-Z0-9_]+)：/) || [])[1] || "");
        }
      }
      if (elements.summary) elements.summary.textContent = !state.hasCatalog
        ? "尚未建立曲庫索引。請先接入經驗證的真實資料來源。"
        : appState.dataStatus === "empty" || state.total === 0 && !Object.entries(state.filters).some(([name, value]) => name !== "includeUnknownYear" && value !== "" && value != null) && state.page === 0
          ? "曲庫目前沒有可用歌曲資料。"
          : `符合條件 ${state.total.toLocaleString()} 首，顯示第 ${state.start.toLocaleString()}–${state.end.toLocaleString()} 首`;
      refreshSelect(elements.source, state.facets.sources, "全部來源", state.filters.source);
      refreshSelect(elements.type, state.facets.types, "全部歌曲類型", state.filters.type);
      refreshSelect(elements.workKind, state.facets.workKinds, "全部作品類型", state.filters.workKind);
      refreshSelect(elements.animeType, state.facets.animeTypes, "全部作品細分類", state.filters.animeType);
      refreshSelect(elements.decade, state.facets.decades, "全部年代", state.filters.animeDecade);
      renderFilterPresets();
      renderTagControls();
      renderBatchSelection();
      if (elements.rows) {
        artworkRenderSequence += 1;
        elements.rows.replaceChildren();
        state.records.forEach((record, index) => {
          const row = document.createElement("tr");
          const key = recordKey(record);
          row.setAttribute("data-record-key", key);
          row.setAttribute("aria-selected", String(key === selectedRecordKey));
          row.setAttribute("tabindex", "0");
          row.setAttribute("aria-label", `${record.title || "未提供"}，${record.animeTitle || "未提供作品"}，按 Enter 選取`);
          [record.title, record.artist, record.animeTitle, record.type, record.source].forEach((value, columnIndex) => {
            const cell = document.createElement("td");
            if (columnIndex === 0) {
              cell.className = "catalog-title-cell catalog-title-cell--artwork";
              const fallbackParts = createArtworkFallback(record);
              if (artworkAdapter && record.artworkRef) {
                fallbackParts.fallback.textContent = "封面載入中";
                fallbackParts.artwork.setAttribute("data-artwork-status", "loading");
              }
              cell.appendChild(fallbackParts.artwork);
              const renderSequence = artworkRenderSequence;
              if (artworkAdapter && record.artworkRef) {
                void artworkAdapter.getArtwork(record).then(result => {
                  if (disposed || renderSequence !== artworkRenderSequence || row.isConnected === false || fallbackParts.artwork.isConnected === false) return;
                  if (!result || !result.url) {
                    fallbackParts.fallback.textContent = artworkFallbackLabel(record);
                    fallbackParts.artwork.setAttribute("data-artwork-status", "missing");
                    fallbackParts.artwork.setAttribute("aria-label", `作品封面未提供：${String(record.animeTitle || "未命名作品")}`);
                    return;
                  }
                  const image = document.createElement("img");
                  image.className = "catalog-artwork-image";
                  image.alt = "";
                  image.loading = "lazy";
                  image.decoding = "async";
                  image.addEventListener("load", () => {
                    if (disposed || renderSequence !== artworkRenderSequence || row.isConnected === false || fallbackParts.artwork.isConnected === false) return;
                    fallbackParts.fallback.hidden = true;
                    fallbackParts.artwork.setAttribute("data-artwork-status", "available");
                    fallbackParts.artwork.setAttribute("aria-label", `作品封面：${String(record.animeTitle || "未命名作品")}`);
                    const sourceLink = createArtworkSourceLink(result);
                    if (sourceLink) cell.appendChild(sourceLink);
                  }, { once: true });
                  image.addEventListener("error", () => {
                    image.remove();
                    for (const link of cell.children.filter(child => child.className === "catalog-artwork-source")) link.remove();
                    fallbackParts.fallback.textContent = artworkFallbackLabel(record);
                    fallbackParts.fallback.hidden = false;
                    fallbackParts.artwork.setAttribute("data-artwork-status", "missing");
                    fallbackParts.artwork.setAttribute("aria-label", `作品封面載入失敗：${String(record.animeTitle || "未命名作品")}`);
                  }, { once: true });
                  fallbackParts.artwork.insertBefore(image, fallbackParts.fallback);
                  fallbackParts.artwork.setAttribute("data-artwork-status", "loading");
                  fallbackParts.artwork.setAttribute("aria-label", `作品封面載入中：${String(record.animeTitle || "未命名作品")}`);
                  image.src = result.url;
                }).catch(() => {
                  if (!disposed && renderSequence === artworkRenderSequence && fallbackParts.artwork.isConnected !== false) {
                    fallbackParts.fallback.textContent = artworkFallbackLabel(record);
                    fallbackParts.artwork.setAttribute("data-artwork-status", "missing");
                    fallbackParts.artwork.setAttribute("aria-label", `作品封面未提供：${String(record.animeTitle || "未命名作品")}`);
                  }
                });
              }
              const text = document.createElement("span");
              text.className = "catalog-song-title";
              text.textContent = value == null || value === "" ? "未提供" : String(value);
              cell.appendChild(text);
            } else {
              cell.textContent = value == null || value === "" ? "未提供" : String(value);
            }
            if (columnIndex === 4) {
              const checkbox = document.createElement("input");
              checkbox.type = "checkbox";
              checkbox.className = "catalog-row-select";
              checkbox.checked = batchSelection.has(recordKey(record));
              checkbox.setAttribute("aria-label", `選取歌曲：${record.title || record.id}（${record.source}）`);
              checkbox.addEventListener("click", event => { if (event && typeof event.stopPropagation === "function") event.stopPropagation(); });
              checkbox.addEventListener("change", event => { if (event && typeof event.stopPropagation === "function") event.stopPropagation(); setBatchSelected(record, checkbox.checked); });
              cell.appendChild(checkbox);
            }
            row.appendChild(cell);
          });
          row.addEventListener("click", event => { if (isInteractiveTarget(event && event.target)) return; selectRecord(record, row, false); });
          row.addEventListener("keydown", event => {
            if (isInteractiveTarget(event.target)) return;
            const currentIndex = state.records.findIndex(item => recordKey(item) === selectedRecordKey);
            if (event.key === "ArrowDown" || event.key === "ArrowUp") {
              const base = currentIndex >= 0 ? currentIndex : index;
              const nextIndex = Math.max(0, Math.min(state.records.length - 1, base + (event.key === "ArrowDown" ? 1 : -1)));
              if (state.records[nextIndex]) {
                if (typeof event.preventDefault === "function") event.preventDefault();
                selectRecord(state.records[nextIndex], elements.rows.children[nextIndex], true);
              }
            } else if (event.key === "Enter") {
              if (typeof event.preventDefault === "function") event.preventDefault();
              selectRecord(record, row, false);
              libraryMessage("已選取歌曲與其作品；新版尚無曲庫列播放 owner，因此 Enter 不會播放音訊。", "");
            }
          });
          elements.rows.appendChild(row);
        });
        if (shouldRestoreRowFocus) {
          const matchingRow = Array.from(elements.rows.children || []).find(row => row.getAttribute && row.getAttribute("data-record-key") === focusedRecordKey);
          if (matchingRow && typeof matchingRow.focus === "function") matchingRow.focus();
          else if (elements.query && typeof elements.query.focus === "function") elements.query.focus();
        }
      }
      if (elements.empty) {
        if (typeof elements.empty.setAttribute === "function") elements.empty.setAttribute("data-empty-state", catalogState);
        elements.empty.hidden = state.records.length > 0;
        elements.empty.textContent = !state.hasCatalog
          ? loadError || appState.dataStatus === "failed" ? "曲庫載入失敗，請查看錯誤訊息或重新載入。"
            : loading || appState.dataStatus === "loading" ? "曲庫載入中。"
              : "曲庫尚未載入。"
          : appState.dataStatus === "empty" ? "來源沒有提供可用歌曲資料。"
            : state.total === 0 ? "沒有符合條件的歌曲。請調整搜尋或篩選條件。" : "這一頁沒有歌曲。";
      }
      if (elements.previous) elements.previous.disabled = !state.hasCatalog || state.page <= 0 || loading;
      if (elements.next) elements.next.disabled = !state.hasCatalog || state.page + 1 >= state.pageCount || loading;
      const pageIndicator = root.querySelector("#catalog-page-indicator");
      if (pageIndicator) pageIndicator.textContent = state.pageCount ? `第 ${state.page + 1} / ${state.pageCount} 頁` : "第 0 頁";
      if (elements.reload) {
        elements.reload.disabled = loading || !runtime;
        elements.reload.textContent = loading ? "載入中…" : catalogState === "failed" ? "重試載入" : "重新載入";
        elements.reload.setAttribute("aria-label", loading ? "曲庫載入中" : catalogState === "failed" ? "重試載入曲庫" : "重新載入曲庫");
        elements.reload.setAttribute("aria-describedby", "catalog-error");
      }
      if (elements.pageSize) elements.pageSize.value = String(state.pageSize);
      renderLibrary();
    }
    listen(elements.tagFilter, "change", () => { controller.setFilter("tagId", elements.tagFilter.value); render(); });
    listen(elements.batchTag, "change", () => { renderBatchSelection(); });
    listen(elements.tagCreate, "click", () => {
      if (!songTags) return setTagStatus("歌曲標籤服務不可用。", true);
      const result = songTags.createTag(elements.tagName && elements.tagName.value || "");
      if (!result.ok) return setTagStatus(`標籤建立失敗：${result.reason || "unknown"}`, true);
      if (elements.tagName) elements.tagName.value = "";
      renderTagControls(); setTagStatus(`已建立標籤「${result.tag.name}」。`); rebuildCatalogIndex();
    });
    listen(elements.tagRename, "click", () => {
      const id = elements.tagFilter && elements.tagFilter.value; if (!id || !songTags) return;
      const old = currentTags().find(tag => tag.id === id);
      const result = songTags.renameTag(id, elements.tagName && elements.tagName.value || "");
      if (!result.ok) return setTagStatus(`標籤重新命名失敗：${result.reason || "unknown"}`, true);
      if (elements.tagName) elements.tagName.value = "";
      renderTagControls(); setTagStatus(`標籤「${old ? old.name : id}」已重新命名。`); rebuildCatalogIndex();
    });
    listen(elements.tagDelete, "click", () => {
      const id = elements.tagFilter && elements.tagFilter.value; if (!id || !songTags) return;
      const old = currentTags().find(tag => tag.id === id);
      const result = songTags.deleteTag(id);
      if (!result.ok) return setTagStatus(`標籤刪除失敗：${result.reason || "unknown"}`, true);
      if (elements.tagName) elements.tagName.value = "";
      if (elements.tagFilter) elements.tagFilter.value = "";
      renderTagControls(); setTagStatus(`已刪除標籤「${old ? old.name : id}」，並移除其歌曲關聯。`); rebuildCatalogIndex();
    });
    listen(elements.selectPage, "click", () => {
      const visible = controller.snapshot().records;
      const allSelected = visible.length > 0 && visible.every(record => batchSelection.has(recordKey(record)));
      visible.forEach(record => { if (allSelected) batchSelection.delete(recordKey(record)); else batchSelection.set(recordKey(record), record); });
      render();
    });
    listen(elements.clearSelection, "click", () => { batchSelection.clear(); render(); setBatchStatus("已清除批次選取。"); });
    listen(elements.batchListAdd, "click", () => {
      const list = selectedList(); if (!list || !personalLibrary) return setBatchStatus("請先選擇可用的自訂清單。", true);
      const works = new Map();
      for (const record of batchSelection.values()) if ((record.source === "AMQ" || record.source === "EMQ") && record.animeId != null) works.set(JSON.stringify([record.source, String(record.animeId)]), { source: record.source, id: String(record.animeId) });
      let changed = 0, failed = 0;
      for (const ref of works.values()) { const result = personalLibrary.setWorkMembership(list.id, ref, true); if (result && result.ok) changed += 1; else failed += 1; }
      renderLibrary();
      setBatchStatus(failed ? `已加入 ${changed} 個作品，${failed} 個失敗；請檢查個人清單狀態。` : `已將 ${changed} 個不同作品加入「${list.name}」。`, failed > 0);
    });
    listen(elements.batchTagApply, "click", () => {
      const tagId = selectedTagId(); if (!tagId || !songTags) return;
      let changed = 0, failed = 0;
      const records = [...batchSelection.values()];
      const result = songTags.setSongTagForMany(records.map(record => ({ source: record.source, id: record.id })), tagId, true);
      if (result && result.ok) changed = records.length; else failed = records.length;
      rebuildCatalogIndex(); setBatchStatus(failed ? `批次標籤保存失敗：${result && result.reason || "unknown"}；沒有套用變更。` : `已套用標籤至 ${changed} 首歌曲。`, failed > 0);
    });
    listen(elements.batchTagRemove, "click", () => {
      const tagId = selectedTagId(); if (!tagId || !songTags) return;
      let changed = 0, failed = 0;
      const records = [...batchSelection.values()];
      const result = songTags.setSongTagForMany(records.map(record => ({ source: record.source, id: record.id })), tagId, false);
      if (result && result.ok) changed = records.length; else failed = records.length;
      rebuildCatalogIndex(); setBatchStatus(failed ? `批次標籤保存失敗：${result && result.reason || "unknown"}；沒有套用變更。` : `已從 ${changed} 首歌曲移除標籤。`, failed > 0);
    });
    listen(elements.preset, "change", () => { renderFilterPresets(); });
    listen(elements.presetName, "input", () => { renderFilterPresets(); });
    listen(elements.presetApply, "click", () => { applyFilterPreset(selectedFilterPreset()); });
    listen(elements.presetSave, "click", () => {
      if (!appSettings) return setPresetStatus("設定儲存服務不可用，預設未保存。", true);
      const name = String(elements.presetName && elements.presetName.value || "").trim();
      if (!name || name.length > 40) return setPresetStatus("請輸入 1–40 字元的預設名稱。", true);
      const state = controller.snapshot();
      const filters = { ...state.filters };
      const existing = getFilterPresets().find(item => item.name.toLocaleLowerCase() === name.toLocaleLowerCase());
      const preset = { id: existing ? existing.id : `catalog-filter-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`,
        name, filters, sortBy: state.sortBy, sortDirection: state.sortDirection, pageSize: state.pageSize };
      const presets = getFilterPresets().filter(item => item.id !== preset.id);
      if (!existing && presets.length >= 30) return setPresetStatus("最多只能保存 30 組預設，請先刪除一組。", true);
      presets.push(preset);
      const result = appSettings.set({ catalogFilterPresets: presets });
      if (!result.ok) return setPresetStatus(`預設保存失敗：${result.reason || "unknown"}`, true);
      if (elements.preset) elements.preset.value = preset.id;
      renderFilterPresets();
      setPresetStatus(existing ? `已更新預設「${name}」。` : `已保存預設「${name}」。`);
    });
    listen(elements.presetDelete, "click", () => {
      const selected = selectedFilterPreset();
      if (!selected || !appSettings) return;
      const result = appSettings.set({ catalogFilterPresets: getFilterPresets().filter(item => item.id !== selected.id) });
      if (!result.ok) return setPresetStatus(`刪除失敗：${result.reason || "unknown"}`, true);
      if (elements.presetName) elements.presetName.value = "";
      if (elements.preset) elements.preset.value = "";
      renderFilterPresets();
      setPresetStatus(`已刪除預設「${selected.name}」。`);
    });
    listen(elements.query, "input", () => { controller.setFilter("query", elements.query.value); render(); });
    listen(elements.source, "change", () => { controller.setFilter("source", elements.source.value); render(); });
    listen(elements.type, "change", () => { controller.setFilter("type", elements.type.value); render(); });
    listen(elements.workKind, "change", () => { controller.setFilter("workKind", elements.workKind.value); render(); });
    listen(elements.yearFrom, "change", () => { try { controller.setFilter("animeYearFrom", elements.yearFrom.value); render(); } catch (error) { if (elements.error) elements.error.textContent = error.message; } });
    listen(elements.yearTo, "change", () => { try { controller.setFilter("animeYearTo", elements.yearTo.value); render(); } catch (error) { if (elements.error) elements.error.textContent = error.message; } });
    listen(elements.includeUnknownYear, "change", () => { controller.setFilter("includeUnknownYear", elements.includeUnknownYear.checked ? "true" : "false"); render(); });
    listen(elements.animeType, "change", () => { controller.setFilter("animeType", elements.animeType.value); render(); });
    listen(elements.decade, "change", () => { controller.setFilter("animeDecade", elements.decade.value); render(); });
    listen(elements.watchFilter, "change", () => { rebuildCatalogIndex(); controller.setFilter("watchStatus", elements.watchFilter.value); render(); });
    listen(elements.familiarityFilter, "change", () => { rebuildCatalogIndex(); controller.setFilter("familiarityLevel", elements.familiarityFilter.value); render(); });
    listen(elements.sort, "change", () => { controller.setSort(elements.sort.value, elements.direction.value); render(); });
    listen(elements.direction, "change", () => { controller.setSort(elements.sort.value, elements.direction.value); render(); });
    listen(elements.pageSize, "change", () => { controller.setPageSize(Number(elements.pageSize.value)); render(); });
    listen(elements.previous, "click", () => { controller.movePage(-1); render(); });
    listen(elements.next, "click", () => { controller.movePage(1); render(); });
    listen(elements.listSelect, "change", () => {
      const result = appSettings ? appSettings.set({ customListId: elements.listSelect.value || "" }) : { ok: false, reason: "settings-store-unavailable" };
      if (result.ok) libraryMessage("已選擇自訂清單。", "");
      else libraryMessage("清單選擇尚未保存到新版設定。", `原因：${result.reason || "settings-store-unavailable"}`);
      renderLibrary();
    });
    listen(elements.listCreate, "click", () => {
      if (!personalLibrary) return libraryMessage("個人清單功能目前不可用。", "personal-library-store-unavailable");
      const result = personalLibrary.createList(elements.listName ? elements.listName.value : "");
      if (!result.ok) return showLibraryResult(result);
      if (elements.listName) elements.listName.value = "";
      if (appSettings) {
        const saved = appSettings.set({ customListId: result.list.id });
        if (!saved.ok) return showLibraryResult({ ok: false, reason: `list-created-settings-save-failed:${saved.reason}` }, "", "清單已建立，但選取狀態未保存。");
      }
      showLibraryResult(result, `已建立清單「${result.list.name}」。`);
    });
    listen(elements.listRename, "click", () => {
      const list = selectedList(); if (!list || !personalLibrary) return;
      const result = personalLibrary.renameList(list.id, elements.listName ? elements.listName.value : "");
      if (result.ok && elements.listName) elements.listName.value = "";
      showLibraryResult(result, result.ok ? "清單已重新命名。" : "");
    });
    listen(elements.listDelete, "click", () => {
      const list = selectedList(); if (!list || !personalLibrary) return;
      const result = personalLibrary.deleteList(list.id);
      if (!result.ok) return showLibraryResult(result);
      let cleanup = { ok: true };
      if (appSettings && appSettings.getSettings().customListId === String(list.id)) cleanup = appSettings.set({ customListId: "" });
      if (elements.listName) elements.listName.value = "";
      if (cleanup.ok) showLibraryResult(result, `清單「${list.name}」已刪除；作品與學習資料未刪除。`);
      else showLibraryResult({ ok: false, reason: `list-deleted-settings-cleanup-failed:${cleanup.reason}` }, "", `清單「${list.name}」已刪除，但新版設定中的清單 ID 未能清除；作品與學習資料未刪除。`);
    });
    listen(elements.addWork, "click", () => {
      const list = selectedList(), workId = selectedWorkId(); if (!list || !workId || !personalLibrary) return;
      const workRef = selectedWorkRef(); if (!workRef) return;
      showLibraryResult(personalLibrary.setWorkMembership(list.id, workRef, true), `作品 ${workRef.source}:${workRef.id} 已加入清單。`);
    });
    listen(elements.removeWork, "click", () => {
      const list = selectedList(), workId = selectedWorkId(); if (!list || !workId || !personalLibrary) return;
      const workRef = selectedWorkRef(); if (!workRef) return;
      showLibraryResult(personalLibrary.setWorkMembership(list.id, workRef, false), `作品 ${workRef.source}:${workRef.id} 已從清單移除。`);
    });
    listen(elements.watchStatus, "change", () => {
      const workId = selectedWorkId(); if (!workId || !personalLibrary) return;
      const workRef = selectedWorkRef(); if (!workRef) return;
      showLibraryResult(personalLibrary.setWorkWatchStatus(workRef, elements.watchStatus.value), `作品 ${workRef.source}:${workRef.id} 的看番狀態已更新。`);
    });
    const unsubscribeLibrary = personalLibrary && typeof personalLibrary.subscribe === "function" ? personalLibrary.subscribe(() => { renderLibrary(); if (controller.snapshot().filters.watchStatus) rebuildCatalogIndex(); }) : () => {};
    const unsubscribeFamiliarity = familiarity && typeof familiarity.subscribe === "function" ? familiarity.subscribe(() => { if (controller.snapshot().filters.familiarityLevel !== "") rebuildCatalogIndex(); }) : () => {};
    async function rebuildChineseTitleIndex() {
      const request = ++chineseTitleRequest;
      if (disposed || !runtime || !appSettings || appSettings.getSettings().chineseTitlesEnabled !== true || !chineseTitleProvider) return false;
      try {
        await chineseTitleProvider.load();
        if (disposed || request !== chineseTitleRequest || appSettings.getSettings().chineseTitlesEnabled !== true) return false;
        const catalog = runtime.catalogSnapshot();
        if (!catalog) return false;
        chineseTitleLoaded = true;
        rebuildCatalogIndex();
        return true;
      } catch (_) {
        // Optional external titles must never make the regular catalog unavailable.
        return false;
      }
    }
    const unsubscribeSongTags = songTags && typeof songTags.subscribe === "function" ? songTags.subscribe(() => { renderTagControls(); rebuildCatalogIndex(); }) : () => {};
    const unsubscribeSettings = appSettings && typeof appSettings.subscribe === "function" ? appSettings.subscribe(() => {
      renderLibrary(); renderFilterPresets();
      const enabled = appSettings.getSettings().chineseTitlesEnabled === true;
      if (enabled === lastChineseEnabled) return;
      lastChineseEnabled = enabled;
      if (enabled) void rebuildChineseTitleIndex();
      else { chineseTitleRequest += 1; chineseTitleLoaded = false; rebuildCatalogIndex(); }
    }) : () => {};
    async function loadCurrentMode() {
      if (!runtime || disposed) return null;
      const sequence = ++loadSequence;
      const restoreReloadFocus = !!elements.reload && document.activeElement === elements.reload;
      loading = true; loadError = ""; controller.clearCatalog(); render();
      try {
        const result = await runtime.loadCurrentMode();
        if (disposed || sequence !== loadSequence) return result;
        if (result && result.accepted && !result.stale) {
          const catalog = runtime.catalogSnapshot();
          if (catalog) {
            rebuildCatalogIndex();
            if (appSettings && appSettings.getSettings().chineseTitlesEnabled === true) void rebuildChineseTitleIndex();
          } else controller.clearCatalog();
        } else if (result && result.error) {
          loadError = formatCatalogError(result.error, "曲庫載入失敗");
        } else if (!result || (!result.accepted && !result.stale)) {
          // A completed request that was neither accepted nor explicitly stale is not an empty catalog.
          // Keep the failure local to this request rather than fabricating shared-store success state.
          loadError = "DATA_LOAD_NOT_ACCEPTED：曲庫來源未接受本次載入，請重新載入。";
        }
        return result;
      } catch (error) {
        if (!disposed && sequence === loadSequence) {
          loadError = formatCatalogError(error, "曲庫載入失敗");
        }
        return null;
      } finally {
        if (!disposed && sequence === loadSequence) {
          loading = false;
          render();
          if (restoreReloadFocus && elements.reload && !elements.reload.disabled && typeof elements.reload.focus === "function") elements.reload.focus();
        }
      }
    }
    listen(elements.reload, "click", () => { void loadCurrentMode(); });
    const unsubscribe = store.subscribe(nextState => {
      render();
      if (nextState.mode !== lastMode) {
        lastMode = nextState.mode;
        batchSelection.clear();
        renderBatchSelection();
        if (runtime) void loadCurrentMode();
      }
    });
    render();
    if (runtime) void loadCurrentMode();
    return Object.freeze({
      setCatalog(records) { controller.setCatalog(records); loadError = ""; render(); },
      clearCatalog() { controller.clearCatalog(); render(); },
      configureRuntime(nextRuntime) { runtime = nextRuntime || null; render(); if (runtime && !controller.snapshot().hasCatalog) void loadCurrentMode(); },
      reload: loadCurrentMode,
      render,
      dispose() { if (disposed) return false; disposed = true; artworkRenderSequence += 1; chineseTitleRequest += 1; const sceneImage = root.querySelector(".catalog-scene-background img"); if (sceneImage) sceneImage.removeAttribute("src"); unsubscribe(); unsubscribeLibrary(); unsubscribeFamiliarity(); unsubscribeSongTags(); unsubscribeSettings(); if (ownsChineseTitleProvider && chineseTitleProvider) chineseTitleProvider.dispose(); removers.splice(0).forEach(remove => remove()); if (ownsLibraryStore && personalLibrary && personalLibrary.dispose) personalLibrary.dispose(); if (ownsSettingsStore && appSettings && appSettings.dispose) appSettings.dispose(); if (ownsFamiliarityStore && familiarity && familiarity.dispose) familiarity.dispose(); if (ownsSongTagsStore && songTags && songTags.dispose) songTags.dispose(); return true; },
      get isDisposed() { return disposed; }
    });
  }

  global.AMQCatalogBrowser = Object.freeze({ createController, mount });
})(window);
