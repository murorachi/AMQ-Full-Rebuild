/* Minimal statistics UI: projects existing stores and exposes persistence read failures. */
(function (global) {
  "use strict";
  function createStatisticsDashboardPanel(options) {
    const deps = options && typeof options === "object" ? options : {}, elements = deps.elements || {};
    const persistence = deps.persistence || global.AMQPersistence || {}, learning = deps.learning || global.AMQLearning;
    // Validate required pure dependencies before acquiring stores; otherwise a failed
    // constructor can leak five persistence subscriptions before returning a disposer.
    if (!learning || !learning.statisticsDashboard || typeof learning.statisticsDashboard.buildDashboard !== "function") throw new TypeError("statistics dashboard projection is unavailable");
    const history = deps.quizHistoryStore || persistence.quizHistoryStore.createQuizHistoryStore();
    const familiarity = deps.familiarityStore || persistence.familiarityStore.createFamiliarityStore();
    const srsAMQ = deps.srsAMQ || persistence.srsStore.createSrsStore({ source: "AMQ" });
    const srsEMQ = deps.srsEMQ || persistence.srsStore.createSrsStore({ source: "EMQ" });
    const playback = deps.playbackHistoryStore || persistence.playbackHistoryStore.createPlaybackHistoryStore();
    const owned = [[history, !deps.quizHistoryStore], [familiarity, !deps.familiarityStore], [srsAMQ, !deps.srsAMQ], [srsEMQ, !deps.srsEMQ], [playback, !deps.playbackHistoryStore]];
    const runtime = deps.runtime && typeof deps.runtime.catalogSnapshot === "function" ? deps.runtime : null;
    const artworkAdapter = deps.artworkAdapter && typeof deps.artworkAdapter.getArtwork === "function" ? deps.artworkAdapter : null;
    const stateStore = deps.stateStore && typeof deps.stateStore.subscribe === "function" ? deps.stateStore : null;
    let catalogSnapshotRef = null, catalogRecordsByIdentity = new Map();
    let disposed = false; const removers = []; const subscribers = new Set(); let latestSnapshot = null; let renderGeneration = 0;
    function listen(target, event, handler) { if (!target || typeof target.addEventListener !== "function") return; target.addEventListener(event, handler); removers.push(() => target.removeEventListener(event, handler)); }
    function setText(target, value) { if (target) target.textContent = String(value ?? ""); }
    function percent(value) { return value === null || value === undefined ? "尚無資料" : `${(value * 100).toFixed(1)}%`; }
    const targetLabels = Object.freeze({ anime: "作品", title: "歌曲", artist: "歌手" });
    const reviewStateLabels = Object.freeze({ new: "新卡", learning: "學習中", review: "複習", relearning: "重新學習", suspended: "已暫停" });
    function formatDate(value) {
      const timestamp = typeof value === "number" ? value : Date.parse(value || "");
      if (!Number.isFinite(timestamp) || timestamp <= 0) return "時間未提供";
      try { return new Date(timestamp).toLocaleString("zh-TW", { year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit" }); }
      catch (_) { return new Date(timestamp).toISOString().slice(0, 16).replace("T", " "); }
    }
    function catalogRecord(source, songId) {
      if (!runtime) return null;
      let catalog = null;
      try { catalog = runtime.catalogSnapshot(); } catch (_) { return null; }
      if (!catalog || typeof catalog.search !== "function") return null;
      if (catalog !== catalogSnapshotRef) {
        const records = new Map();
        try {
          for (let offset = 0; offset < catalog.size; offset += 10000) {
            const page = catalog.search({ offset, limit: Math.min(10000, catalog.size - offset) });
            for (const record of page.records || []) records.set(`${String(record.source || "").toUpperCase()}\u0000${String(record.id)}`, record);
          }
        } catch (_) { return null; }
        catalogSnapshotRef = catalog; catalogRecordsByIdentity = records;
      }
      return catalogRecordsByIdentity.get(`${String(source || "").toUpperCase()}\u0000${String(songId)}`) || null;
    }
    function recentHistoryRows() {
      return history.getHistory().slice(-8).reverse().map(row => {
        const record = catalogRecord(row.source, row.songId);
        const savedSongName = String(row.songName || row.title || "");
        const savedWorkTitle = String(row.workTitle || row.animeTitle || "");
        const songName = savedSongName && savedSongName !== "未命名歌曲" ? savedSongName : record && record.title || (row.songId != null ? `歌曲記錄 #${row.songId}` : "未命名歌曲");
        const workTitle = savedWorkTitle && savedWorkTitle !== "未知作品" ? savedWorkTitle : record && (record.animeTitle || record.workTitle) || "未知作品";
        return Object.freeze({ id: String(row.id || ""), source: row.source, songId: row.songId == null ? "" : String(row.songId), workTitle: String(workTitle),
          songName: String(songName), target: targetLabels[row.target] || "答題目標未標示",
          result: row.result || (row.correct === true ? "答對" : row.correct === false ? "答錯" : "結果未標示"),
          correct: row.correct === true, at: formatDate(row.at), catalogRecord: record });
      });
    }
    function dueReviewSnapshot(store, source, timestamp) {
      const counts = store.counts(timestamp);
      const schedule = store.snapshot();
      const session = store.chooseSession(timestamp);
      const ids = session.ids.slice(0, Math.min(session.dueCount, session.ids.length));
      const items = ids.map(id => schedule.cards && schedule.cards[String(id)]).filter(card => card && card.state !== "new" && card.state !== "suspended" && Number(card.dueAt) <= timestamp)
        .map(card => {
          const record = catalogRecord(source, card.songId);
          return Object.freeze({ source, songId: String(card.songId), songName: record && record.title || `歌曲記錄 #${card.songId}`,
            workTitle: record && (record.animeTitle || record.workTitle) || "未知作品", catalogRecord: record,
            state: reviewStateLabels[card.state] || "學習卡", dueAtTimestamp: Number(card.dueAt), dueAt: formatDate(Number(card.dueAt)) });
        })
        .sort((a, b) => a.dueAtTimestamp - b.dueAtTimestamp);
      return { due: Number(counts.due) || 0, items };
    }
    function renderList(element, rows, emptyElement, emptyText, createRow) {
      if (!element || typeof element.replaceChildren !== "function") return;
      element.replaceChildren();
      for (const row of rows) element.appendChild(createRow(row));
      if (emptyElement) { emptyElement.hidden = rows.length > 0; setText(emptyElement, emptyText); }
    }
    function makeArtworkSlot(row, generation) {
      const slot = global.document.createElement("span"); slot.className = "learning-item-artwork"; slot.dataset.source = String(row.source || "unknown").toLowerCase();
      const fallback = global.document.createElement("span"); fallback.className = "learning-item-artwork-fallback";
      fallback.textContent = row.catalogRecord ? "封面載入中" : `${row.source || "曲目"} · 封面未提供`;
      slot.appendChild(fallback);
      const record = row.catalogRecord;
      if (!artworkAdapter || !record || !record.artworkRef) return slot;
      fallback.textContent = "封面載入中";
      Promise.resolve().then(() => artworkAdapter.getArtwork(record)).then(result => {
        if (disposed || generation !== renderGeneration || !result || !result.url) {
          if (!disposed && generation === renderGeneration && !result?.url) fallback.textContent = "封面未提供";
          return;
        }
        const image = global.document.createElement("img"); image.className = "learning-item-artwork-image";
        image.alt = `${row.workTitle || row.songName} 封面`; image.loading = "lazy"; image.decoding = "async";
        image.addEventListener("load", () => { if (!disposed && generation === renderGeneration) fallback.hidden = true; });
        image.addEventListener("error", () => { if (disposed || generation !== renderGeneration) return; image.remove(); fallback.hidden = false; fallback.textContent = "封面無法載入"; });
        image.src = result.url;
        if (disposed || generation !== renderGeneration) return;
        slot.appendChild(image);
      }).catch(() => {
        if (!disposed && generation === renderGeneration) fallback.textContent = "封面無法載入";
      });
      return slot;
    }
    function makeHistoryItem(row, generation) {
      const item = global.document.createElement("li"); item.className = "learning-history-item";
      item.dataset.result = row.correct ? "correct" : "incorrect";
      item.appendChild(makeArtworkSlot(row, generation));
      const main = global.document.createElement("div"); main.className = "learning-list-item-main";
      const title = global.document.createElement("strong"); title.textContent = row.songName; main.appendChild(title);
      const work = global.document.createElement("span"); work.textContent = `${row.source} · ${row.workTitle}`; main.appendChild(work);
      const meta = global.document.createElement("div"); meta.className = "learning-list-item-meta";
      const target = global.document.createElement("span"); target.textContent = row.target; meta.appendChild(target);
      const result = global.document.createElement("span"); result.className = "learning-result-badge"; result.textContent = row.result; meta.appendChild(result);
      const at = global.document.createElement("time"); at.textContent = row.at; meta.appendChild(at);
      item.append(main, meta); return item;
    }
    function makeReviewItem(row, generation) {
      const item = global.document.createElement("li"); item.className = "learning-review-item";
      item.appendChild(makeArtworkSlot(row, generation));
      const main = global.document.createElement("div"); main.className = "learning-list-item-main";
      const title = global.document.createElement("strong"); title.textContent = row.songName || `歌曲記錄 #${row.songId}`; main.appendChild(title);
      const source = global.document.createElement("span"); source.textContent = `${row.source} · ${row.workTitle || "未知作品"} · ${row.state}`; main.appendChild(source);
      const due = global.document.createElement("time"); due.className = "learning-review-due"; due.textContent = `到期：${row.dueAt}`;
      item.append(main, due); return item;
    }
    function checkReadErrors() {
      const issues = [], quizStatus = history.getPersistenceStatus();
      if (quizStatus.legacyReadError || quizStatus.detailWriteBlocked || quizStatus.summaryWriteBlocked || quizStatus.detailSaveFailed || quizStatus.summarySaveFailed) issues.push("答題歷史");
      const familiarityStatus = familiarity.getPersistenceStatus(); if (familiarityStatus.AMQ.readBlocked || familiarityStatus.EMQ.readBlocked) issues.push("熟悉度");
      for (const [source, store] of [["AMQ", srsAMQ], ["EMQ", srsEMQ]]) {
        const status = store.getPersistenceStatus();
        if (status.blocked || status.error || status.recoveryAvailable || status.persisted === false) issues.push(`${source} SRS`);
      }
      const playbackStatus = playback.getPersistenceStatus(); if (!playbackStatus.ok || playbackStatus.readBlocked || playbackStatus.persisted === false) issues.push("自由播放歷史");
      return issues;
    }
    function getSnapshot() {
      const issues = checkReadErrors();
      if (issues.length) return Object.freeze({ available: false, issues: Object.freeze([...new Set(issues)]), report: null });
      const quizHistory = history.getHistory();
      const report = learning.statisticsDashboard.buildDashboard({ quizHistory, familiarityAMQ: familiarity.getSnapshot("AMQ"),
        familiarityEMQ: familiarity.getSnapshot("EMQ"), srsAMQ: srsAMQ.counts(), srsEMQ: srsEMQ.counts(), playbackHistory: playback.getEntries() });
      const timestamp = Date.now();
      const dueAMQ = dueReviewSnapshot(srsAMQ, "AMQ", timestamp), dueEMQ = dueReviewSnapshot(srsEMQ, "EMQ", timestamp);
      const dueItems = [...dueAMQ.items, ...dueEMQ.items].sort((a, b) => a.dueAtTimestamp - b.dueAtTimestamp || a.source.localeCompare(b.source))
        .slice(0, 8).map(({ dueAtTimestamp, ...item }) => Object.freeze(item));
      return Object.freeze({ available: true, issues: Object.freeze([]), report,
        recentHistory: Object.freeze(recentHistoryRows()), dueReview: Object.freeze({ totalDue: dueAMQ.due + dueEMQ.due, items: Object.freeze(dueItems) }) });
    }
    function publishSnapshot(snapshot) {
      for (const listener of [...subscribers]) { if (!subscribers.has(listener)) continue; try { listener(snapshot); } catch (_) {} }
    }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      subscribers.add(listener);
      try { listener(latestSnapshot || getSnapshot()); } catch (_) {}
      return () => subscribers.delete(listener);
    }
    function render() {
      if (disposed) return;
      const generation = ++renderGeneration;
      const snapshot = getSnapshot(); latestSnapshot = snapshot;
      if (!snapshot.available) {
        const issues = snapshot.issues; setText(elements.status, "讀取失敗");
        setText(elements.error, `以下資料無法可靠讀取，為避免把錯誤顯示成零，暫停統計：${issues.join("、")}。請先檢查瀏覽器儲存權限或資料備份。`);
        setText(elements.summary, "統計暫不可用。");
        renderList(elements.historyList, [], elements.historyEmpty, "答題歷史讀取失敗，暫不顯示清單。", row => makeHistoryItem(row, generation));
        renderList(elements.reviewList, [], elements.reviewEmpty, "SRS 資料讀取失敗，暫不顯示複習清單。", row => makeReviewItem(row, generation));
        setText(elements.historyCount, "讀取失敗"); setText(elements.reviewCount, "讀取失敗"); publishSnapshot(snapshot); return;
      }
      setText(elements.error, "");
      renderList(elements.historyList, snapshot.recentHistory, elements.historyEmpty, "目前沒有可顯示的答題歷史。", row => makeHistoryItem(row, generation));
      setText(elements.historyCount, `最近 ${snapshot.recentHistory.length} 筆`);
      renderList(elements.reviewList, snapshot.dueReview.items, elements.reviewEmpty, snapshot.dueReview.totalDue ? "有到期卡片，但目前批次沒有可顯示的項目。" : "目前沒有到期複習卡片。", row => makeReviewItem(row, generation));
      setText(elements.reviewCount, `到期 ${snapshot.dueReview.totalDue} 張 · 顯示 ${snapshot.dueReview.items.length} 張`);
      const report = snapshot.report;
      const quiz = report.quiz; setText(elements.status, quiz.total ? "統計已更新" : "尚無答題資料");
      setText(elements.summary, `答題 ${quiz.total} 題，答對 ${quiz.correct} 題、答錯 ${quiz.wrong} 題；正確率 ${percent(quiz.accuracy)}；平均答題時間 ${quiz.averageElapsedSeconds === null ? "尚無資料" : `${quiz.averageElapsedSeconds.toFixed(1)} 秒`}。`);
      setText(elements.bySource, ["AMQ", "EMQ"].map(source => `${source}：${quiz.bySource[source].total} 題，正確率 ${percent(quiz.bySource[source].accuracy)}`).join("；"));
      setText(elements.byTarget, ["anime", "title", "artist"].map((target, index) => `${["作品", "歌曲", "歌手"][index]}：${quiz.byTarget[target].total} 題，正確率 ${percent(quiz.byTarget[target].accuracy)}`).join("；"));
      const workProgress = report.workProgress;
      if (workProgress && workProgress.works.length) {
        const top = workProgress.works.slice(0, 8).map(work => `${work.source} · ${work.title}：${work.total} 次作答、${work.uniqueSongs} 首歌曲、正確率 ${percent(work.accuracy)}${work.lastAt ? `、最近 ${work.lastAt.slice(0, 10)}` : ""}`);
        setText(elements.workProgress, `已練習 ${workProgress.totalWorks} 部作品，共 ${workProgress.totalAnswers} 次作答。${top.join("；")}${workProgress.works.length > 8 ? `；另有 ${workProgress.works.length - 8} 部作品` : ""}`);
      } else setText(elements.workProgress, "尚無可歸屬至作品的答題紀錄。此統計由歷史即時計算，不另存資料；歌曲熟悉度仍是獨立指標。");
      setText(elements.familiarity, ["AMQ", "EMQ"].map(source => { const levels = report.familiarity[source]; return `${source}：未知／無效值 ${levels.unknown}、明確等級 0 ${levels.level0}、1 ${levels.level1}、2 ${levels.level2}、3 ${levels.level3}`; }).join("；"));
      setText(elements.srs, ["AMQ", "EMQ"].map(source => { const counts = report.srs[source]; return `${source}：卡片 ${counts.total}、到期 ${counts.due}、新卡 ${counts.new}、學習中 ${counts.learning}、複習 ${counts.review}、暫停 ${counts.suspended}`; }).join("；"));
      setText(elements.playback, `自由播放 ${report.playback.total} 筆；AMQ ${report.playback.bySource.AMQ} 筆、EMQ ${report.playback.bySource.EMQ} 筆。${report.playback.latest ? `最近：${report.playback.latest.source} · ${report.playback.latest.title || "未命名歌曲"} · ${report.playback.latest.workTitle || "未標示作品"}` : "尚無符合紀錄。"}`);
      const days = quiz.recentDays.slice(-7).map(day => `${day.date}：${day.total} 題，${percent(day.accuracy)}`); setText(elements.daily, days.length ? days.join("；") : "尚無每日答題紀錄。");
      publishSnapshot(snapshot);
    }
    const eventNames = [persistence.quizHistoryStore.keys && persistence.quizHistoryStore.keys.UPDATE_EVENT,
      persistence.familiarityStore.keys && persistence.familiarityStore.keys.AMQ_EVENT, persistence.familiarityStore.keys && persistence.familiarityStore.keys.EMQ_EVENT,
      persistence.srsStore.updateEvent, persistence.playbackHistoryStore.updateEvent].filter(Boolean);
    eventNames.forEach(name => listen(global.document, name, render)); listen(global, "storage", render); listen(elements.refresh, "click", render);
    if (stateStore) {
      const stateKey = state => `${String(state && state.mode || "")}\u0000${String(state && state.dataStatus || "")}`;
      let lastStateKey = typeof stateStore.getState === "function" ? stateKey(stateStore.getState()) : "";
      const unsubscribe = stateStore.subscribe(nextState => {
        const nextKey = stateKey(nextState);
        if (nextKey !== lastStateKey) { lastStateKey = nextKey; catalogSnapshotRef = null; catalogRecordsByIdentity = new Map(); render(); }
      });
      if (typeof unsubscribe === "function") removers.push(unsubscribe);
    }
    render();
    return Object.freeze({ render, getSnapshot: () => latestSnapshot || getSnapshot(), subscribe, dispose() { if (disposed) return false; disposed = true; removers.splice(0).forEach(remove => { try { remove(); } catch (_) {} }); subscribers.clear(); owned.forEach(([store, isOwned]) => { if (isOwned && store && typeof store.dispose === "function") store.dispose(); }); return true; }, get isDisposed() { return disposed; } });
  }
  function mount(options) {
    const ids = { status: "statistics-status", error: "statistics-error", summary: "statistics-summary", bySource: "statistics-by-source",
      byTarget: "statistics-by-target", workProgress: "statistics-work-progress", familiarity: "statistics-familiarity", srs: "statistics-srs", playback: "statistics-playback", daily: "statistics-daily", refresh: "statistics-refresh",
      historyList: "learning-history-list", historyEmpty: "learning-history-empty", historyCount: "learning-history-count",
      reviewList: "learning-review-list", reviewEmpty: "learning-review-empty", reviewCount: "learning-review-count" };
    const elements = Object.fromEntries(Object.entries(ids).map(([key, id]) => [key, global.document.getElementById(id)]));
    return createStatisticsDashboardPanel({ ...(options || {}), elements });
  }
  global.AMQUI = global.AMQUI || {};
  global.AMQUI.statisticsDashboardPanel = Object.freeze({ createStatisticsDashboardPanel, mount });
})(window);
