/* Thin DOM adapter for the quiz session. The session remains the sole owner of quiz phase and question state. */
(function (global) {
  "use strict";

  function safeAudioSourceLabel(value) {
    const source = String(value == null ? "" : value).trim();
    if (!source) return "未知來源";
    if (/^https?:\/\//i.test(source)) {
      const match = source.match(/^https?:\/\/(?:[^/@?#]*@)?([^/:?#]+)/i);
      return match && match[1] ? match[1].toLowerCase() : "未知來源";
    }
    return source.replace(/[\u0000-\u001f\u007f]/g, "").replace(/[?#].*$/u, "").slice(0, 100) || "未知來源";
  }

  function mount(options) {
    const settings = options && typeof options === "object" ? options : {};
    const store = settings.stateStore || (global.AMQCore && global.AMQCore.state);
    const runtime = settings.runtime || null;
    if (!store || typeof store.getState !== "function" || typeof store.subscribe !== "function") throw new TypeError("quiz panel requires shared state store");
    const root = document.getElementById("quiz-panel");
    if (!root) throw new Error("quiz panel root is missing");
    const sessionApi = global.AMQEngine && global.AMQEngine.quizSession;
    if (!sessionApi || typeof sessionApi.createQuizSession !== "function") throw new TypeError("quiz panel requires quiz session module");
    const familiarityApi = global.AMQPersistence && global.AMQPersistence.familiarityStore;
    const historyApi = global.AMQPersistence && global.AMQPersistence.quizHistoryStore;
    const blacklistApi = global.AMQPersistence && global.AMQPersistence.blacklistStore;
    const srsApi = global.AMQPersistence && global.AMQPersistence.srsStore;
    const appSettingsApi = global.AMQPersistence && global.AMQPersistence.appSettingsStore;
    const personalLibraryApi = global.AMQPersistence && global.AMQPersistence.personalLibraryStore;
    let amqSongIds = new Set();
    let emqSongIds = new Set();
    let amqRecordsById = new Map();
    let emqRecordsById = new Map();
    let srsCatalog = null;
    const acquiredOwnedResources = [];
    function acquireOwnedResource(value, owned) {
      if (owned && value && typeof value.dispose === "function") acquiredOwnedResources.push(value);
      return value;
    }
    function rollbackOwnedResources(error) {
      const cleanupErrors = [];
      for (const resource of acquiredOwnedResources.splice(0).reverse()) {
        try { resource.dispose(); } catch (cleanupError) { cleanupErrors.push(cleanupError); }
      }
      if (cleanupErrors.length && error && typeof error === "object") error.cleanupErrors = cleanupErrors;
      throw error;
    }
    const ownsBlacklistStore = !settings.blacklistStore && Boolean(blacklistApi && typeof blacklistApi.createBlacklistStore === "function");
    let blacklistStore = null;
    const isBlacklisted = id => {
      if (typeof settings.isBlacklisted === "function" && settings.isBlacklisted(String(id))) return true;
      if (!blacklistStore) return false;
      const record = amqRecordsById.get(String(id));
      return blacklistStore.isSongBlacklisted(id) || Boolean(record && blacklistStore.isWorkBlacklisted(record.animeId));
    };
    const ownsLocalSrsStore = !settings.srsStore && Boolean(srsApi && typeof srsApi.createSrsStore === "function");
    const ownsLocalEmqSrsStore = !settings.emqSrsStore && Boolean(srsApi && typeof srsApi.createSrsStore === "function");
    function createSrsStoreFor(source, storage) {
      if (!srsApi || typeof srsApi.createSrsStore !== "function") return null;
      const isEmq = source === "EMQ";
      return srsApi.createSrsStore({ source, storage,
        songExists: id => (isEmq ? emqSongIds : amqSongIds).has(String(id)),
        ...(isEmq ? {} : { isBlacklisted }) });
    }
    let localSrsStore = null;
    let localEmqSrsStore = null;
    let srsStore = null;
    let emqSrsStore = null;
    let remoteSrsStores = null;
    function srsStoreFor(source) { return String(source || "AMQ").toUpperCase() === "EMQ" ? emqSrsStore : srsStore; }
    function createIsolatedEmptyStorage(source) {
      const scheduler = global.AMQLearning && global.AMQLearning.fsrsScheduler;
      if (!scheduler || !srsApi || !srsApi.storageKeys) throw new Error("isolated SRS storage dependencies are missing");
      const key = srsApi.storageKeys[source];
      const schedule = scheduler.emptySchedule(Date.now());
      if (source === "EMQ") schedule.source = "EMQ";
      const values = new Map([[key, JSON.stringify(schedule)]]);
      return { getItem: name => values.has(String(name)) ? values.get(String(name)) : null,
        setItem: (name, value) => values.set(String(name), String(value)),
        removeItem: name => values.delete(String(name)), clear: () => values.clear() };
    }
    const ownsFamiliarityStore = !settings.familiarityStore && Boolean(familiarityApi && typeof familiarityApi.createFamiliarityStore === "function");
    const ownsHistoryStore = !settings.historyStore && Boolean(historyApi && typeof historyApi.createQuizHistoryStore === "function");
    const ownsAppSettingsStore = !settings.appSettingsStore && Boolean(appSettingsApi && typeof appSettingsApi.createAppSettingsStore === "function");
    const ownsPersonalLibraryStore = !settings.personalLibraryStore && Boolean(personalLibraryApi && typeof personalLibraryApi.createPersonalLibraryStore === "function");
    let familiarityStore = settings.familiarityStore || null;
    let historyStore = settings.historyStore || null;
    let appSettingsStore = settings.appSettingsStore || null;
    let personalLibraryStore = settings.personalLibraryStore || null;
    try {
      blacklistStore = settings.blacklistStore || (ownsBlacklistStore ? acquireOwnedResource(blacklistApi.createBlacklistStore(), true) : null);
      localSrsStore = settings.srsStore || (ownsLocalSrsStore ? acquireOwnedResource(createSrsStoreFor("AMQ"), true) : null);
      localEmqSrsStore = settings.emqSrsStore || (ownsLocalEmqSrsStore ? acquireOwnedResource(createSrsStoreFor("EMQ"), true) : null);
      srsStore = localSrsStore;
      emqSrsStore = localEmqSrsStore;
      familiarityStore = settings.familiarityStore || (ownsFamiliarityStore ? acquireOwnedResource(familiarityApi.createFamiliarityStore(), true) : null);
      historyStore = settings.historyStore || (ownsHistoryStore ? acquireOwnedResource(historyApi.createQuizHistoryStore(), true) : null);
      appSettingsStore = settings.appSettingsStore || (ownsAppSettingsStore ? acquireOwnedResource(appSettingsApi.createAppSettingsStore(), true) : null);
      personalLibraryStore = settings.personalLibraryStore || (ownsPersonalLibraryStore ? acquireOwnedResource(personalLibraryApi.createPersonalLibraryStore(), true) : null);
      if (personalLibraryStore && typeof personalLibraryStore.refresh === "function") personalLibraryStore.refresh();
    } catch (error) {
      rollbackOwnedResources(error);
    }
    function queryRootOrDocument(selector) {
      const local = root.querySelector(selector);
      if (local) return local;
      const id = selector.charAt(0) === "#" ? selector.slice(1) : "";
      return id && global.document && typeof global.document.getElementById === "function" ? global.document.getElementById(id) : null;
    }
    const elements = {
      status: root.querySelector("#quiz-status"), target: root.querySelector("#quiz-target"), count: root.querySelector("#quiz-count"),
      clipSeconds: root.querySelector("#quiz-clip-seconds"), partial: root.querySelector("#quiz-partial"), autoPlay: root.querySelector("#quiz-autoplay"),
      randomSample: root.querySelector("#quiz-random-sample"), clipStartSeconds: root.querySelector("#quiz-clip-start"), autoNextDelaySeconds: root.querySelector("#quiz-auto-next-delay"),
      chineseTitlesEnabled: root.querySelector("#quiz-chinese-titles-enabled"), chineseTitlesStatus: root.querySelector("#quiz-chinese-titles-status"),
      poolSize: root.querySelector("#quiz-pool-size"), progress: root.querySelector("#quiz-progress"), timer: root.querySelector("#quiz-timer"),
      audioStatus: root.querySelector("#quiz-audio-status"), questionMeta: root.querySelector("#quiz-question-meta"), questionTitle: root.querySelector("#quiz-question-title"),
      message: root.querySelector("#quiz-message"), error: root.querySelector("#quiz-error"), form: root.querySelector("#quiz-answer-form"),
      singleLabel: root.querySelector("#quiz-single-answer-label"), singleAnswer: root.querySelector("#quiz-answer"), suggestions: root.querySelector("#quiz-suggestions"), allFields: root.querySelector("#quiz-all-answer-fields"),
      animeAnswer: root.querySelector("#quiz-answer-anime"), animeSuggestions: root.querySelector("#quiz-suggestions-anime"),
      artistAnswer: root.querySelector("#quiz-answer-artist"), artistSuggestions: root.querySelector("#quiz-suggestions-artist"),
      titleAnswer: root.querySelector("#quiz-answer-title"), titleSuggestions: root.querySelector("#quiz-suggestions-title"),
      submit: root.querySelector("#quiz-submit"), start: root.querySelector("#quiz-start"), play: root.querySelector("#quiz-play"), pause: root.querySelector("#quiz-pause"),
      reveal: root.querySelector("#quiz-reveal"), skip: root.querySelector("#quiz-skip"), next: root.querySelector("#quiz-next"), end: root.querySelector("#quiz-end"),
      roundSection: root.querySelector(".quiz-round-section"), questionStage: root.querySelector(".quiz-question-card"),
      answerForm: root.querySelector("#quiz-answer-form"), characterBar: root.querySelector("#quiz-character-bar"),
      answerReveal: root.querySelector("#quiz-answer-reveal"), correctAnime: root.querySelector("#quiz-correct-anime"),
      correctTitle: root.querySelector("#quiz-correct-title"), correctArtist: root.querySelector("#quiz-correct-artist"),
      historyCounts: root.querySelector("#quiz-history-counts"), historyRecent: root.querySelector("#quiz-history-recent"), historyWarning: root.querySelector("#quiz-history-warning"),
      roundResults: queryRootOrDocument("#quiz-round-results"), roundResultsSummary: queryRootOrDocument("#quiz-round-results-summary"),
      roundResultsList: queryRootOrDocument("#quiz-round-results-list"), roundResultsNote: queryRootOrDocument("#quiz-round-results-note"),
      roundResultsEmpty: queryRootOrDocument("#results-empty"),
      srsEnabled: root.querySelector("#quiz-srs-enabled"),
      yearFrom: root.querySelector("#quiz-year-from"), yearTo: root.querySelector("#quiz-year-to"),
      includeUnknownYear: root.querySelector("#quiz-unknown-year"), animeType: root.querySelector("#quiz-anime-type"),
      difficultyMin: root.querySelector("#quiz-difficulty-min"), difficultyMax: root.querySelector("#quiz-difficulty-max"),
      songType: root.querySelector("#quiz-song-type"), watchStatus: root.querySelector("#quiz-watch-status"),
      srsCounts: root.querySelector("#quiz-srs-counts"), srsDailyNew: root.querySelector("#quiz-srs-daily-new"), srsBatchSize: root.querySelector("#quiz-srs-batch-size"),
      srsToggle: root.querySelector("#quiz-srs-toggle"), srsStart: root.querySelector("#quiz-srs-start"), srsMessage: root.querySelector("#quiz-srs-message"),
      srsRating: root.querySelector("#quiz-srs-rating"),
      srsGradeButtons: [...root.querySelectorAll("[data-srs-grade]")],
      blacklistToggle: root.querySelector("#quiz-blacklist-toggle"), workBlacklistToggle: root.querySelector("#quiz-work-blacklist-toggle")
    };
    const removers = [];
    let unsubscribeAppSettings = null;
    let unsubscribePersonalLibrary = null;
    let appliedCustomListId = appSettingsStore && appSettingsStore.getSettings ? appSettingsStore.getSettings().customListId || "" : "";
    let session = null;
    let unsubscribeSession = null;
    let unsubscribeHistory = null;
    let unsubscribeBlacklist = null;
    let disposed = false;
    let lastMode = store.getState().mode;
    let lastCatalog = null;
    let suggestionCatalog = null;
    let suggestionValuesCache = new Map();
    let lastRenderedQuestion = null;
    const suggestionControllers = [];
    let poolSize = 0;
    let localError = "";
    let srsMessage = "";
    let srsModeActive = false;
    let focusSongIds = null;
    let focusSongQueue = null;
    let srsSkippedIds = new Set();
    let roundToken = 0;
    let ratingDoneKey = null;
    const chineseTitleApi = global.AMQData && global.AMQData.chineseTitleProvider;
    let openccConverter = null;
    let chineseTitleProvider = null;
    try {
      const createChineseTitleProvider = settings.factories && settings.factories.createChineseTitleProvider;
      chineseTitleProvider = typeof createChineseTitleProvider === "function"
        ? acquireOwnedResource(createChineseTitleProvider({ convertToTraditional(value) {
            try {
              if (!openccConverter && global.OpenCC && typeof global.OpenCC.Converter === "function") openccConverter = global.OpenCC.Converter({ from: "cn", to: "tw" });
              return openccConverter ? openccConverter(value) : value;
            } catch (_) { return value; }
          } }), true)
        : chineseTitleApi && typeof chineseTitleApi.createChineseTitleProvider === "function"
        ? acquireOwnedResource(chineseTitleApi.createChineseTitleProvider({ convertToTraditional(value) {
            try {
              if (!openccConverter && global.OpenCC && typeof global.OpenCC.Converter === "function") openccConverter = global.OpenCC.Converter({ from: "cn", to: "tw" });
              return openccConverter ? openccConverter(value) : value;
            } catch (_) { return value; }
          } }), true) : null;
    } catch (error) {
      rollbackOwnedResources(error);
    }
    let openccLoadPromise = null;
    let chineseTitleAbortController = null;
    let chineseTitleLoadPromise = null;
    let chineseTitleLoadState = "disabled";

    function rollbackMountInitialization(error) {
      // Event wiring happens after the panel has acquired stores and providers. If a
      // DOM adapter rejects a listener, unwind only resources owned by this mount.
      for (const remove of removers.splice(0).reverse()) {
        try { remove(); } catch (_) { /* Preserve the original initialization error. */ }
      }
      for (const unsubscribe of [unsubscribeAppSettings, unsubscribePersonalLibrary, unsubscribeHistory, unsubscribeBlacklist]) {
        if (typeof unsubscribe === "function") {
          try { unsubscribe(); } catch (_) { /* Preserve the original initialization error. */ }
        }
      }
      unsubscribeAppSettings = null;
      unsubscribePersonalLibrary = null;
      unsubscribeHistory = null;
      unsubscribeBlacklist = null;
      suggestionControllers.splice(0).forEach(controller => {
        try { controller.dispose(); } catch (_) { /* Preserve the original initialization error. */ }
      });
      if (chineseTitleAbortController) {
        try { chineseTitleAbortController.abort(); } catch (_) {}
        chineseTitleAbortController = null;
      }
      try { disposeSession(); } catch (_) { /* Preserve the original initialization error. */ }
      rollbackOwnedResources(error);
    }
    function listen(element, event, handler) {
      if (!element) return;
      const addListener = settings.addEventListener;
      try {
        if (typeof addListener === "function") addListener(element, event, handler);
        else element.addEventListener(event, handler);
      } catch (error) {
        rollbackMountInitialization(error);
      }
      removers.push(() => element.removeEventListener(event, handler));
    }
    function readCatalogRecords(catalog, source) {
      const sourceFilter = source === "MIX" ? ["AMQ", "EMQ"] : source;
      const first = catalog.search({ source: sourceFilter, offset: 0, limit: 10000 });
      const records = [];
      for (let offset = 0; offset < first.total; offset += 10000) {
        const page = offset === 0 ? first : catalog.search({ source: sourceFilter, offset, limit: 10000 });
        records.push(...page.records);
      }
      return records;
    }
    function getSuggestionValues(requestedTarget) {
      const state = session && session.getState();
      const active = state && !["idle", "finished"].includes(state.phase);
      const target = requestedTarget || (active ? state.target : elements.target.value);
      if (!lastCatalog || !["anime", "title", "artist"].includes(target)) return [];
      if (suggestionCatalog !== lastCatalog) { suggestionCatalog = lastCatalog; suggestionValuesCache = new Map(); }
      const source = store.getState().mode;
      const key = `${source}:${target}`;
      if (suggestionValuesCache.has(key)) return suggestionValuesCache.get(key);
      const values = new Set();
      const chineseEnabled = Boolean(appSettingsStore && appSettingsStore.getSettings().chineseTitlesEnabled);
      for (const record of readCatalogRecords(lastCatalog, source)) {
        // Prefer the old V82.x suggestion-source behavior where metadata is available:
        // primary label plus known aliases, without fabricating or deriving aliases.
        const candidates = target === "title"
          ? [record.title, ...(Array.isArray(record.aliases) ? record.aliases : []), ...(Array.isArray(record.titleAliases) ? record.titleAliases : [])]
          : target === "artist"
            ? [record.artist, ...(Array.isArray(record.artistAliases) ? record.artistAliases : [])]
            : [record.animeTitle, record.animeAlternateTitle, record.animeChineseTitle,
              ...(Array.isArray(record.animeAliases) ? record.animeAliases : []),
              ...(chineseEnabled && chineseTitleProvider ? chineseTitleProvider.getAliases(record) : [])];
        for (const value of candidates) {
          const label = String(value == null ? "" : value).trim();
          if (label) values.add(label);
        }
      }
      const result = [...values];
      suggestionValuesCache.set(key, result);
      return result;
    }
    function setupAnswerSuggestions() {
      const api = global.AMQUI && global.AMQUI.answerSuggestions;
      if (!api || typeof api.createController !== "function") return;
      const fields = [
        { input: elements.singleAnswer, listbox: elements.suggestions, target: null },
        { input: elements.animeAnswer, listbox: elements.animeSuggestions, target: "anime" },
        { input: elements.artistAnswer, listbox: elements.artistSuggestions, target: "artist" },
        { input: elements.titleAnswer, listbox: elements.titleSuggestions, target: "title" }
      ];
      for (const field of fields) {
        if (!field.input || !field.listbox) continue;
        suggestionControllers.push(api.createController({
          input: field.input,
          listbox: field.listbox,
          document,
          getValues: () => getSuggestionValues(field.target),
          isEnabled: () => {
            if (!session || !lastCatalog) return false;
            const state = session.getState();
            if (!state || !state.question || !["ready", "playing", "paused"].includes(state.phase)) return false;
            return field.target ? state.target === "all" : state.target !== "all";
          },
          onSelect: () => { if (answerInputsHaveText(session && session.getState())) localError = ""; }
        }));
      }
    }

    function updateSrsCatalog(catalog, source, records) {
      if (srsCatalog === catalog) return;
      const amqRecords = source === "AMQ" ? records : readCatalogRecords(catalog, "AMQ");
      const emqRecords = source === "EMQ" ? records : readCatalogRecords(catalog, "EMQ");
      amqRecordsById = new Map(amqRecords.filter(record => record && record.id != null).map(record => [String(record.id), record]));
      emqRecordsById = new Map(emqRecords.filter(record => record && record.id != null).map(record => [String(record.id), record]));
      amqSongIds = new Set(amqRecords.filter(record => record && record.id != null && record.animeTitle && record.title && record.artist
        && Array.isArray(record.audioCandidates) && record.audioCandidates.length > 0).map(record => String(record.id)));
      emqSongIds = new Set(emqRecords.filter(record => record && record.id != null && record.animeTitle && record.title && record.artist
        && Array.isArray(record.audioCandidates) && record.audioCandidates.length > 0).map(record => String(record.id)));
      srsCatalog = catalog;
    }
    function ensureOpenCCLoaded(signal) {
      if (global.OpenCC && typeof global.OpenCC.Converter === "function") return Promise.resolve(true);
      if (openccLoadPromise) return openccLoadPromise;
      const doc = global.document;
      if (!doc || !doc.head || typeof doc.createElement !== "function" || !chineseTitleApi || !chineseTitleApi.urls) return Promise.resolve(false);
      openccLoadPromise = new Promise(resolve => {
        const script = doc.createElement("script");
        let settled = false;
        const finish = value => { if (settled) return; settled = true; clearTimeout(timer); if (signal) signal.removeEventListener("abort", onAbort); resolve(value); };
        const onAbort = () => finish(false);
        const timer = setTimeout(() => { script.remove(); finish(false); }, 10000);
        script.src = chineseTitleApi.urls.opencc; script.async = true;
        script.onload = () => finish(Boolean(global.OpenCC && typeof global.OpenCC.Converter === "function"));
        script.onerror = () => finish(false);
        if (signal) { if (signal.aborted) { finish(false); return; } signal.addEventListener("abort", onAbort, { once: true }); }
        doc.head.appendChild(script);
      }).finally(() => { openccLoadPromise = null; });
      return openccLoadPromise;
    }
    function syncChineseTitleProvider(enabled) {
      if (!chineseTitleProvider || !elements.chineseTitlesStatus) return;
      if (!enabled) {
        if (chineseTitleAbortController) chineseTitleAbortController.abort();
        chineseTitleAbortController = null; chineseTitleLoadPromise = null; chineseTitleLoadState = "disabled";
        suggestionValuesCache.clear();
        elements.chineseTitlesStatus.textContent = "中文標題服務已關閉；不會下載外部標題資料。";
        return;
      }
      if (chineseTitleProvider.getStatus().ready) {
        chineseTitleLoadState = chineseTitleProvider.getStatus().status;
        elements.chineseTitlesStatus.textContent = chineseTitleLoadState === "ready-stale"
          ? "中文標題使用快取資料；遠端來源暫時不可用。"
          : chineseTitleLoadState === "ready-partial" ? "中文標題已載入部分來源；缺失來源不會阻擋猜歌。" : "中文標題資料已就緒。";
        return;
      }
      if (chineseTitleLoadPromise) return;
      chineseTitleAbortController = new AbortController();
      const controller = chineseTitleAbortController;
      chineseTitleLoadState = "loading";
      elements.chineseTitlesStatus.textContent = "正在載入中文標題資料；一般猜歌不會因此停住。";
      chineseTitleLoadPromise = ensureOpenCCLoaded(controller.signal).catch(() => false)
        .then(() => chineseTitleProvider.load({ signal: controller.signal })).then(result => {
        if (disposed || controller.signal.aborted) return;
        chineseTitleLoadState = result.status || "ready";
        suggestionValuesCache.clear();
        elements.chineseTitlesStatus.textContent = result.stale ? "中文標題使用過期快取；遠端來源暫時不可用。"
          : result.partial ? "中文標題已載入部分來源；缺失來源不會阻擋猜歌。" : `中文標題資料已就緒（${Number(result.count || 0).toLocaleString()} 個作品映射）。`;
        render();
      }).catch(error => {
        if (disposed || controller.signal.aborted || error && error.name === "AbortError") return;
        chineseTitleLoadState = "error";
        elements.chineseTitlesStatus.textContent = "中文標題資料載入失敗；猜歌仍可使用原有標題。可關閉再開啟重試。";
      }).finally(() => {
        if (chineseTitleAbortController === controller) chineseTitleAbortController = null;
        chineseTitleLoadPromise = null;
      });
    }
    function applyAppSettings(saved) {
      if (!saved) return;
      if (elements.target && (!global.document || global.document.activeElement !== elements.target)) elements.target.value = saved.target;
      if (elements.count && (!global.document || global.document.activeElement !== elements.count)) elements.count.value = String(saved.questionCount);
      if (elements.clipSeconds && (!global.document || global.document.activeElement !== elements.clipSeconds)) elements.clipSeconds.value = String(saved.clipSeconds);
      if (elements.partial && (!global.document || global.document.activeElement !== elements.partial)) elements.partial.checked = saved.acceptPartial;
      if (elements.autoPlay && (!global.document || global.document.activeElement !== elements.autoPlay)) elements.autoPlay.checked = saved.autoPlay;
      if (elements.chineseTitlesEnabled && (!global.document || global.document.activeElement !== elements.chineseTitlesEnabled)) elements.chineseTitlesEnabled.checked = saved.chineseTitlesEnabled === true;
      syncChineseTitleProvider(saved.chineseTitlesEnabled === true);
      if (elements.randomSample && (!global.document || global.document.activeElement !== elements.randomSample)) elements.randomSample.checked = saved.randomSample === true;
      if (elements.clipStartSeconds && (!global.document || global.document.activeElement !== elements.clipStartSeconds)) elements.clipStartSeconds.value = String(saved.clipStartSeconds ?? 0);
      if (elements.autoNextDelaySeconds && (!global.document || global.document.activeElement !== elements.autoNextDelaySeconds)) elements.autoNextDelaySeconds.value = String(saved.autoNextDelaySeconds ?? 0);
      if (elements.srsEnabled && (!global.document || global.document.activeElement !== elements.srsEnabled)) elements.srsEnabled.checked = saved.srsEnabled === true;
      for (const [name, element] of [["yearFrom", elements.yearFrom], ["yearTo", elements.yearTo], ["animeType", elements.animeType], ["difficultyMin", elements.difficultyMin], ["difficultyMax", elements.difficultyMax], ["songType", elements.songType], ["watchStatus", elements.watchStatus]]) {
        if (!element || global.document && global.document.activeElement === element) continue;
        const value = saved[name]; element.value = value == null ? "" : String(value);
      }
      if (elements.includeUnknownYear && (!global.document || global.document.activeElement !== elements.includeUnknownYear)) elements.includeUnknownYear.checked = saved.includeUnknownYear !== false;
    }
    function optionalNumber(element) { if (!element || element.value === "") return null; const value = Number(element.value); return Number.isFinite(value) ? value : NaN; }
    function saveAppSettings() {
      if (!appSettingsStore) return;
      const patch = { target: elements.target.value, questionCount: Number(elements.count.value),
        clipSeconds: Number(elements.clipSeconds.value), acceptPartial: elements.partial.checked, autoPlay: elements.autoPlay.checked,
        randomSample: elements.randomSample ? Boolean(elements.randomSample.checked) : false,
        clipStartSeconds: elements.clipStartSeconds ? Number(elements.clipStartSeconds.value) : 0,
        autoNextDelaySeconds: elements.autoNextDelaySeconds ? Number(elements.autoNextDelaySeconds.value) : 0,
        chineseTitlesEnabled: elements.chineseTitlesEnabled ? Boolean(elements.chineseTitlesEnabled.checked) : appSettingsStore.getSettings().chineseTitlesEnabled === true,
        srsEnabled: elements.srsEnabled ? Boolean(elements.srsEnabled.checked) : appSettingsStore.getSettings().srsEnabled === true,
        yearFrom: optionalNumber(elements.yearFrom), yearTo: optionalNumber(elements.yearTo),
        includeUnknownYear: elements.includeUnknownYear ? Boolean(elements.includeUnknownYear.checked) : appSettingsStore.getSettings().includeUnknownYear !== false,
        animeType: elements.animeType ? elements.animeType.value.trim() : "",
        difficultyMin: optionalNumber(elements.difficultyMin), difficultyMax: optionalNumber(elements.difficultyMax),
        songType: elements.songType ? elements.songType.value.trim() : "", watchStatus: elements.watchStatus ? elements.watchStatus.value : "" };
      const result = appSettingsStore.set(patch);
      if (!result.ok) localError = result.reason === "invalid-settings" ? "出題篩選條件無效；請確認年份與難度範圍，且起始值不大於結束值。" : "猜歌設定未能保存；目前值只在本次頁面工作階段有效。";
      else {
        if (localError.includes("未能保存") || localError.includes("篩選條件無效")) localError = "";
      }
      render();
    }
    function formatInterval(ms) {
      const value = Math.max(0, Number(ms) || 0);
      if (value < 3600000) return `${Math.max(1, Math.round(value / 60000))} 分鐘`;
      if (value < 86400000) return `${Math.max(1, Math.round(value / 3600000))} 小時`;
      return `${Math.max(1, Math.round(value / 86400000))} 天`;
    }
    function currentSrsRatingKey(state) {
      if (!state || !state.question || !state.result) return null;
      return `${roundToken}:${state.completedCount}:${state.question.source}:${state.question.id}:${state.result.kind}`;
    }
    function disposeSession() {
      const cleanupErrors = [];
      const unsubscribe = unsubscribeSession;
      const activeSession = session;
      unsubscribeSession = null;
      session = null;
      poolSize = 0;
      if (unsubscribe) {
        try { unsubscribe(); } catch (error) { cleanupErrors.push(error); }
      }
      if (activeSession) {
        try { activeSession.dispose(); } catch (error) { cleanupErrors.push(error); }
      }
      if (cleanupErrors.length) {
        if (!localError) localError = "猜歌工作階段已停止，但部分資源清理發生錯誤。";
        return cleanupErrors;
      }
      return [];
    }
    function setupSession(catalog, source) {
      disposeSession();
      ratingDoneKey = null;
      try {
        const allRecords = readCatalogRecords(catalog, source);
        updateSrsCatalog(catalog, source, allRecords);
        const records = focusSongIds && source === "AMQ" ? allRecords.filter(record => focusSongIds.has(String(record.id))) : allRecords;
        const sessionOptions = { records, source };
        if (settings.playbackCoordinator) sessionOptions.playbackCoordinator = settings.playbackCoordinator;
        if (focusSongQueue && source === "AMQ") sessionOptions.questionQueue = focusSongQueue.slice();
        if (familiarityStore) sessionOptions.familiarityStore = familiarityStore;
        if (historyStore) sessionOptions.historyStore = historyStore;
        sessionOptions.isEligible = record => {
          if (record.source === "AMQ" && isBlacklisted(record.id)) return false;
          const saved = appSettingsStore && appSettingsStore.getSettings ? appSettingsStore.getSettings() : null;
          const filters = saved || {};
          if (filters.yearFrom != null || filters.yearTo != null) {
            if (record.animeYear == null) { if (filters.includeUnknownYear === false) return false; }
            else {
              const year = Number(record.animeYear);
              if (!Number.isFinite(year)) { if (filters.includeUnknownYear === false) return false; }
              else {
                if (filters.yearFrom != null && year < filters.yearFrom) return false;
                if (filters.yearTo != null && year > filters.yearTo) return false;
              }
            }
          }
          if (filters.animeType && String(record.animeType == null ? "" : record.animeType).trim() !== filters.animeType) return false;
          if (filters.difficultyMin != null || filters.difficultyMax != null) {
            const difficulty = Number(record.difficulty);
            if (record.difficulty == null || !Number.isFinite(difficulty)) return false;
            if (filters.difficultyMin != null && difficulty < filters.difficultyMin) return false;
            if (filters.difficultyMax != null && difficulty > filters.difficultyMax) return false;
          }
          if (filters.songType && String(record.type == null ? "" : record.type).trim() !== filters.songType) return false;
          if (filters.watchStatus) {
            if (!personalLibraryStore || typeof personalLibraryStore.getWorkWatchStatus !== "function" || record.animeId == null) return false;
            const status = personalLibraryStore.getWorkWatchStatus({ source: record.source, id: record.animeId });
            if (status !== filters.watchStatus) return false;
          }
          const listId = filters.customListId || "";
          if (!listId) return true;
          if (!personalLibraryStore || typeof personalLibraryStore.hasWorkMembership !== "function") return false;
          return record.animeId != null && personalLibraryStore.hasWorkMembership(listId, { source: record.source, id: record.animeId });
        };
        sessionOptions.selectNext = (available, context) => {
          const saved = appSettingsStore && appSettingsStore.getSettings ? appSettingsStore.getSettings() : null;
          const selector = global.AMQEngine && global.AMQEngine.quizPool;
          if (!saved || saved.srsEnabled !== true || !selector || typeof selector.pickSrsWeighted !== "function") return null;
          return selector.pickSrsWeighted(available, {
            source: context.source,
            random: context.random,
            timestamp: typeof settings.now === "function" ? settings.now() : Date.now(),
            getCard: record => {
              const sourceStore = srsStoreFor(record.source);
              return sourceStore && typeof sourceStore.getCard === "function" ? sourceStore.getCard(record) : null;
            }
          });
        };
        let createdAudioService = null;
        if (settings.audioService && typeof settings.audioService.play === "function") { sessionOptions.audioService = settings.audioService; sessionOptions.disposeAudioService = false; }
        else if (typeof settings.audioServiceFactory === "function") {
          createdAudioService = settings.audioServiceFactory();
          sessionOptions.audioService = createdAudioService;
        }
        if (typeof settings.random === "function") sessionOptions.random = settings.random;
        if (typeof settings.now === "function") sessionOptions.now = settings.now;
        if (typeof settings.setInterval === "function") sessionOptions.setInterval = settings.setInterval;
        if (typeof settings.clearInterval === "function") sessionOptions.clearInterval = settings.clearInterval;
        if (settings.tickMs !== undefined) sessionOptions.tickMs = settings.tickMs;
        const createSession = settings.factories && settings.factories.createQuizSession;
        try {
          session = typeof createSession === "function" ? createSession(sessionOptions) : sessionApi.createQuizSession(sessionOptions);
        } catch (error) {
          if (createdAudioService && typeof createdAudioService.dispose === "function") {
            try { createdAudioService.dispose(); } catch (cleanupError) {
              if (error && typeof error === "object") error.cleanupErrors = [...(error.cleanupErrors || []), cleanupError];
            }
          }
          throw error;
        }
        poolSize = session.getPoolSize();
        unsubscribeSession = session.subscribe(render);
        const selectedListId = appSettingsStore && appSettingsStore.getSettings ? appSettingsStore.getSettings().customListId || "" : "";
        const selectedList = selectedListId && personalLibraryStore && personalLibraryStore.getListsResult().data.lists.find(item => String(item.id) === String(selectedListId));
        const hasLegacyMembers = Boolean(selectedList && selectedList.animeIds && selectedList.animeIds.length);
        localError = poolSize ? "" : selectedListId
          ? hasLegacyMembers
            ? "所選清單含未標記 AMQ／EMQ 來源的舊成員，為避免 ID 撞號不會自動納入出題池；請在曲庫中重新加入作品。"
            : "所選自訂清單沒有可播放的來源明確作品；請在曲庫中加入作品，或清除清單選擇。"
          : "此模式沒有同時具備作品、歌手與音訊候選的可播放曲目。";
      } catch (error) {
        session = null;
        poolSize = 0;
        localError = global.AMQCore.errors.normalize(error, { code: "QUIZ_POOL_BUILD_FAILED", category: "state", message: "無法建立猜歌題庫" }).message;
      }
      if (lastCatalog !== catalog) { suggestionCatalog = null; suggestionValuesCache = new Map(); }
      lastCatalog = catalog;
      suggestionControllers.forEach(controller => controller.close());
    }
    function syncAppState(nextState) {
      if (nextState.mode !== lastMode) {
        disposeSession();
        focusSongIds = null;
        focusSongQueue = null;
        srsModeActive = false;
        ratingDoneKey = null;
        srsSkippedIds.clear();
        srsMessage = "";
        lastCatalog = null;
        lastMode = nextState.mode;
      }
      if (nextState.dataStatus !== "loaded") {
        if (session) disposeSession();
        if (srsModeActive) {
          focusSongIds = null; focusSongQueue = null; srsModeActive = false; ratingDoneKey = null; srsSkippedIds.clear();
          srsMessage = "曲庫載入中斷，間隔複習已停止；未評級卡片保留原排程。";
        }
        lastCatalog = null;
      } else if (runtime && ["AMQ", "EMQ", "MIX"].includes(nextState.mode)) {
        const catalog = runtime.catalogSnapshot();
        if (catalog && catalog !== lastCatalog) setupSession(catalog, nextState.mode);
      }
      render();
    }
    function targetIsAll(state) { const active = state && !["idle", "finished"].includes(state.phase); return (active ? state.target : elements.target.value) === "all"; }
    function answerInputsHaveText(state) {
      if (targetIsAll(state)) return [elements.animeAnswer, elements.artistAnswer, elements.titleAnswer].some(input => input && input.value.trim());
      return Boolean(elements.singleAnswer && elements.singleAnswer.value.trim());
    }
    function renderRoundResults(state) {
      if (!elements.roundResults) return;
      let resultState = state;
      let restored = false;
      if (state && state.phase === "idle" && historyStore && typeof historyStore.getLastCompletedRoundId === "function") {
        try {
          const savedRoundId = historyStore.getLastCompletedRoundId();
          if (typeof savedRoundId === "string" && savedRoundId.trim()) {
            resultState = { ...state, phase: "finished", roundId: savedRoundId, restoredResult: true };
            restored = true;
          }
        } catch (_) {}
      }
      const visible = Boolean(resultState && resultState.phase === "finished");
      elements.roundResults.hidden = !visible;
      if (elements.roundResultsEmpty) elements.roundResultsEmpty.hidden = visible;
      if (!visible) return;
      let rows = [];
      let unavailable = !resultState.roundId;
      try {
        if (resultState.roundId && historyStore && typeof historyStore.getRoundHistory === "function") rows = historyStore.getRoundHistory(resultState.roundId) || [];
        else unavailable = true;
      } catch (_) { unavailable = true; }
      const safeRows = Array.isArray(rows) ? rows.filter(entry => entry && entry.roundId === resultState.roundId) : [];
      const persistedRows = safeRows.filter(entry => entry.persisted !== false);
      const pendingRows = safeRows.filter(entry => entry.persisted === false);
      const uniqueQuestions = new Set(persistedRows.map(entry => `${entry.source || ""}:${entry.songId || ""}:${entry.at || ""}`));
      const correct = persistedRows.filter(entry => entry.correct === true).length;
      const accuracy = persistedRows.length ? Math.round(correct / persistedRows.length * 100) : null;
      const completedCount = Number.isFinite(Number(resultState.completedCount)) && Number(resultState.completedCount) > 0
        ? Number(resultState.completedCount) : uniqueQuestions.size;
      if (elements.roundResultsSummary) {
        if (!resultState.roundId) elements.roundResultsSummary.textContent = "本輪識別碼未建立，無法安全區分本輪與舊紀錄，因此不顯示明細。";
        else if (unavailable) elements.roundResultsSummary.textContent = "本輪紀錄查詢功能不可用；為避免混入其他回合，暫不顯示結果明細。";
        else if (!safeRows.length) elements.roundResultsSummary.textContent = restored
          ? "上一輪已完成，但沒有可恢復的已保存計分紀錄。揭曉與未播放跳過不會被補成成績。"
          : `本輪已計分 ${completedCount} 題；目前沒有可確認歸屬的已保存計分紀錄。`;
        else if (!persistedRows.length) elements.roundResultsSummary.textContent = `本輪已計分 ${completedCount} 題；${pendingRows.length} 個計分目標尚未保存，暫不計算已保存紀錄的正確率。`;
        else elements.roundResultsSummary.textContent = `${restored ? "上一輪已保存結果" : `本輪已計分 ${completedCount} 題`} · 已保存 ${uniqueQuestions.size} 首題目、${persistedRows.length} 個計分目標 · 已保存目標正確率 ${accuracy}%（${correct}/${persistedRows.length}）${pendingRows.length ? `；另有 ${pendingRows.length} 個目標尚未保存` : ""}。`;
      }
      if (elements.roundResultsList) {
        const items = safeRows.slice().reverse().map(entry => {
          const item = document.createElement("li");
          item.className = `quiz-round-result-item${entry.correct === true ? " is-correct" : " is-wrong"}`;
          const title = document.createElement("strong");
          title.textContent = String(entry.songName || `歌曲 ${entry.songId || "未知"}`);
          const meta = document.createElement("span");
          const targetLabels = { anime: "作品", title: "歌曲", artist: "歌手", unknown: "未知目標" };
          const resultLabel = String(entry.result || (entry.correct ? "答對" : "答錯"));
          const elapsed = Number.isFinite(Number(entry.elapsed)) && entry.elapsed !== null && entry.elapsed !== ""
            ? ` · ${Number(entry.elapsed).toFixed(1)} 秒` : "";
          meta.textContent = `${entry.source === "EMQ" ? "EMQ" : entry.source === "AMQ" ? "AMQ" : "未知來源"} · ${targetLabels[entry.target] || "未知目標"} · ${resultLabel}${elapsed}${entry.persisted === false ? " · 尚未保存" : ""}`;
          item.appendChild(title); item.appendChild(meta);
          return item;
        });
        elements.roundResultsList.replaceChildren(...items);
      }
      if (elements.roundResultsNote) {
        let persistence = null;
        try { persistence = historyStore && typeof historyStore.getPersistenceStatus === "function" ? historyStore.getPersistenceStatus() : null; } catch (_) { persistence = null; }
        const failed = pendingRows.length > 0 || persistence && (persistence.detailWriteBlocked || persistence.detailSaveFailed);
        const completionWarning = typeof resultState.persistenceWarning === "string" && /完成狀態|結果標記/.test(resultState.persistenceWarning);
        const previousPointerWarning = typeof resultState.persistenceWarning === "string" && /上一輪完成結果指標清除失敗/.test(resultState.persistenceWarning);
        elements.roundResultsNote.textContent = previousPointerWarning
          ? "警告：上一輪完成結果指標未能清除。若重新載入後恢復了舊回合，該紀錄不代表本輪成績；下方只列出目前回合可確認歸屬的紀錄。"
          : completionWarning
            ? "本輪完成狀態未能保存，重新載入後可能無法恢復結果頁；逐題明細仍依各自的實際保存狀態呈現。"
          : failed
            ? "本機答題紀錄有儲存問題；標示「尚未保存」的項目只存在於目前工作階段，結果可能不完整。揭曉與未播放跳過不會寫入歷史。"
            : restored
            ? "這是重新載入後恢復的最近一輪完成結果，只包含持久化的本輪計分目標。開始新回合時會清除這個結果指標。"
            : "只列出本輪已保存的計分目標；揭曉與未播放跳過不會寫入答題歷史。正確率以已保存的目標紀錄計算，不代表未保存或未計分題目。";
      }
    }

    function render() {
      if (disposed) return;
      const appState = store.getState();
      const state = session ? session.getState() : null;
      const phase = state ? state.phase : "idle";
      const renderedQuestion = state && state.question ? state.question : null;
      if (renderedQuestion && renderedQuestion !== lastRenderedQuestion) {
        // A question owns a fresh answer draft. Never carry a wrong answer into the next song.
        for (const input of [elements.singleAnswer, elements.animeAnswer, elements.artistAnswer, elements.titleAnswer]) {
          if (input) input.value = "";
        }
        suggestionControllers.forEach(controller => controller.close());
      }
      lastRenderedQuestion = renderedQuestion;
      const sharedPhase = store.getState().questionStatus;
      if (sharedPhase !== phase) store.update({ questionStatus: phase });
      const active = Boolean(state && !["idle", "finished"].includes(phase));
      const canAnswer = phase === "playing";
      const canRevealOrSkip = ["ready", "playing"].includes(phase) && Boolean(state && state.question);
      const canNext = ["answered", "timed-out", "revealed"].includes(phase);
      const result = state && state.result;
      const currentQuestion = state && state.question;
      const resultVisualState = !result ? "none"
        : result.kind === "unplayed-skip" ? "unplayed-skip"
          : result.kind === "skip" ? "skipped"
            : result.kind === "timeout" ? "timeout"
              : result.kind === "revealed" ? "revealed"
                : result.kind === "submitted" ? (result.correct === true || result.correctByTarget && result.correctByTarget.anime === true ? "correct" : result.correct === false || result.correctByTarget && result.correctByTarget.anime === false ? "incorrect" : "answered")
                  : "none";
      if (elements.roundSection) elements.roundSection.setAttribute("data-quiz-phase", phase);
      if (elements.questionStage) elements.questionStage.setAttribute("data-result-state", resultVisualState);
      if (elements.answerForm) {
        elements.answerForm.setAttribute("data-quiz-phase", phase);
        elements.answerForm.setAttribute("data-result-state", resultVisualState);
      }
      if (elements.answerReveal) elements.answerReveal.setAttribute("data-result-state", resultVisualState);
      renderRoundResults(state);
      const questionSrsStore = currentQuestion ? srsStoreFor(currentQuestion.source) : srsStoreFor(appState.mode);
      let srsCard = questionSrsStore && currentQuestion ? questionSrsStore.getCard(currentQuestion) : null;
      const srsRatingKey = currentSrsRatingKey(state);
      // Global SRS applies only to scored work-title answers. A missing card is enrolled on first valid assessment.
      // Song title and artist targets are deliberately excluded from this learning signal.
      const srsEnabled = Boolean(appSettingsStore && appSettingsStore.getSettings().srsEnabled);
      // A round that lost every audio candidate must not produce an automatic SRS grade,
      // even if playback had started earlier and a latency value is still available.
      const audioFailedForQuestion = Boolean(state && state.audioStatus === "failed");
      if (srsEnabled && !audioFailedForQuestion && result && result.scored === true && canNext && srsRatingKey && ratingDoneKey !== srsRatingKey
        && questionSrsStore && currentQuestion && ["AMQ", "EMQ"].includes(currentQuestion.source)) {
        const assessmentApi = global.AMQLearning && global.AMQLearning.assessmentEngine;
        const assessment = assessmentApi && assessmentApi.assess(result, state.target);
        if (assessment && assessment.grade !== null) {
          if (!srsCard) {
            const enrolled = questionSrsStore.enroll(currentQuestion);
            if (!enrolled.ok) { srsMessage = "全域 SRS 建立卡片失敗；本題排程未更新。"; ratingDoneKey = srsRatingKey; }
            else srsCard = enrolled.card || questionSrsStore.getCard(currentQuestion);
          }
          if (!srsCard || srsCard.state === "suspended") { ratingDoneKey = srsRatingKey; }
          else {
          // Set the guard before rate(): store subscribers render synchronously during persistence.
          ratingDoneKey = srsRatingKey;
          const saved = questionSrsStore.rate(currentQuestion, assessment.grade, Date.now(), {
            origin: "automatic", ruleVersion: assessment.ruleVersion, reasonCodes: assessment.reasonCodes,
            observedGrade: assessment.grade
          });
          if (saved.ok) {
            srsCard = questionSrsStore.getCard(currentQuestion);
            const labels = { 1: "答錯", 2: "答對但超過 15 秒", 3: "答對且 11–15 秒", 4: "答對且 0–10 秒" };
            srsMessage = `自動評級 ${assessment.grade}：${labels[assessment.grade]}。`;
          } else {
            ratingDoneKey = null;
            srsMessage = "自動評級未能保存；本題排程未更新。";
          }
          }
        }
      }
      const srsEligibleResult = Boolean(result && (result.scored === true || result.kind === "revealed" && result.elapsedSeconds !== null));
      const srsRatingPending = Boolean(srsEnabled && questionSrsStore && currentQuestion && srsCard
        && srsCard.state !== "suspended" && srsEligibleResult && canNext && ratingDoneKey !== srsRatingKey);
      const statusLabels = { idle: "尚未開始", ready: "等待播放", playing: "播放中／計時中", paused: "已暫停", answered: "已作答", "timed-out": "時間到", revealed: "已揭曉", finished: "回合完成" };
      if (elements.status) elements.status.textContent = appState.dataStatus === "failed" ? `${appState.mode} 曲庫載入失敗`
        : appState.dataStatus === "loading" ? `${appState.mode} 曲庫載入中`
          : (state ? statusLabels[phase] || phase : "等待曲庫");
      if (elements.poolSize) elements.poolSize.textContent = (state ? state.poolSize : poolSize).toLocaleString();
      if (elements.progress) {
        elements.progress.textContent = state ? `${state.completedCount} / ${state.questionCount === 0 ? "∞" : state.questionCount}` : "0 / 25";
        elements.progress.setAttribute("aria-label", state ? `已完成 ${state.completedCount} 題，共 ${state.questionCount === 0 ? "不限" : state.questionCount} 題` : "尚未開始，預設 25 題");
      }
      if (elements.timer) {
        elements.timer.textContent = state && ["playing", "paused"].includes(phase) ? `${state.remainingSeconds} 秒` : "--";
        elements.timer.setAttribute("data-timer-state", phase === "playing" ? "running" : phase === "paused" ? "paused" : phase === "timed-out" ? "expired" : "idle");
      }
      const audioLabels = { idle: "尚未載入", loading: "載入中", ready: "已就緒", playing: "播放中", paused: "已暫停", blocked: "需要手動播放", failed: "候選皆失敗", cancelled: "已取消", stopped: "已停止", disposed: "已釋放" };
      if (elements.audioStatus) {
        const audioState = state && typeof state.audioStatus === "string" ? state.audioStatus : "idle";
        elements.audioStatus.textContent = audioLabels[audioState] || audioState || "尚未載入";
        elements.audioStatus.setAttribute("data-audio-state", audioState);
      }
      if (elements.questionMeta) elements.questionMeta.textContent = state && state.question
        ? `第 ${state.roundNumber} 題 · ${state.source} · ${state.question.type || "未提供類型"}`
        : "尚未開始猜歌回合";
      if (elements.questionTitle) elements.questionTitle.textContent = state && state.question
        ? "聆聽音訊，依所選目標回答。播放成功後才開始倒數。"
        : appState.mode === "MIX" ? "MIX 會依 2:1 權重抽取 AMQ／EMQ 曲目；間隔複習需選擇單一來源。" : "按「開始回合」後會隨機抽取未重複且有音訊候選的歌曲。";
      if (elements.message) {
        const baseMessage = state ? state.message : appState.mode === "MIX"
          ? "MIX 已載入 AMQ 與 EMQ 曲庫；兩個來源都有候選時按 2:1 權重抽題，單一來源耗盡時使用另一來源。"
          : appState.dataStatus === "loading" ? "曲庫載入中，完成後即可開始猜歌。"
          : appState.dataStatus !== "loaded" ? "等待經驗證的曲庫載入。" : "正在建立可播放曲目清單。";
        const persistence = appSettingsStore && appSettingsStore.getStatus();
        const settingsWarning = !persistence ? ""
          : persistence.blocked || persistence.error ? " 猜歌設定儲存異常，變更可能無法跨工作階段保存。"
          : persistence.recoveryNotice ? " 猜歌設定格式異常，原始內容已備份；修改任一設定即可保存有效版本。" : "";
        const persistenceWarning = state && state.persistenceWarning ? ` ${state.persistenceWarning}` : "";
        const activeSource = currentQuestion && currentQuestion.source ? currentQuestion.source : appState.mode;
        const familiarityStatus = familiarityStore && typeof familiarityStore.getPersistenceStatus === "function" ? familiarityStore.getPersistenceStatus() : null;
        const familiarityScope = activeSource === "EMQ" ? familiarityStatus && familiarityStatus.EMQ : activeSource === "AMQ" ? familiarityStatus && familiarityStatus.AMQ : null;
        const familiarityLastWrite = familiarityStore && typeof familiarityStore.getLastWrite === "function" ? familiarityStore.getLastWrite() : null;
        const familiarityWarning = familiarityScope && familiarityScope.readBlocked
          ? ` ${activeSource} 熟悉度資料讀取失敗，保留上次快照並暫停寫入。`
          : familiarityLastWrite && familiarityLastWrite.persisted === false && (!familiarityLastWrite.source || familiarityLastWrite.source === activeSource)
            ? ` ${activeSource} 熟悉度保存失敗，這次變更未能確認寫入。` : "";
        const blacklistStatus = ["AMQ", "MIX"].includes(appState.mode) && blacklistStore && blacklistStore.getStatus ? blacklistStore.getStatus() : null;
        const blacklistWarning = blacklistStatus && blacklistStatus.songReadError ? " 歌曲黑名單讀取失敗，保留上次快照。"
          : blacklistStatus && blacklistStatus.songWriteError ? " 歌曲黑名單保存失敗，狀態未變更。"
            : blacklistStatus && blacklistStatus.workReadError ? " 作品黑名單讀取失敗，保留上次快照。"
              : blacklistStatus && blacklistStatus.workWriteError ? " 作品黑名單保存失敗，狀態未變更。"
                : blacklistStatus && blacklistStatus.recoveryAvailable ? " 黑名單資料已隔離備份，請檢查 recovery。" : "";
        elements.message.textContent = baseMessage + settingsWarning + persistenceWarning + familiarityWarning + blacklistWarning;
      }
      if (elements.error) {
        const dataError = appState.dataError
          ? global.AMQCore.errors.normalize(appState.dataError, { code: "DATA_LOAD_FAILED", category: "data", message: "曲庫載入失敗" }) : null;
        const audioErrorLabels = {
          AUDIO_ALL_CANDIDATES_FAILED: "所有音訊候選皆失敗",
          AUDIO_NO_CANDIDATES: "這首歌曲沒有可用音源網址",
          AUDIO_AUTOPLAY_BLOCKED: "瀏覽器阻擋自動播放，請按「播放／恢復音訊」",
          AUDIO_CANDIDATES_INVALID: "音訊候選格式無效",
          AUDIO_START_POSITION_INVALID: "音訊片段起始設定無效"
        };
        const audioFailureLabels = { timeout: "播放逾時", "media-error": "媒體錯誤（瀏覽器未提供細項）", "media-aborted": "媒體載入中止", "network-error": "網路錯誤（可能包含網路／跨域限制）", "decode-error": "音訊解碼錯誤", "source-not-supported": "瀏覽器不支援此音訊格式", "play-rejected": "播放請求遭拒", "play-threw": "播放啟動例外", "media-create-failed": "播放器建立失敗", "seek-failed": "無法定位音訊片段" };
        const audioError = state && ["failed", "blocked"].includes(state.audioStatus) && state.audioError ? String(state.audioError) : "";
        const audioQuestionRef = state && state.question ? `（${state.question.source} 歌曲 ID ${state.question.id}）` : "";
        const audioFailureDetail = audioError === "AUDIO_ALL_CANDIDATES_FAILED" && state.audioFailures && state.audioFailures.length
          ? `；候選結果：${state.audioFailures.map(item => `候選 ${item.candidateIndex || "?"} ${safeAudioSourceLabel(item.source)}${item.format && item.format !== "unknown" ? `（.${item.format}）` : ""}：${audioFailureLabels[item.reason] || item.reason}`).join("；")}` : "";
        const errorText = localError || (audioError ? `${audioError}：${audioErrorLabels[audioError] || "音訊播放失敗"}${audioQuestionRef}${audioFailureDetail}` : dataError ? `${dataError.code}：${dataError.message}` : "");
        elements.error.textContent = errorText;
        elements.error.hidden = !errorText;
        elements.error.setAttribute("data-error-state", !errorText ? "none" : audioError ? "audio" : dataError ? "data" : "local");
        elements.error.setAttribute("data-error-code", audioError || dataError && dataError.code || "");
      }
      const all = targetIsAll(state);
      if (elements.singleLabel) elements.singleLabel.hidden = all;
      suggestionControllers.forEach(controller => controller.refresh());
      if (elements.allFields) elements.allFields.hidden = !all;
      if (elements.submit) elements.submit.disabled = !canAnswer || !answerInputsHaveText(state);
      if (elements.start) elements.start.disabled = !session || !poolSize || active;
      if (elements.play) elements.play.disabled = !session || !state || !state.question
        || !(state.audioStatus === "blocked" || state.audioStatus === "paused" || state.audioStatus === "ready" && state.settings.autoPlay === false);
      if (elements.pause) elements.pause.disabled = !session || phase !== "playing" || state.audioStatus !== "playing";
      if (elements.reveal) elements.reveal.disabled = !session || !canRevealOrSkip;
      if (elements.skip) elements.skip.disabled = !session || !canRevealOrSkip;
      if (elements.next) elements.next.disabled = !session || !canNext || srsRatingPending;
      if (elements.end) elements.end.disabled = !session || !active;
      for (const control of [elements.target, elements.count, elements.clipSeconds, elements.partial, elements.autoPlay,
        elements.randomSample, elements.clipStartSeconds, elements.autoNextDelaySeconds]) if (control) control.disabled = active;
      if (elements.clipStartSeconds) elements.clipStartSeconds.disabled = active || Boolean(elements.randomSample && elements.randomSample.checked);
      const showAnswer = Boolean(state && state.question && result && result.kind !== "unplayed-skip"
        && ["submitted", "timeout", "skip", "revealed"].includes(result.kind));
      if (elements.answerReveal) {
        elements.answerReveal.hidden = !showAnswer;
        elements.answerReveal.setAttribute("aria-label", showAnswer ? ({ correct: "答對後的歌曲資訊", incorrect: "答錯後的正確答案", skipped: "跳過題目的正確答案", timeout: "時間到，正確答案", revealed: "已揭曉的歌曲資訊" }[resultVisualState] || "歌曲資訊") : "答案尚未揭曉");
      }
      if (showAnswer) {
        if (elements.correctAnime) {
          const chineseTitle = appSettingsStore && appSettingsStore.getSettings().chineseTitlesEnabled && chineseTitleProvider
            ? chineseTitleProvider.getTitle(state.question) : "";
          elements.correctAnime.textContent = chineseTitle || state.question.animeTitle || state.question.animeAlternateTitle || "未提供";
        }
        if (elements.correctTitle) elements.correctTitle.textContent = state.question.title || "未提供";
        if (elements.correctArtist) elements.correctArtist.textContent = state.question.artist || "未提供";
      }
      if (historyStore) {
        try {
          const historySummary = historyStore.getSummary();
          if (elements.historyCounts) {
            const legacyLabel = historySummary.legacy.source === "legacy-summary-read-only" ? "舊版摘要" : "舊版可用明細";
            elements.historyCounts.textContent = `新版目標紀錄 ${historySummary.current.total} 筆；${legacyLabel} ${historySummary.legacy.total} 筆；目前可見 ${historySummary.combinedTotal} 筆。`;
          }
          if (elements.historyRecent) {
            const recent = historyStore.getHistory().slice(-5).reverse();
            elements.historyRecent.textContent = recent.length ? recent.map(entry => {
              const targetLabels = { anime: "作品", title: "歌曲", artist: "歌手", unknown: "未知目標" };
              const sourceLabel = entry.source === "EMQ" ? "EMQ" : entry.source === "AMQ" ? "AMQ" : "舊資料";
              const answerLabel = entry.result || (entry.correct ? "答對" : "答錯");
              return `${sourceLabel}／${targetLabels[entry.target] || "目標"}／${entry.songName || entry.workTitle || `歌曲 ${entry.songId}`}／${answerLabel}`;
            }).join("；") : "尚無答題紀錄。揭曉答案與未播放跳過不會寫入歷史。";
          }
          const persistence = historyStore.getPersistenceStatus();
          if (elements.historyWarning) elements.historyWarning.textContent = persistence.detailWriteBlocked || persistence.detailSaveFailed || persistence.summarySaveFailed || persistence.summaryWriteBlocked
            ? "答題歷史有資料隔離或儲存異常；請檢查本機儲存空間與 recovery 備份。"
            : persistence.legacyReadError ? "部分舊版答題紀錄暫時無法讀取；保留上次可讀取的紀錄，恢復儲存後會重新載入。"
            : persistence.detailRecoveryNotice ? "偵測到損壞的新版答題紀錄，原始內容已隔離備份；目前以可恢復資料繼續。" : "";
        } catch (_) {
          if (elements.historyWarning) elements.historyWarning.textContent = "答題歷史無法讀取。";
        }
      } else {
        if (elements.historyCounts) elements.historyCounts.textContent = "答題歷史儲存模組未載入。";
        if (elements.historyRecent) elements.historyRecent.textContent = "";
      }
      const srsAvailable = Boolean(srsStore && emqSrsStore && ["AMQ", "EMQ"].includes(appState.mode));
      const visibleSrsStore = currentQuestion ? srsStoreFor(currentQuestion.source) : srsStoreFor(appState.mode);
      if (elements.srsCounts) {
        if (!srsEnabled) elements.srsCounts.textContent = "全域 SRS 已關閉；既有排程保留，普通猜歌與答題歷史不受影響。";
        else if (!srsStore || !emqSrsStore) elements.srsCounts.textContent = "間隔複習模組未載入。";
        else if (!srsAvailable) elements.srsCounts.textContent = "MIX 可正常猜歌；間隔複習請切換到 AMQ 或 EMQ，以免跨來源排程混淆。";
        else {
          const counts = visibleSrsStore.counts();
          elements.srsCounts.textContent = `${visibleSrsStore.source} · 到期 ${counts.due} · 新卡 ${counts.new} · 學習中 ${counts.learning} · 複習中 ${counts.review} · 暫停 ${counts.suspended} · 每日新卡 ${counts.newStudiedToday}/${counts.dailyNew}`;
        }
      }
      if (elements.srsDailyNew && visibleSrsStore && (!global.document || global.document.activeElement !== elements.srsDailyNew)) elements.srsDailyNew.value = String(visibleSrsStore.getSettings().dailyNew);
      if (elements.srsBatchSize && visibleSrsStore && (!global.document || global.document.activeElement !== elements.srsBatchSize)) elements.srsBatchSize.value = String(visibleSrsStore.getSettings().batchSize);
      if (elements.srsToggle) {
        const blacklistedQuestion = Boolean(currentQuestion && currentQuestion.source === "AMQ" && isBlacklisted(currentQuestion.id));
        elements.srsToggle.disabled = !srsEnabled || !srsAvailable || !currentQuestion || !["AMQ", "EMQ"].includes(currentQuestion.source) || srsModeActive || srsRatingPending || blacklistedQuestion;
        elements.srsToggle.textContent = blacklistedQuestion ? "歌曲已在黑名單" : !srsCard ? "加入間隔複習" : srsCard.state === "suspended" ? "恢復間隔複習" : "暫停間隔複習";
      }
      if (elements.blacklistToggle) {
        const canBlacklist = Boolean(blacklistStore && currentQuestion && currentQuestion.source === "AMQ");
        elements.blacklistToggle.hidden = !canBlacklist;
        elements.blacklistToggle.disabled = !canBlacklist || srsModeActive || srsRatingPending;
        if (canBlacklist) elements.blacklistToggle.textContent = blacklistStore.isSongBlacklisted(currentQuestion.id) ? "解除歌曲黑名單" : "加入歌曲黑名單";
      }
      if (elements.workBlacklistToggle) {
        const canBlacklistWork = Boolean(blacklistStore && currentQuestion && currentQuestion.source === "AMQ" && currentQuestion.animeId != null);
        elements.workBlacklistToggle.hidden = !canBlacklistWork;
        elements.workBlacklistToggle.disabled = !canBlacklistWork || srsModeActive || srsRatingPending;
        if (canBlacklistWork) elements.workBlacklistToggle.textContent = blacklistStore.isWorkBlacklisted(currentQuestion.animeId) ? "解除作品黑名單" : "排除此作品";
      }
      if (elements.srsStart) elements.srsStart.disabled = !srsEnabled || !srsAvailable || appState.dataStatus !== "loaded" || active;
      for (const control of [elements.srsDailyNew, elements.srsBatchSize]) if (control) control.disabled = !srsEnabled || !srsAvailable || active;
      if (elements.srsEnabled && (!global.document || global.document.activeElement !== elements.srsEnabled)) elements.srsEnabled.checked = srsEnabled;
      const canManuallyOverride = Boolean(srsEnabled && srsRatingKey && ratingDoneKey === srsRatingKey
        && srsCard && srsCard.assessment && srsCard.assessment.origin === "automatic" && canNext);
      if (elements.srsRating) elements.srsRating.hidden = !(srsRatingPending || canManuallyOverride);
      const gradeLabels = { 1: "忘記", 2: "困難", 3: "記得", 4: "輕鬆" };
      for (const button of elements.srsGradeButtons) {
        const grade = Number(button.getAttribute("data-srs-grade"));
        if (!(srsRatingPending || canManuallyOverride) || !questionSrsStore || !currentQuestion) continue;
        try { button.textContent = `${gradeLabels[grade] || "評級"} · ${formatInterval(questionSrsStore.preview(currentQuestion, grade).intervalMs)}`; }
        catch (_) { button.textContent = gradeLabels[grade] || "評級"; }
      }
      if (elements.srsMessage) {
        const persistence = visibleSrsStore && visibleSrsStore.getPersistenceStatus();
        const persistenceWarning = persistence && (persistence.blocked || persistence.error || persistence.recoveryAvailable || persistence.persisted === false)
          ? persistence.recoveryAvailable
            ? "SRS 排程存在隔離／恢復資料；請檢查 recovery 備份，保存狀態尚未完全確認。"
            : "SRS 排程儲存異常；原始排程可能已被保護，請檢查 recovery 備份。"
          : "";
        elements.srsMessage.textContent = persistenceWarning || srsMessage || "";
      }
    }
    function startSrsSession() {
      const appState = store.getState();
      const source = appState.mode;
      const activeSrsStore = srsStoreFor(source);
      if (!activeSrsStore || !runtime || !["AMQ", "EMQ"].includes(source) || appState.dataStatus !== "loaded") {
        srsMessage = "間隔複習需要已載入 AMQ 或 EMQ 曲庫；MIX 模式請先選擇單一來源。"; render(); return;
      }
      const catalog = runtime.catalogSnapshot();
      if (!catalog) { srsMessage = `${source} 曲庫尚未就緒。`; render(); return; }
      const sourceRecords = readCatalogRecords(catalog, source);
      updateSrsCatalog(catalog, source, sourceRecords);
      const queue = activeSrsStore.chooseSession();
      if (!queue.ids.length) {
        srsMessage = "目前沒有可播放的到期卡片或每日額度內的新卡。"; render(); return;
      }
      focusSongQueue = queue.ids.map(String);
      focusSongIds = new Set(focusSongQueue);
      srsSkippedIds = new Set();
      srsModeActive = true;
      ratingDoneKey = null;
      roundToken++;
      setupSession(catalog, source);
      if (!session || !poolSize) {
        focusSongIds = null; focusSongQueue = null; srsModeActive = false; setupSession(catalog, source);
        srsMessage = "排程卡片目前沒有符合猜歌條件的可播放音源。"; render(); return;
      }
      const result = session.startRound({ target: "anime", questionCount: Math.min(poolSize, focusSongIds.size),
        clipSeconds: Number(elements.clipSeconds.value), acceptPartial: elements.partial.checked,
        autoPlay: elements.autoPlay.checked, randomSample: elements.randomSample ? elements.randomSample.checked : false,
        clipStartSeconds: elements.clipStartSeconds ? Number(elements.clipStartSeconds.value) : 0,
        autoNextDelaySeconds: 0, // SRS requires explicit manual rating before advancing.
        instantSeconds: 5, keepHigher: true });
      if (!result.accepted) srsMessage = result.reason === "empty-pool" ? "沒有可播放的到期卡片。" : "無法開始間隔複習回合。";
      else srsMessage = `間隔複習已開始，共 ${Math.min(poolSize, focusSongIds.size)} 首。`;
      render();
    }
    function endSrsSession(message) {
      if (session && !["idle", "finished"].includes(session.getState().phase)) session.endRound();
      focusSongIds = null; focusSongQueue = null; srsModeActive = false; ratingDoneKey = null; srsSkippedIds.clear();
      const catalog = runtime && runtime.catalogSnapshot();
      if (catalog && ["AMQ", "EMQ"].includes(store.getState().mode)) setupSession(catalog, store.getState().mode);
      srsMessage = message || "本次間隔複習已結束；未評級卡片保留原排程。";
      render();
    }
    function continueSrsSession() {
      const activeSrsStore = srsStoreFor(lastMode);
      if (!srsModeActive || !activeSrsStore || !runtime) return;
      const catalog = runtime.catalogSnapshot();
      if (!catalog) { endSrsSession("曲庫已不可用，本次間隔複習已結束；未評級卡片保留原排程。"); return; }
      const queue = activeSrsStore.chooseSession(Date.now(), [...srsSkippedIds]);
      if (!queue.ids.length) {
        endSrsSession("本次間隔複習完成，沒有其他到期卡片或今日可學的新卡。未評級卡片保留原排程。");
        return;
      }
      focusSongQueue = queue.ids.map(String);
      focusSongIds = new Set(focusSongQueue);
      roundToken++; ratingDoneKey = null;
      setupSession(catalog, lastMode);
      if (!session || !poolSize) { endSrsSession("下一批沒有符合猜歌條件的可播放音源；未評級卡片保留原排程。"); return; }
      const result = session.startRound({ target: "anime", questionCount: Math.min(poolSize, focusSongQueue.length),
        clipSeconds: Number(elements.clipSeconds.value), acceptPartial: elements.partial.checked,
        autoPlay: elements.autoPlay.checked, randomSample: elements.randomSample ? elements.randomSample.checked : false,
        clipStartSeconds: elements.clipStartSeconds ? Number(elements.clipStartSeconds.value) : 0,
        autoNextDelaySeconds: 0, // SRS requires explicit manual rating before advancing.
        instantSeconds: 5, keepHigher: true });
      srsMessage = result.accepted ? `本批已完成，繼續下一批 ${Math.min(poolSize, focusSongQueue.length)} 首。` : "下一批無法啟動；未評級卡片保留原排程。";
      if (!result.accepted) endSrsSession(srsMessage); else render();
    }
    function rateCurrentSrs(grade) {
      const state = session && session.getState();
      const key = currentSrsRatingKey(state);
      const activeSrsStore = state && state.question ? srsStoreFor(state.question.source) : null;
      if (!activeSrsStore || !state || !state.question || !key) return;
      const result = activeSrsStore.rate(state.question, grade, Date.now(), {
        origin: "manual", ruleVersion: "manual-override-v1", reasonCodes: ["manual_override"], observedGrade: grade
      });
      if (!result.ok) {
        srsMessage = result.reason === "storage" ? "評級未能保存；請檢查本機儲存空間。" : "無法更新這張間隔複習卡。";
      } else {
        ratingDoneKey = key;
        const labels = { 1: "忘記", 2: "困難", 3: "記得", 4: "輕鬆" };
        srsMessage = `已評級「${labels[grade] || grade}」，下次複習約在 ${new Date(result.nextDue).toLocaleString()}。`;
      }
      render();
    }
    function submitForm(event) {
      if (event) event.preventDefault();
      if (!session) return;
      const target = session.getState().target;
      const answer = target === "all" ? {
        anime: elements.animeAnswer.value, artist: elements.artistAnswer.value, title: elements.titleAnswer.value
      } : elements.singleAnswer.value;
      const result = session.submitAnswer(answer);
      if (result.accepted) {
        localError = "";
        if (elements.singleAnswer) elements.singleAnswer.value = "";
        if (elements.animeAnswer) elements.animeAnswer.value = "";
        if (elements.artistAnswer) elements.artistAnswer.value = "";
        if (elements.titleAnswer) elements.titleAnswer.value = "";
      } else if (result.reason) localError = result.reason === "empty-answer" ? "請先輸入答案。" : "目前狀態不能提交答案。";
      render();
    }
    if (appSettingsStore) {
      applyAppSettings(appSettingsStore.getSettings());
      unsubscribeAppSettings = appSettingsStore.subscribe((status, saved, source) => {
        if (source === "external") applyAppSettings(saved);
        else if (saved) syncChineseTitleProvider(saved.chineseTitlesEnabled === true);
        if (saved && saved.srsEnabled !== true && srsModeActive) {
          endSrsSession("全域 SRS 已關閉；本次複習已停止，既有排程與未評級卡片均保留。");
        }
        const nextListId = saved && saved.customListId || "";
        if (nextListId !== appliedCustomListId) appliedCustomListId = nextListId;
        if (session && typeof session.refreshEligibility === "function") {
          poolSize = session.refreshEligibility();
          const hasFilters = Boolean(saved && (saved.yearFrom != null || saved.yearTo != null || saved.animeType || saved.difficultyMin != null
            || saved.difficultyMax != null || saved.songType || saved.watchStatus || saved.customListId));
          if (!poolSize && nextListId) {
            const selectedList = personalLibraryStore && personalLibraryStore.getListsResult().data.lists.find(item => String(item.id) === String(nextListId));
            localError = selectedList && selectedList.animeIds && selectedList.animeIds.length
              ? "所選清單含未標記 AMQ／EMQ 來源的舊成員，為避免 ID 撞號不會自動納入出題池；請在曲庫中重新加入作品。"
              : "目前清單／篩選條件沒有符合資格的可播放曲目。";
          } else if (!poolSize && hasFilters) localError = "目前出題篩選沒有符合資格且具備音源的曲目；可清除部分篩選或切換模式。";
          else if (poolSize && (localError.includes("沒有符合資格") || localError.includes("清單") || localError.includes("篩選條件"))) localError = "";
        }
        render();
      });
      [elements.target, elements.count, elements.clipSeconds, elements.partial, elements.autoPlay, elements.randomSample, elements.chineseTitlesEnabled,
        elements.clipStartSeconds, elements.autoNextDelaySeconds, elements.yearFrom, elements.yearTo, elements.includeUnknownYear, elements.animeType, elements.difficultyMin, elements.difficultyMax, elements.songType, elements.watchStatus].forEach(element => {
        listen(element, "change", saveAppSettings);
      });
    }
    if (personalLibraryStore && typeof personalLibraryStore.subscribe === "function") {
      unsubscribePersonalLibrary = personalLibraryStore.subscribe((status, source, detail) => {
        if (session && typeof session.refreshEligibility === "function" && (!detail || detail.scope === "lists" || detail.scope === "watchlist" || detail.scope === "all")) {
          poolSize = session.refreshEligibility();
          const listId = appSettingsStore && appSettingsStore.getSettings ? appSettingsStore.getSettings().customListId || "" : "";
          localError = poolSize ? "" : listId
            ? "所選自訂清單沒有可播放的來源明確作品；舊版未標記來源的成員不會自動匹配。"
            : "此模式沒有同時具備作品、歌手與音訊候選的可播放曲目。";
          render();
        }
      });
    }
    setupAnswerSuggestions();
    listen(elements.form, "submit", submitForm);
    [elements.singleAnswer, elements.animeAnswer, elements.artistAnswer, elements.titleAnswer].forEach(input => listen(input, "input", () => { if (answerInputsHaveText(session && session.getState())) localError = ""; render(); }));
    listen(elements.target, "change", render);
    listen(elements.start, "click", () => {
      if (srsModeActive) {
        focusSongIds = null; focusSongQueue = null; srsModeActive = false; ratingDoneKey = null; srsSkippedIds.clear();
        const catalog = runtime && runtime.catalogSnapshot();
        if (catalog) setupSession(catalog, store.getState().mode);
      }
      if (!session) return;
      roundToken++;
      localError = "";
      try {
        const result = session.startRound({
          target: elements.target.value,
          questionCount: Number(elements.count.value),
          clipSeconds: Number(elements.clipSeconds.value),
          acceptPartial: elements.partial.checked,
          autoPlay: elements.autoPlay.checked,
          randomSample: elements.randomSample ? elements.randomSample.checked : false,
          clipStartSeconds: elements.clipStartSeconds ? Number(elements.clipStartSeconds.value) : 0,
          autoNextDelaySeconds: elements.autoNextDelaySeconds ? Number(elements.autoNextDelaySeconds.value) : 0,
          instantSeconds: 5,
          keepHigher: true
        });
        if (!result.accepted) localError = result.reason === "empty-pool" ? "沒有可播放曲目。" : "目前回合尚未結束。";
      } catch (error) { localError = global.AMQCore.errors.normalize(error, { code: "QUIZ_ROUND_START_FAILED", category: "state", message: "無法開始回合" }).message; }
      render();
    });
    listen(elements.play, "click", () => { if (session) { localError = ""; session.resumeAudio(); render(); } });
    listen(elements.pause, "click", () => { if (session) { localError = ""; session.pause(); render(); } });
    listen(elements.reveal, "click", () => {
      if (!session) return;
      const before = session.getState(); localError = ""; const result = session.reveal();
      if (srsModeActive && result.accepted && result.state.result && result.state.result.kind === "revealed" && result.state.result.elapsedSeconds === null && before.question) srsSkippedIds.add(String(before.question.id));
      render();
    });
    listen(elements.skip, "click", () => {
      if (!session) return;
      const before = session.getState(); localError = ""; const result = session.skip();
      if (srsModeActive && result.accepted && result.state.result && result.state.result.kind === "unplayed-skip" && before.question) srsSkippedIds.add(String(before.question.id));
      render();
    });
    listen(elements.next, "click", () => {
      if (!session) return;
      localError = ""; const result = session.nextQuestion();
      if (!result.accepted && result.reason === "pool-exhausted") {
        if (srsModeActive) continueSrsSession(); else localError = "可播放曲目已全部抽過。";
      } else if (!result.accepted && result.reason === "round-complete" && srsModeActive) continueSrsSession();
      render();
    });
    listen(elements.end, "click", () => {
      if (!session) return;
      localError = "";
      if (srsModeActive) endSrsSession("已結束本次間隔複習；未評級卡片保留原排程。");
      else { session.endRound(); render(); }
    });
    listen(elements.blacklistToggle, "click", () => {
      const state = session && session.getState();
      if (!blacklistStore || !state || !state.question || state.question.source !== "AMQ") return;
      const result = blacklistStore.toggle(state.question.id);
      if (!result.ok) localError = "歌曲黑名單儲存失敗；原本狀態未變更。";
      else { localError = ""; srsMessage = result.blocked ? "已將這首 AMQ 歌曲加入黑名單；後續抽題與間隔複習會略過它。" : "已解除這首 AMQ 歌曲的黑名單。"; }
      render();
    });
    listen(elements.workBlacklistToggle, "click", () => {
      const state = session && session.getState();
      if (!blacklistStore || !state || !state.question || state.question.source !== "AMQ" || state.question.animeId == null) return;
      const result = blacklistStore.toggleWork(state.question.animeId);
      if (!result.ok) localError = "作品黑名單儲存失敗；原本狀態未變更。";
      else { localError = ""; srsMessage = result.blocked ? "已排除此作品的所有 AMQ 歌曲。" : "已解除作品黑名單。"; }
      render();
    });
    listen(elements.srsToggle, "click", () => {
      const state = session && session.getState();
      const activeSrsStore = state && state.question ? srsStoreFor(state.question.source) : null;
      if (!appSettingsStore || appSettingsStore.getSettings().srsEnabled !== true || !activeSrsStore || !state || !state.question || !["AMQ", "EMQ"].includes(state.question.source)) return;
      const result = activeSrsStore.toggle(state.question);
      if (!result.ok) srsMessage = result.reason === "missing" ? `這首歌不在可播放 ${state.question.source} 曲庫中。` : "間隔複習卡片未能保存。";
      else if (result.action === "suspended") { ratingDoneKey = currentSrsRatingKey(state); srsMessage = "已暫停這張間隔複習卡。"; }
      else if (result.action === "resumed" || result.resumed) { ratingDoneKey = null; srsMessage = "已恢復這張間隔複習卡。"; }
      else if (result.created) { ratingDoneKey = null; srsMessage = "已加入間隔複習。答題後請選擇回想難度。"; }
      else srsMessage = "間隔複習卡片已更新。";
      render();
    });
    listen(elements.srsStart, "click", startSrsSession);
    listen(elements.srsEnabled, "change", () => {
      if (!appSettingsStore || !elements.srsEnabled) return;
      const result = appSettingsStore.set({ srsEnabled: elements.srsEnabled.checked });
      if (!result.ok) { elements.srsEnabled.checked = appSettingsStore.getSettings().srsEnabled === true; srsMessage = "全域 SRS 設定未能保存；設定維持原值。"; }
      else { srsMessage = result.settings.srsEnabled ? "全域 SRS 已啟用；一般練習的作品標題答題會自動評級。" : "全域 SRS 已關閉；既有排程保留。"; ratingDoneKey = null; }
      render();
    });
    listen(elements.srsDailyNew, "change", () => {
      const activeSrsStore = srsStoreFor(store.getState().mode);
      if (!activeSrsStore || !elements.srsDailyNew) return;
      srsMessage = activeSrsStore.setSetting("dailyNew", Number(elements.srsDailyNew.value)) ? "每日新卡上限已保存。" : "每日新卡上限未能保存。";
      render();
    });
    listen(elements.srsBatchSize, "change", () => {
      const activeSrsStore = srsStoreFor(store.getState().mode);
      if (!activeSrsStore || !elements.srsBatchSize) return;
      srsMessage = activeSrsStore.setSetting("batchSize", Number(elements.srsBatchSize.value)) ? "每次複習上限已保存。" : "每次複習上限未能保存。";
      render();
    });
    elements.srsGradeButtons.forEach(button => listen(button, "click", () => rateCurrentSrs(Number(button.getAttribute("data-srs-grade")))));


    const unsubscribeStore = store.subscribe(syncAppState);
    if (historyStore && typeof historyStore.subscribe === "function") unsubscribeHistory = historyStore.subscribe(render);
    let unsubscribeSrsStores = [];
    function clearSrsStoreSubscriptions() {
      unsubscribeSrsStores.forEach(unsubscribe => { try { unsubscribe(); } catch (_) {} });
      unsubscribeSrsStores = [];
    }
    function subscribeSrsStores() {
      unsubscribeSrsStores = [srsStore, emqSrsStore].filter(item => item && typeof item.subscribe === "function").map(item => item.subscribe(render));
    }
    function disposeRemoteSrsStores() {
      if (!remoteSrsStores) return;
      for (const remoteStore of [remoteSrsStores.AMQ, remoteSrsStores.EMQ]) {
        if (remoteStore && typeof remoteStore.dispose === "function") { try { remoteStore.dispose(); } catch (_) {} }
      }
      remoteSrsStores = null;
    }
    function configureSrsStores(configuration) {
      if (disposed) return false;
      clearSrsStoreSubscriptions();
      disposeRemoteSrsStores();
      if (configuration === null || configuration === undefined) {
        srsStore = localSrsStore;
        emqSrsStore = localEmqSrsStore;
      } else if (configuration && configuration.mode === "disabled") {
        remoteSrsStores = {
          AMQ: createSrsStoreFor("AMQ", createIsolatedEmptyStorage("AMQ")),
          EMQ: createSrsStoreFor("EMQ", createIsolatedEmptyStorage("EMQ"))
        };
        srsStore = remoteSrsStores.AMQ;
        emqSrsStore = remoteSrsStores.EMQ;
      } else if (configuration && typeof configuration.storageFor === "function") {
        remoteSrsStores = {
          AMQ: createSrsStoreFor("AMQ", configuration.storageFor("AMQ")),
          EMQ: createSrsStoreFor("EMQ", configuration.storageFor("EMQ"))
        };
        srsStore = remoteSrsStores.AMQ;
        emqSrsStore = remoteSrsStores.EMQ;
      } else throw new TypeError("SRS configuration must be a remote bridge, disabled mode, or null");
      subscribeSrsStores();
      if (session && typeof session.refreshEligibility === "function") session.refreshEligibility();
      ratingDoneKey = null;
      render();
      return true;
    }
    subscribeSrsStores();
    if (blacklistStore && typeof blacklistStore.subscribe === "function") unsubscribeBlacklist = blacklistStore.subscribe(() => {
      if (session && typeof session.refreshEligibility === "function") session.refreshEligibility();
      render();
    });
    syncAppState(store.getState());
    return Object.freeze({
      render,
      getSession: () => session,
      getState: () => session ? session.getState() : Object.freeze({ phase: "idle", poolSize }),
      configureSrsStores,
      dispose() {
        if (disposed) return false;
        disposed = true;
        const cleanupErrors = [];
        const attempt = cleanup => {
          try { cleanup(); } catch (error) { cleanupErrors.push(error); }
        };
        attempt(unsubscribeStore);
        if (unsubscribeAppSettings) { const cleanup = unsubscribeAppSettings; unsubscribeAppSettings = null; attempt(cleanup); }
        if (unsubscribePersonalLibrary) { const cleanup = unsubscribePersonalLibrary; unsubscribePersonalLibrary = null; attempt(cleanup); }
        if (unsubscribeHistory) { const cleanup = unsubscribeHistory; unsubscribeHistory = null; attempt(cleanup); }
        attempt(clearSrsStoreSubscriptions);
        attempt(disposeRemoteSrsStores);
        if (unsubscribeBlacklist) { const cleanup = unsubscribeBlacklist; unsubscribeBlacklist = null; attempt(cleanup); }
        suggestionControllers.splice(0).forEach(controller => attempt(() => controller.dispose()));
        if (chineseTitleAbortController) { const controller = chineseTitleAbortController; chineseTitleAbortController = null; attempt(() => controller.abort()); }
        if (chineseTitleProvider) { const provider = chineseTitleProvider; chineseTitleProvider = null; attempt(() => provider.dispose()); }
        cleanupErrors.push(...disposeSession());
        if (ownsFamiliarityStore && familiarityStore && typeof familiarityStore.dispose === "function") attempt(() => familiarityStore.dispose());
        if (ownsHistoryStore && historyStore && typeof historyStore.dispose === "function") attempt(() => historyStore.dispose());
        if (ownsAppSettingsStore && appSettingsStore && typeof appSettingsStore.dispose === "function") attempt(() => appSettingsStore.dispose());
        if (ownsPersonalLibraryStore && personalLibraryStore && typeof personalLibraryStore.dispose === "function") attempt(() => personalLibraryStore.dispose());
        if (ownsLocalSrsStore && localSrsStore && typeof localSrsStore.dispose === "function") attempt(() => localSrsStore.dispose());
        if (ownsLocalEmqSrsStore && localEmqSrsStore && typeof localEmqSrsStore.dispose === "function") attempt(() => localEmqSrsStore.dispose());
        if (ownsBlacklistStore && blacklistStore && typeof blacklistStore.dispose === "function") attempt(() => blacklistStore.dispose());
        removers.splice(0).forEach(remove => attempt(remove));
        if (cleanupErrors.length) throw new AggregateError(cleanupErrors, "Quiz Panel disposal completed with cleanup errors");
        return true;
      },
      get isDisposed() { return disposed; }
    });
  }

  global.AMQQuizPanel = Object.freeze({ mount });
})(window);
