/* Minimal authenticated multiplayer room UI; server snapshots remain authoritative. */
(function (global) {
  "use strict";

  function mount(options) {
    const settings = options && typeof options === "object" ? options : {};
    const root = document.getElementById("multiplayer-panel");
    if (!root) throw new Error("multiplayer panel root is missing");
    const clientApi = global.AMQMultiplayer && global.AMQMultiplayer.httpClient;
    const sessionApi = global.AMQMultiplayer && global.AMQMultiplayer.roomSession;
    if (!clientApi || !sessionApi) throw new Error("multiplayer client/session modules are missing");
    const el = id => document.getElementById(id);
    const ui = {
      status: el("multiplayer-status"), message: el("multiplayer-message"), error: el("multiplayer-error"),
      source: el("multiplayer-source"), capacity: el("multiplayer-capacity"), create: el("multiplayer-create"),
      rooms: el("multiplayer-rooms"), refresh: el("multiplayer-refresh"), roomCode: el("multiplayer-room-code"), join: el("multiplayer-join"),
      roomSearch: el("multiplayer-room-search"), roomCount: el("multiplayer-room-count"), showProgress: el("multiplayer-show-progress"), sourceTabs: Array.from(root.querySelectorAll("[data-room-source]")),
      roomDetails: el("multiplayer-room-details"), code: el("multiplayer-current-code"), phase: el("multiplayer-phase"), revision: el("multiplayer-revision"),
      players: el("multiplayer-players"), ready: el("multiplayer-ready"), start: el("multiplayer-start"), leave: el("multiplayer-leave"), close: el("multiplayer-close"),
      round: el("multiplayer-round"), roundStatus: el("multiplayer-round-status"), play: el("multiplayer-play"), stop: el("multiplayer-stop"), audioStatus: el("multiplayer-audio-status"), answerForm: el("multiplayer-answer-form"), answer: el("multiplayer-answer"), submit: el("multiplayer-submit")
    };
    const client = clientApi.createHttpClient();
    let session = sessionApi.createRoomSession({ client });
    const removers = [];
    let disposed = false;
    let busy = false;
    let unsubscribe = null;
    let lease = null;
    let playbackRevoked = false;
    let playerId = null;
    let current = session.getState();
    let commandError = null;
    let lastRenderedConnectionStatus = current.status;
    let roomFilterSource = "ALL";
    let roomFilterQuery = "";
    let roomFilterProgress = false;
    const audioService = settings.audioService || null;
    const clockApi = global.AMQEngine && global.AMQEngine.quizClock;
    let activeRound = null;
    let clockAnchorSnapshot = null;
    let serverTimeAnchor = null;
    let clientTimeAnchor = null;
    let lastClockRoundId = null;
    let playGeneration = 0;
    let unsubscribeAudio = null;
    const clock = clockApi && typeof clockApi.createQuizClock === "function" ? clockApi.createQuizClock({
      now: () => serverTimeAnchor === null ? Date.now() : serverTimeAnchor + (Date.now() - clientTimeAnchor),
      tickMs: 250,
      onTick: seconds => { if (activeRound) renderRoundStatus(activeRound, seconds); },
      onTimeout: () => {
        stopMultiplayerAudio("回合期限已到，等待伺服器結算。");
        if (activeRound) renderRoundStatus(activeRound, 0);
      }
    }) : null;

    function listen(node, type, handler) {
      if (!node) return;
      node.addEventListener(type, handler);
      removers.push(() => node.removeEventListener(type, handler));
    }
    function setMessage(value) { if (ui.message) ui.message.textContent = value || ""; }
    function setError(value) {
      if (!ui.error) return;
      const message = value == null ? "" : String(value);
      ui.error.textContent = message;
      ui.error.hidden = !message;
      ui.error.setAttribute("data-error-state", message ? "visible" : "none");
      const code = (message.match(/\b[A-Z][A-Z0-9_]{3,}\b/) || [])[0] || "";
      ui.error.setAttribute("data-error-code", code);
    }
    function setAudioStatus(message, state) {
      if (!ui.audioStatus) return;
      ui.audioStatus.textContent = message || "";
      ui.audioStatus.setAttribute("data-audio-state", state || "waiting");
    }
    function stateOf(value) { return value && value.state && typeof value.state === "object" ? value.state : null; }
    function playerRows(state) {
      if (!ui.players) return;
      ui.players.textContent = "";
      (state && Array.isArray(state.players) ? state.players : []).forEach(player => {
        const row = document.createElement("li");
        row.className = "multiplayer-player-item";
        row.dataset.skinComponent = "multiplayer.member-item";
        row.dataset.readyState = player.ready ? "ready" : "not-ready";
        const name = document.createElement("span");
        name.className = "multiplayer-player-name";
        name.textContent = `${player.displayName}（${player.role === "host" ? "房主" : "玩家"}）`;
        const ready = document.createElement("span");
        ready.className = "multiplayer-player-ready-state";
        ready.dataset.skinComponent = "multiplayer.ready-state";
        ready.dataset.ready = String(Boolean(player.ready));
        ready.setAttribute("aria-label", player.ready ? "已準備" : "未準備");
        ready.textContent = player.ready ? "✓ 已準備" : "○ 未準備";
        row.append(name, ready);
        ui.players.appendChild(row);
      });
    }
    function renderRoundStatus(round, secondsLeft) {
      if (!ui.roundStatus || !round) return;
      const answers = Array.isArray(round.answers) ? round.answers : [];
      const submitted = answers.length;
      const hasSubmitted = Boolean(playerId && answers.some(answer => String(answer.playerId) === String(playerId)));
      const expired = Number.isFinite(secondsLeft) && secondsLeft <= 0;
      const state = expired ? "expired" : hasSubmitted ? "submitted" : round.status === "active" ? "active" : String(round.status || "unknown");
      const left = Number.isFinite(secondsLeft) && secondsLeft > 0 ? `剩餘 ${secondsLeft} 秒；` : "";
      const phaseMessage = expired ? "期限已到，等待伺服器結算；" : hasSubmitted ? "你已提交答案，等待伺服器評估；" : "請提交作品標題答案；";
      ui.roundStatus.setAttribute("data-round-state", state);
      ui.roundStatus.textContent = `回合 ${round.id}；${expired ? phaseMessage : `${left}${phaseMessage}`}伺服器期限 ${new Date(round.deadlineAt).toLocaleTimeString()}；已提交答案 ${submitted} 人。`;
    }
    function stopMultiplayerAudio(message) {
      playGeneration += 1;
      if (audioService && typeof audioService.cancel === "function") audioService.cancel();
      if (ui.audioStatus && message) {
        const state = /期限已到/.test(message) ? "expired" : /取消/.test(message) ? "cancelled"
          : /尚未播放|等待伺服器/.test(message) ? "waiting" : /失去播放權/.test(message) ? "unavailable" : "stopped";
        setAudioStatus(message, state);
      }
      if (ui.stop) ui.stop.disabled = true;
    }
    if (audioService && typeof audioService.subscribe === "function") {
      unsubscribeAudio = audioService.subscribe(audioState => {
        if (disposed || !activeRound || !lease || lease.isActive === false || playbackRevoked || !ui.audioStatus) return;
        if (audioState.status === "loading") setAudioStatus(`正在載入音源候選 ${audioState.candidateIndex || "…"}。`, "loading");
        else if (audioState.status === "playing") setAudioStatus(`正在播放音源候選 ${audioState.candidateIndex || "…"}。`, "playing");
        else if (audioState.status === "paused") setAudioStatus("多人題目音訊已暫停。", "paused");
        else if (audioState.status === "failed") setAudioStatus(`音訊播放失敗（${audioState.error || "AUDIO_FAILED"}）；已嘗試 ${(audioState.failures || []).length} 個候選。`, "failed");
        else if (audioState.status === "ended") setAudioStatus("題目音訊播放完畢。", "ended");
      });
    }
    function syncRoundLifecycle(state, snapshot) {
      const round = state && state.phase === "round" && state.currentRound ? state.currentRound : null;
      const active = Boolean(round && round.status === "active");
      if (snapshot && snapshot !== clockAnchorSnapshot && Number.isFinite(snapshot.serverNow)) {
        clockAnchorSnapshot = snapshot;
        serverTimeAnchor = snapshot.serverNow;
        clientTimeAnchor = Date.now();
      }
      if (!active) {
        if (activeRound || lastClockRoundId) stopMultiplayerAudio("目前沒有進行中的多人音訊。");
        if (clock) clock.stop();
        activeRound = null;
        lastClockRoundId = null;
        if (ui.play) ui.play.disabled = true;
        if (ui.stop) ui.stop.disabled = true;
        return;
      }
      const isNewRound = lastClockRoundId !== round.id;
      activeRound = round;
      if (isNewRound) {
        stopMultiplayerAudio("新回合已開始，尚未播放題目音訊。");
        lastClockRoundId = round.id;
        if (clock) {
          const estimatedServerNow = serverTimeAnchor === null ? Date.now() : serverTimeAnchor + (Date.now() - clientTimeAnchor);
          const remainingMs = Math.max(0, Number(round.deadlineAt) - estimatedServerNow);
          if (remainingMs >= 1000) clock.start(Math.min(120, Math.max(1, remainingMs / 1000)));
          else { renderRoundStatus(round, 0); }
        }
      } else if (clock && !clock.getState().running && !clock.getState().paused) {
        const estimatedServerNow = serverTimeAnchor === null ? Date.now() : serverTimeAnchor + (Date.now() - clientTimeAnchor);
        const remainingMs = Math.max(0, Number(round.deadlineAt) - estimatedServerNow);
        if (remainingMs >= 1000) clock.start(Math.min(120, Math.max(1, remainingMs / 1000)));
      }
      if (clock && clock.getState().running) renderRoundStatus(round, clock.getRemainingSeconds());
      else renderRoundStatus(round, Math.ceil(Math.max(0, Number(round.deadlineAt) - (serverTimeAnchor === null ? Date.now() : serverTimeAnchor + (Date.now() - clientTimeAnchor))) / 1000));
      const projection = snapshot && snapshot.questionProjection;
      const safeProjection = projection && projection.roundId === round.id && projection.questionId === round.questionId
        && Array.isArray(projection.audioCandidates) && projection.audioCandidates.length > 0
        && projection.audioCandidates.every(candidate => candidate && typeof candidate.url === "string" && /^https?:\/\//i.test(candidate.url) && (candidate.kind === undefined || candidate.kind === "audio"));
      const hasLease = Boolean(lease && lease.isActive !== false && !playbackRevoked);
      if (ui.play) ui.play.disabled = !audioService || !safeProjection || !hasLease;
      if (ui.stop) ui.stop.disabled = !audioService || !hasLease;
      if (!safeProjection && ui.audioStatus) setAudioStatus("等待伺服器提供安全音源投影。", "waiting");
    }
    function syncPlaybackLease(state) {
      const coordinator = settings.playbackCoordinator;
      const active = Boolean(state && state.phase === "round" && state.currentRound && state.currentRound.status === "active");
      if (!coordinator || typeof coordinator.acquire !== "function") return;
      if (active && !lease && !playbackRevoked) {
        try {
          lease = coordinator.acquire("multiplayer-room", { onRevoke: () => {
            lease = null;
            playbackRevoked = true;
            stopMultiplayerAudio("多人回合已失去播放權；其他模式已接管音訊。");
            if (ui.play) ui.play.disabled = true;
            if (ui.stop) ui.stop.disabled = true;
            if (!disposed) setMessage("多人回合已失去播放權；其他模式已接管音訊。 ");
          } });
        } catch (error) { setError(error.message); }
      } else if (!active) {
        if (lease) lease.release();
        lease = null;
        playbackRevoked = false;
      }
    }
    function render(view) {
      current = view;
      if (lastRenderedConnectionStatus === "offline" && view.status === "connected" && commandError && commandError.code === "MULTIPLAYER_NETWORK_ERROR") commandError = null;
      lastRenderedConnectionStatus = view.status;
      const state = stateOf(view.snapshot);
      const isHost = Boolean(state && playerId && state.hostId === playerId);
      const self = state && playerId ? state.players.find(player => player.id === playerId) : null;
      root.setAttribute("aria-busy", String(busy));
      root.setAttribute("data-room-connection", view.status || "unknown");
      if (ui.status) {
        ui.status.textContent = busy ? "操作處理中" : view.status === "connected" ? "房間已連線" : view.status === "offline" ? "連線中斷，正在重試" : view.roomId ? "房間連線中" : "未加入房間";
        ui.status.setAttribute("data-connection-state", view.status || "unknown");
      }
      if (ui.roomDetails) ui.roomDetails.hidden = !view.roomId;
      if (ui.code) ui.code.textContent = view.roomId || "尚未加入";
      if (ui.phase) {
        ui.phase.textContent = state ? ({ lobby: "等待玩家", round: "回合進行中", closed: "房間已關閉" }[state.phase] || state.phase) : "等待房間快照";
        ui.phase.setAttribute("data-room-phase", state ? state.phase : "unknown");
      }
      if (ui.revision) ui.revision.textContent = state ? String(state.revision) : "—";
      playerRows(state);
      if (ui.ready) ui.ready.disabled = busy || !state || !self || state.phase !== "lobby";
      if (ui.start) ui.start.disabled = busy || !state || !isHost || state.phase !== "lobby";
      if (ui.close) ui.close.disabled = busy || !state || !isHost || state.phase !== "lobby";
      if (ui.ready) ui.ready.textContent = self && self.ready ? "取消準備" : "準備完成";
      if (ui.leave) ui.leave.disabled = busy || !view.roomId;
      if (ui.round) ui.round.hidden = !(state && state.phase === "round" && state.currentRound);
      if (ui.roundStatus && !(state && state.currentRound)) ui.roundStatus.textContent = "目前沒有進行中的回合。";
      if (ui.answerForm) ui.answerForm.hidden = !(state && state.phase === "round" && state.currentRound && state.currentRound.status === "active");
      if (ui.submit) ui.submit.disabled = busy || !(state && state.phase === "round" && state.currentRound && state.currentRound.status === "active");
      syncPlaybackLease(state);
      syncRoundLifecycle(state, view.snapshot);
      if (view.status === "offline" && view.error) setError(`房間連線暫時中斷：${view.error.message}。系統會自動重試。`);
      else if (commandError) setError(commandError.message);
      else if (view.status === "connected") setError("");
    }
    function attach(roomId, snapshot) {
      if (unsubscribe) { unsubscribe(); unsubscribe = null; }
      session.attach(roomId, snapshot || null);
      unsubscribe = session.subscribe(render);
      session.start();
      setError("");
      setMessage(`已加入房間 ${roomId}。房間狀態以伺服器快照為準。`);
    }
    async function action(operation, successMessage) {
      if (busy || disposed) return;
      const activeElement = document.activeElement;
      const restoreFocus = activeElement && typeof root.contains === "function" && root.contains(activeElement) ? activeElement : null;
      busy = true; commandError = null; setError(""); render(current);
      try {
        const result = await operation();
        commandError = null;
        if (successMessage) setMessage(successMessage);
        return result;
      } catch (error) {
        commandError = { message: `${error.message || "多人操作失敗。"}${error.code ? `（${error.code}）` : ""}`, code: error.code || "" };
        setError(commandError.message);
        return null;
      } finally {
        busy = false;
        if (!disposed) {
          render(session.getState());
          if (restoreFocus && !restoreFocus.hidden && !restoreFocus.disabled && typeof restoreFocus.focus === "function") {
            try { restoreFocus.focus({ preventScroll: true }); } catch (_) { restoreFocus.focus(); }
          } else if (restoreFocus && ui.status && typeof ui.status.focus === "function") {
            if (!ui.status.hasAttribute || !ui.status.hasAttribute("tabindex")) ui.status.setAttribute("tabindex", "-1");
            try { ui.status.focus({ preventScroll: true }); } catch (_) { ui.status.focus(); }
          }
        }
      }
    }
    function applyRoomFilters() {
      if (!ui.rooms) return;
      let visible = 0;
      Array.from(ui.rooms.options).forEach(option => {
        if (!option.value) { option.hidden = Boolean(ui.rooms.options.length > 1); return; }
        const sourceMatch = roomFilterSource === "ALL" || option.dataset.source === roomFilterSource;
        const queryMatch = !roomFilterQuery || option.textContent.toLocaleLowerCase().includes(roomFilterQuery);
        const progressMatch = !roomFilterProgress || option.dataset.phase === "round";
        option.hidden = !(sourceMatch && queryMatch && progressMatch);
        if (!option.hidden) visible += 1;
      });
      if (ui.roomCount) ui.roomCount.textContent = `${visible} 間 / ${Array.from(ui.rooms.options).filter(option => option.value).length} 間`;
      ui.sourceTabs.forEach(tab => {
        const active = tab.dataset.roomSource === roomFilterSource;
        tab.classList.toggle("is-active", active);
        tab.setAttribute("aria-pressed", String(active));
      });
      if (ui.rooms.selectedOptions && ui.rooms.selectedOptions[0] && ui.rooms.selectedOptions[0].hidden) ui.rooms.selectedIndex = -1;
    }
    async function refreshRooms() {
      return action(async () => {
        const rooms = await client.listRooms();
        if (ui.rooms) {
          ui.rooms.textContent = "";
          if (!rooms.length) {
            const empty = document.createElement("option");
            empty.value = "";
            empty.textContent = "目前沒有可加入的公開房間";
            ui.rooms.appendChild(empty);
          }
          rooms.forEach(room => {
            const option = document.createElement("option");
            option.value = room.roomId;
            option.dataset.source = String(room.source || "").toUpperCase();
            option.dataset.phase = String(room.phase || "").toLowerCase();
            option.textContent = `${room.roomId}  ·  ${room.source}  ·  ${room.playerCount}/${room.maxPlayers} 人  ·  ${room.phase === "round" ? "進行中" : "等待中"}`;
            ui.rooms.appendChild(option);
          });
          applyRoomFilters();
        }
        setMessage(`已更新公開大廳：${rooms.length} 間可加入的房間。`);
        return rooms;
      });
    }
    ui.sourceTabs.forEach(tab => listen(tab, "click", () => { roomFilterSource = tab.dataset.roomSource || "ALL"; applyRoomFilters(); }));
    listen(ui.roomSearch, "input", () => { roomFilterQuery = String(ui.roomSearch.value || "").trim().toLocaleLowerCase(); applyRoomFilters(); });
    listen(ui.showProgress, "change", () => { roomFilterProgress = Boolean(ui.showProgress.checked); applyRoomFilters(); });
    listen(ui.refresh, "click", () => { void refreshRooms(); });
    listen(ui.create, "click", () => { void action(async () => {
      const result = await client.createRoom({ source: ui.source ? ui.source.value : "AMQ", maxPlayers: ui.capacity ? Number(ui.capacity.value) : 8 });
      attach(result.roomId, result.snapshot);
      return result;
    }, "房間已建立。請將房間代碼提供給其他玩家。 "); });
    listen(ui.join, "click", () => { void action(async () => {
      const roomId = ui.roomCode && ui.roomCode.value.trim() || ui.rooms && ui.rooms.value;
      if (!roomId) throw new Error("請輸入房間代碼或先選擇大廳房間。");
      const result = await client.joinRoom(roomId, {});
      attach(roomId, result.snapshot);
      return result;
    }, "已加入房間。 "); });
    listen(ui.ready, "click", () => { const state = stateOf(current.snapshot); const self = state && playerId ? state.players.find(player => player.id === playerId) : null; void action(() => session.setReady(!(self && self.ready)), "準備狀態已更新。 "); });
    listen(ui.start, "click", () => { void action(() => session.startRound(), "已要求伺服器開始回合。 "); });
    listen(ui.close, "click", () => { void action(() => session.dispatch("room.close", {}), "房間已關閉。 "); });
    listen(ui.leave, "click", () => { void action(async () => {
      await session.leave();
      stopMultiplayerAudio("已離開房間，音訊已停止。");
      if (clock) clock.stop();
      session.stop();
      if (unsubscribe) { unsubscribe(); unsubscribe = null; }
      if (lease) { lease.release(); lease = null; }
      playbackRevoked = false;
      session.dispose();
      session = sessionApi.createRoomSession({ client });
      current = session.getState();
      setMessage("已離開房間。 ");
      render(current);
      return true;
    }, "已離開房間。 "); });
    listen(ui.play, "click", () => {
      const state = stateOf(current.snapshot);
      const round = state && state.currentRound;
      const projection = current.snapshot && current.snapshot.questionProjection;
      if (disposed || !audioService || !round || round.status !== "active" || !lease || lease.isActive === false || playbackRevoked) {
        setError("目前沒有可用的多人播放權。請確認回合仍在進行，且沒有其他模式接管音訊。"); return;
      }
      if (!projection || projection.roundId !== round.id || projection.questionId !== round.questionId || !Array.isArray(projection.audioCandidates)) {
        setError("伺服器尚未提供此回合的安全音源投影。"); return;
      }
      const candidates = projection.audioCandidates.filter(candidate => candidate && typeof candidate.url === "string" && /^https?:\/\//i.test(candidate.url)
        && (candidate.kind === undefined || candidate.kind === "audio"));
      if (!candidates.length) { setError("此題沒有可用的安全音源候選。"); return; }
      const generation = ++playGeneration;
      setError("");
      if (ui.audioStatus) setAudioStatus("正在嘗試播放伺服器提供的音源候選…", "loading");
      if (ui.stop) ui.stop.disabled = false;
      Promise.resolve(audioService.play(candidates, { autoPlay: true, timeoutMs: 12000 })).then(result => {
        if (disposed || generation !== playGeneration || !activeRound || activeRound.id !== round.id) return;
        if (result && result.status === "failed") {
          const failures = Array.isArray(result.failures) ? result.failures.length : 0;
          if (ui.audioStatus) setAudioStatus(`音訊播放失敗（${result.error || "AUDIO_FAILED"}）；已嘗試 ${failures} 個候選。`, "failed");
        } else if (result && result.status === "cancelled") {
          if (ui.audioStatus) setAudioStatus("音訊播放已取消。", "cancelled");
        } else if (result && result.status === "ended") {
          if (ui.audioStatus) setAudioStatus("題目音訊播放完畢。", "ended");
        }
        if (ui.stop) ui.stop.disabled = true;
      }).catch(error => {
        if (!disposed && generation === playGeneration && ui.audioStatus) setAudioStatus(`音訊播放失敗：${error.message || "未知錯誤"}`, "failed");
        if (ui.stop) ui.stop.disabled = true;
      });
    });
    listen(ui.stop, "click", () => {
      if (!lease || lease.isActive === false || playbackRevoked) return;
      stopMultiplayerAudio("已停止多人題目音訊。");
    });
    listen(ui.answerForm, "submit", event => {
      if (event && typeof event.preventDefault === "function") event.preventDefault();
      const answer = ui.answer ? ui.answer.value.trim() : "";
      if (!answer) { setError("請輸入答案。 "); return; }
      void action(() => session.submitAnswer(answer), "答案已送交伺服器評估。 ").then(result => { if (result && ui.answer) ui.answer.value = ""; });
    });
    function loadIdentity() {
      return global.fetch("/api/auth/me", { credentials: "same-origin", headers: { Accept: "application/json" } })
        .then(response => response.ok ? response.json() : null)
        .then(payload => { playerId = payload && payload.user && payload.user.id != null ? String(payload.user.id) : null; render(session.getState()); })
        .catch(() => { playerId = null; });
    }
    render(current);
    void loadIdentity();
    void refreshRooms();
    return Object.freeze({
      dispose() {
        if (disposed) return;
        disposed = true;
        removers.splice(0).forEach(remove => { try { remove(); } catch (_) {} });
        if (unsubscribe) unsubscribe();
        if (unsubscribeAudio) { unsubscribeAudio(); unsubscribeAudio = null; }
        stopMultiplayerAudio("多人面板已釋放。");
        if (clock) clock.dispose();
        if (lease) lease.release();
        lease = null;
        session.dispose();
      },
      refreshRooms,
      getState() { return current; },
      getSession() { return session; }
    });
  }
  global.AMQUI = global.AMQUI || {};
  global.AMQUI.multiplayerPanel = Object.freeze({ mount });
})(typeof window !== "undefined" ? window : globalThis);
