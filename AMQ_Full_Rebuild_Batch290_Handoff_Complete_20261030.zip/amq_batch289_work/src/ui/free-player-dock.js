/* Independent free-play controls. It never creates or mutates a QuizSession. */
(function (global) {
  "use strict";
  const PLAY_THRESHOLD_SECONDS = 5;
  const TICK_MS = 250;
  function createFreePlayerDock(options) {
    const deps = options && typeof options === "object" ? options : {};
    const elements = deps.elements || {};
    const runtime = deps.runtime || null;
    const stateStore = deps.stateStore || (global.AMQCore && global.AMQCore.state);
    const audioApi = deps.audioApi || (global.AMQAudio && global.AMQAudio.audioService);
    const historyApi = deps.historyApi || (global.AMQPersistence && global.AMQPersistence.playbackHistoryStore);
    if (!runtime || !stateStore || (!audioApi && !deps.audioService) || (!historyApi && !deps.playbackHistoryStore)) throw new TypeError("free player requires runtime, state, audio and playback history APIs");
    const audio = deps.audioService || audioApi.createAudioService();
    const ownsAudio = !deps.audioService;
    let history;
    try {
      history = deps.playbackHistoryStore || historyApi.createPlaybackHistoryStore();
    } catch (error) {
      // Audio is already acquired but no dock disposer exists yet. Roll it back
      // synchronously if the second dependency cannot be created.
      if (ownsAudio && audio && typeof audio.dispose === "function") audio.dispose();
      throw error;
    }
    const ownsHistory = !deps.playbackHistoryStore;
    const scheduleTick = typeof deps.setInterval === "function" ? deps.setInterval : setInterval;
    const unscheduleTick = typeof deps.clearInterval === "function" ? deps.clearInterval : clearInterval;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    let disposed = false, catalog = null, records = [], visibleRecords = [], currentRecord = null;
    let sequence = null, playedSeconds = 0, playingSince = null, tick = null, lastHistorySequence = null;
    let queue = [], queueIndex = -1, selectedQueueKey = "", queueHistory = [], queueHistoryCursor = -1;
    let playMode = "sequential", volume = 1, muted = false, collapsed = deps.startCollapsed === true, suppressQueueHistoryOnce = false;
    let lastMode = stateStore.getState().mode;
    const dockInstanceId = typeof deps.createHistoryId === "function" ? String(deps.createHistoryId()) : `dock-${now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    let historyEntryCounter = 0, pendingHistorySequence = null, pendingHistoryId = null;
    let status = "等待曲庫載入", error = "";
    const removers = [];
    let dockLayoutObserver = null;
    function syncDockLayout() {
      const dock = elements.dock;
      const root = global.document && global.document.documentElement;
      if (!dock || !root || !root.style || typeof dock.getBoundingClientRect !== "function") return;
      const height = Math.max(0, Math.ceil(dock.getBoundingClientRect().height));
      root.style.setProperty("--amq-player-dock-height", `${height}px`);
    }
    if (elements.dock && global.document && global.document.documentElement) {
      syncDockLayout();
      if (typeof global.ResizeObserver === "function") {
        dockLayoutObserver = new global.ResizeObserver(syncDockLayout);
        dockLayoutObserver.observe(elements.dock);
        removers.push(() => dockLayoutObserver && dockLayoutObserver.disconnect());
      } else if (typeof global.addEventListener === "function") {
        global.addEventListener("resize", syncDockLayout);
        removers.push(() => global.removeEventListener("resize", syncDockLayout));
      }
      removers.push(() => global.document.documentElement.style.removeProperty("--amq-player-dock-height"));
    }
    function listen(element, event, handler) { if (!element || typeof element.addEventListener !== "function") return; element.addEventListener(event, handler); removers.push(() => element.removeEventListener(event, handler)); }
    function setText(element, value) { if (element) element.textContent = String(value ?? ""); }
    function setDisabled(element, value) { if (element) element.disabled = Boolean(value); }
    function keyOf(record) {
      if (!record) return "";
      const identity = global.AMQData && global.AMQData.identity;
      return identity && typeof identity.createIdentity === "function"
        ? identity.createIdentity(record.source, record.id) : `${record.source}:${typeof record.id}:${String(record.id)}`;
    }
    function formatRecord(record) { return `${record.source} · ${record.title || "未命名歌曲"} · ${record.artist || "歌手未標示"} · ${record.animeTitle || "未標示作品"}`; }
    function getSelectedRecord() { if (!elements.results) return null; return visibleRecords.find(record => keyOf(record) === elements.results.value) || visibleRecords[0] || null; }
    function renderQueue() {
      const select = elements.queue;
      if (!select || !select.ownerDocument) return;
      while (select.firstChild) select.removeChild(select.firstChild);
      if (!queue.length) {
        const option = select.ownerDocument.createElement("option"); option.value = ""; option.textContent = "佇列為空"; select.appendChild(option); setDisabled(select, true); return;
      }
      queue.forEach((record, index) => {
        const option = select.ownerDocument.createElement("option"); option.value = keyOf(record); option.textContent = `${index + 1}. ${formatRecord(record)}`;
        option.selected = selectedQueueKey ? selectedQueueKey === option.value : index === queueIndex || queueIndex < 0 && index === 0;
        select.appendChild(option);
      });
      setDisabled(select, false);
    }
    function formatTime(value) {
      if (!Number.isFinite(value) || value < 0) return "--:--";
      const seconds = Math.floor(value);
      return `${Math.floor(seconds / 60).toString().padStart(2, "0")}:${(seconds % 60).toString().padStart(2, "0")}`;
    }
    function renderProgress() {
      const metrics = typeof audio.getPlaybackMetrics === "function" ? audio.getPlaybackMetrics() : {};
      const current = metrics.available === true && typeof metrics.currentTime === "number" && Number.isFinite(metrics.currentTime) ? metrics.currentTime : NaN;
      const duration = metrics.available === true && typeof metrics.duration === "number" && Number.isFinite(metrics.duration) ? metrics.duration : NaN;
      const progressRatio = Number.isFinite(current) && Number.isFinite(duration) && duration > 0
        ? Math.max(0, Math.min(1, current / duration)) : 0;
      if (elements.progress) {
        elements.progress.disabled = !metrics.available || !Number.isFinite(duration) || duration <= 0;
        elements.progress.value = String(Math.round(progressRatio * 1000));
        if (elements.progress.style && typeof elements.progress.style.setProperty === "function") {
          elements.progress.style.setProperty("--playback-progress", `${Math.round(progressRatio * 100)}%`);
        }
        elements.progress.setAttribute("aria-valuetext", `${formatTime(current)} / ${formatTime(duration)}`);
      }
      setText(elements.time, `${formatTime(current)} / ${formatTime(duration)}`);
      if (elements.volume) elements.volume.value = String(volume);
      if (elements.mute) { elements.mute.textContent = muted ? "取消靜音" : "靜音"; elements.mute.setAttribute("aria-pressed", String(muted)); }
      if (elements.body) elements.body.hidden = collapsed;
      if (elements.dock && elements.dock.dataset) elements.dock.dataset.collapsed = String(collapsed);
      if (elements.collapse) { elements.collapse.textContent = collapsed ? "展開播放器" : "收合播放器"; elements.collapse.setAttribute("aria-expanded", String(!collapsed)); }
      if (elements.mode) elements.mode.value = playMode;
    }
    function renderResults() {
      const select = elements.results;
      if (!select || !select.ownerDocument) return;
      while (select.firstChild) select.removeChild(select.firstChild);
      if (!visibleRecords.length) {
        const option = select.ownerDocument.createElement("option"); option.value = "";
        option.textContent = records.length ? "沒有符合條件的可播放歌曲" : "尚無可播放曲目"; select.appendChild(option); setDisabled(select, true); return;
      }
      visibleRecords.forEach((record, index) => {
        const option = select.ownerDocument.createElement("option"); option.value = keyOf(record); option.textContent = formatRecord(record);
        if (currentRecord && keyOf(currentRecord) === keyOf(record)) option.selected = true; else if (!currentRecord && index === 0) option.selected = true;
        select.appendChild(option);
      });
      setDisabled(select, false);
    }
    function render() {
      renderResults(); renderQueue(); renderProgress();
      const audioState = audio.getState(), isPlaying = audioState.status === "playing";
      const visualState = ["loading", "ready", "playing", "paused", "stopped", "cancelled", "failed", "blocked", "ended", "idle", "disposed"].includes(audioState.status)
        ? audioState.status : "idle";
      setText(elements.status, error ? `錯誤：${error}` : status);
      if (elements.status) elements.status.setAttribute("data-playback-state", visualState);
      if (elements.dock) elements.dock.setAttribute("data-playback-state", visualState);
      if (elements.nowPlaying) {
        setText(elements.nowPlaying, currentRecord ? formatRecord(currentRecord) : "尚未選擇歌曲");
        elements.nowPlaying.setAttribute("data-playback-state", visualState);
      }
      setDisabled(elements.play, !getSelectedRecord() || isPlaying || audioState.status === "loading");
      setDisabled(elements.pause, !isPlaying);
      setDisabled(elements.stop, ["idle", "stopped", "cancelled", "failed", "ended", "disposed"].includes(audioState.status));
      setDisabled(elements.random, records.length === 0 && queue.length === 0);
      setDisabled(elements.enqueue, !getSelectedRecord());
      setDisabled(elements.next, queue.length === 0);
      setDisabled(elements.previous, queueHistoryCursor <= 0);
      setDisabled(elements.removeQueue, queue.length === 0 || !getSelectedQueueIndex().valid);
      setDisabled(elements.queuePlay, queue.length === 0 || !getSelectedQueueIndex().valid);
      setDisabled(elements.clearQueue, queue.length === 0);
    }
    function buildCatalog() {
      const nextCatalog = typeof runtime.catalogSnapshot === "function" ? runtime.catalogSnapshot() : null;
      if (!nextCatalog || typeof nextCatalog.search !== "function") { catalog = null; records = []; status = "等待曲庫載入"; render(); return false; }
      catalog = nextCatalog; const all = [], total = Number.isSafeInteger(catalog.size) ? catalog.size : 0;
      for (let offset = 0; offset < total; offset += 10000) all.push(...catalog.search({ offset, limit: Math.min(10000, total - offset) }).records);
      records = all.filter(record => record && Array.isArray(record.audioCandidates) && record.audioCandidates.length > 0 && ["AMQ", "EMQ"].includes(record.source));
      status = records.length ? `已載入 ${records.length.toLocaleString()} 首可播放歌曲` : "曲庫已載入，但沒有可播放候選"; filterRecords(); return true;
    }
    function filterRecords() {
      const query = String(elements.search && elements.search.value || "").trim();
      if (!query) visibleRecords = records.slice(0, 100);
      else {
        const normalized = query.normalize("NFKC").toLocaleLowerCase("und");
        visibleRecords = records.filter(record => [record.title, record.artist, record.animeTitle, record.animeAlternateTitle,
          ...(record.aliases || []), ...(record.artistAliases || []), ...(record.animeAliases || [])]
          .some(value => String(value || "").normalize("NFKC").toLocaleLowerCase("und").includes(normalized))).slice(0, 100);
      }
      render();
    }
    function enqueueRecord(record) {
      if (!record) return { ok: false, reason: "missing-record" };
      const key = keyOf(record);
      const existing = queue.findIndex(item => keyOf(item) === key);
      if (existing >= 0) { selectedQueueKey = key; render(); return { ok: true, added: false, index: existing }; }
      queue.push(record); selectedQueueKey = key; render();
      return { ok: true, added: true, index: queue.length - 1 };
    }
    function getSelectedQueueIndex() {
      for (const key of [String(elements.queue && elements.queue.value || ""), selectedQueueKey]) {
        if (!key) continue;
        const index = queue.findIndex(record => keyOf(record) === key);
        if (index >= 0) return { valid: true, index };
      }
      if (queueIndex >= 0 && queueIndex < queue.length) return { valid: true, index: queueIndex };
      return { valid: queue.length > 0, index: queue.length ? 0 : -1 };
    }
    function markQueueHistory(index) {
      if (index < 0 || index >= queue.length) return;
      if (suppressQueueHistoryOnce) { suppressQueueHistoryOnce = false; return; }
      if (queueHistoryCursor < queueHistory.length - 1) queueHistory = queueHistory.slice(0, queueHistoryCursor + 1);
      if (queueHistory.length && queueHistory[queueHistory.length - 1] === index) { queueHistoryCursor = queueHistory.length - 1; return; }
      queueHistory.push(index); queueHistoryCursor = queueHistory.length - 1;
    }
    function setPlayMode(value) {
      if (!["sequential", "loop", "shuffle"].includes(value)) return false;
      playMode = value; status = `播放模式：${value === "sequential" ? "順序播放" : value === "loop" ? "循環播放" : "隨機播放"}`; render(); return true;
    }
    function removeQueueItem(index) {
      if (!Number.isInteger(index) || index < 0 || index >= queue.length) return false;
      const removed = queue[index], removingCurrent = keyOf(removed) === keyOf(currentRecord);
      if (removingCurrent) { stopPlayback(); currentRecord = null; queueIndex = -1; }
      queue.splice(index, 1);
      if (queueIndex > index) queueIndex -= 1;
      if (selectedQueueKey === keyOf(removed)) selectedQueueKey = queue.length ? keyOf(queue[Math.min(index, queue.length - 1)]) : "";
      queueHistory = queueIndex >= 0 ? [queueIndex] : []; queueHistoryCursor = queueHistory.length ? 0 : -1;
      status = removingCurrent ? "已移除目前播放項目" : "已從佇列移除歌曲"; render(); return true;
    }
    function clearQueue() {
      if (audio.getState().status !== "idle" && audio.getState().status !== "stopped" && audio.getState().status !== "cancelled" && audio.getState().status !== "failed" && audio.getState().status !== "ended") stopPlayback();
      queue = []; queueIndex = -1; selectedQueueKey = ""; queueHistory = []; queueHistoryCursor = -1; currentRecord = null;
      status = "播放佇列已清空"; error = ""; render(); return true;
    }
    function playNext(automatic = false) {
      if (!queue.length) return false;
      let nextIndex;
      if (playMode === "shuffle") {
        const candidates = queue.map((_, index) => index).filter(index => queue.length < 2 || index !== queueIndex);
        nextIndex = candidates[Math.floor(Math.random() * candidates.length)];
      } else if (queueIndex < 0) nextIndex = 0;
      else if (queueIndex + 1 < queue.length) nextIndex = queueIndex + 1;
      else if (playMode === "loop") nextIndex = 0;
      else {
        status = automatic ? "佇列播放完成" : "已到佇列末尾"; render();
        if (automatic && audio.getState().status === "ended") { status = "佇列播放完成"; render(); }
        return false;
      }
      queueIndex = nextIndex; selectedQueueKey = keyOf(queue[nextIndex]);
      void playRecord(queue[nextIndex], { queueIndex: nextIndex }); return true;
    }
    function playPrevious() {
      if (queueHistoryCursor <= 0 || !queueHistory.length) return false;
      queueHistoryCursor -= 1;
      const index = queueHistory[queueHistoryCursor];
      if (!queue[index]) return false;
      queueIndex = index; selectedQueueKey = keyOf(queue[index]); suppressQueueHistoryOnce = true;
      void playRecord(queue[index], { queueIndex: index, preserveHistory: true }); return true;
    }
    function clearTick() { if (tick !== null) unscheduleTick(tick); tick = null; }
    function stopPlayback() {
      const result = audio.stop();
      clearTick(); playingSince = null; playedSeconds = 0; sequence = null;
      return result;
    }
    function maybeRecord() {
      if (disposed || !currentRecord || sequence === null || lastHistorySequence === sequence || playedSeconds < PLAY_THRESHOLD_SECONDS) return;
      const metrics = typeof audio.getPlaybackMetrics === "function" ? audio.getPlaybackMetrics() : {};
      if (pendingHistorySequence !== sequence || !pendingHistoryId) {
        pendingHistorySequence = sequence;
        pendingHistoryId = `${dockInstanceId}-${sequence}-${++historyEntryCounter}`;
      }
      const result = history.recordPlayback({ id: pendingHistoryId, source: currentRecord.source, songId: currentRecord.id,
        workId: currentRecord.animeId, title: currentRecord.title, artist: currentRecord.artist, workTitle: currentRecord.animeTitle,
        playedAt: now(), durationSeconds: metrics.duration, positionSeconds: metrics.currentTime });
      if (result.persisted) { lastHistorySequence = sequence; pendingHistorySequence = null; pendingHistoryId = null; status = "已記錄播放歷史（實際播放至少 5 秒）"; error = ""; }
      else error = `播放歷史未保存：${result.reason || "未知原因"}`;
      render();
    }
    function onAudioState(next) {
      if (disposed) return;
      if (next.status === "playing") {
        if (sequence !== next.sequence) { sequence = next.sequence; playedSeconds = 0; playingSince = now(); pendingHistorySequence = null; pendingHistoryId = null; if (lastHistorySequence !== sequence) lastHistorySequence = null; markQueueHistory(queueIndex); }
        else if (playingSince === null) playingSince = now();
        clearTick(); tick = scheduleTick(() => { if (playingSince !== null) { playedSeconds += Math.max(0, (now() - playingSince) / 1000); playingSince = now(); maybeRecord(); renderProgress(); } }, TICK_MS);
        status = "播放中"; error = "";
      } else {
        if (playingSince !== null) { playedSeconds += Math.max(0, (now() - playingSince) / 1000); playingSince = null; maybeRecord(); }
        clearTick();
        if (["failed", "blocked"].includes(next.status)) { const failed = (next.failures || []).map(item => `${item.source || "unknown"}:${item.reason || "failed"}`).join("、"); error = next.errorInfo && next.errorInfo.message || next.error || "音訊播放失敗"; status = failed ? `${error}（${failed}）` : error; }
        else if (next.status === "paused") status = "已暫停";
        else if (next.status === "stopped") status = "已停止";
        else if (next.status === "cancelled") status = "播放已取消";
        else if (next.status === "loading") status = "正在載入音訊";
        else if (next.status === "ready") status = "音訊已就緒，等待播放";
        else if (next.status === "ended") {
          status = "播放結束";
          const endedSequence = next.sequence;
          Promise.resolve().then(() => { if (!disposed && audio.getState().status === "ended" && audio.getState().sequence === endedSequence) playNext(true); });
        }
      }
      render();
    }
    async function playRecord(record, playOptions) {
      if (disposed || !record) return false;
      const opts = playOptions && typeof playOptions === "object" ? playOptions : {};
      const existingIndex = queue.findIndex(item => keyOf(item) === keyOf(record));
      if (existingIndex < 0) { queue.push(record); queueIndex = queue.length - 1; }
      else queueIndex = Number.isInteger(opts.queueIndex) ? opts.queueIndex : existingIndex;
      selectedQueueKey = keyOf(record);
      if (!["idle", "stopped", "cancelled", "failed", "ended", "disposed"].includes(audio.getState().status)) audio.stop();
      clearTick(); playedSeconds = 0; playingSince = null; sequence = null;
      if (opts.preserveHistory) suppressQueueHistoryOnce = true;
      currentRecord = record; error = ""; render();
      const result = await audio.play(record.audioCandidates);
      if (disposed) return false;
      if (result.status === "failed") { suppressQueueHistoryOnce = false; error = result.errorInfo && result.errorInfo.message || result.error || "播放失敗"; status = error; }
      else if (result.status === "playing") status = "播放中";
      else if (result.status === "ready") status = "音訊已就緒，請按播放";
      render(); return result.status === "playing" || result.status === "ready";
    }
    function onSharedState(next) {
      if (disposed) return;
      if (next.mode !== lastMode) {
        lastMode = next.mode;
        if (["loaded", "partial"].includes(next.dataStatus)) buildCatalog();
        else if (catalog) { catalog = null; records = []; visibleRecords = []; status = "曲庫尚未載入"; render(); }
        return;
      }
      if (["loaded", "partial"].includes(next.dataStatus) && !catalog) buildCatalog();
      else if (!["loaded", "partial"].includes(next.dataStatus) && catalog) { catalog = null; records = []; visibleRecords = []; status = "曲庫尚未載入"; render(); }
    }
    const unsubscribeAudio = audio.subscribe(onAudioState), unsubscribeHistory = history.subscribe(() => { const state = history.getPersistenceStatus(); if (!state.ok) error = `播放歷史讀取／寫入失敗：${state.reason || state.lastError || "未知原因"}`; render(); });
    const unsubscribeState = stateStore.subscribe(onSharedState); removers.push(unsubscribeAudio, unsubscribeHistory, unsubscribeState);
    listen(elements.search, "input", filterRecords);
    listen(elements.play, "click", () => {
      const audioStatus = audio.getState().status;
      if (["paused", "ready", "blocked"].includes(audioStatus)) audio.resume();
      else void playRecord(getSelectedRecord());
    });
    listen(elements.pause, "click", () => audio.pause()); listen(elements.stop, "click", stopPlayback);
    listen(elements.results, "change", render);
    listen(elements.enqueue, "click", () => { const result = enqueueRecord(getSelectedRecord()); status = result.added ? "已加入播放佇列" : "歌曲已在播放佇列中"; render(); });
    listen(elements.removeQueue, "click", () => { const selected = getSelectedQueueIndex(); if (selected.valid) removeQueueItem(selected.index); });
    listen(elements.queuePlay, "click", () => { const selected = getSelectedQueueIndex(); if (selected.valid && queue[selected.index]) { queueIndex = selected.index; void playRecord(queue[selected.index], { queueIndex: selected.index }); } });
    listen(elements.clearQueue, "click", clearQueue);
    listen(elements.next, "click", () => { playNext(false); });
    listen(elements.previous, "click", playPrevious);
    listen(elements.queue, "change", () => { selectedQueueKey = elements.queue.value; render(); });
    listen(elements.mode, "change", () => setPlayMode(elements.mode.value));
    listen(elements.volume, "input", () => { const value = Number(elements.volume.value); if (Number.isFinite(value) && value >= 0 && value <= 1) { volume = value; if (typeof audio.setVolume === "function") audio.setVolume(volume); renderProgress(); } });
    listen(elements.mute, "click", () => { muted = !muted; if (typeof audio.setMuted === "function") audio.setMuted(muted); renderProgress(); });
    listen(elements.progress, "change", () => { const metrics = audio.getPlaybackMetrics(); if (typeof audio.seek === "function" && Number.isFinite(metrics.duration) && metrics.duration > 0) audio.seek(Number(elements.progress.value) / 1000 * metrics.duration); renderProgress(); });
    listen(elements.collapse, "click", () => { collapsed = !collapsed; renderProgress(); });
    listen(elements.random, "click", () => {
      if (queue.length) {
        const candidates = queue.map((_, index) => index).filter(index => queue.length < 2 || index !== queueIndex);
        const index = candidates[Math.floor(Math.random() * candidates.length)];
        queueIndex = index; selectedQueueKey = keyOf(queue[index]); void playRecord(queue[index], { queueIndex: index });
      } else if (records.length) void playRecord(records[Math.floor(Math.random() * records.length)]);
    });
    onSharedState(stateStore.getState()); render();
    return Object.freeze({ refreshCatalog: buildCatalog, playRecord, enqueueRecord, removeQueueItem, clearQueue, playNext, playPrevious, setPlayMode,
      getState: () => Object.freeze({ status, error, currentRecord, recordCount: records.length, playedSeconds, queueCount: queue.length, queue: queue.slice(), queueIndex, playMode, volume, muted, collapsed, queueHistory: queueHistory.slice(), disposed }),
      dispose() { if (disposed) return false; disposed = true; clearTick(); removers.splice(0).forEach(remove => { try { remove(); } catch (_) {} }); if (ownsAudio) audio.dispose(); if (ownsHistory) history.dispose(); return true; },
      get isDisposed() { return disposed; } });
  }
  function mount(options) {
    const ids = { dock: "free-player-dock", search: "free-player-search", results: "free-player-results", play: "free-player-play", pause: "free-player-pause",
      stop: "free-player-stop", random: "free-player-random", status: "free-player-status", nowPlaying: "free-player-now-playing",
      queue: "free-player-queue", enqueue: "free-player-enqueue", queuePlay: "free-player-queue-play", removeQueue: "free-player-queue-remove", clearQueue: "free-player-queue-clear",
      next: "free-player-next", previous: "free-player-previous", mode: "free-player-mode", volume: "free-player-volume", mute: "free-player-mute",
      collapse: "free-player-collapse", body: "free-player-body", progress: "free-player-progress", time: "free-player-time" };
    const elements = Object.fromEntries(Object.entries(ids).map(([key, id]) => [key, global.document.getElementById(id)]));
    return createFreePlayerDock({ ...(options || {}), elements, startCollapsed: options && typeof options.startCollapsed === "boolean" ? options.startCollapsed : true });
  }
  global.AMQUI = global.AMQUI || {};
  global.AMQUI.freePlayerDock = Object.freeze({ createFreePlayerDock, mount, PLAY_THRESHOLD_SECONDS });
})(window);
