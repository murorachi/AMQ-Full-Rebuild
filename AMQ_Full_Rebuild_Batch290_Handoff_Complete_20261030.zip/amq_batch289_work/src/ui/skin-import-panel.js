/* User-facing .osk import preview with versioned IndexedDB-backed theme persistence. */
(function (global) {
  "use strict";
  function mount() {
    const root = document.getElementById("skin-import-panel");
    if (!root || !global.AMQSkins || !global.AMQSkins.oskImporter) return { dispose() {} };
    const input = root.querySelector("#skin-import-file");
    const exportButton = root.querySelector("#skin-theme-export");
    const importThemeInput = root.querySelector("#skin-theme-import-file");
    const transferApi = global.AMQSkins && global.AMQSkins.themeTransfer;
    const persistenceApi = global.AMQPersistence && global.AMQPersistence.skinThemeStore;
    const adapterApi = global.AMQSkins && global.AMQSkins.themeAdapter;
    const themeAdapter = adapterApi && adapterApi.createThemeAdapter ? adapterApi.createThemeAdapter() : null;
    const store = persistenceApi && persistenceApi.createSkinThemeStore ? persistenceApi.createSkinThemeStore() : null;
    const status = root.querySelector("#skin-import-status");
    const details = root.querySelector("#skin-import-details");
    const diagnostics = root.querySelector("#skin-import-diagnostics");
    const gallery = root.querySelector("#skin-import-gallery");
    const reset = root.querySelector("#skin-import-reset");
    const mappingStudio = root.querySelector("#skin-role-mapping-studio");
    const mappingReset = root.querySelector("#skin-mapping-reset");
    const skinIniPreview = root.querySelector("#skin-ini-preview");
    const soundInventory = root.querySelector("#skin-sound-inventory");
    const contract = global.AMQSkins.skinContract || { roles: [], stableAssets: [], pages: [] };
    const roleSelects = new Map();
    const statePairSelects = new Map();
    const applyButton = root.querySelector("#skin-import-apply");
    let result = null;
    let urls = [];
    let disposed = false;
    let applyingTheme = false;
    let persistedTheme = null;
    function say(message, error) {
      if (!status) return;
      status.textContent = message;
      status.classList.toggle("error-message", Boolean(error));
      status.setAttribute("aria-live", error ? "assertive" : "polite");
    }
    function clearUrls() { for (const url of urls) URL.revokeObjectURL(url); urls = []; }
    function imageBlob(entry) {
      const mime = ({ png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", webp: "image/webp", gif: "image/gif", bmp: "image/bmp", wav: "audio/wav", mp3: "audio/mpeg", ogg: "audio/ogg" })[entry.extension] || "application/octet-stream";
      return entry.blob || new Blob([entry.data], { type: mime });
    }
    function themeRecord(enabled) {
      const roleMappings = Object.fromEntries(Array.from(roleSelects, ([role, select]) => [role, select.value || null]));
      const roleStateMappings = Object.fromEntries(Array.from(statePairSelects, ([role, controls]) => [role, { normal: controls.normal.value || null, hover: controls.hover.value || null, fit: controls.fit.value || "contain", position: controls.position.value || "center center" }]).filter(([, pair]) => pair.normal || pair.hover));
      const mappings = { background: roleMappings["app.home.background"] || null, selectionFrame: roleMappings["catalog.item.selected"] || null, characterOverlay: null };
      const persistableEntries = result.entries.filter(entry => ["png", "jpg", "jpeg", "webp", "gif", "bmp", "wav", "mp3", "ogg"].includes(entry.extension));
      return { schemaVersion: 4, enabled: enabled === true, metadata: result.metadata, mappings, roleMappings, roleStateMappings, overrides: result.overrides || (persistedTheme && persistedTheme.overrides) || { regions: {}, components: {} },
        skinIniText: result.skinIniText || result.metadata.rawText || "", skinIniSections: result.metadata.sections || {},
        accentColors: Object.values(result.metadata.colors || {}).map(value => { const match = value.match(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/i); return match ? "#" + match.slice(1).map(n => Number(n).toString(16).padStart(2, "0")).join("") : ""; }).filter(Boolean),
        motionPreference: "system", assets: persistableEntries.map(entry => ({ path: entry.path, name: entry.name, extension: entry.extension, mime: imageBlob(entry).type, blob: imageBlob(entry) })) };
    }
    async function persistCurrentTheme(enabled) {
      if (!store || !result) return false;
      try { await store.save(themeRecord(enabled)); persistedTheme = await store.load(); return true; }
      catch (error) { say(`素材已讀取，但無法永久保存：${error.message || "IndexedDB error"}`, true); return false; }
    }
    function optionsFor(select, entries, selectedPath) {
      select.replaceChildren();
      const placeholder = document.createElement("option");
      placeholder.value = ""; placeholder.textContent = "不使用"; select.append(placeholder);
      for (const entry of entries) {
        const option = document.createElement("option");
        option.value = entry.path; option.textContent = entry.path;
        select.append(option);
      }
      if (selectedPath && entries.some(entry => entry.path === selectedPath)) select.value = selectedPath;
    }
    function imageEntries() { return result.entries.filter(entry => ["png", "jpg", "jpeg", "webp", "gif", "bmp"].includes(entry.extension)); }
    function candidatesForRole(role) {
      const imagePaths = new Set(imageEntries().map(entry => entry.path));
      const stableIds = new Set(role.stableAssets || []);
      const stable = contract.stableAssets.filter(asset => stableIds.has(asset.id));
      const names = new Set(stable.flatMap(asset => asset.filenames || []).map(name => name.toLowerCase().replace(/@2x(?=\.)/, "")));
      const exact = imageEntries().filter(entry => names.has(entry.name.toLowerCase()) || names.has(entry.path.toLowerCase()));
      const rest = imageEntries().filter(entry => !exact.includes(entry));
      return { exact, rest, stable };
    }
    function suggestedMappings() {
      const suggested = {};
      for (const role of contract.roles) { const candidates = candidatesForRole(role); if (candidates.exact.length) suggested[role.id] = candidates.exact[0].path; }
      return suggested;
    }
    function renderRolePreview(preview, role, entry) {
      preview.replaceChildren();
      const geometryApi = global.AMQSkins && global.AMQSkins.skinGeometry;
      const geometry = geometryApi && geometryApi.describe ? geometryApi.describe(role.id, entry ? entry.path : "") : { mode: "contain", anchor: "center center", label: "保留原始比例", note: "預覽示意" };
      preview.dataset.previewMode = geometry.mode;
      preview.dataset.anchor = geometry.anchor;
      if (!entry) {
        const text = document.createElement("span"); text.className = "skin-role-preview-fallback"; text.textContent = `AMQ 預設 fallback：${role.fallback}`; preview.append(text); return;
      }
      const url = URL.createObjectURL(imageBlob(entry)); urls.push(url);
      if (["cover", "repeat-x", "stretch-x", "stateful-panel"].includes(geometry.mode)) {
        const surface = document.createElement("div"); surface.className = "skin-role-preview-surface";
        surface.style.backgroundImage = `url("${url}")`;
        surface.style.backgroundPosition = geometry.anchor;
        if (geometry.mode === "cover") { surface.style.backgroundSize = "cover"; surface.style.backgroundRepeat = "no-repeat"; }
        else if (geometry.mode === "repeat-x") { surface.style.backgroundSize = "auto 100%"; surface.style.backgroundRepeat = "repeat-x"; }
        else if (geometry.mode === "stretch-x") { surface.style.backgroundSize = "100% 100%"; surface.style.backgroundRepeat = "no-repeat"; }
        else { surface.style.backgroundSize = "100% 100%"; surface.style.backgroundRepeat = "no-repeat"; surface.dataset.stateTint = "preview-only"; }
        preview.append(surface);
      } else {
        const img = document.createElement("img"); img.src = url; img.alt = `${role.label} 素材比例預覽`;
        const renderer = global.AMQSkins && global.AMQSkins.skinRenderer;
        const fit = renderer && renderer.fitStyle ? renderer.fitStyle(geometry.mode === "intrinsic" ? "contain" : geometry.mode, geometry.anchor) : { objectFit: "contain", objectPosition: geometry.anchor || "center center" };
        img.style.objectFit = fit.objectFit; img.style.objectPosition = fit.objectPosition;
        img.addEventListener("load", () => {
          if (!preview.isConnected) return;
          const logical = renderer && renderer.logicalSize ? renderer.logicalSize(img.naturalWidth, img.naturalHeight, entry.path) : null;
          preview.dataset.intrinsicSize = `${img.naturalWidth}×${img.naturalHeight}`;
          if (logical) { preview.dataset.logicalSize = `${logical.width}×${logical.height}`; preview.dataset.densityScale = String(logical.scale); }
        }, { once: true });
        preview.append(img);
      }
    }
    function renderStatePairPreview(preview, role, normalPath, hoverPath, fitMode = "contain", position = "center center") {
      const normal = normalPath ? result.entries.find(item => item.path === normalPath) : null;
      const hover = hoverPath ? result.entries.find(item => item.path === hoverPath) : null;
      preview.replaceChildren(); preview.dataset.previewMode = "state-pair";
      const renderer = global.AMQSkins && global.AMQSkins.skinRenderer;
      const resolved = renderer && renderer.resolveStatePair ? renderer.resolveStatePair(imageEntries(), normalPath, hoverPath) : { normal, hover, complete: Boolean(normal && hover), fallback: "renderer-unavailable" };
      for (const [state, entry] of [["normal", resolved.normal], ["hover", resolved.hover]]) {
        const item = document.createElement("div"); item.className = "skin-role-state-preview"; item.dataset.state = state;
        const label = document.createElement("span"); label.textContent = state === "normal" ? "Normal" : "Hover"; item.append(label);
        if (entry) {
          const url = URL.createObjectURL(imageBlob(entry)); urls.push(url);
          const image = document.createElement("img"); image.src = url; image.alt = `${role.label} ${state} 狀態預覽`;
          const geometryApi = global.AMQSkins && global.AMQSkins.skinGeometry;
          const geometry = geometryApi && geometryApi.describe ? geometryApi.describe(role.id, entry.path) : { mode: "contain", anchor: "center center" };
          const fit = renderer && renderer.fitStyle ? renderer.fitStyle(fitMode, position || geometry.anchor) : { objectFit: fitMode, objectPosition: position || geometry.anchor || "center center" };
          image.style.objectFit = fit.objectFit; image.style.objectPosition = fit.objectPosition;
          image.addEventListener("load", () => { const size = renderer && renderer.logicalSize ? renderer.logicalSize(image.naturalWidth, image.naturalHeight, entry.path) : null; if (size && preview.isConnected) item.dataset.logicalSize = `${size.width}×${size.height}`; }, { once: true });
          item.append(image);
        } else {
          const fallback = document.createElement("span"); fallback.className = "skin-role-preview-fallback"; fallback.textContent = `AMQ 預設 fallback（缺少 ${state} 素材）`; item.append(fallback);
        }
        preview.append(item);
      }
      preview.dataset.statePairComplete = String(resolved.complete);
      if (!resolved.complete) preview.dataset.fallback = resolved.fallback || "state-pair-incomplete";
    }
    function renderVisualNeedsOverview(initialMappings, runtimeSupport) {
      const api = global.AMQSkins && global.AMQSkins.visualNeeds;
      if (!api || !Array.isArray(api.needs)) return;
      const section = document.createElement("section"); section.className = "skin-visual-needs";
      const header = document.createElement("div"); header.className = "skin-visual-needs-header";
      const title = document.createElement("div");
      const heading = document.createElement("h4"); heading.textContent = "AMQ 版面需求基準";
      const note = document.createElement("p"); note.textContent = "先定義每個頁面需要什麼視覺元件，再挑選語義相符的 Skin 素材。素材缺失不會改變版面需求，也不會自動用不相關圖片補洞。";
      title.append(heading, note);
      const stats = document.createElement("div"); stats.className = "skin-visual-needs-stats";
      const needs = api.needs;
      const required = needs.filter(item => item.priority === "required").length;
      stats.textContent = `${needs.length} 個視覺需求 · ${required} 個必要槽位`;
      header.append(title, stats); section.append(header);
      const grid = document.createElement("div"); grid.className = "skin-visual-needs-grid";
      for (const need of needs) {
        const card = document.createElement("article"); card.className = "skin-visual-need"; card.dataset.needId = need.id;
        const top = document.createElement("div"); top.className = "skin-visual-need-top";
        const label = document.createElement("strong"); label.textContent = need.label;
        const priority = document.createElement("span"); priority.className = `skin-need-priority ${need.priority === "required" ? "is-required" : "is-optional"}`; priority.textContent = need.priority === "required" ? "必要" : "選配";
        top.append(label, priority);
        const page = document.createElement("span"); page.className = "skin-visual-need-page"; page.textContent = need.page;
        const desc = document.createElement("p"); desc.textContent = need.policy;
        const mapped = need.roleIds.filter(id => Boolean(initialMappings[id])).length;
        const supported = need.roleIds.filter(id => runtimeSupport[id] && runtimeSupport[id].supported).length;
        const status = document.createElement("span"); status.className = "skin-visual-need-status";
        status.textContent = `${mapped}/${need.roleIds.length} 已指定素材 · ${supported}/${need.roleIds.length} 已接正式元件`;
        status.classList.toggle("is-incomplete", mapped < need.roleIds.length || supported < need.roleIds.length);
        card.append(top, page, desc, status); grid.append(card);
      }
      section.append(grid); mappingStudio.append(section);
    }
    function renderMappingStudio(savedMappings, savedStateMappings) {
      mappingStudio.replaceChildren(); roleSelects.clear(); statePairSelects.clear(); statePairSelects.clear();
      const initialMappings = savedMappings && Object.keys(savedMappings).length ? savedMappings : suggestedMappings();
      const runtimeSupport = adapterApi && typeof adapterApi.getRoleSupport === "function" ? adapterApi.getRoleSupport() : {};
      renderVisualNeedsOverview(initialMappings, runtimeSupport);
      const pages = contract.pages || [];
      for (const page of pages) {
        const pageRoles = contract.roles.filter(role => role.page === page.id);
        if (!pageRoles.length) continue;
        const section = document.createElement("section"); section.className = "skin-role-page";
        const heading = document.createElement("h4"); heading.textContent = page.label; section.append(heading);
        const grid = document.createElement("div"); grid.className = "skin-role-grid";
        for (const role of pageRoles) {
          const candidate = candidatesForRole(role);
          const card = document.createElement("article"); card.className = "skin-role-card"; card.dataset.roleId = role.id;
          const title = document.createElement("div"); title.className = "skin-role-title";
          const label = document.createElement("label"); label.textContent = role.label;
          const select = document.createElement("select"); select.id = `skin-role-${role.id.replace(/[^a-z0-9-]/gi, "-")}`; label.htmlFor = select.id;
          const empty = document.createElement("option"); empty.value = ""; empty.textContent = `使用預設：${role.fallback}`; select.append(empty);
          const addGroup = (labelText, entries) => { if (!entries.length) return; const group = document.createElement("optgroup"); group.label = labelText; for (const entry of entries) { const option = document.createElement("option"); option.value = entry.path; option.textContent = `${entry.name} · ${entry.path}`; group.append(option); } select.append(group); };
          addGroup("檔名符合 stable 契約（優先建議）", candidate.exact);
          const manualOverride = document.createElement("details"); manualOverride.className = "skin-role-manual-override";
          const manualSummary = document.createElement("summary"); manualSummary.textContent = `人工覆寫候選（${candidate.rest.length} 張其他圖片）`;
          const manualHelp = document.createElement("p"); manualHelp.className = "subtle"; manualHelp.textContent = "這些素材沒有 stable 檔名依據，不是系統建議。展開後才會加入下拉選單。";
          const manualToggle = document.createElement("button"); manualToggle.type = "button"; manualToggle.className = "skin-role-manual-enable"; manualToggle.textContent = "顯示人工覆寫候選";
          const manualEnabled = document.createElement("div");
          manualToggle.addEventListener("click", () => { addGroup("人工覆寫候選（非自動建議）", candidate.rest); manualToggle.textContent = "已顯示人工覆寫候選"; manualToggle.disabled = true; });
          manualEnabled.append(manualHelp, manualToggle); manualOverride.append(manualSummary, manualEnabled);
          const saved = initialMappings && initialMappings[role.id];
          if (saved && candidate.rest.some(entry => entry.path === saved)) { addGroup("已保存的人工覆寫", candidate.rest.filter(entry => entry.path === saved)); manualToggle.textContent = "已顯示人工覆寫候選"; manualToggle.disabled = true; }
          if (saved && Array.from(select.options).some(option => option.value === saved)) select.value = saved;
          select.addEventListener("change", () => { const preview = card.querySelector(".skin-role-preview"); const entry = select.value ? result.entries.find(item => item.path === select.value) : null; renderRolePreview(preview, role, entry); });
          roleSelects.set(role.id, select); title.append(label);
          const badge = document.createElement("span"); badge.className = "skin-role-badge"; badge.textContent = candidate.exact.length ? `找到 ${candidate.exact.length} 個 stable 檔名匹配` : (candidate.stable.length ? "此 Skin 缺少對應素材" : "AMQ 擴充槽位"); title.append(badge);
          const runtime = runtimeSupport[role.id];
          const runtimeBadge = document.createElement("span"); runtimeBadge.className = `skin-role-runtime-status ${runtime && runtime.supported ? "is-supported" : "is-unsupported"}`;
          runtimeBadge.textContent = runtime && runtime.supported ? `可套用 · ${runtime.targetCount} 個目標` : "尚未接入正式元件";
          runtimeBadge.setAttribute("aria-label", runtime && runtime.supported ? `正式元件支援，選擇素材後可套用至 ${runtime.targetCount} 個目標` : "尚未接入正式元件，映射可保存但不會改變正式畫面");
          const rationale = document.createElement("p"); rationale.className = "subtle"; rationale.textContent = `${candidate.stable.length ? `stable 契約檔名：${candidate.stable.flatMap(asset => asset.filenames).join("、")}` : "沒有直接對應的 stable 素材；使用 AMQ 專屬槽位與 fallback。"} ${candidate.exact.length ? `已找到實際匹配：${candidate.exact.map(entry => entry.path).join("、")}` : candidate.stable.length ? "本次匯入未找到上述檔名；不會自動套用其他圖片。" : "此角色沒有原生 stable 檔名，只有在確認素材用途後才手動覆寫。"} ${runtime && runtime.supported ? `正式目標：${runtime.selector}` : "目前只有映射保存能力，尚未接入正式 UI 元件。"}`;
          const geometryApi = global.AMQSkins && global.AMQSkins.skinGeometry;
          const geometry = geometryApi && geometryApi.describe ? geometryApi.describe(role.id, select.value || "") : { label: "保留原始比例", note: "預覽示意" };
          const geometryLabel = document.createElement("p"); geometryLabel.className = "skin-role-geometry"; geometryLabel.textContent = `${geometry.label}。${geometry.note}${geometry.versionNote ? ` ${geometry.versionNote}` : ""}`;
          const preview = document.createElement("div"); preview.className = "skin-role-preview"; preview.setAttribute("aria-live", "polite");
          const selectedEntry = select.value ? result.entries.find(item => item.path === select.value) : null;
          renderRolePreview(preview, role, selectedEntry);
          const pairMode = geometry.mode === "state-pair" || role.id === "app.navigation.back";
          let pairControls = null;
          if (pairMode) {
            pairControls = document.createElement("fieldset"); pairControls.className = "skin-role-state-pair";
            const legend = document.createElement("legend"); legend.textContent = "明確指定互動狀態（缺件時使用 AMQ 預設，不借用其他圖片）";
            const normalLabel = document.createElement("label"); normalLabel.textContent = "Normal 素材";
            const normalSelect = document.createElement("select"); normalSelect.setAttribute("aria-label", `${role.label} normal 素材`); optionsFor(normalSelect, imageEntries(), savedStateMappings && savedStateMappings[role.id] && savedStateMappings[role.id].normal);
            const hoverLabel = document.createElement("label"); hoverLabel.textContent = "Hover 素材";
            const hoverSelect = document.createElement("select"); hoverSelect.setAttribute("aria-label", `${role.label} hover 素材`); optionsFor(hoverSelect, imageEntries(), savedStateMappings && savedStateMappings[role.id] && savedStateMappings[role.id].hover);
            const fitLabel = document.createElement("label"); fitLabel.textContent = "圖片適配";
            const fitSelect = document.createElement("select"); for (const mode of ["contain", "cover"]) { const option = document.createElement("option"); option.value = mode; option.textContent = mode; fitSelect.append(option); }
            fitSelect.value = savedStateMappings && savedStateMappings[role.id] && savedStateMappings[role.id].fit || "contain";
            const positionLabel = document.createElement("label"); positionLabel.textContent = "錨點";
            const positionSelect = document.createElement("select"); for (const value of ["center center", "center top", "bottom left", "top left"]) { const option = document.createElement("option"); option.value = value; option.textContent = value; positionSelect.append(option); }
            positionSelect.value = savedStateMappings && savedStateMappings[role.id] && savedStateMappings[role.id].position || "center center";
            normalLabel.append(normalSelect); hoverLabel.append(hoverSelect); fitLabel.append(fitSelect); positionLabel.append(positionSelect);
            pairControls.append(legend, normalLabel, hoverLabel, fitLabel, positionLabel);
            const rerenderPair = () => renderStatePairPreview(preview, role, normalSelect.value, hoverSelect.value, fitSelect.value, positionSelect.value);
            normalSelect.addEventListener("change", rerenderPair); hoverSelect.addEventListener("change", rerenderPair); fitSelect.addEventListener("change", rerenderPair); positionSelect.addEventListener("change", rerenderPair);
            statePairSelects.set(role.id, { normal: normalSelect, hover: hoverSelect, fit: fitSelect, position: positionSelect });
            rerenderPair();
          }
          card.append(title, runtimeBadge, rationale, geometryLabel, select, manualOverride);
          if (pairControls) card.append(pairControls);
          card.append(preview); grid.append(card);
        }
        section.append(grid); mappingStudio.append(section);
      }
    }
    function renderGallery(savedMappings, savedStateMappings) {
      clearUrls(); gallery.replaceChildren();
      for (const entry of imageEntries()) {
        const url = URL.createObjectURL(imageBlob(entry)); urls.push(url);
        const figure = document.createElement("figure"); figure.className = "skin-asset-item";
        const image = document.createElement("img"); image.src = url; image.alt = entry.name; image.loading = "lazy";
        const caption = document.createElement("figcaption"); caption.textContent = entry.path;
        figure.append(image, caption); gallery.append(figure);
      }
      const skinName = result.metadata.name + (result.metadata.author ? ` · ${result.metadata.author}` : "");
      const audit = result.referenceAudit;
      details.textContent = `${skinName}｜讀取 ${result.entries.length} 個素材（圖片 ${result.imageCount || imageEntries().length} 張、音效 ${result.soundCount || result.entries.filter(entry => ["wav", "mp3", "ogg"].includes(entry.extension)).length} 個）｜${(result.totalBytes / 1024 / 1024).toFixed(2)} MiB${audit ? `｜skin.ini Mania 圖片參照 ${audit.resolved}/${audit.checked} 可解析` : ""}`;
      if (diagnostics) {
        diagnostics.hidden = !audit || audit.missing.length === 0;
        diagnostics.classList.toggle("is-warning", Boolean(audit && audit.missing.length));
        if (audit && audit.missing.length) {
          const hd = audit.missing.filter(item => item.status === "missing-hd-reference").length;
          const normal = audit.missing.length - hd;
          diagnostics.textContent = `Skin 完整性提醒：skin.ini 有 ${audit.missing.length} 個 Mania 圖片參照無法在封裝中找到（${normal} 個一般素材、${hd} 個 @2x 參照）。這不會阻止其他素材匯入；缺少的圖片不會被假裝成已載入。`;
        } else diagnostics.textContent = "";
      }
      renderMappingStudio(savedMappings || result.roleMappings || {}, savedStateMappings || result.roleStateMappings || {});
      if (skinIniPreview) skinIniPreview.textContent = result.skinIniText || result.metadata.rawText || "此 Skin 沒有 skin.ini，將使用 AMQ 預設設定。";
      if (soundInventory) { soundInventory.replaceChildren(); const sounds = result.entries.filter(entry => ["wav", "mp3", "ogg"].includes(entry.extension)); if (!sounds.length) soundInventory.textContent = "沒有讀取到支援的音效檔案。"; else for (const sound of sounds) { const item = document.createElement("div"); item.className = "skin-sound-item"; item.textContent = sound.path; soundInventory.append(item); } }
      root.querySelector("#skin-import-mapping").hidden = false;
      root.querySelector("#skin-import-gallery-wrap").hidden = false;
      applyButton.disabled = false;
      if (exportButton) exportButton.disabled = !transferApi;
    }
    function onMappingReset() { if (!result) return; renderMappingStudio(suggestedMappings()); say("已還原依 stable 原生檔名配對的建議映射；按套用預覽後保存。", false); }
    async function onReset() { resetTheme(); persistedTheme = null; if (store) { try { await store.clear(); say("已移除保存的 Skin，並切回預設外觀。", false); } catch (error) { say(`已清除目前預覽，但 IndexedDB 清除失敗：${error.message || "未知錯誤"}`, true); return; } } else say("已清除目前預覽。此瀏覽器不支援 IndexedDB，保存的 Skin 無法管理。", true); }
    async function onFile() {
      const file = input.files && input.files[0];
      if (!file) return;
      resetTheme(); result = null; applyButton.disabled = true;
      if (!/\.osk$/i.test(file.name)) { say("請選取 .osk 檔案。", true); return; }
      if (file.size > global.AMQSkins.oskImporter.limits.archiveBytes) { say("檔案超過 80 MiB 上限。", true); return; }
      say(`正在讀取 ${file.name}…`);
      try {
        result = await global.AMQSkins.oskImporter.read(await file.arrayBuffer());
        if (disposed) return;
        renderGallery();
        const saved = await persistCurrentTheme(false);
        if (!disposed) say(saved ? "Skin 讀取成功，圖片與設定已保存至此瀏覽器。按「套用預覽」啟用。" : "Skin 讀取成功，但 IndexedDB 保存失敗；目前只可預覽，重新載入後可能遺失。", !saved);
      } catch (error) {
        result = null; details.textContent = ""; gallery.replaceChildren();
        if (exportButton) exportButton.disabled = true;
        say(`${error.code || "OSK_IMPORT_FAILED"}：${error.message || "無法讀取 Skin。"}`, true);
      }
    }
    async function applyTheme() {
      if (!result || applyingTheme || disposed) return;
      applyingTheme = true;
      const restoreFocus = document.activeElement === applyButton;
      applyButton.disabled = true;
      applyButton.setAttribute("aria-busy", "true");
      const theme = themeRecord(true);
      let applyOutcome = { applied: false, roles: [], warnings: ["theme-adapter-unavailable"] };
      try {
        if (themeAdapter) {
          const outcome = await themeAdapter.apply(theme);
          applyOutcome = outcome;
          if (disposed) return;
          if (outcome.warnings.length) say(`已套用可用素材；部分素材使用預設外觀（${outcome.warnings.join("、")}）。`, false);
          else if (outcome.applied) say("已套用 Skin 主題。", false);
          else say("此 Skin 沒有可套用的角色素材，AMQ 保留預設外觀。", false);
        } else {
          say("Skin 主題轉換器未載入，已保留目前預設外觀。", true);
          return;
        }
        if (store) {
          try {
            await store.save(theme);
            persistedTheme = await store.load();
            if (!disposed) say("已套用並保存 Skin 主題；重新載入後會自動恢復。", false);
          } catch (error) { if (!disposed) say(`${applyOutcome.applied ? "主題已套用" : "沒有可用素材，已保留預設外觀"}，但保存失敗：${error.message || "IndexedDB error"}`, true); }
        } else say("已套用所選素材，但 IndexedDB 不可用，重新載入後不會保留。", true);
      } catch (error) {
        if (!disposed) say(`Skin 套用失敗：${error.code || error.message || "未知錯誤"}。已保留目前可用外觀。`, true);
      } finally {
        applyingTheme = false;
        if (!disposed) {
          applyButton.disabled = !result;
          applyButton.removeAttribute("aria-busy");
          if (restoreFocus && !applyButton.disabled) applyButton.focus();
        }
      }
    }
    async function exportCurrentTheme() {
      if (!transferApi || !result) { say("沒有可匯出的 Skin 主題。", true); return; }
      try {
        const payload = await transferApi.exportTheme(themeRecord(false));
        const blob = new Blob([payload], { type: "application/json;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const anchor = document.createElement("a");
        const safeName = String(result.metadata.name || "amq-skin-theme").replace(/[^\p{L}\p{N}._-]+/gu, "_").slice(0, 80) || "amq-skin-theme";
        anchor.href = url; anchor.download = `${safeName}.amq-skin-theme.json`;
        document.body.append(anchor);
        anchor.click();
        // Removing the anchor or revoking its URL in the same task can cancel Chromium's pending download.
        global.setTimeout(() => { anchor.remove(); URL.revokeObjectURL(url); }, 1000);
        say("主題設定已在本機匯出。檔案可能包含第三方素材，分享前請確認授權。", false);
      } catch (error) { say(`主題匯出失敗：${error.code || error.message || "未知錯誤"}`, true); }
    }
    async function importThemeFile() {
      const file = importThemeInput && importThemeInput.files && importThemeInput.files[0];
      if (!file) return;
      if (file.size > 170 * 1024 * 1024) { say("主題設定檔超過 170 MiB 上限。", true); importThemeInput.value = ""; return; }
      if (!transferApi) { say("主題設定匯入模組未載入。", true); return; }
      try {
        const theme = await transferApi.importTheme(await file.text());
        if (disposed) return;
        resetTheme();
        result = { format: "amq-skin-theme", metadata: theme.metadata, entries: await Promise.all(theme.assets.map(async item => ({ path: item.path, name: item.name, extension: item.extension, mime: item.mime, blob: item.blob, data: new Uint8Array(await item.blob.arrayBuffer()), size: item.blob.size }))),
          imageCount: theme.assets.filter(item => ["png", "jpg", "jpeg", "webp", "gif", "bmp"].includes(item.extension)).length, totalBytes: theme.assets.reduce((sum, item) => sum + item.blob.size, 0), mappings: theme.mappings || {}, roleMappings: theme.roleMappings || {}, roleStateMappings: theme.roleStateMappings || {}, overrides: theme.overrides || { regions: {}, components: {} }, skinIniText: theme.skinIniText || "" };
        renderGallery(theme.roleMappings || {}, theme.roleStateMappings || {});
        if (store) {
          try {
            await store.save({ ...theme, enabled: false }); persistedTheme = await store.load();
            say(`已驗證並匯入主題「${theme.metadata.name}」，設定已保存但尚未套用。請確認素材授權後再預覽。`, false);
          } catch (error) { say(`已驗證並匯入主題「${theme.metadata.name}」，但本機保存失敗：${error.message || "IndexedDB error"}。目前可預覽，重新載入後可能遺失。`, true); }
        } else say("主題設定已匯入供本次預覽；IndexedDB 不可用，重新載入後可能遺失。", true);
      } catch (error) { say(`主題設定匯入失敗：${error.code || error.message || "檔案格式無效"}`, true); }
      finally { if (importThemeInput) importThemeInput.value = ""; }
    }
    function resetTheme(clearResult = true) {
      if (themeAdapter) themeAdapter.reset();
      if (clearResult) {
        result = null; clearUrls(); gallery.replaceChildren(); details.textContent = ""; if (diagnostics) { diagnostics.hidden = true; diagnostics.textContent = ""; }
        if (mappingStudio) mappingStudio.replaceChildren(); roleSelects.clear(); statePairSelects.clear();
        if (skinIniPreview) skinIniPreview.textContent = "";
        if (soundInventory) soundInventory.replaceChildren();
        root.querySelector("#skin-import-mapping").hidden = true;
        root.querySelector("#skin-import-gallery-wrap").hidden = true;
        applyButton.disabled = true; input.value = "";
      }
    }
    async function restoreSavedTheme() {
      if (!store) { say("尚未匯入 Skin。此瀏覽器不支援 IndexedDB 持久化。", true); return; }
      try {
        const saved = await store.load(); if (disposed || !saved) return;
        persistedTheme = saved;
        const entries = await Promise.all(saved.assets.map(async item => ({ path: item.path, name: item.name, extension: item.extension, size: item.size, blob: item.blob, data: new Uint8Array(await item.blob.arrayBuffer()) })));
        result = { format: "osk", metadata: saved.metadata, entries, imageCount: entries.filter(entry => ["png", "jpg", "jpeg", "webp", "gif", "bmp"].includes(entry.extension)).length, soundCount: entries.filter(entry => ["wav", "mp3", "ogg"].includes(entry.extension)).length, totalBytes: entries.reduce((sum, entry) => sum + entry.size, 0), mappings: saved.mappings || {}, roleMappings: saved.roleMappings || {}, roleStateMappings: saved.roleStateMappings || {}, skinIniText: saved.skinIniText || "" };
        renderGallery(saved.roleMappings || {}, saved.roleStateMappings || {});
        if (saved.enabled) applyTheme(); else say(`已還原保存的 Skin「${saved.metadata.name}」，尚未啟用。`, false);
      } catch (error) { say(`無法還原保存的 Skin：${error.message || "IndexedDB error"}。可清除失效素材後重新匯入。`, true); }
    }
    input.addEventListener("change", onFile);
    if (mappingReset) mappingReset.addEventListener("click", onMappingReset);
    applyButton.addEventListener("click", applyTheme);
    reset.addEventListener("click", onReset);
    if (exportButton) exportButton.addEventListener("click", exportCurrentTheme);
    if (importThemeInput) importThemeInput.addEventListener("change", importThemeFile);
    restoreSavedTheme();
    return { dispose() { if (disposed) return; disposed = true; input.removeEventListener("change", onFile); applyButton.removeEventListener("click", applyTheme); reset.removeEventListener("click", onReset); if (exportButton) exportButton.removeEventListener("click", exportCurrentTheme); if (importThemeInput) importThemeInput.removeEventListener("change", importThemeFile); if (mappingReset) mappingReset.removeEventListener("click", onMappingReset); resetTheme(); if (themeAdapter) themeAdapter.dispose(); if (store) store.dispose(); } };
  }
  global.AMQUI = global.AMQUI || {};
  global.AMQUI.skinImportPanel = Object.freeze({ mount });
})(window);
