/* VNDB character preferences and the Quiz character strip share one saved ID list. */
(function (global) {
  "use strict";
  const STORAGE_KEY = "amqVndbQuizCharactersV1";
  const MAX_CHARACTERS = 8;
  function normalizeIds(value) {
    if (!Array.isArray(value)) return [];
    const seen = new Set();
    const ids = [];
    for (const item of value) {
      const id = String(item || "").trim().toLowerCase();
      if (!/^c\d+$/.test(id) || seen.has(id)) continue;
      seen.add(id); ids.push(id);
      if (ids.length >= MAX_CHARACTERS) break;
    }
    return ids;
  }
  function mount(options = {}) {
    const adapter = options.adapter;
    const settingsPanel = document.getElementById("vndb-character-settings-panel");
    const quizBar = document.getElementById("quiz-character-bar");
    if (!settingsPanel || !quizBar || !adapter || typeof adapter.getCharacter !== "function") return Object.freeze({ dispose() {}, isDisposed: false });
    const input = settingsPanel.querySelector("#vndb-character-id");
    const addButton = settingsPanel.querySelector("#vndb-character-add");
    const status = settingsPanel.querySelector("#vndb-character-status");
    const configured = settingsPanel.querySelector("#vndb-character-configured");
    const strip = quizBar.querySelector("#quiz-character-items");
    let ids = [];
    let records = new Map();
    let disposed = false;
    let requestVersion = 0;
    const controllers = new Set();
    function setStatus(message, state = "idle") {
      if (!status) return;
      status.textContent = message;
      status.dataset.state = state;
    }
    function readStorage() {
      try {
        const parsed = JSON.parse(global.localStorage.getItem(STORAGE_KEY) || "[]");
        return normalizeIds(parsed);
      } catch (_) { return []; }
    }
    function save() {
      try { global.localStorage.setItem(STORAGE_KEY, JSON.stringify(ids)); return true; }
      catch (_) { setStatus("無法保存角色設定。", "error"); return false; }
    }
    function renderConfigured() {
      if (!configured) return;
      configured.replaceChildren();
      if (!ids.length) {
        const empty = document.createElement("p"); empty.className = "vndb-character-empty"; empty.textContent = "尚未加入角色"; configured.append(empty); return;
      }
      ids.forEach(id => {
        const record = records.get(id);
        const row = document.createElement("div"); row.className = "vndb-character-configured-item";
        const label = document.createElement("span"); label.textContent = record ? `${record.name || id} · ${id}` : id;
        const remove = document.createElement("button"); remove.type = "button"; remove.dataset.removeCharacter = id; remove.textContent = "移除"; remove.setAttribute("aria-label", `移除 ${id}`);
        row.append(label, remove); configured.append(row);
      });
    }
    function renderStrip() {
      strip.replaceChildren();
      const available = ids.map(id => records.get(id)).filter(record => record && record.imageUrl);
      quizBar.hidden = available.length === 0;
      for (const record of available) {
        const item = document.createElement("figure"); item.className = "quiz-character-item"; item.dataset.vndbCharacterId = record.id;
        item.dataset.skinComponent = "quiz.character.item";
        const image = document.createElement("img"); image.src = record.imageUrl; image.alt = record.name || record.id; image.loading = "lazy"; image.decoding = "async"; image.referrerPolicy = "no-referrer";
        image.addEventListener("error", () => { item.remove(); quizBar.hidden = strip.children.length === 0; }, { once: true });
        const caption = document.createElement("figcaption"); caption.textContent = record.name || record.id;
        item.append(image, caption); strip.append(item);
      }
    }
    async function loadCharacter(id, version) {
      const controller = typeof global.AbortController === "function" ? new global.AbortController() : null;
      if (controller) controllers.add(controller);
      try {
        const record = await adapter.getCharacter(id, { signal: controller ? controller.signal : undefined });
        if (disposed || version !== requestVersion) return null;
        if (!record || record.id !== id) throw Object.assign(new Error("角色資料不符"), { code: "VNDB_CHARACTER_MISMATCH" });
        records.set(id, record);
        return record;
      } catch (error) {
        if (!disposed && version === requestVersion && !(error && error.name === "AbortError")) {
          const message = error && error.code === "VNDB_CHARACTER_NOT_FOUND" ? `找不到角色 ${id}。` : `角色 ${id} 載入失敗。`;
          setStatus(message, "error");
        }
        return null;
      } finally { if (controller) controllers.delete(controller); }
    }
    async function refreshAll() {
      const version = ++requestVersion;
      controllers.forEach(controller => { try { controller.abort(); } catch (_) {} }); controllers.clear();
      records = new Map(); renderConfigured(); renderStrip();
      if (!ids.length) { setStatus("輸入 VNDB 角色 ID 以加入角色。", "idle"); return; }
      setStatus("正在載入角色…", "loading");
      if (typeof adapter.getCharacters === "function") {
        const controller = typeof global.AbortController === "function" ? new global.AbortController() : null;
        if (controller) controllers.add(controller);
        try {
          const result = await adapter.getCharacters(ids.slice(), { signal: controller ? controller.signal : undefined });
          if (disposed || version !== requestVersion) return;
          for (const record of Array.isArray(result) ? result : []) if (record && ids.includes(record.id)) records.set(record.id, record);
        } catch (error) {
          if (!disposed && version === requestVersion && !(error && error.name === "AbortError")) setStatus("角色載入失敗。", "error");
        } finally { if (controller) controllers.delete(controller); }
      } else {
        await Promise.all(ids.map(id => loadCharacter(id, version)));
      }
      if (disposed || version !== requestVersion) return;
      renderConfigured(); renderStrip();
      const loaded = ids.filter(id => records.has(id)).length;
      setStatus(loaded === ids.length ? `已載入 ${loaded} 個角色。` : `已載入 ${loaded}／${ids.length} 個角色。`, loaded ? "success" : "error");
    }
    async function addCharacter() {
      const id = String(input && input.value || "").trim().toLowerCase();
      if (!/^c\d+$/.test(id)) { setStatus("請輸入 VNDB 角色 ID，例如 c123。", "error"); input && input.focus(); return; }
      if (ids.includes(id)) { setStatus(`角色 ${id} 已在清單中。`, "idle"); return; }
      if (ids.length >= MAX_CHARACTERS) { setStatus(`最多可設定 ${MAX_CHARACTERS} 個角色。`, "error"); return; }
      const version = ++requestVersion;
      if (addButton) addButton.disabled = true;
      setStatus("正在查詢角色…", "loading");
      const record = await loadCharacter(id, version);
      if (disposed || version !== requestVersion) { if (addButton) addButton.disabled = false; return; }
      if (!record) { if (addButton) addButton.disabled = false; return; }
      ids = normalizeIds([...ids, id]);
      if (save()) { if (input) input.value = ""; renderConfigured(); renderStrip(); setStatus(`已加入 ${record.name || id}。`, "success"); }
      if (addButton) addButton.disabled = false;
    }
    function onConfiguredClick(event) {
      const button = event.target.closest("[data-remove-character]");
      if (!button) return;
      const id = button.dataset.removeCharacter;
      ids = ids.filter(value => value !== id); records.delete(id); save(); renderConfigured(); renderStrip();
      setStatus(`已移除角色 ${id}。`, "success");
    }
    if (addButton) addButton.addEventListener("click", addCharacter);
    const onInputKeydown = event => { if (event.key === "Enter") { event.preventDefault(); addCharacter(); } };
    if (input) input.addEventListener("keydown", onInputKeydown);
    if (configured) configured.addEventListener("click", onConfiguredClick);
    ids = readStorage();
    renderConfigured();
    refreshAll();
    return Object.freeze({ getIds: () => ids.slice(), refresh: refreshAll, dispose() {
      if (disposed) return false; disposed = true; requestVersion++;
      controllers.forEach(controller => { try { controller.abort(); } catch (_) {} }); controllers.clear();
      if (addButton) addButton.removeEventListener("click", addCharacter);
      if (configured) configured.removeEventListener("click", onConfiguredClick);
      if (input) input.removeEventListener("keydown", onInputKeydown);
      return true;
    }, get isDisposed() { return disposed; } });
  }
  global.AMQUI = global.AMQUI || {};
  global.AMQUI.vndbCharacterPanel = Object.freeze({ mount, normalizeIds, storageKey: STORAGE_KEY, maxCharacters: MAX_CHARACTERS });
})(window);
