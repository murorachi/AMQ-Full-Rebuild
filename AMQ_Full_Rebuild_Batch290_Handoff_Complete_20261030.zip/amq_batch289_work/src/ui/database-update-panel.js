/* Explicit preflight/apply UI for full AMQ + EMQ source database update packages. */
(function (global) {
  "use strict";

  function createDatabaseUpdatePanel(options) {
    const settings = options && typeof options === "object" ? options : {};
    const documentApi = settings.document || global.document;
    const manager = settings.manager;
    const exportPackage = settings.exportPackage;
    const confirmApply = settings.confirm || (message => global.confirm(message));
    const createObjectURL = settings.createObjectURL || (blob => global.URL.createObjectURL(blob));
    const revokeObjectURL = settings.revokeObjectURL || (url => global.URL.revokeObjectURL(url));
    const makeBlob = settings.makeBlob || ((parts, options) => new global.Blob(parts, options));
    const fetchApi = settings.fetch || global.fetch;
    const cryptoApi = settings.crypto || global.crypto;
    const defaultManifestUrl = typeof settings.releaseManifestUrl === "string" ? settings.releaseManifestUrl : (global.AMQ_DATABASE_UPDATE_MANIFEST_URL || "");
    const releasePublicKey = typeof settings.releasePublicKey === "string" ? settings.releasePublicKey : (global.AMQ_DATABASE_UPDATE_RELEASE_PUBLIC_KEY || "");
    const releaseKeyId = typeof settings.releaseKeyId === "string" ? settings.releaseKeyId : (global.AMQ_DATABASE_UPDATE_RELEASE_KEY_ID || "");
    const get = id => documentApi && documentApi.getElementById(id);
    const elements = {
      export: get("database-update-export"), file: get("database-update-file"), fileName: get("database-update-file-name"),
      preflight: get("database-update-preflight"), apply: get("database-update-apply"), clear: get("database-update-clear"),
      status: get("database-update-status"), preview: get("database-update-preview"),
      manifestUrl: get("database-update-manifest-url"), checkRemote: get("database-update-check-remote")
    };
    if (!manager || typeof manager.preflight !== "function" || typeof manager.apply !== "function" || typeof manager.clearActive !== "function"
      || typeof exportPackage !== "function" || Object.values(elements).some(element => !element)) {
      return Object.freeze({ ok: false, reason: "database-update-panel-dependencies-missing", dispose() {} });
    }

    let selectedText = null;
    let selectedName = "";
    let checked = null;
    let selectionVersion = 0;
    let busy = false;
    let disposed = false;
    if (defaultManifestUrl) elements.manifestUrl.value = defaultManifestUrl;
    const removers = [];
    function listen(element, eventName, handler) {
      element.addEventListener(eventName, handler);
      removers.push(() => element.removeEventListener(eventName, handler));
    }
    function status(message, isError) {
      elements.status.textContent = message;
      elements.status.dataset.state = isError ? "error" : "ok";
      elements.status.setAttribute("role", isError ? "alert" : "status");
    }
    function resetPreview() {
      checked = null;
      elements.apply.disabled = true;
      elements.preview.replaceChildren();
      elements.preview.hidden = true;
    }
    function addLine(parent, text, tag = "p") {
      const element = documentApi.createElement(tag);
      element.textContent = text;
      parent.append(element);
      return element;
    }
    function renderPreview(result) {
      elements.preview.replaceChildren();
      if (!result || !result.ok) { elements.preview.hidden = true; return; }
      addLine(elements.preview, `更新格式 v${result.formatVersion}；SHA-256 ${result.checksum}`, "p");
      addLine(elements.preview, "來源資料量（作品／歌曲）", "h4");
      addLine(elements.preview, `AMQ：${result.sourceCounts.AMQ.works.toLocaleString()} 作品／${result.sourceCounts.AMQ.songs.toLocaleString()} 首歌曲`);
      addLine(elements.preview, `EMQ：${result.sourceCounts.EMQ.works.toLocaleString()} 作品／${result.sourceCounts.EMQ.songs.toLocaleString()} 首歌曲`);
      if (result.diff) {
        addLine(elements.preview, "與目前曲庫比較（新增／修改／移除）", "h4");
        for (const source of ["AMQ", "EMQ"]) {
          const diff = result.diff[source];
          addLine(elements.preview, `${source} 歌曲：新增 ${diff.songs.added.toLocaleString()}／修改 ${diff.songs.changed.toLocaleString()}／移除 ${diff.songs.removed.toLocaleString()}`);
          addLine(elements.preview, `${source} 作品：新增 ${diff.works.added.toLocaleString()}／修改 ${diff.works.changed.toLocaleString()}／移除 ${diff.works.removed.toLocaleString()}`);
        }
      } else addLine(elements.preview, "無法取得目前曲庫以比較差異；仍已完成更新檔格式、checksum 與完整資料驗證。", "p");
      addLine(elements.preview, "套用會以單一 IndexedDB 交易取代目前的 AMQ／EMQ 更新覆蓋資料。內建原始資產不會被改寫。成功後必須重新載入頁面才會使用新曲庫。", "p");
      elements.preview.hidden = false;
    }
    async function exportCurrent() {
      if (disposed || busy) return;
      busy = true;
      elements.export.disabled = true; elements.file.disabled = true;
      try {
        const result = await exportPackage();
        if (!result || !result.ok) { status(`曲庫更新包匯出失敗：${result && result.reason || "未知錯誤"}`, true); return; }
        const filename = `amq-database-update-${new Date().toISOString().replace(/[:.]/g, "-")}.json`;
        const blob = makeBlob([JSON.stringify(result.envelope)], { type: "application/json;charset=utf-8" });
        const url = createObjectURL(blob);
        const anchor = documentApi.createElement("a");
        anchor.href = url; anchor.download = filename; anchor.hidden = true;
        documentApi.body.append(anchor); anchor.click(); anchor.remove();
        global.setTimeout(() => revokeObjectURL(url), 0);
        status(`已產生完整曲庫更新包：${filename}`, false);
      } catch (error) { status(`曲庫更新包匯出失敗：${error && error.message || "未知錯誤"}`, true); }
      finally { busy = false; elements.export.disabled = false; elements.file.disabled = false; }
    }
    async function readFile() {
      if (disposed || busy) return;
      selectionVersion += 1;
      resetPreview();
      selectedText = null;
      const file = elements.file.files && elements.file.files[0];
      selectedName = file ? file.name : "";
      elements.fileName.textContent = selectedName || "尚未選擇曲庫更新檔。";
      if (!file) { status("請選擇曲庫更新 JSON 檔案。", true); return; }
      if (file.size > 100 * 1024 * 1024) { status("曲庫更新檔超過 100 MB 上限，已拒絕讀取。", true); return; }
      const version = selectionVersion;
      try {
        const contents = await file.text();
        if (disposed || version !== selectionVersion) return;
        selectedText = contents;
        status("檔案已讀取；尚未修改曲庫。請先執行完整預檢。", false);
      } catch (error) {
        if (disposed || version !== selectionVersion) return;
        selectedText = null;
        status(`讀取曲庫更新檔失敗：${error && error.message || "未知錯誤"}`, true);
      }
    }
    function validateManifestUrl(value) {
      let url;
      try { url = new URL(value, global.location && global.location.href); }
      catch (_) { throw new Error("請輸入有效的版本 manifest 網址"); }
      const pageProtocol = global.location && global.location.protocol;
      const localHost = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
      if (url.username || url.password || url.hash) throw new Error("manifest 網址不可包含帳密或 fragment");
      if (url.protocol !== "https:" && !(url.protocol === "http:" && localHost)) throw new Error("線上曲庫更新只允許 HTTPS（localhost 開發環境例外）");
      if (pageProtocol === "https:" && url.protocol !== "https:") throw new Error("HTTPS 頁面不可載入非 HTTPS 更新來源");
      return url;
    }
    async function sha256Hex(bytes) {
      if (!cryptoApi || !cryptoApi.subtle || typeof cryptoApi.subtle.digest !== "function") throw new Error("此環境不支援 SHA-256，已拒絕遠端更新");
      const digest = await cryptoApi.subtle.digest("SHA-256", bytes);
      return [...new Uint8Array(digest)].map(byte => byte.toString(16).padStart(2, "0")).join("");
    }
    function stableStringify(value) {
      if (value === null || typeof value !== "object") return JSON.stringify(value);
      if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
      return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
    }
    function base64Bytes(value) {
      if (typeof value !== "string" || !/^[A-Za-z0-9+/]+={0,2}$/.test(value)) throw new Error("版本簽章或公鑰不是有效 Base64");
      const binary = global.atob(value);
      return Uint8Array.from(binary, character => character.charCodeAt(0));
    }
    async function verifyManifestSignature(manifest) {
      if (!releasePublicKey || !releaseKeyId) throw new Error("尚未設定固定的 Ed25519 發布公鑰，拒絕遠端更新");
      const signature = manifest && manifest.signature;
      if (!signature || signature.algorithm !== "Ed25519" || signature.keyId !== releaseKeyId || typeof signature.value !== "string") {
        throw new Error("版本清單缺少可信任的 Ed25519 簽章或簽章金鑰 ID 不符");
      }
      if (!cryptoApi || !cryptoApi.subtle || typeof cryptoApi.subtle.importKey !== "function" || typeof cryptoApi.subtle.verify !== "function") {
        throw new Error("此環境不支援 Ed25519 簽章驗證，已拒絕遠端更新");
      }
      const unsigned = { ...manifest };
      delete unsigned.signature;
      const key = await cryptoApi.subtle.importKey("spki", base64Bytes(releasePublicKey), { name: "Ed25519" }, false, ["verify"]);
      const valid = await cryptoApi.subtle.verify({ name: "Ed25519" }, key, base64Bytes(signature.value), new TextEncoder().encode(stableStringify(unsigned)));
      if (!valid) throw new Error("版本清單 Ed25519 簽章驗證失敗，拒絕更新");
      return true;
    }
    async function checkRemoteRelease() {
      if (disposed || busy) return;
      resetPreview(); selectedText = null; selectedName = ""; selectionVersion += 1;
      const version = selectionVersion;
      let manifestUrl;
      try { manifestUrl = validateManifestUrl(String(elements.manifestUrl.value || "").trim()); }
      catch (error) { status(`無法檢查更新：${error.message}`, true); return; }
      if (typeof fetchApi !== "function") { status("此環境不支援網路下載，請使用手動匯入。", true); return; }
      busy = true; elements.checkRemote.disabled = true; elements.manifestUrl.disabled = true;
      elements.preflight.disabled = true; elements.file.disabled = true; elements.export.disabled = true; elements.clear.disabled = true;
      status("正在取得版本清單；尚未修改曲庫。", false);
      try {
        const manifestResponse = await fetchApi(manifestUrl.href, { method: "GET", cache: "no-store", credentials: "omit", redirect: "error", headers: { Accept: "application/json" } });
        if (!manifestResponse || !manifestResponse.ok) throw new Error(`版本清單下載失敗（HTTP ${manifestResponse && manifestResponse.status || "unknown"}）`);
        const manifest = await manifestResponse.json();
        await verifyManifestSignature(manifest);
        if (!manifest || manifest.format !== "amq-learning-database-release" || manifest.manifestVersion !== 1
          || typeof manifest.releaseVersion !== "string" || !/^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][0-9A-Za-z.-]+)?$/.test(manifest.releaseVersion)
          || !manifest.bundle || manifest.bundle.format !== "amq-learning-database-update" || manifest.bundle.formatVersion !== 1
          || !Number.isSafeInteger(manifest.bundle.byteLength) || manifest.bundle.byteLength < 1 || manifest.bundle.byteLength > 100 * 1024 * 1024
          || typeof manifest.bundle.sha256 !== "string" || !/^[a-f0-9]{64}$/.test(manifest.bundle.sha256)
          || !Number.isSafeInteger(manifest.minimumAppUpdateFormatVersion) || !Number.isSafeInteger(manifest.maximumAppUpdateFormatVersion)
          || manifest.minimumAppUpdateFormatVersion > 1 || manifest.maximumAppUpdateFormatVersion < 1) {
          throw new Error("版本清單格式、相容版本或更新包資訊不支援");
        }
        if (typeof manifest.bundle.url !== "string" || !manifest.bundle.url || /^[a-z][a-z0-9+.-]*:/i.test(manifest.bundle.url) || manifest.bundle.url.startsWith("//")) {
          throw new Error("更新包網址必須是相對於 manifest 的同來源路徑");
        }
        const bundleUrl = new URL(manifest.bundle.url, manifestUrl);
        if (bundleUrl.origin !== manifestUrl.origin || bundleUrl.username || bundleUrl.password || bundleUrl.hash) throw new Error("更新包必須與版本清單位於相同來源");
        const bundleResponse = await fetchApi(bundleUrl.href, { method: "GET", cache: "no-store", credentials: "omit", redirect: "error", headers: { Accept: "application/json" } });
        if (!bundleResponse || !bundleResponse.ok) throw new Error(`曲庫更新包下載失敗（HTTP ${bundleResponse && bundleResponse.status || "unknown"}）`);
        const declaredLength = Number(bundleResponse.headers && bundleResponse.headers.get("content-length"));
        if (Number.isFinite(declaredLength) && declaredLength > 100 * 1024 * 1024) throw new Error("更新包超過 100 MB 安全上限，拒絕下載");
        const bytes = await bundleResponse.arrayBuffer();
        if (disposed || version !== selectionVersion) return;
        if (bytes.byteLength !== manifest.bundle.byteLength) throw new Error("更新包大小與版本清單不符");
        const actualHash = await sha256Hex(bytes);
        if (actualHash !== manifest.bundle.sha256) throw new Error("更新包 SHA-256 與版本清單不符，拒絕套用");
        const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
        const result = await manager.preflight(text);
        if (disposed || version !== selectionVersion) return;
        if (!result || !result.ok) throw new Error(`完整曲庫預檢失敗：${result && result.reason || "未知錯誤"}`);
        if (manifest.bundle.payloadChecksum && manifest.bundle.payloadChecksum !== result.checksum) throw new Error("更新包 payload checksum 與版本清單不符");
        selectedText = text; selectedName = `release-${manifest.releaseVersion}`; checked = result;
        elements.fileName.textContent = `遠端版本 ${manifest.releaseVersion}（${manifest.bundle.byteLength.toLocaleString()} bytes）`;
        renderPreview(result); elements.apply.disabled = false;
        status(`版本 ${manifest.releaseVersion} 已通過 Ed25519 簽章、SHA-256 與完整曲庫預檢；尚未套用。`, false);
      } catch (error) {
        if (!disposed && version === selectionVersion) { selectedText = null; selectedName = ""; resetPreview(); status(`遠端更新檢查失敗，曲庫未修改：${error && error.message || "未知錯誤"}`, true); }
      } finally {
        busy = false;
        if (!disposed) { elements.checkRemote.disabled = false; elements.manifestUrl.disabled = false; elements.preflight.disabled = false; elements.file.disabled = false; elements.export.disabled = false; elements.clear.disabled = false; }
      }
    }
    async function runPreflight() {
      if (disposed || busy) return;
      resetPreview();
      if (selectedText === null) { status("請先選擇並讀取曲庫更新檔。", true); return; }
      const version = selectionVersion;
      const text = selectedText;
      busy = true; elements.preflight.disabled = true; elements.file.disabled = true;
      status("正在驗證 checksum、來源 schema、作品關聯與所有歌曲記錄；尚未修改資料。", false);
      try {
        const result = await manager.preflight(text);
        if (disposed || version !== selectionVersion || text !== selectedText) return;
        if (!result.ok) { status(`預檢失敗，未修改曲庫：${result.reason}`, true); return; }
        checked = result;
        renderPreview(result);
        elements.apply.disabled = false;
        status(`預檢通過：${selectedName}。尚未套用任何資料。`, false);
      } catch (error) {
        if (disposed || version !== selectionVersion) return;
        status(`預檢失敗，未修改曲庫：${error && error.message || "未知錯誤"}`, true);
      } finally { busy = false; if (!disposed) { elements.preflight.disabled = false; elements.file.disabled = false; } }
    }
    async function applyUpdate() {
      if (disposed || busy) return;
      if (!checked || !checked.ok || selectedText === null) { status("沒有通過預檢的曲庫更新檔。", true); return; }
      const confirmation = confirmApply(`即將以 ${selectedName || "所選更新檔"} 完整取代 AMQ／EMQ 的本機曲庫覆蓋資料。內建原始檔不會修改。此操作不會合併資料，成功後需要重新載入頁面。確認套用？`);
      if (!confirmation) { status("已取消套用；曲庫未修改。", false); return; }
      const input = selectedText;
      const expectedChecksum = checked.checksum;
      busy = true; elements.apply.disabled = true; elements.preflight.disabled = true; elements.export.disabled = true; elements.clear.disabled = true; elements.file.disabled = true;
      try {
        const result = await manager.apply(input, expectedChecksum);
        if (disposed) return;
        if (!result.ok) { status(`套用失敗，未啟用新曲庫：${result.reason}`, true); return; }
        resetPreview(); selectedText = null; selectedName = ""; elements.file.value = ""; elements.fileName.textContent = "尚未選擇曲庫更新檔。";
        status("曲庫更新已安全寫入 IndexedDB。請重新載入頁面，AMQ／EMQ／MIX 才會使用新資料。", false);
      } catch (error) { if (!disposed) status(`套用失敗：${error && error.message || "未知錯誤"}`, true); }
      finally { busy = false; if (!disposed) { elements.apply.disabled = true; elements.preflight.disabled = false; elements.export.disabled = false; elements.clear.disabled = false; elements.file.disabled = false; } }
    }
    async function clearOverride() {
      if (disposed || busy) return;
      if (!confirmApply("移除目前匯入的曲庫覆蓋資料，恢復使用包內建置的 AMQ／EMQ 原始曲庫？此操作不會修改內建資產，成功後需要重新載入頁面。")) {
        status("已取消恢復內建曲庫；資料未修改。", false); return;
      }
      busy = true; elements.clear.disabled = true; elements.apply.disabled = true; elements.preflight.disabled = true; elements.export.disabled = true; elements.file.disabled = true;
      try {
        const result = await manager.clearActive();
        if (!result.ok) { status(`移除曲庫覆蓋失敗：${result.reason}`, true); return; }
        status("已移除匯入曲庫覆蓋。請重新載入頁面以恢復使用內建原始曲庫。", false);
      } catch (error) { status(`移除曲庫覆蓋失敗：${error && error.message || "未知錯誤"}`, true); }
      finally { busy = false; if (!disposed) { elements.clear.disabled = false; elements.preflight.disabled = false; elements.export.disabled = false; elements.file.disabled = false; } }
    }

    listen(elements.export, "click", exportCurrent);
    listen(elements.file, "change", readFile);
    listen(elements.checkRemote, "click", checkRemoteRelease);
    listen(elements.preflight, "click", runPreflight);
    listen(elements.apply, "click", applyUpdate);
    listen(elements.clear, "click", clearOverride);
    return Object.freeze({ ok: true, dispose() { if (disposed) return; disposed = true; selectionVersion += 1; removers.splice(0).forEach(remove => remove()); } });
  }

  global.AMQUI = global.AMQUI || {};
  global.AMQUI.databaseUpdatePanel = Object.freeze({ createDatabaseUpdatePanel });
})(window);
