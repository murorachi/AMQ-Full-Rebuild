/* Transport-neutral server command orchestration; client identity and round metadata are server-derived. */
(function (global) {
  "use strict";
  const CLIENT_COMMANDS = new Set(["player.join", "player.leave", "player.ready", "round.start", "answer.submit", "round.close", "room.close"]);
  function serviceError(code, message, details) {
    const error = new Error(message);
    error.name = "MultiplayerRoomServiceError";
    error.code = code;
    error.details = Object.freeze({ ...(details || {}) });
    return error;
  }
  function cleanPlayerId(value) {
    if (typeof value !== "string" || !value.trim() || value.trim().length > 128) throw serviceError("ROOM_AUTH_REQUIRED", "Authenticated connection must provide a valid player ID");
    return value.trim();
  }
  function serverTime(now) {
    const value = now();
    if (!Number.isFinite(value) || value < 0) throw serviceError("ROOM_SERVER_TIME_INVALID", "Server clock must return a non-negative finite timestamp");
    return value;
  }
  function cleanRequestId(value) {
    if (value === undefined || value === null) return null;
    if (typeof value !== "string" || !value.trim() || value.trim().length > 128) {
      throw serviceError("ROOM_REQUEST_ID_INVALID", "requestId must be a non-empty string up to 128 characters");
    }
    return value.trim();
  }
  function stableJson(value, seen) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return JSON.stringify(value);
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw serviceError("ROOM_COMMAND_INVALID", "Command numbers must be finite");
      return JSON.stringify(value);
    }
    if (typeof value !== "object") throw serviceError("ROOM_COMMAND_INVALID", "Command must contain JSON-compatible values only");
    if (seen.has(value)) throw serviceError("ROOM_COMMAND_INVALID", "Command must not contain circular references");
    if (Object.getOwnPropertySymbols(value).length) throw serviceError("ROOM_COMMAND_INVALID", "Command must not contain symbol properties");
    const prototype = Object.getPrototypeOf(value);
    if (!Array.isArray(value) && prototype !== null && Object.getPrototypeOf(prototype) !== null) {
      throw serviceError("ROOM_COMMAND_INVALID", "Command objects must be plain JSON objects");
    }
    seen.add(value);
    let result;
    if (Array.isArray(value)) {
      const items = [];
      for (let index = 0; index < value.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (!descriptor || !Object.prototype.hasOwnProperty.call(descriptor, "value")) {
          throw serviceError("ROOM_COMMAND_INVALID", "Command arrays must be dense and must not contain accessors");
        }
        items.push(stableJson(descriptor.value, seen));
      }
      if (Object.keys(value).some(key => !/^(0|[1-9]\d*)$/.test(key) || Number(key) >= value.length)) {
        throw serviceError("ROOM_COMMAND_INVALID", "Command arrays must not contain extra properties");
      }
      result = `[${items.join(",")}]`;
    } else {
      const descriptors = Object.getOwnPropertyDescriptors(value);
      const keys = Object.keys(descriptors).filter(key => descriptors[key].enumerable).sort();
      for (const descriptor of Object.values(descriptors)) {
        if (!Object.prototype.hasOwnProperty.call(descriptor, "value")) {
          throw serviceError("ROOM_COMMAND_INVALID", "Command objects must not contain accessor properties");
        }
      }
      result = `{${keys.map(key => `${JSON.stringify(key)}:${stableJson(descriptors[key].value, seen)}`).join(",")}}`;
    }
    seen.delete(value);
    return result;
  }
  function createRoomCommandService(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const machine = deps.roomStateMachine || (global.AMQMultiplayer && global.AMQMultiplayer.roomStateMachine);
    const assessor = deps.assessor;
    const selectQuestion = deps.selectQuestion;
    const createRoundId = deps.createRoundId;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    let lastServerTime = -1;
    function readServerTime() {
      const value = serverTime(now);
      if (value < lastServerTime) {
        throw serviceError("ROOM_SERVER_TIME_REGRESSION", "Server clock must not move backwards during a room service lifetime", { previousAt: lastServerTime, receivedAt: value });
      }
      lastServerTime = value;
      return value;
    }
    const roundDurationMs = deps.roundDurationMs === undefined ? 15000 : deps.roundDurationMs;
    const maxIdempotencyEntries = deps.maxIdempotencyEntries === undefined ? 256 : deps.maxIdempotencyEntries;
    const maxCommandsPerWindow = deps.maxCommandsPerWindow === undefined ? 60 : deps.maxCommandsPerWindow;
    const commandWindowMs = deps.commandWindowMs === undefined ? 10000 : deps.commandWindowMs;
    if (!machine || typeof machine.applyCommand !== "function" || typeof machine.getSnapshot !== "function" || typeof machine.normalizeState !== "function") {
      throw serviceError("ROOM_SERVICE_DEPENDENCIES_MISSING", "Room state machine with state normalization is required");
    }
    if (!assessor || typeof assessor.assessSubmission !== "function" || typeof assessor.hasQuestion !== "function") {
      throw serviceError("ROOM_SERVICE_ASSESSOR_REQUIRED", "Server answer assessor is required");
    }
    if (typeof selectQuestion !== "function" || typeof createRoundId !== "function") {
      throw serviceError("ROOM_SERVICE_ROUND_FACTORY_REQUIRED", "Trusted question selector and round ID factory are required");
    }
    if (!Number.isInteger(roundDurationMs) || roundDurationMs < 1000 || roundDurationMs > 300000) throw serviceError("ROOM_ROUND_DURATION_INVALID", "roundDurationMs must be between 1000 and 300000");
    if (!Number.isInteger(maxIdempotencyEntries) || maxIdempotencyEntries < 0 || maxIdempotencyEntries > 10000) throw serviceError("ROOM_IDEMPOTENCY_CAPACITY_INVALID", "maxIdempotencyEntries must be an integer from 0 to 10000");
    if (!Number.isInteger(maxCommandsPerWindow) || maxCommandsPerWindow < 1 || maxCommandsPerWindow > 100000) throw serviceError("ROOM_RATE_LIMIT_CONFIG_INVALID", "maxCommandsPerWindow must be an integer from 1 to 100000");
    if (!Number.isInteger(commandWindowMs) || commandWindowMs < 100 || commandWindowMs > 600000) throw serviceError("ROOM_RATE_LIMIT_CONFIG_INVALID", "commandWindowMs must be an integer from 100 to 600000 milliseconds");
    const idempotency = new Map();
    const commandTimesByPlayer = new Map();
    let state;
    try { state = machine.normalizeState(deps.initialState); }
    catch (error) {
      throw serviceError("ROOM_STATE_INVALID", "Initial room state failed structural validation", { causeCode: error && error.code || "UNKNOWN" });
    }

    function authenticatedPlayer(authContext) {
      if (!authContext || authContext.authenticated !== true) throw serviceError("ROOM_AUTH_REQUIRED", "An authenticated connection is required");
      return cleanPlayerId(authContext.playerId);
    }
    function dispatchOnce(authContext, clientCommand, at) {
      const playerId = authenticatedPlayer(authContext);
      if (!clientCommand || typeof clientCommand !== "object" || Array.isArray(clientCommand)) throw serviceError("ROOM_COMMAND_INVALID", "Client command must be an object");
      const type = clientCommand.type;
      if (!CLIENT_COMMANDS.has(type)) throw serviceError("ROOM_COMMAND_NOT_ALLOWED", "Command is not exposed to clients", { type });
      const base = { type, actorId: playerId };
      if (clientCommand.expectedRevision !== undefined) base.expectedRevision = clientCommand.expectedRevision;
      if (type === "player.join") base.displayName = clientCommand.displayName;
      if (type === "player.ready") base.ready = clientCommand.ready;
      if (type === "player.leave" || type === "room.close" || type === "round.close") {
        // No additional client fields are trusted for these commands.
      } else if (type === "round.start") {
        if (state.hostId !== playerId) throw serviceError("ROOM_HOST_REQUIRED", "Only the current room host may start a round");
        if (state.phase !== "lobby") throw serviceError("ROOM_ROUND_ACTIVE", "A round is already active");
        if (clientCommand.expectedRevision !== undefined && clientCommand.expectedRevision !== state.revision) {
          throw serviceError("ROOM_REVISION_CONFLICT", "Room revision is stale; request a fresh snapshot", { expectedRevision: clientCommand.expectedRevision, actualRevision: state.revision });
        }
        // Fail predictable state-machine preconditions before invoking injected factories,
        // which may consume a question pool cursor or a unique round ID.
        if (state.players.length < 2) throw serviceError("ROOM_NEEDS_PLAYERS", "At least two players are required to start a round");
        const unready = state.players.filter(item => item.id !== state.hostId && !item.ready).map(item => item.id);
        if (unready.length) throw serviceError("ROOM_PLAYERS_NOT_READY", "All non-host players must be ready", { playerIds: unready });
        const selected = selectQuestion(Object.freeze({ roomId: state.roomId, revision: state.revision, phase: state.phase, playerId }));
        if (!selected || typeof selected !== "object" || typeof selected.questionId !== "string" || !assessor.hasQuestion(selected.questionId)) {
          throw serviceError("ROOM_QUESTION_SELECTION_INVALID", "Trusted selector must return a known server-owned questionId");
        }
        const roundId = createRoundId(Object.freeze({ roomId: state.roomId, revision: state.revision, playerId, at }));
        if (typeof roundId !== "string" || !roundId.trim()) throw serviceError("ROOM_ROUND_ID_INVALID", "Server round ID factory must return a non-empty string");
        base.roundId = roundId;
        base.questionId = selected.questionId;
        base.durationMs = roundDurationMs;
      } else if (type === "answer.submit") {
        const before = state;
        const transition = machine.applyCommand(before, { ...base, roundId: clientCommand.roundId, answer: clientCommand.answer }, { now: at });
        const assessment = assessor.assessSubmission({ questionId: before.currentRound && before.currentRound.questionId, answer: clientCommand.answer }, {
          outcome: "answered", startedAt: before.currentRound && before.currentRound.startedAt, receivedAt: at
        });
        state = transition.state;
        return Object.freeze({ event: transition.event, snapshot: machine.getSnapshot(state, undefined, playerId), assessment });
      } else {
        // Deliberately ignore client questionId, roundId and durationMs during round.start.
      }
      const transition = machine.applyCommand(state, base, { now: at });
      state = transition.state;
      // A successful leave removes the caller from membership, so its identity can no
      // longer authorize a viewer-specific snapshot of the resulting room state.
      const viewerId = type === "player.leave" ? undefined : playerId;
      return Object.freeze({ event: transition.event, snapshot: machine.getSnapshot(state, undefined, viewerId) });
    }
    function enforceCommandRateLimit(playerId, at) {
      const cutoff = at - commandWindowMs;
      for (const [id, entries] of commandTimesByPlayer) {
        if (!entries.length || entries[entries.length - 1] <= cutoff) commandTimesByPlayer.delete(id);
      }
      const timestamps = (commandTimesByPlayer.get(playerId) || []).filter(timestamp => timestamp > cutoff);
      if (timestamps.length >= maxCommandsPerWindow) {
        commandTimesByPlayer.set(playerId, timestamps);
        throw serviceError("ROOM_RATE_LIMITED", "Too many room commands; retry after the current rate-limit window", {
          retryAfterMs: Math.max(1, timestamps[0] + commandWindowMs - at),
          limit: maxCommandsPerWindow,
          windowMs: commandWindowMs
        });
      }
      timestamps.push(at);
      commandTimesByPlayer.set(playerId, timestamps);
    }
    function dispatch(authContext, clientCommand) {
      const playerId = authenticatedPlayer(authContext);
      if (!clientCommand || typeof clientCommand !== "object" || Array.isArray(clientCommand)) throw serviceError("ROOM_COMMAND_INVALID", "Client command must be an object");
      // Commands are transport JSON: detach and validate before reading any property so
      // requestId/type/other getters cannot execute before canonicalization.
      try { clientCommand = JSON.parse(stableJson(clientCommand, new Set())); }
      catch (error) {
        if (error && error.code === "ROOM_COMMAND_INVALID") throw error;
        throw serviceError("ROOM_COMMAND_INVALID", "Command could not be canonicalized as JSON");
      }
      const requestId = cleanRequestId(clientCommand.requestId);
      if (requestId !== null) clientCommand.requestId = requestId;
      let key = null;
      let fingerprint = null;
      if (requestId !== null && maxIdempotencyEntries > 0) {
        key = JSON.stringify([playerId, requestId]);
        fingerprint = stableJson(clientCommand, new Set());
        const existing = idempotency.get(key);
        if (existing) {
          if (existing.fingerprint !== fingerprint) {
            enforceCommandRateLimit(playerId, readServerTime());
            throw serviceError("ROOM_REQUEST_ID_REUSED", "requestId was already used for a different command", { requestId });
          }
          const replayResult = { ...existing.result };
          // Preserve the original event/assessment for idempotency, but refresh a
          // viewer snapshot while the authenticated caller is still a member. A
          // former member replaying player.leave keeps the original non-authorized
          // snapshot instead of receiving fresh room state after leaving.
          if (state.players.some(player => player.id === playerId)) {
            replayResult.snapshot = machine.getSnapshot(state, undefined, playerId);
          }
          return Object.freeze({ ...replayResult, replayed: true });
        }
      }
      // Use one authoritative timestamp for both quota accounting and the state transition.
      // Reading the clock twice can split a single command across deadline/window boundaries.
      const at = readServerTime();
      enforceCommandRateLimit(playerId, at);
      const result = dispatchOnce(authContext, clientCommand, at);
      if (key !== null) {
        idempotency.set(key, { fingerprint, result });
        while (idempotency.size > maxIdempotencyEntries) idempotency.delete(idempotency.keys().next().value);
        return Object.freeze({ ...result, replayed: false });
      }
      return result;
    }
    function expireRound() {
      const at = readServerTime();
      if (state.phase !== "round" || !state.currentRound || state.currentRound.status !== "active") throw serviceError("ROOM_NO_ACTIVE_ROUND", "There is no active round to expire");
      if (at < state.currentRound.deadlineAt) throw serviceError("ROOM_ANSWER_DEADLINE_NOT_REACHED", "Cannot expire the round before its server deadline", { deadlineAt: state.currentRound.deadlineAt, now: at });
      const before = state;
      const answered = new Set(before.currentRound.answers.map(answer => answer.playerId));
      const timeoutAssessments = before.players.filter(player => !answered.has(player.id)).map(player => Object.freeze({
        playerId: player.id,
        ...assessor.assessSubmission({ questionId: before.currentRound.questionId }, {
          outcome: "timeout", startedAt: before.currentRound.startedAt, receivedAt: before.currentRound.deadlineAt
        })
      }));
      const transition = machine.applyCommand(before, { type: "round.timeout", actorId: before.hostId }, { now: at });
      state = transition.state;
      return Object.freeze({ event: transition.event, snapshot: machine.getSnapshot(state), timeoutAssessments: Object.freeze(timeoutAssessments) });
    }
    function getSnapshot(authContext, sinceRevision) {
      const playerId = authenticatedPlayer(authContext);
      return machine.getSnapshot(state, sinceRevision, playerId);
    }
    return Object.freeze({ dispatch, expireRound, getSnapshot, exportState() { return machine.normalizeState(state); }, get revision() { return state.revision; } });
  }
  global.AMQMultiplayer = global.AMQMultiplayer || {};
  global.AMQMultiplayer.roomCommandService = Object.freeze({ createRoomCommandService });
})(typeof window !== "undefined" ? window : globalThis);
