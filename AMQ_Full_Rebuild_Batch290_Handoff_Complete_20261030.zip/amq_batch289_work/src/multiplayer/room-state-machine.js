/* Pure server-authoritative room state transitions. No transport, DOM, or client trust. */
(function (global) {
  "use strict";
  const SCHEMA_VERSION = 1;
  const MAX_ID_LENGTH = 128;
  const MAX_DISPLAY_NAME_LENGTH = 64;
  const MAX_ANSWER_LENGTH = 256;
  const DEFAULT_MAX_PLAYERS = 8;

  function roomError(code, message, details) {
    const error = new Error(message);
    error.name = "MultiplayerRoomError";
    error.code = code;
    error.details = Object.freeze({ ...(details || {}) });
    return error;
  }
  function cleanString(value, field, maxLength) {
    if (typeof value !== "string" || !value.trim() || value.trim().length > maxLength) {
      throw roomError("ROOM_INPUT_INVALID", `${field} must be a non-empty string up to ${maxLength} characters`, { field });
    }
    return value.trim();
  }
  function cleanNow(now) {
    const value = typeof now === "function" ? now() : now;
    if (!Number.isFinite(value) || value < 0) throw roomError("ROOM_TIME_INVALID", "Server time must be a non-negative finite number");
    return value;
  }
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function deepFreeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    Object.keys(value).forEach(key => deepFreeze(value[key]));
    return Object.freeze(value);
  }
  function publish(state, event) {
    state.revision += 1;
    state.updatedAt = event.at;
    return Object.freeze({ state: deepFreeze(state), event: deepFreeze(event) });
  }
  function cloneJsonValue(value, seen) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number") {
      if (!Number.isFinite(value)) throw roomError("ROOM_STATE_INVALID", "Room state numbers must be finite");
      return value;
    }
    if (typeof value !== "object") throw roomError("ROOM_STATE_INVALID", "Room state must contain JSON-compatible values only");
    if (seen.has(value)) throw roomError("ROOM_STATE_INVALID", "Room state must not contain circular references");
    const prototype = Object.getPrototypeOf(value);
    if (!Array.isArray(value) && prototype !== null && Object.getPrototypeOf(prototype) !== null) throw roomError("ROOM_STATE_INVALID", "Room state objects must be plain JSON objects");
    if (Object.getOwnPropertySymbols(value).length) throw roomError("ROOM_STATE_INVALID", "Room state must not contain symbol properties");
    seen.add(value);
    let result;
    if (Array.isArray(value)) {
      result = [];
      for (let index = 0; index < value.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (!descriptor || !Object.prototype.hasOwnProperty.call(descriptor, "value")) throw roomError("ROOM_STATE_INVALID", "Room state arrays must not contain holes or accessor items");
        result.push(cloneJsonValue(descriptor.value, seen));
      }
      if (Object.keys(value).some(key => !/^(0|[1-9]\d*)$/.test(key) || Number(key) >= value.length)) throw roomError("ROOM_STATE_INVALID", "Room state arrays must not contain extra properties");
    } else {
      result = {};
      const descriptors = Object.getOwnPropertyDescriptors(value);
      for (const key of Object.keys(descriptors)) {
        const descriptor = descriptors[key];
        if (!descriptor.enumerable) continue;
        if (!Object.prototype.hasOwnProperty.call(descriptor, "value")) throw roomError("ROOM_STATE_INVALID", "Room state must not contain accessor properties");
        result[key] = cloneJsonValue(descriptor.value, seen);
      }
    }
    seen.delete(value);
    return result;
  }
  function validTimestamp(value) { return Number.isFinite(value) && value >= 0; }
  function normalizeState(value) {
    let state;
    try { state = cloneJsonValue(value, new Set()); }
    catch (error) {
      if (error && error.code === "ROOM_STATE_INVALID") throw error;
      throw roomError("ROOM_STATE_INVALID", "Room state could not be detached safely");
    }
    const invalid = message => { throw roomError("ROOM_STATE_INVALID", message); };
    if (!state || Array.isArray(state) || state.schemaVersion !== SCHEMA_VERSION) invalid("Unsupported or missing room state schemaVersion");
    if (typeof state.roomId !== "string" || !state.roomId.trim() || state.roomId.length > MAX_ID_LENGTH || typeof state.hostId !== "string" || !state.hostId.trim() || state.hostId.length > MAX_ID_LENGTH) invalid("Room state requires valid roomId and hostId");
    if (!Number.isInteger(state.maxPlayers) || state.maxPlayers < 2 || state.maxPlayers > 64) invalid("Room state maxPlayers is invalid");
    if (!Number.isSafeInteger(state.revision) || state.revision < 0) invalid("Room state revision is invalid");
    if (!new Set(["lobby", "round", "closed"]).has(state.phase)) invalid("Room state phase is invalid");
    if (!validTimestamp(state.createdAt) || !validTimestamp(state.updatedAt)) invalid("Room state timestamps are invalid");
    if (!Array.isArray(state.players) || state.players.length > state.maxPlayers || (state.phase !== "closed" && state.players.length === 0)) invalid("Room state players are invalid for its capacity or phase");
    const playerIds = new Set();
    let hostCount = 0;
    for (const player of state.players) {
      if (!player || Array.isArray(player) || typeof player !== "object") invalid("Room state contains an invalid player");
      if (typeof player.id !== "string" || !player.id.trim() || player.id.length > MAX_ID_LENGTH || playerIds.has(player.id)) invalid("Room state player IDs must be valid and unique");
      if (typeof player.displayName !== "string" || !player.displayName.trim() || player.displayName.length > MAX_DISPLAY_NAME_LENGTH) invalid("Room state player displayName is invalid");
      if (typeof player.ready !== "boolean" || !validTimestamp(player.joinedAt)) invalid("Room state player readiness or joinedAt is invalid");
      if (player.role !== (player.id === state.hostId ? "host" : "player")) invalid("Room state player role does not match hostId");
      if (player.role === "host") hostCount += 1;
      playerIds.add(player.id);
    }
    if (state.players.length ? (!playerIds.has(state.hostId) || hostCount !== 1) : state.phase !== "closed") invalid("Room state host membership is inconsistent");
    if (!Array.isArray(state.usedRoundIds)) invalid("Room state usedRoundIds must be an array");
    const usedRoundIds = new Set();
    for (const id of state.usedRoundIds) {
      if (typeof id !== "string" || !id.trim() || id.length > MAX_ID_LENGTH || usedRoundIds.has(id)) invalid("Room state usedRoundIds must contain unique valid IDs");
      usedRoundIds.add(id);
    }
    const round = state.currentRound;
    if (round !== null) {
      if (!round || Array.isArray(round) || typeof round !== "object") invalid("Room state currentRound is invalid");
      if (typeof round.id !== "string" || !round.id.trim() || round.id.length > MAX_ID_LENGTH || !usedRoundIds.has(round.id)) invalid("Room state currentRound ID must be in usedRoundIds");
      if (typeof round.questionId !== "string" || !round.questionId.trim() || round.questionId.length > MAX_ID_LENGTH) invalid("Room state currentRound questionId is invalid");
      if (!validTimestamp(round.startedAt) || !validTimestamp(round.deadlineAt) || !Number.isInteger(round.durationMs) || round.durationMs < 1000 || round.durationMs > 300000 || round.deadlineAt !== round.startedAt + round.durationMs) invalid("Room state currentRound timing is invalid");
      if (!new Set(["active", "closed"]).has(round.status) || !Array.isArray(round.answers)) invalid("Room state currentRound status or answers is invalid");
      if ((state.phase === "round") !== (round.status === "active")) invalid("Room phase and currentRound status are inconsistent");
      if (round.status === "closed" && (!validTimestamp(round.closedAt) || !new Set(["host", "timeout"]).has(round.closeReason))) invalid("Closed round must include valid close metadata");
      if (round.status === "active" && (round.closedAt !== undefined || round.closeReason !== undefined)) invalid("Active round must not contain close metadata");
      const answeredPlayers = new Set();
      for (const answer of round.answers) {
        if (!answer || Array.isArray(answer) || typeof answer !== "object") invalid("Room state contains an invalid answer");
        if (typeof answer.playerId !== "string" || !answer.playerId.trim() || answeredPlayers.has(answer.playerId)) invalid("Room state answer player IDs must be valid and unique");
        if (typeof answer.answer !== "string" || !answer.answer.trim() || answer.answer.length > MAX_ANSWER_LENGTH || !validTimestamp(answer.receivedAt) || answer.receivedAt < round.startedAt || answer.receivedAt >= round.deadlineAt) invalid("Room state answer payload or receipt time is invalid");
        if (round.status === "active" && !playerIds.has(answer.playerId)) invalid("Active round answer must belong to a current room member");
        answeredPlayers.add(answer.playerId);
      }
    } else if (state.phase === "round") invalid("Round phase requires an active currentRound");
    return deepFreeze(state);
  }
  function findPlayer(state, playerId) { return state.players.find(player => player.id === playerId); }
  function requirePlayer(state, playerId) {
    const player = findPlayer(state, playerId);
    if (!player) throw roomError("ROOM_PLAYER_NOT_MEMBER", "Player is not a member of this room", { playerId });
    return player;
  }
  function requireHost(state, playerId) {
    requirePlayer(state, playerId);
    if (state.hostId !== playerId) throw roomError("ROOM_HOST_REQUIRED", "Only the current room host may perform this action", { playerId });
  }
  function checkRevision(state, expectedRevision) {
    if (expectedRevision !== undefined && expectedRevision !== state.revision) {
      throw roomError("ROOM_REVISION_CONFLICT", "Room revision is stale; request a fresh snapshot", { expectedRevision, actualRevision: state.revision });
    }
  }
  function createRoom(options) {
    const opts = options && typeof options === "object" ? options : {};
    const roomId = cleanString(opts.roomId, "roomId", MAX_ID_LENGTH);
    const hostId = cleanString(opts.hostId, "hostId", MAX_ID_LENGTH);
    const hostName = cleanString(opts.hostName || hostId, "hostName", MAX_DISPLAY_NAME_LENGTH);
    const maxPlayers = opts.maxPlayers === undefined ? DEFAULT_MAX_PLAYERS : opts.maxPlayers;
    if (!Number.isInteger(maxPlayers) || maxPlayers < 2 || maxPlayers > 64) throw roomError("ROOM_CAPACITY_INVALID", "maxPlayers must be an integer from 2 to 64");
    const now = cleanNow(opts.now === undefined ? Date.now : opts.now);
    return deepFreeze({
      schemaVersion: SCHEMA_VERSION, roomId, hostId, maxPlayers, revision: 0, phase: "lobby",
      createdAt: now, updatedAt: now,
      players: [{ id: hostId, displayName: hostName, role: "host", ready: false, joinedAt: now }],
      currentRound: null, usedRoundIds: []
    });
  }
  function applyCommand(currentState, command, options) {
    if (!currentState || currentState.schemaVersion !== SCHEMA_VERSION || !Array.isArray(currentState.players)) {
      throw roomError("ROOM_STATE_INVALID", "Room state was not created by this state machine");
    }
    if (!command || typeof command !== "object" || Array.isArray(command)) throw roomError("ROOM_COMMAND_INVALID", "Room command must be an object");
    const state = clone(currentState);
    const type = command.type;
    const actorId = cleanString(command.actorId, "actorId", MAX_ID_LENGTH);
    const now = cleanNow(options && options.now !== undefined ? options.now : Date.now);
    checkRevision(state, command.expectedRevision);
    if (state.revision >= Number.MAX_SAFE_INTEGER) throw roomError("ROOM_REVISION_EXHAUSTED", "Room revision has reached the maximum safe integer");
    if (state.phase === "closed") throw roomError("ROOM_CLOSED", "Room is closed");

    if (type === "player.join") {
      const playerId = actorId;
      if (findPlayer(state, playerId)) throw roomError("ROOM_PLAYER_ALREADY_MEMBER", "Player already belongs to this room", { playerId });
      if (state.phase !== "lobby") throw roomError("ROOM_ROUND_ACTIVE", "Players cannot join while a round is active");
      if (state.players.length >= state.maxPlayers) throw roomError("ROOM_FULL", "Room has reached its player limit", { maxPlayers: state.maxPlayers });
      const displayName = cleanString(command.displayName || playerId, "displayName", MAX_DISPLAY_NAME_LENGTH);
      state.players.push({ id: playerId, displayName, role: "player", ready: false, joinedAt: now });
      return publish(state, { type, roomId: state.roomId, playerId, at: now });
    }

    const player = requirePlayer(state, actorId);
    if (type === "player.leave") {
      if (state.phase === "round") throw roomError("ROOM_ROUND_ACTIVE", "A player cannot leave while a round is active");
      state.players = state.players.filter(item => item.id !== actorId);
      let hostChanged = false;
      if (actorId === state.hostId) {
        if (state.players.length) {
          state.players.sort((a, b) => a.joinedAt - b.joinedAt || (a.id < b.id ? -1 : a.id > b.id ? 1 : 0));
          state.hostId = state.players[0].id;
          state.players.forEach(item => { item.role = item.id === state.hostId ? "host" : "player"; });
          hostChanged = true;
        } else state.phase = "closed";
      }
      return publish(state, { type, roomId: state.roomId, playerId: actorId, hostId: state.hostId, hostChanged, at: now });
    }
    if (type === "player.ready") {
      if (state.phase !== "lobby") throw roomError("ROOM_ROUND_ACTIVE", "Ready state can only change in the lobby");
      if (typeof command.ready !== "boolean") throw roomError("ROOM_COMMAND_INVALID", "ready must be a boolean");
      if (player.ready === command.ready) return Object.freeze({ state: currentState, event: Object.freeze({ type: "noop", reason: "ready-unchanged", at: now }), unchanged: true });
      player.ready = command.ready;
      return publish(state, { type, roomId: state.roomId, playerId: actorId, ready: command.ready, at: now });
    }
    if (type === "round.start") {
      requireHost(state, actorId);
      if (state.phase !== "lobby") throw roomError("ROOM_ROUND_ACTIVE", "A round is already active");
      const roundId = cleanString(command.roundId, "roundId", MAX_ID_LENGTH);
      if (state.usedRoundIds.includes(roundId)) throw roomError("ROOM_ROUND_ID_REUSED", "Round IDs cannot be reused in a room", { roundId });
      if (state.players.length < 2) throw roomError("ROOM_NEEDS_PLAYERS", "At least two players are required to start a round");
      const unready = state.players.filter(item => item.id !== state.hostId && !item.ready).map(item => item.id);
      if (unready.length) throw roomError("ROOM_PLAYERS_NOT_READY", "All non-host players must be ready", { playerIds: unready });
      const durationMs = command.durationMs === undefined ? 15000 : command.durationMs;
      if (!Number.isInteger(durationMs) || durationMs < 1000 || durationMs > 300000) throw roomError("ROOM_ROUND_DURATION_INVALID", "durationMs must be between 1000 and 300000");
      const questionId = cleanString(command.questionId, "questionId", MAX_ID_LENGTH);
      state.phase = "round";
      state.usedRoundIds.push(roundId);
      state.currentRound = { id: roundId, questionId, startedAt: now, deadlineAt: now + durationMs, durationMs, status: "active", answers: [] };
      state.players.forEach(item => { item.ready = false; });
      return publish(state, { type, roomId: state.roomId, roundId, questionId, startedAt: now, deadlineAt: now + durationMs, at: now });
    }
    if (type === "answer.submit") {
      if (state.phase !== "round" || !state.currentRound || state.currentRound.status !== "active") throw roomError("ROOM_NO_ACTIVE_ROUND", "There is no active round");
      if (now >= state.currentRound.deadlineAt) throw roomError("ROOM_ANSWER_DEADLINE_PASSED", "The answer deadline has passed", { deadlineAt: state.currentRound.deadlineAt, receivedAt: now });
      const roundId = cleanString(command.roundId, "roundId", MAX_ID_LENGTH);
      if (roundId !== state.currentRound.id) throw roomError("ROOM_ROUND_MISMATCH", "Answer belongs to a different round", { expectedRoundId: state.currentRound.id, receivedRoundId: roundId });
      if (state.currentRound.answers.some(answer => answer.playerId === actorId)) throw roomError("ROOM_ANSWER_DUPLICATE", "Each player may submit only one answer per round", { playerId: actorId, roundId });
      const answer = cleanString(command.answer, "answer", MAX_ANSWER_LENGTH);
      state.currentRound.answers.push({ playerId: actorId, answer, receivedAt: now });
      return publish(state, { type, roomId: state.roomId, roundId, playerId: actorId, receivedAt: now, at: now });
    }
    if (type === "round.close" || type === "round.timeout") {
      requireHost(state, actorId);
      if (state.phase !== "round" || !state.currentRound || state.currentRound.status !== "active") throw roomError("ROOM_NO_ACTIVE_ROUND", "There is no active round");
      if (type === "round.timeout" && now < state.currentRound.deadlineAt) throw roomError("ROOM_ANSWER_DEADLINE_NOT_REACHED", "Round timeout cannot be applied before the server deadline", { deadlineAt: state.currentRound.deadlineAt, now });
      state.currentRound.status = "closed";
      state.currentRound.closedAt = now;
      state.currentRound.closeReason = type === "round.timeout" ? "timeout" : "host";
      state.phase = "lobby";
      return publish(state, { type, roomId: state.roomId, roundId: state.currentRound.id, closedAt: now, at: now });
    }
    if (type === "room.close") {
      requireHost(state, actorId);
      if (state.phase === "round") throw roomError("ROOM_ROUND_ACTIVE", "Close the active round before closing the room");
      state.phase = "closed";
      return publish(state, { type, roomId: state.roomId, at: now });
    }
    throw roomError("ROOM_COMMAND_UNKNOWN", "Unknown room command", { type });
  }
  function projectSnapshot(state, viewerPlayerId) {
    const snapshot = clone(state);
    if (snapshot.currentRound && snapshot.currentRound.status === "active") {
      snapshot.currentRound.answers = snapshot.currentRound.answers.map(answer => {
        if (viewerPlayerId && answer.playerId === viewerPlayerId) return answer;
        return { playerId: answer.playerId, receivedAt: answer.receivedAt, submitted: true };
      });
    }
    return snapshot;
  }
  function getSnapshot(state, sinceRevision, authenticatedViewerId) {
    if (!state || state.schemaVersion !== SCHEMA_VERSION || !Number.isSafeInteger(state.revision)) throw roomError("ROOM_STATE_INVALID", "Cannot snapshot invalid room state");
    if (sinceRevision !== undefined && (!Number.isSafeInteger(sinceRevision) || sinceRevision < 0)) throw roomError("ROOM_REVISION_INVALID", "sinceRevision must be a non-negative safe integer");
    if (authenticatedViewerId !== undefined && !findPlayer(state, cleanString(authenticatedViewerId, "authenticatedViewerId", MAX_ID_LENGTH))) throw roomError("ROOM_PLAYER_NOT_MEMBER", "Snapshot viewer is not a room member", { playerId: authenticatedViewerId });
    if (sinceRevision === state.revision) return deepFreeze({ schemaVersion: SCHEMA_VERSION, roomId: state.roomId, revision: state.revision, unchanged: true });
    return deepFreeze({ schemaVersion: SCHEMA_VERSION, roomId: state.roomId, revision: state.revision, unchanged: false, state: projectSnapshot(state, authenticatedViewerId) });
  }
  global.AMQMultiplayer = global.AMQMultiplayer || {};
  global.AMQMultiplayer.roomStateMachine = Object.freeze({ version: SCHEMA_VERSION, defaultMaxPlayers: DEFAULT_MAX_PLAYERS, createRoom, normalizeState, applyCommand, getSnapshot });
})(typeof window !== "undefined" ? window : globalThis);
