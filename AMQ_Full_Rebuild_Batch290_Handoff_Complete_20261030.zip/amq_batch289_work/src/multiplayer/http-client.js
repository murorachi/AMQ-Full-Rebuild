/* Authenticated HTTP client for the single-process multiplayer room API. */
(function (global) {
  "use strict";
  function clientError(code, message, status, details) {
    const error = new Error(message || code);
    error.name = "MultiplayerHttpError";
    error.code = code;
    error.status = Number.isInteger(status) ? status : 0;
    error.details = Object.freeze({ ...(details || {}) });
    return error;
  }
  function validRoomId(value) {
    if (typeof value !== "string" || !/^[A-Fa-f0-9]{12}$/.test(value.trim())) throw clientError("ROOM_ID_INVALID", "房間代碼格式無效。", 0);
    return value.trim().toUpperCase();
  }
  function createHttpClient(options) {
    const opts = options && typeof options === "object" ? options : {};
    const fetchImpl = typeof opts.fetch === "function" ? opts.fetch : global.fetch;
    const baseUrl = typeof opts.baseUrl === "string" ? opts.baseUrl.replace(/\/$/, "") : "";
    const makeRequestId = typeof opts.createRequestId === "function" ? opts.createRequestId : () => {
      if (global.crypto && typeof global.crypto.randomUUID === "function") return global.crypto.randomUUID();
      return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}-${Math.random().toString(36).slice(2)}`;
    };
    if (typeof fetchImpl !== "function") throw new TypeError("fetch implementation is required");

    async function request(path, init) {
      const config = { method: "GET", credentials: "same-origin", headers: { Accept: "application/json" }, ...(init || {}) };
      if (config.body !== undefined) {
        config.headers = { Accept: "application/json", "Content-Type": "application/json", ...(config.headers || {}) };
        config.body = JSON.stringify(config.body);
      }
      let response;
      try { response = await fetchImpl(`${baseUrl}${path}`, config); }
      catch (cause) {
        if (cause && cause.name === "AbortError") throw cause;
        throw clientError("MULTIPLAYER_NETWORK_ERROR", "多人伺服器連線失敗。", 0, { cause: cause && cause.message });
      }
      let payload = null;
      try { payload = await response.json(); } catch (_) { /* handled as invalid response below */ }
      if (!response || !Number.isInteger(response.status)) throw clientError("MULTIPLAYER_RESPONSE_INVALID", "多人伺服器回應格式無效。", 0);
      if (!response.ok) {
        const bodyError = payload && payload.error;
        throw clientError(bodyError && bodyError.code || "MULTIPLAYER_HTTP_ERROR", bodyError && bodyError.message || `多人伺服器回傳 HTTP ${response.status}。`, response.status, bodyError && bodyError.details);
      }
      if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw clientError("MULTIPLAYER_RESPONSE_INVALID", "多人伺服器回應不是有效 JSON 物件。", response.status);
      return payload;
    }
    function command(roomId, type, fields) {
      const id = validRoomId(roomId);
      if (typeof type !== "string" || !type.trim()) throw clientError("ROOM_COMMAND_INVALID", "房間命令類型無效。", 0);
      return request(`/api/multiplayer/rooms/${id}/commands`, { method: "POST", body: { ...(fields || {}), type, requestId: (fields && fields.requestId) || makeRequestId() } });
    }
    return Object.freeze({
      listRooms(options) { return request("/api/multiplayer/rooms", { signal: options && options.signal }).then(result => {
        if (!Array.isArray(result.rooms)) throw clientError("MULTIPLAYER_RESPONSE_INVALID", "房間清單格式無效。", 200);
        return result.rooms;
      }); },
      createRoom(input) { return request("/api/multiplayer/rooms", { method: "POST", body: input || {} }); },
      joinRoom(roomId, input) {
        const id = validRoomId(roomId);
        const fields = { ...(input || {}), requestId: (input && input.requestId) || makeRequestId() };
        return request(`/api/multiplayer/rooms/${id}/join`, { method: "POST", body: fields });
      },
      getSnapshot(roomId, options) {
        const id = validRoomId(roomId);
        const config = options || {};
        const query = Number.isSafeInteger(config.sinceRevision) && config.sinceRevision >= 0 ? `?sinceRevision=${config.sinceRevision}` : "";
        return request(`/api/multiplayer/rooms/${id}${query}`, { signal: config.signal });
      },
      command,
      setReady(roomId, ready, fields) {
        if (typeof ready !== "boolean") throw clientError("ROOM_COMMAND_INVALID", "ready 必須是布林值。", 0);
        return command(roomId, "player.ready", { ...(fields || {}), ready });
      },
      startRound(roomId, fields) { return command(roomId, "round.start", fields); },
      submitAnswer(roomId, answer, fields) {
        if (typeof answer !== "string") throw clientError("ROOM_COMMAND_INVALID", "答案必須是文字。", 0);
        return command(roomId, "answer.submit", { ...(fields || {}), answer });
      },
      leaveRoom(roomId, fields) { return command(roomId, "player.leave", fields); },
      closeRoom(roomId, fields) { return command(roomId, "room.close", fields); }
    });
  }
  global.AMQMultiplayer = global.AMQMultiplayer || {};
  global.AMQMultiplayer.httpClient = Object.freeze({ createHttpClient });
})(typeof window !== "undefined" ? window : globalThis);
