/* Owns one authenticated room view, its polling lifecycle, and safe command retries. */
(function (global) {
  "use strict";

  function roomError(code, message, details) {
    const error = new Error(message);
    error.name = "MultiplayerRoomSessionError";
    error.code = code;
    error.details = Object.freeze({ ...(details || {}) });
    return error;
  }
  function freezeCopy(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    Object.keys(value).forEach(key => freezeCopy(value[key]));
    return Object.freeze(value);
  }
  function createRoomSession(options) {
    const opts = options && typeof options === "object" ? options : {};
    const client = opts.client;
    const timers = opts.timers || global;
    const pollIntervalMs = Number.isFinite(opts.pollIntervalMs) ? Math.max(50, opts.pollIntervalMs) : 1000;
    const maxRetryMs = Number.isFinite(opts.maxRetryMs) ? Math.max(pollIntervalMs, opts.maxRetryMs) : 15000;
    const createRequestId = typeof opts.createRequestId === "function" ? opts.createRequestId : () => {
      if (global.crypto && typeof global.crypto.randomUUID === "function") return global.crypto.randomUUID();
      return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
    };
    if (!client || typeof client.getSnapshot !== "function" || typeof client.command !== "function") throw new TypeError("multiplayer HTTP client is required");
    let roomId = null;
    let snapshot = null;
    let timeoutAssessment = null;
    let status = "idle";
    let lastError = null;
    let timer = null;
    let inFlight = null;
    let generation = 0;
    let disposed = false;
    let running = false;
    let retryDelay = pollIntervalMs;
    let pollController = null;
    const listeners = new Set();
    const pendingCommands = new Map();

    function view() { return Object.freeze({ roomId, snapshot, revision: snapshot ? snapshot.revision : null, timeoutAssessment, status, error: lastError }); }
    function emit() { const value = view(); for (const listener of [...listeners]) { try { listener(value); } catch (_) { /* observers cannot break session ownership */ } } }
    function setStatus(next, error) { status = next; lastError = error || null; emit(); }
    function clearTimer() { if (timer !== null) { timers.clearTimeout(timer); timer = null; } }
    function abortPoll() { if (pollController && !pollController.signal.aborted) pollController.abort(); pollController = null; }
    function schedule(delay) {
      clearTimer();
      if (!running || disposed) return;
      const expectedGeneration = generation;
      timer = timers.setTimeout(() => { timer = null; if (running && !disposed && generation === expectedGeneration) poll(); }, delay);
    }
    function applyResponse(result, expectedGeneration) {
      if (disposed || generation !== expectedGeneration || !roomId) return false;
      if (!result || typeof result !== "object" || !result.snapshot || !Number.isSafeInteger(result.snapshot.revision) || result.snapshot.revision < 0) {
        throw roomError("ROOM_SNAPSHOT_INVALID", "多人房間快照格式無效。");
      }
      const next = result.snapshot;
      if (snapshot && next.revision < snapshot.revision) return false;
      if (snapshot && next.revision === snapshot.revision && next.unchanged) {
        if (result.timeoutAssessment !== undefined) timeoutAssessment = result.timeoutAssessment;
        return false;
      }
      if (snapshot && next.revision === snapshot.revision && !next.unchanged) {
        // Same revision must not replace the authoritative projection with a different payload.
        return false;
      }
      snapshot = freezeCopy(next);
      if (result.timeoutAssessment !== undefined) timeoutAssessment = result.timeoutAssessment;
      emit();
      return true;
    }
    async function poll() {
      if (!running || disposed || !roomId || inFlight) return;
      const expectedGeneration = generation;
      const requestController = typeof AbortController === "function" ? new AbortController() : null;
      pollController = requestController;
      const signal = requestController && requestController.signal;
      const requestOptions = {};
      if (snapshot && Number.isSafeInteger(snapshot.revision)) requestOptions.sinceRevision = snapshot.revision;
      if (signal) requestOptions.signal = signal;
      const operation = Promise.resolve().then(() => client.getSnapshot(roomId, requestOptions));
      inFlight = operation;
      try {
        const result = await operation;
        if (applyResponse(result, expectedGeneration)) retryDelay = pollIntervalMs;
        if (running && !disposed && generation === expectedGeneration) setStatus("connected");
      } catch (error) {
        if (error && error.name === "AbortError") return;
        if (disposed || generation !== expectedGeneration) return;
        retryDelay = Math.min(maxRetryMs, Math.max(pollIntervalMs, retryDelay * 2));
        setStatus("offline", error);
      } finally {
        if (inFlight === operation) inFlight = null;
        if (pollController === requestController) pollController = null;
        if (running && !disposed && generation === expectedGeneration) schedule(retryDelay);
      }
    }
    function start() {
      if (disposed) throw roomError("ROOM_SESSION_DISPOSED", "房間工作階段已結束。");
      if (!roomId) throw roomError("ROOM_ID_REQUIRED", "開始輪詢前必須先設定房間。");
      if (running) return false;
      running = true; generation += 1; retryDelay = pollIntervalMs;
      setStatus("connecting");
      poll();
      return true;
    }
    function stop() {
      if (!running && timer === null && !pollController) return false;
      running = false; generation += 1; clearTimer(); abortPoll(); inFlight = null;
      setStatus("stopped");
      return true;
    }
    function attach(nextRoomId, initialSnapshot) {
      if (disposed) throw roomError("ROOM_SESSION_DISPOSED", "房間工作階段已結束。");
      stop();
      roomId = String(nextRoomId || "").trim().toUpperCase();
      if (!/^[A-F0-9]{12}$/.test(roomId)) { roomId = null; snapshot = null; throw roomError("ROOM_ID_INVALID", "房間代碼格式無效。"); }
      snapshot = null; timeoutAssessment = null; pendingCommands.clear(); retryDelay = pollIntervalMs;
      if (initialSnapshot) {
        if (!Number.isSafeInteger(initialSnapshot.revision) || initialSnapshot.revision < 0) throw roomError("ROOM_SNAPSHOT_INVALID", "初始房間快照格式無效。");
        snapshot = freezeCopy(initialSnapshot);
      }
      setStatus("attached");
      return view();
    }
    async function dispatch(type, fields) {
      if (disposed) throw roomError("ROOM_SESSION_DISPOSED", "房間工作階段已結束。");
      if (!roomId) throw roomError("ROOM_NOT_ATTACHED", "尚未加入房間。");
      if (typeof type !== "string" || !type.trim()) throw roomError("ROOM_COMMAND_INVALID", "房間命令類型無效。");
      const supplied = { ...(fields || {}) };
      const semanticFields = { ...supplied };
      delete semanticFields.requestId;
      delete semanticFields.expectedRevision;
      const fingerprint = `${type}:${JSON.stringify(semanticFields)}`;
      const pending = pendingCommands.get(fingerprint);
      const input = pending ? { ...pending.fields } : supplied;
      if (snapshot && Number.isSafeInteger(snapshot.revision) && input.expectedRevision === undefined) input.expectedRevision = snapshot.revision;
      input.requestId = supplied.requestId || (pending && pending.requestId) || createRequestId();
      pendingCommands.set(fingerprint, { requestId: input.requestId, fields: { ...input } });
      const expectedGeneration = generation;
      try {
        const result = await client.command(roomId, type, input);
        pendingCommands.delete(fingerprint);
        if (!disposed && generation === expectedGeneration && result && result.snapshot) applyResponse({ snapshot: result.snapshot, timeoutAssessment: result.timeoutAssessment }, expectedGeneration);
        return result;
      } catch (error) {
        // Preserve the exact payload and requestId only for transport errors; server idempotency makes retry safe.
        if (!error || error.code !== "MULTIPLAYER_NETWORK_ERROR") pendingCommands.delete(fingerprint);
        throw error;
      }
    }
    function dispose() {
      if (disposed) return;
      stop(); disposed = true; generation += 1; clearTimer(); abortPoll();
      roomId = null; snapshot = null; timeoutAssessment = null; pendingCommands.clear(); listeners.clear(); status = "disposed"; lastError = null;
    }
    return Object.freeze({
      subscribe(listener) { if (typeof listener !== "function") throw new TypeError("listener must be a function"); if (disposed) throw roomError("ROOM_SESSION_DISPOSED", "房間工作階段已結束。"); listeners.add(listener); listener(view()); return () => listeners.delete(listener); },
      attach, start, stop, dispose, refresh() { if (!running || disposed) return Promise.resolve(false); return poll(); },
      dispatch,
      setReady(ready) { if (typeof ready !== "boolean") return Promise.reject(roomError("ROOM_COMMAND_INVALID", "ready 必須是布林值。")); return dispatch("player.ready", { ready }); },
      startRound() { return dispatch("round.start", {}); },
      submitAnswer(answer) { if (typeof answer !== "string") return Promise.reject(roomError("ROOM_COMMAND_INVALID", "答案必須是文字。")); return dispatch("answer.submit", { answer }); },
      leave() { return dispatch("player.leave", {}); },
      getState: view,
      get isRunning() { return running; },
      get isDisposed() { return disposed; }
    });
  }
  global.AMQMultiplayer = global.AMQMultiplayer || {};
  global.AMQMultiplayer.roomSession = Object.freeze({ createRoomSession });
})(typeof window !== "undefined" ? window : globalThis);
