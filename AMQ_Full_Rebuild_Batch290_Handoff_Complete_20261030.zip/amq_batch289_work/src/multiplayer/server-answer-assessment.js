/* Server-owned answer assessment adapter. Never trust client-supplied correctness, grade, or latency. */
(function (global) {
  "use strict";
  const OUTCOMES = new Set(["answered", "timeout", "skip", "revealed", "unplayed-skip", "cancelled"]);
  const TARGETS = new Set(["anime", "all", "title", "artist"]);
  function assessmentError(code, message, details) {
    const error = new Error(message);
    error.name = "ServerAnswerAssessmentError";
    error.code = code;
    error.details = Object.freeze({ ...(details || {}) });
    return error;
  }
  function cleanId(value) {
    if (typeof value !== "string" || !value.trim() || value.trim().length > 128) throw assessmentError("ASSESSMENT_QUESTION_ID_INVALID", "questionId must be a non-empty string up to 128 characters");
    return value.trim();
  }
  function elapsedSeconds(startedAt, receivedAt) {
    if (startedAt === undefined || startedAt === null || receivedAt === undefined || receivedAt === null) return null;
    if (!Number.isFinite(startedAt) || !Number.isFinite(receivedAt) || startedAt < 0 || receivedAt < startedAt) {
      throw assessmentError("ASSESSMENT_TIME_INVALID", "Assessment timestamps must be finite server timestamps with receivedAt >= startedAt");
    }
    return (receivedAt - startedAt) / 1000;
  }
  function createServerAnswerAssessor(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const questions = Array.isArray(deps.questions) ? deps.questions : null;
    if (!questions) throw assessmentError("ASSESSMENT_QUESTIONS_REQUIRED", "Trusted server question records are required");
    const evaluatorFactory = deps.evaluatorFactory || (global.AMQEngine && global.AMQEngine.answerEvaluator && global.AMQEngine.answerEvaluator.createAnswerEvaluator);
    const assessmentEngine = deps.assessmentEngine || (global.AMQLearning && global.AMQLearning.assessmentEngine);
    if (typeof evaluatorFactory !== "function" || !assessmentEngine || typeof assessmentEngine.assess !== "function") {
      throw assessmentError("ASSESSMENT_DEPENDENCIES_MISSING", "Server answer assessment requires the existing answer evaluator and assessment engine");
    }
    const questionById = new Map();
    const records = [];
    for (const item of questions) {
      if (!item || typeof item !== "object" || !item.record || typeof item.record !== "object") throw assessmentError("ASSESSMENT_QUESTION_INVALID", "Each trusted question must contain a record");
      const id = cleanId(item.questionId);
      if (questionById.has(id)) throw assessmentError("ASSESSMENT_QUESTION_DUPLICATE", "Trusted question IDs must be unique", { questionId: id });
      if (!TARGETS.has(item.target)) throw assessmentError("ASSESSMENT_TARGET_INVALID", "Each trusted question must declare a server-owned target");
      questionById.set(id, { record: item.record, target: item.target });
      records.push(item.record);
    }
    const evaluator = deps.evaluator || evaluatorFactory(records);
    const acceptPartial = deps.acceptPartial === true;
    if (!evaluator || typeof evaluator.evaluate !== "function") throw assessmentError("ASSESSMENT_EVALUATOR_INVALID", "Answer evaluator must expose evaluate()");

    function assessSubmission(submission, trustedContext) {
      const value = submission && typeof submission === "object" && !Array.isArray(submission) ? submission : {};
      const context = trustedContext && typeof trustedContext === "object" && !Array.isArray(trustedContext) ? trustedContext : {};
      const questionId = cleanId(value.questionId);
      const question = questionById.get(questionId);
      if (!question) throw assessmentError("ASSESSMENT_QUESTION_UNKNOWN", "Question is not part of the trusted server question set", { questionId });
      const target = question.target;
      const outcome = context.outcome;
      if (!OUTCOMES.has(outcome)) throw assessmentError("ASSESSMENT_OUTCOME_INVALID", "Trusted context must provide a server-owned round outcome");
      const elapsed = elapsedSeconds(context.startedAt, context.receivedAt);
      let correct = null;
      if (outcome === "timeout" || outcome === "skip") correct = false;
      else if (outcome === "answered" && (target === "anime" || target === "all")) {
        const submittedTitle = target === "all"
          ? value.answers && typeof value.answers === "object" ? value.answers.anime : undefined
          : value.answer;
        correct = evaluator.evaluate(question.record, "anime", submittedTitle, { acceptPartial });
      }
      const result = {
        kind: outcome === "answered" ? "answered" : outcome,
        target,
        correct,
        elapsedSeconds: elapsed,
        ...(target === "all" ? { correctByTarget: { anime: correct === true } } : {})
      };
      const assessment = assessmentEngine.assess(result, target);
      return Object.freeze({
        questionId,
        target,
        isWorkTitleCorrect: correct,
        assessment: Object.freeze({ grade: assessment.grade, reasonCodes: Object.freeze(assessment.reasonCodes.slice()), ruleVersion: assessment.ruleVersion })
      });
    }
    return Object.freeze({ ruleVersion: assessmentEngine.RULE_VERSION || null, hasQuestion: questionId => typeof questionId === "string" && questionById.has(questionId.trim()), assessSubmission });
  }
  global.AMQMultiplayer = global.AMQMultiplayer || {};
  global.AMQMultiplayer.serverAnswerAssessment = Object.freeze({ createServerAnswerAssessor });
})(typeof window !== "undefined" ? window : globalThis);
