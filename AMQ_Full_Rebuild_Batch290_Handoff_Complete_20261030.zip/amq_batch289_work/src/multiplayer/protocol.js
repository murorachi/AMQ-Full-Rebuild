/* Versioned multiplayer wire contract. Transport and server implementation are intentionally separate. */
(function (global) {
  "use strict";
  const PROTOCOL_VERSION = 1;
  const MESSAGE_TYPES = Object.freeze([
    "hello", "room.join", "room.leave", "room.snapshot", "player.ready",
    "quiz.question", "quiz.answer", "quiz.result", "room.error", "heartbeat.ping", "heartbeat.pong"
  ]);
  const TYPE_SET = new Set(MESSAGE_TYPES);
  const MAX_ID_LENGTH = 128;
  const MAX_PAYLOAD_BYTES = 64 * 1024;

  function protocolError(code, message, details) {
    const error = new Error(message);
    error.name = "MultiplayerProtocolError";
    error.code = code;
    error.details = Object.freeze({ ...(details || {}) });
    return error;
  }
  function cleanId(value, field, optional) {
    if (optional && (value === undefined || value === null || value === "")) return "";
    if (typeof value !== "string" || !value.trim() || value.trim().length > MAX_ID_LENGTH) {
      throw protocolError("MULTIPLAYER_ID_INVALID", `${field} must be a non-empty string up to ${MAX_ID_LENGTH} characters`, { field });
    }
    return value.trim();
  }
  function serializePayload(value) {
    try {
      const serialized = JSON.stringify(value);
      if (typeof serialized !== "string") throw new Error("Payload is not JSON serializable");
      return { serialized, bytes: new TextEncoder().encode(serialized).byteLength };
    } catch (_) {
      throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "Message payload must be valid JSON data");
    }
  }
  function deepFreeze(value) {
    if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
    Object.keys(value).forEach(key => deepFreeze(value[key]));
    return Object.freeze(value);
  }
  function validatePayload(type, payload) {
    if (!payload || typeof payload !== "object" || Array.isArray(payload)) throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "Message payload must be an object", { type });
    if (type === "hello" && (!Number.isInteger(payload.minVersion) || !Number.isInteger(payload.maxVersion) || payload.minVersion < 1 || payload.maxVersion < payload.minVersion)) {
      throw protocolError("MULTIPLAYER_VERSION_RANGE_INVALID", "hello requires a valid minVersion/maxVersion range", { type });
    }
    if (type === "room.snapshot" && (!Array.isArray(payload.players) || !Number.isInteger(payload.revision) || payload.revision < 0 || payload.players.some(player => !player || typeof player !== "object" || Array.isArray(player) || typeof player.id !== "string" || !player.id.trim() || typeof player.ready !== "boolean"))) throw protocolError("MULTIPLAYER_SNAPSHOT_INVALID", "room.snapshot requires players with id/ready and a non-negative revision", { type });
    if (type === "player.ready" && typeof payload.ready !== "boolean") throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "player.ready requires a boolean ready value", { type });
    if (type === "quiz.question" && (typeof payload.questionId !== "string" || !payload.questionId || typeof payload.prompt !== "object" || payload.prompt === null || Array.isArray(payload.prompt))) throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "quiz.question requires questionId and prompt", { type });
    if (type === "quiz.answer" && (typeof payload.questionId !== "string" || !payload.questionId || typeof payload.answer !== "string")) throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "quiz.answer requires questionId and answer", { type });
    if (type === "quiz.result" && (typeof payload.questionId !== "string" || !payload.questionId || typeof payload.correct !== "boolean")) throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "quiz.result requires questionId and boolean correct", { type });
    if (type === "room.error" && (typeof payload.code !== "string" || !payload.code)) throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "room.error requires a code", { type });
    return payload;
  }
  function validateEnvelope(message, options) {
    const opts = options && typeof options === "object" ? options : {};
    if (!message || typeof message !== "object" || Array.isArray(message)) throw protocolError("MULTIPLAYER_ENVELOPE_INVALID", "Message envelope must be an object");
    if (message.protocol !== PROTOCOL_VERSION) throw protocolError("MULTIPLAYER_VERSION_UNSUPPORTED", "Unsupported multiplayer protocol version", { received: message.protocol, supported: PROTOCOL_VERSION });
    if (!TYPE_SET.has(message.type)) throw protocolError("MULTIPLAYER_TYPE_UNKNOWN", "Unknown multiplayer message type", { type: message.type });
    const roomId = cleanId(message.roomId, "roomId", ["hello", "heartbeat.ping", "heartbeat.pong"].includes(message.type));
    const playerId = cleanId(message.playerId, "playerId", ["hello", "heartbeat.ping", "heartbeat.pong", "room.error"].includes(message.type));
    if (!Number.isSafeInteger(message.seq) || message.seq < 1) throw protocolError("MULTIPLAYER_SEQUENCE_INVALID", "seq must be a positive safe integer");
    if (message.sentAt !== undefined && (!Number.isFinite(message.sentAt) || message.sentAt < 0)) throw protocolError("MULTIPLAYER_TIMESTAMP_INVALID", "sentAt must be a non-negative finite timestamp");
    const serializedPayload = serializePayload(message.payload);
    const maxPayloadBytes = Number.isFinite(opts.maxPayloadBytes) ? Math.max(1, opts.maxPayloadBytes) : MAX_PAYLOAD_BYTES;
    if (serializedPayload.bytes > maxPayloadBytes) throw protocolError("MULTIPLAYER_PAYLOAD_TOO_LARGE", "Message payload exceeds the configured size limit", { maxPayloadBytes });
    let payload;
    try { payload = JSON.parse(serializedPayload.serialized); }
    catch (_) { throw protocolError("MULTIPLAYER_PAYLOAD_INVALID", "Message payload must be valid JSON data"); }
    validatePayload(message.type, payload);
    deepFreeze(payload);
    return Object.freeze({ protocol: message.protocol, type: message.type, roomId, playerId, seq: message.seq, ...(message.sentAt === undefined ? {} : { sentAt: message.sentAt }), payload });
  }
  function createEnvelope(input, now) {
    const value = input && typeof input === "object" ? input : {};
    return validateEnvelope({ protocol: PROTOCOL_VERSION, type: value.type, roomId: value.roomId || "", playerId: value.playerId || "", seq: value.seq, sentAt: typeof now === "function" ? now() : Date.now(), payload: value.payload || {} });
  }
  function negotiateVersion(remote) {
    if (!remote || !Number.isInteger(remote.minVersion) || !Number.isInteger(remote.maxVersion) || remote.minVersion < 1 || remote.maxVersion < remote.minVersion) {
      throw protocolError("MULTIPLAYER_VERSION_RANGE_INVALID", "Remote protocol version range is invalid");
    }
    const min = Math.max(PROTOCOL_VERSION, remote.minVersion);
    const max = Math.min(PROTOCOL_VERSION, remote.maxVersion);
    if (min > max) throw protocolError("MULTIPLAYER_VERSION_MISMATCH", "No compatible multiplayer protocol version", { local: PROTOCOL_VERSION, remoteMin: remote.minVersion, remoteMax: remote.maxVersion });
    return max;
  }
  function createSequenceGuard() {
    const lastByPeer = new Map();
    return Object.freeze({
      accept(peerId, sequence) {
        const id = cleanId(peerId, "peerId", false);
        if (!Number.isSafeInteger(sequence) || sequence < 1) throw protocolError("MULTIPLAYER_SEQUENCE_INVALID", "seq must be a positive safe integer");
        const last = lastByPeer.get(id) || 0;
        if (sequence <= last) return Object.freeze({ accepted: false, reason: "duplicate-or-stale", expected: last + 1, received: sequence });
        if (sequence > last + 1) return Object.freeze({ accepted: false, reason: "sequence-gap", expected: last + 1, received: sequence });
        lastByPeer.set(id, sequence);
        return Object.freeze({ accepted: true, expected: sequence + 1, received: sequence });
      },
      reset(peerId) { if (peerId === undefined) lastByPeer.clear(); else lastByPeer.delete(cleanId(peerId, "peerId", false)); },
      last(peerId) { return lastByPeer.get(cleanId(peerId, "peerId", false)) || 0; }
    });
  }
  global.AMQMultiplayer = global.AMQMultiplayer || {};
  global.AMQMultiplayer.protocol = Object.freeze({ version: PROTOCOL_VERSION, messageTypes: MESSAGE_TYPES, maxPayloadBytes: MAX_PAYLOAD_BYTES, createEnvelope, validateEnvelope, negotiateVersion, createSequenceGuard });
})(typeof window !== "undefined" ? window : globalThis);
