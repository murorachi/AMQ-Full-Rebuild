/* Source-aware song tag definitions and assignments. */
(function (global) {
  "use strict";
  const STORAGE_KEY = "amqSongTagsV1";
  const RECOVERY_KEY = "amqSongTagsRecoveryV1";
  const UPDATE_EVENT = "amq-learning-song-tags-updated-v1";
  const identity = global.AMQData && global.AMQData.identity;
  if (!identity || typeof identity.createIdentity !== "function") throw new Error("data identity module must load before song tags store");

  function cleanName(value) { return String(value == null ? "" : value).trim().replace(/\s+/g, " ").slice(0, 32); }
  function validSongRef(value) {
    return !!value && typeof value === "object" && !Array.isArray(value)
      && (value.source === "AMQ" || value.source === "EMQ") && identity.isIdentifier(value.id);
  }
  function songKey(value) { return validSongRef(value) ? identity.createIdentity(value.source, value.id) : null; }
  function normalizePayload(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || value.version !== 1
      || !Array.isArray(value.tags) || value.tags.length > 200
      || !value.assignments || typeof value.assignments !== "object" || Array.isArray(value.assignments)) return null;
    const ids = new Set(), names = new Set(), tags = [];
    for (const raw of value.tags) {
      if (!raw || typeof raw !== "object" || Array.isArray(raw) || typeof raw.id !== "string" || !raw.id.trim() || raw.id.length > 100
        || typeof raw.name !== "string" || !raw.name.trim() || raw.name.trim().length > 32 || ids.has(raw.id)) return null;
      const name = cleanName(raw.name), nameKey = name.toLocaleLowerCase();
      if (!name || names.has(nameKey)) return null;
      ids.add(raw.id); names.add(nameKey);
      tags.push({ id: raw.id, name, createdAt: typeof raw.createdAt === "string" ? raw.createdAt : "", updatedAt: typeof raw.updatedAt === "string" ? raw.updatedAt : "" });
    }
    const assignments = {};
    const entries = Object.entries(value.assignments);
    if (entries.length > 100000) return null;
    for (const [key, rawIds] of entries) {
      let parts;
      try { parts = JSON.parse(key); } catch (_) { return null; }
      if (!Array.isArray(parts) || parts.length !== 2 || !["AMQ", "EMQ"].includes(parts[0]) || typeof parts[1] !== "string"
        || !/^(?:string|number):.+$/.test(parts[1]) || !Array.isArray(rawIds) || rawIds.some(id => typeof id !== "string" || !ids.has(id))) return null;
      const normalizedIds = [...new Set(rawIds)];
      if (normalizedIds.length) assignments[key] = normalizedIds;
    }
    return { version: 1, tags, assignments };
  }
  const EMPTY = Object.freeze({ version: 1, tags: Object.freeze([]), assignments: Object.freeze({}) });
  function clone(value) { return JSON.parse(JSON.stringify(value)); }

  function createSongTagsStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    const makeId = typeof deps.createId === "function" ? deps.createId : () => `tag-${now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    const listeners = new Set();
    let state = { version: 1, tags: [], assignments: {} };
    let blocked = false, error = null, recoveryAvailable = false, disposed = false;

    function getStatus() { return Object.freeze({ blocked, error, recoveryAvailable, persisted: !blocked && !error && !recoveryAvailable, storageKey: STORAGE_KEY }); }
    function notify(source, detail) {
      const status = getStatus(), snapshot = getData();
      for (const listener of [...listeners]) if (listeners.has(listener)) { try { listener(status, snapshot, source, detail || null); } catch (_) {} }
      try {
        if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT, { source, status, detail: detail || null });
        else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT, { detail: { source, status, detail: detail || null } }));
      } catch (_) {}
    }
    function recover(raw) {
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        let key = RECOVERY_KEY;
        if (storage.getItem(key) !== null) key = `${RECOVERY_KEY}_${now()}`;
        storage.setItem(key, raw); recoveryAvailable = true; return true;
      } catch (cause) { error = cause && cause.message || "recovery-failed"; return false; }
    }
    function refresh(source = "refresh") {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      let raw;
      try { if (!storage || typeof storage.getItem !== "function") throw new Error("storage-unavailable"); raw = storage.getItem(STORAGE_KEY); }
      catch (cause) { blocked = true; error = cause && cause.message || "storage-read-failed"; notify(source); return Object.freeze({ ok: false, reason: error }); }
      blocked = false; error = null; recoveryAvailable = false;
      if (raw == null || raw === "") { state = { version: 1, tags: [], assignments: {} }; notify(source); return Object.freeze({ ok: true, defaults: true }); }
      let parsed; try { parsed = JSON.parse(raw); } catch (_) { parsed = null; }
      const normalized = normalizePayload(parsed);
      if (!normalized) {
        if (!recover(raw)) { blocked = true; notify(source); return Object.freeze({ ok: false, reason: error || "recovery-failed" }); }
        state = { version: 1, tags: [], assignments: {} }; notify(source); return Object.freeze({ ok: true, recovered: true });
      }
      state = normalized; notify(source); return Object.freeze({ ok: true, recovered: false });
    }
    function commit(next, source, detail) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      if (blocked) return Object.freeze({ ok: false, persisted: false, reason: "persistence-blocked" });
      const normalized = normalizePayload(next);
      if (!normalized) return Object.freeze({ ok: false, persisted: false, reason: "invalid-payload" });
      try { if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable"); storage.setItem(STORAGE_KEY, JSON.stringify(normalized)); }
      catch (cause) { error = cause && cause.message || "storage-write-failed"; notify("write-failed", { reason: error, ...(detail || {}) }); return Object.freeze({ ok: false, persisted: false, reason: error }); }
      state = normalized; error = null; recoveryAvailable = false;
      try {
        if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT, { source, detail: detail || null });
        else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT, { detail: { source, detail: detail || null } }));
      } catch (_) {}
      notify(source, detail); return Object.freeze({ ok: true, persisted: true, data: getData() });
    }
    function getData() { return clone(state); }
    function getTags() { return clone(state.tags); }
    function getTagIds(ref) { const key = songKey(ref); return key ? [...(state.assignments[key] || [])] : []; }
    function createTag(rawName) {
      const name = cleanName(rawName);
      if (!name) return { ok: false, persisted: false, reason: "empty-name" };
      if (state.tags.some(tag => tag.name.toLocaleLowerCase() === name.toLocaleLowerCase())) return { ok: false, persisted: false, reason: "duplicate-name" };
      if (state.tags.length >= 200) return { ok: false, persisted: false, reason: "tag-limit" };
      const id = String(makeId());
      if (!id || state.tags.some(tag => tag.id === id)) return { ok: false, persisted: false, reason: "duplicate-id" };
      const stamp = new Date(now()).toISOString();
      const tag = { id, name, createdAt: stamp, updatedAt: stamp };
      const result = commit({ ...state, tags: [...state.tags, tag] }, "tag-created", { tagId: id });
      return result.ok ? { ...result, tag: clone(tag) } : result;
    }
    function renameTag(id, rawName) {
      const old = state.tags.find(tag => tag.id === String(id));
      if (!old) return { ok: false, persisted: false, reason: "missing-tag" };
      const name = cleanName(rawName);
      if (!name) return { ok: false, persisted: false, reason: "empty-name" };
      if (state.tags.some(tag => tag.id !== old.id && tag.name.toLocaleLowerCase() === name.toLocaleLowerCase())) return { ok: false, persisted: false, reason: "duplicate-name" };
      const stamp = new Date(now()).toISOString();
      return commit({ ...state, tags: state.tags.map(tag => tag.id === old.id ? { ...tag, name, updatedAt: stamp } : tag) }, "tag-renamed", { tagId: old.id });
    }
    function deleteTag(id) {
      const tagId = String(id);
      if (!state.tags.some(tag => tag.id === tagId)) return { ok: false, persisted: false, reason: "missing-tag" };
      const assignments = {};
      for (const [key, ids] of Object.entries(state.assignments)) {
        const next = ids.filter(value => value !== tagId);
        if (next.length) assignments[key] = next;
      }
      return commit({ ...state, tags: state.tags.filter(tag => tag.id !== tagId), assignments }, "tag-deleted", { tagId });
    }
    function setSongTags(ref, tagIds) {
      const key = songKey(ref);
      if (!key) return { ok: false, persisted: false, reason: "invalid-song-ref" };
      if (!Array.isArray(tagIds) || tagIds.some(id => typeof id !== "string" || !state.tags.some(tag => tag.id === id))) return { ok: false, persisted: false, reason: "invalid-tag-ids" };
      const assignments = { ...state.assignments };
      const ids = [...new Set(tagIds)];
      if (ids.length) assignments[key] = ids; else delete assignments[key];
      return commit({ ...state, assignments }, "song-tags-updated", { source: ref.source, songId: String(ref.id), tagIds: ids });
    }
    function setSongTag(ref, tagId, assigned) {
      const current = getTagIds(ref);
      if (typeof assigned !== "boolean") return { ok: false, persisted: false, reason: "invalid-assignment" };
      if (assigned && !current.includes(String(tagId))) current.push(String(tagId));
      if (!assigned) { const index = current.indexOf(String(tagId)); if (index >= 0) current.splice(index, 1); }
      return setSongTags(ref, current);
    }
    function setSongTagForMany(refs, tagId, assigned) {
      if (!Array.isArray(refs) || refs.some(ref => !songKey(ref))) return { ok: false, persisted: false, reason: "invalid-song-refs" };
      const id = String(tagId);
      if (!state.tags.some(tag => tag.id === id)) return { ok: false, persisted: false, reason: "missing-tag" };
      if (typeof assigned !== "boolean") return { ok: false, persisted: false, reason: "invalid-assignment" };
      const assignments = { ...state.assignments };
      const unique = new Map(refs.map(ref => [songKey(ref), ref]));
      for (const key of unique.keys()) {
        const current = [...(assignments[key] || [])];
        if (assigned && !current.includes(id)) current.push(id);
        if (!assigned) { const index = current.indexOf(id); if (index >= 0) current.splice(index, 1); }
        if (current.length) assignments[key] = current; else delete assignments[key];
      }
      return commit({ ...state, assignments }, "song-tags-bulk-updated", { tagId: id, assigned, count: unique.size });
    }
    function onStorage(event) { if (!disposed && event && (event.key === null || event.key === STORAGE_KEY)) refresh("external"); }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener); let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function dispose() {
      if (disposed) return false;
      disposed = true;
      if (eventTarget && typeof eventTarget.removeEventListener === "function") eventTarget.removeEventListener("storage", onStorage);
      listeners.clear(); return true;
    }
    refresh("init");
    if (eventTarget && typeof eventTarget.addEventListener === "function") eventTarget.addEventListener("storage", onStorage);
    return Object.freeze({ storageKey: STORAGE_KEY, recoveryKey: RECOVERY_KEY, updateEvent: UPDATE_EVENT, getStatus, getData, getTags, getTagIds, createTag, renameTag, deleteTag, setSongTags, setSongTag, setSongTagForMany, refresh, subscribe, dispose, get isDisposed() { return disposed; } });
  }
  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.songTagsStore = Object.freeze({ createSongTagsStore, storageKey: STORAGE_KEY, recoveryKey: RECOVERY_KEY, updateEvent: UPDATE_EVENT, normalizePayload, songKey });
})(window);
