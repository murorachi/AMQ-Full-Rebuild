/* Session-scoped SRS storage bridge with an optional identity-bound IndexedDB pending queue. */
(function (global) {
  "use strict";
  const SOURCES = Object.freeze(["AMQ", "EMQ"]);
  const PENDING_DB_NAME = "amq-remote-srs-pending-v1";
  const PENDING_STORE_NAME = "pending";

  function cloneJson(value) { return JSON.parse(JSON.stringify(value)); }
  function stableJson(value) {
    if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
    if (value && typeof value === "object") {
      return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableJson(value[key])}`).join(",")}}`;
    }
    return JSON.stringify(value);
  }
  function sameSchedule(left, right) {
    try { return stableJson(left) === stableJson(right); }
    catch (_) { return false; }
  }
  function createIndexedDbPendingStore(userId) {
    const normalizedUserId = Number(userId);
    if (!Number.isSafeInteger(normalizedUserId) || normalizedUserId <= 0 || !global.indexedDB) return null;
    let dbPromise = null;
    function openDatabase() {
      if (dbPromise) return dbPromise;
      dbPromise = new Promise((resolve, reject) => {
        let request;
        try { request = global.indexedDB.open(PENDING_DB_NAME, 1); }
        catch (error) { reject(error); return; }
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(PENDING_STORE_NAME)) db.createObjectStore(PENDING_STORE_NAME, { keyPath: "key" });
        };
        request.onsuccess = () => {
          const db = request.result;
          db.onversionchange = () => db.close();
          resolve(db);
        };
        request.onerror = () => reject(request.error || new Error("REMOTE_SRS_PENDING_STORE_OPEN_FAILED"));
        request.onblocked = () => reject(new Error("REMOTE_SRS_PENDING_STORE_BLOCKED"));
      }).catch(error => { dbPromise = null; throw error; });
      return dbPromise;
    }
    function recordKey(uid, source) { return `${Number(uid)}:${String(source).toUpperCase()}`; }
    async function read(uid, source) {
      const db = await openDatabase();
      return new Promise((resolve, reject) => {
        let result = null;
        const transaction = db.transaction(PENDING_STORE_NAME, "readonly");
        const request = transaction.objectStore(PENDING_STORE_NAME).get(recordKey(uid, source));
        request.onsuccess = () => { result = request.result || null; };
        request.onerror = () => reject(request.error || new Error("REMOTE_SRS_PENDING_STORE_READ_FAILED"));
        transaction.oncomplete = () => { if (result) { const copy = { ...result }; delete copy.key; resolve(copy); } else resolve(null); };
        transaction.onerror = () => reject(transaction.error || new Error("REMOTE_SRS_PENDING_STORE_READ_FAILED"));
        transaction.onabort = () => reject(transaction.error || new Error("REMOTE_SRS_PENDING_STORE_READ_FAILED"));
      });
    }
    async function write(uid, source, record) {
      const db = await openDatabase();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(PENDING_STORE_NAME, "readwrite");
        transaction.objectStore(PENDING_STORE_NAME).put({ ...cloneJson(record), key: recordKey(uid, source), userId: Number(uid), source: String(source).toUpperCase() });
        transaction.oncomplete = () => resolve(true);
        transaction.onerror = () => reject(transaction.error || new Error("REMOTE_SRS_PENDING_STORE_WRITE_FAILED"));
        transaction.onabort = () => reject(transaction.error || new Error("REMOTE_SRS_PENDING_STORE_WRITE_FAILED"));
      });
    }
    async function remove(uid, source) {
      const db = await openDatabase();
      return new Promise((resolve, reject) => {
        const transaction = db.transaction(PENDING_STORE_NAME, "readwrite");
        transaction.objectStore(PENDING_STORE_NAME).delete(recordKey(uid, source));
        transaction.oncomplete = () => resolve(true);
        transaction.onerror = () => reject(transaction.error || new Error("REMOTE_SRS_PENDING_STORE_DELETE_FAILED"));
        transaction.onabort = () => reject(transaction.error || new Error("REMOTE_SRS_PENDING_STORE_DELETE_FAILED"));
      });
    }
    return Object.freeze({ get: read, put: write, delete: remove });
  }

  function createRemoteSrsBridge(options) {
    const settings = options && typeof options === "object" ? options : {};
    const fetcher = typeof settings.fetch === "function" ? settings.fetch : global.fetch && global.fetch.bind(global);
    const srsApi = global.AMQPersistence && global.AMQPersistence.srsStore;
    if (typeof fetcher !== "function") throw new TypeError("remote SRS bridge requires fetch");
    if (!srsApi || !srsApi.storageKeys) throw new TypeError("remote SRS bridge requires SRS store API");
    const userId = Number(settings.userId);
    const hasUserId = Number.isSafeInteger(userId) && userId > 0;
    const injectedPendingStore = settings.pendingStore;
    const pendingStore = injectedPendingStore && typeof injectedPendingStore.get === "function" && typeof injectedPendingStore.put === "function" && typeof injectedPendingStore.delete === "function"
      ? injectedPendingStore : createIndexedDbPendingStore(userId);
    let durableAvailable = Boolean(hasUserId && pendingStore);
    const sources = new Map();
    const listeners = new Set();
    let closed = false;
    let connected = false;

    async function parseResponse(response) {
      let body = null;
      try { body = await response.json(); } catch (_) {}
      if (!response.ok) {
        const detail = body && body.error;
        const error = new Error(detail && detail.message || `SRS API failed (${response.status})`);
        error.code = detail && detail.code || "REMOTE_SRS_REQUEST_FAILED";
        error.status = response.status;
        throw error;
      }
      return body;
    }
    function notify(source) {
      const snapshot = getStatus();
      for (const listener of [...listeners]) if (listeners.has(listener)) { try { listener(snapshot, source || null); } catch (_) {} }
    }
    function setEntryError(entry, error) {
      entry.blocked = true;
      entry.state = error && error.status === 409 ? "conflict" : "error";
      entry.error = Object.freeze({ code: error && error.code || "REMOTE_SRS_REQUEST_FAILED", message: error && error.message || "遠端 SRS 保存失敗。" });
      entry.pending = 0;
      if (String(entry.error.code).startsWith("REMOTE_SRS_PENDING_STORE_")) durableAvailable = false;
      notify(entry.source);
    }
    function getStatus() {
      const status = {};
      for (const [source, entry] of sources) status[source] = Object.freeze({
        source, state: entry.state, revision: entry.revision, pending: entry.pending,
        retrying: entry.retrying, error: entry.error, synced: entry.state === "synced" && entry.pending === 0
      });
      const values = Object.values(status);
      const failed = values.find(item => item.state === "conflict" || item.state === "error");
      const saving = values.some(item => item.state === "saving");
      return Object.freeze({ connected, closed, durable: durableAvailable, state: failed ? failed.state : saving ? "saving" : connected ? "synced" : "disconnected",
        error: failed ? failed.error : null, sources: Object.freeze(status) });
    }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener); let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function storageRecord(entry) {
      if (!entry.pendingRecord) return null;
      return { ...cloneJson(entry.pendingRecord), schemaVersion: 1, userId, source: entry.source, updatedAt: Date.now() };
    }
    function persistPendingRecord(entry) {
      if (!pendingStore || !hasUserId) return Promise.resolve(false);
      const snapshot = storageRecord(entry);
      entry.persistChain = entry.persistChain.catch(() => {}).then(() => snapshot
        ? pendingStore.put(userId, entry.source, snapshot)
        : pendingStore.delete(userId, entry.source));
      return entry.persistChain.then(result => { durableAvailable = true; return result; }).catch(error => {
        durableAvailable = false;
        const wrapped = new Error("無法持久化未同步的 SRS 變更；為避免遺失資料，已暫停遠端寫入。");
        wrapped.code = "REMOTE_SRS_PENDING_STORE_WRITE_FAILED";
        wrapped.cause = error;
        throw wrapped;
      });
    }
    function parseRecordSchedule(raw) {
      if (typeof raw !== "string") throw new Error("REMOTE_SRS_PENDING_QUEUE_INVALID");
      try { return JSON.parse(raw); } catch (_) { throw new Error("REMOTE_SRS_PENDING_QUEUE_INVALID"); }
    }
    function clearPending(entry, current, recovered) {
      const prior = entry.pendingRecord;
      entry.revision = Number(current.revision);
      entry.serverSchedule = cloneJson(current.schedule);
      entry.pendingRecord = null;
      entry.pending = 0;
      entry.blocked = false;
      entry.state = "synced";
      entry.error = null;
      entry.lastQueuedRaw = JSON.stringify(current.schedule);
      entry.values.set(entry.storageKey, entry.lastQueuedRaw);
      return persistPendingRecord(entry).then(() => { notify(entry.source); return "synced"; }).catch(error => {
        entry.pendingRecord = prior;
        entry.pending = 0;
        setEntryError(entry, error);
        throw error;
      });
    }
    async function reconcilePending(entry, current, recovered) {
      const record = entry.pendingRecord;
      if (!record) { entry.revision = Number(current.revision); entry.serverSchedule = cloneJson(current.schedule); return "none"; }
      const baseSchedule = record.baseRaw ? parseRecordSchedule(record.baseRaw) : record.baseSchedule;
      const latestSchedule = parseRecordSchedule(record.latestRaw);
      const inFlightSchedule = record.inFlightRaw ? parseRecordSchedule(record.inFlightRaw) : null;
      const currentRevision = Number(current.revision);
      const conflict = () => {
        const error = new Error("伺服器排程已在其他位置更新，且內容與待同步變更不同；為避免覆蓋資料，未同步變更沒有重送。");
        error.code = "SRS_REVISION_CONFLICT"; error.status = 409;
        setEntryError(entry, error);
        return "conflict";
      };
      if (currentRevision === Number(record.baseRevision) && sameSchedule(current.schedule, baseSchedule)) {
        entry.revision = currentRevision;
        entry.serverSchedule = cloneJson(current.schedule);
        record.inFlightRaw = null;
        entry.pendingRecord = record;
        entry.lastQueuedRaw = record.latestRaw;
        entry.values.set(entry.storageKey, record.latestRaw);
        entry.pending = recovered ? 0 : 1;
        entry.blocked = Boolean(recovered);
        entry.state = recovered ? "error" : "saving";
        entry.error = recovered ? Object.freeze({ code: "REMOTE_SRS_PENDING_RECOVERED", message: "已從本機持久化佇列還原未同步的 SRS 變更；請明確重試或重新載入。" }) : null;
        await persistPendingRecord(entry);
        notify(entry.source);
        return "pending";
      }
      if (currentRevision === Number(record.baseRevision) + 1 && inFlightSchedule && sameSchedule(current.schedule, inFlightSchedule)) {
        if (sameSchedule(current.schedule, latestSchedule)) return clearPending(entry, current, recovered);
        record.baseRevision = currentRevision;
        record.baseSchedule = cloneJson(current.schedule);
        record.baseRaw = JSON.stringify(current.schedule);
        record.inFlightRaw = null;
        entry.revision = currentRevision;
        entry.serverSchedule = cloneJson(current.schedule);
        entry.pendingRecord = record;
        entry.lastQueuedRaw = record.latestRaw;
        entry.values.set(entry.storageKey, record.latestRaw);
        entry.pending = recovered ? 0 : 1;
        entry.blocked = Boolean(recovered);
        entry.state = recovered ? "error" : "saving";
        entry.error = recovered ? Object.freeze({ code: "REMOTE_SRS_PENDING_RECOVERED", message: "上一筆 SRS 寫入已提交；已恢復後續待同步變更，請明確重試。" }) : null;
        await persistPendingRecord(entry);
        notify(entry.source);
        return "pending";
      }
      if (currentRevision === Number(record.baseRevision) + 1 && sameSchedule(current.schedule, latestSchedule)) return clearPending(entry, current, recovered);
      return conflict();
    }
    async function flushPending(entry) {
      if (closed || entry.blocked || !entry.pendingRecord) return getStatus();
      const record = entry.pendingRecord;
      const raw = record.latestRaw;
      const schedule = parseRecordSchedule(raw);
      record.inFlightRaw = raw;
      record.updatedAt = Date.now();
      await persistPendingRecord(entry);
      if (closed || entry.blocked || !entry.pendingRecord) return getStatus();
      const response = await fetcher(`/api/srs/${entry.source}`, {
        method: "PUT", credentials: "same-origin", headers: { "content-type": "application/json" },
        body: JSON.stringify({ expectedRevision: record.baseRevision, schedule })
      });
      const body = await parseResponse(response);
      if (closed) throw new Error("remote-srs-bridge-closed");
      const current = { revision: body.revision, schedule };
      entry.revision = Number(body.revision);
      entry.serverSchedule = cloneJson(schedule);
      if (entry.pendingRecord && entry.pendingRecord.latestRaw === raw) {
        await clearPending(entry, current, false);
      } else if (entry.pendingRecord) {
        const latest = entry.pendingRecord;
        latest.baseRevision = Number(body.revision);
        latest.baseSchedule = cloneJson(schedule);
        latest.baseRaw = JSON.stringify(schedule);
        latest.inFlightRaw = null;
        latest.updatedAt = Date.now();
        entry.pending = 1;
        entry.blocked = false;
        entry.state = "saving";
        entry.error = null;
        await persistPendingRecord(entry);
        notify(entry.source);
      }
      return getStatus();
    }
    function makeStorage(source, snapshot) {
      const storageKey = srsApi.storageKeys[source];
      const initialRaw = JSON.stringify(snapshot.schedule);
      const values = new Map([[storageKey, initialRaw]]);
      const entry = { source, storageKey, revision: snapshot.revision, serverSchedule: cloneJson(snapshot.schedule), state: "synced", pending: 0, error: null,
        blocked: false, retrying: false, retryPromise: null, lastQueuedRaw: initialRaw, queue: Promise.resolve(), persistChain: Promise.resolve(), pendingRecord: null, storage: null, values };
      const storage = {
        getItem(key) { return values.has(String(key)) ? values.get(String(key)) : null; },
        setItem(key, value) {
          const normalizedKey = String(key);
          const raw = String(value);
          if (closed) throw new Error("remote-srs-bridge-closed");
          if (normalizedKey === storageKey && (entry.blocked || entry.retrying)) throw new Error(entry.error && entry.error.code || "remote-srs-persistence-blocked");
          values.set(normalizedKey, raw);
          if (normalizedKey !== storageKey || raw === entry.lastQueuedRaw) return;
          let schedule;
          try { schedule = JSON.parse(raw); } catch (_) { throw new Error("remote-srs-schedule-invalid-json"); }
          if (!entry.pendingRecord) {
            entry.pendingRecord = { schemaVersion: 1, userId: hasUserId ? userId : null, source, baseRevision: entry.revision,
              baseSchedule: cloneJson(entry.serverSchedule), baseRaw: JSON.stringify(entry.serverSchedule), inFlightRaw: null, latestRaw: raw, updatedAt: Date.now() };
          } else {
            entry.pendingRecord.latestRaw = raw;
            entry.pendingRecord.updatedAt = Date.now();
          }
          entry.lastQueuedRaw = raw;
          entry.pending = 1;
          entry.state = "saving";
          entry.error = null;
          notify(source);
          entry.queue = entry.queue.then(async () => {
            if (entry.blocked || closed || !entry.pendingRecord) return;
            await persistPendingRecord(entry);
            if (entry.blocked || closed || !entry.pendingRecord) return;
            await flushPending(entry);
          }).catch(error => setEntryError(entry, error));
        },
        removeItem(key) { values.delete(String(key)); },
        clear() { values.clear(); }
      };
      entry.storage = storage;
      sources.set(source, entry);
      return storage;
    }
    async function retryEntry(entry) {
      if (entry.retryPromise) return entry.retryPromise;
      if (closed) throw new Error("remote-srs-bridge-closed");
      if (entry.state !== "error" || !entry.blocked) return getStatus();
      entry.retrying = true;
      entry.state = "saving";
      entry.error = null;
      notify(entry.source);
      entry.retryPromise = (async () => {
        try {
          const currentResponse = await fetcher(`/api/srs/${entry.source}`, { method: "GET", credentials: "same-origin", headers: { accept: "application/json" } });
          const current = await parseResponse(currentResponse);
          if (closed) throw new Error("remote-srs-bridge-closed");
          if (!entry.pendingRecord && durableAvailable && pendingStore) {
            const saved = await pendingStore.get(userId, entry.source);
            if (saved) {
              entry.pendingRecord = saved;
              entry.lastQueuedRaw = saved.latestRaw;
              entry.values.set(entry.storageKey, saved.latestRaw);
            }
          }
          if (!entry.pendingRecord) throw new Error("remote-srs-pending-schedule-missing");
          const reconciled = await reconcilePending(entry, current, false);
          if (reconciled === "conflict") return getStatus();
          if (reconciled === "synced") return getStatus();
          entry.blocked = false;
          entry.state = "saving";
          entry.error = null;
          entry.pending = 1;
          await flushPending(entry);
        } catch (error) { setEntryError(entry, error); }
        finally { entry.retrying = false; entry.retryPromise = null; notify(entry.source); }
        return getStatus();
      })();
      return entry.retryPromise;
    }
    async function retryPending(sourceInput) {
      if (!connected || closed) throw new Error("remote-srs-bridge-not-connected");
      const source = sourceInput === undefined ? null : String(sourceInput).toUpperCase();
      if (source && !sources.has(source)) throw new TypeError("unknown remote SRS source");
      await Promise.all([...sources.values()].filter(entry => !source || entry.source === source).map(retryEntry));
      return getStatus();
    }
    async function connect() {
      if (closed) throw new Error("remote-srs-bridge-closed");
      if (connected) return getStatus();
      const loaded = await Promise.all(SOURCES.map(async source => {
        const response = await fetcher(`/api/srs/${source}`, { method: "GET", credentials: "same-origin", headers: { accept: "application/json" } });
        return [source, await parseResponse(response)];
      }));
      if (closed) throw new Error("remote-srs-bridge-closed");
      for (const [source, snapshot] of loaded) makeStorage(source, snapshot);
      if (durableAvailable && pendingStore) {
        for (const [source, snapshot] of loaded) {
          let record;
          try { record = await pendingStore.get(userId, source); }
          catch (error) { const wrapped = new Error("無法讀取本機持久化 SRS 佇列；為避免遺失待同步變更，已停止載入。"); wrapped.code = "REMOTE_SRS_PENDING_STORE_READ_FAILED"; wrapped.cause = error; throw wrapped; }
          if (!record) continue;
          const entry = sources.get(source);
          if (Number(record.userId) !== userId || String(record.source).toUpperCase() !== source || Number(record.schemaVersion) !== 1) {
            const invalid = new Error("持久化 SRS 佇列的帳號或格式不符，已停止載入。"); invalid.code = "REMOTE_SRS_PENDING_QUEUE_INVALID"; throw invalid;
          }
          entry.pendingRecord = record;
          entry.lastQueuedRaw = record.latestRaw;
          entry.values.set(entry.storageKey, record.latestRaw);
          const reconciled = await reconcilePending(entry, snapshot, true);
          if (reconciled === "conflict") continue;
        }
      }
      connected = true;
      notify();
      return getStatus();
    }
    function storageFor(sourceInput) {
      const source = String(sourceInput || "").toUpperCase();
      if (!connected || !sources.has(source)) throw new Error("remote-srs-bridge-not-connected");
      return sources.get(source).storage;
    }
    async function flush() {
      await Promise.all([...sources.values()].map(async entry => {
        await entry.queue;
        await entry.persistChain;
        if (entry.retryPromise) await entry.retryPromise;
      }));
      return getStatus();
    }
    async function discardPending(sourceInput) {
      if (!connected || closed) throw new Error("remote-srs-bridge-not-connected");
      const source = sourceInput === undefined ? null : String(sourceInput).toUpperCase();
      if (source && !sources.has(source)) throw new TypeError("unknown remote SRS source");
      for (const entry of [...sources.values()].filter(item => !source || item.source === source)) {
        if (entry.retryPromise) await entry.retryPromise;
        const priorRecord = entry.pendingRecord;
        entry.pendingRecord = null;
        entry.pending = 0;
        entry.blocked = false;
        entry.state = "synced";
        entry.error = null;
        entry.lastQueuedRaw = JSON.stringify(entry.serverSchedule);
        entry.values.set(entry.storageKey, entry.lastQueuedRaw);
        try { await persistPendingRecord(entry); }
        catch (error) {
          entry.pendingRecord = priorRecord;
          if (priorRecord) { entry.lastQueuedRaw = priorRecord.latestRaw; entry.values.set(entry.storageKey, priorRecord.latestRaw); }
          setEntryError(entry, error);
          throw error;
        }
        notify(entry.source);
      }
      return getStatus();
    }
    function close() {
      closed = true;
      notify();
      listeners.clear();
    }
    return Object.freeze({ connect, storageFor, getStatus, subscribe, flush, retryPending, discardPending, close, get isConnected() { return connected; }, get isClosed() { return closed; } });
  }

  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.remoteSrsBridge = Object.freeze({ createRemoteSrsBridge });
})(window);
