/* Versioned persistence for the quiz controls currently exposed by the UI. */
(function (global) {
  "use strict";
  const STORAGE_KEY = "amqLearningAppSettingsV1";
  const RECOVERY_KEY = "amqLearningAppSettingsRecoveryV1";
  const UPDATE_EVENT = "amq-learning-app-settings-updated-v1";
  const DEFAULTS = Object.freeze({ schemaVersion: 1, catalogFilterPresets: Object.freeze([]), target: "anime", questionCount: 25, clipSeconds: 20, acceptPartial: false, autoPlay: true, customListId: "", srsEnabled: true, yearFrom: null, yearTo: null, includeUnknownYear: true, animeType: "", difficultyMin: null, difficultyMax: null, songType: "", watchStatus: "", randomSample: false, clipStartSeconds: 0, autoNextDelaySeconds: 0, chineseTitlesEnabled: false });
  const TARGETS = new Set(["anime", "title", "artist", "all"]);
  const WATCH_FILTERS = new Set(["", "none", "planning", "current", "completed", "paused", "dropped", "repeating"]);
  function validOptionalNumber(value, min, max, integer = false) { return value === null || value === undefined || value === "" || (typeof value === "number" && Number.isFinite(value) && value >= min && value <= max && (!integer || Number.isInteger(value))); }

  const CATALOG_FILTER_KEYS = Object.freeze(["query", "source", "type", "workKind", "animeYearFrom", "animeYearTo", "includeUnknownYear", "animeType", "animeDecade", "watchStatus", "familiarityLevel", "tagId"]);
  const CATALOG_SORT_FIELDS = new Set(["", "title", "artist", "animeTitle", "type", "source", "id", "number", "difficulty", "animeYear"]);
  function normalizeCatalogFilterPresets(value) {
    if (value === undefined) return [];
    if (!Array.isArray(value) || value.length > 30) return null;
    const ids = new Set();
    const names = new Set();
    const result = [];
    for (const item of value) {
      if (!item || typeof item !== "object" || Array.isArray(item)
        || typeof item.id !== "string" || !item.id.trim() || item.id.length > 80 || ids.has(item.id)
        || typeof item.name !== "string" || !item.name.trim() || item.name.trim().length > 40
        || !item.filters || typeof item.filters !== "object" || Array.isArray(item.filters)
        || Object.keys(item.filters).some(key => !CATALOG_FILTER_KEYS.includes(key))
        || !CATALOG_SORT_FIELDS.has(item.sortBy) || !["asc", "desc"].includes(item.sortDirection)
        || ![10, 25, 50, 100].includes(item.pageSize)) return null;
      const name = item.name.trim();
      const nameKey = name.toLocaleLowerCase();
      if (names.has(nameKey)) return null;
      const filters = {};
      for (const key of CATALOG_FILTER_KEYS) {
        const filterValue = item.filters[key];
        if (typeof filterValue !== "string") return null;
        filters[key] = filterValue;
      }
      if (filters.includeUnknownYear !== "true" && filters.includeUnknownYear !== "false") return null;
      for (const key of ["animeYearFrom", "animeYearTo"]) {
        const year = filters[key];
        if (year !== "" && (!/^\d{4}$/.test(year) || Number(year) < 1900 || Number(year) > 2100)) return null;
      }
      if (filters.animeYearFrom && filters.animeYearTo && Number(filters.animeYearFrom) > Number(filters.animeYearTo)) return null;
      if (filters.animeDecade !== "" && (!/^\d{4}$/.test(filters.animeDecade) || Number(filters.animeDecade) < 1900 || Number(filters.animeDecade) > 2100 || Number(filters.animeDecade) % 10 !== 0)) return null;
      if (filters.familiarityLevel !== "" && !["0", "1", "2", "3", "4"].includes(filters.familiarityLevel)) return null;
      if (filters.watchStatus !== "" && !WATCH_FILTERS.has(filters.watchStatus)) return null;
      if (Object.values(filters).some(v => v.length > 300)) return null;
      ids.add(item.id); names.add(nameKey);
      result.push({ id: item.id, name, filters, sortBy: item.sortBy, sortDirection: item.sortDirection, pageSize: item.pageSize });
    }
    return result;
  }

  function normalize(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || value.schemaVersion !== 1) return null;
    const catalogFilterPresets = normalizeCatalogFilterPresets(value.catalogFilterPresets);
    if (!catalogFilterPresets || !TARGETS.has(value.target) || !Number.isInteger(value.questionCount) || value.questionCount < 0 || value.questionCount > 500
      || !Number.isInteger(value.clipSeconds) || value.clipSeconds < 1 || value.clipSeconds > 120
      || typeof value.acceptPartial !== "boolean" || typeof value.autoPlay !== "boolean"
      || (value.customListId !== undefined && typeof value.customListId !== "string")
      || (value.srsEnabled !== undefined && typeof value.srsEnabled !== "boolean")
      || !validOptionalNumber(value.yearFrom, 1900, 2100, true) || !validOptionalNumber(value.yearTo, 1900, 2100, true)
      || !validOptionalNumber(value.difficultyMin, 0, 100) || !validOptionalNumber(value.difficultyMax, 0, 100)
      || (value.yearFrom != null && value.yearFrom !== "" && value.yearTo != null && value.yearTo !== "" && Number(value.yearFrom) > Number(value.yearTo))
      || (value.difficultyMin != null && value.difficultyMin !== "" && value.difficultyMax != null && value.difficultyMax !== "" && Number(value.difficultyMin) > Number(value.difficultyMax))
      || (value.includeUnknownYear !== undefined && typeof value.includeUnknownYear !== "boolean")
      || (value.animeType !== undefined && typeof value.animeType !== "string")
      || (value.songType !== undefined && typeof value.songType !== "string")
      || (value.watchStatus !== undefined && !WATCH_FILTERS.has(value.watchStatus))
      || (value.randomSample !== undefined && typeof value.randomSample !== "boolean")
      || (value.chineseTitlesEnabled !== undefined && typeof value.chineseTitlesEnabled !== "boolean")
      || !validOptionalNumber(value.clipStartSeconds, 0, 600)
      || !Number.isInteger(value.autoNextDelaySeconds === undefined ? 0 : value.autoNextDelaySeconds)
      || (value.autoNextDelaySeconds !== undefined && (value.autoNextDelaySeconds < 0 || value.autoNextDelaySeconds > 30))) return null;
    return { schemaVersion: 1, catalogFilterPresets, target: value.target, questionCount: value.questionCount, clipSeconds: value.clipSeconds,
      acceptPartial: value.acceptPartial, autoPlay: value.autoPlay, customListId: value.customListId || "", srsEnabled: value.srsEnabled !== false,
      yearFrom: value.yearFrom == null || value.yearFrom === "" ? null : Number(value.yearFrom), yearTo: value.yearTo == null || value.yearTo === "" ? null : Number(value.yearTo),
      includeUnknownYear: value.includeUnknownYear !== false, animeType: value.animeType ? value.animeType.trim() : "", difficultyMin: value.difficultyMin == null || value.difficultyMin === "" ? null : Number(value.difficultyMin), difficultyMax: value.difficultyMax == null || value.difficultyMax === "" ? null : Number(value.difficultyMax),
      songType: value.songType ? value.songType.trim() : "", watchStatus: value.watchStatus || "",
      randomSample: value.randomSample === true, clipStartSeconds: value.clipStartSeconds == null || value.clipStartSeconds === "" ? 0 : Number(value.clipStartSeconds),
      autoNextDelaySeconds: value.autoNextDelaySeconds === undefined ? 0 : value.autoNextDelaySeconds,
      chineseTitlesEnabled: value.chineseTitlesEnabled === true };
  }
  function clone(value) { return { ...value, catalogFilterPresets: (value.catalogFilterPresets || []).map(item => ({ ...item, filters: { ...item.filters } })) }; }
  function createAppSettingsStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const listeners = new Set();
    let state = clone(DEFAULTS);
    let blocked = false;
    let error = null;
    let recoveryAvailable = false;
    let disposed = false;

    function notify(source) {
      const snapshot = getStatus();
      for (const listener of [...listeners]) { if (listeners.has(listener)) { try { listener(snapshot, getSettings(), source); } catch (_) {} } }
    }
    function quarantine(raw) {
      if (raw == null) return true;
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        let key = RECOVERY_KEY;
        if (storage.getItem(key) !== null) key = `${RECOVERY_KEY}_${Date.now()}`;
        storage.setItem(key, raw);
        recoveryAvailable = true;
        return true;
      } catch (cause) { error = cause && cause.message ? cause.message : "recovery-failed"; return false; }
    }
    function load(source = "refresh") {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      let raw;
      try {
        if (!storage || typeof storage.getItem !== "function") throw new Error("storage-unavailable");
        raw = storage.getItem(STORAGE_KEY);
      } catch (cause) {
        blocked = true; error = cause && cause.message ? cause.message : "storage-read-failed";
        notify(source);
        return Object.freeze({ ok: false, reason: error });
      }
      blocked = false; error = null; recoveryAvailable = false;
      if (raw == null || raw === "") { state = clone(DEFAULTS); notify(source); return Object.freeze({ ok: true, defaults: true }); }
      let parsed;
      try { parsed = JSON.parse(raw); } catch (_) { parsed = null; }
      const normalized = normalize(parsed);
      if (!normalized) {
        if (!quarantine(raw)) {
          blocked = true; error = error || "recovery-failed";
          notify(source);
          return Object.freeze({ ok: false, reason: error, recoveryAvailable: false });
        }
        state = clone(DEFAULTS);
        notify(source);
        return Object.freeze({ ok: true, recovered: true });
      }
      state = normalized; notify(source);
      return Object.freeze({ ok: true, recovered: false });
    }
    function set(patch) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      if (blocked) return Object.freeze({ ok: false, persisted: false, reason: "persistence-blocked" });
      if (!patch || typeof patch !== "object" || Array.isArray(patch)) return Object.freeze({ ok: false, persisted: false, reason: "invalid-patch" });
      const candidate = normalize({ ...state, ...patch, schemaVersion: 1 });
      if (!candidate || Object.keys(patch).some(key => !["target", "questionCount", "clipSeconds", "acceptPartial", "autoPlay", "customListId", "srsEnabled", "yearFrom", "yearTo", "includeUnknownYear", "animeType", "difficultyMin", "difficultyMax", "songType", "watchStatus", "randomSample", "clipStartSeconds", "autoNextDelaySeconds", "chineseTitlesEnabled", "catalogFilterPresets"].includes(key))) {
        return Object.freeze({ ok: false, persisted: false, reason: "invalid-settings" });
      }
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(STORAGE_KEY, JSON.stringify(candidate));
      } catch (cause) {
        error = cause && cause.message ? cause.message : "storage-write-failed";
        notify("write-failed");
        return Object.freeze({ ok: false, persisted: false, reason: error });
      }
      state = candidate; error = null; recoveryAvailable = false;
      try {
        if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT, getSettings());
        else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT, { detail: getSettings() }));
      } catch (_) {}
      notify("local");
      return Object.freeze({ ok: true, persisted: true, settings: getSettings() });
    }
    function getSettings() { return Object.freeze(clone(state)); }
    function getStatus() { return Object.freeze({ blocked, error, recoveryAvailable, recoveryNotice: recoveryAvailable,
      persisted: !blocked && !error && !recoveryAvailable, storageKey: STORAGE_KEY }); }
    function onStorage(event) { if (!disposed && event && (event.key === null || event.key === STORAGE_KEY)) load("external"); }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener); let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function dispose() {
      if (disposed) return false;
      disposed = true;
      if (eventTarget && typeof eventTarget.removeEventListener === "function") eventTarget.removeEventListener("storage", onStorage);
      listeners.clear(); return true;
    }
    load("init");
    if (eventTarget && typeof eventTarget.addEventListener === "function") eventTarget.addEventListener("storage", onStorage);
    return Object.freeze({ storageKey: STORAGE_KEY, recoveryKey: RECOVERY_KEY, updateEvent: UPDATE_EVENT,
      getSettings, getStatus, set, refresh: () => load("refresh"), subscribe, dispose,
      get isDisposed() { return disposed; } });
  }
  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.appSettingsStore = Object.freeze({ createAppSettingsStore, storageKey: STORAGE_KEY, recoveryKey: RECOVERY_KEY,
    updateEvent: UPDATE_EVENT, defaults: DEFAULTS, normalize, normalizeCatalogFilterPresets });
})(window);
