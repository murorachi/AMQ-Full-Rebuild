/* Source-aware quiz history. Legacy history and summaries are read-only; new writes use independent versioned keys. */
(function (global) {
  "use strict";

  const DETAIL_KEY = "amqLearningQuizHistoryV1";
  const SUMMARY_KEY = "amqLearningQuizHistorySummaryV1";
  const DETAIL_RECOVERY_KEY = "amqLearningQuizHistoryRecoveryV1";
  const SUMMARY_RECOVERY_KEY = "amqLearningQuizHistorySummaryRecoveryV1";
  const LEGACY_DETAIL_KEY = "aniQuizHistory_v1";
  const LEGACY_SUMMARY_KEY = "aniQuizHistorySummaryV1";
  const LEGACY_TARGET_SUMMARY_KEY = "aniQuizTargetSummaryV1";
  const LAST_COMPLETED_ROUND_KEY = "amqLearningQuizLastCompletedRoundV1";
  const UPDATE_EVENT = "amq-learning-quiz-history-updated-v1";
  const DETAIL_LIMIT = 2000;
  const DEDUPE_WINDOW = 5000;
  const SUMMARY_SAVE_DELAY_MS = 30000;
  const SUMMARY_SAVE_BATCH = 20;
  const SOURCES = Object.freeze(["AMQ", "EMQ", "UNKNOWN"]);
  const TARGETS = Object.freeze(["anime", "title", "artist", "unknown"]);

  function isMap(value) { return Boolean(value && typeof value === "object" && !Array.isArray(value)); }
  function validCount(value) { return Number.isInteger(value) && value >= 0; }
  function nearNumber(a, b) { return Number.isFinite(Number(a)) && Number.isFinite(Number(b)) && Math.abs(Number(a) - Number(b)) <= Math.max(1e-7, Math.abs(Number(b)) * 1e-9); }
  function normalizeSource(value) {
    const source = String(value || "").toUpperCase();
    return source === "AMQ" || source === "EMQ" ? source : "UNKNOWN";
  }
  function normalizeTarget(value) { return TARGETS.includes(value) ? value : "unknown"; }
  function normalizeCorrect(value) { return value === true || value === 1 || String(value).toLowerCase() === "true"; }
  function entryKey(entry) {
    if (entry && entry.id != null && String(entry.id)) return String(entry.id);
    return "legacy:" + [entry && entry.source, entry && entry.songId, entry && entry.at, entry && entry.correct, entry && entry.answer, entry && entry.roundId].map(value => String(value ?? "")).join("|");
  }
  function createEmptySummary(now) {
    const at = new Date(now()).toISOString();
    const row = () => [0, 0, 0, 0, 0];
    return {
      schemaVersion: 1, createdAt: at,
      baseline: { sourceRecordCount: 0, mayBeTruncated: false, migratedAt: at },
      total: 0, correct: 0, wrong: 0, elapsedCount: 0, elapsedSum: 0,
      last: null,
      bySource: { AMQ: row(), EMQ: row(), UNKNOWN: row() },
      byTarget: { anime: row(), title: row(), artist: row(), unknown: row() },
      bySong: {}, byDay: {}, processedIds: [], processedCursor: 0
    };
  }
  function validateSummary(summary) {
    if (!isMap(summary) || summary.schemaVersion !== 1 || !validCount(summary.total) || !validCount(summary.correct)
      || !validCount(summary.wrong) || summary.total !== summary.correct + summary.wrong
      || !validCount(summary.elapsedCount) || summary.elapsedCount > summary.total
      || !Number.isFinite(summary.elapsedSum) || summary.elapsedSum < 0
      || (summary.elapsedCount === 0 && summary.elapsedSum !== 0)
      || !isMap(summary.bySource) || !isMap(summary.byTarget) || !isMap(summary.bySong) || !isMap(summary.byDay)
      || !Array.isArray(summary.processedIds) || summary.processedIds.length > DEDUPE_WINDOW
      || !summary.processedIds.every(value => typeof value === "string" && value.length > 0)
      || new Set(summary.processedIds).size !== summary.processedIds.length
      || !validCount(summary.processedCursor) || summary.processedCursor >= DEDUPE_WINDOW) return false;
    if (summary.total > 0 && (!Array.isArray(summary.last) || summary.last.length < 4 || !Number.isFinite(Number(summary.last[0]))
      || !SOURCES.includes(summary.last[1]) || String(summary.last[2] ?? "") === "" || ![0, 1].includes(Number(summary.last[3])))) return false;
    if (summary.total === 0 && summary.last !== null) return false;

    let sourceTotal = 0, sourceCorrect = 0, sourceWrong = 0, sourceElapsedCount = 0, sourceElapsedSum = 0;
    for (const source of SOURCES) {
      const row = summary.bySource[source];
      if (!Array.isArray(row) || row.length < 5 || !validCount(row[0]) || !validCount(row[1]) || !validCount(row[2])
        || row[0] !== row[1] + row[2] || !validCount(row[3]) || row[3] > row[0] || !Number.isFinite(row[4]) || row[4] < 0
        || (row[3] === 0 && row[4] !== 0)) return false;
      sourceTotal += row[0]; sourceCorrect += row[1]; sourceWrong += row[2]; sourceElapsedCount += row[3]; sourceElapsedSum += row[4];
    }
    if (sourceTotal !== summary.total || sourceCorrect !== summary.correct || sourceWrong !== summary.wrong
      || sourceElapsedCount !== summary.elapsedCount || !nearNumber(sourceElapsedSum, summary.elapsedSum)) return false;

    let targetTotal = 0, targetCorrect = 0, targetWrong = 0, targetElapsedCount = 0, targetElapsedSum = 0;
    for (const target of TARGETS) {
      const row = summary.byTarget[target];
      if (!Array.isArray(row) || row.length < 5 || !validCount(row[0]) || !validCount(row[1]) || !validCount(row[2])
        || row[0] !== row[1] + row[2] || !validCount(row[3]) || row[3] > row[0] || !Number.isFinite(row[4]) || row[4] < 0
        || (row[3] === 0 && row[4] !== 0)) return false;
      targetTotal += row[0]; targetCorrect += row[1]; targetWrong += row[2]; targetElapsedCount += row[3]; targetElapsedSum += row[4];
    }
    if (targetTotal !== summary.total || targetCorrect !== summary.correct || targetWrong !== summary.wrong
      || targetElapsedCount !== summary.elapsedCount || !nearNumber(targetElapsedSum, summary.elapsedSum)) return false;

    let songTotal = 0, songCorrect = 0, songWrong = 0, songElapsedCount = 0, songElapsedSum = 0;
    for (const row of Object.values(summary.bySong)) {
      if (!Array.isArray(row) || row.length < 7 || !validCount(row[0]) || row[0] < 1 || !validCount(row[1]) || !validCount(row[2])
        || row[0] !== row[1] + row[2] || !validCount(row[3]) || row[3] > row[0] || !Number.isFinite(row[4]) || row[4] < 0
        || (row[3] === 0 && row[4] !== 0) || !Number.isFinite(Number(row[5])) || Number(row[5]) < 0
        || !(row[6] === null || row[6] === 0 || row[6] === 1)) return false;
      songTotal += row[0]; songCorrect += row[1]; songWrong += row[2]; songElapsedCount += row[3]; songElapsedSum += row[4];
    }
    if (songTotal !== summary.total || songCorrect !== summary.correct || songWrong !== summary.wrong
      || songElapsedCount !== summary.elapsedCount || !nearNumber(songElapsedSum, summary.elapsedSum)) return false;

    let dayTotal = 0, dayCorrect = 0, dayWrong = 0, dayElapsedCount = 0, dayElapsedSum = 0;
    for (const [day, row] of Object.entries(summary.byDay)) {
      if (!/^\d{4}-\d{2}-\d{2}$/.test(day) || !Array.isArray(row) || row.length < 5 || !validCount(row[0])
        || !validCount(row[1]) || !validCount(row[2]) || row[0] !== row[1] + row[2] || !validCount(row[3])
        || row[3] > row[0] || !Number.isFinite(row[4]) || row[4] < 0 || (row[3] === 0 && row[4] !== 0)) return false;
      const stamp = Date.parse(day + "T00:00:00.000Z");
      if (!Number.isFinite(stamp) || new Date(stamp).toISOString().slice(0, 10) !== day) return false;
      dayTotal += row[0]; dayCorrect += row[1]; dayWrong += row[2]; dayElapsedCount += row[3]; dayElapsedSum += row[4];
    }
    return dayTotal === summary.total && dayCorrect === summary.correct && dayWrong === summary.wrong
      && dayElapsedCount === summary.elapsedCount && nearNumber(dayElapsedSum, summary.elapsedSum);
  }

  function createQuizHistoryStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const documentTarget = deps.documentTarget || global.document || null;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    const random = typeof deps.random === "function" ? deps.random : Math.random;
    const schedule = typeof deps.setTimeout === "function" ? deps.setTimeout : global.setTimeout.bind(global);
    const unschedule = typeof deps.clearTimeout === "function" ? deps.clearTimeout : global.clearTimeout.bind(global);
    const listeners = new Set();
    let disposed = false;
    let history = [];
    let legacyHistory = [];
    let summary = null;
    let processedIds = new Set();
    let currentRoundId = null;
    let roundSerial = 0;
    let lastCompletedRoundId = null;
    let entrySerial = 0;
    let summaryPending = 0;
    let summaryTimer = null;
    let summaryTimerGeneration = 0;
    let summaryWriteBlocked = false;
    let summarySaveFailed = false;
    let detailWriteBlocked = false;
    let detailSaveFailed = false;
    // Track only rows added locally after a failed detail write. External snapshots
    // may replace durable history, but must not erase these uncommitted local rows.
    const pendingDetailIds = new Set();
    let detailRecoveryNotice = false;
    let lastDetailError = null;
    let lastSummaryError = null;
    let legacyReadError = null;

    function parseMap(raw) { try { const parsed = JSON.parse(raw || "null"); return isMap(parsed) ? parsed : null; } catch (_) { return null; } }
    function readArray(key) {
      if (!storage || typeof storage.getItem !== "function") return null;
      let raw;
      try { raw = storage.getItem(key); } catch (_) { return null; }
      try { const parsed = JSON.parse(raw || "[]"); return Array.isArray(parsed) ? parsed : []; } catch (_) { return []; }
    }
    function preserveInvalidDetail(raw) {
      if (raw == null) return true;
      if (!storage || typeof storage.setItem !== "function") return false;
      try {
        const existing = storage.getItem(DETAIL_RECOVERY_KEY);
        if (existing === raw) return true;
        const key = existing === null ? DETAIL_RECOVERY_KEY : `${DETAIL_RECOVERY_KEY}_${now()}_${random().toString(36).slice(2, 6)}`;
        storage.setItem(key, raw);
        return true;
      } catch (error) {
        lastDetailError = error && error.message ? error.message : "detail-recovery-failed";
        return false;
      }
    }
    function readCurrentDetail() {
      detailWriteBlocked = false;
      detailRecoveryNotice = false;
      if (!storage || typeof storage.getItem !== "function") return [];
      let raw;
      try { raw = storage.getItem(DETAIL_KEY); }
      catch (error) { detailWriteBlocked = true; lastDetailError = error && error.message ? error.message : "detail-read-failed"; return []; }
      if (raw === null || raw === undefined || raw === "") return [];
      let parsed;
      try { parsed = JSON.parse(raw); }
      catch (_) { parsed = null; }
      if (!Array.isArray(parsed)) {
        if (!preserveInvalidDetail(raw)) detailWriteBlocked = true;
        if (!detailWriteBlocked) { detailRecoveryNotice = true; lastDetailError = "invalid-detail-quarantined"; }
        else lastDetailError = lastDetailError || "invalid-detail-recovery-failed";
        return [];
      }
      const normalized = parsed.map(normalizeEntry).filter(Boolean);
      if (normalized.length !== parsed.length) {
        if (!preserveInvalidDetail(raw)) detailWriteBlocked = true;
        else { detailRecoveryNotice = true; lastDetailError = "invalid-detail-entries-quarantined"; }
      } else lastDetailError = null;
      return normalized.slice(-DETAIL_LIMIT);
    }
    function freezeDeep(value) {
      if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
      for (const child of Object.values(value)) freezeDeep(child);
      return Object.freeze(value);
    }
    function legacySource(value) {
      const raw = String(value || "").toLowerCase();
      return raw === "amq" ? "AMQ" : raw === "emq" ? "EMQ" : "UNKNOWN";
    }
    function normalizeLegacyEntry(entry) {
      if (!entry || typeof entry !== "object" || entry.songId === undefined || entry.songId === null) return null;
      return Object.freeze({ ...entry, source: legacySource(entry.source), target: normalizeTarget(entry.target),
        correct: normalizeCorrect(entry.correct), elapsed: entry.elapsed !== null && entry.elapsed !== undefined && Number.isFinite(Number(entry.elapsed)) && Number(entry.elapsed) >= 0 ? Number(entry.elapsed) : null,
        origin: "legacy" });
    }
    function loadLegacyHistory() {
      const rows = readArray(LEGACY_DETAIL_KEY);
      if (rows === null) { legacyReadError = "legacy-history-read-failed"; return false; }
      legacyHistory = rows.map(normalizeLegacyEntry).filter(Boolean);
      legacyReadError = null;
      return true;
    }
    function readLegacySummary() {
      let overallRaw = null; let targetRaw = null;
      try { overallRaw = storage && storage.getItem ? storage.getItem(LEGACY_SUMMARY_KEY) : null; } catch (_) {}
      try { targetRaw = storage && storage.getItem ? storage.getItem(LEGACY_TARGET_SUMMARY_KEY) : null; } catch (_) {}
      const overall = parseMap(overallRaw);
      const target = parseMap(targetRaw);
      const validOverall = overall && validCount(overall.total) && validCount(overall.correct) && validCount(overall.wrong) && overall.total === overall.correct + overall.wrong;
      const total = validOverall ? overall.total : legacyHistory.length;
      const correct = validOverall ? overall.correct : legacyHistory.filter(entry => entry.correct).length;
      const wrong = validOverall ? overall.wrong : Math.max(0, total - correct);
      const byTarget = target && isMap(target.byTarget) ? target.byTarget : null;
      return Object.freeze({ total, correct, wrong, byTarget, source: validOverall ? "legacy-summary-read-only" : "legacy-detail-fallback" });
    }
    function notify(detail) {
      const state = Object.freeze({ detailSaveFailed, summarySaveFailed, summaryWriteBlocked, ...detail });
      for (const listener of [...listeners]) {
        if (!listeners.has(listener)) continue;
        try { listener(state); } catch (_) {}
      }
    }
    function normalizeEntry(raw) {
      if (!raw || typeof raw !== "object" || raw.songId === undefined || raw.songId === null || String(raw.songId).trim() === "") return null;
      const source = normalizeSource(raw.source);
      if (source === "UNKNOWN") return null;
      const target = normalizeTarget(raw.target);
      const parsedAt = Date.parse(raw.at || "");
      const at = Number.isFinite(parsedAt) ? new Date(parsedAt).toISOString() : new Date(now()).toISOString();
      const elapsed = raw.elapsed !== null && raw.elapsed !== undefined && Number.isFinite(Number(raw.elapsed)) && Number(raw.elapsed) >= 0 ? Number(raw.elapsed) : null;
      const correct = normalizeCorrect(raw.correct);
      const id = raw.id == null || String(raw.id) === "" ? `qh${now()}-${random().toString(36).slice(2, 8)}-${++entrySerial}` : String(raw.id);
      return Object.freeze({ ...raw, id, source, songId: String(raw.songId), animeId: raw.animeId == null ? "" : String(raw.animeId),
        workKind: raw.workKind || (source === "EMQ" ? "visual_novel_game" : "anime"), target, at, correct,
        answer: String(raw.answer ?? ""), elapsed, validAudio: raw.validAudio !== false, origin: "current" });
    }
    function summaryEntryKey(entry) { return entryKey(entry); }
    function row5() { return [0, 0, 0, 0, 0]; }
    function addRow(row, correct, elapsed) {
      row[0]++;
      if (correct) row[1]++; else row[2]++;
      if (elapsed !== null) { row[3]++; row[4] += elapsed; }
    }
    function addSummaryEntry(entry) {
      if (!summary || !entry || entry.songId == null) return false;
      const key = summaryEntryKey(entry);
      if (processedIds.has(key)) return false;
      const source = normalizeSource(entry.source);
      const target = normalizeTarget(entry.target);
      const sid = String(entry.songId);
      const correct = normalizeCorrect(entry.correct);
      const parsedAt = Date.parse(entry.at || "");
      const at = Number.isFinite(parsedAt) ? parsedAt : now();
      const day = new Date(at).toISOString().slice(0, 10);
      const elapsed = entry.elapsed !== null && entry.elapsed !== undefined && Number.isFinite(Number(entry.elapsed)) && Number(entry.elapsed) >= 0 ? Number(entry.elapsed) : null;
      summary.total++;
      if (correct) summary.correct++; else summary.wrong++;
      if (elapsed !== null) { summary.elapsedCount++; summary.elapsedSum += elapsed; }
      addRow(summary.bySource[source], correct, elapsed);
      addRow(summary.byTarget[target], correct, elapsed);
      const songKey = `${source}:${sid}`;
      const songRow = summary.bySong[songKey] || (summary.bySong[songKey] = [0, 0, 0, 0, 0, 0, null]);
      addRow(songRow, correct, elapsed);
      if (at >= Number(songRow[5] || 0)) { songRow[5] = at; songRow[6] = correct ? 1 : 0; }
      const dayRow = summary.byDay[day] || (summary.byDay[day] = row5());
      addRow(dayRow, correct, elapsed);
      if (!summary.last || at >= Number(summary.last[0] || 0)) summary.last = [at, source, sid, correct ? 1 : 0];
      if (summary.processedIds.length < DEDUPE_WINDOW) summary.processedIds.push(key);
      else {
        const cursor = (Number(summary.processedCursor) || 0) % DEDUPE_WINDOW;
        const old = summary.processedIds[cursor];
        if (old !== undefined) processedIds.delete(old);
        summary.processedIds[cursor] = key;
        summary.processedCursor = (cursor + 1) % DEDUPE_WINDOW;
      }
      processedIds.add(key);
      return true;
    }
    function rebuildProcessedIds() { processedIds = new Set(Array.isArray(summary && summary.processedIds) ? summary.processedIds.map(String) : []); }
    function preserveInvalidSummary(raw) {
      if (raw == null) return true;
      if (!storage || typeof storage.setItem !== "function") return false;
      try {
        const existing = storage.getItem(SUMMARY_RECOVERY_KEY);
        if (existing === raw) return true;
        const key = existing === null ? SUMMARY_RECOVERY_KEY : `${SUMMARY_RECOVERY_KEY}_${now()}_${random().toString(36).slice(2, 6)}`;
        storage.setItem(key, raw);
        return true;
      } catch (_) { return false; }
    }
    function persistDetail() {
      if (detailWriteBlocked) {
        detailSaveFailed = true;
        lastDetailError = lastDetailError || "detail-write-blocked";
        return false;
      }
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(DETAIL_KEY, JSON.stringify(history));
        pendingDetailIds.clear();
        detailSaveFailed = false; lastDetailError = null; return true;
      } catch (error) {
        detailSaveFailed = true; lastDetailError = error && error.message ? error.message : "detail-save-failed"; return false;
      }
    }
    function cancelSummaryTimer() {
      // clearTimeout cannot retract a callback that has already entered the task queue.
      // Advance the generation as well so stale callbacks become inert.
      summaryTimerGeneration++;
      if (summaryTimer !== null) { unschedule(summaryTimer); summaryTimer = null; }
    }
    function persistSummary() {
      cancelSummaryTimer();
      if (!summary) return false;
      if (summaryWriteBlocked) { summarySaveFailed = true; lastSummaryError = "summary-write-blocked"; return false; }
      // Detail history is authoritative. Do not persist aggregate counts for rows
      // that have not been durably written, or a reload can show phantom totals.
      if (detailSaveFailed || detailWriteBlocked) {
        summarySaveFailed = true;
        lastSummaryError = lastDetailError || "detail-persistence-incomplete";
        return false;
      }
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(SUMMARY_KEY, JSON.stringify(summary));
        summaryPending = 0; summarySaveFailed = false; lastSummaryError = null; return true;
      } catch (error) {
        summarySaveFailed = true; lastSummaryError = error && error.message ? error.message : "summary-save-failed"; return false;
      }
    }
    function scheduleSummarySave(entryCount) {
      summaryPending += Number.isInteger(entryCount) && entryCount > 0 ? entryCount : 1;
      if (summaryPending >= SUMMARY_SAVE_BATCH) { persistSummary(); return; }
      if (summaryTimer === null) {
        const generation = ++summaryTimerGeneration;
        summaryTimer = schedule(() => {
          if (disposed || generation !== summaryTimerGeneration) return;
          summaryTimer = null;
          persistSummary();
        }, SUMMARY_SAVE_DELAY_MS);
      }
    }
    function syncSummaryFromDetail() {
      if (!summary) return false;
      let changed = false;
      for (const entry of history.slice().sort((a, b) => (Date.parse(a.at || "") || 0) - (Date.parse(b.at || "") || 0))) {
        if (addSummaryEntry(entry)) changed = true;
      }
      if (changed) persistSummary();
      return changed;
    }
    function initializeSummary(forceRebuildFromDetail = false) {
      let raw = null; let stored = null;
      summaryWriteBlocked = false;
      try {
        if (!storage || typeof storage.getItem !== "function") throw new Error("storage-unavailable");
        raw = storage.getItem(SUMMARY_KEY);
      } catch (error) {
        // A failed read is not evidence that the key is empty. Keep a usable in-memory
        // summary, but never overwrite storage until a later refresh reads it successfully.
        summaryWriteBlocked = true;
        summarySaveFailed = true;
        lastSummaryError = error && error.message ? error.message : "summary-read-failed";
      }
      if (!summaryWriteBlocked) {
        try { stored = JSON.parse(raw || "null"); } catch (_) { stored = null; }
      }
      if (validateSummary(stored) && !forceRebuildFromDetail) {
        summaryWriteBlocked = false;
        summarySaveFailed = false;
        lastSummaryError = null;
        summary = stored; rebuildProcessedIds(); syncSummaryFromDetail(); return;
      }
      if (!summaryWriteBlocked && raw !== null && !validateSummary(stored)) summaryWriteBlocked = !preserveInvalidSummary(raw);
      summary = createEmptySummary(now);
      summary.baseline = { sourceRecordCount: history.length, mayBeTruncated: detailRecoveryNotice || history.length >= DETAIL_LIMIT, migratedAt: new Date(now()).toISOString() };
      processedIds = new Set();
      summaryPending = 0;
      rebuildProcessedIds();
      for (const entry of history.slice().sort((a, b) => (Date.parse(a.at || "") || 0) - (Date.parse(b.at || "") || 0))) addSummaryEntry(entry);
      if (!summaryWriteBlocked) persistSummary();
    }
    function reloadExternal(eventKey = null) {
      const previousHistory = history;
      const canRebuildSummaryFromDetail = eventKey === DETAIL_KEY && Boolean(summary && summary.baseline && summary.baseline.mayBeTruncated !== true);
      const pendingRows = previousHistory.filter(entry => pendingDetailIds.has(entryKey(entry)));
      const refreshedHistory = readCurrentDetail();
      // A storage exception is not proof that detail history is empty. Retain the
      // last known snapshot until a successful read or a confirmed empty key arrives.
      if (detailWriteBlocked) {
        history = previousHistory;
      } else {
        history = refreshedHistory;
        if (pendingRows.length) {
          // Preserve only local rows known not to have reached storage. Merging the
          // entire old snapshot would resurrect rows another tab intentionally removed.
          const known = new Set(history.map(entryKey));
          for (const entry of pendingRows) {
            const key = entryKey(entry);
            if (!known.has(key)) { history.push(entry); known.add(key); }
          }
          history = history.slice(-DETAIL_LIMIT);
          // Retry the merged authoritative detail before rebuilding its aggregate.
          persistDetail();
        }
      }
      loadLegacyHistory();
      // When the full detail set is available, it is authoritative for the summary.
      // A valid old aggregate can otherwise retain counts for rows removed by an
      // external restore/replacement because the usual sync path only increments.
      const rebuildSummary = canRebuildSummaryFromDetail && !detailWriteBlocked && !detailSaveFailed && pendingDetailIds.size === 0;
      initializeSummary(rebuildSummary);
      notify({ source: "external" });
    }
    function onStorage(event) {
      if (disposed || !event || ![null, DETAIL_KEY, SUMMARY_KEY, LEGACY_DETAIL_KEY, LEGACY_SUMMARY_KEY, LEGACY_TARGET_SUMMARY_KEY].includes(event.key)) return;
      reloadExternal(event.key);
    }
    function onPageHide() { flush(); }
    function onVisibilityChange() { try { if (documentTarget && documentTarget.visibilityState === "hidden") flush(); } catch (_) {} }

    history = readCurrentDetail();
    loadLegacyHistory();
    roundSerial = Math.max(0, ...history.map(entry => Number(entry.roundNo) || 0), ...legacyHistory.map(entry => Number(entry.roundNo) || 0));
    initializeSummary();
    if (eventTarget && typeof eventTarget.addEventListener === "function") {
      eventTarget.addEventListener("storage", onStorage);
      eventTarget.addEventListener("pagehide", onPageHide);
    }
    if (documentTarget && typeof documentTarget.addEventListener === "function") documentTarget.addEventListener("visibilitychange", onVisibilityChange);

    function readLastCompletedRoundId() {
      if (!storage || typeof storage.getItem !== "function") return lastCompletedRoundId;
      try {
        const raw = storage.getItem(LAST_COMPLETED_ROUND_KEY);
        if (!raw) return null;
        const value = JSON.parse(raw);
        if (!isMap(value) || value.schemaVersion !== 1 || typeof value.roundId !== "string" || !value.roundId.trim()
          || !Number.isFinite(Date.parse(value.completedAt || ""))) return null;
        return value.roundId;
      } catch (_) { return null; }
    }
    function clearLastCompletedRound() {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      lastCompletedRoundId = null;
      if (!storage) return Object.freeze({ ok: false, persisted: false, reason: "storage-unavailable" });
      try {
        if (typeof storage.removeItem === "function") storage.removeItem(LAST_COMPLETED_ROUND_KEY);
        else if (typeof storage.setItem === "function") storage.setItem(LAST_COMPLETED_ROUND_KEY, "");
        else return Object.freeze({ ok: false, persisted: false, reason: "storage-unavailable" });
        return Object.freeze({ ok: true, persisted: true });
      } catch (error) {
        lastDetailError = error && error.message ? error.message : "round-completion-clear-failed";
        return Object.freeze({ ok: false, persisted: false, reason: "storage-write-failed" });
      }
    }
    function completeRound(roundId) {
      const key = typeof roundId === "string" ? roundId.trim() : "";
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      if (!key || key !== currentRoundId) return Object.freeze({ ok: false, persisted: false, reason: "round-id-mismatch" });
      if (!storage || typeof storage.setItem !== "function") return Object.freeze({ ok: false, persisted: false, reason: "storage-unavailable" });
      const completedAt = new Date(now()).toISOString();
      try {
        storage.setItem(LAST_COMPLETED_ROUND_KEY, JSON.stringify({ schemaVersion: 1, roundId: key, completedAt }));
        lastCompletedRoundId = key;
        return Object.freeze({ ok: true, persisted: true, roundId: key, completedAt });
      } catch (error) {
        lastDetailError = error && error.message ? error.message : "round-completion-save-failed";
        return Object.freeze({ ok: false, persisted: false, reason: "storage-write-failed" });
      }
    }
    function beginRound() {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed", roundId: null, roundNo: roundSerial });
      // A new round invalidates the previous completed-result pointer before it can be shown as current.
      // Do not hide a failed pointer clear: durable storage may still restore the previous round after reload.
      const previousResultClear = clearLastCompletedRound();
      roundSerial++;
      currentRoundId = `r${now()}-${roundSerial}`;
      return Object.freeze({ ok: true, roundId: currentRoundId, roundNo: roundSerial,
        previousResultClear, warning: previousResultClear && previousResultClear.persisted === false
          ? "previous-result-clear-failed" : null });
    }
    function appendEntries(entries) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed", entriesAdded: 0 });
      if (!Array.isArray(entries)) throw new TypeError("history entries must be an array");
      const normalized = entries.map(normalizeEntry).filter(Boolean);
      if (!normalized.length) return Object.freeze({ ok: true, persisted: true, entriesAdded: 0 });
      const known = new Set(history.map(entryKey));
      const fresh = normalized.filter(entry => { const key = entryKey(entry); if (known.has(key)) return false; known.add(key); return true; });
      if (!fresh.length) return Object.freeze({ ok: true, persisted: true, entriesAdded: 0, duplicate: true });
      history.push(...fresh);
      if (history.length > DETAIL_LIMIT) {
        history = history.slice(-DETAIL_LIMIT);
        if (summary && summary.baseline) {
          summary.baseline.mayBeTruncated = true;
          summary.baseline.sourceRecordCount = Math.max(Number(summary.baseline.sourceRecordCount) || 0, DETAIL_LIMIT);
        }
      }
      for (const entry of fresh) addSummaryEntry(entry);
      const detailPersisted = persistDetail();
      if (!detailPersisted) for (const entry of fresh) pendingDetailIds.add(entryKey(entry));
      scheduleSummarySave(fresh.length);
      for (const entry of fresh) dispatchUpdate(entry);
      const persistence = getPersistenceStatus();
      const fullyPersisted = persistence.detailPersisted && persistence.summaryPersisted;
      notify({ source: "append", entriesAdded: fresh.length, persisted: detailPersisted, fullyPersisted });
      return Object.freeze({ ok: true, persisted: detailPersisted, fullyPersisted, detailPersisted,
        summaryPersisted: persistence.summaryPersisted, summaryPending: persistence.summaryPending,
        summaryFailed: persistence.summarySaveFailed || persistence.summaryWriteBlocked,
        entriesAdded: fresh.length, reason: detailPersisted ? (persistence.summarySaveFailed || persistence.summaryWriteBlocked ? lastSummaryError || "summary-persistence-incomplete" : null) : lastDetailError });
    }
    function dispatchUpdate(entry) {
      try {
        if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT, entry);
        else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT, { detail: { id: entry.id, source: entry.source, songId: entry.songId, target: entry.target } }));
      } catch (_) {}
    }
    function recordResult(input) {
      const payload = input && typeof input === "object" ? input : {};
      const question = payload.question;
      const result = payload.result;
      if (!question || !result || result.scored !== true) {
        return Object.freeze({ ok: true, persisted: true, entriesAdded: 0, skipped: true });
      }
      if (!currentRoundId) beginRound();
      const source = normalizeSource(question.source);
      if (source === "UNKNOWN") return Object.freeze({ ok: false, persisted: false, reason: "invalid-source", entriesAdded: 0 });
      const targets = result.target === "all" ? ["anime", "title", "artist"] : [normalizeTarget(result.target)];
      const at = new Date(now()).toISOString();
      const elapsed = Number.isFinite(Number(result.elapsedSeconds)) && result.elapsedSeconds !== null && Number(result.elapsedSeconds) >= 0 ? Number(result.elapsedSeconds) : null;
      const entries = targets.map(target => {
        const correct = result.target === "all" ? Boolean(result.correctByTarget && result.correctByTarget[target]) : normalizeCorrect(result.correct);
        const answer = result.answers && typeof result.answers === "object" ? result.answers[target] : result.answers;
        const workTitle = String(question.animeTitle || question.animeAlternateTitle || "未知作品");
        const aliases = [question.animeAlternateTitle].filter(value => typeof value === "string" && value.trim() && value.trim() !== workTitle);
        const label = result.kind === "timeout" ? "時間到" : result.kind === "skip" ? "跳過" : correct ? "答對" : "答錯";
        return {
          id: `qh${now()}-${random().toString(36).slice(2, 8)}-${++entrySerial}`,
          roundId: currentRoundId, roundNo: roundSerial, at, songId: String(question.id), animeId: String(question.animeId ?? ""),
          source, workKind: question.workKind || (source === "EMQ" ? "visual_novel_game" : "anime"),
          workTitle, workAliases: aliases, songName: String(question.title || "未命名歌曲"), artist: String(question.artist || "歌手未標示"),
          animeEnglish: workTitle, animeRomaji: String(question.animeAlternateTitle || workTitle), target,
          validAudio: true, correct, answer: String(answer ?? ""), elapsed, result: label
        };
      });
      return appendEntries(entries);
    }
    function getHistory() {
      const combined = [...legacyHistory, ...history].map(entry => entry);
      combined.sort((a, b) => (Date.parse(a.at || "") || 0) - (Date.parse(b.at || "") || 0));
      return Object.freeze(combined.map(entry => Object.isFrozen(entry) ? entry : Object.freeze({ ...entry })));
    }
    // Round results must never be reconstructed from legacy or cross-round history.
    // Only records explicitly written with this round ID are eligible.
    function getRoundHistory(roundId) {
      const key = typeof roundId === "string" ? roundId.trim() : "";
      if (!key) return Object.freeze([]);
      const rows = history.filter(entry => entry && entry.roundId === key)
        .slice().sort((a, b) => (Date.parse(a.at || "") || 0) - (Date.parse(b.at || "") || 0));
      return Object.freeze(rows.map(entry => Object.freeze({ ...entry, persisted: !pendingDetailIds.has(entryKey(entry)) })));
    }
    function getSummary() {
      const legacy = readLegacySummary();
      return Object.freeze({ current: freezeDeep(JSON.parse(JSON.stringify(summary))), legacy,
        combinedTotal: legacy.total + summary.total,
        persistence: getPersistenceStatus() });
    }
    function getPersistenceStatus() {
      return Object.freeze({ detailSaveFailed, detailWriteBlocked, detailRecoveryNotice, summarySaveFailed, summaryWriteBlocked, lastDetailError, lastSummaryError, legacyReadError,
        summaryPending, detailPersisted: !detailSaveFailed && !detailWriteBlocked,
        summaryPersisted: summaryPending === 0 && !summarySaveFailed && !summaryWriteBlocked,
        fullyPersisted: !detailSaveFailed && !detailWriteBlocked && summaryPending === 0 && !summarySaveFailed && !summaryWriteBlocked });
    }
    function flush() {
      cancelSummaryTimer();
      const detailOk = persistDetail();
      const summaryOk = persistSummary();
      return Object.freeze({ ok: detailOk && summaryOk, detailPersisted: detailOk, summaryPersisted: summaryOk,
        detailError: lastDetailError, summaryError: lastSummaryError });
    }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener); let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function dispose() {
      if (disposed) return false;
      flush();
      disposed = true;
      cancelSummaryTimer();
      if (eventTarget && typeof eventTarget.removeEventListener === "function") {
        eventTarget.removeEventListener("storage", onStorage); eventTarget.removeEventListener("pagehide", onPageHide);
      }
      if (documentTarget && typeof documentTarget.removeEventListener === "function") documentTarget.removeEventListener("visibilitychange", onVisibilityChange);
      listeners.clear();
      return true;
    }

    return Object.freeze({ beginRound, completeRound, clearLastCompletedRound, getLastCompletedRoundId: readLastCompletedRoundId,
      appendEntries, recordResult, getHistory, getRoundHistory, getSummary, getPersistenceStatus, flush, subscribe, dispose,
      getKeys: () => Object.freeze({ detail: DETAIL_KEY, summary: SUMMARY_KEY, detailRecovery: DETAIL_RECOVERY_KEY, summaryRecovery: SUMMARY_RECOVERY_KEY,
        lastCompletedRound: LAST_COMPLETED_ROUND_KEY,
        legacyDetail: LEGACY_DETAIL_KEY, legacySummary: LEGACY_SUMMARY_KEY, legacyTargetSummary: LEGACY_TARGET_SUMMARY_KEY, updateEvent: UPDATE_EVENT }),
      get isDisposed() { return disposed; } });
  }

  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.quizHistoryStore = Object.freeze({ createQuizHistoryStore, validateSummary,
    keys: Object.freeze({ DETAIL_KEY, SUMMARY_KEY, DETAIL_RECOVERY_KEY, SUMMARY_RECOVERY_KEY, LAST_COMPLETED_ROUND_KEY, LEGACY_DETAIL_KEY, LEGACY_SUMMARY_KEY, LEGACY_TARGET_SUMMARY_KEY, UPDATE_EVENT }),
    detailLimit: DETAIL_LIMIT, dedupeWindow: DEDUPE_WINDOW });
})(window);
