/* FSRS schedule persistence with a legacy-compatible AMQ store and a source-tagged EMQ store. */
(function (global) {
  "use strict";
  const AMQ_STORAGE_KEY = "aniSrsScheduleV1";
  const EMQ_STORAGE_KEY = "amqLearningEmqSrsScheduleV1";
  const AMQ_RECOVERY_PREFIX = "aniSrsScheduleRecoveryV1_";
  const EMQ_RECOVERY_PREFIX = "amqLearningEmqSrsRecoveryV1_";
  const UPDATE_EVENT = "amq-learning-srs-updated-v1";

  function createSrsStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const scheduler = global.AMQLearning && global.AMQLearning.fsrsScheduler;
    if (!scheduler) throw new TypeError("SRS store requires FSRS scheduler module");
    const source = String(deps.source || "AMQ").toUpperCase();
    if (!["AMQ", "EMQ"].includes(source)) throw new TypeError("SRS source must be AMQ or EMQ");
    const STORAGE_KEY = source === "AMQ" ? AMQ_STORAGE_KEY : EMQ_STORAGE_KEY;
    const RECOVERY_PREFIX = source === "AMQ" ? AMQ_RECOVERY_PREFIX : EMQ_RECOVERY_PREFIX;
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    const songExists = typeof deps.songExists === "function" ? deps.songExists : () => true;
    const isBlacklisted = typeof deps.isBlacklisted === "function" ? deps.isBlacklisted : () => false;
    const listeners = new Set();
    let persistenceBlocked = false;
    let recoveryRaw = null;
    let lastError = null;
    let disposed = false;
    let state = loadStore();

    function clone(value) { return JSON.parse(JSON.stringify(value)); }
    function freezeDeep(value) {
      if (!value || typeof value !== "object" || Object.isFrozen(value)) return value;
      for (const child of Object.values(value)) freezeDeep(child);
      return Object.freeze(value);
    }
    function notify(detail) {
      const snapshot = Object.freeze({ ...detail, persistenceBlocked, lastError, counts: counts() });
      for (const listener of [...listeners]) {
        if (!listeners.has(listener)) continue;
        try { listener(snapshot); } catch (_) {}
      }
    }
    function quarantine(raw) {
      try {
        if (!storage || typeof storage.setItem !== "function" || typeof storage.removeItem !== "function") throw new Error("storage-unavailable");
        const key = RECOVERY_PREFIX + now();
        storage.setItem(key, raw);
        storage.removeItem(STORAGE_KEY);
        recoveryRaw = raw;
        lastError = "invalid-schedule-quarantined";
        return true;
      } catch (error) {
        persistenceBlocked = true;
        recoveryRaw = raw;
        lastError = error && error.message ? error.message : "recovery-failed";
        return false;
      }
    }
    function isValidForSource(value) {
      if (!scheduler.isValidSchedule(value)) return false;
      if (source === "EMQ" && value.source !== "EMQ") return false;
      if (source === "AMQ" && value.source && value.source !== "AMQ") return false;
      return Object.values(value.cards).every(card => source === "EMQ" ? card.source === "EMQ" : (!card.source || card.source === "AMQ"));
    }
    function loadStore() {
      let raw = null;
      try { raw = storage && typeof storage.getItem === "function" ? storage.getItem(STORAGE_KEY) : null; }
      catch (error) { persistenceBlocked = true; lastError = error && error.message ? error.message : "storage-read-failed"; return { ...scheduler.emptySchedule(now()), ...(source === "EMQ" ? { source: "EMQ" } : {}) }; }
      if (raw === null || raw === undefined) return { ...scheduler.emptySchedule(now()), ...(source === "EMQ" ? { source: "EMQ" } : {}) };
      let parsed = null;
      try { parsed = JSON.parse(raw); } catch (_) {}
      if (isValidForSource(parsed)) {
        const baseline = scheduler.emptySchedule(now());
        return { ...baseline, ...parsed, ...(source === "EMQ" ? { source: "EMQ" } : {}), settings: { ...baseline.settings, ...parsed.settings }, cards: parsed.cards };
      }
      quarantine(raw);
      return { ...scheduler.emptySchedule(now()), ...(source === "EMQ" ? { source: "EMQ" } : {}) };
    }
    function persist(next) {
      if (source === "EMQ") next.source = "EMQ";
      if (disposed) { lastError = "disposed"; return false; }
      if (persistenceBlocked) { lastError = lastError || "persistence-blocked"; return false; }
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(STORAGE_KEY, JSON.stringify(next));
        state = next;
        lastError = null;
        // A validated replacement is now durable. Keep the quarantined bytes in storage,
        // but clear the active recovery warning so consumers can trust this schedule.
        recoveryRaw = null;
        try {
          if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT);
          else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT));
        } catch (_) {}
        notify({ source: "write" });
        return true;
      } catch (error) {
        lastError = error && error.message ? error.message : "storage-write-failed";
        notify({ source: "write-failed" });
        return false;
      }
    }
    function cardKey(id) {
      if (id && typeof id === "object") {
        if (String(id.source || "").toUpperCase() !== source) return null;
        id = id.id;
      }
      const key = String(id ?? "");
      return key && key !== "undefined" && key !== "null" ? key : null;
    }
    function getCard(id) {
      const key = cardKey(id);
      const card = key ? state.cards[key] : null;
      return card ? freezeDeep(clone(card)) : null;
    }
    function hasSong(id) { try { return Boolean(songExists(String(id), source)); } catch (_) { return false; } }
    function blacklisted(id) { try { return Boolean(isBlacklisted(String(id), source)); } catch (_) { return false; } }
    function makeSourceCard(id, timestamp) {
      const card = scheduler.makeCard(String(id), timestamp);
      if (source === "EMQ") card.source = "EMQ";
      return card;
    }
    function localDateCount(timestamp = now()) {
      const today = scheduler.localDay(timestamp);
      return Object.values(state.cards).filter(card => card.firstReviewedAt && scheduler.localDay(Number(card.firstReviewedAt)) === today).length;
    }
    function enroll(id, timestamp = now()) {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      if (id && typeof id === "object" && String(id.source || "").toUpperCase() !== source) return Object.freeze({ ok: false, reason: "unsupported-source" });
      const key = cardKey(id);
      if (!key) return Object.freeze({ ok: false, reason: "invalid" });
      if (!hasSong(key)) return Object.freeze({ ok: false, reason: "missing" });
      const prior = state.cards[key];
      if (prior) {
        if (prior.state === "suspended") {
          const next = clone(state); const card = next.cards[key];
          card.state = scheduler.VALID_STATES.has(card.resumeState) && card.resumeState !== "suspended" ? card.resumeState : "new";
          if (!persist(next)) return Object.freeze({ ok: false, reason: "storage" });
          return Object.freeze({ ok: true, created: false, resumed: true, card: getCard(key) });
        }
        return Object.freeze({ ok: true, created: false, resumed: false, card: getCard(key) });
      }
      const next = clone(state); next.cards[key] = makeSourceCard(key, timestamp);
      if (!persist(next)) return Object.freeze({ ok: false, reason: "storage" });
      return Object.freeze({ ok: true, created: true, resumed: false, card: getCard(key) });
    }
    function enrollMany(ids) {
      if (disposed || !Array.isArray(ids)) return Object.freeze({ ok: false, added: 0, existing: 0, skipped: Array.isArray(ids) ? ids.length : 0 });
      const next = clone(state); let added = 0; let existing = 0; let skipped = 0;
      for (const raw of ids) {
        if (raw && typeof raw === "object" && String(raw.source || "").toUpperCase() !== source) { skipped++; continue; }
        const key = cardKey(raw);
        if (!key || !hasSong(key)) { skipped++; continue; }
        const old = next.cards[key];
        if (old) { existing++; if (old.state === "suspended") old.state = scheduler.VALID_STATES.has(old.resumeState) && old.resumeState !== "suspended" ? old.resumeState : "new"; continue; }
        next.cards[key] = makeSourceCard(key, now()); added++;
      }
      if (!added && !existing) return Object.freeze({ ok: false, added: 0, existing: 0, skipped });
      if (!persist(next)) return Object.freeze({ ok: false, added: 0, existing: 0, skipped, storage: true });
      return Object.freeze({ ok: true, added, existing, skipped });
    }
    function toggle(id) {
      const key = cardKey(id);
      if (!key) return Object.freeze({ ok: false, reason: "invalid" });
      const old = state.cards[key];
      if (!old) return enroll(id);
      const next = clone(state); const card = next.cards[key];
      if (card.state === "suspended") {
        card.state = scheduler.VALID_STATES.has(card.resumeState) && card.resumeState !== "suspended" ? card.resumeState : "new";
        return persist(next) ? Object.freeze({ ok: true, action: "resumed", card: getCard(key) }) : Object.freeze({ ok: false, reason: "storage" });
      }
      card.resumeState = card.state; card.state = "suspended";
      return persist(next) ? Object.freeze({ ok: true, action: "suspended", card: getCard(key) }) : Object.freeze({ ok: false, reason: "storage" });
    }
    function rate(id, grade, timestamp = now(), assessment = null) {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      const key = cardKey(id); const old = key ? state.cards[key] : null;
      if (!old) return Object.freeze({ ok: false, reason: "not-enrolled" });
      const origin = assessment && assessment.origin === "manual" ? "manual" : "automatic";
      let ratingBase = old;
      if (origin === "manual" && old.assessment && old.assessment.origin === "automatic" && old.assessmentBase) {
        ratingBase = old.assessmentBase;
      }
      let rated;
      try { rated = scheduler.applyRatingToCard(ratingBase, grade, timestamp, state.settings); }
      catch (error) { lastError = error && error.message ? error.message : "algorithm-error"; return Object.freeze({ ok: false, reason: "algorithm" }); }
      const next = clone(state);
      if (assessment && typeof assessment === "object") {
        const reasonCodes = Array.isArray(assessment.reasonCodes)
          ? assessment.reasonCodes.filter(code => typeof code === "string").slice(0, 8) : [];
        rated.assessment = { origin, ruleVersion: String(assessment.ruleVersion || "unknown").slice(0, 80),
          reasonCodes, observedAt: timestamp, observedGrade: Number(assessment.observedGrade) || Number(grade) };
        if (origin === "automatic") {
          const base = clone(old); delete base.assessment; delete base.assessmentBase;
          rated.assessmentBase = base;
        }
      }
      next.cards[key] = rated;
      if (!persist(next)) return Object.freeze({ ok: false, reason: "storage" });
      return Object.freeze({ ok: true, card: getCard(key), nextDue: rated.dueAt });
    }
    function preview(id, grade, timestamp = now()) {
      const key = cardKey(id);
      if (!key) throw new TypeError("invalid song id");
      const card = state.cards[key] || makeSourceCard(key, timestamp);
      return scheduler.preview(card, grade, timestamp, state.settings);
    }
    function counts(timestamp = now()) {
      const cards = Object.values(state.cards);
      const unsuspended = cards.filter(card => card.state !== "suspended");
      const active = unsuspended.filter(card => hasSong(card.songId) && !blacklisted(card.songId));
      return Object.freeze({ total: cards.length, active: active.length, suspended: cards.length - unsuspended.length,
        new: active.filter(card => card.state === "new").length,
        due: active.filter(card => card.state !== "new" && Number(card.dueAt) <= timestamp).length,
        learning: active.filter(card => card.state === "learning").length,
        review: active.filter(card => card.state === "review").length,
        newStudiedToday: localDateCount(timestamp), dailyNew: Math.max(0, Number(state.settings.dailyNew) || 0),
        batchSize: Math.max(1, Number(state.settings.batchSize) || 25) });
    }
    function chooseSession(timestamp = now(), excludedIds = []) {
      const excluded = new Set(Array.from(excludedIds || [], id => String(id)));
      const active = Object.values(state.cards).filter(card => card.state !== "suspended" && hasSong(card.songId)
        && !blacklisted(card.songId) && !excluded.has(String(card.songId)));
      const due = active.filter(card => card.state !== "new" && Number(card.dueAt) <= timestamp).sort((a, b) => Number(a.dueAt) - Number(b.dueAt));
      const cap = scheduler.clamp(Number(state.settings.batchSize) || 25, 1, 500);
      const selected = due.slice(0, cap).map(card => String(card.songId));
      if (selected.length < cap) {
        const allowance = Math.max(0, (Number(state.settings.dailyNew) || 0) - localDateCount(timestamp));
        const fresh = active.filter(card => card.state === "new").sort((a, b) => Number(a.createdAt) - Number(b.createdAt));
        selected.push(...fresh.slice(0, Math.min(allowance, cap - selected.length)).map(card => String(card.songId)));
      }
      return Object.freeze({ ids: Object.freeze([...new Set(selected)]), dueCount: due.length,
        newCount: Math.max(0, (Number(state.settings.dailyNew) || 0) - localDateCount()), activeCount: active.length });
    }
    function setSetting(key, value) {
      if (disposed) return false;
      const next = clone(state);
      if (key === "dailyNew") next.settings.dailyNew = scheduler.clamp(Math.round(Number(value) || 0), 0, 500);
      else if (key === "batchSize") {
        const numeric = Number(value);
        next.settings.batchSize = scheduler.clamp(Math.round(Number.isFinite(numeric) ? numeric : 25), 1, 500);
      }
      else return false;
      return persist(next);
    }
    function reloadExternal() {
      const previous = state;
      persistenceBlocked = false; recoveryRaw = null; lastError = null;
      const refreshed = loadStore();
      // A failed external read is not evidence that the schedule became empty.
      // Preserve the last known snapshot while blocking writes until a later reload succeeds.
      state = persistenceBlocked ? previous : refreshed;
      notify({ source: "external" });
    }
    function onStorage(event) { if (!disposed && event && (event.key === null || event.key === STORAGE_KEY)) reloadExternal(); }
    function flush() {
      if (persistenceBlocked) return Object.freeze({ ok: false, reason: "persistence-blocked" });
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(STORAGE_KEY, JSON.stringify(state)); lastError = null; recoveryRaw = null; return Object.freeze({ ok: true });
      } catch (error) {
        lastError = error && error.message ? error.message : "storage-write-failed";
        notify({ source: "flush-failed" });
        return Object.freeze({ ok: false, reason: lastError });
      }
    }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener); let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function dispose() {
      if (disposed) return false;
      flush(); disposed = true;
      if (eventTarget && typeof eventTarget.removeEventListener === "function") { eventTarget.removeEventListener("storage", onStorage); eventTarget.removeEventListener("pagehide", onPageHide); }
      listeners.clear(); return true;
    }
    function onPageHide() { flush(); }
    if (eventTarget && typeof eventTarget.addEventListener === "function") { eventTarget.addEventListener("storage", onStorage); eventTarget.addEventListener("pagehide", onPageHide); }

    return Object.freeze({ version: scheduler.VERSION, source, storageKey: STORAGE_KEY, isValidSchedule: isValidForSource,
      snapshot: () => freezeDeep(clone(state)), getCard, counts, enroll, enrollMany, toggle, rate, preview, chooseSession, setSetting, flush, subscribe, dispose,
      getPersistenceStatus: () => Object.freeze({ blocked: persistenceBlocked, recoveryAvailable: recoveryRaw !== null, error: lastError,
        persisted: !persistenceBlocked && !lastError }),
      getSettings: () => freezeDeep(clone(state.settings)),
      get isDisposed() { return disposed; } });
  }

  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.srsStore = Object.freeze({ createSrsStore, storageKey: AMQ_STORAGE_KEY,
    storageKeys: Object.freeze({ AMQ: AMQ_STORAGE_KEY, EMQ: EMQ_STORAGE_KEY }),
    recoveryPrefix: AMQ_RECOVERY_PREFIX, recoveryPrefixes: Object.freeze({ AMQ: AMQ_RECOVERY_PREFIX, EMQ: EMQ_RECOVERY_PREFIX }), updateEvent: UPDATE_EVENT });
})(window);
