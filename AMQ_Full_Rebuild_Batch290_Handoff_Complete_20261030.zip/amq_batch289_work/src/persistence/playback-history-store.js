/* Independent, source-aware history for free-play playback. Quiz answer history remains untouched. */
(function (global) {
  "use strict";
  const STORAGE_KEY = "amqLearningPlaybackHistoryV1";
  const UPDATE_EVENT = "amq-learning-playback-history-updated-v1";
  const LIMIT = 1000;
  const SOURCES = new Set(["AMQ", "EMQ"]);
  const isMap = value => Boolean(value && typeof value === "object" && !Array.isArray(value));

  function normalizeEntry(raw, fallbackId, now) {
    if (!isMap(raw)) return null;
    const source = String(raw.source || "").toUpperCase();
    const songId = raw.songId == null ? "" : String(raw.songId).trim();
    if (!SOURCES.has(source) || !songId || songId === "undefined" || songId === "null") return null;
    const playedAt = raw.playedAt == null ? now : (typeof raw.playedAt === "number" ? raw.playedAt : Date.parse(raw.playedAt));
    if (!Number.isFinite(playedAt) || playedAt < 0) return null;
    const numericOrNull = value => value == null || value === "" ? null : Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : NaN;
    const durationSeconds = numericOrNull(raw.durationSeconds);
    const positionSeconds = numericOrNull(raw.positionSeconds);
    if (Number.isNaN(durationSeconds) || Number.isNaN(positionSeconds)) return null;
    const id = String(raw.id || fallbackId || "").trim();
    if (!id) return null;
    return Object.freeze({
      id, source, songId, workId: raw.workId == null || String(raw.workId).trim() === "" ? null : String(raw.workId),
      title: String(raw.title || "").slice(0, 300), artist: String(raw.artist || "").slice(0, 300),
      workTitle: String(raw.workTitle || "").slice(0, 300), playedAt: new Date(playedAt).toISOString(),
      durationSeconds, positionSeconds
    });
  }

  function createPlaybackHistoryStore(dependencies) {
    const deps = isMap(dependencies) ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    const makeId = typeof deps.makeId === "function" ? deps.makeId : () => `play-${now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
    const listeners = new Set();
    let entries = [];
    let disposed = false;
    let readBlocked = false;
    let lastError = null;
    let persistence = Object.freeze({ ok: true, persisted: true, reason: null });

    function notify(reason) {
      const snapshot = Object.freeze({ reason, count: entries.length, persistence });
      for (const listener of [...listeners]) { if (listeners.has(listener)) { try { listener(snapshot); } catch (_) {} } }
    }
    function parse(raw) {
      if (raw == null) return { ok: true, rows: [] };
      let value;
      try { value = JSON.parse(raw); } catch (_) { return { ok: false, reason: "invalid-json" }; }
      if (!isMap(value) || value.schemaVersion !== 1 || !Array.isArray(value.entries) || value.entries.length > LIMIT) return { ok: false, reason: "invalid-schema" };
      if (value.entries.some(row => !isMap(row) || typeof row.id !== "string" || !row.id.trim()
        || typeof row.playedAt !== "string" || !Number.isFinite(Date.parse(row.playedAt)))) return { ok: false, reason: "invalid-entry" };
      const rows = value.entries.map(row => normalizeEntry(row, null, now()));
      if (rows.some(row => !row) || new Set(rows.map(row => row.id)).size !== rows.length) return { ok: false, reason: "invalid-entry" };
      return { ok: true, rows: rows.sort((a, b) => Date.parse(a.playedAt) - Date.parse(b.playedAt)) };
    }
    function load(reason = "load") {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      let raw;
      try { raw = storage && typeof storage.getItem === "function" ? storage.getItem(STORAGE_KEY) : null; }
      catch (error) { readBlocked = true; lastError = error?.message || "storage-read-failed"; persistence = Object.freeze({ ok: false, persisted: false, reason: lastError }); notify("read-failed"); return Object.freeze({ ok: false, reason: lastError }); }
      const parsed = parse(raw);
      if (!parsed.ok) { readBlocked = true; lastError = parsed.reason; persistence = Object.freeze({ ok: false, persisted: false, reason: lastError }); notify("read-invalid"); return Object.freeze({ ok: false, reason: lastError }); }
      entries = parsed.rows;
      readBlocked = false; lastError = null;
      persistence = Object.freeze({ ok: true, persisted: true, reason: null });
      notify(reason);
      return Object.freeze({ ok: true, count: entries.length });
    }
    function persist(next) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      if (readBlocked) return Object.freeze({ ok: false, persisted: false, reason: "read-blocked" });
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(STORAGE_KEY, JSON.stringify({ schemaVersion: 1, entries: next }));
      } catch (error) {
        lastError = error?.message || "storage-write-failed";
        persistence = Object.freeze({ ok: false, persisted: false, reason: lastError });
        notify("write-failed");
        return persistence;
      }
      entries = next;
      lastError = null;
      persistence = Object.freeze({ ok: true, persisted: true, reason: null });
      try {
        if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT, getEntries());
        else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT, { detail: getEntries() }));
      } catch (_) {}
      notify("write");
      return persistence;
    }
    function recordPlayback(input) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed", entry: null });
      const row = normalizeEntry({ ...(input || {}), id: input?.id || makeId(), playedAt: input?.playedAt ?? now() }, null, now());
      if (!row) return Object.freeze({ ok: false, persisted: false, reason: "invalid-entry", entry: null });
      if (entries.some(entry => entry.id === row.id)) return Object.freeze({ ok: true, persisted: true, duplicate: true, entry: entries.find(entry => entry.id === row.id) });
      const next = [...entries, row].sort((a, b) => Date.parse(a.playedAt) - Date.parse(b.playedAt)).slice(-LIMIT);
      const result = persist(next);
      return Object.freeze({ ok: result.ok, persisted: result.persisted, reason: result.reason, entry: row, count: entries.length });
    }
    function clear() {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      const result = persist([]);
      return Object.freeze({ ...result, count: entries.length });
    }
    function getEntries(options) {
      const limit = options && Number.isInteger(options.limit) && options.limit >= 0 ? Math.min(options.limit, LIMIT) : LIMIT;
      return Object.freeze((limit === 0 ? [] : entries.slice(-limit)).reverse().map(entry => Object.freeze({ ...entry })));
    }
    function onStorage(event) { if (!disposed && event && (event.key === null || event.key === STORAGE_KEY)) load("external"); }
    function subscribe(listener) { if (typeof listener !== "function") throw new TypeError("listener must be a function"); listeners.add(listener); let active = true; return () => { if (!active) return; active = false; listeners.delete(listener); }; }
    function dispose() { if (disposed) return false; disposed = true; if (eventTarget?.removeEventListener) eventTarget.removeEventListener("storage", onStorage); listeners.clear(); return true; }
    load("init");
    if (eventTarget?.addEventListener) eventTarget.addEventListener("storage", onStorage);
    return Object.freeze({ storageKey: STORAGE_KEY, updateEvent: UPDATE_EVENT, limit: LIMIT, recordPlayback, getEntries, clear, refresh: () => load("refresh"), subscribe, getPersistenceStatus: () => Object.freeze({ readBlocked, lastError, ...persistence }), dispose, get isDisposed() { return disposed; } });
  }
  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.playbackHistoryStore = Object.freeze({ createPlaybackHistoryStore, normalizeEntry, storageKey: STORAGE_KEY, updateEvent: UPDATE_EVENT, limit: LIMIT });
})(window);
