/* Source-backed persistence for legacy AMQ custom lists and anime watch status. */
(function (global) {
  "use strict";
  const LISTS_KEY = "aniCustomPracticeListsV1";
  const LISTS_RECOVERY_KEY = "aniCustomPracticeListsRecoveryV825";
  const WATCH_KEY = "aniAnimeWatch_v1";
  const WATCH_RECOVERY_PREFIX = "aniAnimeWatchRecoveryV1_";
  const UPDATE_EVENT = "amq-learning-personal-library-updated-v1";
  const WATCH_STATUSES = new Set(["current", "completed", "paused", "dropped", "planning", "repeating"]);

  function validId(value) {
    return (typeof value === "string" && value.trim() !== "") || (typeof value === "number" && Number.isFinite(value));
  }
  function normalizeListName(value) {
    return String(value == null ? "" : value).trim().replace(/\s+/g, " ").slice(0, 80);
  }
  function normalizeWorkRef(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)
      || (value.source !== "AMQ" && value.source !== "EMQ") || !validId(value.id)) return null;
    return { source: value.source, id: String(value.id) };
  }
  function workRefKey(value) {
    const ref = normalizeWorkRef(value);
    return ref ? `@work:${JSON.stringify([ref.source, ref.id])}` : null;
  }
  function normalizeLists(payload, now) {
    const rows = Array.isArray(payload) ? payload
      : payload && typeof payload === "object" && !Array.isArray(payload) && Array.isArray(payload.lists) ? payload.lists : null;
    if (!rows || rows.some(row => !row || typeof row !== "object" || Array.isArray(row)
      || !Array.isArray(row.animeIds) || row.animeIds.some(id => !validId(id))
      || (row.workRefs !== undefined && (!Array.isArray(row.workRefs) || row.workRefs.some(ref => !normalizeWorkRef(ref))))
      || (row.id != null && !validId(row.id)) || (row.name != null && typeof row.name !== "string"))) return null;
    const lists = [];
    for (let index = 0; index < rows.length; index += 1) {
      const row = rows[index];
      const id = String(row.id == null || String(row.id) === "" ? `legacy-${index}` : row.id);
      const name = normalizeListName(row.name) || "未命名清單";
      const createdAt = typeof row.createdAt === "string" && row.createdAt ? row.createdAt : now();
      const updatedAt = typeof row.updatedAt === "string" && row.updatedAt ? row.updatedAt : now();
      const refs = Array.isArray(row.workRefs) ? row.workRefs.map(normalizeWorkRef) : [];
      const seenRefs = new Set();
      const workRefs = refs.filter(ref => { const key = workRefKey(ref); if (seenRefs.has(key)) return false; seenRefs.add(key); return true; });
      lists.push({ ...row, id, name, animeIds: [...new Set(row.animeIds.map(String))], workRefs, createdAt, updatedAt });
    }
    return { version: 1, lists };
  }
  function normalizeWatchMap(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return null;
    const result = {};
    for (const [id, raw] of Object.entries(value)) {
      if (!id.trim()) return null;
      const status = typeof raw === "string" ? raw : raw && typeof raw === "object" && !Array.isArray(raw) ? raw.status : null;
      if (typeof status !== "string" || !WATCH_STATUSES.has(status)) return null;
      const source = raw && typeof raw === "object" && typeof raw.source === "string" ? raw.source : "manual";
      const updatedAt = raw && typeof raw === "object" && typeof raw.updatedAt === "string" ? raw.updatedAt : "";
      result[id] = { status, source, updatedAt };
    }
    return result;
  }

  function createPersonalLibraryStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const nowMs = typeof deps.now === "function" ? deps.now : () => Date.now();
    const nowIso = () => new Date(nowMs()).toISOString();
    const makeId = typeof deps.createId === "function" ? deps.createId : () => `cpl-${nowMs().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
    const listeners = new Set();
    let lists = { version: 1, lists: [] };
    let watchMap = {};
    let listReadError = null, listWriteError = null, watchReadError = null, watchWriteError = null;
    let listBlocked = false, watchBlocked = false, listRecoveryAvailable = false, watchRecoveryAvailable = false;
    let disposed = false;

    const clone = value => JSON.parse(JSON.stringify(value));
    const status = () => Object.freeze({
      lists: Object.freeze({ count: lists.lists.length, readError: listReadError, writeError: listWriteError, blocked: listBlocked, recoveryAvailable: listRecoveryAvailable,
        persisted: !listBlocked && !listReadError && !listWriteError && !listRecoveryAvailable, storageKey: LISTS_KEY }),
      watchlist: Object.freeze({ count: Object.keys(watchMap).length, readError: watchReadError, writeError: watchWriteError, blocked: watchBlocked, recoveryAvailable: watchRecoveryAvailable,
        persisted: !watchBlocked && !watchReadError && !watchWriteError && !watchRecoveryAvailable, storageKey: WATCH_KEY })
    });
    function notify(source, detail) {
      const snapshot = status();
      for (const listener of [...listeners]) if (listeners.has(listener)) { try { listener(snapshot, source, detail || null); } catch (_) {} }
      try {
        if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT, { source, status: snapshot, detail: detail || null });
        else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT, { detail: { source, status: snapshot, detail: detail || null } }));
      } catch (_) {}
    }
    function quarantine(key, recoveryKey, raw) {
      try {
        if (!storage || typeof storage.setItem !== "function" || typeof storage.removeItem !== "function") throw new Error("storage-unavailable");
        let target = recoveryKey;
        if (storage.getItem(target) !== null) target = `${recoveryKey}_${nowMs()}`;
        storage.setItem(target, raw);
        storage.removeItem(key);
        return true;
      } catch (_) { return false; }
    }
    function readLists(source) {
      let raw;
      try { if (!storage || typeof storage.getItem !== "function") throw new Error("storage-unavailable"); raw = storage.getItem(LISTS_KEY); }
      catch (error) { listReadError = error && error.message || "storage-read-failed"; listBlocked = true; notify(source, { scope: "lists" }); return false; }
      if (raw == null || raw === "") { lists = { version: 1, lists: [] }; listReadError = listWriteError = null; listBlocked = false; listRecoveryAvailable = false; return true; }
      let parsed; try { parsed = JSON.parse(raw); } catch (_) { parsed = null; }
      const normalized = normalizeLists(parsed, nowIso);
      if (!normalized) {
        if (!quarantine(LISTS_KEY, LISTS_RECOVERY_KEY, raw)) { listReadError = "invalid-payload-recovery-failed"; listBlocked = true; notify(source, { scope: "lists" }); return false; }
        lists = { version: 1, lists: [] }; listReadError = listWriteError = null; listBlocked = false; listRecoveryAvailable = true;
        notify(source, { scope: "lists", recovered: true }); return true;
      }
      lists = normalized; listReadError = listWriteError = null; listBlocked = false; listRecoveryAvailable = false; return true;
    }
    function readWatchlist(source) {
      let raw;
      try { if (!storage || typeof storage.getItem !== "function") throw new Error("storage-unavailable"); raw = storage.getItem(WATCH_KEY); }
      catch (error) { watchReadError = error && error.message || "storage-read-failed"; watchBlocked = true; notify(source, { scope: "watchlist" }); return false; }
      if (raw == null || raw === "") { watchMap = {}; watchReadError = watchWriteError = null; watchBlocked = false; watchRecoveryAvailable = false; return true; }
      let parsed; try { parsed = JSON.parse(raw); } catch (_) { parsed = null; }
      const normalized = normalizeWatchMap(parsed);
      if (!normalized) {
        if (!quarantine(WATCH_KEY, WATCH_RECOVERY_PREFIX + nowMs(), raw)) { watchReadError = "invalid-payload-recovery-failed"; watchBlocked = true; notify(source, { scope: "watchlist" }); return false; }
        watchMap = {}; watchReadError = watchWriteError = null; watchBlocked = false; watchRecoveryAvailable = true;
        notify(source, { scope: "watchlist", recovered: true }); return true;
      }
      watchMap = normalized; watchReadError = watchWriteError = null; watchBlocked = false; watchRecoveryAvailable = false; return true;
    }
    function refresh(source = "refresh") {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      const listOk = readLists(source), watchOk = readWatchlist(source);
      notify(source, { scope: "all" });
      return Object.freeze({ ok: listOk && watchOk, listsOk: listOk, watchlistOk: watchOk, status: status() });
    }
    function persistLists(next, source, detail) {
      if (disposed) return { ok: false, persisted: false, reason: "disposed" };
      if (listBlocked || listReadError) return { ok: false, persisted: false, reason: "read-blocked" };
      const normalized = normalizeLists(next, nowIso);
      if (!normalized) return { ok: false, persisted: false, reason: "invalid-payload" };
      try { if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable"); storage.setItem(LISTS_KEY, JSON.stringify(normalized)); }
      catch (error) { listWriteError = error && error.message || "storage-write-failed"; notify("write-failed", { scope: "lists", reason: listWriteError }); return { ok: false, persisted: false, reason: listWriteError }; }
      lists = normalized; listReadError = listWriteError = null; listRecoveryAvailable = false; notify(source, { scope: "lists", ...(detail || {}) });
      return { ok: true, persisted: true, data: clone(lists) };
    }
    function commitWatch(next, source, detail) {
      if (disposed) return { ok: false, persisted: false, reason: "disposed" };
      if (watchBlocked || watchReadError) return { ok: false, persisted: false, reason: "read-blocked" };
      try { if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable"); storage.setItem(WATCH_KEY, JSON.stringify(next)); }
      catch (error) { watchWriteError = error && error.message || "storage-write-failed"; notify("write-failed", { scope: "watchlist", reason: watchWriteError }); return { ok: false, persisted: false, reason: watchWriteError }; }
      watchMap = next; watchReadError = watchWriteError = null; watchRecoveryAvailable = false; notify(source, { scope: "watchlist", ...(detail || {}) });
      return { ok: true, persisted: true, status: status() };
    }
    function findList(id, source = lists) {
      const matches = source.lists.filter(row => String(row.id) === String(id));
      return matches.length === 1 ? matches[0] : null;
    }
    function getListsResult() { return Object.freeze({ ok: !listBlocked && !listReadError, status: listBlocked ? "unavailable" : listRecoveryAvailable ? "recovered-invalid" : listReadError ? "invalid" : lists.lists.length ? "ready" : "empty", error: listReadError || listWriteError, data: clone(lists) }); }
    function createList(name) {
      const clean = normalizeListName(name);
      if (!clean) return { ok: false, persisted: false, reason: "empty-name" };
      if (lists.lists.some(row => row.name.toLocaleLowerCase() === clean.toLocaleLowerCase())) return { ok: false, persisted: false, reason: "duplicate-name" };
      const id = String(makeId());
      if (lists.lists.some(row => row.id === id)) return { ok: false, persisted: false, reason: "duplicate-id" };
      const stamp = nowIso(); const row = { id, name: clean, animeIds: [], workRefs: [], createdAt: stamp, updatedAt: stamp };
      const result = persistLists({ version: 1, lists: [...lists.lists, row] }, "list-created", { listId: row.id });
      return result.ok ? { ...result, list: clone(row) } : result;
    }
    function renameList(id, name) {
      const old = findList(id); if (!old) return { ok: false, persisted: false, reason: "missing-list" };
      const clean = normalizeListName(name); if (!clean) return { ok: false, persisted: false, reason: "empty-name" };
      if (lists.lists.some(row => row.id !== old.id && row.name.toLocaleLowerCase() === clean.toLocaleLowerCase())) return { ok: false, persisted: false, reason: "duplicate-name" };
      const next = { version: 1, lists: lists.lists.map(row => row.id === old.id ? { ...row, name: clean, updatedAt: nowIso() } : row) };
      return persistLists(next, "list-renamed", { listId: old.id });
    }
    function deleteList(id) {
      if (!findList(id)) return { ok: false, persisted: false, reason: "missing-list" };
      return persistLists({ version: 1, lists: lists.lists.filter(row => row.id !== String(id)) }, "list-deleted", { listId: String(id) });
    }
    function setMembership(listId, workId, included) {
      const row = findList(listId); if (!row) return { ok: false, persisted: false, reason: "missing-list" };
      if (!validId(workId)) return { ok: false, persisted: false, reason: "invalid-work-id" };
      const id = String(workId), before = row.animeIds.map(String), set = new Set(before);
      if (included) set.add(id); else set.delete(id);
      const nextIds = [...set];
      if (nextIds.length === before.length && nextIds.every((value, index) => value === before[index])) return { ok: true, persisted: true, changed: false, included: set.has(id), data: clone(lists) };
      const next = { version: 1, lists: lists.lists.map(item => item.id === row.id ? { ...item, animeIds: nextIds, updatedAt: nowIso() } : item) };
      const result = persistLists(next, included ? "membership-added" : "membership-removed", { listId: row.id, workId: id });
      return result.ok ? { ...result, changed: true, included: set.has(id) } : result;
    }
    function setWatchStatus(workId, nextStatus, source = "manual") {
      if (!validId(workId)) return { ok: false, persisted: false, reason: "invalid-work-id" };
      const id = String(workId), value = String(nextStatus);
      if (value !== "none" && !WATCH_STATUSES.has(value)) return { ok: false, persisted: false, reason: "invalid-status" };
      const next = { ...watchMap };
      if (value === "none") delete next[id];
      else next[id] = { status: value, source: String(source || "manual"), updatedAt: nowIso() };
      if (JSON.stringify(next[id] || null) === JSON.stringify(watchMap[id] || null)) return { ok: true, persisted: true, changed: false, status: value };
      const result = commitWatch(next, "watch-status-changed", { workId: id, watchStatus: value });
      return result.ok ? { ...result, changed: true, watchStatus: value } : result;
    }
    function getWorkWatchStatus(workRef) {
      const key = workRefKey(workRef);
      return key && watchMap[key] ? watchMap[key].status : "none";
    }
    function setWorkWatchStatus(workRef, nextStatus, origin = "manual") {
      const key = workRefKey(workRef);
      if (!key) return { ok: false, persisted: false, reason: "invalid-work-ref" };
      const value = String(nextStatus);
      if (value !== "none" && !WATCH_STATUSES.has(value)) return { ok: false, persisted: false, reason: "invalid-status" };
      const next = { ...watchMap };
      if (value === "none") delete next[key];
      else next[key] = { status: value, source: String(origin || "manual"), updatedAt: nowIso() };
      if (JSON.stringify(next[key] || null) === JSON.stringify(watchMap[key] || null)) return { ok: true, persisted: true, changed: false, status: value };
      const result = commitWatch(next, "watch-status-changed", { workRef: normalizeWorkRef(workRef), watchStatus: value });
      return result.ok ? { ...result, changed: true, watchStatus: value } : result;
    }
    function setWorkMembership(listId, workRef, included) {
      const row = findList(listId), ref = normalizeWorkRef(workRef);
      if (!row) return { ok: false, persisted: false, reason: "missing-list" };
      if (!ref) return { ok: false, persisted: false, reason: "invalid-work-ref" };
      const key = workRefKey(ref), before = row.workRefs || [], set = new Map(before.map(item => [workRefKey(item), item]));
      if (included) set.set(key, ref); else set.delete(key);
      const nextRefs = [...set.values()];
      if (nextRefs.length === before.length && nextRefs.every((item, index) => workRefKey(item) === workRefKey(before[index])))
        return { ok: true, persisted: true, changed: false, included: set.has(key), data: clone(lists) };
      const next = { version: 1, lists: lists.lists.map(item => item.id === row.id ? { ...item, workRefs: nextRefs, updatedAt: nowIso() } : item) };
      const result = persistLists(next, included ? "work-membership-added" : "work-membership-removed", { listId: row.id, workRef: ref });
      return result.ok ? { ...result, changed: true, included: set.has(key) } : result;
    }
    function hasWorkMembership(listId, workRef) {
      const row = findList(listId), key = workRefKey(workRef);
      return Boolean(row && key && (row.workRefs || []).some(ref => workRefKey(ref) === key));
    }
    function onStorage(event) {
      if (disposed || !event || (event.key !== null && event.key !== LISTS_KEY && event.key !== WATCH_KEY)) return;
      refresh("external");
    }
    if (eventTarget && typeof eventTarget.addEventListener === "function") eventTarget.addEventListener("storage", onStorage);
    return Object.freeze({
      refresh, getLists: () => clone(lists), getListsResult,
      createList, renameList, deleteList, setMembership,
      hasMembership: (listId, workId) => { const row = findList(listId); return Boolean(row && row.animeIds.map(String).includes(String(workId))); },
      setWorkMembership, hasWorkMembership,
      getWorkRefs: listId => { const row = findList(listId); return row ? clone(row.workRefs || []) : []; },
      getWatchStatus: id => watchMap[String(id)]?.status || "none",
      getWatchEntry: id => watchMap[String(id)] ? Object.freeze({ ...watchMap[String(id)] }) : null,
      getWorkWatchStatus, setWorkWatchStatus,
      getWatchSnapshot: () => clone(watchMap), setWatchStatus,
      getStatus: status, subscribe: listener => { if (typeof listener !== "function") throw new TypeError("listener must be a function"); if (disposed) return () => false; listeners.add(listener); return () => listeners.delete(listener); },
      dispose: () => { if (disposed) return false; disposed = true; if (eventTarget && typeof eventTarget.removeEventListener === "function") eventTarget.removeEventListener("storage", onStorage); listeners.clear(); return true; }
    });
  }

  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.personalLibraryStore = Object.freeze({
    createPersonalLibraryStore,
    keys: Object.freeze({ lists: LISTS_KEY, listsRecovery: LISTS_RECOVERY_KEY, watchlist: WATCH_KEY }),
    watchStatuses: Object.freeze([...WATCH_STATUSES])
  });
})(typeof window !== "undefined" ? window : globalThis);
