/* Source-aware familiarity persistence. AMQ retains the observed legacy status map; EMQ is isolated to avoid numeric ID collisions. */
(function (global) {
  "use strict";

  const AMQ_KEY = "aniCollection_v2";
  const AMQ_LEGACY_KEY = "anisongFieldGuide_v1";
  const EMQ_KEY = "amqLearningFamiliarityV1";
  const AMQ_EVENT = "ani-familiarity-updated-v51";
  const EMQ_EVENT = "amq-learning-familiarity-updated-v1";

  function isPlainMap(value) { return Boolean(value && typeof value === "object" && !Array.isArray(value)); }
  function normalizeLevel(raw) {
    if (raw === undefined) return 0;
    if (raw === null || raw === "") return null;
    let value = null;
    if (typeof raw === "number" && Number.isFinite(raw)) value = raw;
    else if (typeof raw === "string" && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(raw.trim())) value = Number(raw);
    return value !== null && Number.isInteger(value) && value >= 0 && value <= 4 ? value : null;
  }

  function createFamiliarityStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const dispatchEvent = typeof deps.dispatchEvent === "function" ? deps.dispatchEvent : name => {
      try {
        if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(name));
      } catch (_) {}
    };
    const listeners = new Set();
    let amqStatus = {};
    let emqStatus = {};
    let disposed = false;
    let amqReadBlocked = false;
    let emqReadBlocked = false;
    let amqReadError = null;
    let emqReadError = null;
    let lastWrite = Object.freeze({ ok: true, persisted: true, reason: null });

    function readMap(primaryKey, fallbackKey) {
      if (!storage || typeof storage.getItem !== "function") return { ok: false, error: "storage-unavailable" };
      try {
        const primary = storage.getItem(primaryKey);
        const raw = primary || (fallbackKey ? storage.getItem(fallbackKey) : null) || "{}";
        const parsed = JSON.parse(raw);
        if (!isPlainMap(parsed)) return { ok: false, error: "invalid-status-map" };
        return { ok: true, map: { ...parsed } };
      } catch (error) {
        return { ok: false, error: error && error.message ? error.message : "storage-read-failed" };
      }
    }
    function reload() {
      const amq = readMap(AMQ_KEY, AMQ_LEGACY_KEY);
      const emq = readMap(EMQ_KEY, null);
      amqReadBlocked = !amq.ok; emqReadBlocked = !emq.ok;
      amqReadError = amq.ok ? null : amq.error; emqReadError = emq.ok ? null : emq.error;
      if (amq.ok) amqStatus = amq.map;
      if (emq.ok) emqStatus = emq.map;
    }
    function snapshot(source) {
      const normalized = String(source || "").toUpperCase();
      return Object.freeze({ ...(normalized === "EMQ" ? emqStatus : amqStatus) });
    }
    function notify(detail) {
      const event = Object.freeze({ ...detail, persistence: lastWrite });
      for (const listener of [...listeners]) {
        if (!listeners.has(listener)) continue;
        try { listener(event); } catch (_) {}
      }
    }
    function recordParts(record) {
      if (!record || typeof record !== "object" || record.id === undefined || record.id === null || String(record.id).trim() === "") return null;
      const source = String(record.source || "").toUpperCase();
      if (source !== "AMQ" && source !== "EMQ") return null;
      return { source, key: String(record.id) };
    }
    function getLevel(record) {
      const parts = recordParts(record);
      if (!parts) return 0;
      const map = parts.source === "EMQ" ? emqStatus : amqStatus;
      return normalizeLevel(map[parts.key]);
    }
    function setLevel(record, level) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed", level: null });
      const parts = recordParts(record);
      if (!parts) return Object.freeze({ ok: false, persisted: false, reason: "invalid-record", level: null });
      if (!Number.isInteger(level) || level < 0 || level > 4) return Object.freeze({ ok: false, persisted: false, reason: "invalid-level", level: null });
      const blocked = parts.source === "EMQ" ? emqReadBlocked : amqReadBlocked;
      if (blocked) {
        const reason = parts.source === "EMQ" ? emqReadError : amqReadError;
        lastWrite = Object.freeze({ ok: false, persisted: false, reason: reason || "storage-read-blocked", source: parts.source, id: parts.key, level });
        notify({ source: parts.source, id: parts.key, level, persisted: false, reason: lastWrite.reason });
        return lastWrite;
      }
      const map = parts.source === "EMQ" ? emqStatus : amqStatus;
      const previous = map[parts.key];
      if (level === 0) delete map[parts.key]; else map[parts.key] = level;
      const storageKey = parts.source === "EMQ" ? EMQ_KEY : AMQ_KEY;
      const eventName = parts.source === "EMQ" ? EMQ_EVENT : AMQ_EVENT;
      let persisted = false;
      let reason = null;
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(storageKey, JSON.stringify(map));
        persisted = true;
      } catch (error) {
        reason = error && error.message ? error.message : "storage-write-failed";
        if (previous === undefined) delete map[parts.key]; else map[parts.key] = previous;
      }
      lastWrite = Object.freeze({ ok: persisted, persisted, reason, source: parts.source, id: parts.key, level });
      if (persisted) dispatchEvent(eventName);
      notify({ source: parts.source, id: parts.key, level, persisted, reason });
      return lastWrite;
    }
    function onStorage(event) {
      if (disposed || !event || ![null, AMQ_KEY, AMQ_LEGACY_KEY, EMQ_KEY].includes(event.key)) return;
      reload();
      const blocked = amqReadBlocked || emqReadBlocked;
      const reason = amqReadError || emqReadError || null;
      lastWrite = Object.freeze({ ok: !blocked, persisted: !blocked, reason, external: true });
      notify({ source: "external", id: null, level: null, persisted: !blocked, reason });
    }
    reload();
    if (eventTarget && typeof eventTarget.addEventListener === "function") eventTarget.addEventListener("storage", onStorage);

    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener);
      let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function dispose() {
      if (disposed) return false;
      disposed = true;
      if (eventTarget && typeof eventTarget.removeEventListener === "function") eventTarget.removeEventListener("storage", onStorage);
      listeners.clear();
      return true;
    }
    return Object.freeze({ getLevel, setLevel, getSnapshot: snapshot, subscribe, dispose,
      getLastWrite: () => lastWrite,
      getPersistenceStatus: () => Object.freeze({ AMQ: Object.freeze({ readBlocked: amqReadBlocked, readError: amqReadError }), EMQ: Object.freeze({ readBlocked: emqReadBlocked, readError: emqReadError }) }),
      getKeys: () => Object.freeze({ amq: AMQ_KEY, amqLegacy: AMQ_LEGACY_KEY, emq: EMQ_KEY, amqEvent: AMQ_EVENT, emqEvent: EMQ_EVENT }),
      get isDisposed() { return disposed; } });
  }

  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.familiarityStore = Object.freeze({ createFamiliarityStore, normalizeLevel,
    keys: Object.freeze({ AMQ_KEY, AMQ_LEGACY_KEY, EMQ_KEY, AMQ_EVENT, EMQ_EVENT }) });
})(window);
