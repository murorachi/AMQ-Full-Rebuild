/* Persistent user preferences for workspace visibility, entry point, statistics order and shortcuts. */
(function (global) {
  "use strict";
  const STORAGE_KEY = "amqWorkspacePreferencesV1";
  const RECOVERY_KEY = "amqWorkspacePreferencesRecoveryV1";
  const UPDATE_EVENT = "amq-workspace-preferences-updated-v1";
  const SHORTCUTS = Object.freeze({
    focusAnswer: "Ctrl+Alt+1", startRound: "Ctrl+Alt+2", playQuiz: "Ctrl+Alt+3", pauseQuiz: "Ctrl+Alt+4",
    revealAnswer: "Ctrl+Alt+5", skipQuestion: "Ctrl+Alt+6", nextQuestion: "Ctrl+Alt+7", focusCatalog: "Ctrl+Alt+8",
    focusFreePlayer: "Ctrl+Alt+9", openPreferences: "Ctrl+Alt+0", randomFreePlay: "Ctrl+Alt+R", focusStatistics: "Ctrl+Alt+S"
  });
  const VISIBILITY_KEYS = Object.freeze(["account", "multiplayer", "backupRestore", "databaseUpdate", "catalog", "freePlayer", "statistics", "skinImport", "quizHistory", "quizSrs"]);
  const DEFAULTS = Object.freeze({
    schemaVersion: 1,
    shortcuts: SHORTCUTS,
    visibility: Object.freeze(Object.fromEntries(VISIBILITY_KEYS.map(key => [key, true]))),
    defaultSection: "none",
    statisticsOrder: Object.freeze(["source", "target", "familiarity", "srs", "playback", "daily"])
  });
  const SECTION_IDS = Object.freeze({ none: "", quiz: "quiz-panel", catalog: "catalog-browser", freePlayer: "free-player-dock", statistics: "statistics-dashboard" });
  const STAT_KEYS = new Set(["source", "target", "familiarity", "srs", "playback", "daily"]);
  const ACTION_KEYS = new Set(Object.keys(SHORTCUTS));
  const KEY_PATTERN = /^(?:(?:Ctrl|Alt|Shift|Meta)\+){1,3}(?:[A-Z0-9]|F(?:[1-9]|1[0-2]))$/;

  function normalizeShortcut(value) {
    if (typeof value !== "string" || !KEY_PATTERN.test(value)) return null;
    const parts = value.split("+");
    const key = parts.pop();
    const modifiers = parts;
    if (!modifiers.some(modifier => modifier === "Ctrl" || modifier === "Alt" || modifier === "Meta")) return null;
    if (new Set(modifiers).size !== modifiers.length) return null;
    return [...["Ctrl", "Alt", "Shift", "Meta"].filter(modifier => modifiers.includes(modifier)), key].join("+");
  }
  function normalize(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || (value.schemaVersion !== undefined && value.schemaVersion !== 1)) return null;
    const shortcuts = { ...SHORTCUTS };
    if (value.shortcuts !== undefined) {
      if (!value.shortcuts || typeof value.shortcuts !== "object" || Array.isArray(value.shortcuts)
        || Object.keys(value.shortcuts).some(key => !ACTION_KEYS.has(key))) return null;
      for (const [action, combo] of Object.entries(value.shortcuts)) {
        const normalized = normalizeShortcut(combo);
        if (!normalized) return null;
        shortcuts[action] = normalized;
      }
    }
    if (new Set(Object.values(shortcuts)).size !== Object.values(shortcuts).length) return null;
    const visibility = { ...DEFAULTS.visibility };
    if (value.visibility !== undefined) {
      if (!value.visibility || typeof value.visibility !== "object" || Array.isArray(value.visibility)
        || Object.keys(value.visibility).some(key => !VISIBILITY_KEYS.includes(key))
        || Object.values(value.visibility).some(flag => typeof flag !== "boolean")) return null;
      Object.assign(visibility, value.visibility);
    }
    const defaultSection = value.defaultSection === undefined ? DEFAULTS.defaultSection : value.defaultSection;
    if (!Object.prototype.hasOwnProperty.call(SECTION_IDS, defaultSection)) return null;
    let statisticsOrder = DEFAULTS.statisticsOrder.slice();
    if (value.statisticsOrder !== undefined) {
      if (!Array.isArray(value.statisticsOrder) || value.statisticsOrder.length !== STAT_KEYS.size
        || value.statisticsOrder.some(key => !STAT_KEYS.has(key)) || new Set(value.statisticsOrder).size !== STAT_KEYS.size) return null;
      statisticsOrder = value.statisticsOrder.slice();
    }
    return { schemaVersion: 1, shortcuts, visibility, defaultSection, statisticsOrder };
  }
  function clone(value) {
    return { schemaVersion: value.schemaVersion, shortcuts: { ...value.shortcuts }, visibility: { ...value.visibility }, defaultSection: value.defaultSection, statisticsOrder: value.statisticsOrder.slice() };
  }
  function createWorkspacePreferencesStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const listeners = new Set();
    let state = clone(DEFAULTS);
    let blocked = false;
    let error = null;
    let recoveryAvailable = false;
    let disposed = false;

    function getPreferences() { return Object.freeze(clone(state)); }
    function getStatus() { return Object.freeze({ blocked, error, recoveryAvailable, persisted: !blocked && !error && !recoveryAvailable, storageKey: STORAGE_KEY }); }
    function notify(source) {
      const status = getStatus(); const preferences = getPreferences();
      for (const listener of [...listeners]) if (listeners.has(listener)) { try { listener(status, preferences, source); } catch (_) {} }
    }
    function load(source = "refresh") {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      let raw;
      try {
        if (!storage || typeof storage.getItem !== "function") throw new Error("storage-unavailable");
        raw = storage.getItem(STORAGE_KEY);
      } catch (cause) { blocked = true; error = cause && cause.message || "storage-read-failed"; notify(source); return Object.freeze({ ok: false, reason: error }); }
      blocked = false; error = null; recoveryAvailable = false;
      if (raw == null || raw === "") { state = clone(DEFAULTS); notify(source); return Object.freeze({ ok: true, defaults: true }); }
      let parsed; try { parsed = JSON.parse(raw); } catch (_) { parsed = null; }
      const normalized = normalize(parsed);
      if (!normalized) {
        try {
          if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
          let key = RECOVERY_KEY; if (storage.getItem(key) !== null) key = `${RECOVERY_KEY}_${Date.now()}`;
          storage.setItem(key, raw); recoveryAvailable = true;
        } catch (cause) { blocked = true; error = cause && cause.message || "recovery-failed"; notify(source); return Object.freeze({ ok: false, reason: error }); }
        state = clone(DEFAULTS); notify(source); return Object.freeze({ ok: true, recovered: true });
      }
      state = normalized; notify(source); return Object.freeze({ ok: true, recovered: false });
    }
    function set(patch) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      if (blocked) return Object.freeze({ ok: false, persisted: false, reason: "persistence-blocked" });
      if (!patch || typeof patch !== "object" || Array.isArray(patch) || Object.keys(patch).some(key => !["shortcuts", "visibility", "defaultSection", "statisticsOrder"].includes(key))) return Object.freeze({ ok: false, persisted: false, reason: "invalid-patch" });
      const candidate = normalize({ ...state, ...patch, schemaVersion: 1 });
      if (!candidate) return Object.freeze({ ok: false, persisted: false, reason: "invalid-preferences" });
      try { if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable"); storage.setItem(STORAGE_KEY, JSON.stringify(candidate)); }
      catch (cause) { error = cause && cause.message || "storage-write-failed"; notify("write-failed"); return Object.freeze({ ok: false, persisted: false, reason: error }); }
      state = candidate; error = null; recoveryAvailable = false;
      try {
        if (typeof deps.dispatchEvent === "function") deps.dispatchEvent(UPDATE_EVENT, getPreferences());
        else if (global.document && typeof global.CustomEvent === "function") global.document.dispatchEvent(new global.CustomEvent(UPDATE_EVENT, { detail: getPreferences() }));
      } catch (_) {}
      notify("local"); return Object.freeze({ ok: true, persisted: true, preferences: getPreferences() });
    }
    function onStorage(event) { if (!disposed && event && (event.key === null || event.key === STORAGE_KEY)) load("external"); }
    function subscribe(listener) { if (typeof listener !== "function") throw new TypeError("listener must be a function"); listeners.add(listener); let active = true; return () => { if (!active) return; active = false; listeners.delete(listener); }; }
    function dispose() { if (disposed) return false; disposed = true; if (eventTarget && typeof eventTarget.removeEventListener === "function") eventTarget.removeEventListener("storage", onStorage); listeners.clear(); return true; }
    load("init");
    if (eventTarget && typeof eventTarget.addEventListener === "function") eventTarget.addEventListener("storage", onStorage);
    return Object.freeze({ storageKey: STORAGE_KEY, recoveryKey: RECOVERY_KEY, updateEvent: UPDATE_EVENT, getPreferences, getStatus, set, refresh: () => load("refresh"), subscribe, dispose, get isDisposed() { return disposed; } });
  }
  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.workspacePreferencesStore = Object.freeze({ createWorkspacePreferencesStore, storageKey: STORAGE_KEY, recoveryKey: RECOVERY_KEY, updateEvent: UPDATE_EVENT, defaults: DEFAULTS, normalize, normalizeShortcut, sectionIds: SECTION_IDS });
})(window);
