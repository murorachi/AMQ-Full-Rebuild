/* Versioned IndexedDB persistence for imported osu! Skin assets and AMQ role mappings. */
(function (global) {
  "use strict";
  const DB_NAME = "amq-learning-skin-themes";
  const DB_VERSION = 1;
  const STORE_NAME = "themes";
  const CURRENT_ID = "current";
  const SCHEMA_VERSION = 4;
  const MAX_ASSET_BYTES = 24 * 1024 * 1024;
  const MAX_TOTAL_BYTES = 120 * 1024 * 1024;
  const ROLES = Object.freeze(["background", "selectionFrame", "characterOverlay"]);
  const DEFAULT_THEME = Object.freeze({ schemaVersion: SCHEMA_VERSION, id: CURRENT_ID, enabled: false,
    metadata: { name: "Default", author: "", version: "" }, mappings: { background: null, selectionFrame: null, characterOverlay: null }, roleMappings: {}, roleStateMappings: {},
    skinIniText: "", skinIniSections: {}, accentColors: [], motionPreference: "system", overrides: { regions: {}, components: {} }, assets: [], updatedAt: 0 });

  function normalizeTheme(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || ![1, 2, 3, SCHEMA_VERSION].includes(value.schemaVersion)) return null;
    if (!Array.isArray(value.assets) || value.assets.length > 5000) return null;
    let total = 0;
    const seen = new Set();
    const assets = [];
    for (const item of value.assets) {
      if (!item || typeof item.path !== "string" || !item.path || item.path.length > 1024 || seen.has(item.path)) return null;
      if (!item.blob || typeof item.blob.size !== "number" || item.blob.size > MAX_ASSET_BYTES) return null;
      total += item.blob.size;
      if (total > MAX_TOTAL_BYTES) return null;
      seen.add(item.path);
      assets.push({ path: item.path, name: String(item.name || item.path.split("/").pop()).slice(0, 255),
        extension: String(item.extension || "").toLowerCase(), mime: String(item.mime || item.blob.type || "application/octet-stream"),
        size: item.blob.size, blob: item.blob });
    }
    const sourceMappings = value.mappings && typeof value.mappings === "object" ? value.mappings : {};
    const mappings = {};
    for (const role of ROLES) {
      const path = sourceMappings[role];
      if (path != null && (typeof path !== "string" || !seen.has(path))) return null;
      mappings[role] = path || null;
    }
    const sourceRoleMappings = value.roleMappings && typeof value.roleMappings === "object" ? value.roleMappings : {};
    if (Object.keys(sourceRoleMappings).length > 500) return null;
    const roleMappings = {};
    for (const [role, path] of Object.entries(sourceRoleMappings)) {
      if (!/^[a-z][a-z0-9.-]{1,120}$/.test(role)) return null;
      if (path != null && (typeof path !== "string" || !seen.has(path))) return null;
      roleMappings[role] = path || null;
    }
    // Migrate the legacy three-role theme without dropping the user's existing choices.
    if (!Object.keys(roleMappings).length) {
      if (mappings.background) roleMappings["app.home.background"] = mappings.background;
      if (mappings.selectionFrame) roleMappings["catalog.item.selected"] = mappings.selectionFrame;
    }
    const roleStateMappings = {};
    const sourceStateMappings = value.roleStateMappings && typeof value.roleStateMappings === "object" ? value.roleStateMappings : {};
    if (Object.keys(sourceStateMappings).length > 100) return null;
    for (const [role, pair] of Object.entries(sourceStateMappings)) {
      if (!/^[a-z][a-z0-9.-]{1,120}$/.test(role) || !pair || typeof pair !== "object" || Array.isArray(pair)) return null;
      const normal = pair.normal == null || pair.normal === "" ? null : pair.normal;
      const hover = pair.hover == null || pair.hover === "" ? null : pair.hover;
      if ((normal !== null && (typeof normal !== "string" || !seen.has(normal))) || (hover !== null && (typeof hover !== "string" || !seen.has(hover)))) return null;
      const fit = ["contain", "cover", "fill", "none", "scale-down"].includes(pair.fit) ? pair.fit : "contain";
      const position = typeof pair.position === "string" && pair.position.length <= 80 && /^[a-zA-Z0-9% .-]+$/.test(pair.position) ? pair.position : "center center";
      roleStateMappings[role] = { normal, hover, fit, position };
    }
    const resolver = global.AMQSkins && global.AMQSkins.skinResolver;
    const overrides = resolver && typeof resolver.normalizeOverrides === "function"
      ? resolver.normalizeOverrides(value.overrides)
      : (value.overrides == null ? { regions: {}, components: {} } : null);
    if (!overrides) return null;
    const metadata = value.metadata && typeof value.metadata === "object" ? value.metadata : {};
    const colors = Array.isArray(value.accentColors) ? value.accentColors.filter(color => typeof color === "string" && /^#[\da-f]{6}$/i.test(color)).slice(0, 8) : [];
    const motionPreference = ["system", "reduce", "full"].includes(value.motionPreference) ? value.motionPreference : "system";
    return { schemaVersion: SCHEMA_VERSION, id: CURRENT_ID, enabled: value.enabled === true,
      metadata: { name: String(metadata.name || "未命名 osu! Skin").slice(0, 200), author: String(metadata.author || "").slice(0, 200), version: String(metadata.version || "").slice(0, 80) },
      mappings, roleMappings, roleStateMappings, overrides, skinIniText: typeof value.skinIniText === "string" ? value.skinIniText.slice(0, 1024 * 1024) : "", skinIniSections: value.skinIniSections && typeof value.skinIniSections === "object" ? value.skinIniSections : {}, accentColors: colors, motionPreference, assets, updatedAt: Number.isFinite(value.updatedAt) ? value.updatedAt : Date.now() };
  }
  function createSkinThemeStore(dependencies) {
    const deps = dependencies || {};
    const indexedDB = Object.prototype.hasOwnProperty.call(deps, "indexedDB") ? deps.indexedDB : global.indexedDB;
    let dbPromise = null;
    let disposed = false;
    function open() {
      if (disposed) return Promise.reject(new Error("skin-theme-store-disposed"));
      if (!indexedDB || typeof indexedDB.open !== "function") return Promise.reject(new Error("indexeddb-unavailable"));
      if (!dbPromise) dbPromise = new Promise((resolve, reject) => {
        let request;
        try { request = indexedDB.open(DB_NAME, DB_VERSION); } catch (error) { reject(error); return; }
        request.onupgradeneeded = () => {
          const db = request.result;
          if (!db.objectStoreNames.contains(STORE_NAME)) db.createObjectStore(STORE_NAME, { keyPath: "id" });
        };
        request.onsuccess = () => { const db = request.result; db.onversionchange = () => db.close(); resolve(db); };
        request.onerror = () => reject(request.error || new Error("indexeddb-open-failed"));
        request.onblocked = () => reject(new Error("indexeddb-open-blocked"));
      }).catch(error => { dbPromise = null; throw error; });
      return dbPromise;
    }
    async function transact(mode, operation) {
      const db = await open();
      return new Promise((resolve, reject) => {
        let transaction;
        let output;
        let settled = false;
        const capture = value => { output = value; };
        try {
          transaction = db.transaction(STORE_NAME, mode);
          const store = transaction.objectStore(STORE_NAME);
          operation(store, capture, reject);
          transaction.oncomplete = () => { if (!settled) { settled = true; resolve(output); } };
          transaction.onerror = () => { if (!settled) { settled = true; reject(transaction.error || new Error("indexeddb-transaction-failed")); } };
          transaction.onabort = () => { if (!settled) { settled = true; reject(transaction.error || new Error("indexeddb-transaction-aborted")); } };
        } catch (error) { reject(error); }
      });
    }
    function load() {
      return transact("readwrite", (store, resolve, reject) => {
        const request = store.get(CURRENT_ID);
        request.onsuccess = () => {
          if (request.result == null) { resolve(null); return; }
          const normalized = normalizeTheme(request.result);
          if (!normalized) { reject(new Error("skin-theme-record-invalid")); return; }
          if (request.result.schemaVersion !== SCHEMA_VERSION) store.put(normalized);
          resolve(normalized);
        };
        request.onerror = () => reject(request.error || new Error("skin-theme-read-failed"));
      });
    }
    function save(value) {
      const normalized = normalizeTheme({ ...value, schemaVersion: value && value.schemaVersion === 1 ? 1 : SCHEMA_VERSION, id: CURRENT_ID, updatedAt: Date.now() });
      if (!normalized) return Promise.reject(new Error("skin-theme-invalid"));
      return transact("readwrite", (store, resolve, reject) => {
        const request = store.put(normalized);
        request.onsuccess = () => resolve(Object.freeze({ ok: true, updatedAt: normalized.updatedAt, assetCount: normalized.assets.length }));
        request.onerror = () => reject(request.error || new Error("skin-theme-write-failed"));
      });
    }
    function clear() {
      return transact("readwrite", (store, resolve, reject) => {
        const request = store.delete(CURRENT_ID);
        request.onsuccess = () => resolve(Object.freeze({ ok: true }));
        request.onerror = () => reject(request.error || new Error("skin-theme-delete-failed"));
      });
    }
    function dispose() { if (disposed) return false; disposed = true; if (dbPromise) dbPromise.then(db => db.close()).catch(() => {}); return true; }
    return Object.freeze({ load, save, clear, dispose, get isDisposed() { return disposed; }, schemaVersion: SCHEMA_VERSION });
  }
  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.skinThemeStore = Object.freeze({ createSkinThemeStore, normalizeTheme, defaults: DEFAULT_THEME,
    databaseName: DB_NAME, databaseVersion: DB_VERSION, storeName: STORE_NAME, schemaVersion: SCHEMA_VERSION });
})(window);
