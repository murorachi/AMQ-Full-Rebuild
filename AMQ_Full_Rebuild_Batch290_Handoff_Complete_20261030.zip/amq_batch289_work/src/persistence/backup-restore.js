/* Versioned, preflighted backup/restore for the supported user-data stores. */
(function (global) {
  "use strict";

  const FORMAT = "amq-learning-tool-backup";
  const FORMAT_VERSION = 1;
  const KEYS = Object.freeze([
    "amqLearningAppSettingsV1",
    "aniSrsScheduleV1", "amqLearningEmqSrsScheduleV1",
    "amqLearningQuizHistoryV1", "amqLearningQuizHistorySummaryV1", "amqLearningPlaybackHistoryV1",
    "aniQuizHistory_v1", "aniQuizHistorySummaryV1", "aniQuizTargetSummaryV1",
    "aniCollection_v2", "anisongFieldGuide_v1", "amqLearningFamiliarityV1",
    "aniBlacklistedSongs_v1", "aniBlacklistedAnime_v1",
    "aniCustomPracticeListsV1", "aniAnimeWatch_v1", "amqSongTagsV1"
  ]);
  const KEY_SET = new Set(KEYS);
  const WATCH_STATUSES = new Set(["current", "completed", "paused", "dropped", "planning", "repeating"]);

  function isMap(value) { return Boolean(value && typeof value === "object" && !Array.isArray(value)); }
  function parseRaw(raw) {
    if (raw === null) return { ok: true, value: null };
    if (typeof raw !== "string") return { ok: false, reason: "raw-value-must-be-string-or-null" };
    let value;
    try { value = JSON.parse(raw); } catch (_) { return { ok: false, reason: "invalid-json" }; }
    return { ok: true, value };
  }
  function validFamiliarity(value) {
    return isMap(value) && Object.values(value).every(level => {
      if (typeof level === "number") return Number.isInteger(level) && level >= 0 && level <= 4;
      return typeof level === "string" && /^[0-4]$/.test(level);
    });
  }
  function validWatchMap(value) {
    return isMap(value) && Object.entries(value).every(([id, raw]) => {
      if (!id.trim()) return false;
      const status = typeof raw === "string" ? raw : isMap(raw) ? raw.status : null;
      return typeof status === "string" && WATCH_STATUSES.has(status);
    });
  }
  function validLists(value) {
    const rows = Array.isArray(value) ? value : isMap(value) && Array.isArray(value.lists) ? value.lists : null;
    return Boolean(rows && rows.every(row => isMap(row) && Array.isArray(row.animeIds)
      && row.animeIds.every(id => (typeof id === "string" && id.trim()) || (typeof id === "number" && Number.isFinite(id)))
      && (row.workRefs === undefined || (Array.isArray(row.workRefs) && row.workRefs.every(ref => isMap(ref)
        && ["AMQ", "EMQ"].includes(ref.source) && ref.id !== undefined && ref.id !== null && String(ref.id).trim() !== "")))));
  }
  function validHistoryRows(value) { return Array.isArray(value) && value.every(row => isMap(row)); }
  function validSchedule(value, source) {
    if (!isMap(value) || value.schemaVersion !== 1 || !isMap(value.cards) || !isMap(value.settings)) return false;
    const settings = value.settings;
    if (!Number.isFinite(Number(settings.dailyNew)) || Number(settings.dailyNew) < 0 || Number(settings.dailyNew) > 500
      || !Number.isFinite(Number(settings.batchSize)) || Number(settings.batchSize) < 1 || Number(settings.batchSize) > 500
      || !Number.isFinite(Number(settings.desiredRetention)) || Number(settings.desiredRetention) < 0.7 || Number(settings.desiredRetention) > 0.97) return false;
    for (const [id, card] of Object.entries(value.cards)) {
      if (!isMap(card) || String(card.songId) !== String(id) || !["new", "learning", "review", "suspended"].includes(card.state)
        || !Number.isFinite(Number(card.dueAt)) || !Number.isFinite(Number(card.reps || 0)) || Number(card.reps || 0) < 0
        || !Number.isFinite(Number(card.lapses || 0)) || Number(card.lapses || 0) < 0
        || (card.stability != null && (!Number.isFinite(Number(card.stability)) || Number(card.stability) < 0))
        || (card.difficulty != null && (!Number.isFinite(Number(card.difficulty)) || Number(card.difficulty) < 0 || Number(card.difficulty) > 10))
        || (card.reviewLog !== undefined && !Array.isArray(card.reviewLog))) return false;
      if (source === "EMQ" ? card.source !== "EMQ" : (card.source && card.source !== "AMQ")) return false;
    }
    return source === "EMQ" ? value.source === "EMQ" : (!value.source || value.source === "AMQ");
  }
  function validLegacySummary(value) { return isMap(value) || Array.isArray(value); }

  function validateKeyValue(key, raw, apis) {
    if (!KEY_SET.has(key)) return { ok: false, reason: "unsupported-key" };
    const parsed = parseRaw(raw);
    if (!parsed.ok) return parsed;
    if (raw === null) return { ok: true };
    const value = parsed.value;
    let valid = false;
    switch (key) {
      case "amqLearningAppSettingsV1":
        valid = Boolean(apis.appSettings && apis.appSettings.normalize(value)); break;
      case "aniSrsScheduleV1":
      case "amqLearningEmqSrsScheduleV1": {
        const source = key === "aniSrsScheduleV1" ? "AMQ" : "EMQ";
        valid = validSchedule(value, source);
        break;
      }
      case "amqLearningQuizHistoryV1":
      case "aniQuizHistory_v1": valid = validHistoryRows(value); break;
      case "amqLearningPlaybackHistoryV1": valid = isMap(value) && value.schemaVersion === 1 && Array.isArray(value.entries) && value.entries.length <= 1000 && value.entries.every(row => isMap(row) && typeof row.id === "string" && row.id.trim() && ["AMQ", "EMQ"].includes(row.source) && row.songId != null && String(row.songId).trim() && typeof row.playedAt === "string" && Number.isFinite(Date.parse(row.playedAt)) && (row.durationSeconds == null || (Number.isFinite(Number(row.durationSeconds)) && Number(row.durationSeconds) >= 0)) && (row.positionSeconds == null || (Number.isFinite(Number(row.positionSeconds)) && Number(row.positionSeconds) >= 0))) && new Set(value.entries.map(row => row.id)).size === value.entries.length; break;
      case "amqLearningQuizHistorySummaryV1":
        valid = Boolean(apis.history && apis.history.validateSummary(value)); break;
      case "aniQuizHistorySummaryV1":
      case "aniQuizTargetSummaryV1": valid = validLegacySummary(value); break;
      case "aniCollection_v2":
      case "anisongFieldGuide_v1":
      case "amqLearningFamiliarityV1": valid = validFamiliarity(value); break;
      case "aniBlacklistedSongs_v1":
      case "aniBlacklistedAnime_v1": valid = Array.isArray(value) && value.every(id => id !== null && id !== undefined && typeof id !== "object"); break;
      case "aniCustomPracticeListsV1": valid = validLists(value); break;
      case "aniAnimeWatch_v1": valid = validWatchMap(value); break;
      case "amqSongTagsV1": valid = Boolean(apis.songTags && apis.songTags.normalizePayload(value)); break;
      default: valid = false;
    }
    return valid ? { ok: true } : { ok: false, reason: "schema-validation-failed", key };
  }

  function stableStringify(value) {
    if (value === null || typeof value !== "object") return JSON.stringify(value);
    if (Array.isArray(value)) return `[${value.map(stableStringify).join(",")}]`;
    return `{${Object.keys(value).sort().map(key => `${JSON.stringify(key)}:${stableStringify(value[key])}`).join(",")}}`;
  }
  async function digest(value, cryptoApi) {
    const crypto = cryptoApi;
    if (!crypto || !crypto.subtle || typeof crypto.subtle.digest !== "function" || typeof TextEncoder !== "function") {
      throw new Error("sha256-unavailable");
    }
    const bytes = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(stableStringify(value)));
    return [...new Uint8Array(bytes)].map(byte => byte.toString(16).padStart(2, "0")).join("");
  }

  function createBackupRestore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const cryptoApi = deps.crypto || global.crypto;
    const apis = {
      appSettings: deps.appSettings || global.AMQPersistence?.appSettingsStore,
      history: deps.history || global.AMQPersistence?.quizHistoryStore,
      songTags: deps.songTags || global.AMQPersistence?.songTagsStore,
    };
    const now = typeof deps.now === "function" ? deps.now : () => new Date().toISOString();

    async function exportBackup() {
      if (!storage || typeof storage.getItem !== "function") return Object.freeze({ ok: false, reason: "storage-unavailable" });
      const values = {};
      try {
        for (const key of KEYS) {
          const raw = storage.getItem(key);
          values[key] = raw === undefined ? null : raw;
          const check = validateKeyValue(key, values[key], apis);
          if (!check.ok) return Object.freeze({ ok: false, reason: "invalid-stored-data", key, detail: check.reason });
        }
      } catch (error) { return Object.freeze({ ok: false, reason: error?.message || "storage-read-failed" }); }
      const payload = { schemaVersion: 1, values };
      try {
        const checksum = await digest(payload, cryptoApi);
        return Object.freeze({ ok: true, backup: Object.freeze({ format: FORMAT, formatVersion: FORMAT_VERSION, createdAt: now(), checksum, payload }) });
      } catch (error) { return Object.freeze({ ok: false, reason: error?.message || "checksum-failed" }); }
    }

    async function preflight(input) {
      let backup = input;
      if (typeof input === "string") {
        try { backup = JSON.parse(input); } catch (_) { return Object.freeze({ ok: false, reason: "invalid-backup-json" }); }
      }
      if (!isMap(backup) || backup.format !== FORMAT || !Number.isInteger(backup.formatVersion)
        || backup.formatVersion < 1 || backup.formatVersion > FORMAT_VERSION || !isMap(backup.payload)
        || !isMap(backup.payload.values) || typeof backup.checksum !== "string") {
        return Object.freeze({ ok: false, reason: "unsupported-backup-format" });
      }
      if (backup.payload.schemaVersion !== 1) return Object.freeze({ ok: false, reason: "unsupported-payload-schema" });
      const entries = Object.entries(backup.payload.values);
      if (entries.some(([key]) => !KEY_SET.has(key))) return Object.freeze({ ok: false, reason: "unsupported-key" });
      if (entries.some(([, raw]) => raw !== null && typeof raw !== "string")) return Object.freeze({ ok: false, reason: "invalid-raw-value" });
      let expected;
      try { expected = await digest(backup.payload, cryptoApi); }
      catch (error) { return Object.freeze({ ok: false, reason: error?.message || "checksum-failed" }); }
      if (expected !== backup.checksum) return Object.freeze({ ok: false, reason: "checksum-mismatch" });
      for (const [key, raw] of entries) {
        const result = validateKeyValue(key, raw, apis);
        if (!result.ok) return Object.freeze({ ok: false, reason: result.reason, key });
      }
      return Object.freeze({ ok: true, formatVersion: backup.formatVersion, keys: Object.freeze(entries.map(([key]) => key)),
        values: Object.freeze({ ...backup.payload.values }), backup });
    }

    async function restoreBackup(input) {
      const checked = await preflight(input);
      if (!checked.ok) return Object.freeze({ ok: false, phase: "preflight", reason: checked.reason, key: checked.key || null });
      if (!storage || typeof storage.getItem !== "function" || typeof storage.setItem !== "function" || typeof storage.removeItem !== "function") {
        return Object.freeze({ ok: false, phase: "prepare", reason: "storage-unavailable" });
      }
      const before = new Map();
      try {
        for (const key of checked.keys) before.set(key, storage.getItem(key));
      } catch (error) { return Object.freeze({ ok: false, phase: "prepare", reason: error?.message || "storage-read-failed" }); }
      const written = [];
      try {
        for (const key of checked.keys) {
          const raw = checked.values[key];
          if (raw === null) storage.removeItem(key); else storage.setItem(key, raw);
          written.push(key);
        }
      } catch (error) {
        const rollbackErrors = [];
        for (const key of [...written, ...checked.keys.filter(key => !written.includes(key)).slice(0, 1)].reverse()) {
          try {
            const old = before.get(key);
            if (old === null || old === undefined) storage.removeItem(key); else storage.setItem(key, old);
          } catch (rollbackError) { rollbackErrors.push({ key, reason: rollbackError?.message || "rollback-failed" }); }
        }
        return Object.freeze({ ok: false, phase: "commit", reason: error?.message || "storage-write-failed",
          rolledBack: rollbackErrors.length === 0, rollbackErrors: Object.freeze(rollbackErrors) });
      }
      return Object.freeze({ ok: true, restoredKeys: Object.freeze([...checked.keys]), formatVersion: checked.formatVersion });
    }

    return Object.freeze({ format: FORMAT, formatVersion: FORMAT_VERSION, keys: KEYS,
      exportBackup, preflight, restoreBackup, validateKeyValue: (key, raw) => validateKeyValue(key, raw, apis) });
  }

  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.backupRestore = Object.freeze({ createBackupRestore, format: FORMAT, formatVersion: FORMAT_VERSION, keys: KEYS });
})(typeof window !== "undefined" ? window : globalThis);
