/* Compatibility store for the observed legacy AMQ song and work blacklist keys/events. */
(function (global) {
  "use strict";
  const STORAGE_KEY = "aniBlacklistedSongs_v1";
  const RECOVERY_PREFIX = "aniBlacklistedSongsRecoveryV1_";
  const WORK_STORAGE_KEY = "aniBlacklistedAnime_v1";
  const WORK_RECOVERY_KEY = "aniBlacklistedAnimeRecoveryV825";
  const CHANGE_EVENT = "ani-blacklist-changed-v51";
  const UPDATE_EVENT = "amq-learning-blacklist-updated-v1";

  function createBlacklistStore(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    let storage = deps.storage;
    if (!storage) { try { storage = global.localStorage; } catch (_) { storage = null; } }
    const eventTarget = deps.eventTarget || global;
    const documentTarget = deps.documentTarget || global.document || null;
    const now = typeof deps.now === "function" ? deps.now : () => Date.now();
    const externalDispatch = typeof deps.dispatchEvent === "function" ? deps.dispatchEvent : null;
    const dispatchDomEvent = (name, detail) => {
      try {
        if (documentTarget && typeof documentTarget.dispatchEvent === "function" && typeof global.CustomEvent === "function") {
          documentTarget.dispatchEvent(new global.CustomEvent(name, { detail }));
        }
      } catch (_) {}
    };
    const listeners = new Set();
    let ids = new Set();
    let workIds = new Set();
    let readError = null;
    let workReadError = null;
    let songWriteError = null;
    let workWriteError = null;
    let persistenceBlocked = false;
    let workPersistenceBlocked = false;
    let recoveryAvailable = false;
    let workRecoveryAvailable = false;
    let disposed = false;
    let writingLocally = false;

    function snapshot() { return Object.freeze([...ids]); }
    function workSnapshot() { return Object.freeze([...workIds]); }
    function getStatus() {
      const error = readError || workReadError || songWriteError || workWriteError;
      return Object.freeze({ count: ids.size, workCount: workIds.size, readError: readError || workReadError || songWriteError || workWriteError,
        songReadError: readError, workReadError, songWriteError, workWriteError, lastError: error,
        blocked: persistenceBlocked || workPersistenceBlocked, songBlocked: persistenceBlocked, workBlocked: workPersistenceBlocked,
        recoveryAvailable: recoveryAvailable || workRecoveryAvailable, songRecoveryAvailable: recoveryAvailable, workRecoveryAvailable,
        persisted: !(persistenceBlocked || workPersistenceBlocked || readError || workReadError || songWriteError || workWriteError) });
    }
    function notify(detail) {
      const state = getStatus();
      for (const listener of [...listeners]) {
        if (listeners.has(listener)) { try { listener(snapshot(), state, detail || null); } catch (_) {} }
      }
      if (!externalDispatch) dispatchDomEvent(UPDATE_EVENT, Object.freeze({ ...state, ...(detail || {}) }));
    }
    function quarantine(raw, scope) {
      const key = scope === "anime" ? WORK_STORAGE_KEY : STORAGE_KEY;
      try {
        if (!storage || typeof storage.setItem !== "function" || typeof storage.removeItem !== "function") throw new Error("storage-unavailable");
        let recoveryKey;
        if (scope === "anime") {
          recoveryKey = WORK_RECOVERY_KEY;
          if (storage.getItem(recoveryKey) !== null) recoveryKey = `${WORK_RECOVERY_KEY}_${now()}`;
        } else recoveryKey = `${RECOVERY_PREFIX}${now()}`;
        storage.setItem(recoveryKey, raw);
        storage.removeItem(key);
        if (scope === "anime") { workRecoveryAvailable = true; workReadError = "invalid-blacklist-quarantined"; workPersistenceBlocked = false; }
        else { recoveryAvailable = true; readError = "invalid-blacklist-quarantined"; persistenceBlocked = false; }
        return true;
      } catch (error) {
        if (scope === "anime") { workPersistenceBlocked = true; workReadError = error && error.message ? error.message : "recovery-failed"; }
        else { persistenceBlocked = true; readError = error && error.message ? error.message : "recovery-failed"; }
        return false;
      }
    }
    function loadKey(scope, source, shouldNotify = true) {
      if (disposed) return Object.freeze({ ok: false, reason: "disposed" });
      const isWork = scope === "anime";
      const key = isWork ? WORK_STORAGE_KEY : STORAGE_KEY;
      let raw;
      try {
        if (!storage || typeof storage.getItem !== "function") throw new Error("storage-unavailable");
        raw = storage.getItem(key);
      } catch (error) {
        if (isWork) { workPersistenceBlocked = true; workReadError = error && error.message ? error.message : "storage-read-failed"; }
        else { persistenceBlocked = true; readError = error && error.message ? error.message : "storage-read-failed"; }
        if (shouldNotify) notify({ source, scope });
        return Object.freeze({ ok: false, reason: isWork ? workReadError : readError });
      }
      if (raw == null || raw === "") {
        if (isWork) { workIds = new Set(); workReadError = null; workPersistenceBlocked = false; workRecoveryAvailable = false; }
        else { ids = new Set(); readError = null; persistenceBlocked = false; recoveryAvailable = false; }
        if (shouldNotify) notify({ source, scope });
        return Object.freeze({ ok: true, count: 0 });
      }
      let parsed;
      try { parsed = JSON.parse(raw); } catch (_) { parsed = null; }
      if (!Array.isArray(parsed) || parsed.some(value => value !== null && value !== undefined && typeof value === "object")) {
        const recovered = quarantine(raw, scope);
        if (isWork) workIds = new Set(); else ids = new Set();
        if (shouldNotify) notify({ source, scope, recovered });
        return Object.freeze({ ok: recovered, reason: isWork ? workReadError : readError, count: 0, recovered });
      }
      const normalized = new Set(parsed.map(value => String(value)).filter(value => value.length > 0 && value !== "undefined" && value !== "null"));
      if (isWork) { workIds = normalized; workReadError = null; workPersistenceBlocked = false; workRecoveryAvailable = false; }
      else { ids = normalized; readError = null; persistenceBlocked = false; recoveryAvailable = false; }
      if (shouldNotify) notify({ source, scope });
      return Object.freeze({ ok: true, count: normalized.size });
    }
    function load(source = "refresh") {
      const song = loadKey("song", source, false);
      const work = loadKey("anime", source, false);
      notify({ source, scope: "all" });
      return Object.freeze({ ok: song.ok && work.ok, song, work, count: ids.size, workCount: workIds.size });
    }
    function isSongBlacklisted(id) { return ids.has(String(id ?? "")); }
    function isWorkBlacklisted(id) { return workIds.has(String(id ?? "")); }
    function isBlacklisted(id) { return isSongBlacklisted(id); }
    function isRecordBlacklisted(record) {
      if (!record || typeof record !== "object") return false;
      const source = String(record.source || "AMQ").toUpperCase();
      if (source !== "AMQ") return false;
      return isSongBlacklisted(record.id ?? record.songId) || isWorkBlacklisted(record.animeId ?? record.workId);
    }
    function emitLegacyEvent(detail) {
      writingLocally = true;
      try {
        if (externalDispatch) externalDispatch(CHANGE_EVENT, detail);
        else dispatchDomEvent(CHANGE_EVENT, detail);
      } catch (_) {}
      writingLocally = false;
    }
    function setBlacklisted(id, blocked) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      const key = String(id ?? "");
      if (!key || key === "undefined" || key === "null") return Object.freeze({ ok: false, persisted: false, reason: "invalid-id" });
      if (persistenceBlocked) return Object.freeze({ ok: false, persisted: false, reason: "write-blocked" });
      const next = new Set(ids);
      if (blocked) next.add(key); else next.delete(key);
      const changed = next.size !== ids.size || [...next].some(value => !ids.has(value));
      if (!changed) return Object.freeze({ ok: true, persisted: true, changed: false, blocked: next.has(key) });
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(STORAGE_KEY, JSON.stringify([...next]));
      } catch (error) {
        songWriteError = error && error.message ? error.message : "storage-write-failed";
        notify({ source: "write-failed", songId: key, blocked: Boolean(blocked), scope: "song", persisted: false, reason: songWriteError });
        return Object.freeze({ ok: false, persisted: false, reason: songWriteError });
      }
      ids = next; readError = null; songWriteError = null; recoveryAvailable = false;
      const detail = Object.freeze({ songId: key, blocked: Boolean(blocked) });
      notify({ ...detail, scope: "song" });
      emitLegacyEvent(detail);
      return Object.freeze({ ok: true, persisted: true, changed: true, blocked: Boolean(blocked) });
    }
    function setWorkBlacklisted(id, blocked) {
      if (disposed) return Object.freeze({ ok: false, persisted: false, reason: "disposed" });
      const key = String(id ?? "");
      if (!key || key === "undefined" || key === "null") return Object.freeze({ ok: false, persisted: false, reason: "invalid-id" });
      if (workPersistenceBlocked) return Object.freeze({ ok: false, persisted: false, reason: "write-blocked" });
      const next = new Set(workIds);
      if (blocked) next.add(key); else next.delete(key);
      const changed = next.size !== workIds.size || [...next].some(value => !workIds.has(value));
      if (!changed) return Object.freeze({ ok: true, persisted: true, changed: false, blocked: next.has(key) });
      try {
        if (!storage || typeof storage.setItem !== "function") throw new Error("storage-unavailable");
        storage.setItem(WORK_STORAGE_KEY, JSON.stringify([...next]));
      } catch (error) {
        workWriteError = error && error.message ? error.message : "storage-write-failed";
        notify({ source: "write-failed", animeId: key, blocked: Boolean(blocked), scope: "anime", persisted: false, reason: workWriteError });
        return Object.freeze({ ok: false, persisted: false, reason: workWriteError });
      }
      workIds = next; workReadError = null; workWriteError = null; workRecoveryAvailable = false;
      const detail = Object.freeze({ animeId: key, blocked: Boolean(blocked), scope: "anime" });
      notify(detail);
      emitLegacyEvent(detail);
      return Object.freeze({ ok: true, persisted: true, changed: true, blocked: Boolean(blocked) });
    }
    function toggle(id) { return setBlacklisted(id, !isSongBlacklisted(id)); }
    function toggleWork(id) { return setWorkBlacklisted(id, !isWorkBlacklisted(id)); }
    function onStorage(event) {
      if (disposed || !event) return;
      if (event.key === null) load("storage-clear");
      else if (event.key === STORAGE_KEY) loadKey("song", "storage");
      else if (event.key === WORK_STORAGE_KEY) loadKey("anime", "storage");
    }
    function onChange(event) {
      if (disposed || writingLocally) return;
      if (event && event.detail && (event.detail.scope === "anime" || event.detail.animeId != null)) loadKey("anime", "legacy-event");
      else loadKey("song", "legacy-event");
    }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener); let active = true;
      return () => { if (!active) return; active = false; listeners.delete(listener); };
    }
    function dispose() {
      if (disposed) return false;
      disposed = true;
      if (eventTarget && typeof eventTarget.removeEventListener === "function") eventTarget.removeEventListener("storage", onStorage);
      if (documentTarget && typeof documentTarget.removeEventListener === "function") documentTarget.removeEventListener(CHANGE_EVENT, onChange);
      listeners.clear(); return true;
    }
    load("init");
    if (eventTarget && typeof eventTarget.addEventListener === "function") eventTarget.addEventListener("storage", onStorage);
    if (documentTarget && typeof documentTarget.addEventListener === "function") documentTarget.addEventListener(CHANGE_EVENT, onChange);
    return Object.freeze({ storageKey: STORAGE_KEY, recoveryPrefix: RECOVERY_PREFIX, workStorageKey: WORK_STORAGE_KEY, workRecoveryKey: WORK_RECOVERY_KEY,
      changeEvent: CHANGE_EVENT, updateEvent: UPDATE_EVENT, isBlacklisted, isSongBlacklisted, isWorkBlacklisted, isRecordBlacklisted,
      setBlacklisted, toggle, setWorkBlacklisted, toggleWork, getIds: snapshot, getSnapshot: snapshot, getWorkIds: workSnapshot,
      count: () => ids.size, workCount: () => workIds.size, getStatus, refresh: () => load("refresh"), subscribe, dispose,
      get isDisposed() { return disposed; } });
  }
  global.AMQPersistence = global.AMQPersistence || {};
  global.AMQPersistence.blacklistStore = Object.freeze({ createBlacklistStore, storageKey: STORAGE_KEY, recoveryPrefix: RECOVERY_PREFIX,
    workStorageKey: WORK_STORAGE_KEY, workRecoveryKey: WORK_RECOVERY_KEY, changeEvent: CHANGE_EVENT, updateEvent: UPDATE_EVENT });
})(window);
