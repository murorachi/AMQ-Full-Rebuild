/* Builds conservative artwork providers from explicit external work IDs only. */
(function (global) {
  "use strict";
  function createArtworkProviders(options) {
    const opts = options && typeof options === "object" ? options : {};
    const ann = opts.annArtworkAdapter || null;
    const anilist = opts.anilistAdapter || null;
    const vndb = opts.vndbAdapter || null;
    let titleProvider = opts.chineseTitleProvider || null;
    const ownsTitleProvider = !titleProvider;
    if (!titleProvider) {
      const titleApi = global.AMQData && global.AMQData.chineseTitleProvider;
      if (titleApi && typeof titleApi.createChineseTitleProvider === "function") titleProvider = titleApi.createChineseTitleProvider();
    }
    let disposed = false;
    const diagnostics = [];
    const maxDiagnostics = Number.isInteger(opts.maxDiagnostics) ? Math.max(1, Math.min(500, opts.maxDiagnostics)) : 100;
    const now = typeof opts.now === "function" ? opts.now : Date.now;
    function recordDiagnostic(provider, outcome, code, record) {
      const ref = record && record.artworkRef && typeof record.artworkRef === "object" ? record.artworkRef : {};
      diagnostics.push(Object.freeze({ at: now(), provider, outcome, code: code || null,
        kind: ref.kind === "anime" || ref.kind === "visual_novel_game" ? ref.kind : "unknown",
        source: ref.source === "AMQ" || ref.source === "EMQ" ? ref.source : null }));
      while (diagnostics.length > maxDiagnostics) diagnostics.shift();
    }
    function publicCode(error) {
      const code = error && typeof error.code === "string" ? error.code : "PROVIDER_REQUEST_FAILED";
      return /^[A-Z0-9_]{1,64}$/.test(code) ? code : "PROVIDER_REQUEST_FAILED";
    }
    function explicitId(record, key, pattern) {
      const ref = record && record.artworkRef && typeof record.artworkRef === "object" ? record.artworkRef : {};
      const value = typeof ref[key] === "string" ? ref[key].trim() : "";
      return pattern.test(value) ? value : "";
    }
    async function lookup({ record, signal }) {
      if (disposed) throw Object.assign(new Error("Artwork providers have been disposed"), { code: "ARTWORK_PROVIDER_DISPOSED" });
      if (signal && signal.aborted) throw Object.assign(new Error("Artwork lookup cancelled"), { name: "AbortError", code: "ARTWORK_REQUEST_CANCELLED" });
      const ref = record && record.artworkRef && typeof record.artworkRef === "object" ? record.artworkRef : {};
      // IDs must be explicit crosswalks; source-local IDs and title search are never treated as external IDs.
      if (ref.kind === "anime") {
        // ANN is the primary source because AMQ already stores ANNID on every work row.
        const rawAnnId = ref.annId != null ? ref.annId : record && record.animeAnnId;
        const annId = Number(rawAnnId);
        if (Number.isSafeInteger(annId) && annId > 0 && ann && typeof ann.getArtwork === "function") {
          try {
            const result = await ann.getArtwork(annId, { signal });
            if (signal && signal.aborted) throw Object.assign(new Error("Artwork lookup cancelled"), { name: "AbortError", code: "ARTWORK_REQUEST_CANCELLED" });
            if (result && result.imageUrl) {
              recordDiagnostic("ANN", "available", null, record);
              return { url: result.imageUrl, provider: "ANN", attribution: result.attribution || "Data and artwork provided by Anime News Network", sourceUrl: result.sourceUrl || `https://www.animenewsnetwork.com/encyclopedia/anime.php?id=${annId}` };
            }
            recordDiagnostic("ANN", "missing", "ANN_ARTWORK_NOT_FOUND", record);
          } catch (error) {
            if ((signal && signal.aborted) || (error && (error.name === "AbortError" || error.code === "ANN_REQUEST_CANCELLED" || error.code === "ARTWORK_REQUEST_CANCELLED"))) throw error;
            recordDiagnostic("ANN", "error", publicCode(error), record);
            // A failed ANN request must not prevent a reliable, explicit AniList crosswalk fallback.
          }
        }
        // AniList is secondary, and only allowed when an explicit ANNID crosswalk exists.
        const id = explicitId(record, "anilistId", /^\d{1,12}$/) || (titleProvider && typeof titleProvider.getAniListId === "function" ? String(titleProvider.getAniListId(record) || "") : "");
        if (!id || !/^\d{1,12}$/.test(id)) {
          recordDiagnostic("AniList", "skipped", "ANILIST_CROSSWALK_MISSING", record);
          return null;
        }
        if (!anilist || typeof anilist.getMediaById !== "function") {
          recordDiagnostic("AniList", "skipped", "ANILIST_ADAPTER_UNAVAILABLE", record);
          return null;
        }
        try {
          const media = await anilist.getMediaById(Number(id), { signal });
          if (signal && signal.aborted) throw Object.assign(new Error("Artwork lookup cancelled"), { name: "AbortError", code: "ARTWORK_REQUEST_CANCELLED" });
          if (media && media.coverUrl) recordDiagnostic("AniList", "available", null, record);
          else recordDiagnostic("AniList", "missing", "ANILIST_MEDIA_WITHOUT_COVER", record);
          return media ? { url: media.coverUrl, provider: "AniList", attribution: "Cover artwork provided by AniList", sourceUrl: media.siteUrl } : null;
        } catch (error) {
          if ((signal && signal.aborted) || (error && (error.name === "AbortError" || error.code === "ARTWORK_REQUEST_CANCELLED"))) throw error;
          recordDiagnostic("AniList", "error", publicCode(error), record);
          throw error;
        }
      }
      if (ref.kind === "visual_novel_game") {
        const id = explicitId(record, "vndbId", /^v\d+$/i).toLowerCase();
        if (!id) { recordDiagnostic("VNDB", "skipped", "VNDB_CROSSWALK_MISSING", record); return null; }
        if (!vndb || typeof vndb.getVisualNovel !== "function") { recordDiagnostic("VNDB", "skipped", "VNDB_ADAPTER_UNAVAILABLE", record); return null; }
        try {
          const novel = await vndb.getVisualNovel(id, { signal });
          if (signal && signal.aborted) throw Object.assign(new Error("Artwork lookup cancelled"), { name: "AbortError", code: "ARTWORK_REQUEST_CANCELLED" });
          if (novel && novel.imageUrl) recordDiagnostic("VNDB", "available", null, record);
          else recordDiagnostic("VNDB", "missing", "VNDB_ARTWORK_NOT_FOUND", record);
          return novel ? { url: novel.imageUrl, provider: "VNDB", attribution: "Cover artwork provided by VNDB", sourceUrl: `https://vndb.org/${id}` } : null;
        } catch (error) {
          if ((signal && signal.aborted) || (error && (error.name === "AbortError" || error.code === "ARTWORK_REQUEST_CANCELLED"))) throw error;
          recordDiagnostic("VNDB", "error", publicCode(error), record);
          throw error;
        }
      }
      return null;
    }
    return Object.freeze({
      providers: Object.freeze({ AMQ: lookup, EMQ: lookup }),
      chineseTitleProvider: titleProvider,
      getDiagnostics() { return Object.freeze(diagnostics.slice()); },
      clearDiagnostics() { diagnostics.length = 0; return true; },
      dispose() { if (disposed) return false; disposed = true; if (ownsTitleProvider && titleProvider && typeof titleProvider.dispose === "function") titleProvider.dispose(); titleProvider = null; return true; },
      get isDisposed() { return disposed; }
    });
  }
  global.AMQIntegrations = global.AMQIntegrations || {};
  global.AMQIntegrations.artworkProviderFactory = Object.freeze({ createArtworkProviders });
})(typeof window !== "undefined" ? window : globalThis);
