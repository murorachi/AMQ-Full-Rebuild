/* VNDB API v2 feature adapter. Only fixed HTTPS endpoints are used. */
(function (global) {
  "use strict";
  const ENDPOINT = "https://api.vndb.org/kana/vn";
  const CHARACTER_ENDPOINT = "https://api.vndb.org/kana/character";
  function invalid(message, code = "VNDB_INPUT_INVALID") { const error = new Error(message); error.code = code; return error; }
  function requireClient(client) { if (!client || client.service !== "vndb" || typeof client.request !== "function") throw invalid("VNDB client is required", "VNDB_CLIENT_REQUIRED"); return client; }
  function text(value, name, max = 120) { if (typeof value !== "string" || !value.trim() || value.trim().length > max) throw invalid(`${name} must be a non-empty string up to ${max} characters`); return value.trim(); }
  function integer(value, name, min, max) { if (!Number.isInteger(value) || value < min || value > max) throw invalid(`${name} must be an integer from ${min} to ${max}`); return value; }
  function normalizeCharacter(row) {
    if (!row || typeof row.id !== "string" || !/^c\d+$/.test(row.id)) return null;
    const aliases = Array.isArray(row.aliases) ? row.aliases.filter(value => typeof value === "string" && value.trim()).map(value => value.trim()).slice(0, 20) : [];
    const visualNovels = Array.isArray(row.vns) ? row.vns.map(item => item && typeof item.title === "string" ? item.title : null).filter(Boolean).slice(0, 20) : [];
    const imageUrl = row.image && typeof row.image.url === "string" && /^https:\/\//i.test(row.image.url) ? row.image.url : null;
    return Object.freeze({ service: "vndb", id: row.id, name: typeof row.name === "string" ? row.name : "", original: typeof row.original === "string" ? row.original : null, aliases: Object.freeze(aliases), imageUrl, visualNovels: Object.freeze(visualNovels), sourceUrl: `https://vndb.org/${row.id}` });
  }
  function normalizeNovel(row) {
    if (!row || typeof row.id !== "string" || !/^v\d+$/.test(row.id)) return null;
    const developers = Array.isArray(row.developers) ? row.developers.map(item => item && typeof item.name === "string" ? item.name : null).filter(Boolean) : [];
    return Object.freeze({ service: "vndb", id: row.id, title: typeof row.title === "string" ? row.title : "", alternateTitle: typeof row.alttitle === "string" ? row.alttitle : null,
      imageUrl: row.image && typeof row.image.url === "string" ? row.image.url : null, developers: Object.freeze(developers), released: row.released || null,
      length: Number.isInteger(row.length) ? row.length : null, rating: Number.isFinite(row.rating) ? row.rating : null });
  }
  function createAdapter(client) {
    const http = requireClient(client);
    async function searchVisualNovels(search, options = {}) {
      const term = text(search, "search");
      const results = integer(options.results === undefined ? 20 : options.results, "results", 1, 100);
      const fields = "id,title,alttitle,image.url,developers.name,released,length,rating";
      const response = await http.request({ url: ENDPOINT, method: "POST", auth: "publicReadAuth", body: { filters: ["search", "=", term], fields, results, sort: "searchrank", reverse: false }, signal: options.signal, timeoutMs: options.timeoutMs });
      if (!response.data || !Array.isArray(response.data.results)) throw invalid("VNDB search response is malformed", "VNDB_RESPONSE_INVALID");
      return Object.freeze({ items: Object.freeze(response.data.results.map(normalizeNovel).filter(Boolean)), more: response.data.more === true });
    }
    async function getVisualNovel(id, options = {}) {
      if (typeof id !== "string" || !/^v\d+$/.test(id)) throw invalid("id must be a VNDB visual novel ID such as v17");
      const response = await http.request({ url: ENDPOINT, method: "POST", auth: "publicReadAuth", body: { filters: ["id", "=", id], fields: "id,title,alttitle,image.url,developers.name,released,length,rating", results: 1 }, signal: options.signal });
      if (!response.data || !Array.isArray(response.data.results)) throw invalid("VNDB response is malformed", "VNDB_RESPONSE_INVALID");
      const novel = normalizeNovel(response.data.results[0]);
      if (!novel) throw invalid("VNDB did not return the requested visual novel", "VNDB_NOT_FOUND");
      return novel;
    }
    async function getCharacters(ids, options = {}) {
      if (!Array.isArray(ids) || ids.length < 1 || ids.length > 8) throw invalid("ids must contain 1 to 8 VNDB character IDs");
      const characterIds = [];
      const seen = new Set();
      for (const value of ids) {
        if (typeof value !== "string" || !/^c\d+$/.test(value.trim())) throw invalid("each ID must be a VNDB character ID such as c123");
        const id = value.trim();
        if (!seen.has(id)) { seen.add(id); characterIds.push(id); }
      }
      const filters = characterIds.length === 1 ? ["id", "=", characterIds[0]] : ["or", ...characterIds.map(id => ["id", "=", id])];
      const response = await http.request({ url: CHARACTER_ENDPOINT, method: "POST", auth: "publicReadAuth", body: { filters, fields: "id,name,original,aliases,image.url,vns.title", results: characterIds.length }, signal: options.signal, timeoutMs: options.timeoutMs });
      if (!response.data || !Array.isArray(response.data.results)) throw invalid("VNDB character response is malformed", "VNDB_RESPONSE_INVALID");
      return Object.freeze(response.data.results.map(normalizeCharacter).filter(Boolean).filter(character => seen.has(character.id)));
    }
    async function getCharacter(id, options = {}) {
      if (typeof id !== "string" || !/^c\d+$/.test(id.trim())) throw invalid("id must be a VNDB character ID such as c123");
      const characterId = id.trim();
      const characters = await getCharacters([characterId], options);
      const character = characters.find(item => item.id === characterId);
      if (!character) throw invalid("VNDB character was not found", "VNDB_CHARACTER_NOT_FOUND");
      return character;
    }
    return Object.freeze({ service: "vndb", searchVisualNovels, getVisualNovel, getCharacter, getCharacters });
  }
  global.AMQIntegrations = global.AMQIntegrations || {};
  global.AMQIntegrations.vndbAdapter = Object.freeze({ createAdapter, normalizeNovel, normalizeCharacter, CHARACTER_ENDPOINT });
})(typeof window !== "undefined" ? window : globalThis);
