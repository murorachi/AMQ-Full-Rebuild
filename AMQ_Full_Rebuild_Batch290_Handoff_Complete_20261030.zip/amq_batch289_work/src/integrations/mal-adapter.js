/* MyAnimeList v2 feature adapter. OAuth credential lifecycle remains externally configured. */
(function (global) {
  "use strict";
  const BASE = "https://api.myanimelist.net/v2";
  const STATUSES = new Set(["watching", "completed", "on_hold", "dropped", "plan_to_watch"]);
  const FIELDS = "id,title,main_picture,media_type,status,num_episodes,start_date,end_date,alternative_titles";
  function invalid(message, code = "MAL_INPUT_INVALID") { const error = new Error(message); error.code = code; return error; }
  function requireClient(client) { if (!client || client.service !== "mal" || typeof client.request !== "function") throw invalid("MAL client is required", "MAL_CLIENT_REQUIRED"); return client; }
  function text(value, name, max = 100) { if (typeof value !== "string" || !value.trim() || value.trim().length > max) throw invalid(`${name} must be a non-empty string up to ${max} characters`); return value.trim(); }
  function integer(value, name, min, max) { if (!Number.isInteger(value) || value < min || value > max) throw invalid(`${name} must be an integer from ${min} to ${max}`); return value; }
  function normalizeAnime(row) {
    if (!row || !Number.isSafeInteger(row.id)) return null;
    const alt = row.alternative_titles || {};
    return Object.freeze({ service: "mal", id: row.id, title: typeof row.title === "string" ? row.title : "", mediaType: row.media_type || null,
      imageUrl: row.main_picture && (row.main_picture.large || row.main_picture.medium) || null, status: row.status || null,
      episodes: Number.isInteger(row.num_episodes) ? row.num_episodes : null, startDate: row.start_date || null, endDate: row.end_date || null,
      alternativeTitles: Object.freeze({ en: alt.en || null, ja: alt.ja || null, synonyms: Object.freeze(Array.isArray(alt.synonyms) ? alt.synonyms.slice(0, 20) : []) }) });
  }
  function createAdapter(client) {
    const http = requireClient(client);
    async function searchAnime(search, options = {}) {
      const term = text(search, "search");
      const limit = integer(options.limit === undefined ? 20 : options.limit, "limit", 1, 100);
      const url = new URL(`${BASE}/anime`); url.searchParams.set("q", term); url.searchParams.set("limit", String(limit)); url.searchParams.set("fields", FIELDS);
      const response = await http.request({ url: url.toString(), auth: "publicReadAuth", signal: options.signal, timeoutMs: options.timeoutMs });
      if (!response.data || !Array.isArray(response.data.data)) throw invalid("MAL search response is malformed", "MAL_RESPONSE_INVALID");
      return Object.freeze({ items: Object.freeze(response.data.data.map(item => item && normalizeAnime(item.node)).filter(Boolean)), paging: Object.freeze({ ...(response.data.paging || {}) }) });
    }
    async function getMyAnimeList(options = {}) {
      const limit = integer(options.limit === undefined ? 100 : options.limit, "limit", 1, 1000);
      const offset = integer(options.offset === undefined ? 0 : options.offset, "offset", 0, 1000000);
      const url = new URL(`${BASE}/users/@me/animelist`); url.searchParams.set("limit", String(Math.min(limit, 100))); url.searchParams.set("offset", String(offset)); url.searchParams.set("fields", `${FIELDS},list_status`);
      if (options.status !== undefined) { if (!STATUSES.has(options.status)) throw invalid("status is not a valid MAL list status"); url.searchParams.set("status", options.status); }
      const response = await http.request({ url: url.toString(), auth: "privateReadAuth", signal: options.signal, timeoutMs: options.timeoutMs });
      if (!response.data || !Array.isArray(response.data.data)) throw invalid("MAL list response is malformed", "MAL_RESPONSE_INVALID");
      return Object.freeze({ items: Object.freeze(response.data.data.map(item => {
        if (!item || typeof item !== "object") return null;
        const anime = normalizeAnime(item.node); const status = item.list_status && typeof item.list_status === "object" ? item.list_status : {};
        return anime && Object.freeze({ ...anime, listStatus: status.status || null, score: Number.isFinite(status.score) ? status.score : null,
          numEpisodesWatched: Number.isInteger(status.num_episodes_watched) ? status.num_episodes_watched : 0, updatedAt: status.updated_at || null });
      }).filter(Boolean)), paging: Object.freeze(response.data.paging && typeof response.data.paging === "object" && !Array.isArray(response.data.paging) ? { ...response.data.paging } : {}) });
    }
    async function updateMyListStatus(animeId, input, options = {}) {
      const id = integer(animeId, "animeId", 1, 2147483647);
      const value = input && typeof input === "object" ? input : {};
      const params = new URLSearchParams();
      if (value.status !== undefined) { if (!STATUSES.has(value.status)) throw invalid("status is not a valid MAL list status"); params.set("status", value.status); }
      if (value.score !== undefined) params.set("score", String(integer(value.score, "score", 0, 10)));
      if (value.numEpisodesWatched !== undefined) params.set("num_watched_episodes", String(integer(value.numEpisodesWatched, "numEpisodesWatched", 0, 100000)));
      if (!params.size) throw invalid("at least one list status field must be supplied");
      const response = await http.request({ url: `${BASE}/anime/${id}/my_list_status`, method: "PUT", auth: "mutationAuth",
        headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: params.toString(), signal: options.signal, timeoutMs: options.timeoutMs });
      const result = response.data;
      if (!result || typeof result !== "object" || Array.isArray(result)) throw invalid("MAL update response is malformed", "MAL_RESPONSE_INVALID");
      return Object.freeze({ status: result.status || null, score: Number.isFinite(result.score) ? result.score : null,
        numEpisodesWatched: Number.isInteger(result.num_episodes_watched) ? result.num_episodes_watched : 0, updatedAt: result.updated_at || null });
    }
    return Object.freeze({ service: "mal", searchAnime, getMyAnimeList, updateMyListStatus });
  }
  global.AMQIntegrations = global.AMQIntegrations || {};
  global.AMQIntegrations.malAdapter = Object.freeze({ createAdapter, normalizeAnime });
})(typeof window !== "undefined" ? window : globalThis);
