/* ANN Encyclopedia artwork lookup by the existing AMQ ANNID field. */
(function (global) {
  "use strict";
  const ENDPOINT = "https://cdn.animenewsnetwork.com/encyclopedia/api.xml";
  const ENTRY = "https://www.animenewsnetwork.com/encyclopedia/anime.php?id=";
  function failure(code, message) { const error = new Error(message); error.code = code; return error; }
  function parsePicture(xmlText, annId, parser) {
    if (typeof xmlText !== "string" || xmlText.length > 2_000_000) return null;
    let picture = "";
    if (parser && typeof parser.parseFromString === "function") {
      const doc = parser.parseFromString(xmlText, "application/xml");
      if (doc.querySelector("parsererror")) return null;
      const anime = doc.querySelector(`anime[id="${annId}"]`);
      if (!anime) return null;
      const nodes = Array.from(anime.querySelectorAll('info[type="Picture"]'));
      for (const node of nodes.reverse()) { const value = node.getAttribute("src") || node.querySelector("img")?.getAttribute("src") || ""; if (value) { picture = value; break; } }
    } else {
      const escaped = String(annId).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
      const anime = xmlText.match(new RegExp(`<anime\\b(?=[^>]*\\bid=["']${escaped}["'])[^>]*>([\\s\\S]*?)<\\/anime\\s*>`, "i"));
      if (!anime) return null;
      const infos = [...anime[1].matchAll(/<info\b(?=[^>]*\btype=["']Picture["'])[^>]*>/gi)];
      for (const node of infos.reverse()) { const match = node[0].match(/\bsrc=["']([^"']+)["']/i); if (match) { picture = match[1].replace(/&amp;/g, "&"); break; } }
    }
    if (!picture) return null;
    try {
      const url = new URL(picture);
      if (url.protocol !== "https:" || !["cdn.animenewsnetwork.com", "www.animenewsnetwork.com", "animenewsnetwork.com"].includes(url.hostname)) return null;
      // ANN's XML often returns a thumbnail path. Keep that official image URL as-is.
      return url.toString();
    } catch (_) { return null; }
  }
  function createAdapter(options) {
    const opts = options && typeof options === "object" ? options : {};
    const fetcher = opts.fetch || global.fetch;
    const Parser = opts.DOMParser || global.DOMParser;
    const now = typeof opts.now === "function" ? opts.now : Date.now;
    const minIntervalMs = Number.isFinite(opts.minIntervalMs) ? Math.max(0, opts.minIntervalMs) : 1000;
    const timeoutMs = Number.isFinite(opts.timeoutMs) ? Math.max(1, opts.timeoutMs) : 12000;
    let disposed = false, nextAllowedAt = 0, queue = Promise.resolve();
    const cache = new Map();
    async function getArtwork(annId, requestOptions = {}) {
      if (disposed) throw failure("ANN_ARTWORK_DISPOSED", "ANN artwork adapter has been disposed");
      const id = Number(annId);
      if (!Number.isSafeInteger(id) || id <= 0) throw failure("ANN_ID_INVALID", "ANNID must be a positive integer");
      if (cache.has(id)) return cache.get(id);
      if (requestOptions.signal && requestOptions.signal.aborted) throw failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled");
      const operation = queue.then(async () => {
        if (disposed) throw failure("ANN_ARTWORK_DISPOSED", "ANN artwork adapter has been disposed");
        if (requestOptions.signal && requestOptions.signal.aborted) throw failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled");
        const delay = Math.max(0, nextAllowedAt - now());
        if (delay) await new Promise((resolve, reject) => {
          const timer = setTimeout(resolve, delay);
          if (requestOptions.signal) requestOptions.signal.addEventListener("abort", () => { clearTimeout(timer); reject(failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled")); }, { once: true });
        });
        if (disposed || (requestOptions.signal && requestOptions.signal.aborted)) throw failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled");
        if (typeof fetcher !== "function") throw failure("ANN_FETCH_UNAVAILABLE", "Fetch is unavailable");
        nextAllowedAt = now() + minIntervalMs;
        const Controller = global.AbortController || (typeof AbortController === "function" ? AbortController : null);
        if (typeof Controller !== "function") throw failure("ANN_ABORT_UNAVAILABLE", "AbortController is unavailable");
        const requestController = new Controller();
        let timedOut = false;
        let timeout = null;
        const externalSignal = requestOptions.signal;
        const onExternalAbort = () => requestController.abort();
        if (externalSignal) {
          if (externalSignal.aborted) requestController.abort();
          else externalSignal.addEventListener("abort", onExternalAbort, { once: true });
        }
        timeout = setTimeout(() => { timedOut = true; requestController.abort(); }, timeoutMs);
        try {
          if (requestController.signal.aborted) throw failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled");
          let response;
          try { response = await fetcher(`${ENDPOINT}?anime=${id}`, { method: "GET", headers: { Accept: "application/xml, text/xml" }, credentials: "omit", redirect: "error", signal: requestController.signal }); }
          catch (error) {
            if (timedOut) throw failure("ANN_TIMEOUT", "ANN artwork request timed out");
            if ((externalSignal && externalSignal.aborted) || (error && error.name === "AbortError")) throw failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled");
            throw failure("ANN_NETWORK_ERROR", "ANN artwork request failed");
          }
          if (!response || !response.ok) {
            const status = response && Number(response.status);
            const err = failure(status === 429 ? "ANN_RATE_LIMITED" : "ANN_HTTP_ERROR", "ANN artwork request was not successful");
            if (Number.isFinite(status)) err.status = status;
            throw err;
          }
          let text;
          try { text = await response.text(); }
          catch (error) {
            if (timedOut) throw failure("ANN_TIMEOUT", "ANN artwork response timed out");
            if ((externalSignal && externalSignal.aborted) || (error && error.name === "AbortError")) throw failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled");
            throw failure("ANN_NETWORK_ERROR", "ANN artwork response could not be read");
          }
          if (timedOut) throw failure("ANN_TIMEOUT", "ANN artwork request timed out");
          if (externalSignal && externalSignal.aborted) throw failure("ANN_REQUEST_CANCELLED", "ANN artwork lookup cancelled");
          const imageUrl = parsePicture(text, id, typeof Parser === "function" ? new Parser() : null);
          const result = Object.freeze({ annId: id, imageUrl, provider: "ANN", attribution: "Data and artwork provided by Anime News Network", sourceUrl: `${ENTRY}${id}` });
          cache.set(id, result);
          return result;
        } finally {
          clearTimeout(timeout);
          if (externalSignal) externalSignal.removeEventListener("abort", onExternalAbort);
        }
      });
      queue = operation.catch(() => {});
      return operation;
    }
    return Object.freeze({ getArtwork, dispose() { if (disposed) return false; disposed = true; cache.clear(); return true; }, get isDisposed() { return disposed; }, get cacheSize() { return cache.size; } });
  }
  global.AMQIntegrations = global.AMQIntegrations || {};
  global.AMQIntegrations.annArtworkAdapter = Object.freeze({ createAdapter, parsePicture, ENDPOINT, ENTRY });
})(typeof window !== "undefined" ? window : globalThis);
