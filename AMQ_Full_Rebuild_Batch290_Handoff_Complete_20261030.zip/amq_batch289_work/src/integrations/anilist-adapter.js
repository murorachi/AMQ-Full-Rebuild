/* AniList-specific feature adapter. OAuth tokens and HTTP safety stay in external-service-adapter. */
(function (global) {
  "use strict";
  const ENDPOINT = "https://graphql.anilist.co";
  const MEDIA_TYPE = new Set(["ANIME", "MANGA"]);
  const LIST_STATUS = new Set(["CURRENT", "PLANNING", "COMPLETED", "DROPPED", "PAUSED", "REPEATING"]);
  function invalid(message, code = "ANILIST_INPUT_INVALID") { const error = new Error(message); error.code = code; return error; }
  function requireClient(client) { if (!client || client.service !== "anilist" || typeof client.request !== "function") throw invalid("AniList client is required", "ANILIST_CLIENT_REQUIRED"); return client; }
  function text(value, name, max = 120) { if (typeof value !== "string" || !value.trim() || value.trim().length > max) throw invalid(`${name} must be a non-empty string up to ${max} characters`); return value.trim(); }
  function integer(value, name, min, max) { if (!Number.isInteger(value) || value < min || value > max) throw invalid(`${name} must be an integer from ${min} to ${max}`); return value; }
  function graphData(response) {
    const body = response && response.data;
    if (!body || typeof body !== "object" || Array.isArray(body)) throw invalid("AniList returned an invalid response", "ANILIST_RESPONSE_INVALID");
    if (Array.isArray(body.errors) && body.errors.length) throw invalid("AniList rejected the GraphQL operation", "ANILIST_GRAPHQL_ERROR");
    if (!body.data || typeof body.data !== "object") throw invalid("AniList response has no data object", "ANILIST_RESPONSE_INVALID");
    return body.data;
  }
  function normalizeMedia(media) {
    if (!media || !Number.isSafeInteger(media.id)) return null;
    return Object.freeze({ service: "anilist", id: media.id, type: media.type || null,
      title: Object.freeze({ romaji: media.title && media.title.romaji || null, english: media.title && media.title.english || null, native: media.title && media.title.native || null }),
      coverUrl: media.coverImage && (media.coverImage.extraLarge || media.coverImage.large) || null,
      siteUrl: typeof media.siteUrl === "string" ? media.siteUrl : null, format: media.format || null, status: media.status || null,
      episodes: Number.isInteger(media.episodes) ? media.episodes : null,
      startDate: media.startDate && [media.startDate.year, media.startDate.month, media.startDate.day].some(Number.isInteger) ? Object.freeze({ year: media.startDate.year || null, month: media.startDate.month || null, day: media.startDate.day || null }) : null });
  }
  function createAdapter(client) {
    const http = requireClient(client);
    async function query(queryText, variables, auth = "publicReadAuth", requestOptions = {}) {
      const response = await http.request({ url: ENDPOINT, method: "POST", auth, body: { query: queryText, variables }, signal: requestOptions.signal, timeoutMs: requestOptions.timeoutMs });
      return graphData(response);
    }
    async function searchMedia(search, options = {}) {
      const term = text(search, "search", 100);
      const type = options.type === undefined ? "ANIME" : options.type;
      if (!MEDIA_TYPE.has(type)) throw invalid("type must be ANIME or MANGA");
      const page = integer(options.page === undefined ? 1 : options.page, "page", 1, 500);
      const perPage = integer(options.perPage === undefined ? 20 : options.perPage, "perPage", 1, 50);
      const data = await query(`query($search:String!,$type:MediaType!,$page:Int!,$perPage:Int!){ Page(page:$page,perPage:$perPage){ pageInfo{currentPage lastPage hasNextPage total} media(search:$search,type:$type,sort:SEARCH_MATCH){ id type title{romaji english native} coverImage{large extraLarge} siteUrl format status episodes startDate{year month day} } } }`, { search: term, type, page, perPage }, "publicReadAuth", options);
      const pageData = data.Page;
      if (!pageData || !Array.isArray(pageData.media)) throw invalid("AniList search response is malformed", "ANILIST_RESPONSE_INVALID");
      return Object.freeze({ pageInfo: Object.freeze({ ...(pageData.pageInfo || {}) }), items: Object.freeze(pageData.media.map(normalizeMedia).filter(Boolean)) });
    }
    async function getMediaById(id, options = {}) {
      const mediaId = integer(id, "mediaId", 1, 2147483647);
      const type = options.type === undefined ? "ANIME" : options.type;
      if (!MEDIA_TYPE.has(type)) throw invalid("type must be ANIME or MANGA");
      const data = await query("query($id:Int!,$type:MediaType!){ Media(id:$id,type:$type){ id type title{romaji english native} coverImage{large extraLarge} siteUrl format status episodes startDate{year month day} } }", { id: mediaId, type }, "publicReadAuth", options);
      const media = normalizeMedia(data.Media);
      if (!media) throw invalid("AniList did not return the requested media", "ANILIST_MEDIA_NOT_FOUND");
      return media;
    }
    async function getViewer(options = {}) {
      const data = await query("query { Viewer { id name siteUrl avatar { large } } }", {}, "privateReadAuth", options);
      const viewer = data.Viewer;
      if (!viewer || !Number.isSafeInteger(viewer.id) || typeof viewer.name !== "string") throw invalid("AniList did not return an authenticated viewer", "ANILIST_VIEWER_MISSING");
      return Object.freeze({ id: viewer.id, name: viewer.name, siteUrl: viewer.siteUrl || null, avatarUrl: viewer.avatar && viewer.avatar.large || null });
    }
    async function getMediaList(userName, options = {}) {
      const name = text(userName, "userName", 100);
      const type = options.type === undefined ? "ANIME" : options.type;
      if (!MEDIA_TYPE.has(type)) throw invalid("type must be ANIME or MANGA");
      const data = await query(`query($userName:String!,$type:MediaType!){ MediaListCollection(userName:$userName,type:$type){ user{ id name } lists{ name isCustomList status entries{ id status score progress repeat updatedAt media{ id type title{romaji english native} coverImage{large extraLarge} siteUrl format status episodes startDate{year month day} } } } } }`, { userName: name, type }, "privateReadAuth", options);
      const collection = data.MediaListCollection;
      if (!collection || !Array.isArray(collection.lists)) throw invalid("AniList list response is malformed", "ANILIST_RESPONSE_INVALID");
      return Object.freeze({ user: collection.user && typeof collection.user === "object" ? Object.freeze({ id: collection.user.id, name: collection.user.name }) : null,
        lists: Object.freeze(collection.lists.filter(list => list && typeof list === "object" && !Array.isArray(list)).map(list => Object.freeze({ name: typeof list.name === "string" ? list.name : "", status: typeof list.status === "string" ? list.status : null, isCustomList: list.isCustomList === true,
          entries: Object.freeze((Array.isArray(list.entries) ? list.entries : []).filter(entry => entry && typeof entry === "object" && !Array.isArray(entry)).map(entry => Object.freeze({ id: Number.isSafeInteger(entry.id) ? entry.id : null, status: typeof entry.status === "string" ? entry.status : null, score: Number.isFinite(entry.score) ? entry.score : null, progress: Number.isInteger(entry.progress) && entry.progress >= 0 ? entry.progress : 0, repeat: Number.isInteger(entry.repeat) && entry.repeat >= 0 ? entry.repeat : 0, updatedAt: Number.isFinite(entry.updatedAt) ? entry.updatedAt : null, media: normalizeMedia(entry.media) })).filter(entry => entry.media)) }))) });
    }
    async function saveListEntry(input, options = {}) {
      const value = input && typeof input === "object" ? input : {};
      const mediaId = integer(value.mediaId, "mediaId", 1, 2147483647);
      if (!LIST_STATUS.has(value.status)) throw invalid("status must be a valid AniList list status");
      const variables = { mediaId, status: value.status };
      if (value.score !== undefined) { if (!Number.isFinite(value.score) || value.score < 0 || value.score > 100) throw invalid("score must be from 0 to 100"); variables.score = value.score; }
      if (value.progress !== undefined) variables.progress = integer(value.progress, "progress", 0, 100000);
      const data = await query("mutation($mediaId:Int!,$status:MediaListStatus!,$score:Float,$progress:Int){ SaveMediaListEntry(mediaId:$mediaId,status:$status,score:$score,progress:$progress){ id status score progress repeat updatedAt media{ id type title{romaji english native} coverImage{large extraLarge} siteUrl format status episodes startDate{year month day} } } }", variables, "mutationAuth", options);
      const entry = data.SaveMediaListEntry;
      if (!entry || !Number.isSafeInteger(entry.id)) throw invalid("AniList mutation response is malformed", "ANILIST_RESPONSE_INVALID");
      return Object.freeze({ id: entry.id, status: entry.status, score: Number.isFinite(entry.score) ? entry.score : null, progress: Number.isInteger(entry.progress) ? entry.progress : 0, media: normalizeMedia(entry.media) });
    }
    return Object.freeze({ service: "anilist", searchMedia, getMediaById, getViewer, getMediaList, saveListEntry });
  }
  global.AMQIntegrations = global.AMQIntegrations || {};
  global.AMQIntegrations.anilistAdapter = Object.freeze({ createAdapter, normalizeMedia });
})(typeof window !== "undefined" ? window : globalThis);
