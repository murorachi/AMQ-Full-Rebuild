/* Provider-injected artwork lookup/cache. It never fetches by itself or touches quiz/audio state. */
(function (global) {
  "use strict";

  function error(code, message) { const value = new Error(message); value.name = "ArtworkAdapterError"; value.code = code; return value; }
  function normalizeRecord(record) {
    if (!record || typeof record !== "object") throw error("ARTWORK_RECORD_INVALID", "Artwork lookup requires a catalog record");
    // Catalog song records carry a separate work-level reference. Prefer it so
    // songs from the same anime/game share one cover cache entry; never infer it
    // from the song id.
    const ref = record.artworkRef && typeof record.artworkRef === "object" ? record.artworkRef : record;
    const source = String(ref.source || "").trim().toUpperCase();
    const id = String(ref.id == null ? "" : ref.id).trim();
    const kind = String(ref.kind || "").trim().toLowerCase();
    if (!source || !id || source.length > 32 || id.length > 128 || (kind && !["anime", "visual_novel_game"].includes(kind))) throw error("ARTWORK_RECORD_ID_INVALID", "Artwork work reference is invalid");
    return { source, id, kind, key: `${source}\u0000${id}` };
  }
  function normalizeResult(value, identity) {
    const result = value && typeof value === "object" ? value : {};
    const rawUrl = typeof result.url === "string" ? result.url.trim() : typeof result.imageUrl === "string" ? result.imageUrl.trim() : typeof result.coverUrl === "string" ? result.coverUrl.trim() : "";
    let url = null;
    if (rawUrl) {
      let parsed;
      try { parsed = new URL(rawUrl); } catch (_) { throw error("ARTWORK_URL_INVALID", "Artwork provider returned an invalid URL"); }
      if (parsed.protocol !== "https:" || parsed.username || parsed.password) throw error("ARTWORK_URL_UNSAFE", "Artwork URL must use HTTPS without embedded credentials");
      url = parsed.toString();
    }
    return Object.freeze({ source: identity.source, id: identity.id, url,
      provider: typeof result.provider === "string" ? result.provider.slice(0, 80) : null,
      attribution: typeof result.attribution === "string" ? result.attribution.slice(0, 300) : null,
      sourceUrl: normalizeSourceUrl(result.sourceUrl || result.siteUrl), status: url ? "available" : "missing" });
  }
  function normalizeSourceUrl(value) {
    if (typeof value !== "string" || !value.trim()) return null;
    try { const url = new URL(value.trim()); return url.protocol === "https:" ? url.toString() : null; } catch (_) { return null; }
  }
  function createAdapter(options) {
    const opts = options && typeof options === "object" ? options : {};
    const providers = opts.providers && typeof opts.providers === "object" ? opts.providers : {};
    const getProviderDiagnostics = typeof opts.getProviderDiagnostics === "function" ? opts.getProviderDiagnostics : null;
    const maxEntries = Number.isInteger(opts.maxEntries) ? Math.max(1, Math.min(2000, opts.maxEntries)) : 500;
    const cache = new Map();
    const pending = new Map();
    let disposed = false;

    function remember(key, value) {
      if (cache.has(key)) cache.delete(key);
      cache.set(key, value);
      while (cache.size > maxEntries) cache.delete(cache.keys().next().value);
      return value;
    }
    async function getArtwork(record, requestOptions) {
      if (disposed) throw error("ARTWORK_ADAPTER_DISPOSED", "Artwork adapter has been disposed");
      const identity = normalizeRecord(record);
      const cached = cache.get(identity.key);
      if (cached) { cache.delete(identity.key); cache.set(identity.key, cached); return cached; }
      if (pending.has(identity.key)) return pending.get(identity.key).promise;
      const provider = providers[identity.source] || providers[identity.source.toLowerCase()] || providers.default;
      if (typeof provider !== "function") return normalizeResult(null, identity);
      const Controller = opts.AbortController || global.AbortController;
      if (typeof Controller !== "function") throw error("ARTWORK_ABORT_UNAVAILABLE", "AbortController is unavailable");
      const controller = new Controller();
      const entry = { controller, promise: null };
      pending.set(identity.key, entry);
      const externalSignal = requestOptions && requestOptions.signal;
      const abort = () => controller.abort();
      if (externalSignal) {
        if (externalSignal.aborted) controller.abort();
        else externalSignal.addEventListener("abort", abort, { once: true });
      }
      entry.promise = Promise.resolve().then(() => provider(Object.freeze({ record, source: identity.source, id: identity.id, kind: identity.kind || null, signal: controller.signal })))
        .then(value => {
          if (disposed || controller.signal.aborted || pending.get(identity.key) !== entry) throw error("ARTWORK_REQUEST_CANCELLED", "Artwork request was cancelled or superseded");
          return remember(identity.key, normalizeResult(value, identity));
        })
        .finally(() => {
          if (externalSignal) externalSignal.removeEventListener("abort", abort);
          if (pending.get(identity.key) === entry) pending.delete(identity.key);
        });
      return entry.promise;
    }
    function getDiagnostics() {
      let providerEvents = [];
      if (getProviderDiagnostics) {
        try { const value = getProviderDiagnostics(); if (Array.isArray(value)) providerEvents = value.slice(-100); }
        catch (_) { providerEvents = [{ provider: "unknown", outcome: "error", code: "ARTWORK_DIAGNOSTICS_UNAVAILABLE" }]; }
      }
      return Object.freeze({ disposed, cacheEntries: cache.size, pendingRequests: pending.size,
        providerEvents: Object.freeze(providerEvents.map(item => Object.freeze({
          at: Number.isFinite(item && item.at) ? item.at : null,
          provider: typeof (item && item.provider) === "string" ? item.provider : "unknown",
          outcome: typeof (item && item.outcome) === "string" ? item.outcome : "unknown",
          code: typeof (item && item.code) === "string" ? item.code : null,
          kind: typeof (item && item.kind) === "string" ? item.kind : "unknown",
          source: item && (item.source === "AMQ" || item.source === "EMQ") ? item.source : null
        }))) });
    }
    function invalidate(record) {
      if (!record) { cache.clear(); return true; }
      const identity = normalizeRecord(record);
      cache.delete(identity.key);
      const active = pending.get(identity.key);
      if (active) { pending.delete(identity.key); active.controller.abort(); }
      return true;
    }
    function dispose() {
      if (disposed) return false;
      disposed = true;
      for (const entry of pending.values()) entry.controller.abort();
      pending.clear(); cache.clear();
      return true;
    }
    return Object.freeze({ getArtwork, invalidate, getDiagnostics, dispose, get size() { return cache.size; }, get pendingCount() { return pending.size; }, get isDisposed() { return disposed; } });
  }
  global.AMQIntegrations = global.AMQIntegrations || {};
  global.AMQIntegrations.artworkAdapter = Object.freeze({ createAdapter, normalizeResult, normalizeRecord });
})(typeof window !== "undefined" ? window : globalThis);
