/* Optional external-service boundary. It performs no I/O until a caller invokes request(). */
(function (global) {
  "use strict";

  const SERVICE_POLICIES = Object.freeze({
    anilist: Object.freeze({
      id: "anilist",
      apiHost: "graphql.anilist.co",
      publicReadAuth: "none",
      privateReadAuth: "oauth2",
      mutationAuth: "oauth2",
      rateLimitHeaders: Object.freeze(["x-ratelimit-limit", "x-ratelimit-remaining", "x-ratelimit-reset", "retry-after"]),
      quotaPolicy: "server-headers",
      quotaVerified: true
    }),
    mal: Object.freeze({
      id: "mal",
      apiHost: "api.myanimelist.net",
      publicReadAuth: "clientId",
      privateReadAuth: "oauth2",
      mutationAuth: "oauth2",
      rateLimitHeaders: Object.freeze(["retry-after"]),
      quotaPolicy: "server-headers-or-provider-documentation",
      quotaVerified: false
    }),
    vndb: Object.freeze({
      id: "vndb",
      apiHost: "api.vndb.org",
      publicReadAuth: "none",
      privateReadAuth: "token",
      mutationAuth: "token",
      rateLimitHeaders: Object.freeze(["retry-after"]),
      quotaPolicy: "server-headers-and-service-policy",
      quotaVerified: true,
      defaultTimeoutMs: 2500,
      maxRequestTimeoutMs: 2800
    })
  });

  function makeError(code, message, details, retryable) {
    const error = new Error(message);
    error.name = "ExternalServiceError";
    error.code = code;
    error.details = Object.freeze({ ...(details || {}) });
    error.retryable = Boolean(retryable);
    return error;
  }
  function normalizeService(value) {
    const key = typeof value === "string" ? value.trim().toLowerCase() : "";
    if (!Object.prototype.hasOwnProperty.call(SERVICE_POLICIES, key)) throw makeError("EXTERNAL_SERVICE_UNKNOWN", "Unknown external service", { service: key }, false);
    return SERVICE_POLICIES[key];
  }
  function abortError() { return makeError("EXTERNAL_REQUEST_CANCELLED", "External request was cancelled", {}, false); }
  function readHeader(headers, name) {
    if (!headers) return "";
    if (typeof headers.get === "function") return headers.get(name) || "";
    const key = Object.keys(headers).find(item => item.toLowerCase() === name.toLowerCase());
    return key ? String(headers[key] || "") : "";
  }
  function parseRetryAfter(headers, now) {
    const value = readHeader(headers, "retry-after");
    if (!value) return null;
    const seconds = Number(value);
    if (Number.isFinite(seconds) && seconds >= 0) return now() + Math.ceil(seconds * 1000);
    const date = Date.parse(value);
    return Number.isFinite(date) ? Math.max(now(), date) : null;
  }
  function parseRateLimit(headers, now) {
    const limitRaw = readHeader(headers, "x-ratelimit-limit");
    const remainingRaw = readHeader(headers, "x-ratelimit-remaining");
    const limit = limitRaw.trim() ? Number(limitRaw) : NaN;
    const remaining = remainingRaw.trim() ? Number(remainingRaw) : NaN;
    const resetRaw = readHeader(headers, "x-ratelimit-reset");
    const resetNumber = resetRaw.trim() ? Number(resetRaw) : NaN;
    const resetAt = resetRaw && Number.isFinite(resetNumber)
      ? (resetNumber < 1e12 ? resetNumber * 1000 : resetNumber)
      : parseRetryAfter(headers, now);
    return Object.freeze({
      limit: Number.isFinite(limit) && limit >= 0 ? limit : null,
      remaining: Number.isFinite(remaining) && remaining >= 0 ? remaining : null,
      resetAt: Number.isFinite(resetAt) ? resetAt : null
    });
  }
  function safeUrl(url, policy) {
    let parsed;
    try { parsed = new URL(url); } catch (_) { throw makeError("EXTERNAL_URL_INVALID", "External service URL is invalid", { service: policy.id }, false); }
    if (parsed.protocol !== "https:" || parsed.hostname !== policy.apiHost) {
      throw makeError("EXTERNAL_URL_NOT_ALLOWED", "External service URL is outside the configured HTTPS host", { service: policy.id, host: parsed.hostname }, false);
    }
    return parsed.toString();
  }

  function createClient(options) {
    const opts = options && typeof options === "object" ? options : {};
    const policy = normalizeService(opts.service);
    const fetcher = opts.fetch || global.fetch;
    const Controller = opts.AbortController || global.AbortController;
    const now = typeof opts.now === "function" ? opts.now : Date.now;
    const timeoutMs = Number.isFinite(opts.timeoutMs) ? Math.max(100, opts.timeoutMs) : (policy.defaultTimeoutMs || 15000);
    const tokenProvider = typeof opts.tokenProvider === "function" ? opts.tokenProvider : null;
    const clientIdProvider = typeof opts.clientIdProvider === "function" ? opts.clientIdProvider : null;
    let disposed = false;
    const active = new Map();

    async function request(input) {
      const requestOptions = input && typeof input === "object" ? input : {};
      if (disposed) throw makeError("EXTERNAL_CLIENT_DISPOSED", "External service client has been disposed", { service: policy.id }, false);
      if (typeof fetcher !== "function") throw makeError("EXTERNAL_FETCH_UNAVAILABLE", "Fetch is unavailable", { service: policy.id }, false);
      if (typeof Controller !== "function") throw makeError("EXTERNAL_ABORT_UNAVAILABLE", "AbortController is unavailable", { service: policy.id }, false);
      const url = safeUrl(requestOptions.url, policy);
      const method = String(requestOptions.method || "GET").toUpperCase();
      if (!/^(GET|POST|PUT|PATCH|DELETE)$/.test(method)) throw makeError("EXTERNAL_METHOD_INVALID", "HTTP method is not supported", { service: policy.id, method }, false);
      const auth = requestOptions.auth || "publicReadAuth";
      if (!Object.prototype.hasOwnProperty.call(policy, auth) || !["publicReadAuth", "privateReadAuth", "mutationAuth"].includes(auth)) {
        throw makeError("EXTERNAL_AUTH_POLICY_INVALID", "Authentication policy is invalid", { service: policy.id }, false);
      }
      const authMode = policy[auth];
      const suppliedHeaders = requestOptions.headers && typeof requestOptions.headers === "object" ? requestOptions.headers : {};
      if (Object.keys(suppliedHeaders).some(key => key.toLowerCase() === "authorization")) {
        throw makeError("EXTERNAL_AUTH_HEADER_FORBIDDEN", "Authorization must be supplied only through the configured credential provider", { service: policy.id }, false);
      }
      if (authMode === "clientId" && Object.keys(suppliedHeaders).some(key => key.toLowerCase() === "x-mal-client-id")) {
        throw makeError("EXTERNAL_CLIENT_ID_HEADER_FORBIDDEN", "MAL client ID must be supplied only through the configured client ID provider", { service: policy.id }, false);
      }
      let token = "";
      let clientId = "";
      if (authMode === "clientId") {
        if (!clientIdProvider) throw makeError("EXTERNAL_CLIENT_ID_REQUIRED", "This public request requires an explicitly configured service client ID", { service: policy.id }, false);
        try { clientId = String(await clientIdProvider({ service: policy.id }) || "").trim(); }
        catch (_) { throw makeError("EXTERNAL_CLIENT_ID_UNAVAILABLE", "Service client ID provider failed", { service: policy.id }, false); }
        if (!clientId || clientId.length > 256 || /[\r\n]/.test(clientId)) throw makeError("EXTERNAL_CLIENT_ID_REQUIRED", "Service client ID provider returned an invalid ID", { service: policy.id }, false);
      } else if (authMode !== "none") {
        if (!tokenProvider) throw makeError("EXTERNAL_AUTH_REQUIRED", "This request requires an explicitly configured credential provider", { service: policy.id, authMode }, false);
        try { token = String(await tokenProvider({ service: policy.id, authMode }) || "").trim(); }
        catch (_) { throw makeError("EXTERNAL_AUTH_UNAVAILABLE", "Credential provider failed", { service: policy.id }, false); }
        if (!token) throw makeError("EXTERNAL_AUTH_REQUIRED", "This request requires an explicitly configured credential provider", { service: policy.id, authMode }, false);
      }
      const headers = { Accept: "application/json", ...suppliedHeaders };
      if (token) headers.Authorization = authMode === "token" ? `Token ${token}` : `Bearer ${token}`;
      if (clientId) headers[policy.id === "mal" ? "X-MAL-CLIENT-ID" : "X-EXTERNAL-CLIENT-ID"] = clientId;
      if (requestOptions.body !== undefined && !Object.keys(headers).some(key => key.toLowerCase() === "content-type")) headers["Content-Type"] = "application/json";
      const externalSignal = requestOptions.signal;
      if (externalSignal && externalSignal.aborted) throw abortError();
      const controller = new Controller();
      const operation = { reason: "" };
      active.set(controller, operation);
      let timer;
      const abort = () => { operation.reason = "external"; controller.abort(); };
      if (externalSignal) externalSignal.addEventListener("abort", abort, { once: true });
      const requestedTimeoutMs = Number.isFinite(requestOptions.timeoutMs) ? Math.max(100, requestOptions.timeoutMs) : timeoutMs;
      const effectiveTimeoutMs = Number.isFinite(policy.maxRequestTimeoutMs) ? Math.min(requestedTimeoutMs, policy.maxRequestTimeoutMs) : requestedTimeoutMs;
      timer = setTimeout(() => { operation.reason = "timeout"; controller.abort(); }, effectiveTimeoutMs);
      try {
        const response = await fetcher(url, { method, headers, body: requestOptions.body === undefined ? undefined : (typeof requestOptions.body === "string" ? requestOptions.body : JSON.stringify(requestOptions.body)), signal: controller.signal, credentials: "omit", redirect: "error" });
        const rateLimit = parseRateLimit(response && response.headers, now);
        if (response && response.status === 429) throw makeError("EXTERNAL_RATE_LIMIT", "External service rate limit reached", { service: policy.id, retryAt: parseRetryAfter(response.headers, now), rateLimit }, true);
        if (response && (response.status === 401 || response.status === 403)) throw makeError("EXTERNAL_AUTH_REJECTED", "External service rejected the request credentials or permission", { service: policy.id, status: response.status }, false);
        if (!response || response.ok !== true) {
          const status = response && Number.isFinite(response.status) ? response.status : 0;
          throw makeError("EXTERNAL_HTTP_ERROR", "External service request failed", { service: policy.id, status, rateLimit }, status === 0 || status >= 500);
        }
        let data;
        try { data = await response.json(); }
        catch (_) { throw makeError("EXTERNAL_RESPONSE_INVALID", "External service returned invalid JSON", { service: policy.id }, false); }
        return Object.freeze({ service: policy.id, data, status: response.status, rateLimit });
      } catch (error) {
        if (error && error.code) throw error;
        if ((externalSignal && externalSignal.aborted) || operation.reason === "external") throw abortError();
        if (operation.reason === "disposed") throw makeError("EXTERNAL_REQUEST_CANCELLED", "External service client was disposed during a request", { service: policy.id, reason: "client-disposed" }, false);
        if (operation.reason === "timeout") throw makeError("EXTERNAL_REQUEST_TIMEOUT", "External service request timed out", { service: policy.id }, true);
        throw makeError("EXTERNAL_NETWORK_ERROR", "External service could not be reached", { service: policy.id }, true);
      } finally {
        clearTimeout(timer);
        active.delete(controller);
        if (externalSignal) externalSignal.removeEventListener("abort", abort);
      }
    }
    function dispose() { if (disposed) return; disposed = true; for (const [controller, operation] of active) { operation.reason = "disposed"; controller.abort(); } active.clear(); }
    return Object.freeze({ service: policy.id, policy, request, dispose, get disposed() { return disposed; } });
  }

  global.AMQIntegrations = global.AMQIntegrations || {};
  global.AMQIntegrations.externalServiceAdapter = Object.freeze({ version: 1, services: SERVICE_POLICIES, createClient, normalizeService, parseRetryAfter, parseRateLimit });
})(typeof window !== "undefined" ? window : globalThis);
