/* Single-owner audio playback with ordered, caller-supplied candidates and explicit cancellation. */
(function (global) {
  "use strict";

  function createAudioService(dependencies) {
    const deps = dependencies && typeof dependencies === "object" ? dependencies : {};
    const mediaFactory = typeof deps.mediaFactory === "function"
      ? deps.mediaFactory
      : url => {
        if (typeof global.Audio !== "function") throw new Error("此環境不支援 HTMLAudioElement");
        const media = new global.Audio();
        media.preload = "auto";
        media.src = url;
        return media;
      };
    const errorContract = deps.errors || (global.AMQCore && global.AMQCore.errors);
    function makeErrorInfo(code, message, retryable, cause, details) {
      if (errorContract && typeof errorContract.createError === "function") {
        return errorContract.createError({ code, category: "audio", message, retryable: retryable === true, cause, details });
      }
      const info = { name: "AMQError", code, category: "audio", message, retryable: retryable === true, details: details === undefined ? null : details };
      if (cause !== undefined && cause !== null) info.cause = { name: cause && cause.name || "Error", message: cause && cause.message || String(cause) };
      return Object.freeze(info);
    }
    const defaultTimeoutMs = deps.timeoutMs === undefined ? 12000 : deps.timeoutMs;
    if (!Number.isFinite(defaultTimeoutMs) || defaultTimeoutMs < 1 || defaultTimeoutMs > 120000) {
      throw new RangeError("timeoutMs must be between 1 and 120000");
    }

    let sequence = 0;
    let active = null;
    let volume = 1;
    let muted = false;
    let disposed = false;
    const listeners = new Set();
    const listenerErrors = [];
    let state = Object.freeze({ status: "idle", sequence, candidateIndex: null, candidateSource: null, error: null, errorInfo: null, failures: Object.freeze([]) });

    function publish(next) {
      state = Object.freeze({ ...next, errorInfo: next.errorInfo || null, failures: Object.freeze((next.failures || []).map(item => Object.freeze({ ...item }))) });
      for (const listener of [...listeners]) {
        if (!listeners.has(listener)) continue;
        try { listener(state); }
        catch (error) {
          listenerErrors.push(Object.freeze({ error, state }));
          if (listenerErrors.length > 20) listenerErrors.shift();
        }
      }
      return state;
    }
    function candidateFormat(url) {
      try {
        const pathname = new URL(String(url || ""), "https://invalid.local").pathname;
        const match = pathname.match(/\.([a-z0-9]{2,5})$/i);
        return match ? match[1].toLowerCase() : "unknown";
      } catch (_) { return "unknown"; }
    }
    function safePause(media) { try { media && media.pause && media.pause(); } catch (_) {} }
    function applyMediaSettings(media) {
      if (!media) return;
      try { media.volume = volume; } catch (_) {}
      try { media.muted = muted; } catch (_) {}
    }
    function safeClearSource(media) {
      if (!media) return;
      try { if (typeof media.removeAttribute === "function") media.removeAttribute("src"); else media.src = ""; } catch (_) {}
      try { if (typeof media.load === "function") media.load(); } catch (_) {}
    }
    function removeAbortHandler(request) {
      if (request.signal && request.abortHandler) request.signal.removeEventListener("abort", request.abortHandler);
      request.abortHandler = null;
    }
    function detachCandidateEvents(request) {
      if (request.timer !== null) clearTimeout(request.timer);
      request.timer = null;
      if (request.media && request.handlers) {
        for (const [event, handler] of request.handlers) {
          try { request.media.removeEventListener(event, handler); } catch (_) {}
        }
      }
      request.handlers = null;
    }
    function releaseMedia(request, clearSource = true) {
      detachCandidateEvents(request);
      safePause(request.media);
      if (clearSource) safeClearSource(request.media);
      request.media = null;
    }
    function result(status, request, extra) {
      return Object.freeze({ status, sequence: request.sequence, candidateIndex: request.index < 0 ? null : request.index + 1,
        candidateSource: request.candidate && request.candidate.source || null,
        failures: Object.freeze(request.failures.map(item => Object.freeze({ ...item }))), ...(extra || {}) });
    }
    function settle(request, value) {
      if (request.settled) return false;
      request.settled = true;
      request.resolve(value);
      return true;
    }
    function normalizeCandidates(candidates) {
      if (!Array.isArray(candidates)) throw new TypeError("audio candidates must be an array");
      return candidates.map((candidate, index) => {
        const item = typeof candidate === "string" ? { url: candidate, source: "" } : candidate;
        if (!item || typeof item !== "object" || typeof item.url !== "string" || !item.url.trim()) {
          throw new TypeError(`audio candidate ${index + 1} requires a non-empty url`);
        }
        if (item.kind !== undefined && item.kind !== "audio") throw new TypeError(`audio candidate ${index + 1} must have kind 'audio'`);
        return Object.freeze({ url: item.url.trim(), source: typeof item.source === "string" ? item.source : "", kind: "audio" });
      });
    }

    function terminate(request, status, reason) {
      if (!request || active !== request) return false;
      request.terminal = true;
      releaseMedia(request, true);
      removeAbortHandler(request);
      active = null;
      if (!request.settled) settle(request, result(status, request, { reason: reason || null }));
      publish({ status, sequence: request.sequence, candidateIndex: request.index < 0 ? null : request.index + 1,
        candidateSource: request.candidate && request.candidate.source || null,
        error: status === "cancelled" ? (reason || "cancelled") : null, failures: request.failures });
      return true;
    }

    function scheduleCandidateTimeout(request, index) {
      if (request.timer !== null) clearTimeout(request.timer);
      request.timer = setTimeout(() => {
        // A timeout task can already be queued when clearTimeout runs. It must
        // still prove it belongs to the current candidate and that playback has
        // not started before it is allowed to trigger fallback.
        if (active !== request || request.terminal || request.index !== index
          || request.playbackStarted || request.blocked || request.userPaused) return;
        failCandidate(request, index, "timeout", new Error(`audio candidate timed out after ${request.timeoutMs} ms`));
      }, request.timeoutMs);
    }

    function failCandidate(request, index, reason, error) {
      if (active !== request || request.terminal || request.index !== index) return;
      request.failures.push({ candidateIndex: index + 1, source: request.candidate && request.candidate.source || "",
        format: candidateFormat(request.candidate && request.candidate.url), reason,
        message: error && error.message ? error.message : String(error || reason) });
      releaseMedia(request, true);
      request.playbackStarted = false;
      request.blocked = false;
      request.userPaused = false;
      request.candidate = null;
      attemptCandidate(request, index + 1);
    }

    function attemptCandidate(request, index) {
      if (active !== request || request.terminal) return;
      if (request.signal && request.signal.aborted) { terminate(request, "cancelled", "aborted"); return; }
      if (index >= request.candidates.length) {
        request.index = -1;
        request.candidate = null;
        request.terminal = true;
        const failureInfo = makeErrorInfo("AUDIO_ALL_CANDIDATES_FAILED", "所有音訊候選皆無法播放", true, null,
          { failures: request.failures.map(item => ({ ...item })) });
        const failureResult = Object.freeze({ status: "failed", sequence: request.sequence, candidateIndex: null,
          candidateSource: null, error: "AUDIO_ALL_CANDIDATES_FAILED", errorInfo: failureInfo,
          failures: Object.freeze(request.failures.map(item => Object.freeze({ ...item }))) });
        removeAbortHandler(request);
        active = null;
        publish({ status: "failed", sequence: request.sequence, candidateIndex: null, candidateSource: null,
          error: failureResult.error, errorInfo: failureInfo, failures: request.failures });
        settle(request, failureResult);
        return;
      }

      request.index = index;
      request.candidate = request.candidates[index];
      publish({ status: "loading", sequence: request.sequence, candidateIndex: index + 1,
        candidateSource: request.candidate.source || null, error: null, failures: request.failures });
      // Subscribers run synchronously and may cancel, stop, dispose, or replace this
      // request from inside the loading notification. Do not acquire media afterward.
      if (active !== request || request.terminal) return;
      let media;
      try {
        media = mediaFactory(request.candidate.url, request.candidate, index);
        if (!media || typeof media.addEventListener !== "function" || typeof media.removeEventListener !== "function"
          || typeof media.play !== "function" || typeof media.pause !== "function") {
          throw new TypeError("mediaFactory must return an audio-like media object");
        }
        if ("src" in media && !media.src) media.src = request.candidate.url;
        request.media = media;
        applyMediaSettings(media);
        request.positionReady = request.randomSample !== true && request.clipStartSeconds <= 0;
      } catch (error) {
        request.failures.push({ candidateIndex: index + 1, source: request.candidate.source || "",
          format: candidateFormat(request.candidate.url), reason: "media-create-failed", message: error.message || String(error) });
        request.candidate = null;
        attemptCandidate(request, index + 1);
        return;
      }

      const applyStartPosition = () => {
        if (active !== request || request.terminal || request.index !== index || request.positionReady) return request.positionReady === true;
        const duration = Number(media.duration);
        if (!Number.isFinite(duration) || duration <= 0) return false;
        const maxStart = Math.max(0, duration - Math.max(0, request.clipSeconds));
        let position = request.clipStartSeconds;
        if (request.randomSample) {
          let roll = 0;
          try { roll = Number(request.random()); } catch (_) { roll = 0; }
          if (!Number.isFinite(roll) || roll < 0 || roll >= 1) roll = 0;
          position = roll * maxStart;
        }
        position = Math.min(Math.max(0, position), maxStart);
        try { media.currentTime = position; }
        catch (error) {
          failCandidate(request, index, "seek-failed", error);
          return false;
        }
        request.positionReady = true;
        request.startPositionSeconds = position;
        return true;
      };
      const onLoadedMetadata = () => {
        if (active !== request || request.terminal || request.index !== index) return;
        if (!applyStartPosition()) return;
        if (request.autoPlay && !request.blocked && !request.userPaused && !request.playbackStarted) startMediaPlayback(request, index);
        if (request.canPlaySeen) onCanPlay();
      };
      const onCanPlay = () => {
        if (active !== request || request.terminal || request.index !== index) return;
        request.canPlaySeen = true;
        if (!applyStartPosition()) return;
        // In autoplay mode, canplay is only readiness: keep the candidate deadline
        // armed until a real `playing` event arrives. Otherwise a stalled media
        // element can remain ready forever and never advance to its backup URL.
        if (!request.autoPlay || request.blocked || request.userPaused || request.playbackStarted) {
          if (request.timer !== null) clearTimeout(request.timer);
          request.timer = null;
        }
        if (request.blocked || request.userPaused || request.playbackStarted) return;
        publish({ status: "ready", sequence: request.sequence, candidateIndex: index + 1,
          candidateSource: request.candidate.source || null, error: null, failures: request.failures });
        settle(request, result("ready", request, { url: request.candidate.url, media, error: null }));
      };
      const onPlaying = () => {
        if (active !== request || request.terminal || request.index !== index || request.userPaused) return;
        request.playbackStarted = true;
        request.userPaused = false;
        if (request.timer !== null) clearTimeout(request.timer);
        request.timer = null;
        publish({ status: "playing", sequence: request.sequence, candidateIndex: index + 1,
          candidateSource: request.candidate.source || null, error: null, failures: request.failures });
        settle(request, result("playing", request, { url: request.candidate.url, media, error: null }));
      };
      const onEnded = () => {
        if (active !== request || request.terminal || request.index !== index) return;
        publish({ status: "ended", sequence: request.sequence, candidateIndex: index + 1,
          candidateSource: request.candidate && request.candidate.source || null, error: null, failures: request.failures });
        if (active === request && !request.terminal) terminate(request, "ended", "playback-ended");
      };
      const onError = event => {
        const mediaError = event && event.error || media && media.error || null;
        const mediaErrorCode = Number(mediaError && mediaError.code);
        const mediaErrorReasons = { 1: "media-aborted", 2: "network-error", 3: "decode-error", 4: "source-not-supported" };
        const reason = mediaErrorReasons[mediaErrorCode] || "media-error";
        const defaultMessages = { 1: "media playback aborted", 2: "media network error (may include network or cross-origin restrictions)", 3: "media decode error", 4: "media source is not supported" };
        const error = mediaError || new Error(defaultMessages[mediaErrorCode] || "media error");
        failCandidate(request, index, reason, error);
      };
      request.handlers = [["loadedmetadata", onLoadedMetadata], ["canplay", onCanPlay], ["playing", onPlaying], ["ended", onEnded], ["error", onError]];
      try {
        request.handlers.forEach(([event, handler]) => media.addEventListener(event, handler));
      } catch (error) {
        // A media shim or browser implementation can fail while wiring listeners.
        // Treat this as a candidate failure so partial listeners/media are released
        // and the ordered fallback path remains the single recovery mechanism.
        failCandidate(request, index, "media-listener-failed", error);
        return;
      }
      scheduleCandidateTimeout(request, index);

      try {
        if (typeof media.load === "function") media.load();
        if (request.autoPlay && applyStartPosition()) startMediaPlayback(request, index);
      } catch (error) {
        handlePlayError(request, index, "play-threw", error);
      }
    }

    function blockAutoplay(request, index, error) {
      if (active !== request || request.terminal || request.index !== index) return;
      if (request.timer !== null) clearTimeout(request.timer);
      request.timer = null;
      request.blocked = true;
      const errorInfo = makeErrorInfo("AUDIO_AUTOPLAY_BLOCKED", "瀏覽器阻擋自動播放，需要使用者手動啟動", false, error);
      publish({ status: "blocked", sequence: request.sequence, candidateIndex: index + 1,
        candidateSource: request.candidate && request.candidate.source || null,
        error: "AUDIO_AUTOPLAY_BLOCKED", errorInfo, failures: request.failures });
      settle(request, result("blocked", request, { error: "AUDIO_AUTOPLAY_BLOCKED", errorInfo, message: error && error.message ? error.message : "browser autoplay was blocked" }));
    }

    function handlePlayError(request, index, reason, error, playAttemptId) {
      if (active !== request || request.terminal || request.index !== index) return;
      // A play() promise may reject after pause(), resume(), or a later play() call.
      // Only the latest attempt may affect the current candidate/request state.
      if (playAttemptId !== undefined && request.playAttemptId !== playAttemptId) return;
      if (request.userPaused || request.playbackStarted) return;
      if (error && error.name === "NotAllowedError") blockAutoplay(request, index, error);
      else failCandidate(request, index, reason, error);
    }

    function startMediaPlayback(request, index) {
      if (active !== request || request.terminal || request.index !== index || !request.media || request.positionReady !== true) return false;
      const playAttemptId = ++request.playAttemptId;
      try {
        const playResult = request.media.play();
        if (playResult && typeof playResult.then === "function") playResult.catch(error => handlePlayError(request, index, "play-rejected", error, playAttemptId));
      } catch (error) {
        handlePlayError(request, index, "play-threw", error, playAttemptId);
      }
      return true;
    }

    function pause() {
      if (!active || active.terminal || !active.media || state.status !== "playing") return false;
      active.userPaused = true;
      active.playbackStarted = false;
      // Invalidate any unresolved play() promise from before this pause.
      active.playAttemptId += 1;
      safePause(active.media);
      publish({ status: "paused", sequence: active.sequence, candidateIndex: active.index + 1,
        candidateSource: active.candidate && active.candidate.source || null, error: null, failures: active.failures });
      return true;
    }

    function resume() {
      if (!active || active.terminal || !active.media || !["ready", "blocked", "paused"].includes(state.status)) return false;
      const request = active;
      request.blocked = false;
      request.userPaused = false;
      request.playbackStarted = false;
      if (request.timer !== null) clearTimeout(request.timer);
      scheduleCandidateTimeout(request, request.index);
      publish({ status: "loading", sequence: request.sequence, candidateIndex: request.index + 1,
        candidateSource: request.candidate && request.candidate.source || null, error: null, failures: request.failures });
      return startMediaPlayback(request, request.index);
    }

    function play(candidates, options) {
      if (disposed) return Promise.resolve(Object.freeze({ status: "failed", error: "AUDIO_SERVICE_DISPOSED", errorInfo: makeErrorInfo("AUDIO_SERVICE_DISPOSED", "音訊服務已釋放，無法開始播放", false) }));
      let normalized;
      try { normalized = normalizeCandidates(candidates); }
      catch (error) { return Promise.resolve(Object.freeze({ status: "failed", error: "AUDIO_CANDIDATES_INVALID", errorInfo: makeErrorInfo("AUDIO_CANDIDATES_INVALID", "音訊候選格式無效", false, error), message: error.message })); }
      if (!normalized.length) {
        if (active) terminate(active, "cancelled", "superseded-by-empty-request");
        const nextSequence = ++sequence;
        const errorInfo = makeErrorInfo("AUDIO_NO_CANDIDATES", "目前歌曲沒有可嘗試的音訊候選", false);
        const empty = Object.freeze({ status: "failed", sequence: nextSequence, error: "AUDIO_NO_CANDIDATES", errorInfo, candidateIndex: null, candidateSource: null, failures: Object.freeze([]) });
        publish({ status: "failed", sequence: nextSequence, candidateIndex: null, candidateSource: null, error: empty.error, errorInfo, failures: [] });
        return Promise.resolve(empty);
      }
      const settings = options && typeof options === "object" ? options : {};
      const timeoutMs = settings.timeoutMs === undefined ? defaultTimeoutMs : settings.timeoutMs;
      if (!Number.isFinite(timeoutMs) || timeoutMs < 1 || timeoutMs > 120000) {
        const error = new RangeError("timeoutMs must be between 1 and 120000");
        return Promise.resolve(Object.freeze({ status: "failed", error: "AUDIO_TIMEOUT_INVALID", errorInfo: makeErrorInfo("AUDIO_TIMEOUT_INVALID", "音訊逾時設定超出允許範圍", false, error), message: error.message }));
      }
      const clipStartSeconds = settings.clipStartSeconds === undefined ? 0 : settings.clipStartSeconds;
      const clipSeconds = settings.clipSeconds === undefined ? 20 : settings.clipSeconds;
      if (!Number.isFinite(clipStartSeconds) || clipStartSeconds < 0 || clipStartSeconds > 600
        || !Number.isFinite(clipSeconds) || clipSeconds < 1 || clipSeconds > 120) {
        return Promise.resolve(Object.freeze({ status: "failed", error: "AUDIO_START_POSITION_INVALID", errorInfo: makeErrorInfo("AUDIO_START_POSITION_INVALID", "音訊片段位置設定無效", false) }));
      }
      if (settings.signal && settings.signal.aborted) return Promise.resolve(Object.freeze({ status: "cancelled", reason: "aborted-before-start" }));
      if (active) terminate(active, "cancelled", "superseded");
      const request = {
        sequence: ++sequence, candidates: normalized, timeoutMs, signal: settings.signal || null,
        abortHandler: null, index: -1, candidate: null, media: null, timer: null,
        handlers: null, failures: [], settled: false, terminal: false, blocked: false,
        userPaused: false, playbackStarted: false, playAttemptId: 0,
        autoPlay: settings.autoPlay !== false, resolve: null,
        randomSample: settings.randomSample === true,
        clipStartSeconds,
        clipSeconds,
        random: typeof settings.random === "function" ? settings.random : Math.random,
        positionReady: false, startPositionSeconds: null, canPlaySeen: false
      };
      const promise = new Promise(resolve => { request.resolve = resolve; });
      active = request;
      if (request.signal) {
        request.abortHandler = () => terminate(request, "cancelled", "aborted");
        request.signal.addEventListener("abort", request.abortHandler, { once: true });
      }
      attemptCandidate(request, 0);
      return promise;
    }

    function setVolume(value) {
      if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 1 || disposed) return false;
      volume = value; if (active && !active.terminal && active.media) { try { active.media.volume = volume; } catch (_) { return false; } }
      return true;
    }
    function setMuted(value) {
      if (typeof value !== "boolean" || disposed) return false;
      muted = value; if (active && !active.terminal && active.media) { try { active.media.muted = muted; } catch (_) { return false; } }
      return true;
    }
    function seek(positionSeconds) {
      if (typeof positionSeconds !== "number" || !Number.isFinite(positionSeconds) || positionSeconds < 0 || disposed
        || !active || active.terminal || !active.media) return false;
      const duration = Number(active.media.duration);
      if (!Number.isFinite(duration) || duration <= 0) return false;
      try { active.media.currentTime = Math.min(duration, positionSeconds); return true; }
      catch (_) { return false; }
    }
    function cancel() { return terminate(active, "cancelled", "cancelled-by-caller"); }
    function stop() { return terminate(active, "stopped", "stopped-by-caller"); }
    function dispose() {
      if (disposed) return false;
      if (active) terminate(active, "cancelled", "disposed");
      disposed = true;
      publish({ status: "disposed", sequence, candidateIndex: null, candidateSource: null, error: null, failures: [] });
      listeners.clear();
      return true;
    }
    function subscribe(listener) {
      if (typeof listener !== "function") throw new TypeError("listener must be a function");
      listeners.add(listener);
      let subscribed = true;
      return function unsubscribe() { if (!subscribed) return; subscribed = false; listeners.delete(listener); };
    }

    function getPlaybackMetrics() {
      const media = active && !active.terminal ? active.media : null;
      const currentTime = Number(media && media.currentTime);
      const duration = Number(media && media.duration);
      return Object.freeze({ available: Boolean(media),
        currentTime: Number.isFinite(currentTime) && currentTime >= 0 ? currentTime : null,
        duration: Number.isFinite(duration) && duration >= 0 ? duration : null,
        paused: media ? media.paused === true : null, ended: media ? media.ended === true : null });
    }

    return Object.freeze({ play, pause, resume, cancel, stop, setVolume, setMuted, seek, dispose, subscribe, getState: () => state, getPlaybackMetrics,
      getSubscriberErrors: () => listenerErrors.slice(), clearSubscriberErrors: () => { listenerErrors.length = 0; },
      get isDisposed() { return disposed; } });
  }

  global.AMQAudio = global.AMQAudio || {};
  global.AMQAudio.audioService = Object.freeze({ createAudioService });
})(window);
