/* Coordinates exclusive playback ownership without creating another audio or clock service. */
(function (global) {
  "use strict";
  let nextLeaseId = 1;
  function coordinatorError(code, message) { const error = new Error(message); error.name = "PlaybackCoordinatorError"; error.code = code; return error; }
  function createPlaybackCoordinator() {
    let current = null;
    let disposed = false;
    let revoking = false;
    let generation = 0;
    const errors = [];
    function recordError(error, ownerId) { errors.push(Object.freeze({ ownerId, message: error && error.message || String(error) })); if (errors.length > 20) errors.shift(); }
    function revokeCurrent(reason) {
      const previous = current;
      if (!previous) return false;
      current = null;
      previous.active = false;
      generation += 1;
      if (typeof previous.onRevoke === "function") {
        const wasRevoking = revoking;
        revoking = true;
        try { previous.onRevoke(Object.freeze({ reason, ownerId: previous.ownerId, generation })); }
        catch (error) { recordError(error, previous.ownerId); }
        finally { revoking = wasRevoking; }
      }
      return true;
    }
    function acquire(ownerId, options) {
      if (disposed) throw coordinatorError("PLAYBACK_COORDINATOR_DISPOSED", "播放權協調器已釋放。");
      if (revoking) throw coordinatorError("PLAYBACK_COORDINATOR_REVOKING", "播放權正在交接中，請在撤銷回呼返回後重新取得。");
      if (typeof ownerId !== "string" || !ownerId.trim()) throw coordinatorError("PLAYBACK_OWNER_INVALID", "播放權 owner ID 無效。");
      const id = ownerId.trim(); const opts = options && typeof options === "object" ? options : {};
      if (current && current.active && current.ownerId === id) {
        if (typeof opts.onRevoke === "function") current.onRevoke = opts.onRevoke;
        return current.lease;
      }
      if (current) revokeCurrent("superseded");
      const entry = { ownerId: id, token: nextLeaseId++, active: true, onRevoke: typeof opts.onRevoke === "function" ? opts.onRevoke : null, lease: null };
      const token = entry.token;
      entry.lease = Object.freeze({ ownerId: id, token,
        release() { if (!entry.active) return false; entry.active = false; if (current && current.token === token) { current = null; generation += 1; } return true; },
        get isActive() { return entry.active && !disposed && Boolean(current && current.token === token); }
      });
      current = entry; generation += 1;
      return entry.lease;
    }
    function dispose() { if (disposed) return false; disposed = true; revokeCurrent("coordinator-disposed"); generation += 1; return true; }
    return Object.freeze({ acquire, dispose,
      getState() { return Object.freeze({ ownerId: current && current.active ? current.ownerId : null, generation, disposed }); },
      getErrors() { return errors.slice(); },
      get isDisposed() { return disposed; }
    });
  }
  global.AMQAudio = global.AMQAudio || {};
  global.AMQAudio.playbackCoordinator = Object.freeze({ createPlaybackCoordinator });
})(typeof window !== "undefined" ? window : globalThis);
