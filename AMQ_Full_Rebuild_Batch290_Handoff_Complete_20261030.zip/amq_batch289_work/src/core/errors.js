/* Stable error contract for cross-module reporting. No DOM or console dependency. */
(function (global) {
  "use strict";

  const categories = new Set([
    "validation", "data", "network", "audio", "storage", "state", "lifecycle", "external", "unknown"
  ]);

  function snapshotDetails(value, depth = 0) {
    if (value === null || typeof value === "string" || typeof value === "boolean") return value;
    if (typeof value === "number") return Number.isFinite(value) ? value : null;
    if (depth >= 5) return "[truncated]";
    if (Array.isArray(value)) return Object.freeze(value.slice(0, 100).map(item => snapshotDetails(item, depth + 1)));
    if (typeof value === "object") {
      if (Object.prototype.toString.call(value) !== "[object Object]") return String(value);
      const output = {};
      for (const key of Object.keys(value).slice(0, 100)) {
        if (key === "__proto__" || key === "constructor" || key === "prototype") continue;
        output[key] = snapshotDetails(value[key], depth + 1);
      }
      return Object.freeze(output);
    }
    return String(value);
  }

  function createError(input) {
    if (!input || typeof input !== "object" || Array.isArray(input)) {
      throw new TypeError("error input must be an object");
    }
    const code = typeof input.code === "string" ? input.code.trim() : "";
    const message = typeof input.message === "string" ? input.message.trim() : "";
    if (!code) throw new TypeError("error code must be a non-empty string");
    if (!message) throw new TypeError("error message must be a non-empty string");
    const category = categories.has(input.category) ? input.category : "unknown";
    const result = {
      name: "AMQError",
      code,
      category,
      message,
      retryable: input.retryable === true,
      details: input.details === undefined ? null : snapshotDetails(input.details)
    };
    if (input.cause !== undefined && input.cause !== null) {
      const cause = input.cause;
      result.cause = Object.freeze(cause && typeof cause === "object"
        ? { name: typeof cause.name === "string" ? cause.name.slice(0, 100) : "Error", message: typeof cause.message === "string" ? cause.message.slice(0, 1000) : String(cause).slice(0, 1000) }
        : { name: "Error", message: String(cause).slice(0, 1000) });
    }
    return Object.freeze(result);
  }

  function fromException(error, defaults) {
    const options = defaults && typeof defaults === "object" ? defaults : {};
    let message = options.message;
    if (!message && error && typeof error.message === "string" && error.message.trim()) message = error.message;
    if (!message) message = "發生未預期錯誤";
    return createError({
      code: options.code || "UNEXPECTED_ERROR",
      category: options.category || "unknown",
      message,
      retryable: options.retryable === true,
      details: options.details,
      cause: error
    });
  }

  // Convert boundary values into the stable cross-module contract before UI projection.
  function normalize(error, defaults) {
    const options = defaults && typeof defaults === "object" ? defaults : {};
    if (error && typeof error === "object" && !Array.isArray(error)
      && typeof error.code === "string" && error.code.trim()
      && typeof error.message === "string" && error.message.trim()) {
      return createError({
        code: error.code, category: error.category, message: error.message,
        retryable: error.retryable, details: error.details, cause: error.cause
      });
    }
    const fallbackOptions = { ...options };
    if (error && typeof error.message === "string" && error.message.trim()) {
      fallbackOptions.message = error.message;
    }
    if (fallbackOptions.details === undefined && error && typeof error === "object" && error.details !== undefined) {
      fallbackOptions.details = error.details;
    }
    return fromException(error, fallbackOptions);
  }

  global.AMQCore = global.AMQCore || {};
  global.AMQCore.errors = { createError, fromException, normalize, categories: Object.freeze([...categories]) };
})(window);
