/* Owns disposable resources for one module/app lifetime. No DOM dependency. */
(function (global) {
  "use strict";

  function createScope(timerHost) {
    const timers = timerHost || global;
    const cleanups = [];
    const AbortControllerCtor = global.AbortController || (typeof AbortController === "function" ? AbortController : null);
    const controller = AbortControllerCtor ? new AbortControllerCtor() : null;
    let disposed = false;

    function removeEntry(entry) {
      const index = cleanups.indexOf(entry);
      if (index !== -1) cleanups.splice(index, 1);
    }

    function add(cleanup) {
      if (typeof cleanup !== "function") {
        throw new TypeError("cleanup must be a function");
      }
      if (disposed) {
        cleanup();
        return function noop() {};
      }

      let active = true;
      function run() {
        if (!active) return;
        active = false;
        removeEntry(run);
        cleanup();
      }
      cleanups.push(run);

      return run;
    }

    function listen(target, eventName, handler, options) {
      if (!target || typeof target.addEventListener !== "function" ||
          typeof target.removeEventListener !== "function") {
        throw new TypeError("target must support addEventListener/removeEventListener");
      }
      if (typeof handler !== "function") throw new TypeError("handler must be a function");
      target.addEventListener(eventName, handler, options);
      return add(function () {
        target.removeEventListener(eventName, handler, options);
      });
    }

    function timeout(handler, delay) {
      if (typeof handler !== "function") throw new TypeError("handler must be a function");
      let active = true;
      let unregister = function noop() {};
      const id = timers.setTimeout(function () {
        if (!active) return;
        active = false;
        unregister();
        if (!disposed) handler();
      }, delay);
      unregister = add(function () {
        active = false;
        timers.clearTimeout(id);
      });
      return function cancelTimeout() { return unregister(); };
    }

    function interval(handler, delay) {
      if (typeof handler !== "function") throw new TypeError("handler must be a function");
      let active = true;
      // clearInterval cannot retract a callback that the host has already queued.
      // Check both the individual registration and the owning scope at invocation.
      const id = timers.setInterval(function () {
        if (active && !disposed) handler();
      }, delay);
      return add(function () {
        active = false;
        timers.clearInterval(id);
      });
    }

    function observe(observer, target, options) {
      if (!observer || typeof observer.observe !== "function" || typeof observer.disconnect !== "function") {
        throw new TypeError("observer must support observe/disconnect");
      }
      observer.observe(target, options);
      return add(function () { observer.disconnect(); });
    }

    function dispose() {
      if (disposed) return [];
      disposed = true;
      const errors = [];
      // Cancel in-flight work before releasing listeners/timers/observers.
      if (controller && !controller.signal.aborted) {
        try { controller.abort(new Error("Lifecycle scope disposed")); }
        catch (error) { errors.push(error); }
      }
      while (cleanups.length) {
        const cleanup = cleanups.pop();
        try { cleanup(); } catch (error) { errors.push(error); }
      }
      return errors;
    }

    return {
      add,
      listen,
      timeout,
      interval,
      observe,
      dispose,
      get signal() { return controller ? controller.signal : null; },
      get isDisposed() { return disposed; },
      get size() { return cleanups.length; }
    };
  }

  global.AMQCore = global.AMQCore || {};
  global.AMQCore.lifecycle = { createScope };
})(window);
