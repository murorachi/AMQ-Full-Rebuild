/* Minimal single-source state store. No external dependencies. */
(function (global) {
  "use strict";
  const allowedModes = new Set(["AMQ", "EMQ", "MIX"]);
  let state = Object.freeze({
    mode: "AMQ",
    questionStatus: "idle",
    dataStatus: "not-loaded"
  });
  const allowedDataStatuses = new Set(["not-loaded", "loading", "loaded", "partial", "empty", "failed"]);
  const listeners = new Set();
  const subscriberErrors = [];
  const notificationQueue = [];
  let isNotifying = false;
  const allowedKeys = new Set([
    "mode", "questionStatus", "dataStatus", "dataError",
    "dataInputCount", "dataValidCount", "dataRejectedCount"
  ]);
  const countKeys = ["dataInputCount", "dataValidCount", "dataRejectedCount"];

  function getState() { return state; }

  function update(patch) {
    if (!patch || typeof patch !== "object" || Array.isArray(patch)) {
      throw new TypeError("state patch must be an object");
    }
    Object.keys(patch).forEach((key) => {
      if (!allowedKeys.has(key)) throw new TypeError("Unsupported state field: " + key);
    });
    const next = { ...state, ...patch };
    if (!allowedModes.has(next.mode)) throw new Error("Unsupported mode: " + next.mode);
    if (!allowedDataStatuses.has(next.dataStatus)) throw new Error("Unsupported data status: " + next.dataStatus);
    if (next.dataError !== null && next.dataError !== undefined && (typeof next.dataError !== "object" || typeof next.dataError.code !== "string")) {
      throw new TypeError("dataError must be a normalized error or null");
    }
    countKeys.forEach((key) => {
      if (next[key] !== undefined && (!Number.isSafeInteger(next[key]) || next[key] < 0)) {
        throw new TypeError(key + " must be a non-negative safe integer");
      }
    });
    const committedState = Object.freeze(next);
    state = committedState;
    notificationQueue.push(committedState);
    // Serialize notifications so a listener-triggered update is delivered only after
    // every active listener has received the snapshot that caused the current pass.
    // This preserves commit order and keeps observer diagnostics tied to that snapshot.
    if (!isNotifying) {
      isNotifying = true;
      try {
        while (notificationQueue.length) {
          const snapshot = notificationQueue.shift();
          [...listeners].forEach((listener) => {
            if (!listeners.has(listener)) return;
            try { listener(snapshot); }
            catch (error) {
              subscriberErrors.push(Object.freeze({ error, state: snapshot }));
              if (subscriberErrors.length > 50) subscriberErrors.shift();
            }
          });
        }
      } finally {
        isNotifying = false;
      }
    }
    return state;
  }

  function getSubscriberErrors() { return subscriberErrors.slice(); }
  function clearSubscriberErrors() { subscriberErrors.length = 0; }

  function subscribe(listener) {
    if (typeof listener !== "function") throw new TypeError("listener must be a function");
    listeners.add(listener);
    let active = true;
    return function unsubscribe() {
      if (!active) return;
      active = false;
      listeners.delete(listener);
    };
  }

  global.AMQCore = global.AMQCore || {};
  global.AMQCore.state = { getState, update, subscribe, getSubscriberErrors, clearSubscriberErrors, allowedModes: Object.freeze([...allowedModes]), allowedDataStatuses: Object.freeze([...allowedDataStatuses]) };
})(window);
