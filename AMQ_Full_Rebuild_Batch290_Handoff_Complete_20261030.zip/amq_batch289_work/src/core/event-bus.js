/* Optional lightweight event bus. Prefer direct module contracts unless events are justified. */
(function (global) {
  "use strict";
  const handlers = new Map();

  function on(name, handler) {
    if (typeof handler !== "function") throw new TypeError("handler must be a function");
    if (!handlers.has(name)) handlers.set(name, new Set());
    handlers.get(name).add(handler);
    let active = true;
    return function unsubscribe() {
      if (!active) return;
      active = false;
      const set = handlers.get(name);
      if (!set) return;
      set.delete(handler);
      if (set.size === 0) handlers.delete(name);
    };
  }

  function emit(name, payload) {
    const set = handlers.get(name);
    if (!set) return;
    [...set].forEach((handler) => handler(payload));
  }

  function clear() { handlers.clear(); }

  global.AMQCore = global.AMQCore || {};
  global.AMQCore.events = { on, emit, clear };
})(window);
