/* Deterministic work-title-only automatic SRS assessment. FSRS remains a four-grade scheduler. */
(function (global) {
  "use strict";
  const RULE_VERSION = "work-title-latency-v1";
  function assess(result, target) {
    if (!result || typeof result !== "object") return Object.freeze({ grade: null, reasonCodes: Object.freeze(["insufficient_signals"]), ruleVersion: RULE_VERSION });
    const activeTarget = target || result.target;
    if (activeTarget !== "anime" && activeTarget !== "all") {
      return Object.freeze({ grade: null, reasonCodes: Object.freeze(["non_work_target_ignored"]), ruleVersion: RULE_VERSION });
    }
    if (result.kind === "revealed" || result.kind === "unplayed-skip" || result.kind === "cancelled") {
      return Object.freeze({ grade: null, reasonCodes: Object.freeze(["no_work_title_answer"]), ruleVersion: RULE_VERSION });
    }
    const workCorrect = activeTarget === "all"
      ? Boolean(result.correctByTarget && result.correctByTarget.anime === true)
      : result.correct === true;
    if (!workCorrect) return Object.freeze({ grade: 1, reasonCodes: Object.freeze(["work_title_incorrect"]), ruleVersion: RULE_VERSION });
    if (result.elapsedSeconds === null || result.elapsedSeconds === undefined || result.elapsedSeconds === "") {
      return Object.freeze({ grade: null, reasonCodes: Object.freeze(["insufficient_latency"]), ruleVersion: RULE_VERSION });
    }
    const elapsed = Number(result.elapsedSeconds);
    if (!Number.isFinite(elapsed) || elapsed < 0) {
      return Object.freeze({ grade: null, reasonCodes: Object.freeze(["insufficient_latency"]), ruleVersion: RULE_VERSION });
    }
    if (elapsed <= 10) return Object.freeze({ grade: 4, reasonCodes: Object.freeze(["work_title_correct_fast"]), ruleVersion: RULE_VERSION });
    if (elapsed <= 15) return Object.freeze({ grade: 3, reasonCodes: Object.freeze(["work_title_correct_medium"]), ruleVersion: RULE_VERSION });
    return Object.freeze({ grade: 2, reasonCodes: Object.freeze(["work_title_correct_slow"]), ruleVersion: RULE_VERSION });
  }
  global.AMQLearning = global.AMQLearning || {};
  global.AMQLearning.assessmentEngine = Object.freeze({ RULE_VERSION, assess });
})(window);
