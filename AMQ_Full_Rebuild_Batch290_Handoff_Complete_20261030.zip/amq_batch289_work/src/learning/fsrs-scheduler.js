/* DOM-free port of the observed FSRS-6 default scheduler and song-learning steps. */
(function (global) {
  "use strict";
  const VERSION = "FSRS-6-default+song-learning-steps-v1";
  const DAY_MS = 86400000;
  const MINUTE_MS = 60000;
  const WEIGHTS = Object.freeze([0.212,1.2931,2.3065,8.2956,6.4133,0.8334,3.0194,0.001,1.8722,0.1666,0.796,1.4835,0.0614,0.2629,1.6483,0.6014,1.8729,0.5425,0.0912,0.0658,0.1542]);
  const FACTOR = Math.pow(0.9, -1 / WEIGHTS[20]) - 1;
  const VALID_STATES = new Set(["new", "learning", "review", "suspended"]);
  const DEFAULT_SETTINGS = Object.freeze({ dailyNew: 30, batchSize: 25, desiredRetention: 0.9,
    learningStepsMinutes: Object.freeze([1, 10]), hardStepMinutes: 5, relearnMinutes: 10,
    easyGraduatingDays: 4, maxIntervalDays: 36500 });

  function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }
  function clone(value) { return JSON.parse(JSON.stringify(value)); }
  function localDay(time) {
    const date = new Date(time);
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
  }
  function emptySchedule(now) {
    return { schemaVersion: 1, algorithm: VERSION, createdAt: new Date(now).toISOString(), settings: clone(DEFAULT_SETTINGS), cards: {} };
  }
  function isValidSchedule(value) {
    if (!value || typeof value !== "object" || Array.isArray(value) || value.schemaVersion !== 1
      || !value.cards || typeof value.cards !== "object" || Array.isArray(value.cards)
      || !value.settings || typeof value.settings !== "object" || Array.isArray(value.settings)) return false;
    const settings = value.settings;
    if (!Number.isFinite(Number(settings.dailyNew)) || Number(settings.dailyNew) < 0 || Number(settings.dailyNew) > 500
      || !Number.isFinite(Number(settings.batchSize)) || Number(settings.batchSize) < 1 || Number(settings.batchSize) > 500
      || !Number.isFinite(Number(settings.desiredRetention)) || Number(settings.desiredRetention) < 0.7 || Number(settings.desiredRetention) > 0.97) return false;
    for (const [id, card] of Object.entries(value.cards)) {
      if (!card || typeof card !== "object" || String(card.songId) !== String(id) || !VALID_STATES.has(card.state)
        || !Number.isFinite(Number(card.dueAt)) || !Number.isFinite(Number(card.reps || 0)) || Number(card.reps || 0) < 0
        || !Number.isFinite(Number(card.lapses || 0)) || Number(card.lapses || 0) < 0) return false;
      if (card.stability !== null && card.stability !== undefined && (!Number.isFinite(Number(card.stability)) || Number(card.stability) < 0)) return false;
      if (card.difficulty !== null && card.difficulty !== undefined && (!Number.isFinite(Number(card.difficulty)) || Number(card.difficulty) < 0 || Number(card.difficulty) > 10)) return false;
      if (card.reviewLog !== undefined && !Array.isArray(card.reviewLog)) return false;
    }
    return true;
  }
  function makeCard(songId, now = Date.now()) {
    return { songId: String(songId), state: "new", resumeState: "new", createdAt: now, dueAt: now,
      firstReviewedAt: null, lastReviewedAt: null, lastRating: null, lastIntervalDays: 0, reps: 0, lapses: 0,
      learningStep: 0, relearning: false, stability: null, difficulty: null, reviewLog: [] };
  }
  function initDifficulty(grade) { return clamp(WEIGHTS[4] - Math.exp(WEIGHTS[5] * (grade - 1)) + 1, 1, 10); }
  function initMemory(card, grade) { card.stability = WEIGHTS[grade - 1]; card.difficulty = initDifficulty(grade); }
  function updateMemory(card, grade, elapsedDays) {
    const stability = Math.max(0.001, Number(card.stability) || 0.001);
    const difficulty = clamp(Number(card.difficulty) || initDifficulty(grade), 1, 10);
    const easyDifficulty = initDifficulty(4);
    const nextDifficulty = clamp(WEIGHTS[7] * easyDifficulty + (1 - WEIGHTS[7]) * (difficulty - WEIGHTS[6] * (grade - 3)), 1, 10);
    let nextStability;
    if (elapsedDays < 1) {
      nextStability = stability * Math.exp(WEIGHTS[17] * (grade - 3 + WEIGHTS[18])) * Math.pow(stability, -WEIGHTS[19]);
    } else {
      const retrievability = clamp(Math.pow(1 + FACTOR * elapsedDays / stability, -WEIGHTS[20]), 0.01, 1);
      if (grade === 1) {
        nextStability = WEIGHTS[11] * Math.pow(nextDifficulty, -WEIGHTS[12]) * (Math.pow(stability + 1, WEIGHTS[13]) - 1) * Math.exp(WEIGHTS[14] * (1 - retrievability));
      } else {
        const gradeModifier = grade === 2 ? WEIGHTS[15] : grade === 4 ? WEIGHTS[16] : 1;
        nextStability = stability * (Math.exp(WEIGHTS[8]) * (11 - nextDifficulty) * Math.pow(stability, -WEIGHTS[9])
          * (Math.exp(WEIGHTS[10] * (1 - retrievability)) - 1) * gradeModifier + 1);
      }
    }
    card.stability = clamp(Number.isFinite(nextStability) ? nextStability : stability, 0.01, 36500);
    card.difficulty = nextDifficulty;
  }
  function intervalDays(card, settings) {
    const retention = clamp(Number(settings.desiredRetention) || 0.9, 0.7, 0.97);
    const stability = Math.max(0.01, Number(card.stability) || 1);
    const days = stability / FACTOR * (Math.pow(retention, -1 / WEIGHTS[20]) - 1);
    return clamp(Math.round(Number.isFinite(days) ? days : 1), 1, Math.max(1, Number(settings.maxIntervalDays) || 36500));
  }
  function addReviewLog(card, grade, now, intervalMs) {
    card.reviewLog = Array.isArray(card.reviewLog) ? card.reviewLog : [];
    card.reviewLog.push({ at: now, grade, intervalMs, state: card.state, stability: card.stability, difficulty: card.difficulty });
    if (card.reviewLog.length > 20) card.reviewLog = card.reviewLog.slice(-20);
  }
  function applyRatingToCard(original, grade, now = Date.now(), settings = DEFAULT_SETTINGS) {
    const card = clone(original);
    grade = Number(grade);
    if (![1, 2, 3, 4].includes(grade)) throw new Error("Invalid FSRS rating");
    if (card.state === "suspended") card.state = VALID_STATES.has(card.resumeState) && card.resumeState !== "suspended" ? card.resumeState : "new";
    const oldState = card.state;
    const lastReviewedAt = Number(card.lastReviewedAt) || 0;
    const elapsedDays = lastReviewedAt ? Math.max(0, (now - lastReviewedAt) / DAY_MS) : 0;
    if (card.stability == null || card.difficulty == null) initMemory(card, grade);
    else updateMemory(card, grade, elapsedDays);
    card.reps = (Number(card.reps) || 0) + 1;
    card.firstReviewedAt = Number(card.firstReviewedAt) || now;
    card.lastReviewedAt = now;
    card.lastRating = grade;
    let delayMs = DAY_MS;
    if (oldState === "new") {
      if (grade === 1) { card.state = "learning"; card.learningStep = 0; card.relearning = false; delayMs = Number(settings.learningStepsMinutes?.[0] || 1) * MINUTE_MS; }
      else if (grade === 2) { card.state = "learning"; card.learningStep = 0; card.relearning = false; delayMs = (Number(settings.hardStepMinutes) || 5) * MINUTE_MS; }
      else if (grade === 3) { card.state = "learning"; card.learningStep = 1; card.relearning = false; delayMs = Number(settings.learningStepsMinutes?.[1] || 10) * MINUTE_MS; }
      else { card.state = "review"; card.learningStep = 0; card.relearning = false; delayMs = (Number(settings.easyGraduatingDays) || 4) * DAY_MS; }
    } else if (oldState === "review") {
      if (grade === 1) { card.lapses = (Number(card.lapses) || 0) + 1; card.state = "learning"; card.learningStep = 0; card.relearning = true; delayMs = (Number(settings.relearnMinutes) || 10) * MINUTE_MS; }
      else { card.state = "review"; card.learningStep = 0; card.relearning = false; delayMs = intervalDays(card, settings) * DAY_MS; }
    } else if (oldState === "learning") {
      if (grade === 1) { card.state = "learning"; card.learningStep = 0; delayMs = Number(settings.learningStepsMinutes?.[0] || 1) * MINUTE_MS; }
      else if (grade === 2) { card.state = "learning"; delayMs = (card.relearning ? Number(settings.relearnMinutes) || 10 : (card.learningStep === 0 ? Number(settings.hardStepMinutes) || 5 : 20)) * MINUTE_MS; }
      else if (card.relearning) { card.state = "review"; card.learningStep = 0; card.relearning = false; delayMs = intervalDays(card, settings) * DAY_MS; }
      else if (grade === 3 && card.learningStep === 0) { card.state = "learning"; card.learningStep = 1; delayMs = Number(settings.learningStepsMinutes?.[1] || 10) * MINUTE_MS; }
      else { card.state = "review"; card.learningStep = 0; card.relearning = false; delayMs = grade === 4 ? Math.max(Number(settings.easyGraduatingDays) || 4, intervalDays(card, settings)) * DAY_MS : intervalDays(card, settings) * DAY_MS; }
    }
    card.lastIntervalDays = delayMs / DAY_MS;
    card.dueAt = now + delayMs;
    addReviewLog(card, grade, now, delayMs);
    return card;
  }
  function preview(card, grade, now, settings) {
    const next = applyRatingToCard(card, grade, now, settings);
    return Object.freeze({ dueAt: next.dueAt, intervalMs: next.lastIntervalDays * DAY_MS, state: next.state, stability: next.stability, difficulty: next.difficulty });
  }

  global.AMQLearning = global.AMQLearning || {};
  global.AMQLearning.fsrsScheduler = Object.freeze({ VERSION, DAY_MS, MINUTE_MS, WEIGHTS, FACTOR, VALID_STATES, DEFAULT_SETTINGS,
    clamp, localDay, emptySchedule, isValidSchedule, makeCard, initDifficulty, initMemory, updateMemory, intervalDays, applyRatingToCard, preview });
})(window);
