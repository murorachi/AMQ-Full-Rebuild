/* Pure dashboard projections over existing quiz history, familiarity and SRS snapshots. */
(function (global) {
  "use strict";
  const SOURCES = ["AMQ", "EMQ"];
  const TARGETS = ["anime", "title", "artist"];
  function isMap(value) { return Boolean(value && typeof value === "object" && !Array.isArray(value)); }
  function rows(value) { return Array.isArray(value) ? value : []; }
  function countFamiliarity(snapshot) {
    const result = { unknown: 0, level0: 0, level1: 0, level2: 0, level3: 0, level4: 0 };
    for (const raw of Object.values(isMap(snapshot) ? snapshot : {})) {
      const level = Number(raw);
      if (!Number.isInteger(level) || level < 0 || level > 4 || raw === null || raw === "") result.unknown++;
      else result[`level${level}`]++;
    }
    return result;
  }
  function srsCounts(value) {
    const source = isMap(value) ? value : {};
    return Object.freeze({ total: safeCount(source.total), active: safeCount(source.active), due: safeCount(source.due),
      new: safeCount(source.new), learning: safeCount(source.learning), review: safeCount(source.review), suspended: safeCount(source.suspended) });
  }
  function safeCount(value) { const number = Number(value); return Number.isFinite(number) && number > 0 ? Math.floor(number) : 0; }
  function buildDashboard(input) {
    const data = isMap(input) ? input : {};
    const history = rows(data.quizHistory).filter(row => isMap(row) && (row.source === "AMQ" || row.source === "EMQ") && typeof row.correct === "boolean");
    const sourceStats = Object.fromEntries(SOURCES.map(source => [source, { total: 0, correct: 0, wrong: 0 }]));
    const targetStats = Object.fromEntries(TARGETS.map(target => [target, { total: 0, correct: 0, wrong: 0 }]));
    const daily = {};
    const workProgress = new Map();
    let elapsedTotal = 0, elapsedCount = 0;
    for (const row of history) {
      const source = sourceStats[row.source];
      source.total++; row.correct ? source.correct++ : source.wrong++;
      const targetKey = TARGETS.includes(row.target) ? row.target : null;
      const workTitle = String(row.workTitle || row.animeTitle || row.animeEnglish || row.animeRomaji || "").trim();
      const workId = String(row.animeId ?? "").trim();
      // Work progress is a derived projection over answer history, not another persisted score.
      // Prefer source + typed work ID; title fallback is only for legacy rows without IDs.
      const workKey = workId ? `${row.source}:${String(row.workKind || "work")}:${workId}` : (workTitle ? `${row.source}:title:${workTitle.toLocaleLowerCase()}` : "");
      if (workKey) {
        let work = workProgress.get(workKey);
        if (!work) {
          work = { key: workKey, source: row.source, workId: workId || null, workKind: String(row.workKind || (row.source === "EMQ" ? "visual_novel_game" : "anime")),
            title: workTitle || `未命名作品（${workId}）`, total: 0, correct: 0, wrong: 0, songs: new Set(), lastAt: null };
          workProgress.set(workKey, work);
        }
        work.total++; row.correct ? work.correct++ : work.wrong++;
        if (row.songId != null && String(row.songId).trim()) work.songs.add(String(row.songId));
        const at = Date.parse(row.at || "");
        if (Number.isFinite(at) && (!work.lastAt || at > Date.parse(work.lastAt))) work.lastAt = new Date(at).toISOString();
      }
      if (targetKey) { targetStats[targetKey].total++; row.correct ? targetStats[targetKey].correct++ : targetStats[targetKey].wrong++; }
      const timestamp = Date.parse(row.at || "");
      if (Number.isFinite(timestamp)) {
        const day = new Date(timestamp).toISOString().slice(0, 10);
        daily[day] ||= { total: 0, correct: 0, wrong: 0 };
        daily[day].total++; row.correct ? daily[day].correct++ : daily[day].wrong++;
      }
      const elapsed = Number(row.elapsed);
      if (row.elapsed != null && row.elapsed !== "" && Number.isFinite(elapsed) && elapsed >= 0) { elapsedTotal += elapsed; elapsedCount++; }
    }
    const rate = stats => stats.total ? stats.correct / stats.total : null;
    for (const source of SOURCES) sourceStats[source] = Object.freeze({ ...sourceStats[source], accuracy: rate(sourceStats[source]) });
    for (const target of TARGETS) targetStats[target] = Object.freeze({ ...targetStats[target], accuracy: rate(targetStats[target]) });
    const familiarity = Object.freeze({ AMQ: Object.freeze(countFamiliarity(data.familiarityAMQ)), EMQ: Object.freeze(countFamiliarity(data.familiarityEMQ)) });
    const srs = Object.freeze({ AMQ: srsCounts(data.srsAMQ), EMQ: srsCounts(data.srsEMQ) });
    const workRows = [...workProgress.values()].map(work => Object.freeze({ key: work.key, source: work.source, workId: work.workId,
      workKind: work.workKind, title: work.title, total: work.total, correct: work.correct, wrong: work.wrong,
      accuracy: work.total ? work.correct / work.total : null, uniqueSongs: work.songs.size, lastAt: work.lastAt }))
      .sort((a, b) => b.total - a.total || String(b.lastAt || "").localeCompare(String(a.lastAt || "")) || a.title.localeCompare(b.title));
    const workProgressSummary = Object.freeze({ totalWorks: workRows.length, practicedWorks: workRows.length,
      totalAnswers: workRows.reduce((sum, work) => sum + work.total, 0), works: Object.freeze(workRows) });
    const recentDays = Object.entries(daily).sort(([a], [b]) => a.localeCompare(b)).slice(-30).map(([date, stats]) => Object.freeze({ date, ...stats, accuracy: rate(stats) }));
    const playback = rows(data.playbackHistory).filter(row => isMap(row) && (row.source === "AMQ" || row.source === "EMQ"));
    return Object.freeze({
      quiz: Object.freeze({ total: history.length, correct: history.filter(row => row.correct).length, wrong: history.filter(row => !row.correct).length,
        accuracy: rate({ total: history.length, correct: history.filter(row => row.correct).length }), averageElapsedSeconds: elapsedCount ? elapsedTotal / elapsedCount : null,
        bySource: Object.freeze(sourceStats), byTarget: Object.freeze(targetStats), recentDays: Object.freeze(recentDays) }),
      familiarity, srs, workProgress: workProgressSummary, playback: Object.freeze({ total: playback.length, bySource: Object.freeze(Object.fromEntries(SOURCES.map(source => [source, playback.filter(row => row.source === source).length]))), latest: playback[0] || null })
    });
  }
  global.AMQLearning = global.AMQLearning || {};
  global.AMQLearning.statisticsDashboard = Object.freeze({ buildDashboard });
})(window);
