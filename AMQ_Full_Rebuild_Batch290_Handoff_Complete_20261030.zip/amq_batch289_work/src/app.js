(function () {
  "use strict";
  const store = window.AMQCore.state;
  const lifecycle = window.AMQCore.lifecycle;
  let scope = null;
  let catalogBrowser = null;
  let quizPanel = null;
  let backupRestorePanel = null;
  let databaseUpdatePanel = null;
  let freePlayerDock = null;
  let statisticsDashboardPanel = null;
  let profilePanel = null;
  let skinImportPanel = null;
  let accountPanel = null;
  let multiplayerPanel = null;
  let playbackCoordinator = null;
  let audioService = null;
  let artworkAdapter = null;
  let artworkProviders = null;
  let artworkServiceClient = null;
  let anilistServiceClient = null;
  let anilistFeature = null;
  let vndbFeature = null;
  let vndbCharacterPanel = null;
  let chineseTitleProvider = null;
  let annArtworkAdapter = null;
  let runtimeBundle = null;
  const personalLibraryApi = window.AMQPersistence && window.AMQPersistence.personalLibraryStore;
  const appSettingsApi = window.AMQPersistence && window.AMQPersistence.appSettingsStore;
  const songTagsApi = window.AMQPersistence && window.AMQPersistence.songTagsStore;
  const familiarityApi = window.AMQPersistence && window.AMQPersistence.familiarityStore;
  let personalLibraryStore = null;
  let appSettingsStore = null;
  let songTagsStore = null;
  let workspacePreferencesStore = null;
  let workspacePreferencesPanel = null;
  let familiarityStore = null;

  function render(state) {
    const message = document.getElementById("app-message");
    const modeLabel = document.getElementById("current-mode");
    const questionLabel = document.getElementById("question-state");
    const dataLabel = document.getElementById("data-state");
    const status = document.getElementById("app-status");
    if (modeLabel) modeLabel.textContent = state.mode;
    const questionLabels = { idle: "尚未開始", ready: "等待播放", playing: "播放中／計時中", paused: "已暫停", answered: "已作答", "timed-out": "時間到", revealed: "已揭曉", finished: "回合完成" };
    if (questionLabel) questionLabel.textContent = questionLabels[state.questionStatus] || state.questionStatus;
    const dataLabels = {
      "not-loaded": "尚未載入真實曲庫", loading: "曲庫載入中", loaded: "曲庫已載入",
      partial: "曲庫部分載入，存在無效記錄", empty: "曲庫資料為空", failed: "曲庫載入失敗"
    };
    if (dataLabel) dataLabel.textContent = dataLabels[state.dataStatus] || "未知資料狀態";
    if (status) status.textContent = state.dataStatus === "loaded" ? "框架已啟動" : "等待正式曲庫";
    if (message) {
      if (state.dataError) {
        const error = window.AMQCore.errors.normalize(state.dataError, { code: "DATA_LOAD_FAILED", category: "data", message: "曲庫載入失敗" });
        message.textContent = `${error.code}：${error.message}`;
      }
      else if (state.dataStatus === "loaded") message.textContent = "曲庫已通過新版內部契約驗證；舊版相容性與音訊可用性仍需獨立驗收。";
      else message.textContent = "曲庫瀏覽介面已就緒，但目前未配置正式資料來源。沒有用假資料填補空白。";
    }
    document.querySelectorAll("[data-mode]").forEach(button => {
      button.setAttribute("aria-pressed", String(button.dataset.mode === state.mode));
    });
  }

  function mount() {
    if (scope && !scope.isDisposed) return;
    scope = lifecycle.createScope();
    try {
      personalLibraryStore = personalLibraryApi && personalLibraryApi.createPersonalLibraryStore();
      if (personalLibraryStore) scope.add(() => { personalLibraryStore.dispose(); personalLibraryStore = null; });
      appSettingsStore = appSettingsApi && appSettingsApi.createAppSettingsStore();
      if (appSettingsStore) scope.add(() => { appSettingsStore.dispose(); appSettingsStore = null; });
      songTagsStore = songTagsApi && songTagsApi.createSongTagsStore();
      if (songTagsStore) scope.add(() => { songTagsStore.dispose(); songTagsStore = null; });
      const workspacePreferencesApi = window.AMQPersistence && window.AMQPersistence.workspacePreferencesStore;
      workspacePreferencesStore = workspacePreferencesApi && workspacePreferencesApi.createWorkspacePreferencesStore();
      if (workspacePreferencesStore) scope.add(() => { workspacePreferencesStore.dispose(); workspacePreferencesStore = null; });
      if (window.AMQUI && window.AMQUI.workspacePreferencesPanel && typeof window.AMQUI.workspacePreferencesPanel.mount === "function" && workspacePreferencesStore) {
        workspacePreferencesPanel = window.AMQUI.workspacePreferencesPanel.mount({ preferencesStore: workspacePreferencesStore });
        if (workspacePreferencesPanel && typeof workspacePreferencesPanel.dispose === "function") scope.add(() => { workspacePreferencesPanel.dispose(); workspacePreferencesPanel = null; });
      }
      familiarityStore = familiarityApi && familiarityApi.createFamiliarityStore();
      if (familiarityStore) scope.add(() => { familiarityStore.dispose(); familiarityStore = null; });
      const playbackApi = window.AMQAudio && window.AMQAudio.playbackCoordinator;
      playbackCoordinator = playbackApi && typeof playbackApi.createPlaybackCoordinator === "function" ? playbackApi.createPlaybackCoordinator() : null;
      if (playbackCoordinator) scope.add(() => { playbackCoordinator.dispose(); playbackCoordinator = null; });
      const audioApi = window.AMQAudio && window.AMQAudio.audioService;
      audioService = audioApi && typeof audioApi.createAudioService === "function" ? audioApi.createAudioService() : null;
      if (audioService) scope.add(() => { if (audioService && typeof audioService.dispose === "function") audioService.dispose(); audioService = null; });
      document.querySelectorAll("[data-mode]").forEach(button => {
        scope.listen(button, "click", () => store.update({ mode: button.dataset.mode }));
      });
      const integrations = window.AMQIntegrations || {};
      if (integrations.externalServiceAdapter && integrations.artworkAdapter && integrations.artworkProviderFactory && integrations.vndbAdapter && integrations.annArtworkAdapter) {
        annArtworkAdapter = integrations.annArtworkAdapter.createAdapter();
        scope.add(() => { if (annArtworkAdapter) annArtworkAdapter.dispose(); annArtworkAdapter = null; });
        artworkServiceClient = integrations.externalServiceAdapter.createClient({ service: "vndb" });
        if (artworkServiceClient) scope.add(() => { if (artworkServiceClient) artworkServiceClient.dispose(); artworkServiceClient = null; });
        if (integrations.anilistAdapter) {
          anilistServiceClient = integrations.externalServiceAdapter.createClient({ service: "anilist" });
          if (anilistServiceClient) scope.add(() => { if (anilistServiceClient) anilistServiceClient.dispose(); anilistServiceClient = null; });
          anilistFeature = integrations.anilistAdapter.createAdapter(anilistServiceClient);
        }
        vndbFeature = integrations.vndbAdapter.createAdapter(artworkServiceClient);
        artworkProviders = integrations.artworkProviderFactory.createArtworkProviders({ annArtworkAdapter, anilistAdapter: anilistFeature, vndbAdapter: vndbFeature });
        chineseTitleProvider = artworkProviders && artworkProviders.chineseTitleProvider || null;
        if (artworkProviders) scope.add(() => { if (artworkProviders) artworkProviders.dispose(); artworkProviders = null; chineseTitleProvider = null; });
        artworkAdapter = integrations.artworkAdapter.createAdapter({ providers: artworkProviders.providers, getProviderDiagnostics: () => artworkProviders && typeof artworkProviders.getDiagnostics === "function" ? artworkProviders.getDiagnostics() : [] });
        if (artworkAdapter) scope.add(() => { if (artworkAdapter) artworkAdapter.dispose(); artworkAdapter = null; });
        if (artworkAdapter && window.AMQUI && window.AMQUI.appShell && typeof window.AMQUI.appShell.setArtworkAdapter === "function") {
          window.AMQUI.appShell.setArtworkAdapter(artworkAdapter, (source, workId) => runtimeBundle && typeof runtimeBundle.resolveArtworkRecord === "function" ? runtimeBundle.resolveArtworkRecord(source, workId) : null);
        }
      }
      if (window.AMQAppRuntime && typeof window.AMQAppRuntime.createRuntime === "function") {
        runtimeBundle = window.AMQAppRuntime.createRuntime({ stateStore: store });
        if (runtimeBundle) scope.add(() => { if (runtimeBundle) runtimeBundle.dispose(); runtimeBundle = null; });
      }
      if (artworkAdapter && window.AMQUI && window.AMQUI.appShell && typeof window.AMQUI.appShell.setArtworkAdapter === "function") {
        window.AMQUI.appShell.setArtworkAdapter(artworkAdapter, (source, workId) => runtimeBundle && typeof runtimeBundle.resolveArtworkRecord === "function" ? runtimeBundle.resolveArtworkRecord(source, workId) : null);
      }
      if (window.AMQCatalogBrowser && typeof window.AMQCatalogBrowser.mount === "function") {
        catalogBrowser = window.AMQCatalogBrowser.mount({ stateStore: store, runtime: runtimeBundle && runtimeBundle.runtime, personalLibraryStore, appSettingsStore, familiarityStore, songTagsStore, artworkAdapter, chineseTitleProvider });
        scope.add(() => { if (catalogBrowser) catalogBrowser.dispose(); catalogBrowser = null; });
      }
      if (window.AMQUI && window.AMQUI.vndbCharacterPanel && typeof window.AMQUI.vndbCharacterPanel.mount === "function" && vndbFeature) {
        vndbCharacterPanel = window.AMQUI.vndbCharacterPanel.mount({ adapter: vndbFeature });
        if (vndbCharacterPanel && typeof vndbCharacterPanel.dispose === "function") scope.add(() => { vndbCharacterPanel.dispose(); vndbCharacterPanel = null; });
      }
      if (window.AMQQuizPanel && typeof window.AMQQuizPanel.mount === "function" && document.getElementById("quiz-panel")) {
        quizPanel = window.AMQQuizPanel.mount({ stateStore: store, runtime: runtimeBundle && runtimeBundle.runtime, personalLibraryStore, appSettingsStore, familiarityStore, playbackCoordinator, audioService });
        scope.add(() => { if (quizPanel) quizPanel.dispose(); quizPanel = null; });
      }
      if (window.AMQUI && window.AMQUI.accountPanel && typeof window.AMQUI.accountPanel.mount === "function" && document.getElementById("account-panel")) {
        accountPanel = window.AMQUI.accountPanel.mount({ quizPanel });
        scope.add(() => { if (accountPanel) accountPanel.dispose(); accountPanel = null; });
      }
      if (window.AMQUI && window.AMQUI.multiplayerPanel && typeof window.AMQUI.multiplayerPanel.mount === "function" && document.getElementById("multiplayer-panel")) {
        multiplayerPanel = window.AMQUI.multiplayerPanel.mount({ playbackCoordinator, audioService });
        scope.add(() => { if (multiplayerPanel) multiplayerPanel.dispose(); multiplayerPanel = null; });
      }
      if (window.AMQUI && window.AMQUI.backupRestorePanel && typeof window.AMQUI.backupRestorePanel.createBackupRestorePanel === "function") {
        backupRestorePanel = window.AMQUI.backupRestorePanel.createBackupRestorePanel();
        if (backupRestorePanel && typeof backupRestorePanel.dispose === "function") scope.add(() => { backupRestorePanel.dispose(); backupRestorePanel = null; });
      }
      if (window.AMQUI && window.AMQUI.databaseUpdatePanel && typeof window.AMQUI.databaseUpdatePanel.createDatabaseUpdatePanel === "function" && runtimeBundle) {
        databaseUpdatePanel = window.AMQUI.databaseUpdatePanel.createDatabaseUpdatePanel({
          manager: runtimeBundle.databaseUpdate,
          exportPackage: () => runtimeBundle.exportDatabaseUpdatePackage()
        });
        if (databaseUpdatePanel && typeof databaseUpdatePanel.dispose === "function") scope.add(() => { databaseUpdatePanel.dispose(); databaseUpdatePanel = null; });
      }
      if (window.AMQUI && window.AMQUI.freePlayerDock && typeof window.AMQUI.freePlayerDock.mount === "function" && runtimeBundle) {
        freePlayerDock = window.AMQUI.freePlayerDock.mount({ stateStore: store, runtime: runtimeBundle.runtime });
        if (freePlayerDock && typeof freePlayerDock.dispose === "function") scope.add(() => { freePlayerDock.dispose(); freePlayerDock = null; });
      }
      if (window.AMQUI && window.AMQUI.statisticsDashboardPanel && typeof window.AMQUI.statisticsDashboardPanel.mount === "function") {
        statisticsDashboardPanel = window.AMQUI.statisticsDashboardPanel.mount({ runtime: runtimeBundle && runtimeBundle.runtime, artworkAdapter, stateStore: store });
        if (statisticsDashboardPanel && typeof statisticsDashboardPanel.dispose === "function") scope.add(() => { statisticsDashboardPanel.dispose(); statisticsDashboardPanel = null; });
      }
      if (window.AMQUI && window.AMQUI.profilePanel && typeof window.AMQUI.profilePanel.mount === "function" && statisticsDashboardPanel) {
        profilePanel = window.AMQUI.profilePanel.mount({ dashboard: statisticsDashboardPanel });
        if (profilePanel && typeof profilePanel.dispose === "function") scope.add(() => { profilePanel.dispose(); profilePanel = null; });
      }
      if (window.AMQUI && window.AMQUI.skinImportPanel && typeof window.AMQUI.skinImportPanel.mount === "function") {
        skinImportPanel = window.AMQUI.skinImportPanel.mount();
        if (skinImportPanel && typeof skinImportPanel.dispose === "function") scope.add(() => { skinImportPanel.dispose(); skinImportPanel = null; });
      }
      scope.add(store.subscribe(render));
      render(store.getState());
    } catch (error) {
      // Mount is transactional for resources already registered with the scope.
      // Roll them back so a later mount() can retry instead of reusing a half-live scope.
      const cleanupErrors = scope ? scope.dispose() : [];
      scope = null;
      catalogBrowser = null;
      quizPanel = null;
      backupRestorePanel = null;
      databaseUpdatePanel = null;
      freePlayerDock = null;
      statisticsDashboardPanel = null;
      profilePanel = null;
      skinImportPanel = null;
      accountPanel = null;
      multiplayerPanel = null;
      playbackCoordinator = null;
      audioService = null;
      artworkAdapter = null;
      artworkProviders = null;
      vndbFeature = null;
      vndbCharacterPanel = null;
      artworkServiceClient = null;
      annArtworkAdapter = null;
      runtimeBundle = null;
      personalLibraryStore = null;
      appSettingsStore = null;
      songTagsStore = null;
      workspacePreferencesStore = null;
      workspacePreferencesPanel = null;
      familiarityStore = null;
      if (cleanupErrors.length && error && typeof error === "object") error.cleanupErrors = cleanupErrors;
      throw error;
    }
  }

  function dispose() {
    if (!scope) return [];
    const errors = scope.dispose();
    scope = null;
    return errors;
  }

  window.AMQApp = Object.freeze({
    mount,
    dispose,
    configureRuntime(runtime) {
      if (!catalogBrowser || catalogBrowser.isDisposed) mount();
      if (!catalogBrowser) throw new Error("catalog browser module is not loaded");
      catalogBrowser.configureRuntime(runtime);
    }
  });
  mount();
})();
